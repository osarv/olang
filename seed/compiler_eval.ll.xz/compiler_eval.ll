; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/eval:Machine" = type { ptr, i32, i64, { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span", i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/eval:scope" = type { i64, i1, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i1, i1 }
%"compiler/eval:gkey" = type { i64, i32 }
%"compiler/eval:global" = type { i64, i1, i64, i64, i64, i1, i1, i1 }
%"compiler/eval:alloc" = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i32, i64, i1, i64, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" = type { i64, %"compiler/source:Span" }
%"compiler/eval:reg" = type { i64, i64, i64, i64, i64, i64, i64, i64 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/eval:frame" = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i64, i64, i1, i64, i32, i32, i64 }
%"compiler/eval:cfn" = type { i64, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, { i64, ptr } }
%"compiler/eval:task" = type { i64, i64, i64, i64, i64 }
%"compiler/eval:dkey" = type { i64, i32, i32, i32, i32, i64 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/eval:Snapshot" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range", i64, i64, %"compiler/mir:Range" }
%"compiler/eval:Image" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
@G_2ecompiler_2feval_2eB0 = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eCmpOps = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eCmpOps.k1 }>, align 8
@G_2ecompiler_2feval_2eCmpOps.k1 = internal constant <{ [24 x i8] }> <{ [24 x i8] c"\0D\00\00\00\0E\00\00\00\0F\00\00\00\10\00\00\00\11\00\00\00\12\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eFloatOps = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eFloatOps.k1 }>, align 8
@G_2ecompiler_2feval_2eFloatOps.k1 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\03\00\00\00\04\00\00\00\05\00\00\00\06\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eForeignId = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eIntOps = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eIntOps.k1 }>, align 8
@G_2ecompiler_2feval_2eIntOps.k1 = internal constant <{ [32 x i8] }> <{ [32 x i8] c"\03\00\00\00\04\00\00\00\05\00\00\00\06\00\00\00\07\00\00\00\0A\00\00\00\0B\00\00\00\0C\00\00\00" }>, align 32
@G_2ecompiler_2feval_2eInterpCrash = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\BB\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eInterpCrash.k1 }>, align 8
@G_2ecompiler_2feval_2eInterpCrash.k1 = internal constant <{ [187 x i8] }> <{ [187 x i8] c"\6F\6C\61\6E\67\3A\20\69\6E\74\65\72\6E\61\6C\20\63\6F\6D\70\69\6C\65\72\20\65\72\72\6F\72\3A\20\74\68\65\20\63\6F\6D\70\69\6C\65\72\20\63\72\61\73\68\65\64\20\77\68\69\6C\65\20\69\6E\74\65\72\70\72\65\74\69\6E\67\20\2D\20\69\6E\20\61\20\66\6F\72\65\69\67\6E\20\66\75\6E\63\74\69\6F\6E\20\74\68\65\20\70\72\6F\67\72\61\6D\20\63\61\6C\6C\73\2C\20\69\66\20\69\74\73\20\65\78\74\65\72\6E\20\64\65\63\6C\61\72\61\74\69\6F\6E\20\69\73\20\77\72\6F\6E\67\20\28\58\31\61\29\2C\20\6F\72\20\65\6C\73\65\20\61\20\62\75\67\20\69\6E\20\74\68\65\20\63\6F\6D\70\69\6C\65\72\0A" }>, align 64
@G_2ecompiler_2feval_2eNullPtr = constant <{ [16 x i8] }> <{ [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eNumNames = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k1 }>, align 8
@G_2ecompiler_2feval_2eNumNames.k1 = internal constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k2, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k3, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k5, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k6, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k7, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k10, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k12, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eNumNames.k13 }>, align 64
@G_2ecompiler_2feval_2eNumNames.k2 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\49\38" }>, align 8
@G_2ecompiler_2feval_2eNumNames.k3 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\31\36" }>, align 8
@G_2ecompiler_2feval_2eNumNames.k4 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\33\32" }>, align 8
@G_2ecompiler_2feval_2eNumNames.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\36\34" }>, align 8
@G_2ecompiler_2feval_2eNumNames.k6 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\55\38" }>, align 8
@G_2ecompiler_2feval_2eNumNames.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\31\36" }>, align 8
@G_2ecompiler_2feval_2eNumNames.k8 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\33\32" }>, align 8
@G_2ecompiler_2feval_2eNumNames.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\36\34" }>, align 8
@G_2ecompiler_2feval_2eNumNames.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\31\36" }>, align 8
@G_2ecompiler_2feval_2eNumNames.k11 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\42\46\31\36" }>, align 8
@G_2ecompiler_2feval_2eNumNames.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\33\32" }>, align 8
@G_2ecompiler_2feval_2eNumNames.k13 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\36\34" }>, align 8
@G_2ecompiler_2feval_2eS0 = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eSp0 = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eWatchSteps = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\01\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eWhyBeyond = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\2B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyBeyond.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyBeyond.k1 = internal constant <{ [43 x i8] }> <{ [43 x i8] c"\69\74\20\72\65\61\63\68\65\73\20\6F\75\74\73\69\64\65\20\74\68\65\20\73\74\6F\72\61\67\65\20\69\74\20\72\65\66\65\72\73\20\74\6F" }>, align 32
@G_2ecompiler_2feval_2eWhyCFunc = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\58\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyCFunc.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyCFunc.k1 = internal constant <{ [88 x i8] }> <{ [88 x i8] c"\69\74\20\6D\61\6B\65\73\20\6F\72\20\63\61\6C\6C\73\20\74\68\72\6F\75\67\68\20\61\20\43\20\66\75\6E\63\74\69\6F\6E\20\70\6F\69\6E\74\65\72\20\28\58\31\33\61\29\2C\20\77\68\69\63\68\20\6F\6E\6C\79\20\43\27\73\20\63\6F\64\65\20\73\74\61\6E\64\73\20\62\65\68\69\6E\64" }>, align 64
@G_2ecompiler_2feval_2eWhyChangeable = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\64\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyChangeable.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyChangeable.k1 = internal constant <{ [100 x i8] }> <{ [100 x i8] c"\69\74\20\72\65\61\64\73\20\61\20\67\6C\6F\62\61\6C\20\68\6F\6C\64\69\6E\67\20\73\74\6F\72\61\67\65\20\61\20\77\72\69\74\61\62\6C\65\20\72\65\66\65\72\65\6E\63\65\20\72\65\61\63\68\65\73\2C\20\77\68\69\63\68\20\74\68\65\20\72\75\6E\6E\69\6E\67\20\70\72\6F\67\72\61\6D\20\63\61\6E\20\63\68\61\6E\67\65" }>, align 64
@G_2ecompiler_2feval_2eWhyClosed = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\35\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyClosed.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyClosed.k1 = internal constant <{ [53 x i8] }> <{ [53 x i8] c"\69\74\20\75\73\65\73\20\73\74\6F\72\61\67\65\20\61\66\74\65\72\20\74\68\65\20\73\63\6F\70\65\20\69\74\20\77\61\73\20\6D\61\64\65\20\69\6E\20\63\6C\6F\73\65\64" }>, align 32
@G_2ecompiler_2feval_2eWhyConvert = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\34\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyConvert.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyConvert.k1 = internal constant <{ [52 x i8] }> <{ [52 x i8] c"\69\74\20\63\6F\6E\76\65\72\74\73\20\61\20\66\6C\6F\61\74\20\74\68\65\20\74\61\72\67\65\74\20\74\79\70\65\20\63\61\6E\6E\6F\74\20\72\65\70\72\65\73\65\6E\74" }>, align 32
@G_2ecompiler_2feval_2eWhyCycle = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\30\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyCycle.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyCycle.k1 = internal constant <{ [48 x i8] }> <{ [48 x i8] c"\74\68\65\73\65\20\67\6C\6F\62\61\6C\73\20\61\72\65\20\64\65\66\69\6E\65\64\20\69\6E\20\74\65\72\6D\73\20\6F\66\20\65\61\63\68\20\6F\74\68\65\72" }>, align 32
@G_2ecompiler_2feval_2eWhyDepth = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\43\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyDepth.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyDepth.k1 = internal constant <{ [67 x i8] }> <{ [67 x i8] c"\74\68\65\20\63\6F\6D\70\75\74\61\74\69\6F\6E\20\72\65\63\75\72\73\65\73\20\64\65\65\70\65\72\20\74\68\61\6E\20\63\6F\6D\70\69\6C\65\2D\74\69\6D\65\20\65\76\61\6C\75\61\74\69\6F\6E\20\61\6C\6C\6F\77\73" }>, align 64
@G_2ecompiler_2feval_2eWhyDestructor = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\3D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyDestructor.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyDestructor.k1 = internal constant <{ [61 x i8] }> <{ [61 x i8] c"\69\74\20\62\75\69\6C\64\73\20\61\20\76\61\6C\75\65\20\77\68\6F\73\65\20\64\65\73\74\72\75\63\74\6F\72\20\72\75\6E\73\20\77\68\65\6E\20\69\74\73\20\73\63\6F\70\65\20\63\6C\6F\73\65\73" }>, align 32
@G_2ecompiler_2feval_2eWhyDivMin = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\39\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyDivMin.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyDivMin.k1 = internal constant <{ [57 x i8] }> <{ [57 x i8] c"\69\74\20\64\69\76\69\64\65\73\20\74\68\65\20\6D\6F\73\74\20\6E\65\67\61\74\69\76\65\20\76\61\6C\75\65\20\62\79\20\2D\31\2C\20\77\68\69\63\68\20\6F\76\65\72\66\6C\6F\77\73" }>, align 32
@G_2ecompiler_2feval_2eWhyDivZero = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyDivZero.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyDivZero.k1 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\69\74\20\64\69\76\69\64\65\73\20\62\79\20\7A\65\72\6F" }>, align 8
@G_2ecompiler_2feval_2eWhyEnds = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\1F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyEnds.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyEnds.k1 = internal constant <{ [31 x i8] }> <{ [31 x i8] c"\69\74\20\65\6E\64\73\20\74\68\65\20\74\65\73\74\20\6F\72\20\74\68\65\20\70\72\6F\63\65\73\73" }>, align 8
@G_2ecompiler_2feval_2eWhyEqDepth = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\42\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyEqDepth.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyEqDepth.k1 = internal constant <{ [66 x i8] }> <{ [66 x i8] c"\74\68\65\20\63\6F\6D\70\61\72\69\73\6F\6E\20\72\65\63\75\72\73\65\73\20\64\65\65\70\65\72\20\74\68\61\6E\20\63\6F\6D\70\69\6C\65\2D\74\69\6D\65\20\65\76\61\6C\75\61\74\69\6F\6E\20\61\6C\6C\6F\77\73" }>, align 64
@G_2ecompiler_2feval_2eWhyExtern = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\1D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyExtern.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyExtern.k1 = internal constant <{ [29 x i8] }> <{ [29 x i8] c"\69\74\20\63\61\6C\6C\73\20\61\6E\20\65\78\74\65\72\6E\61\6C\20\66\75\6E\63\74\69\6F\6E" }>, align 8
@G_2ecompiler_2feval_2eWhyFfiFind = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\43\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyFfiFind.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyFfiFind.k1 = internal constant <{ [67 x i8] }> <{ [67 x i8] c"\69\74\20\63\61\6C\6C\73\20\61\6E\20\65\78\74\65\72\6E\61\6C\20\66\75\6E\63\74\69\6F\6E\20\69\6E\74\65\72\70\72\65\74\20\63\61\6E\6E\6F\74\20\66\69\6E\64\20\69\6E\20\74\68\69\73\20\70\72\6F\63\65\73\73" }>, align 64
@G_2ecompiler_2feval_2eWhyFfiPass = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\98\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyFfiPass.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyFfiPass.k1 = internal constant <{ [152 x i8] }> <{ [152 x i8] c"\69\74\20\63\61\6C\6C\73\20\61\6E\20\65\78\74\65\72\6E\61\6C\20\66\75\6E\63\74\69\6F\6E\20\77\69\74\68\20\61\20\70\61\72\61\6D\65\74\65\72\20\6F\72\20\72\65\73\75\6C\74\20\69\6E\74\65\72\70\72\65\74\20\63\61\6E\6E\6F\74\20\70\61\73\73\20\2D\20\6F\6E\6C\79\20\6E\75\6D\62\65\72\73\2C\20\42\6F\6F\6C\73\2C\20\61\72\72\61\79\73\20\61\6E\64\20\73\74\72\75\63\74\73\20\6F\66\20\6E\75\6D\62\65\72\73\2C\20\61\6E\64\20\70\6F\69\6E\74\65\72\73\20\43\20\67\61\76\65" }>, align 64
@G_2ecompiler_2feval_2eWhyForeign = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\38\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyForeign.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyForeign.k1 = internal constant <{ [56 x i8] }> <{ [56 x i8] c"\69\74\20\72\65\61\64\73\20\74\68\72\6F\75\67\68\20\61\20\70\6F\69\6E\74\65\72\20\43\20\67\61\76\65\2C\20\77\68\69\63\68\20\6F\6E\6C\79\20\43\20\6D\61\79\20\72\65\61\64" }>, align 32
@G_2ecompiler_2feval_2eWhyFreedEarly = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\5C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyFreedEarly.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyFreedEarly.k1 = internal constant <{ [92 x i8] }> <{ [92 x i8] c"\69\74\20\75\73\65\73\20\73\74\6F\72\61\67\65\20\65\61\72\6C\79\20\66\72\65\65\69\6E\67\20\72\65\63\6C\61\69\6D\65\64\20\28\4F\38\64\29\20\2D\20\61\20\70\6C\61\63\65\20\64\65\63\69\64\65\64\20\73\6F\6C\65\20\77\61\73\20\6E\6F\74\3A\20\61\20\63\6F\6D\70\69\6C\65\72\20\62\75\67" }>, align 64
@G_2ecompiler_2feval_2eWhyHolderMissed = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\86\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyHolderMissed.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyHolderMissed.k1 = internal constant <{ [134 x i8] }> <{ [134 x i8] c"\61\6E\20\6F\77\6E\69\6E\67\20\70\6C\61\63\65\20\68\6F\6C\64\73\20\61\6E\20\69\6E\73\74\61\6E\63\65\20\69\74\73\20\63\6F\75\6E\74\20\6F\66\20\68\6F\6C\64\65\72\73\20\73\61\79\73\20\6E\6F\6E\65\20\68\6F\6C\64\73\20\28\67\65\6E\72\65\66\73\20\32\2E\34\29\20\2D\20\61\20\73\74\6F\72\65\20\74\68\61\74\20\72\65\63\6F\72\64\65\64\20\6E\6F\20\68\6F\6C\64\65\72\3A\20\61\20\63\6F\6D\70\69\6C\65\72\20\62\75\67" }>, align 64
@G_2ecompiler_2feval_2eWhyInterrupted = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyInterrupted.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyInterrupted.k1 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\69\6E\74\65\72\72\75\70\74\65\64" }>, align 8
@G_2ecompiler_2feval_2eWhyLong = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\31\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyLong.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyLong.k1 = internal constant <{ [49 x i8] }> <{ [49 x i8] c"\69\74\20\6D\61\6B\65\73\20\61\6E\20\61\72\72\61\79\20\6C\6F\6E\67\65\72\20\74\68\61\6E\20\74\68\65\20\65\76\61\6C\75\61\74\6F\72\20\68\6F\6C\64\73" }>, align 32
@G_2ecompiler_2feval_2eWhyMemory = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\45\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyMemory.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyMemory.k1 = internal constant <{ [69 x i8] }> <{ [69 x i8] c"\74\68\65\20\63\6F\6D\70\75\74\61\74\69\6F\6E\20\74\61\6B\65\73\20\6D\6F\72\65\20\6D\65\6D\6F\72\79\20\74\68\61\6E\20\63\6F\6D\70\69\6C\65\2D\74\69\6D\65\20\65\76\61\6C\75\61\74\69\6F\6E\20\61\6C\6C\6F\77\73" }>, align 64
@G_2ecompiler_2feval_2eWhyMutableGlobal = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\3F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyMutableGlobal.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyMutableGlobal.k1 = internal constant <{ [63 x i8] }> <{ [63 x i8] c"\69\74\20\72\65\61\64\73\20\61\20\6D\75\74\61\62\6C\65\20\67\6C\6F\62\61\6C\2C\20\77\68\6F\73\65\20\76\61\6C\75\65\20\69\73\20\74\68\65\20\72\75\6E\6E\69\6E\67\20\70\72\6F\67\72\61\6D\27\73" }>, align 32
@G_2ecompiler_2feval_2eWhyNaNOp = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\54\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyNaNOp.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyNaNOp.k1 = internal constant <{ [84 x i8] }> <{ [84 x i8] c"\69\74\20\72\65\61\64\73\20\74\68\65\20\62\69\74\73\20\6F\66\20\61\20\4E\61\4E\20\61\6E\20\6F\70\65\72\61\74\69\6F\6E\20\6D\61\64\65\2C\20\77\68\6F\73\65\20\73\69\67\6E\20\61\6E\64\20\70\61\79\6C\6F\61\64\20\61\72\65\20\75\6E\73\70\65\63\69\66\69\65\64" }>, align 64
@G_2ecompiler_2feval_2eWhyNaNSignal = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\47\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyNaNSignal.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyNaNSignal.k1 = internal constant <{ [71 x i8] }> <{ [71 x i8] c"\69\74\20\72\65\61\64\73\20\74\68\65\20\62\69\74\73\20\6F\66\20\61\20\73\69\67\6E\61\6C\6C\69\6E\67\20\4E\61\4E\2C\20\77\68\69\63\68\20\6D\6F\76\69\6E\67\20\69\74\20\6D\61\79\20\68\61\76\65\20\71\75\69\65\74\65\64" }>, align 64
@G_2ecompiler_2feval_2eWhyNoBody = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\2F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyNoBody.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyNoBody.k1 = internal constant <{ [47 x i8] }> <{ [47 x i8] c"\69\74\20\63\61\6C\6C\73\20\61\20\66\75\6E\63\74\69\6F\6E\20\77\68\6F\73\65\20\62\6F\64\79\20\69\73\20\6E\6F\74\20\61\76\61\69\6C\61\62\6C\65" }>, align 32
@G_2ecompiler_2feval_2eWhyNoClause = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\27\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyNoClause.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyNoClause.k1 = internal constant <{ [39 x i8] }> <{ [39 x i8] c"\61\20\74\61\73\6B\27\73\20\65\72\72\6F\72\20\68\61\73\20\6E\6F\20\63\6C\61\75\73\65\20\74\6F\20\74\61\6B\65\20\69\74" }>, align 32
@G_2ecompiler_2feval_2eWhyNoGlobal = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\4E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyNoGlobal.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyNoGlobal.k1 = internal constant <{ [78 x i8] }> <{ [78 x i8] c"\69\74\20\72\65\61\64\73\20\61\20\67\6C\6F\62\61\6C\20\77\68\6F\73\65\20\69\6E\69\74\69\61\6C\69\7A\65\72\20\68\61\73\20\6E\6F\74\20\72\75\6E\20\2D\20\6F\6E\65\20\77\69\74\68\20\61\6E\20\65\72\72\6F\72\20\6E\65\76\65\72\20\64\6F\65\73" }>, align 64
@G_2ecompiler_2feval_2eWhyNoValue = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\28\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyNoValue.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyNoValue.k1 = internal constant <{ [40 x i8] }> <{ [40 x i8] c"\69\74\73\20\69\6E\69\74\69\61\6C\69\7A\65\72\20\64\6F\65\73\20\6E\6F\74\20\70\72\6F\64\75\63\65\20\61\20\76\61\6C\75\65" }>, align 32
@G_2ecompiler_2feval_2eWhyNotModelled = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\36\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyNotModelled.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyNotModelled.k1 = internal constant <{ [54 x i8] }> <{ [54 x i8] c"\69\74\20\75\73\65\73\20\61\20\76\61\6C\75\65\20\63\6F\6D\70\69\6C\65\2D\74\69\6D\65\20\65\76\61\6C\75\61\74\69\6F\6E\20\64\6F\65\73\20\6E\6F\74\20\6D\6F\64\65\6C" }>, align 32
@G_2ecompiler_2feval_2eWhyNull = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\21\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyNull.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyNull.k1 = internal constant <{ [33 x i8] }> <{ [33 x i8] c"\69\74\20\72\65\61\64\73\20\74\68\72\6F\75\67\68\20\61\20\6E\75\6C\6C\20\72\65\66\65\72\65\6E\63\65" }>, align 32
@G_2ecompiler_2feval_2eWhyNullCall = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\26\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyNullCall.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyNullCall.k1 = internal constant <{ [38 x i8] }> <{ [38 x i8] c"\69\74\20\63\61\6C\6C\73\20\74\68\72\6F\75\67\68\20\61\20\6E\75\6C\6C\20\66\75\6E\63\74\69\6F\6E\20\76\61\6C\75\65" }>, align 32
@G_2ecompiler_2feval_2eWhyOutside = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\3C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyOutside.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyOutside.k1 = internal constant <{ [60 x i8] }> <{ [60 x i8] c"\69\74\20\69\6E\64\65\78\65\73\20\6F\75\74\73\69\64\65\20\74\68\65\20\61\72\72\61\79\2C\20\77\68\69\63\68\20\69\73\20\75\6E\64\65\66\69\6E\65\64\20\61\74\20\72\75\6E\20\74\69\6D\65" }>, align 32
@G_2ecompiler_2feval_2eWhyPayload = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\36\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyPayload.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyPayload.k1 = internal constant <{ [54 x i8] }> <{ [54 x i8] c"\69\74\20\72\65\61\64\73\20\74\68\65\20\70\61\79\6C\6F\61\64\20\6F\66\20\61\20\63\61\73\65\20\74\68\65\20\76\61\6C\75\65\20\64\6F\65\73\20\6E\6F\74\20\68\6F\6C\64" }>, align 32
@G_2ecompiler_2feval_2eWhyReadOnly = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\17\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyReadOnly.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyReadOnly.k1 = internal constant <{ [23 x i8] }> <{ [23 x i8] c"\69\74\20\77\72\69\74\65\73\20\63\6F\6E\73\74\61\6E\74\20\64\61\74\61" }>, align 8
@G_2ecompiler_2feval_2eWhyRunDepth = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\28\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyRunDepth.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyRunDepth.k1 = internal constant <{ [40 x i8] }> <{ [40 x i8] c"\69\74\20\72\65\63\75\72\73\65\73\20\64\65\65\70\65\72\20\74\68\61\6E\20\69\6E\74\65\72\70\72\65\74\20\61\6C\6C\6F\77\73" }>, align 32
@G_2ecompiler_2feval_2eWhyRunEqDepth = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\34\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyRunEqDepth.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyRunEqDepth.k1 = internal constant <{ [52 x i8] }> <{ [52 x i8] c"\74\68\65\20\63\6F\6D\70\61\72\69\73\6F\6E\20\72\65\63\75\72\73\65\73\20\64\65\65\70\65\72\20\74\68\61\6E\20\69\6E\74\65\72\70\72\65\74\20\61\6C\6C\6F\77\73" }>, align 32
@G_2ecompiler_2feval_2eWhyShift = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\2D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyShift.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyShift.k1 = internal constant <{ [45 x i8] }> <{ [45 x i8] c"\69\74\20\73\68\69\66\74\73\20\62\79\20\61\20\63\6F\75\6E\74\20\6F\75\74\73\69\64\65\20\74\68\65\20\74\79\70\65\27\73\20\77\69\64\74\68" }>, align 32
@G_2ecompiler_2feval_2eWhyStale = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\90\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyStale.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyStale.k1 = internal constant <{ [144 x i8] }> <{ [144 x i8] c"\69\74\20\75\73\65\73\20\61\20\76\69\65\77\20\6F\66\20\61\20\63\6F\6C\6C\65\63\74\69\6F\6E\27\73\20\65\6C\65\6D\65\6E\74\73\20\74\61\6B\65\6E\20\62\65\66\6F\72\65\20\74\68\65\20\63\6F\6C\6C\65\63\74\69\6F\6E\20\67\72\65\77\2C\20\77\68\69\63\68\20\73\68\6F\77\73\20\74\68\65\20\72\65\74\69\72\65\64\20\62\75\66\66\65\72\20\2D\20\69\74\73\20\65\6C\65\6D\65\6E\74\73\20\6F\77\6E\69\6E\67\20\73\74\6F\72\61\67\65\20\65\6D\70\74\69\65\64" }>, align 64
@G_2ecompiler_2feval_2eWhySteps = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\3F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhySteps.k1 }>, align 8
@G_2ecompiler_2feval_2eWhySteps.k1 = internal constant <{ [63 x i8] }> <{ [63 x i8] c"\74\68\65\20\63\6F\6D\70\75\74\61\74\69\6F\6E\20\72\75\6E\73\20\6C\6F\6E\67\65\72\20\74\68\61\6E\20\63\6F\6D\70\69\6C\65\2D\74\69\6D\65\20\65\76\61\6C\75\61\74\69\6F\6E\20\61\6C\6C\6F\77\73" }>, align 32
@G_2ecompiler_2feval_2eWhyWaits = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\67\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyWaits.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyWaits.k1 = internal constant <{ [103 x i8] }> <{ [103 x i8] c"\69\74\20\77\61\69\74\73\20\66\6F\72\20\61\6E\6F\74\68\65\72\20\74\61\73\6B\2C\20\61\6E\64\20\69\6E\74\65\72\70\72\65\74\20\72\75\6E\73\20\61\20\6A\6F\69\6E\27\73\20\74\61\73\6B\73\20\6F\6E\65\20\61\66\74\65\72\20\61\6E\6F\74\68\65\72\2C\20\6E\65\76\65\72\20\62\65\73\69\64\65\20\65\61\63\68\20\6F\74\68\65\72" }>, align 64
@G_2ecompiler_2feval_2eWhyWalkLetGo = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\51\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyWalkLetGo.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyWalkLetGo.k1 = internal constant <{ [81 x i8] }> <{ [81 x i8] c"\69\74\20\6C\65\74\73\20\67\6F\20\6F\66\20\61\20\67\65\6E\65\72\61\74\6F\72\20\70\61\72\74\20\77\61\79\2C\20\77\68\6F\73\65\20\77\61\6C\6B\20\74\68\65\6E\20\72\75\6E\73\20\63\6F\64\65\20\61\73\20\69\74\73\20\73\63\6F\70\65\20\63\6C\6F\73\65\73" }>, align 64
@G_2ecompiler_2feval_2eWhyWeakUnheld = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\66\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyWeakUnheld.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyWeakUnheld.k1 = internal constant <{ [102 x i8] }> <{ [102 x i8] c"\69\74\20\72\65\61\64\73\20\61\20\77\65\61\6B\20\70\6C\61\63\65\20\77\68\6F\73\65\20\72\65\66\65\72\65\6E\74\20\6E\6F\20\6F\77\6E\69\6E\67\20\70\6C\61\63\65\20\68\6F\6C\64\73\2C\20\77\68\69\63\68\20\74\68\65\20\72\75\6E\6E\69\6E\67\20\70\72\6F\67\72\61\6D\20\6D\61\79\20\72\65\61\64\20\61\73\20\6E\75\6C\6C" }>, align 64
@G_2ecompiler_2feval_2eWhyWritesGlobal = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\5A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyWritesGlobal.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyWritesGlobal.k1 = internal constant <{ [90 x i8] }> <{ [90 x i8] c"\69\74\20\77\72\69\74\65\73\20\61\20\67\6C\6F\62\61\6C\20\6F\72\20\77\68\61\74\20\6F\6E\65\20\68\6F\6C\64\73\2C\20\77\68\69\63\68\20\74\68\65\20\72\75\6E\6E\69\6E\67\20\70\72\6F\67\72\61\6D\20\77\6F\75\6C\64\20\74\68\65\6E\20\6E\6F\74\20\73\65\65\20\77\72\69\74\74\65\6E" }>, align 64
@G_2ecompiler_2feval_2eWhyWritesGlobalVar = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\48\00\00\00\00\00\00\00", ptr @G_2ecompiler_2feval_2eWhyWritesGlobalVar.k1 }>, align 8
@G_2ecompiler_2feval_2eWhyWritesGlobalVar.k1 = internal constant <{ [72 x i8] }> <{ [72 x i8] c"\69\74\20\77\72\69\74\65\73\20\61\20\67\6C\6F\62\61\6C\2C\20\77\68\69\63\68\20\74\68\65\20\72\75\6E\6E\69\6E\67\20\70\72\6F\67\72\61\6D\20\77\6F\75\6C\64\20\74\68\65\6E\20\6E\6F\74\20\73\65\65\20\77\72\69\74\74\65\6E" }>, align 64
@G_2ecompiler_2feval_2eaCode = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eaData = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eaFree = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eaGlobal = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eaValue = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efBin = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efConst = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efCopy = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efLoad = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efStore = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efUn = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efastStride = constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2egDtor = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2egGen = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2erCall = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2erClause = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2erDtor = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2erGlobal = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2erRequest = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2erTask = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esBlock = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esBuilder = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esInert = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esJoin = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esProgram = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esRegion = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esStore = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eslotBits = constant <{ [8 x i8] }> <{ [8 x i8] c"\18\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eslotMask = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2etCall = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2etJoin = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2etRaised = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2etraceKept = constant <{ [8 x i8] }> <{ [8 x i8] c"\20\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evAgg = constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evBool = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evEnum = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evFixed = constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evFloat = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evFunc = constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evInt = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evNone = constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evOrd = constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evPair = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evPtr = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evUint = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evVoid = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evWide = constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
define dso_local void @compiler_2feval_2eMachine_2eNew(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca %"compiler/eval:Machine"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/eval:scope"
  %l16 = alloca i64
  %l22 = alloca %"compiler/eval:Ptr"
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l53 = alloca %"compiler/eval:Ptr"
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i32
  %l63 = alloca i1
  %l65 = alloca %"compiler/eval:Machine"
  %s0 = alloca %olang.scope
  %t3 = alloca %"compiler/eval:Machine", align 8
  %t10 = alloca %"compiler/eval:scope", align 8
  %t12 = alloca %"compiler/eval:scope", align 8
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load i32, ptr %l1, !range !{i32 0, i32 2}
  call void @compiler_2feval_3aMachine_2ector(ptr %t3, ptr %v0, ptr %v1, ptr %a0, i32 %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %t3, i64 3400, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 3400, i64 8)
  store ptr %t6, ptr %lp2
  %t7 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %l11, i64 3400, i1 false)
  %t8 = load ptr, ptr %lp2
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t8, i32 0, i32 53
  store ptr %t9, ptr %l12, !tbaa !29
  call void @compiler_2feval_3ascope_2ector(ptr %t10, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t10, i64 152, i1 false)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l12, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l13, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2ePush_3ccompiler_2feval_3ascope_3e(ptr %v1, ptr %t11, ptr %t12)
  br label %bb3
bb3:
  %t13 = load ptr, ptr %lp2
  %t14 = load i64, ptr @G_2ecompiler_2feval_2esProgram, !tbaa !24
  %t17 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l16
  br label %bb4
bb4:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = load ptr, ptr %lp2
  %t20 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 71
  store i64 %t18, ptr %t20, !tbaa !24
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 2}
  %t23 = trunc i64 1 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %lp2
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t26, i32 0, i32 2
  store i64 -1, ptr %t27, !tbaa !24
  %t28 = load ptr, ptr %lp2
  %t29 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 10
  store i64 -1, ptr %t29, !tbaa !24
  %t30 = load ptr, ptr %lp2
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 11
  store i64 10000000, ptr %t31, !tbaa !24
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t32 = load ptr, ptr %lp2
  %t33 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t34 = load ptr, ptr %lp2
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t34, i32 0, i32 71
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v1, ptr %t32, i64 64, i64 %t33, i64 %t36)
  store %"compiler/eval:Ptr" %t40, ptr %l22
  br label %bb8
bb8:
  %t41 = getelementptr %"compiler/eval:Ptr", ptr %l22, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = load ptr, ptr %lp2
  %t45 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 72
  store i64 %t42, ptr %t45, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb14
bb11:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l3, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l30, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t72 = load i64, ptr %l30, !tbaa !24
  store i64 %t72, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t73 = load i64, ptr %l27, !tbaa !24
  store i64 %t73, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t74 = load i64, ptr %l7, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  %t92 = load ptr, ptr %lp2
  %t93 = getelementptr %"compiler/eval:Machine", ptr %t92, i32 0, i32 73
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l48, !tbaa !27
  store i64 %t90, ptr %l49, !tbaa !24
  %t96 = load ptr, ptr %lp2
  %t97 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t98 = load ptr, ptr %lp2
  %t99 = getelementptr %"compiler/eval:Machine", ptr %t98, i32 0, i32 71
  %t100 = load i64, ptr %t99, !tbaa !24
  %t104 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v1, ptr %t96, i64 64, i64 %t97, i64 %t100)
  store %"compiler/eval:Ptr" %t104, ptr %l53
  br label %bb19
bb19:
  %t105 = getelementptr %"compiler/eval:Ptr", ptr %l53, i32 0, i32 0
  %t106 = load i64, ptr %t105, !tbaa !24
  %t108 = load i64, ptr %l49, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i64, ptr %t110, i64 %t108
  store i64 %t106, ptr %t111, !tbaa !34
  br label %bb20
bb20:
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = add i64 %t112, 1
  store i64 %t115, ptr %l7, !tbaa !24
  br label %bb15
bb21:
  %t117 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d0, i32 0, i32 1) })
  %t118 = extractvalue { i32, { i64, ptr } } %t117, 1
  %t119 = extractvalue { i32, { i64, ptr } } %t117, 0
  store i32 %t119, ptr %l60
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb23, label %ok.121, !prof !99
ok.121:
  store { i64, ptr } %t118, ptr %l59
  br label %bb22
bb22:
  %t122 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t122, ptr %l58, !tbaa !27
  br label %bb27
bb23:
  %t123 = load i32, ptr %l60, !tbaa !23
  %t124 = ashr i32 %t123, 16
  %t126 = icmp eq i32 %t124, 1
  br i1 %t126, label %bb24, label %bb25
bb24:
  call void @__olang_errpay_pop()
  br label %bb25
bb25:
  br label %bb26
bb26:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l58, !tbaa !27
  br label %bb27
bb27:
  %t128 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t128, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t129, ptr %l63
  br label %bb28
bb28:
  %t130 = load i1, ptr %l63, !tbaa !21
  %t131 = xor i1 %t130, true
  %t133 = load ptr, ptr %lp2
  %t134 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 17
  store i1 %t131, ptr %t134, !tbaa !21
  %t135 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t135, i64 3400, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l65, i64 3400, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2feval_2eadd128(i64 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i64
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t5 = add i64 %t1, %a2
  store i64 %t5, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l8, !tbaa !24
  %t12 = add i64 %a1, %a3
  store i64 %t12, ptr %l11, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l0, !tbaa !24
  %t17 = call i1 @compiler_2feval_2eult64(i64 %t13, i64 %t14)
  store i1 %t17, ptr %l14
  br label %bb1
bb1:
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i64 1, ptr %l15, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb4
bb4:
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l15, !tbaa !24
  %t21 = add i64 %t19, %t20
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = insertvalue { i64, i64 } undef, i64 %t22, 0
  %t25 = insertvalue { i64, i64 } %t23, i64 %t21, 1
  store { i64, i64 } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i64 @compiler_2feval_2ebmask(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sge i64 %t1, 64
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  %t5 = load i64, ptr %l0, !tbaa !24
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = shl i64 1, %t7
  %t10 = sub i64 %t8, 1
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t12 = load i64, ptr %l3, !tbaa !24
  store i64 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecmp128(i64 %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = icmp ne i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  br i1 %a4, label %bb3, label %bb4
bb2:
  br label %bb13
bb3:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  br i1 %t13, label %bb5, label %bb6
bb4:
  br label %bb8
bb5:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb7
bb6:
  store i64 1, ptr %l12, !tbaa !24
  br label %bb7
bb7:
  %t15 = load i64, ptr %l12, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
bb8:
  %t16 = load i64, ptr %l1, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = call i1 @compiler_2feval_2eult64(i64 %t16, i64 %t17)
  store i1 %t20, ptr %l15
  br label %bb9
bb9:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  store i64 -1, ptr %l16, !tbaa !24
  br label %bb12
bb11:
  store i64 1, ptr %l16, !tbaa !24
  br label %bb12
bb12:
  %t22 = load i64, ptr %l16, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
bb13:
  %t23 = load i64, ptr %l0, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = icmp eq i64 %t23, %t24
  br i1 %t27, label %bb14, label %bb15
bb14:
  store i64 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t30 = load i64, ptr %l0, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call i1 @compiler_2feval_2eult64(i64 %t30, i64 %t31)
  store i1 %t34, ptr %l23
  br label %bb17
bb17:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb18, label %bb19
bb18:
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb20
bb19:
  store i64 1, ptr %l24, !tbaa !24
  br label %bb20
bb20:
  %t36 = load i64, ptr %l24, !tbaa !24
  store i64 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eAllocations(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 51
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eBits(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2)
  store i64 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eBuildGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca i1
  %l7 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca %"compiler/eval:gkey"
  %l13 = alloca i64
  %l14 = alloca i32
  %l21 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 44
  store ptr %t3, ptr %l9, !tbaa !29
  %t8 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s0, i64 %a1, i32 %a2)
  store %"compiler/eval:gkey" %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load %"compiler/eval:gkey", ptr %l12
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t9, %"compiler/eval:gkey" %t10)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l14
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l13
  br label %bb2
bb2:
  %t16 = load i64, ptr %l13, !tbaa !24
  store i64 %t16, ptr %l7, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l7, !tbaa !24
  store i64 %t17, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp sge i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load i64, ptr %l3, !tbaa !24
  store i1 true, ptr %l5, !tbaa !21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/eval:Machine", ptr %t24, i32 0, i32 43
  %t30 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eRefMut_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %v0, ptr %t26, i64 %t22)
  store ptr %t30, ptr %l21
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t33 = load i1, ptr %l5, !tbaa !21
  %t36 = getelementptr %"compiler/eval:global", ptr %t31, i32 0, i32 5
  store i1 %t33, ptr %t36, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineDestructor(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 38
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Haf69023555548e8239d9db5dde4c25f9(ptr %v0, ptr %t3, i32 %a1, { i64, [2 x i64] } %a2)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineExtern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 35
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %t3, i64 %t4, { i64, ptr } %a2)
  br label %bb1
bb1:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 36
  %t16 = load i64, ptr %l1, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t15, i64 %t16, i64 %t17)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i1 %a4, { i64, [2 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca %"compiler/eval:global"
  %l7 = alloca %"compiler/eval:Ptr"
  %l10 = alloca i1
  %l11 = alloca %"compiler/eval:global"
  %l17 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i64
  %l25 = alloca %"compiler/eval:Ptr"
  %l28 = alloca ptr
  %l31 = alloca %"compiler/eval:gkey"
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca i64
  %l42 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = call %"compiler/eval:global" @compiler_2feval_3aglobal_2ector(ptr %s0)
  store %"compiler/eval:global" %t6, ptr %l11
  br label %bb2
bb2:
  %t7 = load %"compiler/eval:global", ptr %l11
  store %"compiler/eval:global" %t7, ptr %l6
  %t8 = load i32, ptr %l3, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t12 = getelementptr %"compiler/eval:global", ptr %l6, i32 0, i32 0
  store i64 %t10, ptr %t12, !tbaa !24
  %t15 = getelementptr %"compiler/eval:global", ptr %l6, i32 0, i32 1
  store i1 %a4, ptr %t15, !tbaa !21
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t20 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodeIndex(ptr %v0, ptr %t16, { i64, [2 x i64] } %a5)
  store i64 %t20, ptr %l17
  br label %bb3
bb3:
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = getelementptr %"compiler/eval:global", ptr %l6, i32 0, i32 2
  store i64 %t21, ptr %t22, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t24, i32 %t25)
  store i64 %t28, ptr %l21
  br label %bb4
bb4:
  %t29 = load i64, ptr @G_2ecompiler_2feval_2eaGlobal, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 71
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load ptr, ptr %l18, !tbaa !29
  %t35 = load i64, ptr %l21, !tbaa !24
  %t38 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t34, i64 %t35, i64 %t29, i64 %t33)
  store %"compiler/eval:Ptr" %t38, ptr %l25
  br label %bb5
bb5:
  %t39 = load %"compiler/eval:Ptr", ptr %l25
  store %"compiler/eval:Ptr" %t39, ptr %l7
  %t40 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = getelementptr %"compiler/eval:global", ptr %l6, i32 0, i32 3
  store i64 %t41, ptr %t43, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 44
  store ptr %t46, ptr %l28, !tbaa !29
  %t51 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s0, i64 %a1, i32 %a2)
  store %"compiler/eval:gkey" %t51, ptr %l31
  br label %bb6
bb6:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/eval:Machine", ptr %t52, i32 0, i32 43
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eLen_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t54)
  store i64 %t56, ptr %l34
  br label %bb7
bb7:
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = load %"compiler/eval:gkey", ptr %l31
  %t59 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eP_Hdbb1ec214f67f51e9ea8789b3bf075dc(ptr %v0, ptr %t57, %"compiler/eval:gkey" %t58, i64 %t59)
  br label %bb8
bb8:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Machine", ptr %t60, i32 0, i32 50
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l36, !tbaa !27
  %t64 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t69 = and i64 %t65, %t66
  store i64 %t69, ptr %l39, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t70, i32 0, i32 43
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eLen_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t72)
  store i64 %t74, ptr %l42
  br label %bb9
bb9:
  %t75 = load i64, ptr %l42, !tbaa !24
  %t76 = load i64, ptr %l39, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"compiler/eval:alloc", ptr %t78, i64 %t76
  %t80 = getelementptr %"compiler/eval:alloc", ptr %t79, i32 0, i32 8
  store i64 %t75, ptr %t80, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/eval:Machine", ptr %t81, i32 0, i32 43
  %t84 = load %"compiler/eval:global", ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2ePush_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t83, %"compiler/eval:global" %t84)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineTable(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l7 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 40
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_H6f34e373626f6b99bb5e62c0fd8bd7a4(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i1, ptr %l7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 39
  %t12 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__Hbdd7c5068e376aa260a62181a9f99429(ptr %v0, ptr %t11, i64 %t12, i32 %a2)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 40
  %t20 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_Hd8d89e440939766a34c786789c5d3b97(ptr %v0, ptr %v1, ptr %t19, i64 %t20, { i64, ptr } %a3)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eElems(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { %"compiler/eval:Ptr", i64 }
  %l5 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca { %"compiler/eval:Ptr", i64 }
  %l23 = alloca i64
  %l24 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l53 = alloca i64
  %l54 = alloca ptr
  %l61 = alloca %"compiler/eval:Ptr"
  %l63 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i32 %a2)
  store { %"compiler/eval:Ptr", i64 } %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load { %"compiler/eval:Ptr", i64 }, ptr %l18
  store { %"compiler/eval:Ptr", i64 } %t8, ptr %l4
  %t9 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l4, i32 0, i32 0
  %t10 = load %"compiler/eval:Ptr", ptr %t9
  store %"compiler/eval:Ptr" %t10, ptr %l5
  %t12 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l4, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l6, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t15, i32 %t16)
  store i64 %t19, ptr %l23
  br label %bb2
bb2:
  %t20 = load i64, ptr %l23, !tbaa !24
  store i64 %t20, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  store i64 %t21, ptr %l24, !tbaa !24
  %t22 = load i64, ptr %l24, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l24, !tbaa !24
  %t26 = icmp sle i64 %t25, 1152921504606846975
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a07810e0cbb459c4_651f13a6a529fa18)
  unreachable
bb5:
  %t28 = load i64, ptr %l24, !tbaa !24
  %t29 = mul i64 %t28, 8
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  store i64 %t34, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t36 = load i64, ptr %l10, !tbaa !24
  %t37 = load i64, ptr %l9, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a07810e0cbb459c4_651f13a6a529fa18)
  unreachable
bb7:
  %t42 = load i64, ptr %l11, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb12
bb9:
  %t46 = load i64, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l11, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l11, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l35, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb11
bb11:
  %t62 = load i64, ptr %l35, !tbaa !24
  store i64 %t62, ptr %l32, !tbaa !24
  br label %bb12
bb12:
  %t63 = load i64, ptr %l32, !tbaa !24
  store i64 %t63, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t64 = load i64, ptr %l13, !tbaa !24
  %t65 = load i64, ptr %l12, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l13, !tbaa !24
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l14, !tbaa !24
  %t82 = load i64, ptr %l14, !tbaa !24
  store i64 %t82, ptr %l53, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l54, !tbaa !29
  %t84 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t85 = load i64, ptr %t84, !tbaa !24
  %t86 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 1
  %t87 = load i64, ptr %t86, !tbaa !24
  %t88 = load i64, ptr %l14, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  %t98 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t85, i64 %t95)
  store %"compiler/eval:Ptr" %t98, ptr %l61
  br label %bb17
bb17:
  %t99 = load i32, ptr %l3, !tbaa !23
  %t100 = load ptr, ptr %l54, !tbaa !29
  %t101 = load %"compiler/eval:Ptr", ptr %l61
  %t103 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t100, %"compiler/eval:Ptr" %t101, i32 %t99)
  store i64 %t103, ptr %l63
  br label %bb18
bb18:
  %t104 = load i64, ptr %l63, !tbaa !24
  %t105 = load i64, ptr %l53, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i64, ptr %t107, i64 %t105
  store i64 %t104, ptr %t108, !tbaa !34
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t109 = load i64, ptr %l13, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l13, !tbaa !24
  br label %bb13
bb20:
  %t114 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t114, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEndProgram(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l20 = alloca i64
  %l27 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i1
  %rv = alloca { i64, [5 x i64] }
  %t5 = alloca { i64, [5 x i64] }, align 8
  %t21 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 23
  store i1 false, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [5 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t7 = load { i64, [5 x i64] }, ptr %t5
  %t10 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 21
  store { i64, [5 x i64] } %t7, ptr %t10
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t11, { i64, [2 x i64] } %a1)
  store i64 %t15, ptr %l11
  br label %bb1
bb1:
  %t16 = load i64, ptr %l11, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp slt i64 %t17, 0
  br i1 %t19, label %bb2, label %bb3
bb2:
  store { i64, [5 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 0
  store i64 0, ptr %t22
  %t23 = load { i64, [5 x i64] }, ptr %t21
  store { i64, [5 x i64] } %t23, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 60
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr @G_2ecompiler_2feval_2erRequest, !tbaa !24
  %t36 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %t30, i64 %t31, i64 %t32, i64 0)
  store i64 %t36, ptr %l20
  br label %bb5
bb5:
  %t37 = load i64, ptr %l20, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp slt i64 %t38, 0
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 21
  %t45 = load { i64, [5 x i64] }, ptr %t44
  store { i64, [5 x i64] } %t45, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t47, i32 0, i32 63
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t49)
  store i64 %t51, ptr %l27
  br label %bb9
bb9:
  %t52 = load i64, ptr %l27, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/eval:Machine", ptr %t53, i32 0, i32 63
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/eval:Machine", ptr %t56, i32 0, i32 71
  %t59 = load i64, ptr %t58, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t55, i64 %t59)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/eval:Machine", ptr %t62, i32 0, i32 63
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l34
  br label %bb12
bb12:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t68 = load i64, ptr %l34, !tbaa !24
  %t70 = icmp sgt i64 %t68, %t67
  br i1 %t70, label %bb13, label %bb14
bb13:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/eval:Machine", ptr %t72, i32 0, i32 23
  %t75 = load i1, ptr %t74, !tbaa !21
  %t77 = xor i1 %t75, true
  store i1 %t77, ptr %l37, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb15
bb15:
  %t79 = load i1, ptr %l37, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb16, label %bb17
bb16:
  br label %bb22
bb17:
  br label %bb18
bb18:
  %t82 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estepClose(ptr %v0, ptr %t82)
  br label %bb19
bb19:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l4, !tbaa !24
  %t87 = add i64 %t85, 1
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %t84, i64 %t87)
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb11
bb22:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunwind(ptr %v0, ptr %t90, i64 %t91)
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/eval:Machine", ptr %t94, i32 0, i32 21
  %t97 = load { i64, [5 x i64] }, ptr %t96
  store { i64, [5 x i64] } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca %"compiler/eval:gkey"
  %l10 = alloca i64
  %l11 = alloca i32
  %l16 = alloca %"compiler/eval:global"
  %l18 = alloca %"compiler/eval:Ptr"
  %l22 = alloca %"compiler/eval:global"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { %"compiler/eval:Ptr", i32 } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 44
  store ptr %t3, ptr %l6, !tbaa !29
  %t8 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s0, i64 %a1, i32 %a2)
  store %"compiler/eval:gkey" %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load %"compiler/eval:gkey", ptr %l9
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t9, %"compiler/eval:gkey" %t10)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l11
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l10
  br label %bb2
bb2:
  %t16 = load i64, ptr %l10, !tbaa !24
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t18 = insertvalue { i32, { %"compiler/eval:Ptr", i32 } } zeroinitializer, i32 65539, 0
  store { i32, { %"compiler/eval:Ptr", i32 } } %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load i64, ptr %l4, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 43
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t22, i64 %t23)
  store %"compiler/eval:global" %t26, ptr %l16
  br label %bb6
bb6:
  %t27 = getelementptr %"compiler/eval:global", ptr %l16, i32 0, i32 3
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t28, i64 0)
  store %"compiler/eval:Ptr" %t30, ptr %l18
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/eval:Machine", ptr %t31, i32 0, i32 43
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t33, i64 %t34)
  store %"compiler/eval:global" %t37, ptr %l22
  br label %bb8
bb8:
  %t38 = getelementptr %"compiler/eval:global", ptr %l22, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t43 = load %"compiler/eval:Ptr", ptr %l18
  %t44 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t43, 0
  %t46 = insertvalue { %"compiler/eval:Ptr", i32 } %t44, i32 %t41, 1
  call void @__olang_scope_close(ptr %s0)
  %t48 = insertvalue { i32, { %"compiler/eval:Ptr", i32 } } zeroinitializer, { %"compiler/eval:Ptr", i32 } %t46, 1
  store { i32, { %"compiler/eval:Ptr", i32 } } %t48, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { %"compiler/eval:Ptr", i32 } }, ptr %rv
  ret { i32, { %"compiler/eval:Ptr", i32 } } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eHeapBytes(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 48
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eInitGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l14 = alloca %"compiler/eval:gkey"
  %l15 = alloca i64
  %l16 = alloca i32
  %l24 = alloca %"compiler/eval:global"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [5 x i64] }
  %t5 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 23
  store i1 false, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [5 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t7 = load { i64, [5 x i64] }, ptr %t5
  %t10 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 21
  store { i64, [5 x i64] } %t7, ptr %t10
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t11, i32 0, i32 15
  store i64 0, ptr %t13, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 44
  store ptr %t16, ptr %l11, !tbaa !29
  %t21 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s0, i64 %a1, i32 %a2)
  store %"compiler/eval:gkey" %t21, ptr %l14
  br label %bb1
bb1:
  %t22 = load ptr, ptr %l11, !tbaa !29
  %t23 = load %"compiler/eval:gkey", ptr %l14
  %t24 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t22, %"compiler/eval:gkey" %t23)
  %t25 = extractvalue { i32, i64 } %t24, 1
  %t26 = extractvalue { i32, i64 } %t24, 0
  store i32 %t26, ptr %l16
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb3, label %ok.28, !prof !99
ok.28:
  store i64 %t25, ptr %l15
  br label %bb2
bb2:
  %t29 = load i64, ptr %l15, !tbaa !24
  store i64 %t29, ptr %l9, !tbaa !24
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t32 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t32, ptr %t30, { i64, ptr } %t31)
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/eval:Machine", ptr %t35, i32 0, i32 21
  %t38 = load { i64, [5 x i64] }, ptr %t37
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t38, ptr %rv
  br label %ret
bb6:
  %t40 = load i64, ptr %l9, !tbaa !24
  store i64 %t40, ptr %l3, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/eval:Machine", ptr %t41, i32 0, i32 43
  %t44 = load i64, ptr %l3, !tbaa !24
  %t47 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t43, i64 %t44)
  store %"compiler/eval:global" %t47, ptr %l24
  br label %bb7
bb7:
  %t48 = getelementptr %"compiler/eval:global", ptr %l24, i32 0, i32 4
  %t49 = load i64, ptr %t48, !tbaa !24
  %t51 = icmp ne i64 %t49, 2
  br i1 %t51, label %bb8, label %bb9
bb8:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/eval:Machine", ptr %t53, i32 0, i32 60
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l4, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartGlobal(ptr %v0, ptr %t58, i64 %t59)
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %t62, i64 %t63)
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunwind(ptr %v0, ptr %t66, i64 %t67)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t70, i32 0, i32 21
  %t73 = load { i64, [5 x i64] }, ptr %t72
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l4, !tbaa !29
  store %"compiler/eval:Ptr" %a1, ptr %l5
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t4, i32 %t5)
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"compiler/eval:Ptr", ptr %l5
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t9, %"compiler/eval:Ptr" %t10, i64 %t11)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i64, ptr %l9, !tbaa !24
  %t17 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t14, i64 %t15, i32 %t13)
  store i64 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i64, ptr %l11, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eLayout(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l5
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2elayoutOf(ptr %v0, ptr %s0, ptr %s0, ptr %a0, i32 %a1, ptr %l2, ptr %l3)
  br label %bb3
bb3:
  %t12 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t12, ptr %l11
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eMain(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca [0 x i64]
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, [5 x i64] }
  %l17 = alloca { i64, ptr }
  %l24 = alloca { i64, [5 x i64] }
  %l36 = alloca { i64, [5 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [5 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store [0 x i64] zeroinitializer, ptr %l3
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t12 = icmp slt i64 %t8, %t9
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t16, ptr %l17, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i64 %t17
  %t22 = load { i64, [2 x i64] }, ptr %t21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t27 = insertvalue { i64, ptr } undef, i64 0, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %l3, 1
  %t32 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s0, ptr %v2, ptr %t24, { i64, [2 x i64] } %t22, { i64, ptr } %t28)
  store { i64, [5 x i64] } %t32, ptr %l24
  br label %bb5
bb5:
  %t33 = load { i64, [5 x i64] }, ptr %l24
  store { i64, [5 x i64] } %t33, ptr %l8
  %t34 = load { i64, [5 x i64] }, ptr %l8
  %t36 = extractvalue { i64, [5 x i64] } %t34, 0
  %t37 = icmp eq i64 %t36, 0
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load { i64, [5 x i64] }, ptr %l8
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t41, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = add i64 %t43, 1
  store i64 %t46, ptr %l5, !tbaa !24
  br label %bb1
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t51 = insertvalue { i64, ptr } undef, i64 0, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %l3, 1
  %t56 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s0, ptr %v2, ptr %t48, { i64, [2 x i64] } %a2, { i64, ptr } %t52)
  store { i64, [5 x i64] } %t56, ptr %l36
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t57 = load { i64, [5 x i64] }, ptr %l36
  store { i64, [5 x i64] } %t57, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eMarkSet(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca %"compiler/eval:gkey"
  %l13 = alloca i64
  %l14 = alloca i32
  %l19 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 44
  store ptr %t3, ptr %l9, !tbaa !29
  %t8 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s0, i64 %a1, i32 %a2)
  store %"compiler/eval:gkey" %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load %"compiler/eval:gkey", ptr %l12
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t9, %"compiler/eval:gkey" %t10)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l14
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l13
  br label %bb2
bb2:
  %t16 = load i64, ptr %l13, !tbaa !24
  store i64 %t16, ptr %l7, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t17 = load i64, ptr %l7, !tbaa !24
  store i64 2, ptr %l5, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 43
  %t26 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eRefMut_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %v0, ptr %t22, i64 %t17)
  store ptr %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = getelementptr %"compiler/eval:global", ptr %t27, i32 0, i32 4
  store i64 %t29, ptr %t32, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eRefAt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1) #0 {
entry:
  %l4 = alloca %"compiler/eval:Ptr"
  %rv = alloca %"compiler/eval:Ptr"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1)
  store %"compiler/eval:Ptr" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load %"compiler/eval:Ptr", ptr %l4
  store %"compiler/eval:Ptr" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eResultHoldsAddress(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:alloc"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l20 = alloca i64
  %l24 = alloca i64
  %l38 = alloca i1
  %l40 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 19
  %t4 = getelementptr %"compiler/eval:Ptr", ptr %t3, i32 0, i32 0
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 50
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 19
  %t17 = getelementptr %"compiler/eval:Ptr", ptr %t16, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t22 = and i64 %t18, %t19
  %t24 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/eval:alloc", ptr %t25, i64 %t22
  %t27 = load %"compiler/eval:alloc", ptr %t26
  store %"compiler/eval:alloc" %t27, ptr %l1
  %t29 = getelementptr %"compiler/eval:alloc", ptr %l1, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/eval:Machine", ptr %t31, i32 0, i32 19
  %t34 = getelementptr %"compiler/eval:Ptr", ptr %t33, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t38 = add i64 %t30, %t35
  store i64 %t38, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l2, !tbaa !24
  store i64 %t40, ptr %l20, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 20
  %t45 = load i32, ptr %t44, !tbaa !23
  %t48 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t41, i32 %t45)
  store i64 %t48, ptr %l24
  br label %bb4
bb4:
  %t49 = load i64, ptr %l20, !tbaa !24
  %t50 = load i64, ptr %l24, !tbaa !24
  %t51 = add i64 %t49, %t50
  store i64 %t51, ptr %l3, !tbaa !24
  %t53 = load i64, ptr %l2, !tbaa !24
  %t55 = sdiv i64 %t53, 8
  store i64 %t55, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = mul i64 %t57, 8
  %t60 = load i64, ptr %l3, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  br label %bb8
bb8:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/eval:Machine", ptr %t68, i32 0, i32 47
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t76 = icmp slt i64 %t67, %t73
  br i1 %t76, label %bb9, label %bb10
bb9:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/eval:Machine", ptr %t78, i32 0, i32 47
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l40, !tbaa !27
  %t82 = load i64, ptr %l4, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 %t82
  %t87 = load i64, ptr %t86, !tbaa !34
  %t89 = icmp ne i64 %t87, 0
  store i1 %t89, ptr %l38, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb11
bb11:
  %t91 = load i1, ptr %l38, !tbaa !21
  br i1 %t91, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t93 = load i64, ptr %l4, !tbaa !24
  %t96 = add i64 %t93, 1
  store i64 %t96, ptr %l4, !tbaa !24
  br label %bb15
bb15:
  br label %bb5
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eScopeSlots(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 53
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eLen_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eStaleGrewAt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l5 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %l18 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %s1 = alloca %olang.scope
  %rv = alloca { i64, %"compiler/source:Span" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 81
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/eval:Machine", ptr %t8, i32 0, i32 81
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t12, i32 0, i32 80
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l10
  br label %bb3
bb3:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = icmp sge i64 %t17, %t18
  store i1 %t19, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l5, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t22, ptr %l12
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t23 = insertvalue { i64, %"compiler/source:Span" } undef, i64 -1, 0
  %t24 = load %"compiler/source:Span", ptr %l12
  %t25 = insertvalue { i64, %"compiler/source:Span" } %t23, %"compiler/source:Span" %t24, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, %"compiler/source:Span" } %t25, ptr %rv
  br label %ret
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/eval:Machine", ptr %t27, i32 0, i32 80
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 81
  %t33 = load i64, ptr %t32, !tbaa !24
  %t36 = call %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H1a77801a5ab3ea58cbf0ff15b43ff2de(ptr %v0, ptr %t29, i64 %t33)
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t36, ptr %l18
  br label %bb9
bb9:
  %t37 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l18
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t37, ptr %l1
  %t38 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l1, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l1, i32 0, i32 1
  %t41 = load %"compiler/source:Span", ptr %t40
  %t43 = insertvalue { i64, %"compiler/source:Span" } undef, i64 %t39, 0
  %t45 = insertvalue { i64, %"compiler/source:Span" } %t43, %"compiler/source:Span" %t41, 1
  store { i64, %"compiler/source:Span" } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, %"compiler/source:Span" }, ptr %rv
  ret { i64, %"compiler/source:Span" } %rr
}

define dso_local { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { %"compiler/eval:Ptr", i64 }
  %l4 = alloca %"compiler/eval:Ptr"
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { %"compiler/eval:Ptr", i64 }
  %l19 = alloca %"std/prelude/text:StringBuilder"
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l51 = alloca %"compiler/eval:Ptr"
  %l52 = alloca i64
  %l59 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i32 %a2)
  store { %"compiler/eval:Ptr", i64 } %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load { %"compiler/eval:Ptr", i64 }, ptr %l16
  store { %"compiler/eval:Ptr", i64 } %t8, ptr %l3
  %t9 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l3, i32 0, i32 0
  %t10 = load %"compiler/eval:Ptr", ptr %t9
  store %"compiler/eval:Ptr" %t10, ptr %l4
  %t12 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l3, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t15 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t15, ptr %l19
  br label %bb2
bb2:
  %t16 = load %"std/prelude/text:StringBuilder", ptr %l19
  store %"std/prelude/text:StringBuilder" %t16, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  store i64 %t17, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t19 = load i64, ptr %l8, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l27, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l24, !tbaa !24
  store i64 %t46, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load i64, ptr %l11, !tbaa !24
  %t48 = load i64, ptr %l10, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l11, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store ptr %l6, ptr %l45, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l46, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  %t73 = add i64 %t69, %t63
  %t76 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t67, i64 %t73)
  store %"compiler/eval:Ptr" %t76, ptr %l51
  br label %bb13
bb13:
  %t77 = load ptr, ptr %l46, !tbaa !29
  %t78 = load %"compiler/eval:Ptr", ptr %l51
  %t79 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t77, %"compiler/eval:Ptr" %t78, i64 1)
  store i64 %t79, ptr %l52
  br label %bb14
bb14:
  %t80 = load i64, ptr %l52, !tbaa !24
  %t81 = trunc i64 %t80 to i8
  %t83 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t83, i8 %t81)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t85 = load i64, ptr %l11, !tbaa !24
  %t88 = add i64 %t85, 1
  store i64 %t88, ptr %l11, !tbaa !24
  br label %bb9
bb17:
  %t91 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l6)
  store { i64, ptr } %t91, ptr %l59
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l18 = alloca i64
  %rv = alloca { i64, i64, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 89
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = mul i64 4, %t4
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 89
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = mul i64 4, %t13
  %t17 = add i64 %t15, 1
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t17)
  store i64 %t20, ptr %l12
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/eval:Machine", ptr %t21, i32 0, i32 89
  %t24 = load i64, ptr %l1, !tbaa !24
  %t26 = mul i64 4, %t24
  %t28 = add i64 %t26, 2
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t23, i64 %t28)
  store i64 %t31, ptr %l18
  br label %bb3
bb3:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = insertvalue { i64, i64, i64 } undef, i64 %t32, 0
  %t34 = load i64, ptr %l12, !tbaa !24
  %t35 = insertvalue { i64, i64, i64 } %t33, i64 %t34, 1
  %t36 = load i64, ptr %l18, !tbaa !24
  %t37 = insertvalue { i64, i64, i64 } %t35, i64 %t36, 2
  store { i64, i64, i64 } %t37, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64, i64 }, ptr %rv
  ret { i64, i64, i64 } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceLen(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 89
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = sdiv i64 %t6, 4
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceWhat(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i64
  %l11 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 89
  %t6 = mul i64 4, %a1
  %t8 = add i64 %t6, 3
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t8)
  store i64 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 90
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %t19, i64 %t20)
  store { i64, ptr } %t23, ptr %l15
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l11, !tbaa !27
  br label %bb5
bb4:
  %t24 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t24, ptr %l11, !tbaa !27
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddReg(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/eval:Ptr" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca %"compiler/eval:Ptr"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/eval:reg"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l25 = alloca i1
  %l29 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l35 = alloca i64
  %l43 = alloca %"compiler/eval:scope"
  %l47 = alloca i1
  %l48 = alloca ptr
  %l52 = alloca %"compiler/eval:scope"
  %l54 = alloca i1
  %l58 = alloca %"compiler/eval:scope"
  %l63 = alloca %"compiler/eval:reg"
  %l71 = alloca %"compiler/eval:scope"
  %l87 = alloca %"compiler/eval:scope"
  %l93 = alloca ptr
  %l99 = alloca %"compiler/eval:scope"
  %l105 = alloca %"compiler/eval:scope"
  %l110 = alloca ptr
  %l121 = alloca ptr
  %s0 = alloca %olang.scope
  %t41 = alloca %"compiler/eval:scope", align 8
  %t56 = alloca %"compiler/eval:scope", align 8
  %t70 = alloca %"compiler/eval:scope", align 8
  %t98 = alloca %"compiler/eval:scope", align 8
  %t137 = alloca %"compiler/eval:scope", align 8
  %t163 = alloca %"compiler/eval:scope", align 8
  %t175 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l25
  br label %bb1
bb1:
  %t6 = load i1, ptr %l25, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  %t11 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t11, ptr %t9, { i64, ptr } %t10)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 56
  %t18 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t16)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l33
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb7, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l32
  br label %bb6
bb6:
  %t23 = load i64, ptr %l32, !tbaa !24
  store i64 %t23, ptr %l29, !tbaa !24
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewRegSlot(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l35
  br label %bb9
bb9:
  %t27 = load i64, ptr %l35, !tbaa !24
  store i64 %t27, ptr %l29, !tbaa !24
  br label %bb10
bb10:
  %t28 = load i64, ptr %l29, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l1, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t33 = and i64 %t29, %t30
  store i64 %t33, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l1, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/eval:Machine", ptr %t37, i32 0, i32 53
  %t40 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t41, ptr %v0, ptr %t39, i64 %t40)
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %t41, i64 152, i1 false)
  br label %bb11
bb11:
  %t44 = getelementptr %"compiler/eval:scope", ptr %l43, i32 0, i32 2
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t49 = icmp eq i64 %t45, %t46
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l48, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/eval:Machine", ptr %t52, i32 0, i32 53
  %t55 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t56, ptr %v0, ptr %t54, i64 %t55)
  call void @llvm.memmove.p0.p0.i64(ptr %l52, ptr %t56, i64 152, i1 false)
  br label %bb14
bb13:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb16
bb14:
  %t59 = getelementptr %"compiler/eval:scope", ptr %l52, i32 0, i32 16
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = load ptr, ptr %l48, !tbaa !29
  %t63 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t61, i64 %t60)
  store i1 %t63, ptr %l54
  br label %bb15
bb15:
  %t64 = load i1, ptr %l54, !tbaa !21
  store i1 %t64, ptr %l47, !tbaa !21
  br label %bb16
bb16:
  %t65 = load i1, ptr %l47, !tbaa !21
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/eval:Machine", ptr %t66, i32 0, i32 53
  %t69 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t70, ptr %v0, ptr %t68, i64 %t69)
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t70, i64 152, i1 false)
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t73 = getelementptr %"compiler/eval:scope", ptr %l58, i32 0, i32 16
  %t74 = load i64, ptr %t73, !tbaa !24
  store i64 %t74, ptr %l7, !tbaa !24
  br label %bb20
bb20:
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t80 = and i64 %t76, %t77
  store i64 %t80, ptr %l8, !tbaa !24
  %t82 = call %"compiler/eval:reg" @compiler_2feval_3areg_2ector(ptr %s0)
  store %"compiler/eval:reg" %t82, ptr %l63
  br label %bb21
bb21:
  %t83 = load %"compiler/eval:reg", ptr %l63
  store %"compiler/eval:reg" %t83, ptr %l9
  store i64 %a2, ptr %l10, !tbaa !24
  store i64 %a3, ptr %l11, !tbaa !24
  %t88 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 0
  %t89 = load i64, ptr %t88, !tbaa !24
  store i64 %t89, ptr %l12, !tbaa !24
  %t91 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l13, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/eval:Machine", ptr %t94, i32 0, i32 53
  %t97 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t98, ptr %v0, ptr %t96, i64 %t97)
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %t98, i64 152, i1 false)
  br label %bb22
bb22:
  %t101 = getelementptr %"compiler/eval:scope", ptr %l71, i32 0, i32 4
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t108 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 0
  store i64 %t106, ptr %t108, !tbaa !24
  %t109 = load i64, ptr %l11, !tbaa !24
  %t111 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 1
  store i64 %t109, ptr %t111, !tbaa !24
  %t112 = load i64, ptr %l12, !tbaa !24
  %t114 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 2
  store i64 %t112, ptr %t114, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t117 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 3
  store i64 %t115, ptr %t117, !tbaa !24
  %t120 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 4
  store i64 %t102, ptr %t120, !tbaa !24
  %t123 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 5
  store i64 -1, ptr %t123, !tbaa !24
  %t126 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 6
  store i64 %t104, ptr %t126, !tbaa !24
  %t127 = load i64, ptr %l7, !tbaa !24
  %t128 = load i64, ptr %l1, !tbaa !24
  %t131 = icmp ne i64 %t127, %t128
  br i1 %t131, label %bb23, label %bb24
bb23:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 53
  %t136 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t137, ptr %v0, ptr %t135, i64 %t136)
  call void @llvm.memmove.p0.p0.i64(ptr %l87, ptr %t137, i64 152, i1 false)
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t140 = getelementptr %"compiler/eval:scope", ptr %l87, i32 0, i32 17
  %t141 = load i64, ptr %t140, !tbaa !24
  %t143 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 7
  store i64 %t141, ptr %t143, !tbaa !24
  %t144 = load i64, ptr %l6, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/eval:Machine", ptr %t146, i32 0, i32 53
  %t152 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t148, i64 %t144)
  store ptr %t152, ptr %l93
  br label %bb26
bb26:
  %t153 = load ptr, ptr %l93, !tbaa !29
  %t155 = load i64, ptr %l5, !tbaa !24
  %t158 = getelementptr %"compiler/eval:scope", ptr %t153, i32 0, i32 17
  store i64 %t155, ptr %t158, !tbaa !24
  br label %bb27
bb27:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/eval:Machine", ptr %t159, i32 0, i32 53
  %t162 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t163, ptr %v0, ptr %t161, i64 %t162)
  call void @llvm.memmove.p0.p0.i64(ptr %l99, ptr %t163, i64 152, i1 false)
  br label %bb28
bb28:
  %t166 = getelementptr %"compiler/eval:scope", ptr %l99, i32 0, i32 4
  %t167 = load i64, ptr %t166, !tbaa !24
  %t169 = icmp sge i64 %t167, 0
  br i1 %t169, label %bb29, label %bb30
bb29:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/eval:Machine", ptr %t171, i32 0, i32 53
  %t174 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t175, ptr %v0, ptr %t173, i64 %t174)
  call void @llvm.memmove.p0.p0.i64(ptr %l105, ptr %t175, i64 152, i1 false)
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t178 = getelementptr %"compiler/eval:scope", ptr %l105, i32 0, i32 4
  %t179 = load i64, ptr %t178, !tbaa !24
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/eval:Machine", ptr %t181, i32 0, i32 55
  %t187 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eRefMut_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %v0, ptr %t183, i64 %t179)
  store ptr %t187, ptr %l110
  br label %bb32
bb32:
  %t188 = load ptr, ptr %l110, !tbaa !29
  %t190 = load i64, ptr %l5, !tbaa !24
  %t193 = getelementptr %"compiler/eval:reg", ptr %t188, i32 0, i32 5
  store i64 %t190, ptr %t193, !tbaa !24
  br label %bb33
bb33:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/eval:Machine", ptr %t194, i32 0, i32 55
  %t197 = load i64, ptr %l5, !tbaa !24
  %t198 = load %"compiler/eval:reg", ptr %l9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eSetAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t196, i64 %t197, %"compiler/eval:reg" %t198)
  br label %bb34
bb34:
  %t202 = load i64, ptr %l8, !tbaa !24
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/eval:Machine", ptr %t204, i32 0, i32 53
  %t210 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t206, i64 %t202)
  store ptr %t210, ptr %l121
  br label %bb35
bb35:
  %t211 = load ptr, ptr %l121, !tbaa !29
  %t213 = load i64, ptr %l5, !tbaa !24
  %t216 = getelementptr %"compiler/eval:scope", ptr %t211, i32 0, i32 4
  store i64 %t213, ptr %t216, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l4 = alloca %"compiler/mir:Lvalue"
  %l5 = alloca { %"compiler/eval:Ptr", i32 }
  %l7 = alloca i32
  %l8 = alloca %"compiler/eval:Ptr"
  %l15 = alloca { %"compiler/eval:Ptr", i32 }
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca i64
  %l28 = alloca %"compiler/eval:Ptr"
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l4
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = load %"compiler/mir:Lvalue", ptr %l4
  %t16 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t10, i64 %t11, %"compiler/mir:Lvalue" %t12)
  store { %"compiler/eval:Ptr", i32 } %t16, ptr %l15
  br label %bb4
bb4:
  %t17 = load { %"compiler/eval:Ptr", i32 }, ptr %l15
  store { %"compiler/eval:Ptr", i32 } %t17, ptr %l5
  %t18 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l5, i32 0, i32 0
  %t19 = load %"compiler/eval:Ptr", ptr %t18
  store %"compiler/eval:Ptr" %t19, ptr %rv
  br label %ret
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6f754b89a33b6044_bbcfb7dbcaa58778)
  unreachable
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t25 = load { i64, [4 x i64] }, ptr %l2
  %t29 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t23, i64 %t24, { i64, [4 x i64] } %t25)
  store i32 %t29, ptr %l21
  br label %bb11
bb11:
  %t30 = load i32, ptr %l21, !tbaa !23
  store i32 %t30, ptr %l7, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i64 %a3, ptr %l23, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l7, !tbaa !23
  %t37 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t33, i32 %t34)
  store i64 %t37, ptr %l26
  br label %bb12
bb12:
  %t38 = load i64, ptr %l26, !tbaa !24
  %t39 = add i64 %t38, 16
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = load i64, ptr %l23, !tbaa !24
  %t43 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2escratchFor(ptr %v0, ptr %t40, i64 %t41, i64 %t39)
  store %"compiler/eval:Ptr" %t43, ptr %l28
  br label %bb13
bb13:
  %t44 = load %"compiler/eval:Ptr", ptr %l28
  store %"compiler/eval:Ptr" %t44, ptr %l8
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load %"compiler/eval:Ptr", ptr %l8
  %t48 = load i32, ptr %l7, !tbaa !23
  %t49 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t45, i64 %t46, %"compiler/eval:Ptr" %t47, i32 %t48, { i64, [4 x i64] } %t49)
  br label %bb14
bb14:
  %t55 = load %"compiler/eval:Ptr", ptr %l8
  store %"compiler/eval:Ptr" %t55, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eadopt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l31 = alloca ptr
  %l38 = alloca %"compiler/eval:scope"
  %l43 = alloca ptr
  %l50 = alloca ptr
  %t51 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i1, ptr %l14, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t13, ptr %l19
  br label %bb4
bb4:
  %t14 = load i1, ptr %l19, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l16, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t18 = load i64, ptr %l1, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t22 = and i64 %t18, %t19
  store i64 %t22, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t28 = and i64 %t24, %t25
  store i64 %t28, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 53
  %t38 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t34, i64 %t30)
  store ptr %t38, ptr %l31
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l31, !tbaa !29
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = getelementptr %"compiler/eval:scope", ptr %t39, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  store i64 %t45, ptr %l7, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t47, i32 0, i32 53
  %t50 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t51, ptr %v0, ptr %t49, i64 %t50)
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t51, i64 152, i1 false)
  br label %bb10
bb10:
  %t54 = getelementptr %"compiler/eval:scope", ptr %l38, i32 0, i32 6
  %t55 = load i64, ptr %t54, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/eval:Machine", ptr %t57, i32 0, i32 53
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l43
  br label %bb11
bb11:
  %t64 = load ptr, ptr %l43, !tbaa !29
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = getelementptr %"compiler/eval:scope", ptr %t64, i32 0, i32 7
  store i64 %t66, ptr %t69, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/eval:Machine", ptr %t72, i32 0, i32 53
  %t78 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t74, i64 %t70)
  store ptr %t78, ptr %l50
  br label %bb12
bb12:
  %t79 = load ptr, ptr %l50, !tbaa !29
  %t81 = load i64, ptr %l1, !tbaa !24
  %t84 = getelementptr %"compiler/eval:scope", ptr %t79, i32 0, i32 6
  store i64 %t81, ptr %t84, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i64
  %l11 = alloca i64
  %l19 = alloca %"compiler/eval:scope"
  %l24 = alloca %"compiler/eval:scope"
  %l28 = alloca { i64, ptr }
  %l39 = alloca %"compiler/eval:Ptr"
  %l42 = alloca ptr
  %l43 = alloca %"compiler/eval:Ptr"
  %l45 = alloca %"compiler/eval:Ptr"
  %l56 = alloca ptr
  %l60 = alloca ptr
  %l63 = alloca %"compiler/eval:Ptr"
  %l71 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t11 = alloca %"compiler/eval:scope", align 8
  %t21 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t5 = and i64 %t1, %t2
  store i64 %t5, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 53
  %t10 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t11, ptr %v0, ptr %t9, i64 %t10)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t11, i64 152, i1 false)
  br label %bb1
bb1:
  %t14 = getelementptr %"compiler/eval:scope", ptr %l19, i32 0, i32 8
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 53
  %t20 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t21, ptr %v0, ptr %t19, i64 %t20)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t21, i64 152, i1 false)
  br label %bb2
bb2:
  %t24 = getelementptr %"compiler/eval:scope", ptr %l24, i32 0, i32 9
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 50
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l28, !tbaa !27
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t36 = and i64 %t32, %t33
  %t38 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr %"compiler/eval:alloc", ptr %t39, i64 %t36
  %t41 = getelementptr %"compiler/eval:alloc", ptr %t40, i32 0, i32 1
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = icmp sge i64 %t27, %t42
  br i1 %t45, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l5, !tbaa !24
  %t50 = mul i64 2, %t48
  %t51 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t52 = load i64, ptr %l1, !tbaa !24
  %t57 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t47, i64 %t50, i64 %t51, i64 %t52)
  store %"compiler/eval:Ptr" %t57, ptr %l39
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t58 = load %"compiler/eval:Ptr", ptr %l39
  store %"compiler/eval:Ptr" %t58, ptr %l6
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/eval:Machine", ptr %t59, i32 0, i32 23
  %t62 = load i1, ptr %t61, !tbaa !21
  br i1 %t62, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l42, !tbaa !29
  %t65 = load %"compiler/eval:Ptr", ptr %l6
  store %"compiler/eval:Ptr" %t65, ptr %l43
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s1, i64 %t66, i64 0)
  store %"compiler/eval:Ptr" %t68, ptr %l45
  br label %bb9
bb9:
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = load ptr, ptr %l42, !tbaa !29
  %t71 = load %"compiler/eval:Ptr", ptr %l43
  %t72 = load %"compiler/eval:Ptr", ptr %l45
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t70, %"compiler/eval:Ptr" %t71, %"compiler/eval:Ptr" %t72, i64 %t69)
  br label %bb10
bb10:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t76 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t79 = and i64 %t75, %t76
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %t74, i64 %t79)
  br label %bb11
bb11:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t84 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 0
  %t85 = load i64, ptr %t84, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/eval:Machine", ptr %t87, i32 0, i32 53
  %t93 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t89, i64 %t82)
  store ptr %t93, ptr %l56
  br label %bb12
bb12:
  %t94 = load ptr, ptr %l56, !tbaa !29
  %t96 = load i64, ptr %l8, !tbaa !24
  %t99 = getelementptr %"compiler/eval:scope", ptr %t94, i32 0, i32 8
  store i64 %t96, ptr %t99, !tbaa !24
  %t100 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 0
  %t101 = load i64, ptr %t100, !tbaa !24
  store i64 %t101, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l60, !tbaa !29
  %t104 = load i64, ptr %l4, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t108 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t104, i64 %t105)
  store %"compiler/eval:Ptr" %t108, ptr %l63
  br label %bb14
bb14:
  %t110 = load ptr, ptr %l60, !tbaa !29
  %t111 = load %"compiler/eval:Ptr", ptr %l63
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t110, %"compiler/eval:Ptr" %t111, i64 1, i64 %a2)
  br label %bb15
bb15:
  %t113 = load i64, ptr %l3, !tbaa !24
  %t115 = load i64, ptr %l5, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l11, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/eval:Machine", ptr %t119, i32 0, i32 53
  %t125 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t121, i64 %t113)
  store ptr %t125, ptr %l71
  br label %bb16
bb16:
  %t126 = load ptr, ptr %l71, !tbaa !29
  %t128 = load i64, ptr %l11, !tbaa !24
  %t131 = getelementptr %"compiler/eval:scope", ptr %t126, i32 0, i32 9
  store i64 %t128, ptr %t131, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Range" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 27
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 59
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i64 %a1
  %t14 = getelementptr %"compiler/eval:frame", ptr %t13, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr %"compiler/eval:cfn", ptr %t18, i64 %t15
  %t20 = getelementptr %"compiler/eval:cfn", ptr %t19, i32 0, i32 4
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t22 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t29 = add i64 %t25, %a3
  %t31 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t32, i64 %t29
  %t34 = load { i64, [4 x i64] }, ptr %t33
  store { i64, [4 x i64] } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l21 = alloca i32
  %l24 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t19 = trunc i64 20 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l17
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load i32, ptr %l18, !tbaa !23
  store i32 %t31, ptr %l3, !tbaa !23
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l21
  br label %bb8
bb8:
  %t37 = load i32, ptr %l21, !range !{i32 0, i32 33}
  %t39 = trunc i64 19 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load i32, ptr %l3, !tbaa !23
  store i32 %t42, ptr %l24, !tbaa !23
  br label %bb11
bb10:
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t44, ptr %l24, !tbaa !23
  br label %bb11
bb11:
  %t46 = load i32, ptr %l24, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i32
  %l15 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l29 = alloca %"compiler/eval:Ptr"
  %l32 = alloca i64
  %l36 = alloca i32
  %l38 = alloca %"compiler/eval:Ptr"
  %l41 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca %"compiler/eval:Ptr"
  %l51 = alloca %"compiler/eval:Ptr"
  %l54 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { %"compiler/eval:Ptr", i64 }
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a2)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load i32, ptr %l12, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l15
  br label %bb2
bb2:
  %t17 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t19 = trunc i64 20 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l21
  br label %bb5
bb4:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t29 = load i32, ptr %l4, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l36
  br label %bb13
bb5:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i32, ptr %l21, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t35, ptr %l22
  br label %bb6
bb6:
  %t36 = load i32, ptr %l22, !tbaa !23
  store i32 %t36, ptr %l5, !tbaa !23
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l25
  br label %bb7
bb7:
  %t42 = load i32, ptr %l25, !tbaa !23
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb8, label %bb9
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/eval:Ptr", ptr %l1
  %t49 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t45, %"compiler/eval:Ptr" %t46)
  store %"compiler/eval:Ptr" %t49, ptr %l29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l5, !tbaa !23
  %t54 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %t50, i32 %t51)
  store i64 %t54, ptr %l32
  br label %bb11
bb11:
  %t55 = load %"compiler/eval:Ptr", ptr %l29
  %t56 = insertvalue { %"compiler/eval:Ptr", i64 } undef, %"compiler/eval:Ptr" %t55, 0
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = insertvalue { %"compiler/eval:Ptr", i64 } %t56, i64 %t57, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i64 } %t58, ptr %rv
  br label %ret
bb12:
  br label %bb18
bb13:
  %t60 = load i32, ptr %l36, !tbaa !23
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t63 = load %"compiler/eval:Ptr", ptr %l1
  store %"compiler/eval:Ptr" %t63, ptr %l38
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l4, !tbaa !23
  %t68 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %t64, i32 %t65)
  store i64 %t68, ptr %l41
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t69 = load %"compiler/eval:Ptr", ptr %l38
  %t70 = insertvalue { %"compiler/eval:Ptr", i64 } undef, %"compiler/eval:Ptr" %t69, 0
  %t71 = load i64, ptr %l41, !tbaa !24
  %t72 = insertvalue { %"compiler/eval:Ptr", i64 } %t70, i64 %t71, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i64 } %t72, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/eval:Ptr", ptr %l1
  %t78 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t74, %"compiler/eval:Ptr" %t75, i64 8)
  store i64 %t78, ptr %l45
  br label %bb19
bb19:
  %t79 = load i64, ptr %l45, !tbaa !24
  store i64 %t79, ptr %l6, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l46, !tbaa !29
  %t81 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 8
  %t89 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t82, i64 %t86)
  store %"compiler/eval:Ptr" %t89, ptr %l50
  br label %bb20
bb20:
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = load %"compiler/eval:Ptr", ptr %l50
  %t92 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t90, %"compiler/eval:Ptr" %t91)
  store %"compiler/eval:Ptr" %t92, ptr %l51
  br label %bb21
bb21:
  %t93 = load %"compiler/eval:Ptr", ptr %l51
  store %"compiler/eval:Ptr" %t93, ptr %l7
  %t94 = load i64, ptr %l6, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t98 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t99 = load i64, ptr %t98, !tbaa !24
  %t101 = icmp eq i64 %t99, 0
  store i1 %t101, ptr %l54, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb24
bb24:
  %t103 = load i1, ptr %l54, !tbaa !21
  br i1 %t103, label %bb25, label %bb26
bb25:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNull, !tbaa !27
  %t106 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t106, ptr %t104, { i64, ptr } %t105)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t109 = load %"compiler/eval:Ptr", ptr %l7
  %t110 = load i64, ptr %l6, !tbaa !24
  %t112 = insertvalue { %"compiler/eval:Ptr", i64 } undef, %"compiler/eval:Ptr" %t109, 0
  %t114 = insertvalue { %"compiler/eval:Ptr", i64 } %t112, i64 %t110, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i64 } %t114, ptr %rv
  br label %ret
ret:
  %rr = load { %"compiler/eval:Ptr", i64 }, ptr %rv
  ret { %"compiler/eval:Ptr", i64 } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/eval:global"
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l38 = alloca { i64, ptr }
  %l42 = alloca i64
  %l47 = alloca i1
  %l51 = alloca i1
  %l58 = alloca i1
  %l61 = alloca i1
  %l66 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l99 = alloca i1
  %l101 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l119 = alloca %"compiler/eval:global"
  %l122 = alloca i1
  %l132 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 23
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp eq i64 %t8, 0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNull, !tbaa !27
  %t14 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t14, ptr %t12, { i64, ptr } %t13)
  br label %bb6
bb5:
  br label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  %t18 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t19 = load i64, ptr %t18, !tbaa !24
  %t20 = load i64, ptr @G_2ecompiler_2feval_2eForeignId, !tbaa !24
  %t23 = icmp eq i64 %t19, %t20
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyForeign, !tbaa !27
  %t27 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t27, ptr %t25, { i64, ptr } %t26)
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i64 -1, ptr %rv
  br label %ret
bb11:
  %t31 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t36 = and i64 %t32, %t33
  store i64 %t36, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 51
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = icmp sge i64 %t38, %t42
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  %t49 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t49, ptr %t47, { i64, ptr } %t48)
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/eval:Machine", ptr %t53, i32 0, i32 50
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l31, !tbaa !27
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/eval:alloc", ptr %t60, i64 %t57
  %t62 = getelementptr %"compiler/eval:alloc", ptr %t61, i32 0, i32 4
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t67 = icmp eq i64 %t63, %t64
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb18
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/eval:Machine", ptr %t69, i32 0, i32 50
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l38, !tbaa !27
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"compiler/eval:alloc", ptr %t76, i64 %t73
  %t78 = getelementptr %"compiler/eval:alloc", ptr %t77, i32 0, i32 3
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t82, ptr %l42, !tbaa !24
  %t84 = load i64, ptr %l42, !tbaa !24
  %t85 = load i64, ptr %l42, !tbaa !24
  %t86 = ashr i64 %t81, %t85
  %t89 = icmp ne i64 %t79, %t86
  store i1 %t89, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  %t91 = load i1, ptr %l36, !tbaa !21
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/eval:Machine", ptr %t92, i32 0, i32 17
  %t95 = load i1, ptr %t94, !tbaa !21
  br i1 %t95, label %bb21, label %bb22
bb20:
  br label %bb30
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/eval:Machine", ptr %t97, i32 0, i32 18
  %t100 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t101 = load i64, ptr %t100, !tbaa !24
  %t104 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t99, i64 %t101)
  store i1 %t104, ptr %l51
  br label %bb23
bb22:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb24
bb23:
  %t105 = load i1, ptr %l51, !tbaa !21
  store i1 %t105, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t106 = load i1, ptr %l47, !tbaa !21
  br i1 %t106, label %bb25, label %bb26
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreedEarly(ptr %v0, ptr %t107)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  %t111 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t111, ptr %t109, { i64, ptr } %t110)
  br label %bb29
bb29:
  store i64 -1, ptr %rv
  br label %ret
bb30:
  %t115 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb33
bb32:
  %t120 = load i64, ptr %l2, !tbaa !24
  %t122 = icmp slt i64 %t120, 0
  store i1 %t122, ptr %l58, !tbaa !21
  br label %bb33
bb33:
  %t124 = load i1, ptr %l58, !tbaa !21
  br i1 %t124, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb36
bb35:
  %t125 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  %t127 = load i64, ptr %l2, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/eval:Machine", ptr %t131, i32 0, i32 50
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l66, !tbaa !27
  %t135 = load i64, ptr %l4, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/eval:alloc", ptr %t138, i64 %t135
  %t140 = getelementptr %"compiler/eval:alloc", ptr %t139, i32 0, i32 1
  %t141 = load i64, ptr %t140, !tbaa !24
  %t144 = icmp sgt i64 %t130, %t141
  store i1 %t144, ptr %l61, !tbaa !21
  br label %bb36
bb36:
  %t146 = load i1, ptr %l61, !tbaa !21
  br i1 %t146, label %bb37, label %bb38
bb37:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyBeyond, !tbaa !27
  %t149 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t149, ptr %t147, { i64, ptr } %t148)
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i64 -1, ptr %rv
  br label %ret
bb40:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/eval:Machine", ptr %t153, i32 0, i32 50
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l74, !tbaa !27
  %t157 = load i64, ptr %l4, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr %"compiler/eval:alloc", ptr %t160, i64 %t157
  %t162 = getelementptr %"compiler/eval:alloc", ptr %t161, i32 0, i32 9
  %t163 = load i64, ptr %t162, !tbaa !24
  %t165 = icmp sge i64 %t163, 0
  br i1 %t165, label %bb41, label %bb42
bb41:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/eval:Machine", ptr %t168, i32 0, i32 50
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  store { i64, ptr } %t171, ptr %l80, !tbaa !27
  %t172 = load i64, ptr %l4, !tbaa !24
  %t174 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr %"compiler/eval:alloc", ptr %t175, i64 %t172
  %t177 = getelementptr %"compiler/eval:alloc", ptr %t176, i32 0, i32 9
  %t178 = load i64, ptr %t177, !tbaa !24
  %t181 = getelementptr %"compiler/eval:Machine", ptr %t167, i32 0, i32 81
  store i64 %t178, ptr %t181, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  %t184 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t184, ptr %t182, { i64, ptr } %t183)
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i64 -1, ptr %rv
  br label %ret
bb44:
  br i1 %a3, label %bb45, label %bb46
bb45:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/eval:Machine", ptr %t190, i32 0, i32 50
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  store { i64, ptr } %t193, ptr %l88, !tbaa !27
  %t194 = load i64, ptr %l4, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr %"compiler/eval:alloc", ptr %t197, i64 %t194
  %t199 = getelementptr %"compiler/eval:alloc", ptr %t198, i32 0, i32 13
  %t200 = load i1, ptr %t199, !tbaa !21
  br i1 %t200, label %bb47, label %bb48
bb46:
  br label %bb69
bb47:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyReadOnly, !tbaa !27
  %t204 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t204, ptr %t202, { i64, ptr } %t203)
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i64 -1, ptr %rv
  br label %ret
bb50:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/eval:Machine", ptr %t208, i32 0, i32 50
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  store { i64, ptr } %t211, ptr %l95, !tbaa !27
  %t212 = load i64, ptr %l4, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr %"compiler/eval:alloc", ptr %t215, i64 %t212
  %t217 = getelementptr %"compiler/eval:alloc", ptr %t216, i32 0, i32 8
  %t218 = load i64, ptr %t217, !tbaa !24
  %t220 = icmp sge i64 %t218, 0
  br i1 %t220, label %bb51, label %bb52
bb51:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/eval:Machine", ptr %t222, i32 0, i32 50
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  store { i64, ptr } %t225, ptr %l101, !tbaa !27
  %t226 = load i64, ptr %l4, !tbaa !24
  %t228 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr %"compiler/eval:alloc", ptr %t229, i64 %t226
  %t231 = getelementptr %"compiler/eval:alloc", ptr %t230, i32 0, i32 8
  %t232 = load i64, ptr %t231, !tbaa !24
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/eval:Machine", ptr %t233, i32 0, i32 74
  %t236 = load i64, ptr %t235, !tbaa !24
  %t239 = icmp ne i64 %t232, %t236
  store i1 %t239, ptr %l99, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb53
bb53:
  %t241 = load i1, ptr %l99, !tbaa !21
  br i1 %t241, label %bb54, label %bb55
bb54:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/eval:Machine", ptr %t242, i32 0, i32 1
  %t245 = load i32, ptr %t244, !range !{i32 0, i32 2}
  %t247 = trunc i64 0 to i32
  %t248 = icmp eq i32 %t245, %t247
  br i1 %t248, label %bb56, label %bb57
bb55:
  br label %bb68
bb56:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWritesGlobal, !tbaa !27
  %t252 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t252, ptr %t250, { i64, ptr } %t251)
  br label %bb58
bb57:
  br label %bb59
bb58:
  store i64 -1, ptr %rv
  br label %ret
bb59:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/eval:Machine", ptr %t256, i32 0, i32 43
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/eval:Machine", ptr %t259, i32 0, i32 50
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  store { i64, ptr } %t262, ptr %l116, !tbaa !27
  %t263 = load i64, ptr %l4, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr %"compiler/eval:alloc", ptr %t266, i64 %t263
  %t268 = getelementptr %"compiler/eval:alloc", ptr %t267, i32 0, i32 8
  %t269 = load i64, ptr %t268, !tbaa !24
  %t272 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t258, i64 %t269)
  store %"compiler/eval:global" %t272, ptr %l119
  br label %bb60
bb60:
  %t273 = load %"compiler/eval:global", ptr %l119
  store %"compiler/eval:global" %t273, ptr %l5
  %t274 = getelementptr %"compiler/eval:global", ptr %l5, i32 0, i32 1
  %t275 = load i1, ptr %t274, !tbaa !21
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb61, label %bb62
bb61:
  %t279 = getelementptr %"compiler/eval:global", ptr %l5, i32 0, i32 3
  %t280 = load i64, ptr %t279, !tbaa !24
  %t281 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t284 = and i64 %t280, %t281
  %t285 = load i64, ptr %l4, !tbaa !24
  %t288 = icmp eq i64 %t284, %t285
  store i1 %t288, ptr %l122, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb63
bb63:
  %t290 = load i1, ptr %l122, !tbaa !21
  br i1 %t290, label %bb64, label %bb65
bb64:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyReadOnly, !tbaa !27
  %t293 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t293, ptr %t291, { i64, ptr } %t292)
  br label %bb66
bb65:
  br label %bb67
bb66:
  store i64 -1, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/eval:Machine", ptr %t297, i32 0, i32 50
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  store { i64, ptr } %t300, ptr %l132, !tbaa !27
  %t301 = load i64, ptr %l4, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr %"compiler/eval:alloc", ptr %t304, i64 %t301
  %t306 = getelementptr %"compiler/eval:alloc", ptr %t305, i32 0, i32 0
  %t307 = load i64, ptr %t306, !tbaa !24
  %t308 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t309 = load i64, ptr %t308, !tbaa !24
  %t312 = add i64 %t307, %t309
  store i64 %t312, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/eval:Machine", ptr %t2, i32 0, i32 27
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  store { i64, ptr } %t5, ptr %l5, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr %"compiler/eval:cfn", ptr %t9, i64 %a1
  %t11 = getelementptr %"compiler/eval:cfn", ptr %t10, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 78
  store i64 %t12, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 79
  store %"compiler/source:Span" %a2, ptr %t20
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t1, i64 %a1, { i64, [1 x i64] } %a2)
  store i64 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  %t19 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t19, ptr %t17, { i64, ptr } %t18)
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  %t23 = load i64, ptr %l3, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecalleeType(ptr %v0, ptr %a0, i64 %a1, { i64, [7 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [7 x i64] }
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l23 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 1
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb9
bb2:
  %t10 = load { i64, [7 x i64] }, ptr %l2
  %t12 = extractvalue { i64, [7 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t16 = getelementptr { i64, i32 }, ptr %t15, i32 0, i32 1
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l3, !tbaa !23
  br label %bb9
bb4:
  %t19 = load { i64, [7 x i64] }, ptr %l2
  %t21 = extractvalue { i64, [7 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 3
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t25 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t24, i32 0, i32 2
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb9
bb6:
  %t28 = load { i64, [7 x i64] }, ptr %l2
  %t30 = extractvalue { i64, [7 x i64] } %t28, 0
  %t31 = icmp eq i64 %t30, 4
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t34 = getelementptr { { i64, [4 x i64] }, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3, !tbaa !23
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t37 = load i32, ptr %l3, !tbaa !23
  store i32 %t37, ptr %l5, !tbaa !23
  br label %bb17
bb10:
  %t39 = load { i64, [7 x i64] }, ptr %l2
  %t41 = extractvalue { i64, [7 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 2
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t45 = getelementptr { { i64, [4 x i64] } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, [4 x i64] }, ptr %t45
  store { i64, [4 x i64] } %t46, ptr %l4
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/eval:Machine", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  store ptr %t51, ptr %l23, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = load { i64, [4 x i64] }, ptr %l4
  %t58 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t52, i64 %a1, { i64, [4 x i64] } %t54)
  store i32 %t58, ptr %l27
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l23, !tbaa !29
  %t60 = load i32, ptr %l27, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t61, ptr %l28
  br label %bb15
bb15:
  %t62 = load i32, ptr %l28, !tbaa !23
  store i32 %t62, ptr %l5, !tbaa !23
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_467821a0171adcef_9f7d024fdb995773)
  unreachable
bb17:
  %t63 = load i32, ptr %l5, !tbaa !23
  store i32 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecanonBits(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l2, !tbaa !24
  store i64 %t20, ptr %l14, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l17
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t26 = load i64, ptr %l17, !tbaa !24
  %t27 = call i64 @compiler_2feval_2ebmask(i64 %t26)
  store i64 %t27, ptr %l18
  br label %bb8
bb8:
  %t28 = load i64, ptr %l14, !tbaa !24
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = and i64 %t28, %t29
  store i64 %t30, ptr %rv
  br label %ret
bb9:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t36 = icmp eq i64 %t32, %t33
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load i64, ptr %l2, !tbaa !24
  store i64 %t40, ptr %l24, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l25, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t42, i32 %t43)
  store i64 %t46, ptr %l28
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i64, ptr %l28, !tbaa !24
  %t49 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t47, i64 %t48)
  store i64 %t49, ptr %l29
  br label %bb14
bb14:
  %t50 = load i64, ptr %l24, !tbaa !24
  %t51 = load i64, ptr %l29, !tbaa !24
  %t52 = and i64 %t50, %t51
  store i64 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseNow(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l17 = alloca %"compiler/eval:scope"
  %l20 = alloca i1
  %l28 = alloca %"compiler/eval:scope"
  %l34 = alloca %"compiler/eval:task"
  %l39 = alloca ptr
  %l45 = alloca %"compiler/eval:scope"
  %l52 = alloca ptr
  %l73 = alloca i64
  %l75 = alloca { i64, ptr }
  %l79 = alloca i1
  %t11 = alloca %"compiler/eval:scope", align 8
  %t33 = alloca %"compiler/eval:scope", align 8
  %t68 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t5 = and i64 %t1, %t2
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 53
  %t10 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t11, ptr %v0, ptr %t9, i64 %t10)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t11, i64 152, i1 false)
  br label %bb2
bb2:
  %t14 = getelementptr %"compiler/eval:scope", ptr %l17, i32 0, i32 10
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp sge i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 23
  %t22 = load i1, ptr %t21, !tbaa !21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l20, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l20, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  br label %bb23
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t29, i32 0, i32 53
  %t32 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t33, ptr %v0, ptr %t31, i64 %t32)
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %t33, i64 152, i1 false)
  br label %bb9
bb9:
  %t36 = getelementptr %"compiler/eval:scope", ptr %l28, i32 0, i32 10
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/eval:Machine", ptr %t41, i32 0, i32 57
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = call %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t43, i64 %t44)
  store %"compiler/eval:task" %t47, ptr %l34
  br label %bb10
bb10:
  %t48 = getelementptr %"compiler/eval:task", ptr %l34, i32 0, i32 3
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/eval:Machine", ptr %t51, i32 0, i32 53
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t53, i64 %t54)
  store ptr %t57, ptr %l39
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l39, !tbaa !29
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = getelementptr %"compiler/eval:scope", ptr %t58, i32 0, i32 10
  store i64 %t60, ptr %t63, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 53
  %t67 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t68, ptr %v0, ptr %t66, i64 %t67)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t68, i64 152, i1 false)
  br label %bb12
bb12:
  %t71 = getelementptr %"compiler/eval:scope", ptr %l45, i32 0, i32 10
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp slt i64 %t72, 0
  br i1 %t74, label %bb13, label %bb14
bb13:
  %t76 = load i64, ptr %l3, !tbaa !24
  store i64 -1, ptr %l9, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/eval:Machine", ptr %t78, i32 0, i32 53
  %t84 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t80, i64 %t76)
  store ptr %t84, ptr %l52
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t85 = load ptr, ptr %l52, !tbaa !29
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = getelementptr %"compiler/eval:scope", ptr %t85, i32 0, i32 11
  store i64 %t87, ptr %t90, !tbaa !24
  br label %bb16
bb16:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l1, !tbaa !24
  %t93 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartTask(ptr %v0, ptr %t91, i64 %t92, i64 %t93)
  br label %bb17
bb17:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/eval:Machine", ptr %t97, i32 0, i32 60
  %t100 = load i64, ptr %t99, !tbaa !24
  %t101 = load i64, ptr %l1, !tbaa !24
  %t103 = add i64 %t101, 1
  %t106 = icmp sgt i64 %t100, %t103
  br i1 %t106, label %bb18, label %bb19
bb18:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l1, !tbaa !24
  %t111 = add i64 %t109, 1
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %t108, i64 %t111)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb1
bb23:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/eval:Machine", ptr %t114, i32 0, i32 23
  %t117 = load i1, ptr %t116, !tbaa !21
  br i1 %t117, label %bb24, label %bb25
bb24:
  br label %ret
bb25:
  br label %bb26
bb26:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/eval:Machine", ptr %t119, i32 0, i32 63
  %t122 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/eval:Machine", ptr %t125, i32 0, i32 63
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t127)
  store i64 %t129, ptr %l73
  br label %bb29
bb29:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/eval:Machine", ptr %t130, i32 0, i32 59
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l75, !tbaa !27
  %t134 = load i64, ptr %l1, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr %"compiler/eval:frame", ptr %t137, i64 %t134
  %t139 = getelementptr %"compiler/eval:frame", ptr %t138, i32 0, i32 9
  %t140 = load i64, ptr %t139, !tbaa !24
  %t141 = load i64, ptr %l73, !tbaa !24
  %t143 = icmp sgt i64 %t141, %t140
  br i1 %t143, label %bb30, label %bb31
bb30:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/eval:Machine", ptr %t145, i32 0, i32 23
  %t148 = load i1, ptr %t147, !tbaa !21
  %t150 = xor i1 %t148, true
  store i1 %t150, ptr %l79, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb32
bb32:
  %t152 = load i1, ptr %l79, !tbaa !21
  %t153 = xor i1 %t152, true
  br i1 %t153, label %bb33, label %bb34
bb33:
  br label %bb42
bb34:
  br label %bb35
bb35:
  %t155 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estepClose(ptr %v0, ptr %t155)
  br label %bb36
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/eval:Machine", ptr %t157, i32 0, i32 60
  %t160 = load i64, ptr %t159, !tbaa !24
  %t161 = load i64, ptr %l1, !tbaa !24
  %t163 = add i64 %t161, 1
  %t166 = icmp sgt i64 %t160, %t163
  br i1 %t166, label %bb37, label %bb38
bb37:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i64, ptr %l1, !tbaa !24
  %t171 = add i64 %t169, 1
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %t168, i64 %t171)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb28
bb42:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseOpen(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [5 x i64] }
  %l5 = alloca i64
  %l6 = alloca %"compiler/eval:frame"
  %l7 = alloca i64
  %l8 = alloca i64
  %l23 = alloca i1
  %l34 = alloca { i64, ptr }
  %l36 = alloca %"compiler/eval:frame"
  %l43 = alloca i1
  %l49 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l61 = alloca i1
  %l71 = alloca i1
  %l74 = alloca i1
  %t9 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 21
  %t4 = load { i64, [5 x i64] }, ptr %t3
  store { i64, [5 x i64] } %t4, ptr %l2
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 88
  store i1 true, ptr %t8, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [5 x i64] }, ptr %t9, i32 0, i32 0
  store i64 0, ptr %t10
  %t11 = load { i64, [5 x i64] }, ptr %t9
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 23
  store i1 false, ptr %t17, !tbaa !21
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t18, i32 0, i32 21
  store { i64, [5 x i64] } %t11, ptr %t22
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 60
  %t26 = load i64, ptr %t25, !tbaa !24
  %t30 = icmp sgt i64 %t26, %a1
  br i1 %t30, label %bb2, label %bb3
bb2:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 23
  %t35 = load i1, ptr %t34, !tbaa !21
  %t37 = xor i1 %t35, true
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb4
bb4:
  %t39 = load i1, ptr %l23, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb5, label %bb6
bb5:
  br label %bb36
bb6:
  br label %bb7
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 60
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l5, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropOwnDefers(ptr %v0, ptr %t49, i64 %t50)
  br label %bb8
bb8:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/eval:Machine", ptr %t53, i32 0, i32 59
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/eval:frame", ptr %t60, i64 %t57
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t61, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l36, i64 136, i1 false)
  %t62 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 5
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 4
  %t65 = load i64, ptr %t64, !tbaa !24
  %t68 = sub i64 %t63, %t65
  %t70 = sub i64 %t68, 1
  store i64 %t70, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sge i64 %t72, 0
  br i1 %t74, label %bb10, label %bb11
bb10:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/eval:Machine", ptr %t76, i32 0, i32 23
  %t79 = load i1, ptr %t78, !tbaa !21
  %t81 = xor i1 %t79, true
  store i1 %t81, ptr %l43, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb12
bb12:
  %t83 = load i1, ptr %l43, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb13, label %bb14
bb13:
  br label %bb22
bb14:
  br label %bb15
bb15:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/eval:Machine", ptr %t86, i32 0, i32 61
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l49, !tbaa !27
  %t90 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 4
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i64, ptr %t98, i64 %t95
  %t100 = load i64, ptr %t99, !tbaa !34
  store i64 %t100, ptr %l8, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/eval:Machine", ptr %t102, i32 0, i32 61
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l55, !tbaa !27
  %t106 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 4
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = load i64, ptr %l7, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i64, ptr %t114, i64 %t111
  store i64 0, ptr %t115, !tbaa !34
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i64, ptr %l8, !tbaa !24
  %t120 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t116, i64 %t117)
  store i1 %t120, ptr %l61
  br label %bb16
bb16:
  %t121 = load i1, ptr %l61, !tbaa !21
  br i1 %t121, label %bb17, label %bb18
bb17:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l5, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseNow(ptr %v0, ptr %t122, i64 %t123, i64 %t124)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = sub i64 %t128, 1
  store i64 %t131, ptr %l7, !tbaa !24
  br label %bb9
bb22:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 23
  %t136 = load i1, ptr %t135, !tbaa !21
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb23, label %bb24
bb23:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 6
  %t142 = load i64, ptr %t141, !tbaa !24
  %t145 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t140, i64 %t142)
  store i1 %t145, ptr %l74
  br label %bb25
bb24:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb26
bb25:
  %t146 = load i1, ptr %l74, !tbaa !21
  store i1 %t146, ptr %l71, !tbaa !21
  br label %bb26
bb26:
  %t147 = load i1, ptr %l71, !tbaa !21
  br i1 %t147, label %bb27, label %bb28
bb27:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i64, ptr %l5, !tbaa !24
  %t150 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 6
  %t151 = load i64, ptr %t150, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseNow(ptr %v0, ptr %t148, i64 %t149, i64 %t151)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/eval:Machine", ptr %t155, i32 0, i32 23
  %t158 = load i1, ptr %t157, !tbaa !21
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb31, label %bb32
bb31:
  %t162 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropFrame(ptr %v0, ptr %t162)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb1
bb36:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/eval:Machine", ptr %t164, i32 0, i32 88
  store i1 false, ptr %t166, !tbaa !21
  %t167 = load { i64, [5 x i64] }, ptr %l2
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/eval:Machine", ptr %t169, i32 0, i32 23
  store i1 true, ptr %t173, !tbaa !21
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/eval:Machine", ptr %t174, i32 0, i32 21
  store { i64, [5 x i64] } %t167, ptr %t178
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseRegion(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i1
  %l13 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edisown(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t9 = and i64 %t5, %t6
  store i1 true, ptr %l3, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t11, i32 0, i32 53
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t13, i64 %t9)
  store ptr %t17, ptr %l13
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t20 = load i1, ptr %l3, !tbaa !21
  %t23 = getelementptr %"compiler/eval:scope", ptr %t18, i32 0, i32 15
  store i1 %t20, ptr %t23, !tbaa !21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/eval:Machine", ptr %t24, i32 0, i32 63
  %t27 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t26, i64 %t27)
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodeIndex(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca { i64, [2 x i64] }
  %l17 = alloca i64
  %l25 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 33
  %t4 = load { i64, [2 x i64] }, ptr %l1
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t3, { i64, [2 x i64] } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 33
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t23, ptr %l14
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/eval:Machine", ptr %t24, i32 0, i32 32
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l17
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l13, !tbaa !29
  %t30 = load { i64, [2 x i64] }, ptr %l14
  %t31 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eP_H79a97b7337c7adf08bdd37311af7e171(ptr %v0, ptr %t29, { i64, [2 x i64] } %t30, i64 %t31)
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 32
  %t35 = load { i64, [2 x i64] }, ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t34, { i64, [2 x i64] } %t35)
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t40, i64 0)
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 32
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l25
  br label %bb12
bb12:
  %t47 = load i64, ptr %l25, !tbaa !24
  %t48 = sub i64 %t47, 1
  store i64 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodePtr(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i64
  %l10 = alloca i64
  %l16 = alloca %"compiler/eval:Ptr"
  %l18 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodeIndex(ptr %v0, ptr %t1, { i64, [2 x i64] } %a1)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 34
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t9, i64 %t10)
  store i64 %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load i64, ptr %l10, !tbaa !24
  %t15 = icmp eq i64 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr @G_2ecompiler_2feval_2eaCode, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 71
  %t22 = load i64, ptr %t21, !tbaa !24
  %t26 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t17, i64 0, i64 %t18, i64 %t22)
  store %"compiler/eval:Ptr" %t26, ptr %l16
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t27 = load %"compiler/eval:Ptr", ptr %l16
  store %"compiler/eval:Ptr" %t27, ptr %l3
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 50
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t32 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 0
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t37 = and i64 %t33, %t34
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr %"compiler/eval:alloc", ptr %t42, i64 %t37
  %t44 = getelementptr %"compiler/eval:alloc", ptr %t43, i32 0, i32 14
  store i64 %t38, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/eval:Machine", ptr %t45, i32 0, i32 34
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 0
  %t50 = load i64, ptr %t49, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t47, i64 %t48, i64 %t50)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/eval:Machine", ptr %t54, i32 0, i32 34
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t56, i64 %t57)
  store i64 %t60, ptr %l30
  br label %bb8
bb8:
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t61, i64 0)
  store %"compiler/eval:Ptr" %t62, ptr %l31
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t63 = load %"compiler/eval:Ptr", ptr %l31
  store %"compiler/eval:Ptr" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2econstLen(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [1 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i64 1, ptr %l4, !tbaa !24
  br label %bb11
bb4:
  %t6 = load { i64, [1 x i64] }, ptr %l2
  %t8 = extractvalue { i64, [1 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t12 = getelementptr { %"compiler/mir:Range" }, ptr %t11, i32 0, i32 0
  %t13 = load %"compiler/mir:Range", ptr %t12
  store %"compiler/mir:Range" %t13, ptr %l3
  br label %bb9
bb6:
  %t15 = load { i64, [1 x i64] }, ptr %l2
  %t17 = extractvalue { i64, [1 x i64] } %t15, 0
  %t18 = icmp eq i64 %t17, 2
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t20 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t21 = getelementptr { %"compiler/mir:Range" }, ptr %t20, i32 0, i32 0
  %t22 = load %"compiler/mir:Range", ptr %t21
  store %"compiler/mir:Range" %t22, ptr %l3
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t24 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = sext i32 %t25 to i64
  store i64 %t27, ptr %l4, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_6be2223409a54017_8087911232ed0aeb)
  unreachable
bb11:
  %t29 = load i64, ptr %l4, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i64, ptr %l3, !tbaa !24
  %t11 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t5, %"compiler/eval:Ptr" %a2, i64 %t7, i1 false)
  store i64 %t11, ptr %l11
  br label %bb4
bb4:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l3, !tbaa !24
  %t19 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t13, %"compiler/eval:Ptr" %a1, i64 %t15, i1 true)
  store i64 %t19, ptr %l15
  br label %bb5
bb5:
  %t20 = load i64, ptr %l15, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2emove(ptr %v0, ptr %t30, i64 %t31, i64 %t32, i64 %t33)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopyBits(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2, %"compiler/eval:Ptr" %a3, i64 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l3 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/eval:Ptr"
  %l20 = alloca i64
  %l23 = alloca i64
  %l47 = alloca ptr
  %l53 = alloca %"compiler/eval:Ptr"
  %l54 = alloca i64
  %l56 = alloca i64
  %l64 = alloca %"compiler/eval:Ptr"
  %l65 = alloca ptr
  %l66 = alloca %"compiler/eval:Ptr"
  %l69 = alloca i64
  %l71 = alloca i64
  %l77 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  store %"compiler/eval:Ptr" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l6, !tbaa !24
  store i64 %a5, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t3 = load i64, ptr %l7, !tbaa !24
  %t4 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l8, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l8, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l8, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l23, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l23, !tbaa !24
  store i64 %t29, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l20, !tbaa !24
  store i64 %t30, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l10, !tbaa !24
  %t32 = load i64, ptr %l9, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l10, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l11, !tbaa !24
  %t50 = load i64, ptr %l11, !tbaa !24
  %t53 = add i64 %a4, %t50
  store i64 %t53, ptr %l12, !tbaa !24
  %t56 = load i64, ptr %l11, !tbaa !24
  %t59 = add i64 %a2, %t56
  store i64 %t59, ptr %l13, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l47, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = load i64, ptr %l12, !tbaa !24
  %t68 = sdiv i64 %t66, 8
  %t71 = add i64 %t65, %t68
  %t74 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t63, i64 %t71)
  store %"compiler/eval:Ptr" %t74, ptr %l53
  br label %bb11
bb11:
  %t75 = load ptr, ptr %l47, !tbaa !29
  %t76 = load %"compiler/eval:Ptr", ptr %l53
  %t77 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t75, %"compiler/eval:Ptr" %t76, i64 1)
  store i64 %t77, ptr %l54
  br label %bb12
bb12:
  %t78 = load i64, ptr %l12, !tbaa !24
  %t80 = srem i64 %t78, 8
  store i64 %t80, ptr %l56, !tbaa !24
  %t81 = load i64, ptr %l54, !tbaa !24
  %t82 = load i64, ptr %l56, !tbaa !24
  %t83 = load i64, ptr %l56, !tbaa !24
  %t84 = ashr i64 %t81, %t83
  %t86 = and i64 %t84, 1
  store i64 %t86, ptr %l14, !tbaa !24
  %t88 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t89 = load i64, ptr %t88, !tbaa !24
  %t90 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = load i64, ptr %l13, !tbaa !24
  %t94 = sdiv i64 %t92, 8
  %t97 = add i64 %t91, %t94
  %t100 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t89, i64 %t97)
  store %"compiler/eval:Ptr" %t100, ptr %l64
  br label %bb13
bb13:
  %t101 = load %"compiler/eval:Ptr", ptr %l64
  store %"compiler/eval:Ptr" %t101, ptr %l15
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l65, !tbaa !29
  %t103 = load %"compiler/eval:Ptr", ptr %l15
  store %"compiler/eval:Ptr" %t103, ptr %l66
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load %"compiler/eval:Ptr", ptr %l15
  %t108 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t104, %"compiler/eval:Ptr" %t105, i64 1)
  store i64 %t108, ptr %l69
  br label %bb14
bb14:
  %t109 = load i64, ptr %l13, !tbaa !24
  %t111 = srem i64 %t109, 8
  store i64 %t111, ptr %l71, !tbaa !24
  %t112 = load i64, ptr %l71, !tbaa !24
  %t113 = load i64, ptr %l71, !tbaa !24
  %t114 = shl i64 1, %t113
  %t116 = xor i64 %t114, -1
  %t117 = load i64, ptr %l69, !tbaa !24
  %t119 = and i64 %t117, %t116
  %t120 = load i64, ptr %l14, !tbaa !24
  %t121 = load i64, ptr %l13, !tbaa !24
  %t123 = srem i64 %t121, 8
  store i64 %t123, ptr %l77, !tbaa !24
  %t125 = load i64, ptr %l77, !tbaa !24
  %t126 = load i64, ptr %l77, !tbaa !24
  %t127 = shl i64 %t120, %t126
  %t130 = or i64 %t119, %t127
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = load %"compiler/eval:Ptr", ptr %l66
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t131, %"compiler/eval:Ptr" %t132, i64 1, i64 %t130)
  br label %bb15
bb15:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/eval:Machine", ptr %t134, i32 0, i32 23
  %t137 = load i1, ptr %t136, !tbaa !21
  br i1 %t137, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = add i64 %t139, 1
  store i64 %t142, ptr %l10, !tbaa !24
  br label %bb7
bb20:
  br label %ret
ret:
  ret void
}

define dso_local { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2edataFor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/eval:dkey"
  %l8 = alloca i64
  %l9 = alloca { i64, [1 x i64] }
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca %"compiler/eval:Ptr"
  %l16 = alloca i64
  %l23 = alloca %"compiler/eval:dkey"
  %l24 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i32
  %l34 = alloca { i64, [1 x i64] }
  %l38 = alloca i64
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i64
  %l48 = alloca i64
  %l53 = alloca %"compiler/eval:Ptr"
  %l64 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l79 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca { %"compiler/eval:Ptr", i64 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/mir:Fn", ptr %t2, i32 0, i32 0
  %t5 = load { i64, [2 x i64] }, ptr %t4
  %t8 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodeIndex(ptr %v0, ptr %t1, { i64, [2 x i64] } %t5)
  store i64 %t8, ptr %l16
  br label %bb1
bb1:
  %t9 = load i64, ptr %l16, !tbaa !24
  %t11 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  %t13 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t14 = load i32, ptr %t13, !tbaa !23
  %t15 = load i32, ptr %l2, !tbaa !23
  %t16 = load i32, ptr %l3, !tbaa !23
  %t24 = call %"compiler/eval:dkey" @compiler_2feval_3adkey_2ector(ptr %s0, i64 %a4, i32 %t12, i32 %t14, i32 %t15, i32 %t16, i64 %t9)
  store %"compiler/eval:dkey" %t24, ptr %l23
  br label %bb2
bb2:
  %t25 = load %"compiler/eval:dkey", ptr %l23
  store %"compiler/eval:dkey" %t25, ptr %l7
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/eval:Machine", ptr %t26, i32 0, i32 45
  %t29 = load %"compiler/eval:dkey", ptr %l7
  %t32 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3adkey_2c_20I64_3e_2eG_H537d495038c4cf6799e621bee696b05f(ptr %v0, ptr %t28, %"compiler/eval:dkey" %t29)
  %t33 = extractvalue { i32, i64 } %t32, 1
  %t34 = extractvalue { i32, i64 } %t32, 0
  store i32 %t34, ptr %l29
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb4, label %ok.36, !prof !99
ok.36:
  store i64 %t33, ptr %l28
  br label %bb3
bb3:
  %t37 = load i64, ptr %l28, !tbaa !24
  store i64 %t37, ptr %l24, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  store i64 %t38, ptr %l8, !tbaa !24
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/mir:Fn", ptr %t39, i32 0, i32 19
  %t42 = load i32, ptr %l3, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t47 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v1, ptr %t41, i64 %t44)
  store { i64, [1 x i64] } %t47, ptr %l34
  br label %bb7
bb7:
  %t48 = load { i64, [1 x i64] }, ptr %l34
  store { i64, [1 x i64] } %t48, ptr %l9
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = load { i64, [1 x i64] }, ptr %l9
  %t55 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2econstLen(ptr %v0, ptr %v1, ptr %t49, ptr %t50, { i64, [1 x i64] } %t51)
  store i64 %t55, ptr %l38
  br label %bb8
bb8:
  %t56 = load i64, ptr %l38, !tbaa !24
  store i64 %t56, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp eq i64 %t57, 0
  br i1 %t59, label %bb9, label %bb10
bb9:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l2, !tbaa !23
  %t65 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l43
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t66 = load i32, ptr %l43, !tbaa !23
  store i32 %t66, ptr %l11, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l44, !tbaa !29
  %t68 = load i64, ptr %l10, !tbaa !24
  store i64 %t68, ptr %l45, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l11, !tbaa !23
  %t73 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t69, i32 %t70)
  store i64 %t73, ptr %l48
  br label %bb12
bb12:
  %t74 = load i64, ptr %l45, !tbaa !24
  %t75 = load i64, ptr %l48, !tbaa !24
  %t76 = mul i64 %t74, %t75
  %t77 = load i64, ptr @G_2ecompiler_2feval_2eaData, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/eval:Machine", ptr %t78, i32 0, i32 71
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load ptr, ptr %l44, !tbaa !29
  %t86 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t82, i64 %t76, i64 %t77, i64 %t81)
  store %"compiler/eval:Ptr" %t86, ptr %l53
  br label %bb13
bb13:
  %t87 = load %"compiler/eval:Ptr", ptr %l53
  store %"compiler/eval:Ptr" %t87, ptr %l12
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/eval:Machine", ptr %t88, i32 0, i32 23
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb14, label %bb15
bb14:
  %t93 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t95 = insertvalue { %"compiler/eval:Ptr", i64 } undef, %"compiler/eval:Ptr" %t93, 0
  %t96 = insertvalue { %"compiler/eval:Ptr", i64 } %t95, i64 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i64 } %t96, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t100 = load %"compiler/eval:Ptr", ptr %l12
  %t101 = load i32, ptr %l11, !tbaa !23
  %t102 = load { i64, [1 x i64] }, ptr %l9
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewriteElems(ptr %v0, ptr %v1, ptr %t98, ptr %t99, %"compiler/eval:Ptr" %t100, i32 %t101, { i64, [1 x i64] } %t102)
  br label %bb17
bb17:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/eval:Machine", ptr %t108, i32 0, i32 50
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l64, !tbaa !27
  %t112 = getelementptr %"compiler/eval:Ptr", ptr %l12, i32 0, i32 0
  %t113 = load i64, ptr %t112, !tbaa !24
  %t114 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t117 = and i64 %t113, %t114
  %t119 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr %"compiler/eval:alloc", ptr %t120, i64 %t117
  %t122 = getelementptr %"compiler/eval:alloc", ptr %t121, i32 0, i32 13
  store i1 true, ptr %t122, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/eval:Machine", ptr %t123, i32 0, i32 50
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l69, !tbaa !27
  %t127 = getelementptr %"compiler/eval:Ptr", ptr %l12, i32 0, i32 0
  %t128 = load i64, ptr %t127, !tbaa !24
  %t129 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t132 = and i64 %t128, %t129
  %t134 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr %"compiler/eval:alloc", ptr %t135, i64 %t132
  %t137 = getelementptr %"compiler/eval:alloc", ptr %t136, i32 0, i32 8
  store i64 -1, ptr %t137, !tbaa !24
  %t138 = getelementptr %"compiler/eval:Ptr", ptr %l12, i32 0, i32 0
  %t139 = load i64, ptr %t138, !tbaa !24
  store i64 %t139, ptr %l8, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/eval:Machine", ptr %t141, i32 0, i32 45
  %t144 = load %"compiler/eval:dkey", ptr %l7
  %t145 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3adkey_2c_20I64_3e_2eP_H91b95c77ac9fc5702101e9e6061f40cd(ptr %v0, ptr %t143, %"compiler/eval:dkey" %t144, i64 %t145)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t149 = load i64, ptr %l8, !tbaa !24
  %t151 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t149, i64 0)
  store %"compiler/eval:Ptr" %t151, ptr %l79
  br label %bb20
bb20:
  %t152 = load i64, ptr %l10, !tbaa !24
  %t153 = load %"compiler/eval:Ptr", ptr %l79
  %t154 = insertvalue { %"compiler/eval:Ptr", i64 } undef, %"compiler/eval:Ptr" %t153, 0
  %t156 = insertvalue { %"compiler/eval:Ptr", i64 } %t154, i64 %t152, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i64 } %t156, ptr %rv
  br label %ret
ret:
  %rr = load { %"compiler/eval:Ptr", i64 }, ptr %rv
  ret { %"compiler/eval:Ptr", i64 } %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2edeliver(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/eval:frame"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/mir:Call"
  %l8 = alloca { %"compiler/eval:Ptr", i32 }
  %l12 = alloca %"compiler/eval:Ptr"
  %l15 = alloca %"compiler/eval:global"
  %l17 = alloca { i64, ptr }
  %l19 = alloca %"compiler/eval:frame"
  %l25 = alloca i32
  %l34 = alloca ptr
  %l38 = alloca %"compiler/mir:Call"
  %l43 = alloca { %"compiler/eval:Ptr", i32 }
  %l56 = alloca i64
  %l62 = alloca %"compiler/eval:Ptr"
  %l80 = alloca %"compiler/eval:global"
  %l81 = alloca ptr
  %l82 = alloca i64
  %l84 = alloca %"compiler/eval:Ptr"
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 59
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l17, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t9, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l19, i64 136, i1 false)
  %t10 = load { i64, [4 x i64] }, ptr %l2
  %t12 = extractvalue { i64, [4 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l1, !tbaa !24
  %t17 = load { i64, [4 x i64] }, ptr %l2
  %t21 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t15, i64 %t16, { i64, [4 x i64] } %t17)
  store i32 %t21, ptr %l25
  br label %bb4
bb4:
  %t22 = load i32, ptr %l25, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  %t23 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 7
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr @G_2ecompiler_2feval_2erCall, !tbaa !24
  %t30 = icmp eq i64 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb15
bb7:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = sub i64 %t32, 1
  store i64 %t34, ptr %l6, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = call ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  store ptr %t40, ptr %l34
  br label %bb8
bb8:
  %t41 = load ptr, ptr %l34, !tbaa !29
  %t43 = getelementptr %"compiler/mir:Fn", ptr %t41, i32 0, i32 14
  %t44 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 8
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t43, i64 %t45)
  store %"compiler/mir:Call" %t48, ptr %l38
  br label %bb9
bb9:
  %t49 = load %"compiler/mir:Call", ptr %l38
  store %"compiler/mir:Call" %t49, ptr %l7
  %t50 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 4
  %t51 = load i1, ptr %t50, !tbaa !21
  br i1 %t51, label %bb10, label %bb11
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 3
  %t56 = load %"compiler/mir:Lvalue", ptr %t55
  %t60 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t53, i64 %t54, %"compiler/mir:Lvalue" %t56)
  store { %"compiler/eval:Ptr", i32 } %t60, ptr %l43
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t61 = load { %"compiler/eval:Ptr", i32 }, ptr %l43
  store { %"compiler/eval:Ptr", i32 } %t61, ptr %l8
  %t62 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l8, i32 0, i32 0
  %t63 = load %"compiler/eval:Ptr", ptr %t62
  %t65 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l8, i32 0, i32 1
  %t66 = load i32, ptr %t65, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  %t72 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t68, i64 %t69, %"compiler/eval:Ptr" %t63, i32 %t66, { i64, [4 x i64] } %t72)
  br label %bb13
bb13:
  br label %bb14
bb14:
  br label %bb41
bb15:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t79 = load i64, ptr @G_2ecompiler_2feval_2erRequest, !tbaa !24
  %t82 = icmp eq i64 %t78, %t79
  br i1 %t82, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t84, i32 %t85)
  store i64 %t88, ptr %l56
  br label %bb19
bb19:
  %t89 = load i64, ptr %l56, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/eval:Machine", ptr %t93, i32 0, i32 71
  %t96 = load i64, ptr %t95, !tbaa !24
  %t101 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t90, i64 %t89, i64 %t92, i64 %t96)
  store %"compiler/eval:Ptr" %t101, ptr %l62
  br label %bb20
bb20:
  %t102 = load %"compiler/eval:Ptr", ptr %l62
  store %"compiler/eval:Ptr" %t102, ptr %l12
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i64, ptr %l1, !tbaa !24
  %t105 = load %"compiler/eval:Ptr", ptr %l12
  %t106 = load i32, ptr %l4, !tbaa !23
  %t107 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t103, i64 %t104, %"compiler/eval:Ptr" %t105, i32 %t106, { i64, [4 x i64] } %t107)
  br label %bb21
bb21:
  %t113 = load %"compiler/eval:Ptr", ptr %l12
  %t115 = load i32, ptr %l4, !tbaa !23
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/eval:Machine", ptr %t117, i32 0, i32 19
  store %"compiler/eval:Ptr" %t113, ptr %t121
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/eval:Machine", ptr %t122, i32 0, i32 20
  store i32 %t115, ptr %t126, !tbaa !23
  br label %bb41
bb22:
  %t127 = load i64, ptr %l5, !tbaa !24
  %t128 = load i64, ptr @G_2ecompiler_2feval_2erGlobal, !tbaa !24
  %t131 = icmp eq i64 %t127, %t128
  br i1 %t131, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb29
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 43
  %t136 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 8
  %t137 = load i64, ptr %t136, !tbaa !24
  %t140 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t135, i64 %t137)
  store %"compiler/eval:global" %t140, ptr %l80
  br label %bb26
bb26:
  %t141 = load %"compiler/eval:global", ptr %l80
  store %"compiler/eval:global" %t141, ptr %l15
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l81, !tbaa !29
  %t143 = load i64, ptr %l1, !tbaa !24
  store i64 %t143, ptr %l82, !tbaa !24
  %t144 = getelementptr %"compiler/eval:global", ptr %l15, i32 0, i32 3
  %t145 = load i64, ptr %t144, !tbaa !24
  %t147 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t145, i64 0)
  store %"compiler/eval:Ptr" %t147, ptr %l84
  br label %bb27
bb27:
  %t148 = getelementptr %"compiler/eval:global", ptr %l15, i32 0, i32 0
  %t149 = load i64, ptr %t148, !tbaa !24
  %t151 = trunc i64 %t149 to i32
  %t153 = load { i64, [4 x i64] }, ptr %l2
  %t154 = load ptr, ptr %l81, !tbaa !29
  %t155 = load i64, ptr %l82, !tbaa !24
  %t156 = load %"compiler/eval:Ptr", ptr %l84
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t154, i64 %t155, %"compiler/eval:Ptr" %t156, i32 %t151, { i64, [4 x i64] } %t153)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb29:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t160 = load i64, ptr @G_2ecompiler_2feval_2erTask, !tbaa !24
  %t163 = icmp eq i64 %t159, %t160
  br i1 %t163, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  %t165 = load i64, ptr %l5, !tbaa !24
  %t166 = load i64, ptr @G_2ecompiler_2feval_2erClause, !tbaa !24
  %t169 = icmp eq i64 %t165, %t166
  br i1 %t169, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i64, ptr %l1, !tbaa !24
  %t173 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 8
  %t174 = load i64, ptr %t173, !tbaa !24
  %t175 = load { i64, [4 x i64] }, ptr %l2
  %t176 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2etoTargets(ptr %v0, ptr %t171, i64 %t172, i64 %t174, { i64, [4 x i64] } %t175, i32 %t176)
  br label %bb35
bb35:
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_17d12c125f58d820_35ade4b878109a14)
  unreachable
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2edisown(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l22 = alloca %"compiler/eval:scope"
  %l26 = alloca i1
  %l29 = alloca i1
  %l37 = alloca %"compiler/eval:scope"
  %l45 = alloca %"compiler/eval:scope"
  %l50 = alloca ptr
  %l56 = alloca %"compiler/eval:scope"
  %l66 = alloca %"compiler/eval:scope"
  %l77 = alloca %"compiler/eval:scope"
  %l82 = alloca ptr
  %l90 = alloca ptr
  %t11 = alloca %"compiler/eval:scope", align 8
  %t40 = alloca %"compiler/eval:scope", align 8
  %t56 = alloca %"compiler/eval:scope", align 8
  %t63 = alloca %"compiler/eval:scope", align 8
  %t99 = alloca %"compiler/eval:scope", align 8
  %t121 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t5 = and i64 %t1, %t2
  store i64 %t5, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 53
  %t10 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t11, ptr %v0, ptr %t9, i64 %t10)
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t11, i64 152, i1 false)
  br label %bb1
bb1:
  %t14 = getelementptr %"compiler/eval:scope", ptr %l22, i32 0, i32 5
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp eq i64 %t17, 0
  br i1 %t19, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb5
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t21, i64 %t22)
  store i1 %t25, ptr %l29
  br label %bb4
bb4:
  %t26 = load i1, ptr %l29, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l26, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t34 = and i64 %t30, %t31
  store i64 %t34, ptr %l4, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/eval:Machine", ptr %t36, i32 0, i32 53
  %t39 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t40, ptr %v0, ptr %t38, i64 %t39)
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t40, i64 152, i1 false)
  br label %bb9
bb9:
  %t43 = getelementptr %"compiler/eval:scope", ptr %l37, i32 0, i32 6
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = icmp eq i64 %t44, %t45
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load i64, ptr %l4, !tbaa !24
  store i64 %t50, ptr %l5, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/eval:Machine", ptr %t52, i32 0, i32 53
  %t55 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t56, ptr %v0, ptr %t54, i64 %t55)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t56, i64 152, i1 false)
  br label %bb12
bb11:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/eval:Machine", ptr %t59, i32 0, i32 53
  %t62 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t63, ptr %v0, ptr %t61, i64 %t62)
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %t63, i64 152, i1 false)
  br label %bb14
bb12:
  %t66 = getelementptr %"compiler/eval:scope", ptr %l45, i32 0, i32 7
  %t67 = load i64, ptr %t66, !tbaa !24
  store i64 %t67, ptr %l6, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/eval:Machine", ptr %t69, i32 0, i32 53
  %t72 = load i64, ptr %l5, !tbaa !24
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l50
  br label %bb13
bb13:
  %t76 = load ptr, ptr %l50, !tbaa !29
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = getelementptr %"compiler/eval:scope", ptr %t76, i32 0, i32 6
  store i64 %t78, ptr %t81, !tbaa !24
  br label %bb27
bb14:
  %t82 = getelementptr %"compiler/eval:scope", ptr %l56, i32 0, i32 6
  %t83 = load i64, ptr %t82, !tbaa !24
  store i64 %t83, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = icmp ne i64 %t85, 0
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb16, label %bb17
bb16:
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/eval:Machine", ptr %t91, i32 0, i32 53
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t98 = and i64 %t94, %t95
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t99, ptr %v0, ptr %t93, i64 %t98)
  call void @llvm.memmove.p0.p0.i64(ptr %l66, ptr %t99, i64 152, i1 false)
  br label %bb19
bb19:
  %t102 = getelementptr %"compiler/eval:scope", ptr %l66, i32 0, i32 7
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l9, !tbaa !24
  %t105 = load i64, ptr %l9, !tbaa !24
  %t106 = load i64, ptr %l1, !tbaa !24
  %t109 = icmp eq i64 %t105, %t106
  br i1 %t109, label %bb20, label %bb21
bb20:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t112 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t115 = and i64 %t111, %t112
  store i64 %t115, ptr %l10, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/eval:Machine", ptr %t117, i32 0, i32 53
  %t120 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t121, ptr %v0, ptr %t119, i64 %t120)
  call void @llvm.memmove.p0.p0.i64(ptr %l77, ptr %t121, i64 152, i1 false)
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t124 = getelementptr %"compiler/eval:scope", ptr %l77, i32 0, i32 7
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %l11, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/eval:Machine", ptr %t127, i32 0, i32 53
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t129, i64 %t130)
  store ptr %t133, ptr %l82
  br label %bb23
bb23:
  %t134 = load ptr, ptr %l82, !tbaa !29
  %t136 = load i64, ptr %l11, !tbaa !24
  %t139 = getelementptr %"compiler/eval:scope", ptr %t134, i32 0, i32 7
  store i64 %t136, ptr %t139, !tbaa !24
  br label %bb26
bb24:
  %t140 = load i64, ptr %l9, !tbaa !24
  store i64 %t140, ptr %l8, !tbaa !24
  br label %bb25
bb25:
  br label %bb15
bb26:
  br label %bb27
bb27:
  %t142 = load i64, ptr %l2, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/eval:Machine", ptr %t144, i32 0, i32 53
  %t150 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t146, i64 %t142)
  store ptr %t150, ptr %l90
  br label %bb28
bb28:
  %t151 = load ptr, ptr %l90, !tbaa !29
  %t153 = load i64, ptr %l14, !tbaa !24
  %t156 = getelementptr %"compiler/eval:scope", ptr %t151, i32 0, i32 5
  store i64 %t153, ptr %t156, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropFrame(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/eval:frame"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/eval:frame"
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca { i64, ptr }
  %l52 = alloca i1
  %l60 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 60
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/eval:Machine", ptr %t8, i32 0, i32 59
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l14, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr %"compiler/eval:frame", ptr %t15, i64 %t6
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t16, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l16, i64 136, i1 false)
  store i64 0, ptr %l3, !tbaa !24
  %t17 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 5
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 4
  %t20 = load i64, ptr %t19, !tbaa !24
  %t23 = sub i64 %t18, %t20
  store i64 %t23, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb1, label %bb2
bb1:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb3:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l26, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb5
bb5:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t52 = load i64, ptr %l23, !tbaa !24
  store i64 %t52, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/eval:Machine", ptr %t71, i32 0, i32 61
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l45, !tbaa !27
  %t75 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 4
  %t76 = load i64, ptr %t75, !tbaa !24
  %t80 = add i64 %t76, %t69
  %t82 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i64, ptr %t83, i64 %t80
  %t85 = load i64, ptr %t84, !tbaa !34
  store i64 %t85, ptr %l9, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i64, ptr %l9, !tbaa !24
  %t91 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t87, i64 %t88)
  store i1 %t91, ptr %l52
  br label %bb11
bb11:
  %t92 = load i1, ptr %l52, !tbaa !21
  br i1 %t92, label %bb12, label %bb13
bb12:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropScope(ptr %v0, ptr %t93, i64 %t94)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t97, 1
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb7
bb17:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 6
  %t104 = load i64, ptr %t103, !tbaa !24
  %t107 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t102, i64 %t104)
  store i1 %t107, ptr %l60
  br label %bb18
bb18:
  %t108 = load i1, ptr %l60, !tbaa !21
  br i1 %t108, label %bb19, label %bb20
bb19:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 6
  %t111 = load i64, ptr %t110, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropScope(ptr %v0, ptr %t109, i64 %t111)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/eval:Machine", ptr %t114, i32 0, i32 63
  %t117 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 9
  %t118 = load i64, ptr %t117, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t116, i64 %t118)
  br label %bb23
bb23:
  %t121 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2epopFrame(ptr %v0, ptr %t121)
  br label %bb24
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropOwnDefers(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 67
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t11, i32 0, i32 67
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = sub i64 %t14, 1
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t16)
  store i64 %t19, ptr %l13
  br label %bb5
bb4:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t21 = load i64, ptr %l13, !tbaa !24
  %t23 = icmp sge i64 %t21, %a1
  store i1 %t23, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l8, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = sub i64 %t28, 1
  store i64 %t31, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t33, i32 0, i32 67
  %t36 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t35, i64 %t36)
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 68
  %t42 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/eval:Machine", ptr %t45, i32 0, i32 69
  %t48 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t47, i64 %t48)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t19 = trunc i64 20 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l17
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load i32, ptr %l18, !tbaa !23
  store i32 %t31, ptr %l3, !tbaa !23
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l21
  br label %bb8
bb8:
  %t37 = load i32, ptr %l21, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eelement(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { %"compiler/eval:Ptr", i64 }
  %l6 = alloca %"compiler/eval:Ptr"
  %l7 = alloca i64
  %l10 = alloca i32
  %l14 = alloca { %"compiler/eval:Ptr", i64 }
  %l24 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l41 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca { %"compiler/eval:Ptr", i32 }
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l2, !tbaa !23
  %t13 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t7, %"compiler/eval:Ptr" %a1, i32 %t9)
  store { %"compiler/eval:Ptr", i64 } %t13, ptr %l14
  br label %bb2
bb2:
  %t14 = load { %"compiler/eval:Ptr", i64 }, ptr %l14
  store { %"compiler/eval:Ptr", i64 } %t14, ptr %l5
  %t15 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l5, i32 0, i32 0
  %t16 = load %"compiler/eval:Ptr", ptr %t15
  store %"compiler/eval:Ptr" %t16, ptr %l6
  %t18 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l5, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l7, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/eval:Machine", ptr %t21, i32 0, i32 23
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t27 = load i32, ptr %l4, !tbaa !23
  %t29 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t26, 0
  %t31 = insertvalue { %"compiler/eval:Ptr", i32 } %t29, i32 %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i32 } %t31, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  br i1 %t35, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb8
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp sge i64 %t37, %t38
  store i1 %t41, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyOutside, !tbaa !27
  %t46 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t46, ptr %t44, { i64, ptr } %t45)
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t49 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t50 = load i32, ptr %l4, !tbaa !23
  %t52 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t49, 0
  %t54 = insertvalue { %"compiler/eval:Ptr", i32 } %t52, i32 %t50, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i32 } %t54, ptr %rv
  br label %ret
bb12:
  %t56 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !24
  store i64 %t57, ptr %l33, !tbaa !24
  %t58 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  store i64 %t59, ptr %l34, !tbaa !24
  %t60 = load i64, ptr %l3, !tbaa !24
  store i64 %t60, ptr %l35, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l4, !tbaa !23
  %t65 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t61, i32 %t62)
  store i64 %t65, ptr %l38
  br label %bb13
bb13:
  %t66 = load i64, ptr %l35, !tbaa !24
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = mul i64 %t66, %t67
  %t69 = load i64, ptr %l34, !tbaa !24
  %t71 = add i64 %t69, %t68
  %t72 = load i64, ptr %l33, !tbaa !24
  %t74 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t72, i64 %t71)
  store %"compiler/eval:Ptr" %t74, ptr %l41
  br label %bb14
bb14:
  %t75 = load i32, ptr %l4, !tbaa !23
  %t76 = load %"compiler/eval:Ptr", ptr %l41
  %t77 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t76, 0
  %t79 = insertvalue { %"compiler/eval:Ptr", i32 } %t77, i32 %t75, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i32 } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { %"compiler/eval:Ptr", i32 }, ptr %rv
  ret { %"compiler/eval:Ptr", i32 } %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eexit(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i32 %a4, { i64, [4 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { %"compiler/eval:Ptr", i64 }
  %l9 = alloca %"compiler/eval:Ptr"
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i1
  %l24 = alloca i1
  %l35 = alloca %"compiler/eval:Ptr"
  %l36 = alloca ptr
  %l37 = alloca %"compiler/eval:Ptr"
  %l41 = alloca i32
  %l42 = alloca { %"compiler/eval:Ptr", i64 }
  %l45 = alloca %"std/prelude/text:StringBuilder"
  %l50 = alloca i64
  %l53 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l77 = alloca %"compiler/eval:Ptr"
  %l78 = alloca i64
  %l85 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t145 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a4, ptr %l4
  store { i64, [4 x i64] } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !range !{i32 0, i32 2}
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i32, ptr %l4, !range !{i32 0, i32 20}
  %t11 = trunc i64 0 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb6
bb3:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb5
bb4:
  %t14 = load i32, ptr %l4, !range !{i32 0, i32 20}
  %t16 = trunc i64 1 to i32
  %t17 = icmp eq i32 %t14, %t16
  store i1 %t17, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l24, !tbaa !21
  store i1 %t19, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l21, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyEnds, !tbaa !27
  %t23 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t23, ptr %t21, { i64, ptr } %t22)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %ret
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t26 = load { i64, [4 x i64] }, ptr %l5
  %t28 = extractvalue { i64, [4 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 0
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l1, !tbaa !24
  %t35 = load { i64, [4 x i64] }, ptr %l5
  %t39 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t33, i64 %t34, { i64, [4 x i64] } %t35, i64 1)
  store %"compiler/eval:Ptr" %t39, ptr %l35
  br label %bb13
bb12:
  br label %bb33
bb13:
  %t40 = load %"compiler/eval:Ptr", ptr %l35
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l36, !tbaa !29
  store %"compiler/eval:Ptr" %t40, ptr %l37
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l1, !tbaa !24
  %t45 = load { i64, [4 x i64] }, ptr %l5
  %t49 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t43, i64 %t44, { i64, [4 x i64] } %t45)
  store i32 %t49, ptr %l41
  br label %bb14
bb14:
  %t50 = load ptr, ptr %l36, !tbaa !29
  %t51 = load %"compiler/eval:Ptr", ptr %l37
  %t52 = load i32, ptr %l41, !tbaa !23
  %t53 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t50, %"compiler/eval:Ptr" %t51, i32 %t52)
  store { %"compiler/eval:Ptr", i64 } %t53, ptr %l42
  br label %bb15
bb15:
  %t54 = load { %"compiler/eval:Ptr", i64 }, ptr %l42
  store { %"compiler/eval:Ptr", i64 } %t54, ptr %l8
  %t55 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 0
  %t56 = load %"compiler/eval:Ptr", ptr %t55
  store %"compiler/eval:Ptr" %t56, ptr %l9
  %t58 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  store i64 %t59, ptr %l10, !tbaa !24
  %t61 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t61, ptr %l45
  br label %bb16
bb16:
  %t62 = load %"std/prelude/text:StringBuilder", ptr %l45
  store %"std/prelude/text:StringBuilder" %t62, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  store i64 %t63, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t65 = load i64, ptr %l13, !tbaa !24
  %t66 = load i64, ptr %l12, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb17, label %bb18
bb17:
  %t71 = load i64, ptr %l14, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb22
bb19:
  %t75 = load i64, ptr %l13, !tbaa !24
  %t76 = load i64, ptr %l12, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l14, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l14, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l53, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb21
bb21:
  %t91 = load i64, ptr %l53, !tbaa !24
  store i64 %t91, ptr %l50, !tbaa !24
  br label %bb22
bb22:
  %t92 = load i64, ptr %l50, !tbaa !24
  store i64 %t92, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t93 = load i64, ptr %l16, !tbaa !24
  %t94 = load i64, ptr %l15, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t101 = load i64, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l16, !tbaa !24
  %t103 = load i64, ptr %l14, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store ptr %l11, ptr %l71, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l72, !tbaa !29
  %t112 = getelementptr %"compiler/eval:Ptr", ptr %l9, i32 0, i32 0
  %t113 = load i64, ptr %t112, !tbaa !24
  %t114 = getelementptr %"compiler/eval:Ptr", ptr %l9, i32 0, i32 1
  %t115 = load i64, ptr %t114, !tbaa !24
  %t119 = add i64 %t115, %t109
  %t122 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t113, i64 %t119)
  store %"compiler/eval:Ptr" %t122, ptr %l77
  br label %bb27
bb27:
  %t123 = load ptr, ptr %l72, !tbaa !29
  %t124 = load %"compiler/eval:Ptr", ptr %l77
  %t125 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t123, %"compiler/eval:Ptr" %t124, i64 1)
  store i64 %t125, ptr %l78
  br label %bb28
bb28:
  %t126 = load i64, ptr %l78, !tbaa !24
  %t127 = trunc i64 %t126 to i8
  %t129 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s2, ptr %t129, i8 %t127)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  %t131 = load i64, ptr %l16, !tbaa !24
  %t134 = add i64 %t131, 1
  store i64 %t134, ptr %l16, !tbaa !24
  br label %bb23
bb31:
  %t137 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %v0, ptr %l11)
  store { i64, ptr } %t137, ptr %l85
  br label %bb32
bb32:
  %t138 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t138, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l4, !range !{i32 0, i32 20}
  %t144 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t145
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 0
  store i64 2, ptr %t146
  %t148 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } undef, i32 %t141, 0
  %t150 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t148, i64 %a2, 1
  %t152 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t150, %"compiler/source:Span" %a3, 2
  %t154 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t152, { i64, ptr } %t144, 3
  %t155 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 1
  store { i32, i64, %"compiler/source:Span", { i64, ptr } } %t154, ptr %t155
  %t156 = load { i64, [5 x i64] }, ptr %t145
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estop(ptr %v0, ptr %v0, ptr %t140, { i64, [5 x i64] } %t156)
  br label %bb34
bb34:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2efailedHere(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, [8 x i64] }
  %l4 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca i32
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 27
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l9, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 59
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l11, !tbaa !27
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i64 %t9
  %t14 = getelementptr %"compiler/eval:frame", ptr %t13, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr %"compiler/eval:cfn", ptr %t18, i64 %t15
  %t20 = getelementptr %"compiler/eval:cfn", ptr %t19, i32 0, i32 9
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/eval:Machine", ptr %t22, i32 0, i32 59
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l16, !tbaa !27
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr %"compiler/eval:frame", ptr %t29, i64 %t26
  %t31 = getelementptr %"compiler/eval:frame", ptr %t30, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, [8 x i64] }, ptr %t35, i64 %t32
  %t37 = load { i64, [8 x i64] }, ptr %t36
  store { i64, [8 x i64] } %t37, ptr %l3
  %t39 = load { i64, [8 x i64] }, ptr %l3
  %t41 = extractvalue { i64, [8 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 4
  br i1 %t42, label %bb1, label %bb2
bb1:
  %t44 = getelementptr { i64, [8 x i64] }, ptr %l3, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32 }, ptr %t44, i32 0, i32 0
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l4
  br label %bb5
bb2:
  %t48 = load { i64, [8 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [8 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 8
  br i1 %t51, label %bb3, label %bb4
bb3:
  %t53 = getelementptr { i64, [8 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load %"compiler/source:Span", ptr %t54
  store %"compiler/source:Span" %t55, ptr %l4
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t57 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  store i32 %t58, ptr %l20, !tbaa !23
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 -1, ptr %l20, !tbaa !23
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_ae4c96370005e5a0_f3d2360ec3e473b4)
  unreachable
bb11:
  %t60 = load i32, ptr %l20, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/eval:Machine", ptr %t65, i32 0, i32 59
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l31, !tbaa !27
  %t69 = load i64, ptr %l1, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr %"compiler/eval:frame", ptr %t74, i64 %t69
  %t76 = getelementptr %"compiler/eval:frame", ptr %t75, i32 0, i32 16
  store i64 %a2, ptr %t76, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/eval:Machine", ptr %t77, i32 0, i32 59
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l35, !tbaa !27
  %t81 = load i64, ptr %l1, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr %"compiler/eval:frame", ptr %t86, i64 %t81
  %t88 = getelementptr %"compiler/eval:frame", ptr %t87, i32 0, i32 17
  store i32 %t60, ptr %t88, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiScalar(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l11
  br label %bb2
bb2:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t19 = load i32, ptr %l3, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t23 = icmp eq i32 %t19, %t20
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l12, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb14
bb7:
  br i1 %a2, label %bb8, label %bb9
bb8:
  %t28 = load i32, ptr %l3, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t32 = icmp eq i32 %t28, %t29
  br i1 %t32, label %bb10, label %bb11
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb13
bb10:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb12
bb11:
  %t34 = load i32, ptr %l3, !tbaa !23
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t38 = icmp eq i32 %t34, %t35
  store i1 %t38, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l22, !tbaa !21
  store i1 %t40, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t41 = load i1, ptr %l18, !tbaa !21
  store i1 %t41, ptr %l16, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l16, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t18 = load i32, ptr %l9, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l10
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load i32, ptr %l10, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t20, i32 %t21)
  store i64 %t22, ptr %l11
  br label %bb3
bb3:
  %t23 = load i64, ptr %l11, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatOperand(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [4 x i64] } %a2, ptr %a3, i64 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l22 = alloca i1
  %l28 = alloca i64
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l51 = alloca i64
  %l54 = alloca i1
  %l55 = alloca ptr
  %l59 = alloca %"compiler/mir:Local"
  %l61 = alloca i1
  %l65 = alloca ptr
  %l69 = alloca %"compiler/mir:Local"
  %l71 = alloca i64
  %l75 = alloca %"compiler/mir:Local"
  %l79 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i32, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l6, !tbaa !23
  %t10 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t11 = getelementptr { i32, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l7, !tbaa !24
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l6, !tbaa !23
  %t18 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l22
  br label %bb4
bb4:
  %t19 = load i1, ptr %l22, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  store i32 65536, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 -1, ptr %l8, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l6, !tbaa !23
  %t25 = load i64, ptr %l7, !tbaa !24
  %t29 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecanonBits(ptr %v0, ptr %t23, i32 %t24, i64 %t25)
  store i64 %t29, ptr %l28
  br label %bb8
bb8:
  %t30 = load i64, ptr %l28, !tbaa !24
  %t31 = load i32, ptr %l6, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/eval:cfn", ptr %t35, i32 0, i32 13
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l32, !tbaa !27
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i64, ptr %t44, i64 %t39
  store i64 %t40, ptr %t45, !tbaa !34
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/eval:cfn", ptr %t46, i32 0, i32 13
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l36, !tbaa !27
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = add i64 %t50, 1
  %t56 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i64, ptr %t57, i64 %t52
  store i64 %t30, ptr %t58, !tbaa !34
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = getelementptr %"compiler/eval:cfn", ptr %t59, i32 0, i32 13
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l41, !tbaa !27
  %t63 = load i64, ptr %l5, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i64, ptr %t68, i64 %t63
  store i64 %t33, ptr %t69, !tbaa !34
  br label %bb33
bb9:
  %t70 = load { i64, [4 x i64] }, ptr %l2
  %t72 = extractvalue { i64, [4 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 1
  br i1 %t73, label %bb10, label %bb11
bb10:
  %t75 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t76 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t75, i32 0, i32 0
  %t77 = load %"compiler/mir:Lvalue", ptr %t76
  store %"compiler/mir:Lvalue" %t77, ptr %l11
  br label %bb12
bb11:
  br label %bb28
bb12:
  %t79 = getelementptr %"compiler/mir:Lvalue", ptr %l11, i32 0, i32 1
  %t80 = getelementptr %"compiler/mir:Range", ptr %t79, i32 0, i32 1
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = icmp ne i32 %t81, 0
  br i1 %t83, label %bb13, label %bb14
bb13:
  store i32 65536, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t86 = load %"compiler/mir:Lvalue", ptr %l11
  %t88 = call i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %t86)
  store i64 %t88, ptr %l51
  br label %bb16
bb16:
  %t89 = load i64, ptr %l51, !tbaa !24
  store i64 %t89, ptr %l12, !tbaa !24
  %t90 = load i64, ptr %l12, !tbaa !24
  %t92 = icmp slt i64 %t90, 0
  br i1 %t92, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb21
bb18:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l55, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/mir:Fn", ptr %t95, i32 0, i32 7
  %t98 = load i64, ptr %l12, !tbaa !24
  %t101 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t97, i64 %t98)
  store %"compiler/mir:Local" %t101, ptr %l59
  br label %bb19
bb19:
  %t102 = getelementptr %"compiler/mir:Local", ptr %l59, i32 0, i32 2
  %t103 = load i32, ptr %t102, !tbaa !23
  %t104 = load ptr, ptr %l55, !tbaa !29
  %t106 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t104, i32 %t103)
  store i1 %t106, ptr %l61
  br label %bb20
bb20:
  %t107 = load i1, ptr %l61, !tbaa !21
  %t108 = xor i1 %t107, true
  store i1 %t108, ptr %l54, !tbaa !21
  br label %bb21
bb21:
  %t110 = load i1, ptr %l54, !tbaa !21
  br i1 %t110, label %bb22, label %bb23
bb22:
  store i32 65536, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t112 = load i64, ptr %l12, !tbaa !24
  store i64 %t112, ptr %l13, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l65, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/mir:Fn", ptr %t115, i32 0, i32 7
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t117, i64 %t118)
  store %"compiler/mir:Local" %t121, ptr %l69
  br label %bb25
bb25:
  %t122 = getelementptr %"compiler/mir:Local", ptr %l69, i32 0, i32 2
  %t123 = load i32, ptr %t122, !tbaa !23
  %t124 = load ptr, ptr %l65, !tbaa !29
  %t126 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t124, i32 %t123)
  store i64 %t126, ptr %l71
  br label %bb26
bb26:
  %t127 = load i64, ptr %l71, !tbaa !24
  store i64 %t127, ptr %l14, !tbaa !24
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr %"compiler/mir:Fn", ptr %t128, i32 0, i32 7
  %t131 = load i64, ptr %l12, !tbaa !24
  %t134 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t130, i64 %t131)
  store %"compiler/mir:Local" %t134, ptr %l75
  br label %bb27
bb27:
  %t135 = getelementptr %"compiler/mir:Local", ptr %l75, i32 0, i32 2
  %t136 = load i32, ptr %t135, !tbaa !23
  %t138 = sext i32 %t136 to i64
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t142 = getelementptr %"compiler/eval:cfn", ptr %t140, i32 0, i32 13
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l79, !tbaa !27
  %t144 = load i64, ptr %l4, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i64, ptr %t149, i64 %t144
  store i64 %t145, ptr %t150, !tbaa !34
  %t151 = load ptr, ptr %l3, !tbaa !29
  %t153 = getelementptr %"compiler/eval:cfn", ptr %t151, i32 0, i32 13
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  store { i64, ptr } %t154, ptr %l83, !tbaa !27
  %t155 = load i64, ptr %l4, !tbaa !24
  %t157 = add i64 %t155, 1
  %t158 = load i64, ptr %l14, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i64, ptr %t162, i64 %t157
  store i64 %t158, ptr %t163, !tbaa !34
  %t164 = load ptr, ptr %l3, !tbaa !29
  %t166 = getelementptr %"compiler/eval:cfn", ptr %t164, i32 0, i32 13
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  store { i64, ptr } %t167, ptr %l88, !tbaa !27
  %t168 = load i64, ptr %l5, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i64, ptr %t173, i64 %t168
  store i64 %t138, ptr %t174, !tbaa !34
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 65536, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e07540d555d7dc03_f134256d7232b767)
  unreachable
bb33:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca { ptr, ptr }
  %l4 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 31
  %t4 = load { i64, [2 x i64] }, ptr %l1
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t3, { i64, [2 x i64] } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 4
  %t23 = load { ptr, ptr }, ptr %t22
  store { ptr, ptr } %t23, ptr %l3
  %t25 = load { ptr, ptr }, ptr %l3
  %t27 = extractvalue { ptr, ptr } %t25, 0
  %t28 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t29 = icmp eq ptr %t27, %t28
  %t30 = extractvalue { ptr, ptr } %t25, 1
  %t31 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t32 = icmp eq ptr %t30, %t31
  %t33 = and i1 %t29, %t32
  br i1 %t33, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t35 = load { ptr, ptr }, ptr %l3
  %t36 = load { i64, [2 x i64] }, ptr %l1
  %t38 = extractvalue { ptr, ptr } %t35, 0
  %t39 = extractvalue { ptr, ptr } %t35, 1
  %t41 = call i1 %t38(ptr %t39, { i64, [2 x i64] } %t36)
  store i1 %t41, ptr %l20
  br label %bb10
bb10:
  %t42 = load i1, ptr %l20, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l17, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i64 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t47, i32 0, i32 31
  %t50 = load { i64, [2 x i64] }, ptr %l1
  %t53 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t49, { i64, [2 x i64] } %t50)
  %t54 = extractvalue { i32, i64 } %t53, 1
  %t55 = extractvalue { i32, i64 } %t53, 0
  store i32 %t55, ptr %l28
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb16, label %ok.57, !prof !99
ok.57:
  store i64 %t54, ptr %l27
  br label %bb15
bb15:
  %t58 = load i64, ptr %l27, !tbaa !24
  store i64 %t58, ptr %l23, !tbaa !24
  br label %bb18
bb16:
  br label %bb17
bb17:
  store i64 -1, ptr %l23, !tbaa !24
  br label %bb18
bb18:
  %t59 = load i64, ptr %l23, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l8 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 26
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 59
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:frame", ptr %t11, i64 %a1
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v1, ptr %t3, i64 %t14)
  store ptr %t17, ptr %l8
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l8, !tbaa !29
  store ptr %t18, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreeTask(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 58
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t3, i64 %a1)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreedEarly(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 78
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 79
  %t8 = getelementptr %"compiler/source:Span", ptr %t7, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t10 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFreedEarly, !tbaa !27
  %t11 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %t4)
  %t15 = add i64 %t12, %t14
  %t16 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = sext i32 %t9 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %t10, 1
  %t28 = extractvalue { i64, ptr } %t10, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t11, i64 %t12)
  %t34 = getelementptr i8, ptr %t33, i64 %t12
  %t35 = call i64 @__olang_fmt_i64(ptr %t34, i64 %t4)
  %t36 = getelementptr i8, ptr %t34, i64 %t14
  call void @olang_textcopy(ptr %t36, ptr %t16, i64 %t17)
  %t37 = getelementptr i8, ptr %t36, i64 %t17
  %t38 = call i64 @__olang_fmt_i64(ptr %t37, i64 %t20)
  %t39 = getelementptr i8, ptr %t37, i64 %t21
  call void @olang_textcopy(ptr %t39, ptr %t23, i64 %t24)
  %t40 = getelementptr i8, ptr %t39, i64 %t24
  call void @olang_textcopy(ptr %t40, ptr %t27, i64 %t28)
  %t41 = getelementptr i8, ptr %t40, i64 %t28
  call void @olang_textcopy(ptr %t41, ptr %t30, i64 %t31)
  %t42 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t33, 1
  %t45 = call i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t43)
  store i32 %t45, ptr %l7
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb2, label %ok.47, !prof !99
ok.47:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t48 = load i32, ptr %l7, !tbaa !23
  %t49 = ashr i32 %t48, 16
  %t51 = icmp eq i32 %t49, 1
  store i1 %t51, ptr %l9, !tbaa !21
  %t52 = load i32, ptr %l7, !tbaa !23
  %t53 = ashr i32 %t52, 16
  %t55 = icmp eq i32 %t53, 1
  br i1 %t55, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  call void @std_2fos_2eExit(i32 70)
  unreachable
bb7:
  call void @__olang_check_failed(ptr @olang_loc_c25616630356082_96e485ee4d1c8d36)
  unreachable
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efromF64(ptr %v0, ptr %a0, double %a1, i32 %a2) #0 {
entry:
  %l1 = alloca double
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %rv = alloca i64
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a2)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load i32, ptr %l3, !tbaa !23
  %t12 = icmp eq i32 %t10, 11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load double, ptr %l1, !tbaa !26
  %t16 = fptrunc double %t14 to half
  %t18 = bitcast half %t16 to i16
  %t19 = call i16 asm "", "=r,0"(i16 %t18)
  %t21 = zext i16 %t19 to i64
  store i64 %t21, ptr %l8, !tbaa !24
  br label %bb18
bb5:
  %t23 = load i32, ptr %l3, !tbaa !23
  %t25 = icmp eq i32 %t23, 12
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t27 = load double, ptr %l1, !tbaa !26
  %t29 = fptrunc double %t27 to bfloat
  %t31 = bitcast bfloat %t29 to i16
  %t32 = call i16 asm "", "=r,0"(i16 %t31)
  %t34 = zext i16 %t32 to i64
  store i64 %t34, ptr %l8, !tbaa !24
  br label %bb18
bb9:
  %t36 = load i32, ptr %l3, !tbaa !23
  %t38 = icmp eq i32 %t36, 13
  br i1 %t38, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t40 = load double, ptr %l1, !tbaa !26
  %t42 = fptrunc double %t40 to float
  %t44 = bitcast float %t42 to i32
  %t46 = zext i32 %t44 to i64
  store i64 %t46, ptr %l8, !tbaa !24
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t48 = load double, ptr %l1, !tbaa !26
  %t50 = bitcast double %t48 to i64
  store i64 %t50, ptr %l8, !tbaa !24
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_463be9bfcfc802eb_383f1498b2d4337)
  unreachable
bb18:
  %t53 = load i64, ptr %l8, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2egenHeld(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1) #0 {
entry:
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca ptr
  %l6 = alloca %"compiler/eval:Ptr"
  %l7 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l2, !tbaa !29
  %t2 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = sub i64 %t5, 8
  %t10 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t3, i64 %t7)
  store %"compiler/eval:Ptr" %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load %"compiler/eval:Ptr", ptr %l6
  %t13 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t11, %"compiler/eval:Ptr" %t12, i64 8)
  store i64 %t13, ptr %l7
  br label %bb2
bb2:
  %t14 = load i64, ptr %l7, !tbaa !24
  %t15 = ashr i64 %t14, 16
  %t17 = and i64 %t15, 3
  call void @__olang_scope_close(ptr %s0)
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2egenLive(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i1
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t6 = and i64 %t2, %t3
  store i64 %t6, ptr %l2, !tbaa !24
  %t8 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp ne i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 51
  %t17 = load i64, ptr %t16, !tbaa !24
  %t20 = icmp slt i64 %t13, %t17
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t22 = load i1, ptr %l8, !tbaa !21
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 50
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l15, !tbaa !27
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr %"compiler/eval:alloc", ptr %t30, i64 %t27
  %t32 = getelementptr %"compiler/eval:alloc", ptr %t31, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t37 = icmp ne i64 %t33, %t34
  store i1 %t37, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t39 = load i1, ptr %l13, !tbaa !21
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/eval:Machine", ptr %t40, i32 0, i32 50
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l22, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr %"compiler/eval:alloc", ptr %t47, i64 %t44
  %t49 = getelementptr %"compiler/eval:alloc", ptr %t48, i32 0, i32 3
  %t50 = load i64, ptr %t49, !tbaa !24
  %t51 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t53, ptr %l26, !tbaa !24
  %t55 = load i64, ptr %l26, !tbaa !24
  %t56 = load i64, ptr %l26, !tbaa !24
  %t57 = ashr i64 %t52, %t56
  %t60 = icmp eq i64 %t50, %t57
  store i1 %t60, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t62 = load i1, ptr %l20, !tbaa !21
  store i1 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eheldScope(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca %"compiler/eval:Ptr"
  %l9 = alloca i64
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l4, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t9 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t3, i64 %a1, i32 %a2)
  store %"compiler/eval:Ptr" %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load %"compiler/eval:Ptr", ptr %l8
  %t12 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t10, %"compiler/eval:Ptr" %t11, i64 8)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i64, ptr %l9, !tbaa !24
  %t17 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t14, i64 %t15, i32 %t13)
  store i64 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i64, ptr %l11, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l10
  br label %bb2
bb2:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t26 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t22, i32 %t23)
  store i64 %t26, ptr %l15
  br label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t27, i32 %t28)
  store i64 %t31, ptr %l18
  br label %bb6
bb5:
  %t32 = load i64, ptr %l15, !tbaa !24
  store i64 %t32, ptr %l11, !tbaa !24
  br label %bb7
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  %t34 = mul i64 8, %t33
  store i64 %t34, ptr %l11, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l11, !tbaa !24
  store i64 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i1
  %l23 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 64
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = call i64 @compiler_2feval_2ebmask(i64 %t14)
  store i64 %t16, ptr %l13
  br label %bb5
bb5:
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = load i64, ptr %l13, !tbaa !24
  %t19 = and i64 %t17, %t18
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l17
  br label %bb6
bb6:
  %t26 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t27 = load i64, ptr %l17, !tbaa !24
  %t29 = icmp eq i64 %t27, %t26
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t32, 1
  store i64 %t34, ptr %l23, !tbaa !24
  %t36 = load i64, ptr %l23, !tbaa !24
  %t37 = load i64, ptr %l23, !tbaa !24
  %t38 = ashr i64 %t31, %t37
  %t40 = and i64 %t38, 1
  %t42 = icmp eq i64 %t40, 1
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t44 = load i1, ptr %l20, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t45 = load i64, ptr %l4, !tbaa !24
  store i64 %t45, ptr %l27, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = call i64 @compiler_2feval_2ebmask(i64 %t46)
  store i64 %t48, ptr %l29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t49 = load i64, ptr %l29, !tbaa !24
  %t50 = xor i64 %t49, -1
  %t51 = load i64, ptr %l27, !tbaa !24
  %t53 = or i64 %t51, %t50
  store i64 %t53, ptr %rv
  br label %ret
bb13:
  %t55 = load i64, ptr %l4, !tbaa !24
  store i64 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l5 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l14 = alloca i64
  %l16 = alloca i1
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l28 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 59
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load i32, ptr %l2, !tbaa !23
  %t8 = sext i32 %t6 to i64
  %t11 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i64 %t5
  %t14 = getelementptr %"compiler/eval:frame", ptr %t13, i32 0, i32 1
  store i64 %t8, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:Machine", ptr %t15, i32 0, i32 59
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l10, !tbaa !27
  %t19 = load i64, ptr %l1, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/eval:frame", ptr %t22, i64 %t19
  %t24 = getelementptr %"compiler/eval:frame", ptr %t23, i32 0, i32 2
  store i64 0, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 89
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l14
  br label %bb1
bb1:
  %t30 = load i64, ptr %l14, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  br i1 %t31, label %bb2, label %bb3
bb2:
  %t33 = load i32, ptr %l2, !tbaa !23
  store i32 %t33, ptr %l3, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/eval:Machine", ptr %t35, i32 0, i32 26
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 59
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr %"compiler/eval:frame", ptr %t45, i64 %t42
  %t47 = getelementptr %"compiler/eval:frame", ptr %t46, i32 0, i32 0
  %t48 = load i64, ptr %t47, !tbaa !24
  %t51 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t37, i64 %t48)
  store ptr %t51, ptr %l24
  br label %bb4
bb3:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb6
bb4:
  %t52 = load ptr, ptr %l24, !tbaa !29
  %t54 = getelementptr %"compiler/mir:Fn", ptr %t52, i32 0, i32 22
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eHas_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t54, i32 %t55)
  store i1 %t58, ptr %l28
  br label %bb5
bb5:
  %t59 = load i1, ptr %l28, !tbaa !21
  store i1 %t59, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t60 = load i1, ptr %l16, !tbaa !21
  br i1 %t60, label %bb7, label %bb8
bb7:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/eval:Machine", ptr %t61, i32 0, i32 89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t63)
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/eval:Machine", ptr %t65, i32 0, i32 91
  store i64 0, ptr %t67, !tbaa !24
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l27 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca i32
  %l36 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l49 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i32
  %l62 = alloca i64
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load i64, ptr %l13, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  %t16 = icmp eq i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr @G_2ecompiler_2ftypes_2eNotLaidOut, !tbaa !24
  %t23 = icmp ne i64 %t19, %t20
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t28 = load i64, ptr @G_2ecompiler_2ftypes_2eLayingOut, !tbaa !24
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetLayoutState(ptr %v0, ptr %t26, i32 %t27, i64 %t28)
  br label %bb8
bb8:
  store i1 true, ptr %l4, !tbaa !21
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l27
  br label %bb9
bb9:
  %t37 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t39 = trunc i64 20 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l30, !tbaa !29
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t44 = load i32, ptr %l1, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l33
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t48 = load ptr, ptr %l30, !tbaa !29
  %t49 = load i32, ptr %l33, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2elayRepr(ptr %v0, ptr %t48, i32 %t49)
  br label %bb13
bb13:
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %s4, ptr %t50, i32 %t51)
  store { i64, ptr } %t54, ptr %l36
  br label %bb15
bb15:
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t55, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l7, !tbaa !24
  br label %bb16
bb16:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t69 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t69, ptr %l44, !tbaa !27
  %t70 = load i64, ptr %l6, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 %t70
  %t75 = load i32, ptr %t74, !tbaa !33
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %t77, i32 %t75)
  store i1 %t81, ptr %l49
  br label %bb20
bb20:
  %t82 = load i1, ptr %l49, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb21, label %bb22
bb21:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t85 = load i64, ptr %l6, !tbaa !24
  %t88 = add i64 %t85, 1
  store i64 %t88, ptr %l6, !tbaa !24
  br label %bb16
bb25:
  call void @__olang_scope_close(ptr %s4)
  %t90 = load i1, ptr %l4, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t93 = load i32, ptr %l1, !tbaa !23
  %t96 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %t92, i32 %t93)
  store i1 %t96, ptr %l58
  br label %bb28
bb27:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb29
bb28:
  %t97 = load i1, ptr %l58, !tbaa !21
  store i1 %t97, ptr %l55, !tbaa !21
  br label %bb29
bb29:
  %t98 = load i1, ptr %l55, !tbaa !21
  store i1 %t98, ptr %l4, !tbaa !21
  %t99 = load ptr, ptr %l2, !tbaa !29
  store ptr %t99, ptr %l59, !tbaa !29
  %t100 = load i32, ptr %l1, !tbaa !23
  store i32 %t100, ptr %l60, !tbaa !23
  %t101 = load i1, ptr %l4, !tbaa !21
  br i1 %t101, label %bb30, label %bb31
bb30:
  %t103 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  store i64 %t103, ptr %l62, !tbaa !24
  br label %bb32
bb31:
  %t105 = load i64, ptr @G_2ecompiler_2ftypes_2eNoLayout, !tbaa !24
  store i64 %t105, ptr %l62, !tbaa !24
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l59, !tbaa !29
  %t108 = load i32, ptr %l60, !tbaa !23
  %t109 = load i64, ptr %l62, !tbaa !24
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetLayoutState(ptr %v0, ptr %t107, i32 %t108, i64 %t109)
  br label %bb33
bb33:
  %t110 = load i1, ptr %l4, !tbaa !21
  store i1 %t110, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2elayRepr(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t11, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb4:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb5
bb5:
  %t26 = load i32, ptr %l16, !range !{i32 0, i32 6}
  %t28 = trunc i64 4 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l11, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i1, ptr %l22, !tbaa !21
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l25
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l18 = alloca %"compiler/eval:scope"
  %l20 = alloca i1
  %l24 = alloca %"compiler/eval:scope"
  %l27 = alloca i64
  %rv = alloca i1
  %t26 = alloca %"compiler/eval:scope", align 8
  %t37 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t5 = and i64 %t1, %t2
  store i64 %t5, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp ne i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t12, i32 0, i32 53
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eLen_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l12
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l8, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/eval:Machine", ptr %t22, i32 0, i32 53
  %t25 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t26, ptr %v0, ptr %t24, i64 %t25)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t26, i64 152, i1 false)
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t29 = getelementptr %"compiler/eval:scope", ptr %l18, i32 0, i32 1
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l14, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t33, i32 0, i32 53
  %t36 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t37, ptr %v0, ptr %t35, i64 %t36)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t37, i64 152, i1 false)
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t40 = getelementptr %"compiler/eval:scope", ptr %l24, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr %l1, !tbaa !24
  %t43 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t43, ptr %l27, !tbaa !24
  %t45 = load i64, ptr %l27, !tbaa !24
  %t46 = load i64, ptr %l27, !tbaa !24
  %t47 = ashr i64 %t42, %t46
  %t50 = icmp eq i64 %t41, %t47
  store i1 %t50, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l20, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/eval:alloc"
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l27 = alloca i1
  %l32 = alloca ptr
  %l34 = alloca %"compiler/eval:Ptr"
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %l45 = alloca i1
  %l48 = alloca i64
  %l51 = alloca i1
  %l55 = alloca ptr
  %l57 = alloca %"compiler/eval:Ptr"
  %l60 = alloca i64
  %l62 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i1
  %l80 = alloca %"compiler/eval:global"
  %l83 = alloca ptr
  %l85 = alloca %"compiler/eval:Ptr"
  %l88 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 61
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l9, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 59
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l11, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i64 %a1
  %t14 = getelementptr %"compiler/eval:frame", ptr %t13, i32 0, i32 3
  %t15 = load i64, ptr %t14, !tbaa !24
  %t19 = add i64 %t15, %a2
  %t21 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i64, ptr %t22, i64 %t19
  %t24 = load i64, ptr %t23, !tbaa !34
  store i64 %t24, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp eq i64 %t26, 0
  br i1 %t28, label %bb1, label %bb2
bb1:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  %t32 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t32, ptr %t30, { i64, ptr } %t31)
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i64 -1, ptr %rv
  br label %ret
bb4:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t40 = and i64 %t36, %t37
  store i64 %t40, ptr %l6, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 23
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb7
bb6:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/eval:Machine", ptr %t48, i32 0, i32 51
  %t51 = load i64, ptr %t50, !tbaa !24
  %t54 = icmp sge i64 %t47, %t51
  store i1 %t54, ptr %l27, !tbaa !21
  br label %bb7
bb7:
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t58, i64 0)
  store %"compiler/eval:Ptr" %t60, ptr %l34
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i1, ptr %l4, !tbaa !21
  %t63 = load ptr, ptr %l32, !tbaa !29
  %t64 = load %"compiler/eval:Ptr", ptr %l34
  %t67 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t63, %"compiler/eval:Ptr" %t64, i64 %t61, i1 %t62)
  store i64 %t67, ptr %l37
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  %t68 = load i64, ptr %l37, !tbaa !24
  store i64 %t68, ptr %rv
  br label %ret
bb12:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/eval:Machine", ptr %t69, i32 0, i32 50
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l39, !tbaa !27
  %t73 = load i64, ptr %l6, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"compiler/eval:alloc", ptr %t76, i64 %t73
  %t78 = load %"compiler/eval:alloc", ptr %t77
  store %"compiler/eval:alloc" %t78, ptr %l7
  %t80 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 4
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t85 = icmp eq i64 %t81, %t82
  br i1 %t85, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb15
bb14:
  %t87 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load i64, ptr %l5, !tbaa !24
  %t90 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t90, ptr %l48, !tbaa !24
  %t92 = load i64, ptr %l48, !tbaa !24
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = ashr i64 %t89, %t93
  %t97 = icmp ne i64 %t88, %t94
  store i1 %t97, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t99 = load i1, ptr %l45, !tbaa !21
  br i1 %t99, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb18
bb17:
  %t100 = load i64, ptr %l3, !tbaa !24
  %t101 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 1
  %t102 = load i64, ptr %t101, !tbaa !24
  %t105 = icmp sgt i64 %t100, %t102
  store i1 %t105, ptr %l51, !tbaa !21
  br label %bb18
bb18:
  %t107 = load i1, ptr %l51, !tbaa !21
  br i1 %t107, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l55, !tbaa !29
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t109, i64 0)
  store %"compiler/eval:Ptr" %t111, ptr %l57
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t113 = load i1, ptr %l4, !tbaa !21
  %t114 = load ptr, ptr %l55, !tbaa !29
  %t115 = load %"compiler/eval:Ptr", ptr %l57
  %t118 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t114, %"compiler/eval:Ptr" %t115, i64 %t112, i1 %t113)
  store i64 %t118, ptr %l60
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  %t119 = load i64, ptr %l60, !tbaa !24
  store i64 %t119, ptr %rv
  br label %ret
bb23:
  %t120 = load i1, ptr %l4, !tbaa !21
  br i1 %t120, label %bb24, label %bb25
bb24:
  %t122 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 13
  %t123 = load i1, ptr %t122, !tbaa !21
  br i1 %t123, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb39
bb26:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb38
bb27:
  %t125 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 8
  %t126 = load i64, ptr %t125, !tbaa !24
  %t128 = icmp sge i64 %t126, 0
  br i1 %t128, label %bb28, label %bb29
bb28:
  %t130 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 8
  %t131 = load i64, ptr %t130, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/eval:Machine", ptr %t132, i32 0, i32 74
  %t135 = load i64, ptr %t134, !tbaa !24
  %t138 = icmp ne i64 %t131, %t135
  store i1 %t138, ptr %l67, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb30
bb30:
  %t140 = load i1, ptr %l67, !tbaa !21
  br i1 %t140, label %bb31, label %bb32
bb31:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/eval:Machine", ptr %t141, i32 0, i32 1
  %t144 = load i32, ptr %t143, !range !{i32 0, i32 2}
  %t146 = trunc i64 0 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb33, label %bb34
bb32:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb37
bb33:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb36
bb34:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/eval:Machine", ptr %t149, i32 0, i32 43
  %t152 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 8
  %t153 = load i64, ptr %t152, !tbaa !24
  %t156 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t151, i64 %t153)
  store %"compiler/eval:global" %t156, ptr %l80
  br label %bb35
bb35:
  %t157 = getelementptr %"compiler/eval:global", ptr %l80, i32 0, i32 1
  %t158 = load i1, ptr %t157, !tbaa !21
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l76, !tbaa !21
  br label %bb36
bb36:
  %t162 = load i1, ptr %l76, !tbaa !21
  store i1 %t162, ptr %l72, !tbaa !21
  br label %bb37
bb37:
  %t163 = load i1, ptr %l72, !tbaa !21
  store i1 %t163, ptr %l64, !tbaa !21
  br label %bb38
bb38:
  %t164 = load i1, ptr %l64, !tbaa !21
  store i1 %t164, ptr %l62, !tbaa !21
  br label %bb39
bb39:
  %t165 = load i1, ptr %l62, !tbaa !21
  br i1 %t165, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l83, !tbaa !29
  %t167 = load i64, ptr %l5, !tbaa !24
  %t169 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t167, i64 0)
  store %"compiler/eval:Ptr" %t169, ptr %l85
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t170 = load i64, ptr %l3, !tbaa !24
  %t171 = load i1, ptr %l4, !tbaa !21
  %t172 = load ptr, ptr %l83, !tbaa !29
  %t173 = load %"compiler/eval:Ptr", ptr %l85
  %t176 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t172, %"compiler/eval:Ptr" %t173, i64 %t170, i1 %t171)
  store i64 %t176, ptr %l88
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  %t177 = load i64, ptr %l88, !tbaa !24
  store i64 %t177, ptr %rv
  br label %ret
bb44:
  %t178 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 0
  %t179 = load i64, ptr %t178, !tbaa !24
  store i64 %t179, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l20 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 61
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 59
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i64 %a1
  %t14 = getelementptr %"compiler/eval:frame", ptr %t13, i32 0, i32 3
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = sext i32 %a2 to i64
  %t21 = add i64 %t15, %t18
  %t23 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i64, ptr %t24, i64 %t21
  %t26 = load i64, ptr %t25, !tbaa !34
  store i64 %t26, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp eq i64 %t28, 0
  br i1 %t30, label %bb1, label %bb2
bb1:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  %t34 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t34, ptr %t32, { i64, ptr } %t33)
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t37 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/eval:Ptr" %t37, ptr %rv
  br label %ret
bb4:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t39, i64 0)
  store %"compiler/eval:Ptr" %t41, ptr %l20
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load %"compiler/eval:Ptr", ptr %l20
  store %"compiler/eval:Ptr" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l12 = alloca i1
  %l17 = alloca ptr
  %l24 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l38 = alloca i64
  %l40 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l110 = alloca i1
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca i64
  %l147 = alloca i1
  %l148 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l161 = alloca i1
  %l167 = alloca i1
  %l169 = alloca i1
  %l180 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 60
  %t4 = load i64, ptr %t3, !tbaa !24
  %t8 = icmp sgt i64 %t4, %a1
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 23
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l12, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %bb65
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t21, i32 0, i32 15
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = add i64 %t23, 1
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 15
  store i64 %t26, ptr %t29, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 2
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = icmp sge i64 %t33, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/eval:Machine", ptr %t37, i32 0, i32 15
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/eval:Machine", ptr %t41, i32 0, i32 2
  %t44 = load i64, ptr %t43, !tbaa !24
  %t47 = icmp sgt i64 %t40, %t44
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb10
bb10:
  %t49 = load i1, ptr %l24, !tbaa !21
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoverBudget(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l32
  br label %bb13
bb12:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  %t53 = load i1, ptr %l32, !tbaa !21
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/eval:Machine", ptr %t55, i32 0, i32 60
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = sub i64 %t58, 1
  store i64 %t60, ptr %l2, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/eval:Machine", ptr %t62, i32 0, i32 63
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l38
  br label %bb18
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/eval:Machine", ptr %t67, i32 0, i32 59
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l40, !tbaa !27
  %t71 = load i64, ptr %l2, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr %"compiler/eval:frame", ptr %t74, i64 %t71
  %t76 = getelementptr %"compiler/eval:frame", ptr %t75, i32 0, i32 9
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = load i64, ptr %l38, !tbaa !24
  %t80 = icmp sgt i64 %t78, %t77
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t82 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estepClose(ptr %v0, ptr %t82)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb64
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/eval:Machine", ptr %t84, i32 0, i32 59
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l46, !tbaa !27
  %t88 = load i64, ptr %l2, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr %"compiler/eval:frame", ptr %t91, i64 %t88
  %t93 = getelementptr %"compiler/eval:frame", ptr %t92, i32 0, i32 0
  %t94 = load i64, ptr %t93, !tbaa !24
  store i64 %t94, ptr %l3, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/eval:Machine", ptr %t96, i32 0, i32 59
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l50, !tbaa !27
  %t100 = load i64, ptr %l2, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr %"compiler/eval:frame", ptr %t103, i64 %t100
  %t105 = getelementptr %"compiler/eval:frame", ptr %t104, i32 0, i32 1
  %t106 = load i64, ptr %t105, !tbaa !24
  store i64 %t106, ptr %l4, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/eval:Machine", ptr %t108, i32 0, i32 27
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l54, !tbaa !27
  %t112 = load i64, ptr %l3, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr %"compiler/eval:cfn", ptr %t115, i64 %t112
  %t117 = getelementptr %"compiler/eval:cfn", ptr %t116, i32 0, i32 8
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l56, !tbaa !27
  %t119 = load i64, ptr %l4, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i64, ptr %t122, i64 %t119
  %t124 = load i64, ptr %t123, !tbaa !34
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/eval:Machine", ptr %t125, i32 0, i32 59
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l60, !tbaa !27
  %t129 = load i64, ptr %l2, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/eval:frame", ptr %t132, i64 %t129
  %t134 = getelementptr %"compiler/eval:frame", ptr %t133, i32 0, i32 2
  %t135 = load i64, ptr %t134, !tbaa !24
  %t138 = add i64 %t124, %t135
  store i64 %t138, ptr %l5, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/eval:Machine", ptr %t140, i32 0, i32 59
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l65, !tbaa !27
  %t144 = load i64, ptr %l2, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr %"compiler/eval:frame", ptr %t147, i64 %t144
  %t149 = getelementptr %"compiler/eval:frame", ptr %t148, i32 0, i32 10
  %t150 = load i1, ptr %t149, !tbaa !21
  br i1 %t150, label %bb23, label %bb24
bb23:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/eval:Machine", ptr %t152, i32 0, i32 59
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l69, !tbaa !27
  %t156 = load i64, ptr %l2, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr %"compiler/eval:frame", ptr %t159, i64 %t156
  %t161 = getelementptr %"compiler/eval:frame", ptr %t160, i32 0, i32 10
  store i1 false, ptr %t161, !tbaa !21
  %t162 = load i64, ptr %l5, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/eval:Machine", ptr %t163, i32 0, i32 27
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l73, !tbaa !27
  %t167 = load i64, ptr %l3, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr %"compiler/eval:cfn", ptr %t170, i64 %t167
  %t172 = getelementptr %"compiler/eval:cfn", ptr %t171, i32 0, i32 8
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l75, !tbaa !27
  %t174 = load i64, ptr %l4, !tbaa !24
  %t176 = add i64 %t174, 1
  %t178 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i64, ptr %t179, i64 %t176
  %t181 = load i64, ptr %t180, !tbaa !34
  %t184 = icmp slt i64 %t162, %t181
  br i1 %t184, label %bb25, label %bb26
bb24:
  br label %bb29
bb25:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/eval:Machine", ptr %t186, i32 0, i32 59
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  store { i64, ptr } %t189, ptr %l81, !tbaa !27
  %t190 = load i64, ptr %l2, !tbaa !24
  store i64 %t190, ptr %l82, !tbaa !24
  %t191 = load i64, ptr %l82, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr %"compiler/eval:frame", ptr %t193, i64 %t191
  %t195 = getelementptr %"compiler/eval:frame", ptr %t194, i32 0, i32 2
  %t196 = load i64, ptr %t195, !tbaa !24
  %t199 = add i64 %t196, 1
  %t201 = load i64, ptr %l82, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr %"compiler/eval:frame", ptr %t203, i64 %t201
  %t205 = getelementptr %"compiler/eval:frame", ptr %t204, i32 0, i32 2
  store i64 %t199, ptr %t205, !tbaa !24
  br label %bb28
bb26:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i64, ptr %l2, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/eval:Machine", ptr %t208, i32 0, i32 27
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  store { i64, ptr } %t211, ptr %l89, !tbaa !27
  %t212 = load i64, ptr %l3, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr %"compiler/eval:cfn", ptr %t215, i64 %t212
  %t217 = getelementptr %"compiler/eval:cfn", ptr %t216, i32 0, i32 9
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  store { i64, ptr } %t218, ptr %l91, !tbaa !27
  %t219 = load i64, ptr %l4, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr { i64, [8 x i64] }, ptr %t222, i64 %t219
  %t224 = load { i64, [8 x i64] }, ptr %t223
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/eval:Machine", ptr %t225, i32 0, i32 27
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l95, !tbaa !27
  %t229 = load i64, ptr %l3, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr %"compiler/eval:cfn", ptr %t232, i64 %t229
  %t234 = getelementptr %"compiler/eval:cfn", ptr %t233, i32 0, i32 11
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !27
  store { i64, ptr } %t235, ptr %l97, !tbaa !27
  %t236 = load i64, ptr %l4, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr i1, ptr %t239, i64 %t236
  %t241 = load i1, ptr %t240, !tbaa !31
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eterm(ptr %v0, ptr %t206, i64 %t207, { i64, [8 x i64] } %t224, i1 %t241)
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb64
bb29:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/eval:Machine", ptr %t246, i32 0, i32 27
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  store { i64, ptr } %t249, ptr %l101, !tbaa !27
  %t250 = load i64, ptr %l3, !tbaa !24
  %t252 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr %"compiler/eval:cfn", ptr %t253, i64 %t250
  %t255 = getelementptr %"compiler/eval:cfn", ptr %t254, i32 0, i32 8
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  store { i64, ptr } %t256, ptr %l103, !tbaa !27
  %t257 = load i64, ptr %l4, !tbaa !24
  %t259 = add i64 %t257, 1
  %t261 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr i64, ptr %t262, i64 %t259
  %t264 = load i64, ptr %t263, !tbaa !34
  store i64 %t264, ptr %l6, !tbaa !24
  %t266 = load i64, ptr %l5, !tbaa !24
  %t267 = load i64, ptr %l6, !tbaa !24
  %t270 = icmp slt i64 %t266, %t267
  br i1 %t270, label %bb30, label %bb31
bb30:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/eval:Machine", ptr %t272, i32 0, i32 27
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !27
  store { i64, ptr } %t275, ptr %l112, !tbaa !27
  %t276 = load i64, ptr %l3, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr %"compiler/eval:cfn", ptr %t279, i64 %t276
  %t281 = getelementptr %"compiler/eval:cfn", ptr %t280, i32 0, i32 13
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !27
  store { i64, ptr } %t282, ptr %l114, !tbaa !27
  %t283 = load i64, ptr %l5, !tbaa !24
  %t284 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t287 = mul i64 %t283, %t284
  %t289 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr i64, ptr %t290, i64 %t287
  %t292 = load i64, ptr %t291, !tbaa !34
  %t294 = icmp ne i64 %t292, 0
  store i1 %t294, ptr %l110, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb32
bb32:
  %t296 = load i1, ptr %l110, !tbaa !21
  br i1 %t296, label %bb33, label %bb34
bb33:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/eval:Machine", ptr %t297, i32 0, i32 27
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  store { i64, ptr } %t300, ptr %l121, !tbaa !27
  %t301 = load i64, ptr %l3, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr %"compiler/eval:cfn", ptr %t304, i64 %t301
  %t306 = getelementptr %"compiler/eval:cfn", ptr %t305, i32 0, i32 13
  %t307 = load { i64, ptr }, ptr %t306, !tbaa !27
  store { i64, ptr } %t307, ptr %l7, !tbaa !27
  br label %bb35
bb34:
  br label %bb58
bb35:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load i64, ptr %l2, !tbaa !24
  %t311 = load i64, ptr %l3, !tbaa !24
  %t312 = load i64, ptr %l5, !tbaa !24
  %t313 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t313, ptr %l128, !tbaa !27
  %t314 = load i64, ptr %l5, !tbaa !24
  %t315 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t318 = mul i64 %t314, %t315
  %t320 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr i64, ptr %t321, i64 %t318
  %t323 = load i64, ptr %t322, !tbaa !34
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eflat(ptr %v0, ptr %t309, i64 %t310, i64 %t311, i64 %t312, i64 %t323)
  br label %bb36
bb36:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/eval:Machine", ptr %t329, i32 0, i32 23
  %t332 = load i1, ptr %t331, !tbaa !21
  br i1 %t332, label %bb37, label %bb38
bb37:
  br label %ret
bb38:
  br label %bb39
bb39:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/eval:Machine", ptr %t334, i32 0, i32 59
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l136, !tbaa !27
  %t338 = load i64, ptr %l2, !tbaa !24
  store i64 %t338, ptr %l137, !tbaa !24
  %t339 = load i64, ptr %l137, !tbaa !24
  %t340 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr %"compiler/eval:frame", ptr %t341, i64 %t339
  %t343 = getelementptr %"compiler/eval:frame", ptr %t342, i32 0, i32 2
  %t344 = load i64, ptr %t343, !tbaa !24
  %t347 = add i64 %t344, 1
  %t349 = load i64, ptr %l137, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr %"compiler/eval:frame", ptr %t351, i64 %t349
  %t353 = getelementptr %"compiler/eval:frame", ptr %t352, i32 0, i32 2
  store i64 %t347, ptr %t353, !tbaa !24
  %t354 = load i64, ptr %l5, !tbaa !24
  %t357 = add i64 %t354, 1
  store i64 %t357, ptr %l5, !tbaa !24
  %t359 = load i64, ptr %l5, !tbaa !24
  %t360 = load i64, ptr %l6, !tbaa !24
  %t363 = icmp sge i64 %t359, %t360
  br i1 %t363, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb42
bb41:
  %t365 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t365, ptr %l148, !tbaa !27
  %t366 = load i64, ptr %l5, !tbaa !24
  %t367 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t370 = mul i64 %t366, %t367
  %t372 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = getelementptr i64, ptr %t373, i64 %t370
  %t375 = load i64, ptr %t374, !tbaa !34
  %t377 = icmp eq i64 %t375, 0
  store i1 %t377, ptr %l147, !tbaa !21
  br label %bb42
bb42:
  %t379 = load i1, ptr %l147, !tbaa !21
  br i1 %t379, label %bb43, label %bb44
bb43:
  br label %bb57
bb44:
  br label %bb45
bb45:
  %t380 = load ptr, ptr %l0, !tbaa !29
  store ptr %t380, ptr %l154, !tbaa !29
  %t381 = load ptr, ptr %l154, !tbaa !29
  %t382 = getelementptr %"compiler/eval:Machine", ptr %t381, i32 0, i32 15
  %t383 = load i64, ptr %t382, !tbaa !24
  %t386 = add i64 %t383, 1
  %t388 = load ptr, ptr %l154, !tbaa !29
  %t389 = getelementptr %"compiler/eval:Machine", ptr %t388, i32 0, i32 15
  store i64 %t386, ptr %t389, !tbaa !24
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/eval:Machine", ptr %t390, i32 0, i32 2
  %t393 = load i64, ptr %t392, !tbaa !24
  %t395 = icmp sge i64 %t393, 0
  br i1 %t395, label %bb46, label %bb47
bb46:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/eval:Machine", ptr %t397, i32 0, i32 15
  %t400 = load i64, ptr %t399, !tbaa !24
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/eval:Machine", ptr %t401, i32 0, i32 2
  %t404 = load i64, ptr %t403, !tbaa !24
  %t407 = icmp sgt i64 %t400, %t404
  store i1 %t407, ptr %l161, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb48
bb48:
  %t409 = load i1, ptr %l161, !tbaa !21
  br i1 %t409, label %bb49, label %bb50
bb49:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoverBudget(ptr %v0, ptr %t410)
  store i1 %t412, ptr %l169
  br label %bb51
bb50:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb52
bb51:
  %t413 = load i1, ptr %l169, !tbaa !21
  store i1 %t413, ptr %l167, !tbaa !21
  br label %bb52
bb52:
  %t414 = load i1, ptr %l167, !tbaa !21
  br i1 %t414, label %bb53, label %bb54
bb53:
  br label %ret
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb35
bb57:
  br label %bb64
bb58:
  %t415 = load i64, ptr %l5, !tbaa !24
  %t416 = load i64, ptr %l6, !tbaa !24
  %t419 = icmp slt i64 %t415, %t416
  br i1 %t419, label %bb59, label %bb60
bb59:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load i64, ptr %l2, !tbaa !24
  %t423 = load i64, ptr %l3, !tbaa !24
  %t424 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estmtAt(ptr %v0, ptr %t421, i64 %t422, i64 %t423, i64 %t424)
  br label %bb61
bb60:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i64, ptr %l2, !tbaa !24
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/eval:Machine", ptr %t431, i32 0, i32 27
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  store { i64, ptr } %t434, ptr %l180, !tbaa !27
  %t435 = load i64, ptr %l3, !tbaa !24
  %t437 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr %"compiler/eval:cfn", ptr %t438, i64 %t435
  %t440 = getelementptr %"compiler/eval:cfn", ptr %t439, i32 0, i32 9
  %t441 = load { i64, ptr }, ptr %t440, !tbaa !27
  store { i64, ptr } %t441, ptr %l182, !tbaa !27
  %t442 = load i64, ptr %l4, !tbaa !24
  %t444 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t445 = load ptr, ptr %t444, !tbaa !27
  %t446 = getelementptr { i64, [8 x i64] }, ptr %t445, i64 %t442
  %t447 = load { i64, [8 x i64] }, ptr %t446
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/eval:Machine", ptr %t448, i32 0, i32 27
  %t451 = load { i64, ptr }, ptr %t450, !tbaa !27
  store { i64, ptr } %t451, ptr %l186, !tbaa !27
  %t452 = load i64, ptr %l3, !tbaa !24
  %t454 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = getelementptr %"compiler/eval:cfn", ptr %t455, i64 %t452
  %t457 = getelementptr %"compiler/eval:cfn", ptr %t456, i32 0, i32 11
  %t458 = load { i64, ptr }, ptr %t457, !tbaa !27
  store { i64, ptr } %t458, ptr %l188, !tbaa !27
  %t459 = load i64, ptr %l4, !tbaa !24
  %t461 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t462 = load ptr, ptr %t461, !tbaa !27
  %t463 = getelementptr i1, ptr %t462, i64 %t459
  %t464 = load i1, ptr %t463, !tbaa !31
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eterm(ptr %v0, ptr %t429, i64 %t430, { i64, [8 x i64] } %t447, i1 %t464)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb1
bb65:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = mul i64 8, %t5
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = shl i64 1, %t9
  %t12 = sub i64 %t10, 1
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2emutableGlobal(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca %"compiler/eval:gkey"
  %l17 = alloca i64
  %l18 = alloca i32
  %l21 = alloca i1
  %l25 = alloca %"compiler/eval:global"
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i64, i32, i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t14 = getelementptr { i64, i32, i32 }, ptr %t13, i32 0, i32 1
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb13
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 44
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i32, ptr %l4, !tbaa !23
  %t24 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s1, i64 %t20, i32 %t21)
  store %"compiler/eval:gkey" %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load %"compiler/eval:gkey", ptr %l16
  %t27 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t25, %"compiler/eval:gkey" %t26)
  %t28 = extractvalue { i32, i64 } %t27, 1
  %t29 = extractvalue { i32, i64 } %t27, 0
  store i32 %t29, ptr %l18
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31, !prof !99
ok.31:
  store i64 %t28, ptr %l17
  br label %bb5
bb5:
  %t32 = load i64, ptr %l17, !tbaa !24
  store i64 %t32, ptr %l11, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l11, !tbaa !24
  store i64 %t33, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sge i64 %t34, 0
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 43
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t40, i64 %t41)
  store %"compiler/eval:global" %t44, ptr %l25
  br label %bb11
bb10:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  %t45 = getelementptr %"compiler/eval:global", ptr %l25, i32 0, i32 1
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t48 = load i1, ptr %l21, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b24244fd0a11c914_466201095dcd7a18)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewRegSlot(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/eval:reg"
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 55
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = call %"compiler/eval:reg" @compiler_2feval_3areg_2ector(ptr %s0)
  store %"compiler/eval:reg" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load %"compiler/eval:reg", ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2ePush_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t5, %"compiler/eval:reg" %t6)
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 55
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eLen_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = sub i64 %t12, 1
  call void @__olang_scope_close(ptr %s0)
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/eval:scope"
  %l21 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l27 = alloca i64
  %l31 = alloca %"compiler/eval:scope"
  %l53 = alloca %"compiler/eval:scope"
  %l55 = alloca i64
  %rv = alloca i64
  %t20 = alloca %"compiler/eval:scope", align 8
  %t82 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 54
  %t5 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t3)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l25
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l24, !tbaa !24
  store i64 %t10, ptr %l21, !tbaa !24
  br label %bb5
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScopeSlot(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l27
  br label %bb4
bb4:
  %t14 = load i64, ptr %l27, !tbaa !24
  store i64 %t14, ptr %l21, !tbaa !24
  br label %bb5
bb5:
  %t15 = load i64, ptr %l21, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 53
  %t19 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t20, ptr %v0, ptr %t18, i64 %t19)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t20, i64 152, i1 false)
  br label %bb6
bb6:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l31, i64 152, i1 false)
  %t27 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 1
  store i1 true, ptr %t27, !tbaa !21
  %t30 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 2
  store i64 %a1, ptr %t30, !tbaa !24
  %t33 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 3
  store i64 0, ptr %t33, !tbaa !24
  %t36 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 4
  store i64 -1, ptr %t36, !tbaa !24
  %t39 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 5
  store i64 0, ptr %t39, !tbaa !24
  %t42 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 6
  store i64 0, ptr %t42, !tbaa !24
  %t45 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 7
  store i64 0, ptr %t45, !tbaa !24
  %t48 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 8
  store i64 0, ptr %t48, !tbaa !24
  %t51 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 9
  store i64 0, ptr %t51, !tbaa !24
  %t54 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 10
  store i64 -1, ptr %t54, !tbaa !24
  %t57 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 11
  store i64 -1, ptr %t57, !tbaa !24
  %t60 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 12
  store i64 0, ptr %t60, !tbaa !24
  %t63 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 14
  store i64 0, ptr %t63, !tbaa !24
  %t66 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 16
  store i64 0, ptr %t66, !tbaa !24
  %t69 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 17
  store i64 -1, ptr %t69, !tbaa !24
  %t72 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 18
  store i1 false, ptr %t72, !tbaa !21
  %t75 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 19
  store i1 false, ptr %t75, !tbaa !21
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/eval:Machine", ptr %t76, i32 0, i32 53
  %t79 = load i64, ptr %l2, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l53, ptr %l3, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t82, ptr %l53, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t78, i64 %t79, ptr %t82)
  br label %bb7
bb7:
  %t83 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 0
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t85, ptr %l55, !tbaa !24
  %t87 = load i64, ptr %l55, !tbaa !24
  %t88 = load i64, ptr %l55, !tbaa !24
  %t89 = shl i64 %t84, %t88
  %t90 = load i64, ptr %l2, !tbaa !24
  %t93 = or i64 %t89, %t90
  store i64 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScopeSlot(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/eval:scope"
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t4 = alloca %"compiler/eval:scope", align 8
  %t6 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 53
  store ptr %t3, ptr %l2, !tbaa !29
  call void @compiler_2feval_3ascope_2ector(ptr %t4, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %t4, i64 152, i1 false)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %l3, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2ePush_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t5, ptr %t6)
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 53
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eLen_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = sub i64 %t12, 1
  call void @__olang_scope_close(ptr %s0)
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t3 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t3, ptr %a0, { i64, ptr } %t2)
  br label %bb1
bb1:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i32 %a4, i32 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l6 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i1
  %l29 = alloca i64
  %l33 = alloca i64
  %l56 = alloca i64
  %l62 = alloca i64
  %l68 = alloca i64
  %l74 = alloca i64
  %l80 = alloca i64
  %l82 = alloca i64
  %l84 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store i64 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l6, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i32, ptr %l4, !tbaa !23
  %t17 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatOp(ptr %v0, ptr %t7, i32 %t8, i64 %t9, i64 %t10, i32 %t11)
  store i64 %t17, ptr %l15
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t18 = load i64, ptr %l15, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t23 = icmp eq i64 %t19, %t20
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb7
bb6:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t29 = icmp eq i64 %t25, %t26
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = load i32, ptr %l4, !tbaa !23
  %t44 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintOp(ptr %v0, ptr %t32, i32 %t33, i64 %t34, i64 %t35, i32 %t36, i32 %a5)
  store i64 %t44, ptr %l29
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t45 = load i64, ptr %l29, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
bb11:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t50 = icmp eq i64 %t46, %t47
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t54 = trunc i64 10 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb14, label %bb15
bb13:
  br label %bb69
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l3, !tbaa !24
  %t61 = and i64 %t57, %t58
  store i64 %t61, ptr %l33, !tbaa !24
  br label %bb68
bb17:
  %t63 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t65 = trunc i64 11 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t68 = load i64, ptr %l2, !tbaa !24
  %t69 = load i64, ptr %l3, !tbaa !24
  %t72 = or i64 %t68, %t69
  store i64 %t72, ptr %l33, !tbaa !24
  br label %bb68
bb21:
  %t74 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t76 = trunc i64 12 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  %t79 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t81 = trunc i64 14 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t84 = load i64, ptr %l2, !tbaa !24
  %t85 = load i64, ptr %l3, !tbaa !24
  %t88 = xor i64 %t84, %t85
  store i64 %t88, ptr %l33, !tbaa !24
  br label %bb68
bb27:
  %t90 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t92 = trunc i64 13 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t96 = load i64, ptr %l3, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  br i1 %t99, label %bb31, label %bb32
bb31:
  store i64 1, ptr %l56, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb33
bb33:
  %t101 = load i64, ptr %l56, !tbaa !24
  store i64 %t101, ptr %l33, !tbaa !24
  br label %bb68
bb34:
  %t102 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t104 = trunc i64 15 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t107 = load i64, ptr %l2, !tbaa !24
  %t108 = load i64, ptr %l3, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  br i1 %t111, label %bb38, label %bb39
bb38:
  store i64 1, ptr %l62, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb40
bb40:
  %t113 = load i64, ptr %l62, !tbaa !24
  store i64 %t113, ptr %l33, !tbaa !24
  br label %bb68
bb41:
  %t114 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t116 = trunc i64 16 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb48
bb44:
  %t119 = load i64, ptr %l2, !tbaa !24
  %t120 = load i64, ptr %l3, !tbaa !24
  %t123 = icmp sle i64 %t119, %t120
  br i1 %t123, label %bb45, label %bb46
bb45:
  store i64 1, ptr %l68, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb47
bb47:
  %t125 = load i64, ptr %l68, !tbaa !24
  store i64 %t125, ptr %l33, !tbaa !24
  br label %bb68
bb48:
  %t126 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t128 = trunc i64 17 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb55
bb51:
  %t131 = load i64, ptr %l2, !tbaa !24
  %t132 = load i64, ptr %l3, !tbaa !24
  %t135 = icmp sgt i64 %t131, %t132
  br i1 %t135, label %bb52, label %bb53
bb52:
  store i64 1, ptr %l74, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb54
bb54:
  %t137 = load i64, ptr %l74, !tbaa !24
  store i64 %t137, ptr %l33, !tbaa !24
  br label %bb68
bb55:
  %t138 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t140 = trunc i64 18 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb62
bb58:
  %t143 = load i64, ptr %l2, !tbaa !24
  %t144 = load i64, ptr %l3, !tbaa !24
  %t147 = icmp sge i64 %t143, %t144
  br i1 %t147, label %bb59, label %bb60
bb59:
  store i64 1, ptr %l80, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb61
bb61:
  %t149 = load i64, ptr %l80, !tbaa !24
  store i64 %t149, ptr %l33, !tbaa !24
  br label %bb68
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t150)
  store i64 %t152, ptr %l82
  br label %bb66
bb66:
  %t153 = load i64, ptr %l82, !tbaa !24
  store i64 %t153, ptr %l33, !tbaa !24
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_590198b1bba6f342_437268d8e9153c4e)
  unreachable
bb68:
  %t154 = load i64, ptr %l33, !tbaa !24
  store i64 %t154, ptr %rv
  br label %ret
bb69:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t155)
  store i64 %t157, ptr %l84
  br label %bb70
bb70:
  %t158 = load i64, ptr %l84, !tbaa !24
  store i64 %t158, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t24 = icmp eq i64 %t20, %t21
  store i1 %t24, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l13, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb10
bb9:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t31 = icmp eq i64 %t27, %t28
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l17, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eobjectAt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l3 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i32
  %l16 = alloca ptr
  %l20 = alloca %"compiler/eval:Ptr"
  %l21 = alloca %"compiler/eval:Ptr"
  %l24 = alloca %"compiler/eval:Ptr"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayOf(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp ne i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = icmp eq i32 %t21, 0
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  %t26 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = add i64 %t29, 8
  %t34 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s1, i64 %t27, i64 %t31)
  store %"compiler/eval:Ptr" %t34, ptr %l20
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load %"compiler/eval:Ptr", ptr %l20
  %t37 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t35, %"compiler/eval:Ptr" %t36)
  store %"compiler/eval:Ptr" %t37, ptr %l21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t38 = load %"compiler/eval:Ptr", ptr %l21
  store %"compiler/eval:Ptr" %t38, ptr %rv
  br label %ret
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/eval:Ptr", ptr %l1
  %t43 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t39, %"compiler/eval:Ptr" %t40)
  store %"compiler/eval:Ptr" %t43, ptr %l24
  br label %bb11
bb11:
  %t44 = load %"compiler/eval:Ptr", ptr %l24
  store %"compiler/eval:Ptr" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca i32
  %l5 = alloca i32
  %l15 = alloca i32
  %rv = alloca i32
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t6, ptr %l5, !tbaa !23
  br label %bb16
bb4:
  %t8 = load { i64, [4 x i64] }, ptr %l2
  %t10 = extractvalue { i64, [4 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t14 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t13, i32 0, i32 0
  %t15 = load %"compiler/mir:Lvalue", ptr %t14
  store %"compiler/mir:Lvalue" %t15, ptr %l3
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t19 = load %"compiler/mir:Lvalue", ptr %l3
  %t23 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eplaceType(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %t19)
  store i32 %t23, ptr %l15
  br label %bb8
bb8:
  %t24 = load i32, ptr %l15, !tbaa !23
  store i32 %t24, ptr %l5, !tbaa !23
  br label %bb16
bb9:
  %t25 = load { i64, [4 x i64] }, ptr %l2
  %t27 = extractvalue { i64, [4 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 2
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t30 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t31 = getelementptr { i32, i64 }, ptr %t30, i32 0, i32 0
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l4, !tbaa !23
  br label %bb14
bb11:
  %t34 = load { i64, [4 x i64] }, ptr %l2
  %t36 = extractvalue { i64, [4 x i64] } %t34, 0
  %t37 = icmp eq i64 %t36, 3
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t40 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %l5, !tbaa !23
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_75dcc6d397d821f4_f630b477c159fde0)
  unreachable
bb16:
  %t45 = load i32, ptr %l5, !tbaa !23
  store i32 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l3
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = load %"compiler/mir:Lvalue", ptr %l3
  %t16 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eplaceReady(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %t12)
  store i1 %t16, ptr %l11
  br label %bb4
bb4:
  %t17 = load i1, ptr %l11, !tbaa !21
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ad3bfe70499dbe21_2daaaf2a9e405db5)
  unreachable
bb10:
  %t18 = load i1, ptr %l4, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoverBudget(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { ptr, ptr }
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 3
  %t4 = load { ptr, ptr }, ptr %t3
  store { ptr, ptr } %t4, ptr %l1
  %t6 = load { ptr, ptr }, ptr %l1
  %t8 = extractvalue { ptr, ptr } %t6, 0
  %t9 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t10 = icmp eq ptr %t8, %t9
  %t11 = extractvalue { ptr, ptr } %t6, 1
  %t12 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t13 = icmp eq ptr %t11, %t12
  %t14 = and i1 %t10, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load { ptr, ptr }, ptr %l1
  %t20 = extractvalue { ptr, ptr } %t18, 0
  %t21 = extractvalue { ptr, ptr } %t18, 1
  %t22 = call i1 %t20(ptr %t21)
  store i1 %t22, ptr %l8
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t23 = load i1, ptr %l8, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/eval:Machine", ptr %t27, i32 0, i32 15
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2feval_2eWatchSteps, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t37 = getelementptr %"compiler/eval:Machine", ptr %t26, i32 0, i32 2
  store i64 %t34, ptr %t37, !tbaa !24
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyInterrupted, !tbaa !27
  %t41 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t41, ptr %t39, { i64, ptr } %t40)
  br label %bb7
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhySteps, !tbaa !27
  %t47 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t47, ptr %t45, { i64, ptr } %t46)
  br label %bb9
bb9:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eownParams(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i64
  %l13 = alloca %"compiler/eval:Ptr"
  %l14 = alloca i64
  %l15 = alloca %"compiler/eval:Ptr"
  %l17 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l57 = alloca i32
  %l61 = alloca %"compiler/eval:Ptr"
  %l64 = alloca i64
  %l67 = alloca i1
  %l70 = alloca ptr
  %l74 = alloca %"compiler/eval:Ptr"
  %l75 = alloca %"compiler/eval:Ptr"
  %l76 = alloca i64
  %l77 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l86 = alloca i32
  %l87 = alloca i64
  %l94 = alloca %"compiler/eval:Ptr"
  %l99 = alloca ptr
  %l103 = alloca %"compiler/eval:Ptr"
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 27
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l17, !tbaa !27
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:cfn", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:cfn", ptr %t9, i32 0, i32 12
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb1, label %bb2
bb1:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb3:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l28, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb5
bb5:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l9, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t63, ptr %l46, !tbaa !27
  %t64 = load i64, ptr %l9, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i1, ptr %t67, i64 %t64
  %t69 = load i1, ptr %t68, !tbaa !31
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb12:
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/eval:Machine", ptr %t73, i32 0, i32 26
  %t76 = load i64, ptr %l2, !tbaa !24
  %t79 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t75, i64 %t76)
  store ptr %t79, ptr %l53
  br label %bb14
bb14:
  %t80 = load ptr, ptr %l53, !tbaa !29
  %t82 = getelementptr %"compiler/mir:Fn", ptr %t80, i32 0, i32 4
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t82, i64 %t83)
  store i32 %t86, ptr %l57
  br label %bb15
bb15:
  %t87 = load i32, ptr %l57, !tbaa !23
  store i32 %t87, ptr %l10, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l10, !tbaa !23
  %t94 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t88, i64 %a1, i32 %t90)
  store %"compiler/eval:Ptr" %t94, ptr %l61
  br label %bb16
bb16:
  %t95 = load %"compiler/eval:Ptr", ptr %l61
  store %"compiler/eval:Ptr" %t95, ptr %l11
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load %"compiler/eval:Ptr", ptr %l11
  %t100 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t96, %"compiler/eval:Ptr" %t97, i64 8)
  store i64 %t100, ptr %l64
  br label %bb17
bb17:
  %t101 = load i64, ptr %l64, !tbaa !24
  store i64 %t101, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l12, !tbaa !24
  %t104 = icmp sle i64 %t102, 0
  br i1 %t104, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb20
bb19:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/eval:Machine", ptr %t106, i32 0, i32 23
  %t109 = load i1, ptr %t108, !tbaa !21
  store i1 %t109, ptr %l67, !tbaa !21
  br label %bb20
bb20:
  %t111 = load i1, ptr %l67, !tbaa !21
  br i1 %t111, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb22:
  br label %bb23
bb23:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l70, !tbaa !29
  %t113 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 0
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  %t118 = add i64 %t116, 8
  %t121 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t114, i64 %t118)
  store %"compiler/eval:Ptr" %t121, ptr %l74
  br label %bb24
bb24:
  %t122 = load ptr, ptr %l70, !tbaa !29
  %t123 = load %"compiler/eval:Ptr", ptr %l74
  %t124 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t122, %"compiler/eval:Ptr" %t123)
  store %"compiler/eval:Ptr" %t124, ptr %l75
  br label %bb25
bb25:
  %t125 = load %"compiler/eval:Ptr", ptr %l75
  store %"compiler/eval:Ptr" %t125, ptr %l13
  %t126 = load i64, ptr %l12, !tbaa !24
  store i64 %t126, ptr %l76, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l77, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/eval:Machine", ptr %t129, i32 0, i32 27
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l80, !tbaa !27
  %t133 = load i64, ptr %l2, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr %"compiler/eval:cfn", ptr %t136, i64 %t133
  %t138 = getelementptr %"compiler/eval:cfn", ptr %t137, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l82, !tbaa !27
  %t140 = load i32, ptr %l10, !tbaa !23
  %t142 = sext i32 %t140 to i64
  %t144 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr %"compiler/mir:Local", ptr %t145, i64 %t142
  %t147 = getelementptr %"compiler/mir:Local", ptr %t146, i32 0, i32 2
  %t148 = load i32, ptr %t147, !tbaa !23
  %t151 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t128, i32 %t148)
  store i32 %t151, ptr %l86
  br label %bb26
bb26:
  %t152 = load ptr, ptr %l77, !tbaa !29
  %t153 = load i32, ptr %l86, !tbaa !23
  %t154 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t152, i32 %t153)
  store i64 %t154, ptr %l87
  br label %bb27
bb27:
  %t155 = load i64, ptr %l76, !tbaa !24
  %t156 = load i64, ptr %l87, !tbaa !24
  %t157 = mul i64 %t155, %t156
  store i64 %t157, ptr %l14, !tbaa !24
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i64, ptr %l14, !tbaa !24
  %t161 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/eval:Machine", ptr %t162, i32 0, i32 71
  %t165 = load i64, ptr %t164, !tbaa !24
  %t170 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t159, i64 %t160, i64 %t161, i64 %t165)
  store %"compiler/eval:Ptr" %t170, ptr %l94
  br label %bb28
bb28:
  %t171 = load %"compiler/eval:Ptr", ptr %l94
  store %"compiler/eval:Ptr" %t171, ptr %l15
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load %"compiler/eval:Ptr", ptr %l15
  %t174 = load %"compiler/eval:Ptr", ptr %l13
  %t175 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t172, %"compiler/eval:Ptr" %t173, %"compiler/eval:Ptr" %t174, i64 %t175)
  br label %bb29
bb29:
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l99, !tbaa !29
  %t181 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 0
  %t182 = load i64, ptr %t181, !tbaa !24
  %t183 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 1
  %t184 = load i64, ptr %t183, !tbaa !24
  %t186 = add i64 %t184, 8
  %t189 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t182, i64 %t186)
  store %"compiler/eval:Ptr" %t189, ptr %l103
  br label %bb30
bb30:
  %t190 = load %"compiler/eval:Ptr", ptr %l15
  %t191 = load ptr, ptr %l99, !tbaa !29
  %t192 = load %"compiler/eval:Ptr", ptr %l103
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t191, %"compiler/eval:Ptr" %t192, %"compiler/eval:Ptr" %t190)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t194 = load i64, ptr %l8, !tbaa !24
  %t197 = add i64 %t194, 1
  store i64 %t197, ptr %l8, !tbaa !24
  br label %bb7
bb33:
  br label %ret
ret:
  ret void
}

define dso_local { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2epack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l43 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l52 = alloca i64
  %l55 = alloca { i64, ptr }
  %l58 = alloca i64
  %l72 = alloca i64
  %l74 = alloca { i64, ptr }
  %l77 = alloca i64
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sle i64 %t7, 1152921504606846975
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4df6f2ee185eb0d1_4c6469cdbf591dfd)
  unreachable
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 8
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t15, ptr %lp2
  %t17 = load ptr, ptr %lp2
  store { i64, ptr } %t14, ptr %t17, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4df6f2ee185eb0d1_4c6469cdbf591dfd)
  unreachable
bb5:
  %t28 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l24, !tbaa !24
  store i64 %t48, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l21, !tbaa !24
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb25
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l4, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l9, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t69, ptr %l43, !tbaa !27
  %t70 = load i64, ptr %l9, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 %t70
  %t75 = load i32, ptr %t74, !tbaa !33
  %t78 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %t68, i32 %t75)
  store i1 %t78, ptr %l46
  br label %bb15
bb15:
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t79, ptr %l47, !tbaa !27
  %t80 = load i64, ptr %l9, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i32, ptr %t83, i64 %t80
  %t85 = load i32, ptr %t84, !tbaa !33
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t89 = icmp ne i32 %t85, %t86
  br i1 %t89, label %bb16, label %bb17
bb16:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/eval:Machine", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t95, ptr %l55, !tbaa !27
  %t96 = load i64, ptr %l9, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i32, ptr %t99, i64 %t96
  %t101 = load i32, ptr %t100, !tbaa !33
  %t104 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t94, i32 %t101)
  store i64 %t104, ptr %l58
  br label %bb18
bb17:
  store i64 1, ptr %l52, !tbaa !24
  br label %bb19
bb18:
  %t105 = load i64, ptr %l58, !tbaa !24
  store i64 %t105, ptr %l52, !tbaa !24
  br label %bb19
bb19:
  %t106 = load i64, ptr %l52, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t109 = icmp slt i64 %t107, 1
  br i1 %t109, label %bb20, label %bb21
bb20:
  store i64 1, ptr %l10, !tbaa !24
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t111 = load i64, ptr %l3, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = add i64 %t111, %t113
  %t118 = sub i64 %t116, 1
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = sdiv i64 %t118, %t119
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = mul i64 %t122, %t123
  store i64 %t126, ptr %l3, !tbaa !24
  %t128 = load i64, ptr %l9, !tbaa !24
  %t129 = load i64, ptr %l3, !tbaa !24
  %t131 = load ptr, ptr %lp2
  %t133 = getelementptr { i64, ptr }, ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i64, ptr %t134, i64 %t128
  store i64 %t129, ptr %t135, !tbaa !34
  %t136 = load i64, ptr %l3, !tbaa !24
  store i64 %t136, ptr %l72, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t138, ptr %l74, !tbaa !27
  %t139 = load i64, ptr %l9, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i32, ptr %t142, i64 %t139
  %t144 = load i32, ptr %t143, !tbaa !33
  %t147 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t137, i32 %t144)
  store i64 %t147, ptr %l77
  br label %bb23
bb23:
  %t148 = load i64, ptr %l72, !tbaa !24
  %t149 = load i64, ptr %l77, !tbaa !24
  %t150 = add i64 %t148, %t149
  store i64 %t150, ptr %l3, !tbaa !24
  br label %bb24
bb24:
  %t152 = load i64, ptr %l8, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l8, !tbaa !24
  br label %bb11
bb25:
  %t157 = load ptr, ptr %lp2
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l3, !tbaa !24
  %t161 = add i64 %t159, 7
  %t163 = sdiv i64 %t161, 8
  %t165 = mul i64 %t163, 8
  %t167 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t158, 0
  %t169 = insertvalue { { i64, ptr }, i64 } %t167, i64 %t165, 1
  store { { i64, ptr }, i64 } %t169, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l20 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i32, ptr %l12, !range !{i32 0, i32 33}
  store i32 %t17, ptr %l4
  %t18 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t20 = trunc i64 22 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t23 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t25 = trunc i64 23 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l20
  br label %bb8
bb8:
  %t33 = load i32, ptr %l20, !tbaa !23
  store i32 %t33, ptr %l13, !tbaa !23
  br label %bb19
bb9:
  %t34 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t36 = trunc i64 18 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l25
  br label %bb13
bb13:
  %t44 = load i32, ptr %l25, !tbaa !23
  store i32 %t44, ptr %l13, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i32 0, ptr %l13, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d4aeb51afef739b6_d573fd1fa5ffe912)
  unreachable
bb19:
  %t45 = load i32, ptr %l13, !tbaa !23
  store i32 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l23 = alloca i1
  %l26 = alloca i64
  %l30 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l56 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load i32, ptr %l12, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 75
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t12, i32 %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l18
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb3, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l17
  br label %bb2
bb2:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l13, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb5
bb5:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp slt i64 %t23, 0
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l23
  br label %bb8
bb7:
  br label %bb19
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 76
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l26
  br label %bb9
bb9:
  %t37 = load i64, ptr %l26, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %s2, ptr %t41, i32 %t42)
  store { i64, ptr } %t45, ptr %l30
  br label %bb10
bb10:
  %t46 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t46, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t60, ptr %l38, !tbaa !27
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t61
  %t66 = load i64, ptr %t65, !tbaa !34
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/eval:Machine", ptr %t68, i32 0, i32 76
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t70, i64 %t66)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb11
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/eval:Machine", ptr %t79, i32 0, i32 75
  %t82 = load i32, ptr %l3, !tbaa !23
  %t83 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t81, i32 %t82, i64 %t83)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/eval:Machine", ptr %t87, i32 0, i32 76
  %t90 = load i64, ptr %l4, !tbaa !24
  %t94 = add i64 %t90, %a2
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t89, i64 %t94)
  store i64 %t97, ptr %l56
  br label %bb20
bb20:
  %t98 = load i64, ptr %l56, !tbaa !24
  store i64 %t98, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartList(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t10, i32 %t11)
  store { i64, ptr } %t12, ptr %l8
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i32, ptr %t17, i64 %a2
  %t19 = load i32, ptr %t18, !tbaa !33
  call void @__olang_scope_close(ptr %s0)
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2epayDrop(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sle i64 %t7, %a1
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t11, i32 0, i32 13
  %t15 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t13)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l12
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb6, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l11
  br label %bb5
bb5:
  %t20 = load i64, ptr %l11, !tbaa !24
  store i64 %t20, ptr %l8, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t21 = load i64, ptr %l8, !tbaa !24
  store i64 %t21, ptr %l2, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/eval:Machine", ptr %t22, i32 0, i32 14
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 14
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eLen_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l17
  br label %bb9
bb9:
  %t30 = load i64, ptr %l17, !tbaa !24
  %t31 = sub i64 %t30, 1
  %t32 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eTruncate_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %t32, i64 %t31)
  br label %bb10
bb10:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = icmp ne i64 %t34, 0
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseRegion(ptr %v0, ptr %t38, i64 %t39)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epayloadType(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca { i64, ptr }
  %l11 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l26 = alloca { i64, ptr }
  %l29 = alloca i1
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %rv = alloca i32
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load i32, ptr %l11, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l14
  br label %bb2
bb2:
  %t17 = load i32, ptr %l14, !range !{i32 0, i32 33}
  %t19 = trunc i64 24 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load i32, ptr %l4, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l20
  br label %bb5
bb4:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t28 = load i32, ptr %l4, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l23
  br label %bb6
bb5:
  %t32 = load i32, ptr %l20, !tbaa !23
  store i32 %t32, ptr %l17, !tbaa !23
  br label %bb7
bb6:
  %t33 = load i32, ptr %l23, !tbaa !23
  store i32 %t33, ptr %l17, !tbaa !23
  br label %bb7
bb7:
  %t34 = load i32, ptr %l17, !tbaa !23
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t35, i32 %t34)
  store { i64, ptr } %t39, ptr %l26
  br label %bb8
bb8:
  %t40 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t40, ptr %l6, !tbaa !27
  %t41 = load i64, ptr %l2, !tbaa !24
  %t43 = icmp sge i64 %t41, 0
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t51 = icmp slt i64 %t45, %t48
  store i1 %t51, ptr %l29, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb11
bb11:
  %t53 = load i1, ptr %l29, !tbaa !21
  br i1 %t53, label %bb12, label %bb13
bb12:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  store i32 %t60, ptr %l34, !tbaa !23
  br label %bb14
bb13:
  store i32 0, ptr %l34, !tbaa !23
  br label %bb14
bb14:
  %t62 = load i32, ptr %l34, !tbaa !23
  store i32 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eplaceReady(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/eval:global"
  %l13 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca %"compiler/eval:gkey"
  %l19 = alloca i64
  %l20 = alloca i32
  %l23 = alloca i1
  %l32 = alloca %"compiler/eval:global"
  %l34 = alloca i1
  %l42 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l64 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l3
  %t4 = load { i64, [2 x i64] }, ptr %l3
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t10 = getelementptr { i64, i32, i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  store i64 %t11, ptr %l4, !tbaa !24
  %t13 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t14 = getelementptr { i64, i32, i32 }, ptr %t13, i32 0, i32 1
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  br label %bb53
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 44
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i32, ptr %l5, !tbaa !23
  %t24 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s1, i64 %t20, i32 %t21)
  store %"compiler/eval:gkey" %t24, ptr %l18
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = load %"compiler/eval:gkey", ptr %l18
  %t27 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t25, %"compiler/eval:gkey" %t26)
  %t28 = extractvalue { i32, i64 } %t27, 1
  %t29 = extractvalue { i32, i64 } %t27, 0
  store i32 %t29, ptr %l20
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31, !prof !99
ok.31:
  store i64 %t28, ptr %l19
  br label %bb5
bb5:
  %t32 = load i64, ptr %l19, !tbaa !24
  store i64 %t32, ptr %l13, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l13, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t34, 0
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb11
bb10:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 74
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = icmp eq i64 %t38, %t42
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/eval:Machine", ptr %t49, i32 0, i32 43
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t51, i64 %t52)
  store %"compiler/eval:global" %t55, ptr %l32
  br label %bb15
bb15:
  %t56 = load %"compiler/eval:global", ptr %l32
  store %"compiler/eval:global" %t56, ptr %l7
  %t57 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 5
  %t58 = load i1, ptr %t57, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb18
bb17:
  %t60 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 6
  %t61 = load i1, ptr %t60, !tbaa !21
  store i1 %t61, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 24
  store i1 true, ptr %t66, !tbaa !21
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/eval:Machine", ptr %t67, i32 0, i32 1
  %t70 = load i32, ptr %t69, !range !{i32 0, i32 2}
  %t72 = trunc i64 1 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t75 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 4
  %t76 = load i64, ptr %t75, !tbaa !24
  %t78 = icmp ne i64 %t76, 0
  br i1 %t78, label %bb24, label %bb25
bb23:
  br label %bb31
bb24:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb26
bb25:
  %t80 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 2
  %t81 = load i64, ptr %t80, !tbaa !24
  %t83 = icmp slt i64 %t81, 0
  store i1 %t83, ptr %l42, !tbaa !21
  br label %bb26
bb26:
  %t85 = load i1, ptr %l42, !tbaa !21
  br i1 %t85, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartGlobal(ptr %v0, ptr %t87, i64 %t88)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb31:
  %t92 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 1
  %t93 = load i1, ptr %t92, !tbaa !21
  br i1 %t93, label %bb32, label %bb33
bb32:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l50, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i64, ptr %l4, !tbaa !24
  %t99 = load i32, ptr %l5, !tbaa !23
  %t104 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewritesAfter(ptr %v0, ptr %t96, i64 %a1, i64 %t98, i32 %t99)
  store i1 %t104, ptr %l55
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t105 = load i1, ptr %l55, !tbaa !21
  br i1 %t105, label %bb35, label %bb36
bb35:
  %t106 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWritesGlobalVar, !tbaa !27
  store { i64, ptr } %t106, ptr %l56, !tbaa !27
  br label %bb37
bb36:
  %t108 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyMutableGlobal, !tbaa !27
  store { i64, ptr } %t108, ptr %l56, !tbaa !27
  br label %bb37
bb37:
  %t110 = load ptr, ptr @__olang_prog_scope
  %t111 = load ptr, ptr %l50, !tbaa !29
  %t112 = load { i64, ptr }, ptr %l56, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t110, ptr %t111, { i64, ptr } %t112)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb39:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 0
  %t116 = load i64, ptr %t115, !tbaa !24
  %t118 = trunc i64 %t116 to i32
  %t122 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereachesWritable(ptr %v0, ptr %t114, i32 %t118)
  store i1 %t122, ptr %l64
  br label %bb40
bb40:
  %t123 = load i1, ptr %l64, !tbaa !21
  br i1 %t123, label %bb41, label %bb42
bb41:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyChangeable, !tbaa !27
  %t126 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t126, ptr %t124, { i64, ptr } %t125)
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb44:
  %t130 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 4
  %t131 = load i64, ptr %t130, !tbaa !24
  %t133 = icmp eq i64 %t131, 2
  br i1 %t133, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t136 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 4
  %t137 = load i64, ptr %t136, !tbaa !24
  %t139 = icmp eq i64 %t137, 1
  br i1 %t139, label %bb48, label %bb49
bb48:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyCycle, !tbaa !27
  %t143 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t143, ptr %t141, { i64, ptr } %t142)
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb51:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartGlobal(ptr %v0, ptr %t147, i64 %t148)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 true, ptr %rv
  br label %ret
bb57:
  call void @__olang_check_failed(ptr @olang_loc_a7714af53687ff6b_1e8ca3031727412f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eplaceType(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l25 = alloca i32
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l47 = alloca i32
  %l50 = alloca i32
  %l69 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l78 = alloca i32
  %l85 = alloca i32
  %l92 = alloca i32
  %l95 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca i32
  %l106 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 59
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l19, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %a1
  %t10 = getelementptr %"compiler/eval:frame", ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  %t18 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 0
  %t19 = load { i64, [2 x i64] }, ptr %t18
  store { i64, [2 x i64] } %t19, ptr %l5
  %t21 = load { i64, [2 x i64] }, ptr %l5
  %t23 = extractvalue { i64, [2 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 1
  br i1 %t24, label %bb1, label %bb2
bb1:
  %t26 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t27 = getelementptr { i32 }, ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l6, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 27
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l30, !tbaa !27
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/eval:cfn", ptr %t37, i64 %t34
  %t39 = getelementptr %"compiler/eval:cfn", ptr %t38, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l32, !tbaa !27
  %t41 = load i32, ptr %l6, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t45 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr %"compiler/mir:Local", ptr %t46, i64 %t43
  %t48 = getelementptr %"compiler/mir:Local", ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48, !tbaa !23
  store i32 %t49, ptr %l25, !tbaa !23
  br label %bb13
bb4:
  %t51 = load { i64, [2 x i64] }, ptr %l5
  %t53 = extractvalue { i64, [2 x i64] } %t51, 0
  %t54 = icmp eq i64 %t53, 2
  br i1 %t54, label %bb5, label %bb6
bb5:
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t57 = getelementptr { i64, i32, i32 }, ptr %t56, i32 0, i32 2
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l7, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t60 = load i32, ptr %l7, !tbaa !23
  store i32 %t60, ptr %l25, !tbaa !23
  br label %bb13
bb8:
  %t62 = load { i64, [2 x i64] }, ptr %l5
  %t64 = extractvalue { i64, [2 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 0
  br i1 %t65, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t67, ptr %l25, !tbaa !23
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_48067455946c0246_37fc1727e867ffc2)
  unreachable
bb13:
  %t69 = load i32, ptr %l25, !tbaa !23
  store i32 %t69, ptr %l8, !tbaa !23
  store i32 0, ptr %l9, !tbaa !23
  %t70 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 1
  %t71 = getelementptr %"compiler/mir:Range", ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71, !tbaa !23
  store i32 %t72, ptr %l10, !tbaa !23
  store i32 1, ptr %l11, !tbaa !23
  %t74 = load i32, ptr %l10, !tbaa !23
  %t75 = load i32, ptr %l9, !tbaa !23
  %t78 = icmp sgt i32 %t74, %t75
  br i1 %t78, label %bb14, label %bb15
bb14:
  %t80 = load i32, ptr %l11, !tbaa !23
  %t82 = icmp sgt i32 %t80, 0
  br i1 %t82, label %bb16, label %bb17
bb15:
  store i32 0, ptr %l47, !tbaa !23
  br label %bb19
bb16:
  %t84 = load i32, ptr %l10, !tbaa !23
  %t85 = load i32, ptr %l9, !tbaa !23
  %t88 = sub i32 %t84, %t85
  %t89 = load i32, ptr %l11, !tbaa !23
  %t92 = add i32 %t88, %t89
  %t94 = sub i32 %t92, 1
  %t95 = load i32, ptr %l11, !tbaa !23
  %t98 = sdiv i32 %t94, %t95
  store i32 %t98, ptr %l50, !tbaa !23
  br label %bb18
bb17:
  store i32 0, ptr %l50, !tbaa !23
  br label %bb18
bb18:
  %t100 = load i32, ptr %l50, !tbaa !23
  store i32 %t100, ptr %l47, !tbaa !23
  br label %bb19
bb19:
  %t101 = load i32, ptr %l47, !tbaa !23
  store i32 %t101, ptr %l12, !tbaa !23
  store i32 0, ptr %l13, !tbaa !23
  br label %bb20
bb20:
  %t102 = load i32, ptr %l13, !tbaa !23
  %t103 = load i32, ptr %l12, !tbaa !23
  %t106 = icmp slt i32 %t102, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb21, label %bb22
bb21:
  br label %bb49
bb22:
  br label %bb23
bb23:
  %t110 = load i32, ptr %l9, !tbaa !23
  %t111 = load i32, ptr %l13, !tbaa !23
  %t112 = load i32, ptr %l11, !tbaa !23
  %t115 = mul i32 %t111, %t112
  %t118 = add i32 %t110, %t115
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/eval:Machine", ptr %t120, i32 0, i32 27
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l69, !tbaa !27
  %t124 = load i64, ptr %l3, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr %"compiler/eval:cfn", ptr %t127, i64 %t124
  %t129 = getelementptr %"compiler/eval:cfn", ptr %t128, i32 0, i32 3
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l71, !tbaa !27
  %t131 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 1
  %t132 = getelementptr %"compiler/mir:Range", ptr %t131, i32 0, i32 0
  %t133 = load i32, ptr %t132, !tbaa !23
  %t135 = sext i32 %t133 to i64
  %t138 = sext i32 %t118 to i64
  %t141 = add i64 %t135, %t138
  %t143 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, [1 x i64] }, ptr %t144, i64 %t141
  %t146 = load { i64, [1 x i64] }, ptr %t145
  store { i64, [1 x i64] } %t146, ptr %l15
  %t148 = load { i64, [1 x i64] }, ptr %l15
  %t150 = extractvalue { i64, [1 x i64] } %t148, 0
  %t151 = icmp eq i64 %t150, 0
  br i1 %t151, label %bb24, label %bb25
bb24:
  %t153 = getelementptr { i64, [1 x i64] }, ptr %l15, i32 0, i32 1
  %t154 = getelementptr { i64 }, ptr %t153, i32 0, i32 0
  %t155 = load i64, ptr %t154
  store i64 %t155, ptr %l16, !tbaa !24
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i32, ptr %l8, !tbaa !23
  %t159 = load i64, ptr %l16, !tbaa !24
  %t163 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %t157, i32 %t158, i64 %t159)
  store i32 %t163, ptr %l85
  br label %bb27
bb27:
  %t164 = load i32, ptr %l85, !tbaa !23
  store i32 %t164, ptr %l78, !tbaa !23
  br label %bb47
bb28:
  %t165 = load { i64, [1 x i64] }, ptr %l15
  %t167 = extractvalue { i64, [1 x i64] } %t165, 0
  %t168 = icmp eq i64 %t167, 1
  br i1 %t168, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  %t170 = load { i64, [1 x i64] }, ptr %l15
  %t172 = extractvalue { i64, [1 x i64] } %t170, 0
  %t173 = icmp eq i64 %t172, 2
  br i1 %t173, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l8, !tbaa !23
  %t179 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t175, i32 %t176)
  store i32 %t179, ptr %l92
  br label %bb34
bb34:
  %t180 = load i32, ptr %l92, !tbaa !23
  store i32 %t180, ptr %l78, !tbaa !23
  br label %bb47
bb35:
  %t181 = load { i64, [1 x i64] }, ptr %l15
  %t183 = extractvalue { i64, [1 x i64] } %t181, 0
  %t184 = icmp eq i64 %t183, 3
  br i1 %t184, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t186 = load ptr, ptr %l4, !tbaa !29
  store ptr %t186, ptr %l95, !tbaa !29
  %t187 = load ptr, ptr %l4, !tbaa !29
  %t188 = load i32, ptr %l8, !tbaa !23
  %t191 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t187, i32 %t188)
  store i32 %t191, ptr %l98
  br label %bb39
bb39:
  %t192 = load ptr, ptr %l95, !tbaa !29
  %t193 = load i32, ptr %l98, !tbaa !23
  %t194 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t194, ptr %l99
  br label %bb40
bb40:
  %t195 = load i32, ptr %l99, !tbaa !23
  store i32 %t195, ptr %l78, !tbaa !23
  br label %bb47
bb41:
  %t196 = load { i64, [1 x i64] }, ptr %l15
  %t198 = extractvalue { i64, [1 x i64] } %t196, 0
  %t199 = icmp eq i64 %t198, 4
  br i1 %t199, label %bb42, label %bb43
bb42:
  %t201 = getelementptr { i64, [1 x i64] }, ptr %l15, i32 0, i32 1
  %t202 = getelementptr { i64 }, ptr %t201, i32 0, i32 0
  %t203 = load i64, ptr %t202
  store i64 %t203, ptr %l17, !tbaa !24
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l8, !tbaa !23
  %t207 = load i64, ptr %l17, !tbaa !24
  %t211 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epayloadType(ptr %v0, ptr %t205, i32 %t206, i64 %t207)
  store i32 %t211, ptr %l106
  br label %bb45
bb45:
  %t212 = load i32, ptr %l106, !tbaa !23
  store i32 %t212, ptr %l78, !tbaa !23
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_ed29d0e1fe37827_73f8bd43b4184743)
  unreachable
bb47:
  %t213 = load i32, ptr %l78, !tbaa !23
  store i32 %t213, ptr %l8, !tbaa !23
  br label %bb48
bb48:
  %t214 = load i32, ptr %l13, !tbaa !23
  %t217 = add i32 %t214, 1
  store i32 %t217, ptr %l13, !tbaa !23
  br label %bb20
bb49:
  %t219 = load i32, ptr %l8, !tbaa !23
  store i32 %t219, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2epopFrame(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l22 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 60
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp eq i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 60
  %t11 = load i64, ptr %t10, !tbaa !24
  %t14 = sub i64 %t11, 1
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 60
  store i64 %t14, ptr %t17, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/eval:Machine", ptr %t18, i32 0, i32 27
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l9, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/eval:Machine", ptr %t22, i32 0, i32 59
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l11, !tbaa !27
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/eval:Machine", ptr %t26, i32 0, i32 60
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/eval:frame", ptr %t32, i64 %t29
  %t34 = getelementptr %"compiler/eval:frame", ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr %"compiler/eval:cfn", ptr %t38, i64 %t35
  %t40 = getelementptr %"compiler/eval:cfn", ptr %t39, i32 0, i32 17
  %t41 = load i1, ptr %t40, !tbaa !21
  br i1 %t41, label %bb4, label %bb5
bb4:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l16, !tbaa !29
  %t44 = load ptr, ptr %l16, !tbaa !29
  %t45 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 12
  %t46 = load i64, ptr %t45, !tbaa !24
  %t49 = sub i64 %t46, 1
  %t51 = load ptr, ptr %l16, !tbaa !29
  %t52 = getelementptr %"compiler/eval:Machine", ptr %t51, i32 0, i32 12
  store i64 %t49, ptr %t52, !tbaa !24
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/eval:Machine", ptr %t54, i32 0, i32 59
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l22, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/eval:Machine", ptr %t58, i32 0, i32 60
  %t61 = load i64, ptr %t60, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr %"compiler/eval:frame", ptr %t64, i64 %t61
  %t66 = getelementptr %"compiler/eval:frame", ptr %t65, i32 0, i32 3
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = getelementptr %"compiler/eval:Machine", ptr %t53, i32 0, i32 62
  store i64 %t67, ptr %t70, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/eval:Machine", ptr %t72, i32 0, i32 60
  %t75 = load i64, ptr %t74, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropOwnDefers(ptr %v0, ptr %t71, i64 %t75)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, { i64, [4 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca %"compiler/mir:Lvalue"
  %l6 = alloca { %"compiler/eval:Ptr", i32 }
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, i64 }
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l27 = alloca { %"compiler/eval:Ptr", i32 }
  %l30 = alloca ptr
  %l31 = alloca %"compiler/eval:Ptr"
  %l32 = alloca %"compiler/eval:Ptr"
  %l35 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i1
  %l48 = alloca i64
  %l59 = alloca i1
  %l62 = alloca i64
  %l65 = alloca i1
  %l68 = alloca i64
  %l76 = alloca i64
  %l82 = alloca { i64, i64 }
  %l90 = alloca ptr
  %l91 = alloca %"compiler/eval:Ptr"
  %l94 = alloca i64
  %l98 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store { i64, [4 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l4
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb52
bb4:
  %t6 = load { i64, [4 x i64] }, ptr %l4
  %t8 = extractvalue { i64, [4 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t12 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t11, i32 0, i32 0
  %t13 = load %"compiler/mir:Lvalue", ptr %t12
  store %"compiler/mir:Lvalue" %t13, ptr %l5
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l1, !tbaa !24
  %t17 = load %"compiler/mir:Lvalue", ptr %l5
  %t21 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t15, i64 %t16, %"compiler/mir:Lvalue" %t17)
  store { %"compiler/eval:Ptr", i32 } %t21, ptr %l27
  br label %bb8
bb8:
  %t22 = load { %"compiler/eval:Ptr", i32 }, ptr %l27
  store { %"compiler/eval:Ptr", i32 } %t22, ptr %l6
  %t23 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l6, i32 0, i32 0
  %t24 = load %"compiler/eval:Ptr", ptr %t23
  %t26 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l6, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l30, !tbaa !29
  %t30 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t30, ptr %l31
  store %"compiler/eval:Ptr" %t24, ptr %l32
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t32, i32 %t27)
  store i64 %t36, ptr %l35
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l30, !tbaa !29
  %t38 = load %"compiler/eval:Ptr", ptr %l31
  %t39 = load %"compiler/eval:Ptr", ptr %l32
  %t40 = load i64, ptr %l35, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t37, %"compiler/eval:Ptr" %t38, %"compiler/eval:Ptr" %t39, i64 %t40)
  br label %bb10
bb10:
  br label %bb52
bb11:
  %t41 = load { i64, [4 x i64] }, ptr %l4
  %t43 = extractvalue { i64, [4 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 2
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t47 = getelementptr { i32, i64 }, ptr %t46, i32 0, i32 0
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l9, !tbaa !23
  %t50 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t51 = getelementptr { i32, i64 }, ptr %t50, i32 0, i32 1
  %t52 = load i64, ptr %t51
  store i64 %t52, ptr %l10, !tbaa !24
  br label %bb14
bb13:
  br label %bb46
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t58 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t54, i32 %a3)
  store i64 %t58, ptr %l42
  br label %bb15
bb15:
  %t59 = load i64, ptr %l42, !tbaa !24
  store i64 %t59, ptr %l11, !tbaa !24
  %t60 = load i64, ptr %l10, !tbaa !24
  %t62 = icmp ne i64 %t60, 0
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l9, !tbaa !23
  %t68 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t64, i32 %t65)
  store i64 %t68, ptr %l48
  br label %bb18
bb17:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb19
bb18:
  %t69 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t70 = load i64, ptr %l48, !tbaa !24
  %t72 = icmp eq i64 %t70, %t69
  store i1 %t72, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t74 = load i1, ptr %l45, !tbaa !21
  br i1 %t74, label %bb20, label %bb21
bb20:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load %"compiler/eval:Ptr", ptr %l2
  %t77 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ezero(ptr %v0, ptr %t75, %"compiler/eval:Ptr" %t76, i64 %t77)
  br label %bb22
bb21:
  %t81 = load i64, ptr %l10, !tbaa !24
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb24, label %bb25
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/eval:Ptr", ptr %l2
  %t87 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t85, %"compiler/eval:Ptr" %t86, i64 8, i64 %t87)
  br label %bb23
bb23:
  br label %bb45
bb24:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb27
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l9, !tbaa !23
  %t95 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t91, i32 %t92)
  store i64 %t95, ptr %l62
  br label %bb26
bb26:
  %t96 = load i64, ptr @G_2ecompiler_2feval_2evAgg, !tbaa !24
  %t97 = load i64, ptr %l62, !tbaa !24
  %t99 = icmp eq i64 %t97, %t96
  store i1 %t99, ptr %l59, !tbaa !21
  br label %bb27
bb27:
  %t101 = load i1, ptr %l59, !tbaa !21
  br i1 %t101, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb31
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l9, !tbaa !23
  %t106 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t102, i32 %t103)
  store i64 %t106, ptr %l68
  br label %bb30
bb30:
  %t107 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  %t108 = load i64, ptr %l68, !tbaa !24
  %t110 = icmp eq i64 %t108, %t107
  store i1 %t110, ptr %l65, !tbaa !21
  br label %bb31
bb31:
  %t112 = load i1, ptr %l65, !tbaa !21
  br i1 %t112, label %bb32, label %bb33
bb32:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load %"compiler/eval:Ptr", ptr %l2
  %t115 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ezero(ptr %v0, ptr %t113, %"compiler/eval:Ptr" %t114, i64 %t115)
  br label %bb34
bb33:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l9, !tbaa !23
  %t123 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t119, i32 %t120)
  store i64 %t123, ptr %l76
  br label %bb35
bb34:
  br label %bb44
bb35:
  %t124 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t125 = load i64, ptr %l76, !tbaa !24
  %t127 = icmp eq i64 %t125, %t124
  br i1 %t127, label %bb36, label %bb37
bb36:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l9, !tbaa !23
  %t131 = load i64, ptr %l10, !tbaa !24
  %t135 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideConst(ptr %v0, ptr %t129, i32 %t130, i64 %t131)
  store { i64, i64 } %t135, ptr %l82
  br label %bb38
bb37:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l90, !tbaa !29
  %t137 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t137, ptr %l91
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l9, !tbaa !23
  %t142 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t138, i32 %t139)
  store i64 %t142, ptr %l94
  br label %bb40
bb38:
  %t143 = load { i64, i64 }, ptr %l82
  store { i64, i64 } %t143, ptr %l12
  %t144 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 0
  %t145 = load i64, ptr %t144, !tbaa !24
  %t147 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 1
  %t148 = load i64, ptr %t147, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load %"compiler/eval:Ptr", ptr %l2
  %t152 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrWide(ptr %v0, ptr %t150, %"compiler/eval:Ptr" %t151, i32 %t152, i64 %t145, i64 %t148)
  br label %bb39
bb39:
  br label %bb43
bb40:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l9, !tbaa !23
  %t162 = load i64, ptr %l10, !tbaa !24
  %t166 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecanonBits(ptr %v0, ptr %t160, i32 %t161, i64 %t162)
  store i64 %t166, ptr %l98
  br label %bb41
bb41:
  %t167 = load ptr, ptr %l90, !tbaa !29
  %t168 = load %"compiler/eval:Ptr", ptr %l91
  %t169 = load i64, ptr %l94, !tbaa !24
  %t170 = load i64, ptr %l98, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t167, %"compiler/eval:Ptr" %t168, i64 %t169, i64 %t170)
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb52
bb46:
  %t171 = load { i64, [4 x i64] }, ptr %l4
  %t173 = extractvalue { i64, [4 x i64] } %t171, 0
  %t174 = icmp eq i64 %t173, 3
  br i1 %t174, label %bb47, label %bb48
bb47:
  %t176 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t177 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t176, i32 0, i32 0
  %t178 = load i32, ptr %t177
  store i32 %t178, ptr %l15, !tbaa !23
  %t180 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t181 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t180, i32 0, i32 1
  %t182 = load i32, ptr %t181
  store i32 %t182, ptr %l16, !tbaa !23
  %t184 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t185 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t184, i32 0, i32 2
  %t186 = load i64, ptr %t185
  store i64 %t186, ptr %l17, !tbaa !24
  %t188 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t189 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t188, i32 0, i32 3
  %t190 = load %"compiler/source:Span", ptr %t189
  store %"compiler/source:Span" %t190, ptr %l18
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i64, ptr %l1, !tbaa !24
  %t194 = load %"compiler/eval:Ptr", ptr %l2
  %t195 = load i32, ptr %l15, !tbaa !23
  %t196 = load i32, ptr %l16, !tbaa !23
  %t197 = load i64, ptr %l17, !tbaa !24
  %t198 = load %"compiler/source:Span", ptr %l18
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputData(ptr %v0, ptr %t192, i64 %t193, %"compiler/eval:Ptr" %t194, i32 %t195, i32 %t196, i64 %t197, %"compiler/source:Span" %t198)
  br label %bb50
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_af1f9cfaa1609478_d5c4fc0e8d836404)
  unreachable
bb52:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputData(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, i32 %a4, i64 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca i64
  %l10 = alloca { %"compiler/eval:Ptr", i64 }
  %l11 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca ptr
  %l21 = alloca { i64, [1 x i64] }
  %l25 = alloca ptr
  %l26 = alloca %"compiler/eval:Ptr"
  %l29 = alloca i64
  %l37 = alloca { %"compiler/eval:Ptr", i64 }
  %l44 = alloca i64
  %l51 = alloca ptr
  %l55 = alloca %"compiler/eval:Ptr"
  %l66 = alloca ptr
  %l67 = alloca %"compiler/eval:Ptr"
  %l68 = alloca %"compiler/eval:Ptr"
  %l71 = alloca i64
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v0, ptr %t1, i64 %a1)
  store ptr %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l16, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 19
  %t10 = load i32, ptr %l4, !tbaa !23
  %t12 = sext i32 %t10 to i64
  %t15 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t9, i64 %t12)
  store { i64, [1 x i64] } %t15, ptr %l21
  br label %bb2
bb2:
  %t16 = load { i64, [1 x i64] }, ptr %l21
  store { i64, [1 x i64] } %t16, ptr %l8
  %t17 = load { i64, [1 x i64] }, ptr %l8
  %t19 = extractvalue { i64, [1 x i64] } %t17, 0
  %t20 = icmp eq i64 %t19, 0
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = getelementptr { i64, [1 x i64] }, ptr %l8, i32 0, i32 1
  %t23 = getelementptr { i64 }, ptr %t22, i32 0, i32 0
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l9, !tbaa !24
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l25, !tbaa !29
  %t27 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t27, ptr %l26
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t28, i32 %t29)
  store i64 %t32, ptr %l29
  br label %bb6
bb6:
  %t33 = load i64, ptr %l9, !tbaa !24
  %t34 = load ptr, ptr %l25, !tbaa !29
  %t35 = load %"compiler/eval:Ptr", ptr %l26
  %t36 = load i64, ptr %l29, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t34, %"compiler/eval:Ptr" %t35, i64 %t36, i64 %t33)
  br label %bb7
bb7:
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_12565802a2336670_a75db38aedd0e3fc)
  unreachable
bb13:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l7, !tbaa !29
  %t40 = load i32, ptr %l3, !tbaa !23
  %t41 = load i32, ptr %l4, !tbaa !23
  %t50 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2edataFor(ptr %v0, ptr %v0, ptr %t38, ptr %t39, i32 %t40, i32 %t41, i64 %a5, %"compiler/source:Span" %a6)
  store { %"compiler/eval:Ptr", i64 } %t50, ptr %l37
  br label %bb14
bb14:
  %t51 = load { %"compiler/eval:Ptr", i64 }, ptr %l37
  store { %"compiler/eval:Ptr", i64 } %t51, ptr %l10
  %t52 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l10, i32 0, i32 0
  %t53 = load %"compiler/eval:Ptr", ptr %t52
  store %"compiler/eval:Ptr" %t53, ptr %l11
  %t55 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l10, i32 0, i32 1
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l12, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/eval:Machine", ptr %t58, i32 0, i32 23
  %t61 = load i1, ptr %t60, !tbaa !21
  br i1 %t61, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l3, !tbaa !23
  %t67 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t63, i32 %t64)
  store i64 %t67, ptr %l44
  br label %bb18
bb18:
  %t68 = load i64, ptr %l44, !tbaa !24
  store i64 %t68, ptr %l13, !tbaa !24
  %t69 = load i64, ptr %l13, !tbaa !24
  %t70 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t73 = icmp eq i64 %t69, %t70
  br i1 %t73, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb25
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load %"compiler/eval:Ptr", ptr %l2
  %t77 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t75, %"compiler/eval:Ptr" %t76, i64 8, i64 %t77)
  br label %bb22
bb22:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l51, !tbaa !29
  %t82 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t85 = load i64, ptr %t84, !tbaa !24
  %t87 = add i64 %t85, 8
  %t90 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t83, i64 %t87)
  store %"compiler/eval:Ptr" %t90, ptr %l55
  br label %bb23
bb23:
  %t91 = load %"compiler/eval:Ptr", ptr %l11
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = load %"compiler/eval:Ptr", ptr %l55
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t92, %"compiler/eval:Ptr" %t93, %"compiler/eval:Ptr" %t91)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb42
bb25:
  %t95 = load i64, ptr %l13, !tbaa !24
  %t96 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  br i1 %t99, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load %"compiler/eval:Ptr", ptr %l2
  %t103 = load %"compiler/eval:Ptr", ptr %l11
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t101, %"compiler/eval:Ptr" %t102, %"compiler/eval:Ptr" %t103)
  br label %bb29
bb29:
  br label %bb42
bb30:
  %t107 = load i64, ptr %l13, !tbaa !24
  %t108 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  %t111 = icmp eq i64 %t107, %t108
  br i1 %t111, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l66, !tbaa !29
  %t114 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t114, ptr %l67
  %t115 = load %"compiler/eval:Ptr", ptr %l11
  store %"compiler/eval:Ptr" %t115, ptr %l68
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l3, !tbaa !23
  %t120 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t116, i32 %t117)
  store i64 %t120, ptr %l71
  br label %bb34
bb34:
  %t121 = load ptr, ptr %l66, !tbaa !29
  %t122 = load %"compiler/eval:Ptr", ptr %l67
  %t123 = load %"compiler/eval:Ptr", ptr %l68
  %t124 = load i64, ptr %l71, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t121, %"compiler/eval:Ptr" %t122, %"compiler/eval:Ptr" %t123, i64 %t124)
  br label %bb35
bb35:
  br label %bb42
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t127 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t127, ptr %t125, { i64, ptr } %t126)
  br label %bb40
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_1069159e4cdf0a01_3c7ea434b50ec3ad)
  unreachable
bb42:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputInt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca i32
  %l3 = alloca i64
  %l7 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"compiler/eval:Ptr"
  %l19 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t7 = load i64, ptr %l7, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load %"compiler/eval:Ptr", ptr %l1
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrWide(ptr %v0, ptr %t11, %"compiler/eval:Ptr" %t12, i32 %t13, i64 %t14, i64 %a4)
  br label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load %"compiler/eval:Ptr", ptr %l1
  store %"compiler/eval:Ptr" %t22, ptr %l16
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l2, !tbaa !23
  %t27 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t23, i32 %t24)
  store i64 %t27, ptr %l19
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t28 = load i64, ptr %l3, !tbaa !24
  store i64 %t28, ptr %l20, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l23
  br label %bb6
bb6:
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = call i64 @compiler_2feval_2ebmask(i64 %t34)
  store i64 %t35, ptr %l24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = and i64 %t36, %t37
  %t39 = load ptr, ptr %l15, !tbaa !29
  %t40 = load %"compiler/eval:Ptr", ptr %l16
  %t41 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t39, %"compiler/eval:Ptr" %t40, i64 %t41, i64 %t38)
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeReady(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca i64
  %l44 = alloca { i64, [4 x i64] }
  %l45 = alloca i1
  %rv = alloca i1
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l4, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t4 = load i32, ptr %l5, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l5, !tbaa !23
  %t15 = load i32, ptr %l4, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l6, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l6, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l17, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l17, !tbaa !23
  store i32 %t30, ptr %l14, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l14, !tbaa !23
  store i32 %t31, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = load i32, ptr %l7, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l4, !tbaa !23
  %t41 = load i32, ptr %l8, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  store ptr %a0, ptr %l35, !tbaa !29
  store i64 %a1, ptr %l36, !tbaa !24
  %t54 = getelementptr %"compiler/mir:Fn", ptr %a2, i32 0, i32 11
  %t55 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 0
  %t56 = load i32, ptr %t55, !tbaa !23
  %t58 = sext i32 %t56 to i64
  %t61 = sext i32 %t48 to i64
  %t64 = add i64 %t58, %t61
  %t67 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v1, ptr %t54, i64 %t64)
  store { i64, [4 x i64] } %t67, ptr %l44
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = load i64, ptr %l36, !tbaa !24
  %t70 = load { i64, [4 x i64] }, ptr %l44
  %t71 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t68, i64 %t69, { i64, [4 x i64] } %t70)
  store i1 %t71, ptr %l45
  br label %bb12
bb12:
  %t72 = load i1, ptr %l45, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t76 = load i32, ptr %l8, !tbaa !23
  %t79 = add i32 %t76, 1
  store i32 %t79, ptr %l8, !tbaa !23
  br label %bb7
bb17:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l14 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i64, ptr %l2, !tbaa !24
  %t7 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i64 %t3, i1 false)
  store i64 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t20 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t14, i64 %t15, i64 %t16)
  store i64 %t20, ptr %l14
  br label %bb5
bb5:
  %t21 = load i64, ptr %l14, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l25 = alloca i1
  %l33 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i64 8, i1 false)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/eval:Ptr" %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t13, i64 %t14, i64 8)
  store i64 %t17, ptr %l13
  br label %bb5
bb5:
  %t18 = load i64, ptr %l13, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = srem i64 %t19, 8
  %t23 = icmp eq i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 47
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = sdiv i64 %t29, 8
  %t33 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i64, ptr %t34, i64 %t31
  %t36 = load i64, ptr %t35, !tbaa !34
  store i64 %t36, ptr %l17, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l17, !tbaa !24
  store i64 %t38, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp eq i64 %t39, 0
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp ne i64 %t43, 0
  store i1 %t45, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l25, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t50 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t50, ptr %t48, { i64, ptr } %t49)
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t53 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/eval:Ptr" %t53, ptr %rv
  br label %ret
bb15:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t56 = load i64, ptr %l3, !tbaa !24
  %t59 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t55, i64 %t56)
  store %"compiler/eval:Ptr" %t59, ptr %l33
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load %"compiler/eval:Ptr", ptr %l33
  store %"compiler/eval:Ptr" %t60, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i64 8, i1 false)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/eval:Ptr" %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = srem i64 %t13, 8
  %t17 = icmp eq i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 47
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l14, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = sdiv i64 %t23, 8
  %t27 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  store i64 %t30, ptr %l12, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t32, i64 %t33, i64 8)
  store i64 %t36, ptr %l20
  br label %bb8
bb8:
  %t37 = load i64, ptr %l12, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t37, i64 %t38)
  store %"compiler/eval:Ptr" %t39, ptr %l21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load %"compiler/eval:Ptr", ptr %l21
  store %"compiler/eval:Ptr" %t40, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l12 = alloca i1
  %l16 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l37 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l48 = alloca { i64, ptr }
  %l51 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = ashr i64 %t1, 3
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = and i64 %t5, 7
  store i64 %t7, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp eq i64 %t13, 8
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l12, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/eval:Machine", ptr %t18, i32 0, i32 46
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i64, ptr %t25, i64 %t22
  %t27 = load i64, ptr %t26, !tbaa !34
  store i64 %t27, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = icmp sle i64 %t33, 8
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/eval:Machine", ptr %t37, i32 0, i32 46
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l24, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i64, ptr %t44, i64 %t41
  %t46 = load i64, ptr %t45, !tbaa !34
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 8, %t47
  store i64 %t49, ptr %l28, !tbaa !24
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = ashr i64 %t46, %t52
  store i64 %t53, ptr %l29, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l2, !tbaa !24
  %t58 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t54, i64 %t55)
  store i64 %t58, ptr %l32
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t59 = load i64, ptr %l29, !tbaa !24
  %t60 = load i64, ptr %l32, !tbaa !24
  %t61 = and i64 %t59, %t60
  store i64 %t61, ptr %rv
  br label %ret
bb10:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = sub i64 8, %t63
  store i64 %t65, ptr %l5, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/eval:Machine", ptr %t67, i32 0, i32 46
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l37, !tbaa !27
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i64, ptr %t74, i64 %t71
  %t76 = load i64, ptr %t75, !tbaa !34
  %t77 = load i64, ptr %l4, !tbaa !24
  %t79 = mul i64 8, %t77
  store i64 %t79, ptr %l41, !tbaa !24
  %t81 = load i64, ptr %l41, !tbaa !24
  %t82 = load i64, ptr %l41, !tbaa !24
  %t83 = ashr i64 %t76, %t82
  store i64 %t83, ptr %l42, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t84, i64 %t85)
  store i64 %t88, ptr %l45
  br label %bb11
bb11:
  %t89 = load i64, ptr %l42, !tbaa !24
  %t90 = load i64, ptr %l45, !tbaa !24
  %t91 = and i64 %t89, %t90
  store i64 %t91, ptr %l46, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/eval:Machine", ptr %t92, i32 0, i32 46
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l48, !tbaa !27
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = add i64 %t96, 1
  %t100 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i64, ptr %t101, i64 %t98
  %t103 = load i64, ptr %t102, !tbaa !34
  store i64 %t103, ptr %l51, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i64, ptr %l2, !tbaa !24
  %t106 = load i64, ptr %l5, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t112 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t104, i64 %t109)
  store i64 %t112, ptr %l56
  br label %bb12
bb12:
  %t113 = load i64, ptr %l51, !tbaa !24
  %t114 = load i64, ptr %l56, !tbaa !24
  %t115 = and i64 %t113, %t114
  %t116 = load i64, ptr %l5, !tbaa !24
  %t118 = mul i64 8, %t116
  store i64 %t118, ptr %l59, !tbaa !24
  %t120 = load i64, ptr %l59, !tbaa !24
  %t121 = load i64, ptr %l59, !tbaa !24
  %t122 = shl i64 %t115, %t121
  %t123 = load i64, ptr %l46, !tbaa !24
  %t125 = or i64 %t123, %t122
  store i64 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2erdWide(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca i32
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l12 = alloca %"compiler/eval:Ptr"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i1
  %l26 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i1
  %l33 = alloca { i64, i64 }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/eval:Ptr", ptr %l1
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %t2, i64 8)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l8, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = add i64 %t11, 8
  %t16 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t9, i64 %t13)
  store %"compiler/eval:Ptr" %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = load %"compiler/eval:Ptr", ptr %l12
  %t19 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t17, %"compiler/eval:Ptr" %t18, i64 8)
  store i64 %t19, ptr %l13
  br label %bb3
bb3:
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  store i64 %t21, ptr %l14, !tbaa !24
  store i64 %t20, ptr %l15, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l2, !tbaa !23
  %t27 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t23, i32 %t24)
  store i64 %t27, ptr %l18
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t28, i32 %t29)
  store i64 %t32, ptr %l21
  br label %bb5
bb5:
  %t33 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t34 = load i64, ptr %l21, !tbaa !24
  %t36 = icmp ne i64 %t34, %t33
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l26, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l30
  br label %bb8
bb7:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb10
bb8:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i32, ptr %l30, !tbaa !23
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t52, ptr %l31
  br label %bb9
bb9:
  %t53 = load i1, ptr %l31, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l24, !tbaa !21
  br label %bb10
bb10:
  %t56 = load i64, ptr %l14, !tbaa !24
  %t57 = load i64, ptr %l15, !tbaa !24
  %t58 = load i64, ptr %l18, !tbaa !24
  %t59 = load i1, ptr %l24, !tbaa !21
  %t60 = call { i64, i64 } @compiler_2feval_2eextend128(i64 %t56, i64 %t57, i64 %t58, i1 %t59)
  store { i64, i64 } %t60, ptr %l33
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load { i64, i64 }, ptr %l33
  store { i64, i64 } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erecode(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l13 = alloca { i64, ptr }
  %l19 = alloca i1
  %l30 = alloca { i64, ptr }
  %l35 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t9, i32 %a2)
  store { i64, ptr } %t13, ptr %l13
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = ashr i64 %t15, 16
  %t19 = sub i64 %t17, 1
  store i64 %t19, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb7
bb6:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp sge i64 %t25, %t28
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t36 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t36, ptr %t34, { i64, ptr } %t35)
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i64 0, ptr %rv
  br label %ret
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/eval:Machine", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l30, !tbaa !27
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i32, ptr %t49, i64 %t46
  %t51 = load i32, ptr %t50, !tbaa !33
  %t52 = load i64, ptr %l1, !tbaa !24
  %t54 = and i64 %t52, 65535
  %t59 = call i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %t43, i32 %a3, i32 %t51, i64 %t54)
  store i64 %t59, ptr %l35
  br label %bb12
bb12:
  %t60 = load i64, ptr %l35, !tbaa !24
  store i64 %t60, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp slt i64 %t61, 0
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t67 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t67, ptr %t65, { i64, ptr } %t66)
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i64 0, ptr %rv
  br label %ret
bb16:
  %t71 = load i64, ptr %l6, !tbaa !24
  store i64 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %t11 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/eval:Machine", ptr %t3, i32 0, i32 78
  %t6 = load i64, ptr %t5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 79
  %t10 = load %"compiler/source:Span", ptr %t9
  store { i64, [5 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 0
  store i64 3, ptr %t12
  %t14 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %a1, 0
  %t16 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t14, i64 %t6, 1
  %t18 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t16, %"compiler/source:Span" %t10, 2
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t18, ptr %t19
  %t20 = load { i64, [5 x i64] }, ptr %t11
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estop(ptr %v0, ptr %v0, ptr %t1, { i64, [5 x i64] } %t20)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eregion(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l7 = alloca i64
  %l16 = alloca %"compiler/eval:scope"
  %l26 = alloca ptr
  %rv = alloca i64
  %t21 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eadopt(ptr %v0, ptr %t7, i64 %t8, i64 %t9)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 53
  %t16 = load i64, ptr %l1, !tbaa !24
  %t17 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t20 = and i64 %t16, %t17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t21, ptr %v0, ptr %t15, i64 %t20)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t21, i64 152, i1 false)
  br label %bb3
bb3:
  %t24 = getelementptr %"compiler/eval:scope", ptr %l16, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t29 = icmp ne i64 %t25, %t26
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t35 = and i64 %t31, %t32
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/eval:Machine", ptr %t37, i32 0, i32 53
  %t43 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t39, i64 %t35)
  store ptr %t43, ptr %l26
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t46 = load i64, ptr %l1, !tbaa !24
  %t49 = getelementptr %"compiler/eval:scope", ptr %t44, i32 0, i32 16
  store i64 %t46, ptr %t49, !tbaa !24
  br label %bb7
bb7:
  %t50 = load i64, ptr %l2, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eregionOfObject(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca i64
  %l3 = alloca i64
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l20 = alloca i64
  %l25 = alloca { i64, ptr }
  %l30 = alloca i1
  %l32 = alloca i1
  %l38 = alloca %"compiler/eval:scope"
  %rv = alloca i64
  %t75 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t4 = icmp eq i64 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t12 = and i64 %t8, %t9
  store i64 %t12, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:Machine", ptr %t15, i32 0, i32 51
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = icmp sge i64 %t14, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 50
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l16, !tbaa !27
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr %"compiler/eval:alloc", ptr %t30, i64 %t27
  %t32 = getelementptr %"compiler/eval:alloc", ptr %t31, i32 0, i32 3
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t36, ptr %l20, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = load i64, ptr %l20, !tbaa !24
  %t40 = ashr i64 %t35, %t39
  %t43 = icmp ne i64 %t33, %t40
  store i1 %t43, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t45 = load i1, ptr %l14, !tbaa !21
  br i1 %t45, label %bb7, label %bb8
bb7:
  store i64 0, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t47, i32 0, i32 50
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l25, !tbaa !27
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr %"compiler/eval:alloc", ptr %t54, i64 %t51
  %t56 = getelementptr %"compiler/eval:alloc", ptr %t55, i32 0, i32 5
  %t57 = load i64, ptr %t56, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i64, ptr %l3, !tbaa !24
  %t63 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t59, i64 %t60)
  store i1 %t63, ptr %l30
  br label %bb10
bb10:
  %t64 = load i1, ptr %l30, !tbaa !21
  %t65 = xor i1 %t64, true
  br i1 %t65, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb14
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/eval:Machine", ptr %t67, i32 0, i32 53
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t74 = and i64 %t70, %t71
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t75, ptr %v0, ptr %t69, i64 %t74)
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t75, i64 152, i1 false)
  br label %bb13
bb13:
  %t78 = getelementptr %"compiler/eval:scope", ptr %l38, i32 0, i32 2
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t83 = icmp ne i64 %t79, %t80
  store i1 %t83, ptr %l32, !tbaa !21
  br label %bb14
bb14:
  %t85 = load i1, ptr %l32, !tbaa !21
  br i1 %t85, label %bb15, label %bb16
bb15:
  store i64 0, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t87 = load i64, ptr %l3, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:alloc"
  %l3 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l17 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i1
  %l80 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l112 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 50
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l17, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:alloc", ptr %t8, i64 %t5
  %t10 = load %"compiler/eval:alloc", ptr %t9
  store %"compiler/eval:alloc" %t10, ptr %l2
  %t12 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 4
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  br i1 %t17, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t19 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 5
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = icmp ne i64 %t20, 0
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 5
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t29 = and i64 %t25, %t26
  store i64 %t29, ptr %l3, !tbaa !24
  %t31 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 6
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp ne i64 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb5:
  br label %bb13
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/eval:Machine", ptr %t36, i32 0, i32 50
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l31, !tbaa !27
  %t40 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 6
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 7
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr %"compiler/eval:alloc", ptr %t47, i64 %t41
  %t49 = getelementptr %"compiler/eval:alloc", ptr %t48, i32 0, i32 7
  store i64 %t43, ptr %t49, !tbaa !24
  br label %bb9
bb7:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 7
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l5, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/eval:Machine", ptr %t55, i32 0, i32 53
  %t61 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t57, i64 %t50)
  store ptr %t61, ptr %l39
  br label %bb8
bb8:
  %t62 = load ptr, ptr %l39, !tbaa !29
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = getelementptr %"compiler/eval:scope", ptr %t62, i32 0, i32 3
  store i64 %t64, ptr %t67, !tbaa !24
  br label %bb9
bb9:
  %t68 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 7
  %t69 = load i64, ptr %t68, !tbaa !24
  %t71 = icmp ne i64 %t69, 0
  br i1 %t71, label %bb10, label %bb11
bb10:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/eval:Machine", ptr %t73, i32 0, i32 50
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l45, !tbaa !27
  %t77 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 7
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 6
  %t80 = load i64, ptr %t79, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr %"compiler/eval:alloc", ptr %t84, i64 %t78
  %t86 = getelementptr %"compiler/eval:alloc", ptr %t85, i32 0, i32 6
  store i64 %t80, ptr %t86, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  store i64 0, ptr %l7, !tbaa !24
  %t87 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = add i64 %t88, 7
  %t92 = sdiv i64 %t90, 8
  store i64 %t92, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb14, label %bb15
bb14:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb19
bb16:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l57, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb18
bb18:
  %t120 = load i64, ptr %l57, !tbaa !24
  store i64 %t120, ptr %l54, !tbaa !24
  br label %bb19
bb19:
  %t121 = load i64, ptr %l54, !tbaa !24
  store i64 %t121, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = sub i64 %t122, 1
  store i64 %t123, ptr %l66, !tbaa !24
  %t124 = load i64, ptr %l10, !tbaa !24
  %t125 = icmp slt i64 %t124, 2147483648
  %t126 = load i64, ptr %l11, !tbaa !24
  %t127 = icmp sge i64 %t126, 0
  %t130 = and i1 %t125, %t127
  store i1 %t130, ptr %l69, !tbaa !21
  br label %bb20
bb20:
  %t131 = load i64, ptr %l11, !tbaa !24
  %t132 = load i64, ptr %l10, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  br label %bb23
bb23:
  %t139 = load i64, ptr %l7, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = mul i64 %t140, %t141
  %t147 = add i64 %t139, %t144
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/eval:Machine", ptr %t149, i32 0, i32 47
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  store { i64, ptr } %t152, ptr %l80, !tbaa !27
  %t153 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 0
  %t154 = load i64, ptr %t153, !tbaa !24
  %t156 = sdiv i64 %t154, 8
  %t160 = add i64 %t156, %t147
  %t162 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i64, ptr %t163, i64 %t160
  store i64 0, ptr %t164, !tbaa !34
  br label %bb24
bb24:
  %t165 = load i64, ptr %l11, !tbaa !24
  %t168 = add i64 %t165, 1
  store i64 %t168, ptr %l11, !tbaa !24
  br label %bb20
bb25:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 0
  %t172 = load i64, ptr %t171, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/eval:Machine", ptr %t173, i32 0, i32 49
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  store { i64, ptr } %t176, ptr %l91, !tbaa !27
  %t177 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 2
  %t178 = load i64, ptr %t177, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i64, ptr %t181, i64 %t178
  %t183 = load i64, ptr %t182, !tbaa !34
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t170, i64 %t172, i64 8, i64 %t183)
  br label %bb26
bb26:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/eval:Machine", ptr %t187, i32 0, i32 49
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l95, !tbaa !27
  %t191 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 2
  %t192 = load i64, ptr %t191, !tbaa !24
  %t193 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 0
  %t194 = load i64, ptr %t193, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr i64, ptr %t198, i64 %t192
  store i64 %t194, ptr %t199, !tbaa !34
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l98, !tbaa !29
  %t201 = load ptr, ptr %l98, !tbaa !29
  %t202 = getelementptr %"compiler/eval:Machine", ptr %t201, i32 0, i32 16
  %t203 = load i64, ptr %t202, !tbaa !24
  %t205 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 1
  %t206 = load i64, ptr %t205, !tbaa !24
  %t209 = sub i64 %t203, %t206
  %t211 = load ptr, ptr %l98, !tbaa !29
  %t212 = getelementptr %"compiler/eval:Machine", ptr %t211, i32 0, i32 16
  store i64 %t209, ptr %t212, !tbaa !24
  %t213 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t215 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 4
  store i64 %t213, ptr %t215, !tbaa !24
  %t216 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 3
  %t217 = load i64, ptr %t216, !tbaa !24
  %t220 = add i64 %t217, 1
  %t222 = and i64 %t220, 274877906943
  %t224 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 3
  store i64 %t222, ptr %t224, !tbaa !24
  %t227 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 5
  store i64 0, ptr %t227, !tbaa !24
  %t230 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 6
  store i64 0, ptr %t230, !tbaa !24
  %t233 = getelementptr %"compiler/eval:alloc", ptr %l2, i32 0, i32 7
  store i64 0, ptr %t233, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/eval:Machine", ptr %t234, i32 0, i32 50
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  store { i64, ptr } %t237, ptr %l112, !tbaa !27
  %t238 = load i64, ptr %l1, !tbaa !24
  %t239 = load %"compiler/eval:alloc", ptr %l2
  %t242 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = getelementptr %"compiler/eval:alloc", ptr %t243, i64 %t238
  store %"compiler/eval:alloc" %t239, ptr %t244
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/eval:Machine", ptr %t245, i32 0, i32 52
  %t248 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t247, i64 %t248)
  br label %bb27
bb27:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ertArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i1
  %l17 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l10
  br label %bb2
bb2:
  %t18 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t20 = trunc i64 19 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l17
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t31 = load i32, ptr %l17, !tbaa !23
  %t32 = icmp eq i32 %t31, 0
  store i1 %t32, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l13, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2erunCleanups(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [5 x i64] }
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l35 = alloca i64
  %l39 = alloca i1
  %l43 = alloca i64
  %l50 = alloca i64
  %l63 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %t141 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 21
  %t4 = load { i64, [5 x i64] }, ptr %t3
  store { i64, [5 x i64] } %t4, ptr %l2
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 93
  %t9 = load i64, ptr %t8, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t11, i32 0, i32 94
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l4
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 60
  %t19 = load i64, ptr %t18, !tbaa !24
  %t23 = icmp sgt i64 %t19, %a1
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb2, label %bb3
bb2:
  br label %bb33
bb3:
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/eval:Machine", ptr %t27, i32 0, i32 60
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = sub i64 %t30, 1
  store i64 %t32, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/eval:Machine", ptr %t34, i32 0, i32 67
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l35
  br label %bb5
bb5:
  %t39 = load i64, ptr %l35, !tbaa !24
  %t40 = sub i64 %t39, 1
  store i64 %t40, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb9
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/eval:Machine", ptr %t46, i32 0, i32 67
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t48, i64 %t49)
  store i64 %t52, ptr %l43
  br label %bb8
bb8:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l43, !tbaa !24
  %t56 = icmp ne i64 %t54, %t53
  store i1 %t56, ptr %l39, !tbaa !21
  br label %bb9
bb9:
  %t58 = load i1, ptr %l39, !tbaa !21
  br i1 %t58, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropFrame(ptr %v0, ptr %t59)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb32
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/eval:Machine", ptr %t61, i32 0, i32 69
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  store i64 %t67, ptr %l50
  br label %bb14
bb14:
  %t68 = load i64, ptr %l50, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/eval:Machine", ptr %t69, i32 0, i32 67
  %t72 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t71, i64 %t72)
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/eval:Machine", ptr %t75, i32 0, i32 68
  %t78 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t77, i64 %t78)
  br label %bb16
bb16:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/eval:Machine", ptr %t81, i32 0, i32 69
  %t84 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t83, i64 %t84)
  br label %bb17
bb17:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/eval:Machine", ptr %t87, i32 0, i32 63
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/eval:Machine", ptr %t90, i32 0, i32 59
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l63, !tbaa !27
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr %"compiler/eval:frame", ptr %t97, i64 %t94
  %t99 = getelementptr %"compiler/eval:frame", ptr %t98, i32 0, i32 9
  %t100 = load i64, ptr %t99, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t89, i64 %t100)
  br label %bb18
bb18:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/eval:Machine", ptr %t105, i32 0, i32 59
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l68, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr %"compiler/eval:frame", ptr %t114, i64 %t109
  %t116 = getelementptr %"compiler/eval:frame", ptr %t115, i32 0, i32 1
  store i64 %t103, ptr %t116, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/eval:Machine", ptr %t117, i32 0, i32 59
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l72, !tbaa !27
  %t121 = load i64, ptr %l5, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr %"compiler/eval:frame", ptr %t126, i64 %t121
  %t128 = getelementptr %"compiler/eval:frame", ptr %t127, i32 0, i32 2
  store i64 0, ptr %t128, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/eval:Machine", ptr %t129, i32 0, i32 59
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l76, !tbaa !27
  %t133 = load i64, ptr %l5, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/eval:frame", ptr %t138, i64 %t133
  %t140 = getelementptr %"compiler/eval:frame", ptr %t139, i32 0, i32 10
  store i1 false, ptr %t140, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 0
  store i64 0, ptr %t142
  %t143 = load { i64, [5 x i64] }, ptr %t141
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/eval:Machine", ptr %t145, i32 0, i32 23
  store i1 false, ptr %t149, !tbaa !21
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/eval:Machine", ptr %t150, i32 0, i32 70
  store i1 false, ptr %t154, !tbaa !21
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/eval:Machine", ptr %t155, i32 0, i32 21
  store { i64, [5 x i64] } %t143, ptr %t159
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %t160, i64 %t161)
  br label %bb19
bb19:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/eval:Machine", ptr %t164, i32 0, i32 70
  %t167 = load i1, ptr %t166, !tbaa !21
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb20, label %bb21
bb20:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/eval:Machine", ptr %t171, i32 0, i32 21
  %t174 = load { i64, [5 x i64] }, ptr %t173
  %t178 = extractvalue { i64, [5 x i64] } %t174, 0
  %t179 = icmp eq i64 %t178, 2
  br i1 %t179, label %bb22, label %bb23
bb21:
  br label %bb31
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/eval:Machine", ptr %t181, i32 0, i32 21
  %t184 = load { i64, [5 x i64] }, ptr %t183
  store { i64, [5 x i64] } %t184, ptr %l2
  br label %bb33
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_26a77dbb944b4c43_3cbd97c51474f5af)
  unreachable
bb30:
  br label %bb31
bb31:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/eval:Machine", ptr %t186, i32 0, i32 70
  store i1 false, ptr %t188, !tbaa !21
  br label %bb32
bb32:
  br label %bb1
bb33:
  %t189 = load { i64, [5 x i64] }, ptr %l2
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/eval:Machine", ptr %t191, i32 0, i32 23
  store i1 true, ptr %t195, !tbaa !21
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/eval:Machine", ptr %t196, i32 0, i32 21
  store { i64, [5 x i64] } %t189, ptr %t200
  %t201 = load i64, ptr %l3, !tbaa !24
  %t203 = load %"compiler/source:Span", ptr %l4
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/eval:Machine", ptr %t205, i32 0, i32 93
  store i64 %t201, ptr %t209, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/eval:Machine", ptr %t210, i32 0, i32 94
  store %"compiler/source:Span" %t203, ptr %t214
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2erunDtor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/eval:Ptr" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, [2 x i64] }
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i32
  %l24 = alloca i64
  %l32 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l48 = alloca i32
  %l49 = alloca %"compiler/eval:Ptr"
  %l53 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l79 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l85 = alloca i64
  %l89 = alloca { i64, [1 x i64] }
  %l92 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 38
  %t7 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Ha5986096190b27059e1b255ecbd90571(ptr %v0, ptr %t3, i32 %a2)
  %t8 = extractvalue { i32, { i64, [2 x i64] } } %t7, 1
  %t9 = extractvalue { i32, { i64, [2 x i64] } } %t7, 0
  store i32 %t9, ptr %l19
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store { i64, [2 x i64] } %t8, ptr %l18
  br label %bb1
bb1:
  %t12 = load { i64, [2 x i64] }, ptr %l18
  store { i64, [2 x i64] } %t12, ptr %l14
  br label %bb5
bb2:
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t15 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t15, ptr %t13, { i64, ptr } %t14)
  br label %bb4
bb4:
  br label %ret
bb5:
  %t18 = load { i64, [2 x i64] }, ptr %l14
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t23 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t19, { i64, [2 x i64] } %t18)
  store i64 %t23, ptr %l24
  br label %bb6
bb6:
  %t24 = load i64, ptr %l24, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t31 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t31, ptr %t29, { i64, ptr } %t30)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %ret
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr @G_2ecompiler_2feval_2erDtor, !tbaa !24
  %t40 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %t34, i64 %t35, i64 %t36, i64 0)
  store i64 %t40, ptr %l32
  br label %bb11
bb11:
  %t41 = load i64, ptr %l32, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  br i1 %t44, label %bb12, label %bb13
bb12:
  br label %ret
bb13:
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/eval:Machine", ptr %t46, i32 0, i32 26
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store ptr %t52, ptr %l38
  br label %bb15
bb15:
  %t53 = load ptr, ptr %l38, !tbaa !29
  store ptr %t53, ptr %l7, !tbaa !29
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t56 = getelementptr %"compiler/mir:Fn", ptr %t54, i32 0, i32 4
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l41
  br label %bb16
bb16:
  %t59 = load i64, ptr %l41, !tbaa !24
  %t60 = icmp sgt i64 %t59, 0
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l43, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l44, !tbaa !29
  %t64 = load i64, ptr %l6, !tbaa !24
  store i64 %t64, ptr %l45, !tbaa !24
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t67 = getelementptr %"compiler/mir:Fn", ptr %t65, i32 0, i32 4
  %t69 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t67, i64 0)
  store i32 %t69, ptr %l48
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t70 = load ptr, ptr %l44, !tbaa !29
  %t71 = load i64, ptr %l45, !tbaa !24
  %t72 = load i32, ptr %l48, !tbaa !23
  %t73 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t70, i64 %t71, i32 %t72)
  store %"compiler/eval:Ptr" %t73, ptr %l49
  br label %bb20
bb20:
  %t75 = load ptr, ptr %l43, !tbaa !29
  %t76 = load %"compiler/eval:Ptr", ptr %l49
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t75, %"compiler/eval:Ptr" %t76, %"compiler/eval:Ptr" %a3)
  br label %bb21
bb21:
  br label %bb22
bb22:
  store i64 0, ptr %l8, !tbaa !24
  %t78 = load ptr, ptr %l7, !tbaa !29
  %t80 = getelementptr %"compiler/mir:Fn", ptr %t78, i32 0, i32 6
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t80)
  store i64 %t82, ptr %l53
  br label %bb23
bb23:
  %t83 = load i64, ptr %l53, !tbaa !24
  store i64 %t83, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = icmp sgt i64 %t84, %t85
  br i1 %t88, label %bb24, label %bb25
bb24:
  %t90 = load i64, ptr %l10, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb29
bb26:
  %t94 = load i64, ptr %l9, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = add i64 %t98, %t99
  %t104 = sub i64 %t102, 1
  %t105 = load i64, ptr %l10, !tbaa !24
  %t108 = sdiv i64 %t104, %t105
  store i64 %t108, ptr %l60, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb28
bb28:
  %t110 = load i64, ptr %l60, !tbaa !24
  store i64 %t110, ptr %l57, !tbaa !24
  br label %bb29
bb29:
  %t111 = load i64, ptr %l57, !tbaa !24
  store i64 %t111, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb30
bb30:
  %t112 = load i64, ptr %l12, !tbaa !24
  %t113 = load i64, ptr %l11, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb31, label %bb32
bb31:
  br label %bb39
bb32:
  br label %bb33
bb33:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t121 = load i64, ptr %l12, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t125 = mul i64 %t121, %t122
  %t128 = add i64 %t120, %t125
  store i64 %t128, ptr %l13, !tbaa !24
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/eval:Machine", ptr %t130, i32 0, i32 61
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l79, !tbaa !27
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/eval:Machine", ptr %t134, i32 0, i32 59
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l81, !tbaa !27
  %t138 = load i64, ptr %l6, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr %"compiler/eval:frame", ptr %t141, i64 %t138
  %t143 = getelementptr %"compiler/eval:frame", ptr %t142, i32 0, i32 5
  %t144 = load i64, ptr %t143, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t148 = add i64 %t144, %t145
  store i64 %t148, ptr %l85, !tbaa !24
  %t149 = load ptr, ptr %l7, !tbaa !29
  %t151 = getelementptr %"compiler/mir:Fn", ptr %t149, i32 0, i32 6
  %t152 = load i64, ptr %l13, !tbaa !24
  %t155 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t151, i64 %t152)
  store { i64, [1 x i64] } %t155, ptr %l89
  br label %bb34
bb34:
  %t156 = load { i64, [1 x i64] }, ptr %l89
  %t158 = extractvalue { i64, [1 x i64] } %t156, 0
  %t159 = icmp eq i64 %t158, 5
  br i1 %t159, label %bb35, label %bb36
bb35:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb37
bb36:
  store i64 %a1, ptr %l92, !tbaa !24
  br label %bb37
bb37:
  %t163 = load i64, ptr %l92, !tbaa !24
  %t164 = load i64, ptr %l85, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i64, ptr %t166, i64 %t164
  store i64 %t163, ptr %t167, !tbaa !34
  br label %bb38
bb38:
  %t168 = load i64, ptr %l12, !tbaa !24
  %t171 = add i64 %t168, 1
  store i64 %t171, ptr %l12, !tbaa !24
  br label %bb30
bb39:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2esaveAlloc(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/eval:alloc"
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l17 = alloca { i64, ptr }
  %l25 = alloca i1
  %l28 = alloca i64
  %l35 = alloca i1
  %l41 = alloca i1
  %l47 = alloca i1
  %l53 = alloca i64
  %rv = alloca { i32, i64 }
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Snapshot", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l12
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l11
  br label %bb1
bb1:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l7, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = insertvalue { i32, i64 } zeroinitializer, i64 %t18, 1
  store { i32, i64 } %t20, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 50
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l1, !tbaa !24
  %t26 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t29 = and i64 %t25, %t26
  %t31 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/eval:alloc", ptr %t32, i64 %t29
  %t34 = load %"compiler/eval:alloc", ptr %t33
  store %"compiler/eval:alloc" %t34, ptr %l5
  %t36 = getelementptr %"compiler/eval:alloc", ptr %l5, i32 0, i32 4
  %t37 = load i64, ptr %t36, !tbaa !24
  %t38 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t41 = icmp eq i64 %t37, %t38
  br i1 %t41, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb10
bb9:
  %t43 = getelementptr %"compiler/eval:alloc", ptr %l5, i32 0, i32 3
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr %l1, !tbaa !24
  %t46 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t46, ptr %l28, !tbaa !24
  %t48 = load i64, ptr %l28, !tbaa !24
  %t49 = load i64, ptr %l28, !tbaa !24
  %t50 = ashr i64 %t45, %t49
  %t53 = icmp ne i64 %t44, %t50
  store i1 %t53, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l25, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t57 = insertvalue { i32, i64 } zeroinitializer, i32 65539, 0
  store { i32, i64 } %t57, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t58 = getelementptr %"compiler/eval:alloc", ptr %l5, i32 0, i32 4
  %t59 = load i64, ptr %t58, !tbaa !24
  %t60 = load i64, ptr @G_2ecompiler_2feval_2eaCode, !tbaa !24
  %t63 = icmp eq i64 %t59, %t60
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb16
bb15:
  %t65 = getelementptr %"compiler/eval:alloc", ptr %l5, i32 0, i32 15
  %t66 = load i1, ptr %t65, !tbaa !21
  store i1 %t66, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t68 = load i1, ptr %l35, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t70, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t71 = getelementptr %"compiler/eval:alloc", ptr %l5, i32 0, i32 4
  %t72 = load i64, ptr %t71, !tbaa !24
  %t73 = load i64, ptr @G_2ecompiler_2feval_2eaGlobal, !tbaa !24
  %t76 = icmp eq i64 %t72, %t73
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t80 = xor i1 %a3, true
  store i1 %t80, ptr %l41, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t82 = load i1, ptr %l41, !tbaa !21
  br i1 %t82, label %bb23, label %bb24
bb23:
  %t84 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t84, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t85 = getelementptr %"compiler/eval:alloc", ptr %l5, i32 0, i32 11
  %t86 = load i32, ptr %t85, !tbaa !23
  %t88 = icmp ne i32 %t86, 0
  br i1 %t88, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb28
bb27:
  %t90 = getelementptr %"compiler/eval:alloc", ptr %l5, i32 0, i32 10
  %t91 = load i64, ptr %t90, !tbaa !24
  %t93 = icmp ne i64 %t91, 0
  store i1 %t93, ptr %l47, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l47, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t97 = insertvalue { i32, i64 } zeroinitializer, i32 65537, 0
  store { i32, i64 } %t97, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/eval:Snapshot", ptr %t98, i32 0, i32 1
  %t102 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t100)
  store i64 %t102, ptr %l53
  br label %bb32
bb32:
  %t103 = load i64, ptr %l53, !tbaa !24
  store i64 %t103, ptr %l6, !tbaa !24
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t106 = getelementptr %"compiler/eval:Snapshot", ptr %t104, i32 0, i32 5
  %t107 = load i64, ptr %l1, !tbaa !24
  %t108 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v1, ptr %t106, i64 %t107, i64 %t108)
  br label %bb33
bb33:
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t114 = getelementptr %"compiler/eval:Snapshot", ptr %t112, i32 0, i32 1
  %t115 = load i64, ptr %l1, !tbaa !24
  %t117 = sub i64 0, %t115
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t114, i64 %t117)
  br label %bb34
bb34:
  %t120 = load i64, ptr %l6, !tbaa !24
  %t122 = insertvalue { i32, i64 } zeroinitializer, i64 %t120, 1
  store { i32, i64 } %t122, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/mir:Lvalue"
  %l6 = alloca i64
  %l7 = alloca { %"compiler/eval:Ptr", i32 }
  %l20 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i1
  %l31 = alloca ptr
  %l37 = alloca %"compiler/eval:Ptr"
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l53 = alloca { %"compiler/eval:Ptr", i32 }
  %l56 = alloca ptr
  %l57 = alloca %"compiler/eval:Ptr"
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca ptr
  %l66 = alloca %"compiler/eval:Ptr"
  %l67 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i64
  %l73 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i64 0, ptr %rv
  br label %ret
bb4:
  %t7 = load { i64, [4 x i64] }, ptr %l2
  %t9 = extractvalue { i64, [4 x i64] } %t7, 0
  %t10 = icmp eq i64 %t9, 2
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t13 = getelementptr { i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t17 = getelementptr { i32, i64 }, ptr %t16, i32 0, i32 1
  %t18 = load i64, ptr %t17
  store i64 %t18, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l3, !tbaa !23
  %t22 = load i64, ptr %l4, !tbaa !24
  %t26 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecanonBits(ptr %v0, ptr %t20, i32 %t21, i64 %t22)
  store i64 %t26, ptr %l20
  br label %bb8
bb8:
  %t27 = load i64, ptr %l20, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
bb9:
  %t28 = load { i64, [4 x i64] }, ptr %l2
  %t30 = extractvalue { i64, [4 x i64] } %t28, 0
  %t31 = icmp eq i64 %t30, 1
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t34 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/mir:Lvalue", ptr %t34
  store %"compiler/mir:Lvalue" %t35, ptr %l5
  br label %bb12
bb11:
  br label %bb26
bb12:
  %t37 = load %"compiler/mir:Lvalue", ptr %l5
  %t39 = call i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %t37)
  store i64 %t39, ptr %l25
  br label %bb13
bb13:
  %t40 = load i64, ptr %l25, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  %t41 = getelementptr %"compiler/mir:Lvalue", ptr %l5, i32 0, i32 1
  %t42 = getelementptr %"compiler/mir:Range", ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = icmp eq i32 %t43, 0
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  store i1 %t49, ptr %l28, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l28, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l31, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l1, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = trunc i64 %t55 to i32
  %t62 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t53, i64 %t54, i32 %t57)
  store %"compiler/eval:Ptr" %t62, ptr %l37
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 27
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l40, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/eval:Machine", ptr %t68, i32 0, i32 59
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  %t72 = load i64, ptr %l1, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr %"compiler/eval:frame", ptr %t75, i64 %t72
  %t77 = getelementptr %"compiler/eval:frame", ptr %t76, i32 0, i32 0
  %t78 = load i64, ptr %t77, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr %"compiler/eval:cfn", ptr %t81, i64 %t78
  %t83 = getelementptr %"compiler/eval:cfn", ptr %t82, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l45, !tbaa !27
  %t85 = load i64, ptr %l6, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr %"compiler/mir:Local", ptr %t88, i64 %t85
  %t90 = getelementptr %"compiler/mir:Local", ptr %t89, i32 0, i32 2
  %t91 = load i32, ptr %t90, !tbaa !23
  %t94 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eword(ptr %v0, ptr %t63, i32 %t91)
  store i64 %t94, ptr %l48
  br label %bb20
bb20:
  %t95 = load ptr, ptr %l31, !tbaa !29
  %t96 = load %"compiler/eval:Ptr", ptr %l37
  %t97 = load i64, ptr %l48, !tbaa !24
  %t98 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t95, %"compiler/eval:Ptr" %t96, i64 %t97)
  store i64 %t98, ptr %l49
  br label %bb21
bb21:
  %t99 = load i64, ptr %l49, !tbaa !24
  store i64 %t99, ptr %rv
  br label %ret
bb22:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  %t102 = load %"compiler/mir:Lvalue", ptr %l5
  %t106 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t100, i64 %t101, %"compiler/mir:Lvalue" %t102)
  store { %"compiler/eval:Ptr", i32 } %t106, ptr %l53
  br label %bb23
bb23:
  %t107 = load { %"compiler/eval:Ptr", i32 }, ptr %l53
  store { %"compiler/eval:Ptr", i32 } %t107, ptr %l7
  %t108 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l7, i32 0, i32 0
  %t109 = load %"compiler/eval:Ptr", ptr %t108
  %t111 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l7, i32 0, i32 1
  %t112 = load i32, ptr %t111, !tbaa !23
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l56, !tbaa !29
  store %"compiler/eval:Ptr" %t109, ptr %l57
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t120 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eword(ptr %v0, ptr %t116, i32 %t112)
  store i64 %t120, ptr %l60
  br label %bb24
bb24:
  %t121 = load ptr, ptr %l56, !tbaa !29
  %t122 = load %"compiler/eval:Ptr", ptr %l57
  %t123 = load i64, ptr %l60, !tbaa !24
  %t124 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t121, %"compiler/eval:Ptr" %t122, i64 %t123)
  store i64 %t124, ptr %l61
  br label %bb25
bb25:
  %t125 = load i64, ptr %l61, !tbaa !24
  store i64 %t125, ptr %rv
  br label %ret
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb34
bb29:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l62, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l1, !tbaa !24
  %t129 = load { i64, [4 x i64] }, ptr %l2
  %t133 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t127, i64 %t128, { i64, [4 x i64] } %t129, i64 1)
  store %"compiler/eval:Ptr" %t133, ptr %l66
  br label %bb30
bb30:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l67, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i64, ptr %l1, !tbaa !24
  %t137 = load { i64, [4 x i64] }, ptr %l2
  %t141 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t135, i64 %t136, { i64, [4 x i64] } %t137)
  store i32 %t141, ptr %l71
  br label %bb31
bb31:
  %t142 = load ptr, ptr %l67, !tbaa !29
  %t143 = load i32, ptr %l71, !tbaa !23
  %t144 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eword(ptr %v0, ptr %t142, i32 %t143)
  store i64 %t144, ptr %l72
  br label %bb32
bb32:
  %t145 = load ptr, ptr %l62, !tbaa !29
  %t146 = load %"compiler/eval:Ptr", ptr %l66
  %t147 = load i64, ptr %l72, !tbaa !24
  %t148 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t145, %"compiler/eval:Ptr" %t146, i64 %t147)
  store i64 %t148, ptr %l73
  br label %bb33
bb33:
  %t149 = load i64, ptr %l73, !tbaa !24
  store i64 %t149, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_1c104311c72af5f5_c45dcd645c687dc1)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca %"compiler/eval:frame"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l8 = alloca { i64, ptr }
  %l10 = alloca %"compiler/eval:frame"
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l44 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [1 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 59
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t9, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l10, i64 136, i1 false)
  %t10 = load { i64, [1 x i64] }, ptr %l2
  %t12 = extractvalue { i64, [1 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 61
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 4
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load i32, ptr %l4, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t30 = add i64 %t24, %t27
  %t32 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i64, ptr %t33, i64 %t30
  %t35 = load i64, ptr %t34, !tbaa !34
  store i64 %t35, ptr %l11, !tbaa !24
  br label %bb22
bb4:
  %t37 = load { i64, [1 x i64] }, ptr %l2
  %t39 = extractvalue { i64, [1 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 1
  br i1 %t40, label %bb5, label %bb6
bb5:
  %t42 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t43 = getelementptr { i64 }, ptr %t42, i32 0, i32 0
  %t44 = load i64, ptr %t43
  store i64 %t44, ptr %l5, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/eval:Machine", ptr %t46, i32 0, i32 61
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l26, !tbaa !27
  %t50 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 5
  %t51 = load i64, ptr %t50, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i64, ptr %t58, i64 %t55
  %t60 = load i64, ptr %t59, !tbaa !34
  store i64 %t60, ptr %l11, !tbaa !24
  br label %bb22
bb8:
  %t62 = load { i64, [1 x i64] }, ptr %l2
  %t64 = extractvalue { i64, [1 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 2
  br i1 %t65, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/eval:Machine", ptr %t67, i32 0, i32 71
  %t70 = load i64, ptr %t69, !tbaa !24
  store i64 %t70, ptr %l11, !tbaa !24
  br label %bb22
bb12:
  %t72 = load { i64, [1 x i64] }, ptr %l2
  %t74 = extractvalue { i64, [1 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 3
  br i1 %t75, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t77 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 6
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l11, !tbaa !24
  br label %bb22
bb16:
  %t80 = load { i64, [1 x i64] }, ptr %l2
  %t82 = extractvalue { i64, [1 x i64] } %t80, 0
  %t83 = icmp eq i64 %t82, 4
  br i1 %t83, label %bb17, label %bb18
bb17:
  %t85 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t86 = getelementptr { i32 }, ptr %t85, i32 0, i32 0
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l6, !tbaa !23
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l1, !tbaa !24
  %t91 = load i32, ptr %l6, !tbaa !23
  %t95 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eheldScope(ptr %v0, ptr %t89, i64 %t90, i32 %t91)
  store i64 %t95, ptr %l44
  br label %bb20
bb20:
  %t96 = load i64, ptr %l44, !tbaa !24
  store i64 %t96, ptr %l11, !tbaa !24
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bcf45b1eafea1f9c_8e096368132121a8)
  unreachable
bb22:
  %t97 = load i64, ptr %l11, !tbaa !24
  store i64 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2escratchFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/eval:Ptr"
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l24 = alloca %"compiler/eval:Ptr"
  %l35 = alloca %"compiler/eval:Ptr"
  %l40 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 72
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 73
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = sub i64 %t14, 1
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t23 = load i64, ptr %l7, !tbaa !24
  store i64 %t23, ptr %l3, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/eval:Machine", ptr %t24, i32 0, i32 50
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t32 = and i64 %t28, %t29
  %t34 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/eval:alloc", ptr %t35, i64 %t32
  %t37 = getelementptr %"compiler/eval:alloc", ptr %t36, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load i64, ptr %l2, !tbaa !24
  %t42 = icmp sge i64 %t38, %t39
  br i1 %t42, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s1, i64 %t44, i64 0)
  store %"compiler/eval:Ptr" %t46, ptr %l24
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  %t47 = load %"compiler/eval:Ptr", ptr %l24
  store %"compiler/eval:Ptr" %t47, ptr %rv
  br label %ret
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t53 = and i64 %t49, %t50
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %t48, i64 %t53)
  br label %bb8
bb8:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  %t59 = mul i64 %t57, 2
  %t60 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/eval:Machine", ptr %t61, i32 0, i32 71
  %t64 = load i64, ptr %t63, !tbaa !24
  %t69 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t56, i64 %t59, i64 %t60, i64 %t64)
  store %"compiler/eval:Ptr" %t69, ptr %l35
  br label %bb9
bb9:
  %t70 = load %"compiler/eval:Ptr", ptr %l35
  store %"compiler/eval:Ptr" %t70, ptr %l4
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/eval:Machine", ptr %t71, i32 0, i32 23
  %t74 = load i1, ptr %t73, !tbaa !21
  br i1 %t74, label %bb10, label %bb11
bb10:
  %t76 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t76, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/eval:Machine", ptr %t78, i32 0, i32 50
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l40, !tbaa !27
  %t82 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t87 = and i64 %t83, %t84
  %t89 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr %"compiler/eval:alloc", ptr %t90, i64 %t87
  %t92 = getelementptr %"compiler/eval:alloc", ptr %t91, i32 0, i32 8
  store i64 -1, ptr %t92, !tbaa !24
  %t93 = load i64, ptr %l1, !tbaa !24
  %t95 = icmp eq i64 %t93, 0
  br i1 %t95, label %bb13, label %bb14
bb13:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 0
  %t99 = load i64, ptr %t98, !tbaa !24
  %t102 = getelementptr %"compiler/eval:Machine", ptr %t97, i32 0, i32 72
  store i64 %t99, ptr %t102, !tbaa !24
  br label %bb15
bb14:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/eval:Machine", ptr %t103, i32 0, i32 73
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l49, !tbaa !27
  %t107 = load i64, ptr %l1, !tbaa !24
  %t109 = sub i64 %t107, 1
  %t110 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 0
  %t111 = load i64, ptr %t110, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i64, ptr %t115, i64 %t109
  store i64 %t111, ptr %t116, !tbaa !34
  br label %bb15
bb15:
  %t117 = load %"compiler/eval:Ptr", ptr %l4
  store %"compiler/eval:Ptr" %t117, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i1
  %l28 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 29
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp slt i64 %t5, %t11
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 29
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 %t20
  %t25 = load i64, ptr %t24, !tbaa !34
  %t27 = icmp sge i64 %t25, 0
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t29 = load i1, ptr %l11, !tbaa !21
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 29
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l18, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i64, ptr %t37, i64 %t34
  %t39 = load i64, ptr %t38, !tbaa !34
  store i64 %t39, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshapeOf(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l23
  br label %bb7
bb7:
  %t46 = load i64, ptr %l23, !tbaa !24
  store i64 %t46, ptr %l3, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2esettled(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l26
  br label %bb8
bb8:
  %t52 = load i1, ptr %l26, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/eval:Machine", ptr %t53, i32 0, i32 29
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l28, !tbaa !27
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t57
  store i64 %t58, ptr %t63, !tbaa !34
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t64 = load i64, ptr %l3, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l24 = alloca i64
  %l28 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i1
  %l42 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 28
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp slt i64 %t5, %t11
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 28
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 %t20
  %t25 = load i64, ptr %t24, !tbaa !34
  %t27 = icmp sge i64 %t25, 0
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t29 = load i1, ptr %l11, !tbaa !21
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 28
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l18, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i64, ptr %t37, i64 %t34
  %t39 = load i64, ptr %t38, !tbaa !34
  store i64 %t39, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load i32, ptr %l1, !tbaa !23
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t45 = icmp eq i32 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  store i64 8, ptr %l24, !tbaa !24
  br label %bb17
bb8:
  %t47 = load i32, ptr %l1, !tbaa !23
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t51 = icmp eq i32 %t47, %t48
  br i1 %t51, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb12
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l1, !tbaa !23
  %t57 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l31
  br label %bb11
bb11:
  %t58 = load i1, ptr %l31, !tbaa !21
  %t59 = xor i1 %t58, true
  store i1 %t59, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t61 = load i1, ptr %l28, !tbaa !21
  br i1 %t61, label %bb13, label %bb14
bb13:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb16
bb14:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/eval:Machine", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l37
  br label %bb15
bb15:
  %t70 = load i64, ptr %l37, !tbaa !24
  store i64 %t70, ptr %l33, !tbaa !24
  br label %bb16
bb16:
  %t71 = load i64, ptr %l33, !tbaa !24
  store i64 %t71, ptr %l24, !tbaa !24
  br label %bb17
bb17:
  %t72 = load i64, ptr %l24, !tbaa !24
  store i64 %t72, ptr %l3, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2esettled(ptr %v0, ptr %t73, i32 %t74)
  store i1 %t77, ptr %l40
  br label %bb18
bb18:
  %t78 = load i1, ptr %l40, !tbaa !21
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/eval:Machine", ptr %t79, i32 0, i32 28
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l42, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load i64, ptr %l3, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i64, ptr %t88, i64 %t83
  store i64 %t84, ptr %t89, !tbaa !34
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t90 = load i64, ptr %l3, !tbaa !24
  store i64 %t90, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartGlobal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca i64
  %l12 = alloca %"compiler/eval:global"
  %l14 = alloca ptr
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i64
  %l31 = alloca i64
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l51 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 43
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/eval:global" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/eval:global", ptr %l12, i32 0, i32 2
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l14, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t12, i32 0, i32 32
  %t18 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t14, i64 %t9)
  store { i64, [2 x i64] } %t18, ptr %l18
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t20 = load { i64, [2 x i64] }, ptr %l18
  %t21 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t19, { i64, [2 x i64] } %t20)
  store i64 %t21, ptr %l19
  br label %bb3
bb3:
  %t22 = load i64, ptr %l19, !tbaa !24
  store i64 %t22, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp slt i64 %t23, 0
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t29 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t29, ptr %t27, { i64, ptr } %t28)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %ret
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 24
  %t35 = load i1, ptr %t34, !tbaa !21
  store i1 %t35, ptr %l4, !tbaa !21
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/eval:Machine", ptr %t37, i32 0, i32 24
  store i1 false, ptr %t39, !tbaa !21
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2feval_2erGlobal, !tbaa !24
  %t43 = load i64, ptr %l1, !tbaa !24
  %t48 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %t40, i64 %t41, i64 %t42, i64 %t43)
  store i64 %t48, ptr %l31
  br label %bb8
bb8:
  %t49 = load i64, ptr %l31, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i1, ptr %l4, !tbaa !21
  %t58 = getelementptr %"compiler/eval:Machine", ptr %t54, i32 0, i32 24
  store i1 %t55, ptr %t58, !tbaa !21
  br label %ret
bb10:
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/eval:Machine", ptr %t59, i32 0, i32 59
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l37, !tbaa !27
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i1, ptr %l4, !tbaa !21
  %t67 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr %"compiler/eval:frame", ptr %t68, i64 %t63
  %t70 = getelementptr %"compiler/eval:frame", ptr %t69, i32 0, i32 15
  store i1 %t64, ptr %t70, !tbaa !21
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/eval:Machine", ptr %t71, i32 0, i32 59
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l41, !tbaa !27
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/eval:Machine", ptr %t76, i32 0, i32 74
  %t79 = load i64, ptr %t78, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr %"compiler/eval:frame", ptr %t83, i64 %t75
  %t85 = getelementptr %"compiler/eval:frame", ptr %t84, i32 0, i32 14
  store i64 %t79, ptr %t85, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l1, !tbaa !24
  %t90 = getelementptr %"compiler/eval:Machine", ptr %t86, i32 0, i32 74
  store i64 %t87, ptr %t90, !tbaa !24
  %t91 = load i64, ptr %l1, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/eval:Machine", ptr %t93, i32 0, i32 43
  %t99 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eRefMut_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %v0, ptr %t95, i64 %t91)
  store ptr %t99, ptr %l51
  br label %bb12
bb12:
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = getelementptr %"compiler/eval:global", ptr %t100, i32 0, i32 4
  store i64 %t102, ptr %t105, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2estop(ptr %v0, ptr %v1, ptr %a0, { i64, [5 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 23
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 23
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 21
  store { i64, [5 x i64] } %a1, ptr %t13
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2etagOf(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l5 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %a2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/eval:Ptr", ptr %l1
  %t16 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t12, %"compiler/eval:Ptr" %t13, i64 4)
  store i64 %t16, ptr %l11
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t18 = load ptr, ptr %l8, !tbaa !29
  %t19 = load i64, ptr %l11, !tbaa !24
  %t21 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t18, i64 %t19, i32 %t17)
  store i64 %t21, ptr %l13
  br label %bb5
bb5:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load %"compiler/eval:Ptr", ptr %l1
  %t27 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t23, %"compiler/eval:Ptr" %t24, i64 8)
  store i64 %t27, ptr %l16
  br label %bb7
bb7:
  %t28 = load i64, ptr %l16, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskLayout(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/mir:Task"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { { i64, ptr }, i64 }
  %lp12 = alloca ptr
  %l15 = alloca i64
  %l23 = alloca i32
  %l26 = alloca i32
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i64
  %l54 = alloca { i64, [4 x i64] }
  %l55 = alloca i32
  %l61 = alloca { { i64, ptr }, i64 }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 144, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 1
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 1
  %t3 = load i32, ptr %t2, !tbaa !23
  %t5 = sext i32 %t3 to i64
  store i64 %t5, ptr %l15, !tbaa !24
  %t6 = load i64, ptr %l15, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l15, !tbaa !24
  %t10 = icmp sle i64 %t9, 2305843009213693951
  br i1 %t10, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_749f682aa65a479b_d1f85e4e9e0056df)
  unreachable
bb3:
  %t12 = load i64, ptr %l15, !tbaa !24
  %t13 = mul i64 %t12, 4
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  store i32 0, ptr %l5, !tbaa !23
  %t18 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 1
  %t19 = getelementptr %"compiler/mir:Range", ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  store i32 1, ptr %l7, !tbaa !23
  %t22 = load i32, ptr %l6, !tbaa !23
  %t23 = load i32, ptr %l5, !tbaa !23
  %t26 = icmp sgt i32 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_749f682aa65a479b_d1f85e4e9e0056df)
  unreachable
bb5:
  %t28 = load i32, ptr %l7, !tbaa !23
  %t30 = icmp sgt i32 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i32 0, ptr %l23, !tbaa !23
  br label %bb10
bb7:
  %t32 = load i32, ptr %l6, !tbaa !23
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = sub i32 %t32, %t33
  %t37 = load i32, ptr %l7, !tbaa !23
  %t40 = add i32 %t36, %t37
  %t42 = sub i32 %t40, 1
  %t43 = load i32, ptr %l7, !tbaa !23
  %t46 = sdiv i32 %t42, %t43
  store i32 %t46, ptr %l26, !tbaa !23
  br label %bb9
bb8:
  store i32 0, ptr %l26, !tbaa !23
  br label %bb9
bb9:
  %t48 = load i32, ptr %l26, !tbaa !23
  store i32 %t48, ptr %l23, !tbaa !23
  br label %bb10
bb10:
  %t49 = load i32, ptr %l23, !tbaa !23
  store i32 %t49, ptr %l8, !tbaa !23
  store i32 0, ptr %l9, !tbaa !23
  br label %bb11
bb11:
  %t50 = load i32, ptr %l9, !tbaa !23
  %t51 = load i32, ptr %l8, !tbaa !23
  %t54 = icmp slt i32 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t58 = load i32, ptr %l5, !tbaa !23
  %t59 = load i32, ptr %l9, !tbaa !23
  %t60 = load i32, ptr %l7, !tbaa !23
  %t63 = mul i32 %t59, %t60
  %t66 = add i32 %t58, %t63
  store i32 %t66, ptr %l10, !tbaa !23
  %t68 = load i32, ptr %l10, !tbaa !23
  store i32 %t68, ptr %l44, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l45, !tbaa !29
  store i64 %a3, ptr %l46, !tbaa !24
  %t73 = getelementptr %"compiler/mir:Fn", ptr %a1, i32 0, i32 11
  %t74 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 1
  %t75 = getelementptr %"compiler/mir:Range", ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  %t79 = load i32, ptr %l10, !tbaa !23
  %t81 = sext i32 %t79 to i64
  %t84 = add i64 %t78, %t81
  %t87 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v1, ptr %t73, i64 %t84)
  store { i64, [4 x i64] } %t87, ptr %l54
  br label %bb15
bb15:
  %t88 = load ptr, ptr %l45, !tbaa !29
  %t89 = load i64, ptr %l46, !tbaa !24
  %t90 = load { i64, [4 x i64] }, ptr %l54
  %t91 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t88, i64 %t89, { i64, [4 x i64] } %t90)
  store i32 %t91, ptr %l55
  br label %bb16
bb16:
  %t92 = load i32, ptr %l55, !tbaa !23
  %t93 = load i32, ptr %l44, !tbaa !23
  %t94 = sext i32 %t93 to i64
  %t95 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t94
  store i32 %t92, ptr %t97, !tbaa !33
  br label %bb17
bb17:
  %t98 = load i32, ptr %l9, !tbaa !23
  %t101 = add i32 %t98, 1
  store i32 %t101, ptr %l9, !tbaa !23
  br label %bb11
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t107 = call { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2epack(ptr %v0, ptr %s0, ptr %v2, ptr %t103, { i64, ptr } %t104)
  store { { i64, ptr }, i64 } %t107, ptr %l61
  br label %bb19
bb19:
  %t108 = load { { i64, ptr }, i64 }, ptr %l61
  store { { i64, ptr }, i64 } %t108, ptr %l11
  %t109 = getelementptr { { i64, ptr }, i64 }, ptr %l11, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l62, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l63, !tbaa !24
  %t113 = load i64, ptr %l63, !tbaa !24
  %t114 = mul i64 %t113, 8
  %t115 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l64, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l63, !tbaa !24
  %t123 = mul i64 %t122, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t119, ptr %t121, i64 %t123, i1 false)
  %t124 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t124, ptr %lp12
  %t125 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t126 = load ptr, ptr %lp12
  store { i64, ptr } %t125, ptr %t126, !tbaa !27
  %t127 = getelementptr { { i64, ptr }, i64 }, ptr %l11, i32 0, i32 1
  %t128 = load i64, ptr %t127, !tbaa !24
  %t130 = load ptr, ptr %lp12
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t134 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t131, 0
  %t136 = insertvalue { { i64, ptr }, i64 } %t134, i64 %t128, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca double
  %rv = alloca double
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a2)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load i32, ptr %l3, !tbaa !23
  %t12 = icmp eq i32 %t10, 11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = and i64 %t14, 65535
  %t18 = trunc i64 %t16 to i16
  %t20 = call i16 asm "", "=r,0"(i16 %t18)
  %t21 = bitcast i16 %t20 to half
  %t23 = fpext half %t21 to double
  store double %t23, ptr %l8, !tbaa !26
  br label %bb18
bb5:
  %t25 = load i32, ptr %l3, !tbaa !23
  %t27 = icmp eq i32 %t25, 12
  br i1 %t27, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = and i64 %t29, 65535
  %t33 = trunc i64 %t31 to i16
  %t35 = bitcast i16 %t33 to bfloat
  %t37 = bitcast bfloat %t35 to i16
  %t38 = zext i16 %t37 to i32
  %t39 = shl i32 %t38, 16
  %t40 = bitcast i32 %t39 to float
  %t41 = fpext float %t40 to double
  store double %t41, ptr %l8, !tbaa !26
  br label %bb18
bb9:
  %t43 = load i32, ptr %l3, !tbaa !23
  %t45 = icmp eq i32 %t43, 13
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t47 = load i64, ptr %l1, !tbaa !24
  %t49 = and i64 %t47, 4294967295
  %t51 = trunc i64 %t49 to i32
  %t53 = bitcast i32 %t51 to float
  %t55 = fpext float %t53 to double
  store double %t55, ptr %l8, !tbaa !26
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t57 = load i64, ptr %l1, !tbaa !24
  %t60 = bitcast i64 %t57 to double
  store double %t60, ptr %l8, !tbaa !26
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_176c1f0c53cca04e_ded73198e701b2e2)
  unreachable
bb18:
  %t62 = load double, ptr %l8, !tbaa !26
  store double %t62, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2etraced(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l67 = alloca i32
  %l71 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l108 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 59
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l13, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:frame", ptr %t9, i32 0, i32 16
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 59
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l20, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr %"compiler/eval:frame", ptr %t24, i64 %t21
  %t26 = getelementptr %"compiler/eval:frame", ptr %t25, i32 0, i32 17
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t32 = icmp ne i32 %t27, %t29
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr @G_2ecompiler_2feval_2etRaised, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr @G_2ecompiler_2feval_2etCall, !tbaa !24
  %t41 = icmp ne i64 %t37, %t38
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/eval:Machine", ptr %t43, i32 0, i32 89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t45)
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t47, i32 0, i32 91
  store i64 0, ptr %t49, !tbaa !24
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/eval:Machine", ptr %t50, i32 0, i32 59
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l33, !tbaa !27
  %t54 = load i64, ptr %l1, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr %"compiler/eval:frame", ptr %t57, i64 %t54
  %t59 = getelementptr %"compiler/eval:frame", ptr %t58, i32 0, i32 16
  store i64 -1, ptr %t59, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Machine", ptr %t60, i32 0, i32 89
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l37
  br label %bb11
bb11:
  %t65 = load i64, ptr @G_2ecompiler_2feval_2etraceKept, !tbaa !24
  %t67 = mul i64 4, %t65
  %t68 = load i64, ptr %l37, !tbaa !24
  %t70 = icmp sge i64 %t68, %t67
  br i1 %t70, label %bb12, label %bb13
bb12:
  store i64 0, ptr %l5, !tbaa !24
  store i64 4, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t72 = load i64, ptr %l6, !tbaa !24
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb14, label %bb15
bb13:
  br label %bb30
bb14:
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb19
bb16:
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l7, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l47, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb18
bb18:
  %t98 = load i64, ptr %l47, !tbaa !24
  store i64 %t98, ptr %l44, !tbaa !24
  br label %bb19
bb19:
  %t99 = load i64, ptr %l44, !tbaa !24
  store i64 %t99, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb21, label %bb22
bb21:
  br label %bb29
bb22:
  br label %bb23
bb23:
  %t108 = load i64, ptr %l5, !tbaa !24
  %t109 = load i64, ptr %l9, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l10, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/eval:Machine", ptr %t118, i32 0, i32 89
  %t122 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %t120, i64 0)
  store i32 %t122, ptr %l67
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb25, label %ok.124, !prof !99
ok.124:
  br label %bb24
bb24:
  br label %bb27
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = add i64 %t125, 1
  store i64 %t128, ptr %l9, !tbaa !24
  br label %bb20
bb29:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l71, !tbaa !29
  %t131 = load ptr, ptr %l71, !tbaa !29
  %t132 = getelementptr %"compiler/eval:Machine", ptr %t131, i32 0, i32 91
  %t133 = load i64, ptr %t132, !tbaa !24
  %t136 = add i64 %t133, 1
  %t138 = load ptr, ptr %l71, !tbaa !29
  %t139 = getelementptr %"compiler/eval:Machine", ptr %t138, i32 0, i32 91
  store i64 %t136, ptr %t139, !tbaa !24
  br label %bb30
bb30:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/eval:Machine", ptr %t140, i32 0, i32 89
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/eval:Machine", ptr %t143, i32 0, i32 27
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l78, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr %"compiler/eval:cfn", ptr %t150, i64 %a2
  %t152 = getelementptr %"compiler/eval:cfn", ptr %t151, i32 0, i32 0
  %t153 = load i64, ptr %t152, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t142, i64 %t153)
  br label %bb31
bb31:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/eval:Machine", ptr %t156, i32 0, i32 89
  %t159 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t160 = load i32, ptr %t159, !tbaa !23
  %t162 = sext i32 %t160 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t158, i64 %t162)
  br label %bb32
bb32:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/eval:Machine", ptr %t165, i32 0, i32 89
  %t168 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t167, i64 %t168)
  br label %bb33
bb33:
  %t171 = load i64, ptr %l4, !tbaa !24
  %t172 = load i64, ptr @G_2ecompiler_2feval_2etRaised, !tbaa !24
  %t175 = icmp eq i64 %t171, %t172
  br i1 %t175, label %bb34, label %bb35
bb34:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/eval:Machine", ptr %t177, i32 0, i32 26
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/eval:Machine", ptr %t180, i32 0, i32 59
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l95, !tbaa !27
  %t184 = load i64, ptr %l1, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr %"compiler/eval:frame", ptr %t187, i64 %t184
  %t189 = getelementptr %"compiler/eval:frame", ptr %t188, i32 0, i32 0
  %t190 = load i64, ptr %t189, !tbaa !24
  %t193 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t179, i64 %t190)
  store ptr %t193, ptr %l98
  br label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l91, !tbaa !27
  br label %bb38
bb36:
  %t194 = load %"compiler/source:Span", ptr %l3
  %t195 = load ptr, ptr %l98, !tbaa !29
  %t197 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %v0, ptr %t195, %"compiler/source:Span" %t194)
  store { i64, ptr } %t197, ptr %l100
  br label %bb37
bb37:
  %t198 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t198, ptr %l91, !tbaa !27
  br label %bb38
bb38:
  %t199 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t199, ptr %l11, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t204 = icmp sgt i64 %t202, 0
  br i1 %t204, label %bb39, label %bb40
bb39:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/eval:Machine", ptr %t206, i32 0, i32 89
  store ptr %t208, ptr %l105, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/eval:Machine", ptr %t209, i32 0, i32 90
  %t213 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t211)
  store i64 %t213, ptr %l108
  br label %bb41
bb40:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/eval:Machine", ptr %t214, i32 0, i32 89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t216, i64 -1)
  br label %bb44
bb41:
  %t218 = load ptr, ptr %l105, !tbaa !29
  %t219 = load i64, ptr %l108, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t218, i64 %t219)
  br label %bb42
bb42:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/eval:Machine", ptr %t220, i32 0, i32 90
  %t223 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t222, { i64, ptr } %t223)
  br label %bb43
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2etypeid(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i32
  %l9 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l18 = alloca %"compiler/eval:Ptr"
  %l23 = alloca %"compiler/eval:Ptr"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 42
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t12, i32 %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l14
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb3, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l13
  br label %bb2
bb2:
  %t21 = load i64, ptr %l13, !tbaa !24
  store i64 %t21, ptr %l9, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb5
bb5:
  %t22 = load i64, ptr %l9, !tbaa !24
  store i64 %t22, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp ne i64 %t23, 0
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s1, i64 %t27, i64 0)
  store %"compiler/eval:Ptr" %t29, ptr %l18
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  %t30 = load %"compiler/eval:Ptr", ptr %l18
  store %"compiler/eval:Ptr" %t30, ptr %rv
  br label %ret
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr @G_2ecompiler_2feval_2eaData, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t33, i32 0, i32 71
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t31, i64 8, i64 %t32, i64 %t36)
  store %"compiler/eval:Ptr" %t40, ptr %l23
  br label %bb10
bb10:
  %t41 = load %"compiler/eval:Ptr", ptr %l23
  store %"compiler/eval:Ptr" %t41, ptr %l4
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 42
  %t45 = load i32, ptr %l2, !tbaa !23
  %t46 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 0
  %t47 = load i64, ptr %t46, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t44, i32 %t45, i64 %t47)
  br label %bb11
bb11:
  %t51 = load %"compiler/eval:Ptr", ptr %l4
  store %"compiler/eval:Ptr" %t51, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eunary(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t7, i32 %t8)
  store i64 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = call i64 @compiler_2feval_2ebmask(i64 %t12)
  store i64 %t13, ptr %l13
  br label %bb3
bb3:
  %t14 = load i64, ptr %l13, !tbaa !24
  store i64 %t14, ptr %l6, !tbaa !24
  %t15 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = xor i64 %t20, 1
  store i64 %t22, ptr %l14, !tbaa !24
  br label %bb20
bb7:
  %t24 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t26 = trunc i64 1 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = xor i64 %t29, -1
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = and i64 %t31, %t32
  store i64 %t35, ptr %l14, !tbaa !24
  br label %bb20
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t38 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t41 = icmp eq i64 %a4, %t38
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 8, %t44
  %t48 = sub i64 %t46, 1
  store i64 %t48, ptr %l32, !tbaa !24
  %t49 = load i64, ptr %l32, !tbaa !24
  %t50 = load i64, ptr %l32, !tbaa !24
  %t51 = shl i64 1, %t50
  %t54 = xor i64 %t43, %t51
  store i64 %t54, ptr %l34, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l37
  br label %bb17
bb16:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = sub i64 0, %t60
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = and i64 %t62, %t63
  store i64 %t66, ptr %l28, !tbaa !24
  br label %bb18
bb17:
  %t68 = load i64, ptr %l34, !tbaa !24
  %t69 = load i64, ptr %l37, !tbaa !24
  %t70 = and i64 %t68, %t69
  store i64 %t70, ptr %l28, !tbaa !24
  br label %bb18
bb18:
  %t72 = load i64, ptr %l28, !tbaa !24
  store i64 %t72, ptr %l14, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_bb58ffa16789d1e6_53f99027aa0e2dd2)
  unreachable
bb20:
  %t73 = load i64, ptr %l14, !tbaa !24
  store i64 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunlinkReg(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/eval:reg"
  %l4 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l15 = alloca %"compiler/eval:reg"
  %l23 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca ptr
  %l46 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 55
  %t7 = call %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/eval:reg" %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load %"compiler/eval:reg", ptr %l15
  store %"compiler/eval:reg" %t8, ptr %l2
  %t9 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 5
  %t10 = load i64, ptr %t9, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 5
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 4
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 55
  %t26 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eRefMut_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %v0, ptr %t22, i64 %t15)
  store ptr %t26, ptr %l23
  br label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 6
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t27, i64 %t29)
  store i1 %t32, ptr %l28
  br label %bb5
bb4:
  %t33 = load ptr, ptr %l23, !tbaa !29
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = getelementptr %"compiler/eval:reg", ptr %t33, i32 0, i32 4
  store i64 %t35, ptr %t38, !tbaa !24
  br label %bb10
bb5:
  %t39 = load i1, ptr %l28, !tbaa !21
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t40 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 6
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t45 = and i64 %t41, %t42
  %t47 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 4
  %t48 = load i64, ptr %t47, !tbaa !24
  store i64 %t48, ptr %l7, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/eval:Machine", ptr %t50, i32 0, i32 53
  %t56 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t52, i64 %t45)
  store ptr %t56, ptr %l36
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t57 = load ptr, ptr %l36, !tbaa !29
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = getelementptr %"compiler/eval:scope", ptr %t57, i32 0, i32 4
  store i64 %t59, ptr %t62, !tbaa !24
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t63 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 4
  %t64 = load i64, ptr %t63, !tbaa !24
  %t66 = icmp sge i64 %t64, 0
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t68 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 4
  %t69 = load i64, ptr %t68, !tbaa !24
  %t71 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 5
  %t72 = load i64, ptr %t71, !tbaa !24
  store i64 %t72, ptr %l10, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/eval:Machine", ptr %t74, i32 0, i32 55
  %t80 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eRefMut_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %v0, ptr %t76, i64 %t69)
  store ptr %t80, ptr %l46
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t81 = load ptr, ptr %l46, !tbaa !29
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = getelementptr %"compiler/eval:reg", ptr %t81, i32 0, i32 5
  store i64 %t83, ptr %t86, !tbaa !24
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunmark(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i1
  %l48 = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = sdiv i64 %t5, 8
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = add i64 %t9, %t10
  %t15 = sub i64 %t13, 1
  %t17 = sdiv i64 %t15, 8
  %t19 = add i64 %t17, 1
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb6:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l25, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l25, !tbaa !24
  store i64 %t47, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l22, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = sub i64 %t49, 1
  store i64 %t50, ptr %l34, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t51, 2147483648
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = icmp sge i64 %t53, 0
  %t57 = and i1 %t52, %t54
  store i1 %t57, ptr %l37, !tbaa !21
  br label %bb10
bb10:
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t66 = load i64, ptr %l3, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l5, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t78 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 47
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l48, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i64, ptr %t83, i64 %t74
  store i64 0, ptr %t84, !tbaa !34
  br label %bb14
bb14:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = add i64 %t85, 1
  store i64 %t88, ptr %l7, !tbaa !24
  br label %bb10
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunwind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [5 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i1
  %l20 = alloca i1
  %l48 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca %"compiler/eval:global"
  %l60 = alloca { i64, [2 x i64] }
  %l69 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l97 = alloca %"compiler/eval:global"
  %l104 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 23
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 1
  %t9 = load i32, ptr %t8, !range !{i32 0, i32 2}
  %t11 = trunc i64 1 to i32
  %t12 = icmp eq i32 %t9, %t11
  store i1 %t12, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l16, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:Machine", ptr %t15, i32 0, i32 60
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  store i1 %t22, ptr %l20, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l20, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 21
  %t28 = load { i64, [5 x i64] }, ptr %t27
  store { i64, [5 x i64] } %t28, ptr %l2
  %t30 = load { i64, [5 x i64] }, ptr %l2
  %t32 = extractvalue { i64, [5 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 3
  br i1 %t33, label %bb9, label %bb10
bb8:
  br label %bb29
bb9:
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erunCleanups(ptr %v0, ptr %t35, i64 %t36)
  br label %bb12
bb12:
  br label %bb28
bb13:
  %t39 = load { i64, [5 x i64] }, ptr %l2
  %t41 = extractvalue { i64, [5 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 2
  br i1 %t42, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  %t44 = load { i64, [5 x i64] }, ptr %l2
  %t46 = extractvalue { i64, [5 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 1
  br i1 %t47, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/eval:Machine", ptr %t49, i32 0, i32 87
  %t52 = load i1, ptr %t51, !tbaa !21
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseOpen(ptr %v0, ptr %t54, i64 %t55)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_f4c8d7149bd44e26_572dd2a903112792)
  unreachable
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/eval:Machine", ptr %t58, i32 0, i32 60
  %t61 = load i64, ptr %t60, !tbaa !24
  %t62 = load i64, ptr %l1, !tbaa !24
  %t65 = icmp sgt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb31, label %bb32
bb31:
  br label %bb36
bb32:
  br label %bb33
bb33:
  %t69 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropFrame(ptr %v0, ptr %t69)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb30
bb36:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/eval:Machine", ptr %t71, i32 0, i32 74
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = icmp sge i64 %t74, 0
  br i1 %t76, label %bb37, label %bb38
bb37:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/eval:Machine", ptr %t78, i32 0, i32 23
  %t81 = load i1, ptr %t80, !tbaa !21
  store i1 %t81, ptr %l48, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb39
bb39:
  %t83 = load i1, ptr %l48, !tbaa !21
  br i1 %t83, label %bb40, label %bb41
bb40:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/eval:Machine", ptr %t84, i32 0, i32 22
  store i64 -1, ptr %t86, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/eval:Machine", ptr %t87, i32 0, i32 32
  store ptr %t89, ptr %l53, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/eval:Machine", ptr %t90, i32 0, i32 43
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/eval:Machine", ptr %t93, i32 0, i32 74
  %t96 = load i64, ptr %t95, !tbaa !24
  %t99 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t92, i64 %t96)
  store %"compiler/eval:global" %t99, ptr %l58
  br label %bb42
bb41:
  br label %bb71
bb42:
  %t100 = getelementptr %"compiler/eval:global", ptr %l58, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load ptr, ptr %l53, !tbaa !29
  %t104 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t102, i64 %t101)
  store { i64, [2 x i64] } %t104, ptr %l60
  br label %bb43
bb43:
  %t105 = load { i64, [2 x i64] }, ptr %l60
  store { i64, [2 x i64] } %t105, ptr %l3
  %t106 = load { i64, [2 x i64] }, ptr %l3
  %t108 = extractvalue { i64, [2 x i64] } %t106, 0
  %t109 = icmp eq i64 %t108, 0
  br i1 %t109, label %bb44, label %bb45
bb44:
  %t111 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t112 = getelementptr { i32 }, ptr %t111, i32 0, i32 0
  %t113 = load i32, ptr %t112
  store i32 %t113, ptr %l4, !tbaa !23
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l4, !tbaa !23
  %t118 = sext i32 %t116 to i64
  %t121 = getelementptr %"compiler/eval:Machine", ptr %t115, i32 0, i32 22
  store i64 %t118, ptr %t121, !tbaa !24
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_2654da324b88ad87_946d0eedc2d95193)
  unreachable
bb52:
  store i64 0, ptr %l5, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/eval:Machine", ptr %t122, i32 0, i32 43
  %t126 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eLen_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t124)
  store i64 %t126, ptr %l69
  br label %bb53
bb53:
  %t127 = load i64, ptr %l69, !tbaa !24
  store i64 %t127, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t128 = load i64, ptr %l6, !tbaa !24
  %t129 = load i64, ptr %l5, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb54, label %bb55
bb54:
  %t134 = load i64, ptr %l7, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb59
bb56:
  %t138 = load i64, ptr %l6, !tbaa !24
  %t139 = load i64, ptr %l5, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l7, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l7, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l76, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb58
bb58:
  %t154 = load i64, ptr %l76, !tbaa !24
  store i64 %t154, ptr %l73, !tbaa !24
  br label %bb59
bb59:
  %t155 = load i64, ptr %l73, !tbaa !24
  store i64 %t155, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb60
bb60:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t157 = load i64, ptr %l8, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb61, label %bb62
bb61:
  br label %bb70
bb62:
  br label %bb63
bb63:
  %t164 = load i64, ptr %l5, !tbaa !24
  %t165 = load i64, ptr %l9, !tbaa !24
  %t166 = load i64, ptr %l7, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store i64 %t172, ptr %l10, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/eval:Machine", ptr %t174, i32 0, i32 43
  %t177 = load i64, ptr %l10, !tbaa !24
  %t180 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t176, i64 %t177)
  store %"compiler/eval:global" %t180, ptr %l97
  br label %bb64
bb64:
  %t181 = getelementptr %"compiler/eval:global", ptr %l97, i32 0, i32 4
  %t182 = load i64, ptr %t181, !tbaa !24
  %t184 = icmp eq i64 %t182, 1
  br i1 %t184, label %bb65, label %bb66
bb65:
  %t186 = load i64, ptr %l10, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/eval:Machine", ptr %t188, i32 0, i32 43
  %t194 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eRefMut_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %v0, ptr %t190, i64 %t186)
  store ptr %t194, ptr %l104
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t195 = load ptr, ptr %l104, !tbaa !29
  %t197 = load i64, ptr %l12, !tbaa !24
  %t200 = getelementptr %"compiler/eval:global", ptr %t195, i32 0, i32 4
  store i64 %t197, ptr %t200, !tbaa !24
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t201 = load i64, ptr %l9, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l9, !tbaa !24
  br label %bb60
bb70:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/eval:Machine", ptr %t206, i32 0, i32 74
  store i64 -1, ptr %t208, !tbaa !24
  br label %bb71
bb71:
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l3, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/eval:Machine", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a1)
  store i32 %t13, ptr %l9
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb5
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = ashr i64 %t18, 63
  store i64 %t20, ptr %l11, !tbaa !24
  br label %bb5
bb5:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = insertvalue { i64, i64 } undef, i64 %t22, 0
  %t24 = load i64, ptr %l11, !tbaa !24
  %t25 = insertvalue { i64, i64 } %t23, i64 %t24, 1
  store { i64, i64 } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i64
  %l23 = alloca { i64, i64 }
  %l24 = alloca ptr
  %l28 = alloca %"compiler/eval:Ptr"
  %l30 = alloca { i64, i64 }
  %l31 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load { i64, [4 x i64] }, ptr %l2
  %t7 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t1, i64 %t2, { i64, [4 x i64] } %t3)
  store i32 %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load i32, ptr %l10, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t9, i32 %t10)
  store i64 %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t15 = load i64, ptr %l13, !tbaa !24
  %t17 = icmp eq i64 %t15, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load { i64, [4 x i64] }, ptr %l2
  %t21 = extractvalue { i64, [4 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 2
  br i1 %t22, label %bb5, label %bb6
bb4:
  br label %bb16
bb5:
  %t24 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t25 = getelementptr { i32, i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  %t28 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t29 = getelementptr { i32, i64 }, ptr %t28, i32 0, i32 1
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l5, !tbaa !24
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l4, !tbaa !23
  %t34 = load i64, ptr %l5, !tbaa !24
  %t38 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideConst(ptr %v0, ptr %t32, i32 %t33, i64 %t34)
  store { i64, i64 } %t38, ptr %l23
  br label %bb8
bb8:
  %t39 = load { i64, i64 }, ptr %l23
  store { i64, i64 } %t39, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l24, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t43 = load { i64, [4 x i64] }, ptr %l2
  %t47 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t41, i64 %t42, { i64, [4 x i64] } %t43, i64 1)
  store %"compiler/eval:Ptr" %t47, ptr %l28
  br label %bb13
bb13:
  %t48 = load i32, ptr %l3, !tbaa !23
  %t49 = load ptr, ptr %l24, !tbaa !29
  %t50 = load %"compiler/eval:Ptr", ptr %l28
  %t52 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2erdWide(ptr %v0, ptr %t49, %"compiler/eval:Ptr" %t50, i32 %t48)
  store { i64, i64 } %t52, ptr %l30
  br label %bb14
bb14:
  %t53 = load { i64, i64 }, ptr %l30
  store { i64, i64 } %t53, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2742cef73dca1807_235d65ef4c242d83)
  unreachable
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load { i64, [4 x i64] }, ptr %l2
  %t61 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t55, i64 %t56, { i64, [4 x i64] } %t57)
  store i64 %t61, ptr %l35
  br label %bb17
bb17:
  %t62 = load i32, ptr %l3, !tbaa !23
  %t63 = load ptr, ptr %l31, !tbaa !29
  %t64 = load i64, ptr %l35, !tbaa !24
  %t66 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t63, i64 %t64, i32 %t62)
  store i64 %t66, ptr %l37
  br label %bb18
bb18:
  %t67 = load i64, ptr %l37, !tbaa !24
  store i64 %t67, ptr %l6, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t72, ptr %l40
  br label %bb19
bb19:
  %t73 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t74 = load i64, ptr %l40, !tbaa !24
  %t76 = icmp eq i64 %t74, %t73
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = and i64 %t78, 1
  %t82 = insertvalue { i64, i64 } undef, i64 %t80, 0
  %t83 = insertvalue { i64, i64 } %t82, i64 0, 1
  store { i64, i64 } %t83, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t85 = load i64, ptr %l6, !tbaa !24
  store i64 %t85, ptr %l46, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t86, i32 %t87)
  store i64 %t90, ptr %l49
  br label %bb23
bb23:
  %t91 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t92 = load i64, ptr %l49, !tbaa !24
  %t94 = icmp eq i64 %t92, %t91
  br i1 %t94, label %bb24, label %bb25
bb24:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb26
bb25:
  %t96 = load i64, ptr %l6, !tbaa !24
  %t98 = ashr i64 %t96, 63
  store i64 %t98, ptr %l52, !tbaa !24
  br label %bb26
bb26:
  %t100 = load i64, ptr %l46, !tbaa !24
  %t101 = insertvalue { i64, i64 } undef, i64 %t100, 0
  %t102 = load i64, ptr %l52, !tbaa !24
  %t103 = insertvalue { i64, i64 } %t101, i64 %t102, 1
  store { i64, i64 } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i1
  %l28 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 30
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp slt i64 %t5, %t11
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 30
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 %t20
  %t25 = load i64, ptr %t24, !tbaa !34
  %t27 = icmp sge i64 %t25, 0
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t29 = load i1, ptr %l11, !tbaa !21
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 30
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l18, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i64, ptr %t37, i64 %t34
  %t39 = load i64, ptr %t38, !tbaa !34
  store i64 %t39, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidthOf(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l23
  br label %bb7
bb7:
  %t46 = load i64, ptr %l23, !tbaa !24
  store i64 %t46, ptr %l3, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2esettled(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l26
  br label %bb8
bb8:
  %t52 = load i1, ptr %l26, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/eval:Machine", ptr %t53, i32 0, i32 30
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l28, !tbaa !27
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t57
  store i64 %t58, ptr %t63, !tbaa !34
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t64 = load i64, ptr %l3, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidthOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l5 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i64
  %l27 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  %t18 = icmp eq i64 %t14, %t15
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i64 4, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  %t25 = icmp eq i64 %t21, %t22
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i64 8, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l23
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t42, ptr %l24
  br label %bb12
bb12:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l27, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/eval:Machine", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i32, ptr %l1, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l31
  br label %bb15
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/eval:Machine", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l35, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Machine", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l39
  br label %bb18
bb15:
  %t68 = load ptr, ptr %l27, !tbaa !29
  %t69 = load i32, ptr %l31, !tbaa !23
  %t70 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t70, ptr %l32
  br label %bb16
bb16:
  %t71 = load i64, ptr %l32, !tbaa !24
  %t72 = call i64 @compiler_2ftypes_2eIntBytes(i64 %t71)
  store i64 %t72, ptr %l33
  br label %bb17
bb17:
  %t73 = load i64, ptr %l33, !tbaa !24
  store i64 %t73, ptr %l25, !tbaa !24
  br label %bb20
bb18:
  %t74 = load ptr, ptr %l35, !tbaa !29
  %t75 = load i32, ptr %l39, !tbaa !23
  %t76 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t74, i32 %t75)
  store i64 %t76, ptr %l40
  br label %bb19
bb19:
  %t77 = load i64, ptr %l40, !tbaa !24
  %t78 = sdiv i64 %t77, 8
  store i64 %t78, ptr %l25, !tbaa !24
  br label %bb20
bb20:
  %t80 = load i64, ptr %l25, !tbaa !24
  store i64 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eword(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i64 8, ptr %l7, !tbaa !24
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i64, ptr %l10, !tbaa !24
  store i64 %t16, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l7, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i64, ptr %l2, !tbaa !24
  %t7 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i64 %t3, i1 true)
  store i64 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunmark(ptr %v0, ptr %t13, i64 %t14, i64 %t15)
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t19, i64 %t20, i64 %t21, i64 %a3)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca i64
  %l6 = alloca i64
  %l22 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i64 8, i1 true)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunmark(ptr %v0, ptr %t11, i64 %t12, i64 8)
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t15, i64 %t16, i64 8, i64 %t18)
  br label %bb6
bb6:
  %t22 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  %t25 = icmp ne i64 %t23, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = srem i64 %t27, 8
  %t31 = icmp ne i64 %t29, 0
  br i1 %t31, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t35 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t35, ptr %t33, { i64, ptr } %t34)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %ret
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 47
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = sdiv i64 %t42, 8
  %t45 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t46 = load i64, ptr %t45, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i64, ptr %t50, i64 %t44
  store i64 %t46, ptr %t51, !tbaa !34
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l16 = alloca i1
  %l20 = alloca { i64, ptr }
  %l29 = alloca i64
  %l31 = alloca i64
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l45 = alloca i64
  %l54 = alloca i64
  %l56 = alloca i64
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l70 = alloca i64
  %l79 = alloca i64
  %l81 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l94 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = ashr i64 %t1, 3
  store i64 %t3, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = and i64 %t5, 7
  store i64 %t7, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp eq i64 %t13, 8
  store i1 %t15, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l16, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/eval:Machine", ptr %t18, i32 0, i32 46
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l20, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i64, ptr %t27, i64 %t22
  store i64 %t23, ptr %t28, !tbaa !34
  br label %ret
bb5:
  br label %bb6
bb6:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = icmp sle i64 %t33, 8
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t37, i64 %t38)
  store i64 %t41, ptr %l29
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 8, %t42
  store i64 %t44, ptr %l31, !tbaa !24
  %t45 = load i64, ptr %l29, !tbaa !24
  %t46 = load i64, ptr %l31, !tbaa !24
  %t47 = load i64, ptr %l31, !tbaa !24
  %t48 = shl i64 %t45, %t47
  store i64 %t48, ptr %l6, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/eval:Machine", ptr %t50, i32 0, i32 46
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l34, !tbaa !27
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/eval:Machine", ptr %t55, i32 0, i32 46
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l37, !tbaa !27
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t59
  %t64 = load i64, ptr %t63, !tbaa !34
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = xor i64 %t65, -1
  %t70 = and i64 %t64, %t67
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = mul i64 8, %t72
  store i64 %t74, ptr %l45, !tbaa !24
  %t76 = load i64, ptr %l45, !tbaa !24
  %t77 = load i64, ptr %l45, !tbaa !24
  %t78 = shl i64 %t71, %t77
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = and i64 %t78, %t79
  %t85 = or i64 %t70, %t82
  %t88 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i64, ptr %t89, i64 %t54
  store i64 %t85, ptr %t90, !tbaa !34
  br label %ret
bb10:
  %t91 = load i64, ptr %l5, !tbaa !24
  %t93 = sub i64 8, %t91
  store i64 %t93, ptr %l7, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t95, i64 %t96)
  store i64 %t99, ptr %l54
  br label %bb11
bb11:
  %t100 = load i64, ptr %l5, !tbaa !24
  %t102 = mul i64 8, %t100
  store i64 %t102, ptr %l56, !tbaa !24
  %t103 = load i64, ptr %l54, !tbaa !24
  %t104 = load i64, ptr %l56, !tbaa !24
  %t105 = load i64, ptr %l56, !tbaa !24
  %t106 = shl i64 %t103, %t105
  store i64 %t106, ptr %l8, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/eval:Machine", ptr %t108, i32 0, i32 46
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l59, !tbaa !27
  %t112 = load i64, ptr %l4, !tbaa !24
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/eval:Machine", ptr %t113, i32 0, i32 46
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l62, !tbaa !27
  %t117 = load i64, ptr %l4, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i64, ptr %t120, i64 %t117
  %t122 = load i64, ptr %t121, !tbaa !34
  %t123 = load i64, ptr %l8, !tbaa !24
  %t125 = xor i64 %t123, -1
  %t128 = and i64 %t122, %t125
  %t129 = load i64, ptr %l3, !tbaa !24
  %t130 = load i64, ptr %l5, !tbaa !24
  %t132 = mul i64 8, %t130
  store i64 %t132, ptr %l70, !tbaa !24
  %t134 = load i64, ptr %l70, !tbaa !24
  %t135 = load i64, ptr %l70, !tbaa !24
  %t136 = shl i64 %t129, %t135
  %t137 = load i64, ptr %l8, !tbaa !24
  %t140 = and i64 %t136, %t137
  %t143 = or i64 %t128, %t140
  %t146 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i64, ptr %t147, i64 %t112
  store i64 %t143, ptr %t148, !tbaa !34
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i64, ptr %l2, !tbaa !24
  %t151 = load i64, ptr %l7, !tbaa !24
  %t154 = sub i64 %t150, %t151
  %t157 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t149, i64 %t154)
  store i64 %t157, ptr %l79
  br label %bb12
bb12:
  %t158 = load i64, ptr %l79, !tbaa !24
  store i64 %t158, ptr %l9, !tbaa !24
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/eval:Machine", ptr %t159, i32 0, i32 46
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l81, !tbaa !27
  %t163 = load i64, ptr %l4, !tbaa !24
  %t165 = add i64 %t163, 1
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/eval:Machine", ptr %t166, i32 0, i32 46
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l85, !tbaa !27
  %t170 = load i64, ptr %l4, !tbaa !24
  %t172 = add i64 %t170, 1
  %t174 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr i64, ptr %t175, i64 %t172
  %t177 = load i64, ptr %t176, !tbaa !34
  %t178 = load i64, ptr %l9, !tbaa !24
  %t180 = xor i64 %t178, -1
  %t183 = and i64 %t177, %t180
  %t184 = load i64, ptr %l3, !tbaa !24
  %t185 = load i64, ptr %l7, !tbaa !24
  %t187 = mul i64 8, %t185
  store i64 %t187, ptr %l94, !tbaa !24
  %t189 = load i64, ptr %l94, !tbaa !24
  %t190 = load i64, ptr %l94, !tbaa !24
  %t191 = ashr i64 %t184, %t190
  %t192 = load i64, ptr %l9, !tbaa !24
  %t195 = and i64 %t191, %t192
  %t198 = or i64 %t183, %t195
  %t201 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr i64, ptr %t202, i64 %t165
  store i64 %t198, ptr %t203, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrWide(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l5 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca i64
  %l20 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t1, i32 %a2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/eval:Ptr", ptr %l1
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t7, %"compiler/eval:Ptr" %t8, i64 8, i64 %a3)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l12, !tbaa !29
  %t14 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = add i64 %t17, 8
  %t22 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t15, i64 %t19)
  store %"compiler/eval:Ptr" %t22, ptr %l16
  br label %bb3
bb3:
  store i64 %a4, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t24, 64
  %t28 = call i64 @compiler_2feval_2ebmask(i64 %t26)
  store i64 %t28, ptr %l20
  br label %bb4
bb4:
  %t29 = load i64, ptr %l17, !tbaa !24
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = and i64 %t29, %t30
  %t32 = load ptr, ptr %l12, !tbaa !29
  %t33 = load %"compiler/eval:Ptr", ptr %l16
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t32, %"compiler/eval:Ptr" %t33, i64 8, i64 %t31)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ezero(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca i64
  %l19 = alloca i1
  %l39 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i64, ptr %l2, !tbaa !24
  %t11 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t5, %"compiler/eval:Ptr" %a1, i64 %t7, i1 true)
  store i64 %t11, ptr %l10
  br label %bb4
bb4:
  %t12 = load i64, ptr %l10, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunmark(ptr %v0, ptr %t17, i64 %t18, i64 %t19)
  br label %bb8
bb8:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb9
bb9:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  br i1 %t27, label %bb10, label %bb11
bb10:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = srem i64 %t33, 8
  %t37 = icmp ne i64 %t35, 0
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l19, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t43, %t44
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t42, i64 %t47, i64 1, i64 0)
  br label %bb16
bb16:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t50, 1
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb17
bb17:
  br label %bb9
bb18:
  br label %bb19
bb19:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t57 = add i64 %t55, 8
  %t58 = load i64, ptr %l2, !tbaa !24
  %t61 = icmp sle i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/eval:Machine", ptr %t65, i32 0, i32 46
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sdiv i64 %t73, 8
  %t77 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i64, ptr %t78, i64 %t75
  store i64 0, ptr %t79, !tbaa !34
  %t80 = load i64, ptr %l4, !tbaa !24
  %t83 = add i64 %t80, 8
  store i64 %t83, ptr %l4, !tbaa !24
  br label %bb23
bb23:
  br label %bb19
bb24:
  %t85 = load i64, ptr %l4, !tbaa !24
  %t86 = load i64, ptr %l2, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l3, !tbaa !24
  %t93 = load i64, ptr %l4, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t97 = load i64, ptr %l2, !tbaa !24
  %t98 = load i64, ptr %l4, !tbaa !24
  %t101 = sub i64 %t97, %t98
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t91, i64 %t96, i64 %t101, i64 0)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aSnapshot_2eClear(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Snapshot", ptr %t1, i32 0, i32 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t3)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Snapshot", ptr %t5, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t7)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/eval:Snapshot", ptr %t9, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H075fcab2d197e70ad987ab163aa86164(ptr %v0, ptr %t11)
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/eval:Snapshot", ptr %t13, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t15)
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Snapshot", ptr %t17, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t19)
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/eval:Snapshot", ptr %t21, i32 0, i32 5
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t23)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2feval_2eextend128(i64 %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i1
  %l24 = alloca i64
  %l28 = alloca i64
  %l30 = alloca i64
  %l36 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i1
  %l44 = alloca i64
  %l48 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i64
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t1, 128
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = insertvalue { i64, i64 } undef, i64 %t5, 0
  %t10 = insertvalue { i64, i64 } %t8, i64 %t6, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t12, 64
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = sub i64 %t16, 64
  store i64 %t18, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l1, !tbaa !24
  store i64 %t20, ptr %l16, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = call i64 @compiler_2feval_2ebmask(i64 %t21)
  store i64 %t23, ptr %l18
  br label %bb6
bb5:
  br label %bb14
bb6:
  %t24 = load i64, ptr %l16, !tbaa !24
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = and i64 %t24, %t25
  store i64 %t26, ptr %l5, !tbaa !24
  %t28 = load i1, ptr %l3, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = sub i64 %t31, 1
  store i64 %t33, ptr %l24, !tbaa !24
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = load i64, ptr %l24, !tbaa !24
  %t37 = ashr i64 %t30, %t36
  %t39 = and i64 %t37, 1
  %t41 = icmp eq i64 %t39, 1
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l21, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load i64, ptr %l5, !tbaa !24
  store i64 %t44, ptr %l28, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = call i64 @compiler_2feval_2ebmask(i64 %t45)
  store i64 %t47, ptr %l30
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t48 = load i64, ptr %l30, !tbaa !24
  %t49 = xor i64 %t48, -1
  %t50 = load i64, ptr %l28, !tbaa !24
  %t52 = or i64 %t50, %t49
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb13
bb13:
  %t54 = load i64, ptr %l0, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = insertvalue { i64, i64 } undef, i64 %t54, 0
  %t59 = insertvalue { i64, i64 } %t57, i64 %t55, 1
  store { i64, i64 } %t59, ptr %rv
  br label %ret
bb14:
  %t61 = load i64, ptr %l0, !tbaa !24
  store i64 %t61, ptr %l36, !tbaa !24
  %t62 = load i64, ptr %l2, !tbaa !24
  %t64 = call i64 @compiler_2feval_2ebmask(i64 %t62)
  store i64 %t64, ptr %l38
  br label %bb15
bb15:
  %t65 = load i64, ptr %l36, !tbaa !24
  %t66 = load i64, ptr %l38, !tbaa !24
  %t67 = and i64 %t65, %t66
  store i64 %t67, ptr %l6, !tbaa !24
  %t69 = load i1, ptr %l3, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t71 = load i64, ptr %l6, !tbaa !24
  %t72 = load i64, ptr %l2, !tbaa !24
  %t74 = sub i64 %t72, 1
  store i64 %t74, ptr %l44, !tbaa !24
  %t76 = load i64, ptr %l44, !tbaa !24
  %t77 = load i64, ptr %l44, !tbaa !24
  %t78 = ashr i64 %t71, %t77
  %t80 = and i64 %t78, 1
  %t82 = icmp eq i64 %t80, 1
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb18
bb18:
  %t84 = load i1, ptr %l41, !tbaa !21
  br i1 %t84, label %bb19, label %bb20
bb19:
  %t85 = load i64, ptr %l6, !tbaa !24
  store i64 %t85, ptr %l48, !tbaa !24
  %t86 = load i64, ptr %l2, !tbaa !24
  %t88 = call i64 @compiler_2feval_2ebmask(i64 %t86)
  store i64 %t88, ptr %l50
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t89 = load i64, ptr %l50, !tbaa !24
  %t90 = xor i64 %t89, -1
  %t91 = load i64, ptr %l48, !tbaa !24
  %t93 = or i64 %t91, %t90
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb22
bb22:
  %t95 = load i64, ptr %l6, !tbaa !24
  store i64 %t95, ptr %l53, !tbaa !24
  %t96 = load i1, ptr %l3, !tbaa !21
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb23, label %bb24
bb23:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb25
bb24:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = ashr i64 %t100, 63
  store i64 %t102, ptr %l56, !tbaa !24
  br label %bb25
bb25:
  %t104 = load i64, ptr %l53, !tbaa !24
  %t105 = insertvalue { i64, i64 } undef, i64 %t104, 0
  %t106 = load i64, ptr %l56, !tbaa !24
  %t107 = insertvalue { i64, i64 } %t105, i64 %t106, 1
  store { i64, i64 } %t107, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local void @compiler_2feval_2efailFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i32
  %l19 = alloca i32
  %l20 = alloca %"compiler/mir:Fn"
  %l24 = alloca i32
  %l26 = alloca i32
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca { i64, [4 x i64] }
  %l38 = alloca ptr
  %l39 = alloca i32
  %l41 = alloca %"compiler/mir:Lvalue"
  %l50 = alloca { i64, [21 x i64] }
  %l63 = alloca { i64, [21 x i64] }
  %l65 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca { i64, [4 x i64] }
  %l70 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t20 = alloca %"compiler/mir:Fn", align 8
  %t50 = alloca { i64, [4 x i64] }, align 8
  %t69 = alloca { i64, [4 x i64] }, align 8
  %t77 = alloca { i64, [8 x i64] }, align 8
  %t94 = alloca { i64, [21 x i64] }, align 8
  %t110 = alloca { i64, [4 x i64] }, align 8
  %t118 = alloca { i64, [8 x i64] }, align 8
  %t133 = alloca { i64, [21 x i64] }, align 8
  %t148 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i32 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i32, ptr %l10, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  store i64 %a1, ptr %l12, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l4, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l16
  br label %bb2
bb2:
  %t13 = load i32, ptr %l4, !tbaa !23
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t16 = load i32, ptr %l16, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t15, i32 %t16, i32 %t13, i32 %a2, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t19, ptr %l19
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = load i32, ptr %l19, !tbaa !23
  call void @compiler_2feval_2etfn(ptr %t20, ptr %v0, ptr %v1, ptr %t21, i64 %t22, i32 %t23)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t20, i64 808, i1 false)
  br label %bb4
bb4:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  store ptr %t24, ptr %lp5
  %t25 = load ptr, ptr %lp5
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %l20, i64 808, i1 false)
  %t26 = load ptr, ptr %lp5
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t28 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t32 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t26, i32 %t27, %"compiler/source:Span" %t28)
  store i32 %t32, ptr %l24
  br label %bb5
bb5:
  %t33 = load i32, ptr %l24, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  %t34 = load ptr, ptr %lp5
  %t36 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t34)
  store i32 %t36, ptr %l26
  br label %bb6
bb6:
  %t37 = load i32, ptr %l26, !tbaa !23
  store i32 %t37, ptr %l7, !tbaa !23
  %t38 = load ptr, ptr %lp5
  %t40 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t38)
  store i32 %t40, ptr %l28
  br label %bb7
bb7:
  %t41 = load i32, ptr %l28, !tbaa !23
  store i32 %t41, ptr %l8, !tbaa !23
  %t42 = load ptr, ptr %lp5
  store ptr %t42, ptr %l29, !tbaa !29
  %t43 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t43, ptr %l30, !tbaa !23
  %t44 = load i32, ptr %l6, !tbaa !23
  %t46 = sext i32 %t44 to i64
  store i64 %t46, ptr %l32, !tbaa !24
  store i32 15, ptr %l33
  %t47 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t47, ptr %l34, !tbaa !23
  %t48 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t48, ptr %l35
  br label %bb8
bb8:
  %t49 = load i32, ptr %l4, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 0
  store i64 2, ptr %t51
  %t53 = insertvalue { i32, i64 } undef, i32 %t49, 0
  %t54 = insertvalue { i32, i64 } %t53, i64 0, 1
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  store { i32, i64 } %t54, ptr %t55
  %t56 = load { i64, [4 x i64] }, ptr %t50
  %t57 = load ptr, ptr %l29, !tbaa !29
  %t58 = load i32, ptr %l30, !tbaa !23
  %t59 = load i64, ptr %l32, !tbaa !24
  %t60 = load i32, ptr %l33, !range !{i32 0, i32 54}
  %t61 = load i32, ptr %l34, !tbaa !23
  %t62 = load { i64, [4 x i64] }, ptr %l35
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t57, i32 %t58, i64 %t59, i32 %t60, i32 %t61, { i64, [4 x i64] } %t62, { i64, [4 x i64] } %t56)
  br label %bb9
bb9:
  %t64 = load ptr, ptr %lp5
  store ptr %t64, ptr %l38, !tbaa !29
  %t65 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t65, ptr %l39, !tbaa !23
  %t66 = load i32, ptr %l6, !tbaa !23
  %t68 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t66)
  store %"compiler/mir:Lvalue" %t68, ptr %l41
  br label %bb10
bb10:
  store { i64, [4 x i64] } zeroinitializer, ptr %t69
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 0
  store i64 1, ptr %t70
  %t71 = load %"compiler/mir:Lvalue", ptr %l41
  %t72 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t71, 0
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t72, ptr %t73
  %t74 = load { i64, [4 x i64] }, ptr %t69
  %t75 = load i32, ptr %l7, !tbaa !23
  %t76 = load i32, ptr %l8, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [8 x i64] }, ptr %t77, i32 0, i32 0
  store i64 2, ptr %t78
  %t80 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t74, 0
  %t82 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t80, i32 %t75, 1
  %t84 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t82, i32 %t76, 2
  %t85 = getelementptr { i64, [8 x i64] }, ptr %t77, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t84, ptr %t85
  %t86 = load { i64, [8 x i64] }, ptr %t77
  %t87 = load ptr, ptr %l38, !tbaa !29
  %t88 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t87, i32 %t88, { i64, [8 x i64] } %t86)
  br label %bb11
bb11:
  %t90 = load ptr, ptr %lp5
  %t91 = load i32, ptr %l7, !tbaa !23
  %t92 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t93 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [21 x i64] }, ptr %t94, i32 0, i32 0
  store i64 4, ptr %t95
  %t97 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t92, 0
  %t99 = insertvalue { %"compiler/source:Span", i32 } %t97, i32 %t93, 1
  %t100 = getelementptr { i64, [21 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t99, ptr %t100
  %t101 = load { i64, [21 x i64] }, ptr %t94
  store { i64, [21 x i64] } %t101, ptr %l50
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t90, i32 %t91, ptr %l50)
  br label %bb12
bb12:
  %t105 = load ptr, ptr %lp5
  %t106 = load i32, ptr %l7, !tbaa !23
  %t107 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t108 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t110
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t110, i32 0, i32 0
  store i64 2, ptr %t111
  %t113 = insertvalue { i32, i64 } undef, i32 %t108, 0
  %t115 = insertvalue { i32, i64 } %t113, i64 %a3, 1
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t110, i32 0, i32 1
  store { i32, i64 } %t115, ptr %t116
  %t117 = load { i64, [4 x i64] }, ptr %t110
  store { i64, [8 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [8 x i64] }, ptr %t118, i32 0, i32 0
  store i64 7, ptr %t119
  %t121 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t107, 0
  %t123 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t121, { i64, [4 x i64] } %t117, 1
  %t124 = getelementptr { i64, [8 x i64] }, ptr %t118, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t123, ptr %t124
  %t125 = load { i64, [8 x i64] }, ptr %t118
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t105, i32 %t106, { i64, [8 x i64] } %t125)
  br label %bb13
bb13:
  %t129 = load ptr, ptr %lp5
  %t130 = load i32, ptr %l8, !tbaa !23
  %t131 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t132 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [21 x i64] }, ptr %t133, i32 0, i32 0
  store i64 4, ptr %t134
  %t136 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t131, 0
  %t138 = insertvalue { %"compiler/source:Span", i32 } %t136, i32 %t132, 1
  %t139 = getelementptr { i64, [21 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t138, ptr %t139
  %t140 = load { i64, [21 x i64] }, ptr %t133
  store { i64, [21 x i64] } %t140, ptr %l63
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t129, i32 %t130, ptr %l63)
  br label %bb14
bb14:
  %t144 = load ptr, ptr %lp5
  store ptr %t144, ptr %l65, !tbaa !29
  %t145 = load i32, ptr %l8, !tbaa !23
  store i32 %t145, ptr %l66, !tbaa !23
  %t146 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t146, ptr %l67
  %t147 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t147, ptr %l68
  br label %bb15
bb15:
  store { i64, [8 x i64] } zeroinitializer, ptr %t148
  %t149 = getelementptr { i64, [8 x i64] }, ptr %t148, i32 0, i32 0
  store i64 5, ptr %t149
  %t150 = load %"compiler/source:Span", ptr %l67
  %t151 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t150, 0
  %t152 = load { i64, [4 x i64] }, ptr %l68
  %t153 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t151, { i64, [4 x i64] } %t152, 1
  %t154 = getelementptr { i64, [8 x i64] }, ptr %t148, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t153, ptr %t154
  %t155 = load { i64, [8 x i64] }, ptr %t148
  %t156 = load ptr, ptr %l65, !tbaa !29
  %t157 = load i32, ptr %l66, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t156, i32 %t157, { i64, [8 x i64] } %t155)
  br label %bb16
bb16:
  %t159 = load ptr, ptr %lp5
  call void @llvm.memmove.p0.p0.i64(ptr %l70, ptr %t159, i64 808, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l70, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2efibHost(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp slt i64 %t1, 2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb5
bb2:
  %t7 = load i64, ptr %l0, !tbaa !24
  %t9 = sub i64 %t7, 1
  %t11 = call i64 @compiler_2feval_2efibHost(i64 %t9)
  store i64 %t11, ptr %l7
  br label %bb3
bb3:
  %t12 = load i64, ptr %l0, !tbaa !24
  %t14 = sub i64 %t12, 2
  %t16 = call i64 @compiler_2feval_2efibHost(i64 %t14)
  store i64 %t16, ptr %l10
  br label %bb4
bb4:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = add i64 %t17, %t18
  store i64 %t19, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l3, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2efloatFits(double %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca double
  %l1 = alloca i64
  %l3 = alloca double
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i1
  %l54 = alloca i1
  %l61 = alloca i1
  %l71 = alloca i1
  %rv = alloca i1
  store double %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff0000000000000, ptr %l3, !tbaa !26
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = sub i64 %t1, 1
  store i64 %t3, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l18, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l15, !tbaa !24
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = sub i64 %t33, 1
  store i64 %t34, ptr %l27, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp slt i64 %t35, 2147483648
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = icmp sge i64 %t37, 0
  %t41 = and i1 %t36, %t38
  store i1 %t41, ptr %l30, !tbaa !21
  br label %bb7
bb7:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l9, !tbaa !24
  %t60 = load double, ptr %l3, !tbaa !26
  %t63 = fmul double %t60, 0x4000000000000000
  store double %t63, ptr %l3, !tbaa !26
  br label %bb11
bb11:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = add i64 %t65, 1
  store i64 %t68, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  %t70 = load double, ptr %l0, !tbaa !26
  %t71 = load double, ptr %l0, !tbaa !26
  %t74 = fcmp une double %t70, %t71
  br i1 %t74, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t79 = xor i1 %a2, true
  br i1 %t79, label %bb16, label %bb17
bb16:
  %t81 = load double, ptr %l0, !tbaa !26
  %t83 = fcmp ogt double %t81, 0xbff0000000000000
  br i1 %t83, label %bb18, label %bb19
bb17:
  br label %bb21
bb18:
  %t85 = load double, ptr %l0, !tbaa !26
  %t86 = load double, ptr %l3, !tbaa !26
  %t88 = fmul double 0x4000000000000000, %t86
  %t91 = fcmp olt double %t85, %t88
  store i1 %t91, ptr %l54, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb20
bb20:
  %t93 = load i1, ptr %l54, !tbaa !21
  store i1 %t93, ptr %rv
  br label %ret
bb21:
  %t94 = load i64, ptr %l1, !tbaa !24
  %t96 = icmp sgt i64 %t94, 53
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t98 = load double, ptr %l0, !tbaa !26
  %t99 = load double, ptr %l3, !tbaa !26
  %t101 = fneg double %t99
  %t104 = fcmp oge double %t98, %t101
  store i1 %t104, ptr %l61, !tbaa !21
  br label %bb24
bb23:
  %t106 = load double, ptr %l0, !tbaa !26
  %t107 = load double, ptr %l3, !tbaa !26
  %t109 = fneg double %t107
  %t111 = fsub double %t109, 0x3ff0000000000000
  %t114 = fcmp ogt double %t106, %t111
  store i1 %t114, ptr %l61, !tbaa !21
  br label %bb24
bb24:
  %t116 = load i1, ptr %l61, !tbaa !21
  br i1 %t116, label %bb25, label %bb26
bb25:
  %t117 = load double, ptr %l0, !tbaa !26
  %t118 = load double, ptr %l3, !tbaa !26
  %t121 = fcmp olt double %t117, %t118
  store i1 %t121, ptr %l71, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb27
bb27:
  %t123 = load i1, ptr %l71, !tbaa !21
  store i1 %t123, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/mir:Lvalue" @compiler_2feval_2egplace(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i32
  %l7 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Lvalue"
  %t5 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 %a1, ptr %l2, !tbaa !23
  %t4 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %a0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i32 %t4, ptr %l4
  br label %bb1
bb1:
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 2, ptr %t6
  %t7 = insertvalue { i64, i32, i32 } undef, i64 7, 0
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = insertvalue { i64, i32, i32 } %t7, i32 %t8, 1
  %t10 = load i32, ptr %l4, !tbaa !23
  %t11 = insertvalue { i64, i32, i32 } %t9, i32 %t10, 2
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i64, i32, i32 } %t11, ptr %t12
  %t13 = load { i64, [2 x i64] }, ptr %t5
  %t14 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  %t17 = call %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %s0, { i64, [2 x i64] } %t13, %"compiler/mir:Range" %t14)
  store %"compiler/mir:Lvalue" %t17, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"compiler/mir:Lvalue", ptr %l7
  store %"compiler/mir:Lvalue" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local i1 @compiler_2feval_2eisNaNBits(ptr %v0, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l36 = alloca i1
  %l38 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i64 10, ptr %l7, !tbaa !24
  br label %bb12
bb3:
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t7, ptr %l9
  br label %bb4
bb4:
  %t8 = load i1, ptr %l9, !tbaa !21
  br i1 %t8, label %bb5, label %bb6
bb5:
  store i64 7, ptr %l10, !tbaa !24
  br label %bb11
bb6:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t11, ptr %l12
  br label %bb7
bb7:
  %t12 = load i1, ptr %l12, !tbaa !21
  br i1 %t12, label %bb8, label %bb9
bb8:
  store i64 23, ptr %l13, !tbaa !24
  br label %bb10
bb9:
  store i64 52, ptr %l13, !tbaa !24
  br label %bb10
bb10:
  %t13 = load i64, ptr %l13, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t15 = load i64, ptr %l7, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t18, ptr %l15
  br label %bb13
bb13:
  %t19 = load i1, ptr %l15, !tbaa !21
  br i1 %t19, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb17
bb15:
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t22, ptr %l18
  br label %bb16
bb16:
  %t23 = load i1, ptr %l18, !tbaa !21
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb17
bb17:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb18, label %bb19
bb18:
  store i64 16, ptr %l19, !tbaa !24
  br label %bb24
bb19:
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t27, ptr %l21
  br label %bb20
bb20:
  %t28 = load i1, ptr %l21, !tbaa !21
  br i1 %t28, label %bb21, label %bb22
bb21:
  store i64 32, ptr %l22, !tbaa !24
  br label %bb23
bb22:
  store i64 64, ptr %l22, !tbaa !24
  br label %bb23
bb23:
  %t29 = load i64, ptr %l22, !tbaa !24
  store i64 %t29, ptr %l19, !tbaa !24
  br label %bb24
bb24:
  %t30 = load i64, ptr %l19, !tbaa !24
  %t33 = sub i64 %t30, 1
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = sub i64 %t33, %t34
  store i64 %t37, ptr %l26, !tbaa !24
  %t38 = load i64, ptr %l26, !tbaa !24
  %t39 = load i64, ptr %l26, !tbaa !24
  %t40 = shl i64 1, %t39
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l2, !tbaa !24
  store i64 %t43, ptr %l29, !tbaa !24
  %t45 = load i64, ptr %l29, !tbaa !24
  %t46 = load i64, ptr %l29, !tbaa !24
  %t47 = shl i64 %t42, %t46
  store i64 %t47, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l0, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = and i64 %t49, %t50
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = icmp eq i64 %t53, %t54
  br i1 %t57, label %bb25, label %bb26
bb25:
  %t59 = load i64, ptr %l0, !tbaa !24
  %t60 = load i64, ptr %l2, !tbaa !24
  store i64 %t60, ptr %l38, !tbaa !24
  %t61 = load i64, ptr %l38, !tbaa !24
  %t62 = load i64, ptr %l38, !tbaa !24
  %t63 = shl i64 1, %t62
  %t65 = sub i64 %t63, 1
  %t68 = and i64 %t59, %t65
  %t70 = icmp ne i64 %t68, 0
  store i1 %t70, ptr %l36, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load i1, ptr %l36, !tbaa !21
  store i1 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2elz128(i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i1
  %l47 = alloca i64
  %l50 = alloca i64
  %l54 = alloca i64
  %rv = alloca i64
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l19, !tbaa !24
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = sub i64 %t31, 1
  store i64 %t32, ptr %l28, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp slt i64 %t33, 2147483648
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  %t39 = and i1 %t34, %t36
  store i1 %t39, ptr %l31, !tbaa !21
  br label %bb7
bb7:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb18
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  %t58 = load i64, ptr %l2, !tbaa !24
  %t60 = sub i64 %t58, 1
  %t64 = sub i64 %t60, %t56
  store i64 %t64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l10, !tbaa !24
  %t68 = icmp sge i64 %t66, 64
  br i1 %t68, label %bb11, label %bb12
bb11:
  %t71 = load i64, ptr %l10, !tbaa !24
  %t73 = sub i64 %t71, 64
  store i64 %t73, ptr %l50, !tbaa !24
  %t75 = load i64, ptr %l50, !tbaa !24
  %t76 = load i64, ptr %l50, !tbaa !24
  %t77 = ashr i64 %a1, %t76
  %t79 = and i64 %t77, 1
  store i64 %t79, ptr %l47, !tbaa !24
  br label %bb13
bb12:
  %t82 = load i64, ptr %l10, !tbaa !24
  store i64 %t82, ptr %l54, !tbaa !24
  %t84 = load i64, ptr %l54, !tbaa !24
  %t85 = load i64, ptr %l54, !tbaa !24
  %t86 = ashr i64 %a0, %t85
  %t88 = and i64 %t86, 1
  store i64 %t88, ptr %l47, !tbaa !24
  br label %bb13
bb13:
  %t90 = load i64, ptr %l47, !tbaa !24
  %t93 = icmp eq i64 %t90, 1
  br i1 %t93, label %bb14, label %bb15
bb14:
  %t95 = load i64, ptr %l3, !tbaa !24
  store i64 %t95, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t97 = load i64, ptr %l3, !tbaa !24
  %t100 = add i64 %t97, 1
  store i64 %t100, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = add i64 %t102, 1
  store i64 %t105, ptr %l8, !tbaa !24
  br label %bb7
bb18:
  %t107 = load i64, ptr %l3, !tbaa !24
  store i64 %t107, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2eminBits(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sge i64 %t1, 64
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -9223372036854775808, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = sub i64 %t5, 1
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = shl i64 1, %t9
  %t12 = sub i64 0, %t10
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t14 = load i64, ptr %l3, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i64 } @compiler_2feval_2emul128(i64 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, i64 }
  %l9 = alloca { i64, i64 }
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call { i64, i64 } @compiler_2feval_2emul64(i64 %t1, i64 %t2)
  store { i64, i64 } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, i64 }, ptr %l9
  store { i64, i64 } %t6, ptr %l4
  %t7 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t15 = load i64, ptr %l0, !tbaa !24
  %t19 = mul i64 %t15, %a3
  %t22 = add i64 %t11, %t19
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = mul i64 %a1, %t24
  %t30 = add i64 %t22, %t27
  %t32 = insertvalue { i64, i64 } undef, i64 %t8, 0
  %t34 = insertvalue { i64, i64 } %t32, i64 %t30, 1
  store { i64, i64 } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2feval_2emul64(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = and i64 %t1, 4294967295
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l0, !tbaa !24
  %t8 = lshr i64 %t5, 32
  store i64 %t8, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = and i64 %t11, 4294967295
  store i64 %t13, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = lshr i64 %t15, 32
  store i64 %t18, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = mul i64 %t21, %t22
  store i64 %t25, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = mul i64 %t27, %t28
  store i64 %t31, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = mul i64 %t33, %t34
  store i64 %t37, ptr %l8, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = mul i64 %t39, %t40
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = lshr i64 %t45, 32
  %t50 = load i64, ptr %l7, !tbaa !24
  %t52 = and i64 %t50, 4294967295
  %t55 = add i64 %t48, %t52
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = and i64 %t56, 4294967295
  %t61 = add i64 %t55, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t65 = and i64 %t63, 4294967295
  %t66 = load i64, ptr %l10, !tbaa !24
  %t68 = shl i64 %t66, 32
  %t71 = or i64 %t65, %t68
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = lshr i64 %t74, 32
  %t81 = add i64 %t43, %t77
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = lshr i64 %t82, 32
  %t89 = add i64 %t81, %t85
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = lshr i64 %t90, 32
  %t97 = add i64 %t89, %t93
  %t102 = insertvalue { i64, i64 } undef, i64 %t71, 0
  %t104 = insertvalue { i64, i64 } %t102, i64 %t97, 1
  store { i64, i64 } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2feval_2eneg128(i64 %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, i64 }
  %rv = alloca { i64, i64 }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, i64 } @compiler_2feval_2esub128(i64 0, i64 0, i64 %a0, i64 %a1)
  store { i64, i64 } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, i64 }, ptr %l4
  store { i64, i64 } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local void @compiler_2feval_2enfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t10 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i64 %a1, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t4, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t7, i32 0, i32 %t8, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2feval_2etfn(ptr %t10, ptr %v0, ptr %v1, ptr %t11, i64 %t12, i32 %t13)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t10, i64 808, i1 false)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l8, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [4 x i64] }
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca i1
  %l7 = alloca i1
  %rv = alloca i1
  store { i64, [4 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l0, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l1
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load %"compiler/mir:Lvalue", ptr %l1
  %t12 = call i1 @compiler_2feval_2eplaceNamesGlobal(%"compiler/mir:Lvalue" %t10)
  store i1 %t12, ptr %l7
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  store i1 %t13, ptr %l2, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a1e0d3359bcb436b_ac2861f14772b5df)
  unreachable
bb10:
  %t14 = load i1, ptr %l2, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2eovFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %lp4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l15 = alloca i32
  %l16 = alloca %"compiler/mir:Fn"
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/mir:Lvalue"
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca { i64, [4 x i64] }
  %l30 = alloca { i64, [4 x i64] }
  %l31 = alloca { i64, ptr }
  %l32 = alloca %"compiler/mir:Range"
  %l34 = alloca { i64, [21 x i64] }
  %l40 = alloca { i64, [21 x i64] }
  %l42 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca %"compiler/source:Span"
  %l46 = alloca %"compiler/mir:Lvalue"
  %l49 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t27 = alloca %"compiler/mir:Fn", align 8
  %t67 = alloca { i64, [15 x i64] }, align 8
  %t77 = alloca { i64, [21 x i64] }, align 8
  %t94 = alloca { i64, [21 x i64] }, align 8
  %t111 = alloca { i64, [4 x i64] }, align 8
  %t117 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i64 %a1, ptr %l7, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l3, !tbaa !23
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = mul i64 2, 4
  %t8 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 2, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l12, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i32, ptr %t13, i64 0
  store i32 %t5, ptr %t14, !tbaa !33
  %t16 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i32, ptr %t17, i64 1
  store i32 %t6, ptr %t18, !tbaa !33
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t4, { i64, ptr } %t20)
  store i32 %t21, ptr %l13
  br label %bb1
bb1:
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t23 = load ptr, ptr %l8, !tbaa !29
  %t24 = load i32, ptr %l13, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t23, i32 %t24, i32 %t22, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t26, ptr %l15
  br label %bb2
bb2:
  %t28 = load ptr, ptr %l6, !tbaa !29
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2feval_2etfn(ptr %t27, ptr %v0, ptr %v1, ptr %t28, i64 %t29, i32 %t30)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t27, i64 808, i1 false)
  br label %bb3
bb3:
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  store ptr %t31, ptr %lp4
  %t32 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %l16, i64 808, i1 false)
  %t33 = load ptr, ptr %lp4
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t35 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t39 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t33, i32 %t34, %"compiler/source:Span" %t35)
  store i32 %t39, ptr %l20
  br label %bb4
bb4:
  %t40 = load i32, ptr %l20, !tbaa !23
  store i32 %t40, ptr %l5, !tbaa !23
  %t41 = load ptr, ptr %lp4
  store ptr %t41, ptr %l21, !tbaa !29
  %t42 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t42, ptr %l22, !tbaa !23
  %t43 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t43, ptr %l23
  %t44 = load i32, ptr %l5, !tbaa !23
  %t46 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t44)
  store %"compiler/mir:Lvalue" %t46, ptr %l25
  br label %bb5
bb5:
  store i32 %a2, ptr %l26
  %t48 = load i32, ptr %l3, !tbaa !23
  store i32 %t48, ptr %l27, !tbaa !23
  %t49 = load ptr, ptr %lp4
  store ptr %t49, ptr %l28, !tbaa !29
  %t50 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t50, ptr %l29
  br label %bb6
bb6:
  %t51 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 1)
  store { i64, [4 x i64] } %t51, ptr %l30
  br label %bb7
bb7:
  %t52 = mul i64 2, 40
  %t53 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 2, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l31, !tbaa !27
  %t56 = load { i64, [4 x i64] }, ptr %l29
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t58, i64 0
  store { i64, [4 x i64] } %t56, ptr %t59
  %t60 = load { i64, [4 x i64] }, ptr %l30
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t62, i64 1
  store { i64, [4 x i64] } %t60, ptr %t63
  %t64 = load ptr, ptr %l28, !tbaa !29
  %t65 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t66 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t64, { i64, ptr } %t65)
  store %"compiler/mir:Range" %t66, ptr %l32
  br label %bb8
bb8:
  store { i64, [15 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [15 x i64] }, ptr %t67, i32 0, i32 0
  store i64 4, ptr %t68
  %t69 = load i32, ptr %l26, !range !{i32 0, i32 54}
  %t70 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t69, 0
  %t71 = load i32, ptr %l27, !tbaa !23
  %t72 = insertvalue { i32, i32, %"compiler/mir:Range" } %t70, i32 %t71, 1
  %t73 = load %"compiler/mir:Range", ptr %l32
  %t74 = insertvalue { i32, i32, %"compiler/mir:Range" } %t72, %"compiler/mir:Range" %t73, 2
  %t75 = getelementptr { i64, [15 x i64] }, ptr %t67, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t74, ptr %t75
  %t76 = load { i64, [15 x i64] }, ptr %t67
  store { i64, [21 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [21 x i64] }, ptr %t77, i32 0, i32 0
  store i64 0, ptr %t78
  %t79 = load %"compiler/source:Span", ptr %l23
  %t80 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t79, 0
  %t81 = load %"compiler/mir:Lvalue", ptr %l25
  %t82 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t80, %"compiler/mir:Lvalue" %t81, 1
  %t84 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t82, { i64, [15 x i64] } %t76, 2
  %t85 = getelementptr { i64, [21 x i64] }, ptr %t77, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t84, ptr %t85
  %t86 = load { i64, [21 x i64] }, ptr %t77
  store { i64, [21 x i64] } %t86, ptr %l34
  %t87 = load ptr, ptr %l21, !tbaa !29
  %t88 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t87, i32 %t88, ptr %l34)
  br label %bb9
bb9:
  %t90 = load ptr, ptr %lp4
  %t91 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  %t92 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t93 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [21 x i64] }, ptr %t94, i32 0, i32 0
  store i64 4, ptr %t95
  %t97 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t92, 0
  %t99 = insertvalue { %"compiler/source:Span", i32 } %t97, i32 %t93, 1
  %t100 = getelementptr { i64, [21 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t99, ptr %t100
  %t101 = load { i64, [21 x i64] }, ptr %t94
  store { i64, [21 x i64] } %t101, ptr %l40
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t90, i32 %t91, ptr %l40)
  br label %bb10
bb10:
  %t105 = load ptr, ptr %lp4
  store ptr %t105, ptr %l42, !tbaa !29
  %t106 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t106, ptr %l43, !tbaa !23
  %t107 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t107, ptr %l44
  %t108 = load i32, ptr %l5, !tbaa !23
  %t110 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t108)
  store %"compiler/mir:Lvalue" %t110, ptr %l46
  br label %bb11
bb11:
  store { i64, [4 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 0
  store i64 1, ptr %t112
  %t113 = load %"compiler/mir:Lvalue", ptr %l46
  %t114 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t113, 0
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t114, ptr %t115
  %t116 = load { i64, [4 x i64] }, ptr %t111
  store { i64, [8 x i64] } zeroinitializer, ptr %t117
  %t118 = getelementptr { i64, [8 x i64] }, ptr %t117, i32 0, i32 0
  store i64 5, ptr %t118
  %t119 = load %"compiler/source:Span", ptr %l44
  %t120 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t119, 0
  %t122 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t120, { i64, [4 x i64] } %t116, 1
  %t123 = getelementptr { i64, [8 x i64] }, ptr %t117, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t122, ptr %t123
  %t124 = load { i64, [8 x i64] }, ptr %t117
  %t125 = load ptr, ptr %l42, !tbaa !29
  %t126 = load i32, ptr %l43, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t125, i32 %t126, { i64, [8 x i64] } %t124)
  br label %bb12
bb12:
  %t128 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t128, i64 808, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l49, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2eoverflows64(i32 %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l38 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a3, label %bb1, label %bb2
bb1:
  %t3 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t5 = trunc i64 3 to i32
  %t6 = icmp eq i32 %t3, %t5
  br i1 %t6, label %bb3, label %bb4
bb2:
  br label %bb27
bb3:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = add i64 %t8, %t9
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = xor i64 %t14, %t15
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = xor i64 %t19, %t20
  %t26 = and i64 %t18, %t23
  %t28 = icmp slt i64 %t26, 0
  store i1 %t28, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t30 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t32 = trunc i64 4 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = xor i64 %t41, %t42
  %t46 = load i64, ptr %l1, !tbaa !24
  %t50 = xor i64 %t46, %t39
  %t53 = and i64 %t45, %t50
  %t55 = icmp slt i64 %t53, 0
  store i1 %t55, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t57 = load i64, ptr %l1, !tbaa !24
  %t59 = icmp eq i64 %t57, 0
  br i1 %t59, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb11
bb10:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t63 = icmp eq i64 %t61, 0
  store i1 %t63, ptr %l38, !tbaa !21
  br label %bb11
bb11:
  %t65 = load i1, ptr %l38, !tbaa !21
  br i1 %t65, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t67 = shl i64 1, 63
  store i64 %t67, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l1, !tbaa !24
  %t71 = icmp eq i64 %t69, -1
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp eq i64 %t73, %t74
  store i1 %t77, ptr %l45, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t79 = load i1, ptr %l45, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb23
bb19:
  %t80 = load i64, ptr %l2, !tbaa !24
  %t82 = icmp eq i64 %t80, -1
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = load i64, ptr %l6, !tbaa !24
  %t88 = icmp eq i64 %t84, %t85
  store i1 %t88, ptr %l52, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  %t90 = load i1, ptr %l52, !tbaa !21
  store i1 %t90, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t91 = load i1, ptr %l49, !tbaa !21
  br i1 %t91, label %bb24, label %bb25
bb24:
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t93 = load i64, ptr %l1, !tbaa !24
  %t94 = load i64, ptr %l2, !tbaa !24
  %t97 = mul i64 %t93, %t94
  %t98 = load i64, ptr %l2, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  %t102 = load i64, ptr %l1, !tbaa !24
  %t105 = icmp ne i64 %t101, %t102
  store i1 %t105, ptr %rv
  br label %ret
bb27:
  %t107 = load i64, ptr %l1, !tbaa !24
  store i64 %t107, ptr %l7, !tbaa !65
  %t110 = load i64, ptr %l2, !tbaa !24
  store i64 %t110, ptr %l8, !tbaa !65
  %t113 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t115 = trunc i64 3 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb28, label %bb29
bb28:
  %t118 = load i64, ptr %l7, !tbaa !65
  %t119 = load i64, ptr %l8, !tbaa !65
  %t122 = add i64 %t118, %t119
  %t123 = load i64, ptr %l7, !tbaa !65
  %t126 = icmp ult i64 %t122, %t123
  store i1 %t126, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t128 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t130 = trunc i64 4 to i32
  %t131 = icmp eq i32 %t128, %t130
  br i1 %t131, label %bb31, label %bb32
bb31:
  %t133 = load i64, ptr %l8, !tbaa !65
  %t134 = load i64, ptr %l7, !tbaa !65
  %t137 = icmp ugt i64 %t133, %t134
  store i1 %t137, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t139 = load i64, ptr %l7, !tbaa !65
  %t141 = icmp eq i64 %t139, 0
  br i1 %t141, label %bb34, label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t144 = load i64, ptr %l7, !tbaa !65
  %t145 = load i64, ptr %l8, !tbaa !65
  %t148 = mul i64 %t144, %t145
  %t149 = load i64, ptr %l7, !tbaa !65
  %t152 = udiv i64 %t148, %t149
  %t153 = load i64, ptr %l8, !tbaa !65
  %t156 = icmp ne i64 %t152, %t153
  store i1 %t156, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feval_2eplaceNamesGlobal(%"compiler/mir:Lvalue" %a0) #0 {
entry:
  %l0 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca i1
  %rv = alloca i1
  store %"compiler/mir:Lvalue" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l0, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  %t6 = extractvalue { i64, [2 x i64] } %t2, 0
  %t7 = icmp eq i64 %t6, 2
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d44b28fe9fc96fb9_71a7ff2b834e49cd)
  unreachable
bb9:
  %t9 = load i1, ptr %l3, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %a0) #0 {
entry:
  %l0 = alloca %"compiler/mir:Lvalue"
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca i64
  %rv = alloca i64
  store %"compiler/mir:Lvalue" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l0, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l1
  %t4 = load { i64, [2 x i64] }, ptr %l1
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t13 = load i32, ptr %l2, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c25b9553ef801192_ed4b8566966f1316)
  unreachable
bb9:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2erangeNamesGlobal(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l40 = alloca { i64, [4 x i64] }
  %l41 = alloca i1
  %rv = alloca i1
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l2, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  store i32 1, ptr %l4, !tbaa !23
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l12, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l3, !tbaa !23
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l15, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l15, !tbaa !23
  store i32 %t30, ptr %l12, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l12, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  store i32 0, ptr %l6, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l6, !tbaa !23
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load i32, ptr %l6, !tbaa !23
  %t42 = load i32, ptr %l4, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t52 = getelementptr %"compiler/mir:Fn", ptr %a0, i32 0, i32 11
  %t53 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t54 = load i32, ptr %t53, !tbaa !23
  %t56 = sext i32 %t54 to i64
  %t59 = sext i32 %t48 to i64
  %t62 = add i64 %t56, %t59
  %t65 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t52, i64 %t62)
  store { i64, [4 x i64] } %t65, ptr %l40
  br label %bb11
bb11:
  %t66 = load { i64, [4 x i64] }, ptr %l40
  %t67 = call i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %t66)
  store i1 %t67, ptr %l41
  br label %bb12
bb12:
  %t68 = load i1, ptr %l41, !tbaa !21
  br i1 %t68, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t70 = load i32, ptr %l6, !tbaa !23
  %t73 = add i32 %t70, 1
  store i32 %t73, ptr %l6, !tbaa !23
  br label %bb7
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2eretFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca %"compiler/mir:Fn"
  %l8 = alloca ptr
  %l10 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l17 = alloca %"compiler/mir:Lvalue"
  %l20 = alloca { i64, [21 x i64] }
  %l26 = alloca { i64, [21 x i64] }
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/mir:Lvalue"
  %l35 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t3 = alloca %"compiler/mir:Fn", align 8
  %t25 = alloca { i64, [15 x i64] }, align 8
  %t31 = alloca { i64, [21 x i64] }, align 8
  %t48 = alloca { i64, [21 x i64] }, align 8
  %t65 = alloca { i64, [4 x i64] }, align 8
  %t71 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2enfn(ptr %t3, ptr %v0, ptr %v1, ptr %t1, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t3, i64 808, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %l7, i64 808, i1 false)
  %t8 = load ptr, ptr %lp3
  store ptr %t8, ptr %l8, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i32 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = load i32, ptr %l10, !tbaa !23
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t13, i32 %t14, %"compiler/source:Span" %t12)
  store i32 %t16, ptr %l12
  br label %bb3
bb3:
  %t17 = load i32, ptr %l12, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = load ptr, ptr %lp3
  store ptr %t18, ptr %l13, !tbaa !29
  %t19 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t19, ptr %l14, !tbaa !23
  %t20 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t20, ptr %l15
  %t21 = load i32, ptr %l4, !tbaa !23
  %t23 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t21)
  store %"compiler/mir:Lvalue" %t23, ptr %l17
  br label %bb4
bb4:
  store { i64, [15 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [15 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t28 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %a2, 0
  %t29 = getelementptr { i64, [15 x i64] }, ptr %t25, i32 0, i32 1
  store { { i64, [4 x i64] } } %t28, ptr %t29
  %t30 = load { i64, [15 x i64] }, ptr %t25
  store { i64, [21 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [21 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t33 = load %"compiler/source:Span", ptr %l15
  %t34 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t33, 0
  %t35 = load %"compiler/mir:Lvalue", ptr %l17
  %t36 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t34, %"compiler/mir:Lvalue" %t35, 1
  %t38 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t36, { i64, [15 x i64] } %t30, 2
  %t39 = getelementptr { i64, [21 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t38, ptr %t39
  %t40 = load { i64, [21 x i64] }, ptr %t31
  store { i64, [21 x i64] } %t40, ptr %l20
  %t41 = load ptr, ptr %l13, !tbaa !29
  %t42 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t41, i32 %t42, ptr %l20)
  br label %bb5
bb5:
  %t44 = load ptr, ptr %lp3
  %t45 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  %t46 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t47 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [21 x i64] }, ptr %t48, i32 0, i32 0
  store i64 4, ptr %t49
  %t51 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t46, 0
  %t53 = insertvalue { %"compiler/source:Span", i32 } %t51, i32 %t47, 1
  %t54 = getelementptr { i64, [21 x i64] }, ptr %t48, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t53, ptr %t54
  %t55 = load { i64, [21 x i64] }, ptr %t48
  store { i64, [21 x i64] } %t55, ptr %l26
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t44, i32 %t45, ptr %l26)
  br label %bb6
bb6:
  %t59 = load ptr, ptr %lp3
  store ptr %t59, ptr %l28, !tbaa !29
  %t60 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t60, ptr %l29, !tbaa !23
  %t61 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t61, ptr %l30
  %t62 = load i32, ptr %l4, !tbaa !23
  %t64 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t62)
  store %"compiler/mir:Lvalue" %t64, ptr %l32
  br label %bb7
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t65
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 0
  store i64 1, ptr %t66
  %t67 = load %"compiler/mir:Lvalue", ptr %l32
  %t68 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t67, 0
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t68, ptr %t69
  %t70 = load { i64, [4 x i64] }, ptr %t65
  store { i64, [8 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [8 x i64] }, ptr %t71, i32 0, i32 0
  store i64 5, ptr %t72
  %t73 = load %"compiler/source:Span", ptr %l30
  %t74 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t73, 0
  %t76 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t74, { i64, [4 x i64] } %t70, 1
  %t77 = getelementptr { i64, [8 x i64] }, ptr %t71, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t76, ptr %t77
  %t78 = load { i64, [8 x i64] }, ptr %t71
  %t79 = load ptr, ptr %l28, !tbaa !29
  %t80 = load i32, ptr %l29, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t79, i32 %t80, { i64, [8 x i64] } %t78)
  br label %bb8
bb8:
  %t82 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %t82, i64 808, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l35, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2feval_2eshl128(i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l25 = alloca i64
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = insertvalue { i64, i64 } undef, i64 %t5, 0
  %t10 = insertvalue { i64, i64 } %t8, i64 %t6, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sge i64 %t12, 64
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l0, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t17, 64
  store i64 %t19, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = shl i64 %t16, %t22
  %t24 = insertvalue { i64, i64 } undef, i64 0, 0
  %t26 = insertvalue { i64, i64 } %t24, i64 %t23, 1
  store { i64, i64 } %t26, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l0, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  store i64 %t29, ptr %l16, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = shl i64 %t28, %t32
  %t34 = load i64, ptr %l1, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l19, !tbaa !24
  %t37 = load i64, ptr %l19, !tbaa !24
  %t38 = load i64, ptr %l19, !tbaa !24
  %t39 = shl i64 %t34, %t38
  %t40 = load i64, ptr %l0, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 64, %t42
  store i64 %t44, ptr %l25, !tbaa !65
  %t47 = load i64, ptr %l25, !tbaa !65
  %t48 = load i64, ptr %l25, !tbaa !65
  %t49 = lshr i64 %t40, %t48
  %t53 = or i64 %t39, %t49
  %t55 = insertvalue { i64, i64 } undef, i64 %t33, 0
  %t57 = insertvalue { i64, i64 } %t55, i64 %t53, 1
  store { i64, i64 } %t57, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2feval_2eshr128(i64 %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l15 = alloca i64
  %l24 = alloca i64
  %l31 = alloca i64
  %l36 = alloca i64
  %l42 = alloca i64
  %l49 = alloca i64
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = insertvalue { i64, i64 } undef, i64 %t5, 0
  %t10 = insertvalue { i64, i64 } %t8, i64 %t6, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sge i64 %t12, 64
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i1, ptr %l3, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb5:
  br label %bb9
bb6:
  %t18 = load i64, ptr %l1, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t19, 64
  store i64 %t21, ptr %l15, !tbaa !24
  %t23 = load i64, ptr %l15, !tbaa !24
  %t24 = load i64, ptr %l15, !tbaa !24
  %t25 = ashr i64 %t18, %t24
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = ashr i64 %t26, 63
  %t30 = insertvalue { i64, i64 } undef, i64 %t25, 0
  %t32 = insertvalue { i64, i64 } %t30, i64 %t28, 1
  store { i64, i64 } %t32, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t34 = load i64, ptr %l1, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = sub i64 %t36, 64
  store i64 %t38, ptr %l24, !tbaa !65
  %t41 = load i64, ptr %l24, !tbaa !65
  %t42 = load i64, ptr %l24, !tbaa !65
  %t43 = lshr i64 %t34, %t42
  %t46 = insertvalue { i64, i64 } undef, i64 %t43, 0
  %t47 = insertvalue { i64, i64 } %t46, i64 0, 1
  store { i64, i64 } %t47, ptr %rv
  br label %ret
bb9:
  %t49 = load i64, ptr %l0, !tbaa !24
  %t51 = load i64, ptr %l2, !tbaa !24
  store i64 %t51, ptr %l31, !tbaa !65
  %t54 = load i64, ptr %l31, !tbaa !65
  %t55 = load i64, ptr %l31, !tbaa !65
  %t56 = lshr i64 %t49, %t55
  %t58 = load i64, ptr %l1, !tbaa !24
  %t59 = load i64, ptr %l2, !tbaa !24
  %t61 = sub i64 64, %t59
  store i64 %t61, ptr %l36, !tbaa !24
  %t63 = load i64, ptr %l36, !tbaa !24
  %t64 = load i64, ptr %l36, !tbaa !24
  %t65 = shl i64 %t58, %t64
  %t68 = or i64 %t56, %t65
  store i64 %t68, ptr %l4, !tbaa !24
  %t70 = load i1, ptr %l3, !tbaa !21
  br i1 %t70, label %bb10, label %bb11
bb10:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load i64, ptr %l2, !tbaa !24
  store i64 %t74, ptr %l42, !tbaa !24
  %t76 = load i64, ptr %l42, !tbaa !24
  %t77 = load i64, ptr %l42, !tbaa !24
  %t78 = ashr i64 %t73, %t77
  %t80 = insertvalue { i64, i64 } undef, i64 %t72, 0
  %t82 = insertvalue { i64, i64 } %t80, i64 %t78, 1
  store { i64, i64 } %t82, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t84 = load i64, ptr %l4, !tbaa !24
  %t85 = load i64, ptr %l1, !tbaa !24
  %t87 = load i64, ptr %l2, !tbaa !24
  store i64 %t87, ptr %l49, !tbaa !65
  %t90 = load i64, ptr %l49, !tbaa !65
  %t91 = load i64, ptr %l49, !tbaa !65
  %t92 = lshr i64 %t85, %t91
  %t95 = insertvalue { i64, i64 } undef, i64 %t84, 0
  %t97 = insertvalue { i64, i64 } %t95, i64 %t92, 1
  store { i64, i64 } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2feval_2esub128(i64 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = sub i64 %t1, %t2
  store i64 %t5, ptr %l6, !tbaa !24
  %t10 = sub i64 %a1, %a3
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load i64, ptr %l0, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i1 @compiler_2feval_2eult64(i64 %t11, i64 %t12)
  store i1 %t15, ptr %l12
  br label %bb1
bb1:
  %t16 = load i1, ptr %l12, !tbaa !21
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i64 1, ptr %l13, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = load i64, ptr %l13, !tbaa !24
  %t19 = sub i64 %t17, %t18
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = insertvalue { i64, i64 } undef, i64 %t20, 0
  %t23 = insertvalue { i64, i64 } %t21, i64 %t19, 1
  store { i64, i64 } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 %a0) #0 {
entry:
  %l2 = alloca %"compiler/mir:Lvalue"
  %rv = alloca { i64, [4 x i64] }
  %t4 = alloca { i64, [4 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/mir:Lvalue" @compiler_2feval_2etl(i64 %a0)
  store %"compiler/mir:Lvalue" %t3, ptr %l2
  br label %bb1
bb1:
  store { i64, [4 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 0
  store i64 1, ptr %t5
  %t6 = load %"compiler/mir:Lvalue", ptr %l2
  %t7 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t6, 0
  %t8 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t7, ptr %t8
  %t9 = load { i64, [4 x i64] }, ptr %t4
  store { i64, [4 x i64] } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2feval_2etdecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l17 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = call ptr @__olang_scope_hold(ptr %v0)
  %t3 = ptrtoint ptr %t2 to i64
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = call ptr @__olang_region_make(ptr %v0)
  %t7 = ptrtoint ptr %t6 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t8, 1
  %t13 = extractvalue { i64, ptr } %t8, 0
  %t14 = add i64 %t10, %t13
  %t15 = load i64, ptr %l6
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = call ptr @__olang_held_alloc(ptr %t16, i64 %t14)
  call void @olang_textcopy(ptr %t17, ptr %t9, i64 %t10)
  %t18 = getelementptr i8, ptr %t17, i64 %t10
  call void @olang_textcopy(ptr %t18, ptr %t12, i64 %t13)
  %t19 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  %t22 = load ptr, ptr %l5, !tbaa !29
  %t24 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t20)
  store i64 %t24, ptr %l11
  br label %bb3
bb3:
  %t25 = load i64, ptr %l11, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l12, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  store i64 %t25, ptr %l14, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v2, ptr %a1, { i64, ptr } %t30)
  store i32 %t33, ptr %l17
  br label %bb4
bb4:
  %t35 = load ptr, ptr %l13, !tbaa !29
  %t36 = load i64, ptr %l14, !tbaa !24
  %t37 = load i32, ptr %l17, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %v3, ptr %t35, i64 %t36, i32 %t37, i32 %a2, i32 0)
  store i32 %t39, ptr %l19
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l12, !tbaa !29
  %t41 = load i32, ptr %l19, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t40, i32 %t41, i32 0)
  store i32 %t42, ptr %l20
  br label %bb6
bb6:
  %t43 = load i32, ptr %l20, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2feval_2etdefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v2, ptr %v0, ptr %s0, ptr %t1, ptr %a0)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i1, ptr %l8, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v1, ptr %v2, ptr %a1, ptr %t12)
  br label %bb5
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = extractvalue { i64, ptr } %t15, 0
  %t19 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  call void @__olang_check_failed_text(ptr @olang_loc_48f03219a23009f5_27a95ef9d9612249, { i64, ptr } %t20)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2feval_2eterr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = call ptr @__olang_scope_hold(ptr %v0)
  %t3 = ptrtoint ptr %t2 to i64
  store i64 %t3, ptr %l5, !tbaa !24
  %t4 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = call ptr @__olang_region_make(ptr %v0)
  %t7 = ptrtoint ptr %t6 to i64
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t8, 1
  %t13 = extractvalue { i64, ptr } %t8, 0
  %t14 = add i64 %t10, %t13
  %t15 = load i64, ptr %l5
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = call ptr @__olang_held_alloc(ptr %t16, i64 %t14)
  call void @olang_textcopy(ptr %t17, ptr %t9, i64 %t10)
  %t18 = getelementptr i8, ptr %t17, i64 %t10
  call void @olang_textcopy(ptr %t18, ptr %t12, i64 %t13)
  %t19 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t20)
  store i64 %t24, ptr %l10
  br label %bb3
bb3:
  %t25 = load i64, ptr %l10, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l11, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l12, !tbaa !29
  store i64 %t25, ptr %l13, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v2, ptr %a1, { i64, ptr } %t30)
  store i32 %t33, ptr %l16
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l12, !tbaa !29
  %t35 = load i64, ptr %l13, !tbaa !24
  %t36 = load i32, ptr %l16, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %v3, ptr %t34, i64 %t35, i32 %t36, i32 2, i32 0)
  store i32 %t38, ptr %l18
  br label %bb5
bb5:
  %t39 = load ptr, ptr %l11, !tbaa !29
  %t40 = load i32, ptr %l18, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t39, i32 %t40, i32 0)
  store i32 %t41, ptr %l19
  br label %bb6
bb6:
  %t42 = load i32, ptr %l19, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2feval_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l14 = alloca %"compiler/mir:Fn"
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l32 = alloca i32
  %l40 = alloca i32
  %l42 = alloca i32
  %l47 = alloca { i64, [21 x i64] }
  %l49 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t5 = alloca { i64, [2 x i64] }, align 8
  %t13 = alloca %"compiler/mir:Fn", align 8
  %t76 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = trunc i64 %a1 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [2 x i64] }, ptr %t5
  %t11 = load i32, ptr %l2, !tbaa !23
  %t12 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  call void @compiler_2fmir_3aFn_2ector(ptr %t13, ptr %v1, { i64, [2 x i64] } %t10, i32 %t11, i64 0, %"compiler/source:Span" %t12)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %t13, i64 808, i1 false)
  br label %bb1
bb1:
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  store ptr %t17, ptr %lp3
  %t18 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %l14, i64 808, i1 false)
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l18
  br label %bb2
bb2:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = load i32, ptr %l18, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t25, i32 %t26)
  store { i64, ptr } %t27, ptr %l19
  br label %bb3
bb3:
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t41, ptr %l26, !tbaa !27
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 %t42
  %t47 = load i32, ptr %t46, !tbaa !33
  %t49 = load ptr, ptr %lp3
  %t50 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t55 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v1, ptr %t49, i32 0, %"compiler/source:Span" %t50, i32 %t47)
  store i32 %t55, ptr %l32
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t56, 1
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb4
bb10:
  %t61 = load ptr, ptr %lp3
  %t62 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t63 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t68 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v1, ptr %t61, i32 0, i32 %t62, i32 0, %"compiler/source:Span" %t63, i32 0)
  store i32 %t68, ptr %l40
  br label %bb11
bb11:
  %t69 = load ptr, ptr %lp3
  %t71 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t69)
  store i32 %t71, ptr %l42
  br label %bb12
bb12:
  %t72 = load ptr, ptr %lp3
  %t73 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  %t74 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t75 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t76
  %t77 = getelementptr { i64, [21 x i64] }, ptr %t76, i32 0, i32 0
  store i64 3, ptr %t77
  %t79 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t74, 0
  %t81 = insertvalue { %"compiler/source:Span", i32 } %t79, i32 %t75, 1
  %t82 = getelementptr { i64, [21 x i64] }, ptr %t76, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t81, ptr %t82
  %t83 = load { i64, [21 x i64] }, ptr %t76
  store { i64, [21 x i64] } %t83, ptr %l47
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t72, i32 %t73, ptr %l47)
  br label %bb13
bb13:
  %t87 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t87, i64 808, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l49, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2feval_2etkey(i64 %a0) #0 {
entry:
  %rv = alloca { i64, [2 x i64] }
  %t5 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 %a0 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local %"compiler/mir:Lvalue" @compiler_2feval_2etl(i64 %a0) #0 {
entry:
  %l4 = alloca %"compiler/mir:Lvalue"
  %rv = alloca %"compiler/mir:Lvalue"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 %a0 to i32
  %t6 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t3)
  store %"compiler/mir:Lvalue" %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load %"compiler/mir:Lvalue", ptr %l4
  store %"compiler/mir:Lvalue" %t7, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local void @compiler_2feval_2etprim(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3, i32 %a4, { i64, [4 x i64] } %a5, { i64, [4 x i64] } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca i32
  %l13 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"compiler/mir:Range"
  %l20 = alloca { i64, [21 x i64] }
  %s0 = alloca %olang.scope
  %t27 = alloca { i64, [15 x i64] }, align 8
  %t37 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i32 %a1, ptr %l8, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t3, ptr %l9
  %t6 = call %"compiler/mir:Lvalue" @compiler_2feval_2etl(i64 %a2)
  store %"compiler/mir:Lvalue" %t6, ptr %l11
  br label %bb1
bb1:
  store i32 %a3, ptr %l12
  store i32 %a4, ptr %l13, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t12 = mul i64 2, 40
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 2, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, [4 x i64] }, ptr %t18, i64 0
  store { i64, [4 x i64] } %a5, ptr %t19
  %t21 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t22, i64 1
  store { i64, [4 x i64] } %a6, ptr %t23
  %t25 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t26 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } %t25)
  store %"compiler/mir:Range" %t26, ptr %l18
  br label %bb2
bb2:
  store { i64, [15 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [15 x i64] }, ptr %t27, i32 0, i32 0
  store i64 3, ptr %t28
  %t29 = load i32, ptr %l12, !range !{i32 0, i32 54}
  %t30 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t29, 0
  %t31 = load i32, ptr %l13, !tbaa !23
  %t32 = insertvalue { i32, i32, %"compiler/mir:Range" } %t30, i32 %t31, 1
  %t33 = load %"compiler/mir:Range", ptr %l18
  %t34 = insertvalue { i32, i32, %"compiler/mir:Range" } %t32, %"compiler/mir:Range" %t33, 2
  %t35 = getelementptr { i64, [15 x i64] }, ptr %t27, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t34, ptr %t35
  %t36 = load { i64, [15 x i64] }, ptr %t27
  store { i64, [21 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [21 x i64] }, ptr %t37, i32 0, i32 0
  store i64 0, ptr %t38
  %t39 = load %"compiler/source:Span", ptr %l9
  %t40 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t39, 0
  %t41 = load %"compiler/mir:Lvalue", ptr %l11
  %t42 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t40, %"compiler/mir:Lvalue" %t41, 1
  %t44 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t42, { i64, [15 x i64] } %t36, 2
  %t45 = getelementptr { i64, [21 x i64] }, ptr %t37, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t44, ptr %t45
  %t46 = load { i64, [21 x i64] }, ptr %t37
  store { i64, [21 x i64] } %t46, ptr %l20
  %t47 = load ptr, ptr %l7, !tbaa !29
  %t48 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %s0, ptr %t47, i32 %t48, ptr %l20)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2etrueOverflows(i32 %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l18 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l40 = alloca i64
  %l46 = alloca i1
  %l54 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t7 = trunc i64 3 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb3, label %bb4
bb2:
  br label %bb18
bb3:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = add i64 %t10, %t11
  store i64 %t14, ptr %l12, !tbaa !24
  br label %bb8
bb4:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t18 = trunc i64 4 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t21, %t22
  store i64 %t25, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  %t27 = load i64, ptr %l1, !tbaa !24
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = mul i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t34 = load i64, ptr %l12, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  %t35 = load i1, ptr %l4, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = mul i64 8, %t37
  %t41 = sub i64 %t39, 1
  store i64 %t41, ptr %l29, !tbaa !24
  %t42 = load i64, ptr %l29, !tbaa !24
  %t43 = load i64, ptr %l29, !tbaa !24
  %t44 = shl i64 1, %t43
  %t46 = sub i64 0, %t44
  store i64 %t46, ptr %l26, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l26, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i1, ptr %l4, !tbaa !21
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t53 = mul i64 8, %t51
  %t55 = sub i64 %t53, 1
  store i64 %t55, ptr %l36, !tbaa !24
  %t56 = load i64, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = shl i64 1, %t57
  %t60 = sub i64 %t58, 1
  store i64 %t60, ptr %l33, !tbaa !24
  br label %bb14
bb13:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = mul i64 8, %t62
  store i64 %t64, ptr %l40, !tbaa !24
  %t65 = load i64, ptr %l40, !tbaa !24
  %t66 = load i64, ptr %l40, !tbaa !24
  %t67 = shl i64 1, %t66
  %t69 = sub i64 %t67, 1
  store i64 %t69, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t71 = load i64, ptr %l33, !tbaa !24
  store i64 %t71, ptr %l7, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  br i1 %t76, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  store i1 %t82, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t84 = load i1, ptr %l46, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb18:
  %t85 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t86 = load i64, ptr %l1, !tbaa !24
  %t87 = load i64, ptr %l2, !tbaa !24
  %t88 = load i1, ptr %l4, !tbaa !21
  %t93 = call i1 @compiler_2feval_2eoverflows64(i32 %t85, i64 %t86, i64 %t87, i1 %t88)
  store i1 %t93, ptr %l54
  br label %bb19
bb19:
  %t94 = load i1, ptr %l54, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2feval_2etspan(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = trunc i64 %t1 to i32
  %t4 = load i64, ptr %l0, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = trunc i64 %t6 to i32
  %t11 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t3, i32 %t8)
  store %"compiler/source:Span" %t11, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local { i64, i64, i64, i64 } @compiler_2feval_2eudivmod128(i64 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, i64 }
  %l16 = alloca { i64, i64 }
  %l18 = alloca { i64, i64 }
  %l21 = alloca i1
  %l40 = alloca i64
  %l43 = alloca i64
  %l65 = alloca { i64, i64 }
  %l71 = alloca { i64, i64 }
  %l82 = alloca i64
  %l88 = alloca { i64, i64 }
  %l96 = alloca i64
  %l101 = alloca i64
  %rv = alloca { i64, i64, i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  store i1 %t7, ptr %l21, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l21, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load i64, ptr %l0, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t16 = udiv i64 %t10, %t12
  %t18 = load i64, ptr %l0, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t24 = urem i64 %t18, %t20
  %t27 = insertvalue { i64, i64, i64, i64 } undef, i64 %t16, 0
  %t28 = insertvalue { i64, i64, i64, i64 } %t27, i64 0, 1
  %t30 = insertvalue { i64, i64, i64, i64 } %t28, i64 %t24, 2
  %t31 = insertvalue { i64, i64, i64, i64 } %t30, i64 0, 3
  store { i64, i64, i64, i64 } %t31, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  store i64 128, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t33 = load i64, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load i64, ptr %l10, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb12
bb9:
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l10, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l10, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l43, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb11
bb11:
  %t59 = load i64, ptr %l43, !tbaa !24
  store i64 %t59, ptr %l40, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l40, !tbaa !24
  store i64 %t60, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l12, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb14, label %bb15
bb14:
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  %t81 = sub i64 127, %t77
  store i64 %t81, ptr %l14, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = call { i64, i64 } @compiler_2feval_2eshl128(i64 %t83, i64 %t84, i64 1)
  store { i64, i64 } %t87, ptr %l65
  br label %bb17
bb17:
  %t88 = load { i64, i64 }, ptr %l65
  store { i64, i64 } %t88, ptr %l15
  %t89 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 0
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t90, ptr %l6, !tbaa !24
  %t92 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  store i64 %t93, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l0, !tbaa !24
  %t96 = load i64, ptr %l1, !tbaa !24
  %t97 = load i64, ptr %l14, !tbaa !24
  %t101 = call { i64, i64 } @compiler_2feval_2eshr128(i64 %t95, i64 %t96, i64 %t97, i1 false)
  store { i64, i64 } %t101, ptr %l71
  br label %bb18
bb18:
  %t102 = load { i64, i64 }, ptr %l71
  store { i64, i64 } %t102, ptr %l16
  %t103 = getelementptr { i64, i64 }, ptr %l16, i32 0, i32 0
  %t104 = load i64, ptr %t103, !tbaa !24
  %t106 = load i64, ptr %l6, !tbaa !24
  %t110 = and i64 %t104, 1
  %t113 = or i64 %t106, %t110
  store i64 %t113, ptr %l6, !tbaa !24
  %t115 = load i64, ptr %l6, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t117 = load i64, ptr %l2, !tbaa !24
  %t118 = load i64, ptr %l3, !tbaa !24
  %t123 = call i64 @compiler_2feval_2ecmp128(i64 %t115, i64 %t116, i64 %t117, i64 %t118, i1 false)
  store i64 %t123, ptr %l82
  br label %bb19
bb19:
  %t124 = load i64, ptr %l82, !tbaa !24
  %t125 = icmp sge i64 %t124, 0
  br i1 %t125, label %bb20, label %bb21
bb20:
  %t127 = load i64, ptr %l6, !tbaa !24
  %t128 = load i64, ptr %l7, !tbaa !24
  %t129 = load i64, ptr %l2, !tbaa !24
  %t130 = load i64, ptr %l3, !tbaa !24
  %t135 = call { i64, i64 } @compiler_2feval_2esub128(i64 %t127, i64 %t128, i64 %t129, i64 %t130)
  store { i64, i64 } %t135, ptr %l88
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t136 = load { i64, i64 }, ptr %l88
  store { i64, i64 } %t136, ptr %l18
  %t137 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  store i64 %t138, ptr %l6, !tbaa !24
  %t140 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 1
  %t141 = load i64, ptr %t140, !tbaa !24
  store i64 %t141, ptr %l7, !tbaa !24
  %t143 = load i64, ptr %l14, !tbaa !24
  %t145 = icmp sge i64 %t143, 64
  br i1 %t145, label %bb23, label %bb24
bb23:
  %t147 = load i64, ptr %l5, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t151 = sub i64 %t149, 64
  store i64 %t151, ptr %l96, !tbaa !24
  %t152 = load i64, ptr %l96, !tbaa !24
  %t153 = load i64, ptr %l96, !tbaa !24
  %t154 = shl i64 1, %t153
  %t157 = or i64 %t147, %t154
  store i64 %t157, ptr %l5, !tbaa !24
  br label %bb25
bb24:
  %t159 = load i64, ptr %l4, !tbaa !24
  %t161 = load i64, ptr %l14, !tbaa !24
  store i64 %t161, ptr %l101, !tbaa !24
  %t162 = load i64, ptr %l101, !tbaa !24
  %t163 = load i64, ptr %l101, !tbaa !24
  %t164 = shl i64 1, %t163
  %t167 = or i64 %t159, %t164
  store i64 %t167, ptr %l4, !tbaa !24
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t169 = load i64, ptr %l12, !tbaa !24
  %t172 = add i64 %t169, 1
  store i64 %t172, ptr %l12, !tbaa !24
  br label %bb13
bb28:
  %t174 = load i64, ptr %l4, !tbaa !24
  %t175 = load i64, ptr %l5, !tbaa !24
  %t176 = load i64, ptr %l6, !tbaa !24
  %t177 = load i64, ptr %l7, !tbaa !24
  %t179 = insertvalue { i64, i64, i64, i64 } undef, i64 %t174, 0
  %t181 = insertvalue { i64, i64, i64, i64 } %t179, i64 %t175, 1
  %t183 = insertvalue { i64, i64, i64, i64 } %t181, i64 %t176, 2
  %t185 = insertvalue { i64, i64, i64, i64 } %t183, i64 %t177, 3
  store { i64, i64, i64, i64 } %t185, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64, i64, i64 }, ptr %rv
  ret { i64, i64, i64, i64 } %rr
}

define dso_local i1 @compiler_2feval_2eult64(i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t7 = icmp ult i64 %a0, %a1
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, i64 } @compiler_2feval_2ewideMax(i64 %a0, i1 %a1) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, i64 }
  %l7 = alloca i64
  %l15 = alloca { i64, i64 }
  %l20 = alloca { i64, i64 }
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a1, label %bb1, label %bb2
bb1:
  %t3 = load i64, ptr %l0, !tbaa !24
  %t5 = sub i64 %t3, 1
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb3
bb2:
  %t7 = load i64, ptr %l0, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l7, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t10, 128
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t15 = insertvalue { i64, i64 } %t14, i64 -1, 1
  store { i64, i64 } %t15, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = call { i64, i64 } @compiler_2feval_2eshl128(i64 1, i64 0, i64 %t17)
  store { i64, i64 } %t19, ptr %l15
  br label %bb7
bb7:
  %t20 = load { i64, i64 }, ptr %l15
  store { i64, i64 } %t20, ptr %l3
  %t21 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 1
  %t25 = load i64, ptr %t24, !tbaa !24
  %t31 = call { i64, i64 } @compiler_2feval_2esub128(i64 %t22, i64 %t25, i64 1, i64 0)
  store { i64, i64 } %t31, ptr %l20
  br label %bb8
bb8:
  %t32 = load { i64, i64 }, ptr %l20
  store { i64, i64 } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2feval_2ewideMin(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, i64 }
  %l7 = alloca i64
  %l11 = alloca { i64, i64 }
  %l16 = alloca { i64, i64 }
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sle i64 %t1, 64
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = call i64 @compiler_2feval_2eminBits(i64 %t5)
  store i64 %t7, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = insertvalue { i64, i64 } undef, i64 %t8, 0
  %t10 = insertvalue { i64, i64 } %t9, i64 -1, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb4:
  %t12 = load i64, ptr %l0, !tbaa !24
  %t14 = sub i64 %t12, 1
  %t16 = call { i64, i64 } @compiler_2feval_2eshl128(i64 1, i64 0, i64 %t14)
  store { i64, i64 } %t16, ptr %l11
  br label %bb5
bb5:
  %t17 = load { i64, i64 }, ptr %l11
  store { i64, i64 } %t17, ptr %l1
  %t18 = getelementptr { i64, i64 }, ptr %l1, i32 0, i32 0
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = getelementptr { i64, i64 }, ptr %l1, i32 0, i32 1
  %t22 = load i64, ptr %t21, !tbaa !24
  %t28 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t19, i64 %t22)
  store { i64, i64 } %t28, ptr %l16
  br label %bb6
bb6:
  %t29 = load { i64, i64 }, ptr %l16
  store { i64, i64 } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/eval:Image"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aImage_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aImage_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l3
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l0
  %t22 = call ptr @__olang_scope_hold(ptr %v0)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l7, !tbaa !24
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aImage_2e1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = call ptr @__olang_region_make(ptr %v0)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l7
  %t29 = inttoptr i64 %t28 to ptr
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t29, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l9
  br label %bb8
bb8:
  %t31 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aImage_2e1
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load i64, ptr %l7
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = call ptr @__olang_region_or(ptr %t37, ptr null)
  %t39 = call ptr @__olang_region_home(ptr %t38)
  %t40 = icmp ne ptr %t39, null
  %t41 = select i1 %t40, ptr %t39, ptr null
  call void @__olang_region_settle_in(ptr %t34, ptr %t41)
  br label %bb10
bb10:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t43 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  %t44 = insertvalue %"compiler/eval:Image" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, 0
  %t46 = insertvalue %"compiler/eval:Image" %t44, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, 1
  %t48 = insertvalue %"compiler/eval:Image" %t46, i1 false, 2
  store %"compiler/eval:Image" %t48, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Image", ptr %rv
  ret %"compiler/eval:Image" %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/eval:Ptr"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/eval:Ptr" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/eval:Ptr" %t6, i64 %a1, 1
  store %"compiler/eval:Ptr" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local %"compiler/eval:alloc" @compiler_2feval_3aalloc_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/eval:alloc"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/eval:alloc" undef, i64 0, 0
  %t4 = insertvalue %"compiler/eval:alloc" %t2, i64 0, 1
  %t6 = insertvalue %"compiler/eval:alloc" %t4, i64 0, 2
  %t8 = insertvalue %"compiler/eval:alloc" %t6, i64 0, 3
  %t10 = insertvalue %"compiler/eval:alloc" %t8, i64 0, 4
  %t12 = insertvalue %"compiler/eval:alloc" %t10, i64 0, 5
  %t14 = insertvalue %"compiler/eval:alloc" %t12, i64 0, 6
  %t16 = insertvalue %"compiler/eval:alloc" %t14, i64 0, 7
  %t18 = insertvalue %"compiler/eval:alloc" %t16, i64 -1, 8
  %t20 = insertvalue %"compiler/eval:alloc" %t18, i64 -1, 9
  %t22 = insertvalue %"compiler/eval:alloc" %t20, i64 0, 10
  %t24 = insertvalue %"compiler/eval:alloc" %t22, i32 0, 11
  %t26 = insertvalue %"compiler/eval:alloc" %t24, i64 -1, 12
  %t28 = insertvalue %"compiler/eval:alloc" %t26, i1 false, 13
  %t30 = insertvalue %"compiler/eval:alloc" %t28, i64 -1, 14
  %t32 = insertvalue %"compiler/eval:alloc" %t30, i1 false, 15
  store %"compiler/eval:alloc" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:alloc", ptr %rv
  ret %"compiler/eval:alloc" %rr
}

define dso_local void @compiler_2feval_3acfn_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l19 = alloca %"compiler/eval:cfn"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 0
  store i64 0, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t3, !tbaa !27
  %t5 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t5, !tbaa !27
  %t7 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 3
  store { i64, ptr } zeroinitializer, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 4
  store { i64, ptr } zeroinitializer, ptr %t9, !tbaa !27
  %t11 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 5
  store { i64, ptr } zeroinitializer, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 6
  store { i64, ptr } zeroinitializer, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 7
  store { i64, ptr } zeroinitializer, ptr %t15, !tbaa !27
  %t17 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 8
  store { i64, ptr } zeroinitializer, ptr %t17, !tbaa !27
  %t19 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 9
  store { i64, ptr } zeroinitializer, ptr %t19, !tbaa !27
  %t21 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 10
  store { i64, ptr } zeroinitializer, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 11
  store { i64, ptr } zeroinitializer, ptr %t23, !tbaa !27
  %t25 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 12
  store { i64, ptr } zeroinitializer, ptr %t25, !tbaa !27
  %t27 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 13
  store { i64, ptr } zeroinitializer, ptr %t27, !tbaa !27
  %t29 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 14
  store { i64, ptr } zeroinitializer, ptr %t29, !tbaa !27
  %t31 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 15
  store i64 0, ptr %t31, !tbaa !24
  %t33 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 16
  store i1 false, ptr %t33, !tbaa !21
  %t35 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 17
  store i1 false, ptr %t35, !tbaa !21
  %t37 = getelementptr %"compiler/eval:cfn", ptr %l19, i32 0, i32 18
  store { i64, ptr } zeroinitializer, ptr %t37, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l19, i64 264, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:dkey" @compiler_2feval_3adkey_2ector(ptr %v0, i64 %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5) #0 {
entry:
  %rv = alloca %"compiler/eval:dkey"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/eval:dkey" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/eval:dkey" %t14, i32 %a1, 1
  %t18 = insertvalue %"compiler/eval:dkey" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/eval:dkey" %t18, i32 %a3, 3
  %t22 = insertvalue %"compiler/eval:dkey" %t20, i32 %a4, 4
  %t24 = insertvalue %"compiler/eval:dkey" %t22, i64 %a5, 5
  store %"compiler/eval:dkey" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:dkey", ptr %rv
  ret %"compiler/eval:dkey" %rr
}

define dso_local void @compiler_2feval_3aframe_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l20 = alloca %"compiler/eval:frame"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 0
  store i64 0, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 1
  store i64 0, ptr %t3, !tbaa !24
  %t5 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 2
  store i64 0, ptr %t5, !tbaa !24
  %t7 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 3
  store i64 0, ptr %t7, !tbaa !24
  %t9 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 4
  store i64 0, ptr %t9, !tbaa !24
  %t11 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 5
  store i64 0, ptr %t11, !tbaa !24
  %t13 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 6
  store i64 0, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 7
  store i64 0, ptr %t15, !tbaa !24
  %t17 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 8
  store i64 0, ptr %t17, !tbaa !24
  %t19 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 9
  store i64 0, ptr %t19, !tbaa !24
  %t21 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 10
  store i1 false, ptr %t21, !tbaa !21
  %t23 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 11
  store i1 false, ptr %t23, !tbaa !21
  %t25 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 12
  store i1 false, ptr %t25, !tbaa !21
  %t27 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 13
  store i64 0, ptr %t27, !tbaa !24
  %t29 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 14
  store i64 -1, ptr %t29, !tbaa !24
  %t31 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 15
  store i1 false, ptr %t31, !tbaa !21
  %t33 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 16
  store i64 -1, ptr %t33, !tbaa !24
  %t35 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 17
  store i32 0, ptr %t35, !tbaa !23
  %t37 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 18
  store i32 -1, ptr %t37, !tbaa !23
  %t39 = getelementptr %"compiler/eval:frame", ptr %l20, i32 0, i32 19
  store i64 0, ptr %t39, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l20, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %v0, i64 %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/eval:gkey"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/eval:gkey" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/eval:gkey" %t6, i32 %a1, 1
  store %"compiler/eval:gkey" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:gkey", ptr %rv
  ret %"compiler/eval:gkey" %rr
}

define dso_local %"compiler/eval:global" @compiler_2feval_3aglobal_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/eval:global"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/eval:global" undef, i64 0, 0
  %t4 = insertvalue %"compiler/eval:global" %t2, i1 false, 1
  %t6 = insertvalue %"compiler/eval:global" %t4, i64 -1, 2
  %t8 = insertvalue %"compiler/eval:global" %t6, i64 0, 3
  %t10 = insertvalue %"compiler/eval:global" %t8, i64 0, 4
  %t12 = insertvalue %"compiler/eval:global" %t10, i1 false, 5
  %t14 = insertvalue %"compiler/eval:global" %t12, i1 false, 6
  %t16 = insertvalue %"compiler/eval:global" %t14, i1 false, 7
  store %"compiler/eval:global" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:global", ptr %rv
  ret %"compiler/eval:global" %rr
}

define dso_local %"compiler/eval:reg" @compiler_2feval_3areg_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/eval:reg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/eval:reg" undef, i64 0, 0
  %t4 = insertvalue %"compiler/eval:reg" %t2, i64 0, 1
  %t6 = insertvalue %"compiler/eval:reg" %t4, i64 0, 2
  %t8 = insertvalue %"compiler/eval:reg" %t6, i64 0, 3
  %t10 = insertvalue %"compiler/eval:reg" %t8, i64 -1, 4
  %t12 = insertvalue %"compiler/eval:reg" %t10, i64 -1, 5
  %t14 = insertvalue %"compiler/eval:reg" %t12, i64 0, 6
  %t16 = insertvalue %"compiler/eval:reg" %t14, i64 -1, 7
  store %"compiler/eval:reg" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:reg", ptr %rv
  ret %"compiler/eval:reg" %rr
}

define dso_local void @compiler_2feval_3ascope_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l20 = alloca %"compiler/eval:scope"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 0
  store i64 0, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 1
  store i1 false, ptr %t3, !tbaa !21
  %t5 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 2
  store i64 0, ptr %t5, !tbaa !24
  %t7 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 3
  store i64 0, ptr %t7, !tbaa !24
  %t9 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 4
  store i64 -1, ptr %t9, !tbaa !24
  %t11 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 5
  store i64 0, ptr %t11, !tbaa !24
  %t13 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 6
  store i64 0, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 7
  store i64 0, ptr %t15, !tbaa !24
  %t17 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 8
  store i64 0, ptr %t17, !tbaa !24
  %t19 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 9
  store i64 0, ptr %t19, !tbaa !24
  %t21 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 10
  store i64 -1, ptr %t21, !tbaa !24
  %t23 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 11
  store i64 -1, ptr %t23, !tbaa !24
  %t25 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 12
  store i64 0, ptr %t25, !tbaa !24
  %t27 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 13
  store i64 0, ptr %t27, !tbaa !24
  %t29 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 14
  store i64 0, ptr %t29, !tbaa !24
  %t31 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 15
  store i1 false, ptr %t31, !tbaa !21
  %t33 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 16
  store i64 0, ptr %t33, !tbaa !24
  %t35 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 17
  store i64 -1, ptr %t35, !tbaa !24
  %t37 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 18
  store i1 false, ptr %t37, !tbaa !21
  %t39 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 19
  store i1 false, ptr %t39, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l20, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:task" @compiler_2feval_3atask_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/eval:task"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/eval:task" undef, i64 0, 0
  %t4 = insertvalue %"compiler/eval:task" %t2, i64 0, 1
  %t6 = insertvalue %"compiler/eval:task" %t4, i64 0, 2
  %t8 = insertvalue %"compiler/eval:task" %t6, i64 -1, 3
  %t10 = insertvalue %"compiler/eval:task" %t8, i64 0, 4
  store %"compiler/eval:task" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:task", ptr %rv
  ret %"compiler/eval:task" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d0 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"OLANG_DEADREGIONS" }>, align 8
declare void @__olang_errpay_pop()
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"olang: internal compiler error: file " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d15 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d17 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d20 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"eval_test_" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr }) cold noreturn
@.d22 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"eval_test_" }>, align 8
@olang_2esole_2ecompiler_2feval_3aImage_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler_2feval_3aImage_2e1 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare void @compiler_2feval_3aMachine_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2ePush_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0, ptr %a1)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %a0, %"compiler/eval:gkey" %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eRefMut_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Haf69023555548e8239d9db5dde4c25f9(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eLen_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eP_Hdbb1ec214f67f51e9ea8789b3bf075dc(ptr %v0, ptr %a0, %"compiler/eval:gkey" %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2ePush_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, %"compiler/eval:global" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_H6f34e373626f6b99bb5e62c0fd8bd7a4(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__Hbdd7c5068e376aa260a62181a9f99429(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_Hd8d89e440939766a34c786789c5d3b97(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_a07810e0cbb459c4_651f13a6a529fa18 = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2estepClose(ptr %v0, ptr %a0)
declare %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2elayoutOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eLen_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H1a77801a5ab3ea58cbf0ff15b43ff2de(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eRefMut_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eSetAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:reg" %a2)
declare { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2)
@olang_loc_6f754b89a33b6044_bbcfb7dbcaa58778 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_467821a0171adcef_9f7d024fdb995773 = external constant [0 x i8]
declare %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartTask(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eP_H79a97b7337c7adf08bdd37311af7e171(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_6be2223409a54017_8087911232ed0aeb = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2emove(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3adkey_2c_20I64_3e_2eG_H537d495038c4cf6799e621bee696b05f(ptr %v0, ptr %a0, %"compiler/eval:dkey" %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewriteElems(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/eval:Ptr" %a2, i32 %a3, { i64, [1 x i64] } %a4)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3adkey_2c_20I64_3e_2eP_H91b95c77ac9fc5702101e9e6061f40cd(ptr %v0, ptr %a0, %"compiler/eval:dkey" %a1, i64 %a2)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2etoTargets(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [4 x i64] } %a3, i32 %a4)
@olang_loc_17d12c125f58d820_35ade4b878109a14 = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropScope(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ae4c96370005e5a0_f3d2360ec3e473b4 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e07540d555d7dc03_f134256d7232b767 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %a0)
declare void @std_2fos_2eExit(i32 %a0)
@olang_loc_c25616630356082_96e485ee4d1c8d36 = external constant [0 x i8]
@olang_loc_463be9bfcfc802eb_383f1498b2d4337 = external constant [0 x i8]
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eHas_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eLaidOut = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNotLaidOut = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eLayingOut = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetLayoutState(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNoLayout = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eterm(ptr %v0, ptr %a0, i64 %a1, { i64, [8 x i64] } %a2, i1 %a3)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eflat(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2estmtAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
@olang_loc_b24244fd0a11c914_466201095dcd7a18 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2ePush_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0, %"compiler/eval:reg" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eLen_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i32 %a4)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i32 %a4, i32 %a5)
@olang_loc_590198b1bba6f342_437268d8e9153c4e = external constant [0 x i8]
@olang_loc_75dcc6d397d821f4_f630b477c159fde0 = external constant [0 x i8]
@olang_loc_ad3bfe70499dbe21_2daaaf2a9e405db5 = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4df6f2ee185eb0d1_4c6469cdbf591dfd = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d4aeb51afef739b6_d573fd1fa5ffe912 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eLen_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eTruncate_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewritesAfter(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereachesWritable(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a7714af53687ff6b_1e8ca3031727412f = external constant [0 x i8]
@olang_loc_48067455946c0246_37fc1727e867ffc2 = external constant [0 x i8]
@olang_loc_ed29d0e1fe37827_73f8bd43b4184743 = external constant [0 x i8]
@olang_loc_af1f9cfaa1609478_d5c4fc0e8d836404 = external constant [0 x i8]
@olang_loc_12565802a2336670_a75db38aedd0e3fc = external constant [0 x i8]
@olang_loc_1069159e4cdf0a01_3c7ea434b50ec3ad = external constant [0 x i8]
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
@olang_loc_26a77dbb944b4c43_3cbd97c51474f5af = external constant [0 x i8]
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Ha5986096190b27059e1b255ecbd90571(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1c104311c72af5f5_c45dcd645c687dc1 = external constant [0 x i8]
@olang_loc_bcf45b1eafea1f9c_8e096368132121a8 = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshapeOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2esettled(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@olang_loc_749f682aa65a479b_d1f85e4e9e0056df = external constant [0 x i8]
@olang_loc_176c1f0c53cca04e_ded73198e701b2e2 = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_bb58ffa16789d1e6_53f99027aa0e2dd2 = external constant [0 x i8]
declare %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f4c8d7149bd44e26_572dd2a903112792 = external constant [0 x i8]
@olang_loc_2654da324b88ad87_946d0eedc2d95193 = external constant [0 x i8]
@olang_loc_2742cef73dca1807_235d65ef4c242d83 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2eIntBytes(i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H075fcab2d197e70ad987ab163aa86164(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %v0, { i64, [2 x i64] } %a0, %"compiler/mir:Range" %a1)
@olang_loc_a1e0d3359bcb436b_ac2861f14772b5df = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_d44b28fe9fc96fb9_71a7ff2b834e49cd = external constant [0 x i8]
@olang_loc_c25b9553ef801192_ed4b8566966f1316 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_48f03219a23009f5_27a95ef9d9612249 = external constant [0 x i8]
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
