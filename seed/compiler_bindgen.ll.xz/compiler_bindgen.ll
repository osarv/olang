; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, i32 }
%"compiler/bindgen:ctp" = type { { i64, ptr }, i64 }
%"compiler/bindgen:gen" = type { { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, i64 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/bindgen:ctype" = type { i32, { i64, ptr }, i64, i1, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/bindgen:cFunc" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/bindgen:record" = type { { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, i1, i64 }
%"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" = type { ptr, i64, ptr }
%"std/json:Object" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
define dso_local i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca %"std/io:Writer"
  %l4 = alloca i32
  %l5 = alloca %"std/io:Writer"
  %l10 = alloca i32
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 2, i64 65536)
  store %"std/io:Writer" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/io:Writer", ptr %l5
  store %"std/io:Writer" %t2, ptr %l3
  %t10 = call i32 @compiler_2fbindgen_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %s0, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %l3)
  store i32 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i32, ptr %l10, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t13 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l3)
  store i32 %t13, ptr %l12
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb4, label %ok.15
ok.15:
  br label %bb3
bb3:
  br label %bb8
bb4:
  %t16 = load i32, ptr %l12, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d0c4be1b37fb70ff_4af1c68652343f9b)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  br label %bb8
bb8:
  %t21 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:ctp", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t8 = add i64 %t4, %a1
  store i64 %t8, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/bindgen:ctp", ptr %t11, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp slt i64 %t10, %t16
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/bindgen:ctp", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l14, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %t28, i64 %t25
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !37
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = extractvalue { i64, ptr } %t30, 0
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t32, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l12, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t38, ptr %l12, !tbaa !27
  br label %bb3
bb3:
  %t40 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l20, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = mul i64 %t42, 1
  %t44 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l21, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l20, !tbaa !24
  %t52 = mul i64 %t51, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %t50, i64 %t52, i1 false)
  %t53 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t53, ptr %l12, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t6 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v1, ptr %a0, i32 6, { i64, ptr } %a1, i64 -1, i1 false, i64 0)
  store i64 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l6 = alloca i1
  %l8 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @compiler_2fbindgen_2eusable(ptr %v1, { i64, ptr } %t1)
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:gen", ptr %t9, i32 0, i32 7
  %t15 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %t11, { i64, ptr } %t7)
  store i1 %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load i1, ptr %l13, !tbaa !21
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp sge i64 %t18, -2147483648
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = icmp sle i64 %t22, 2147483647
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb14
bb14:
  %t27 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/bindgen:gen", ptr %t28, i32 0, i32 6
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = extractvalue { i64, ptr } %t31, 1
  %t36 = extractvalue { i64, ptr } %t31, 0
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t41 = extractvalue { i64, ptr } %t27, 1
  %t42 = extractvalue { i64, ptr } %t27, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t48 = call i64 @__olang_fmt_i64(ptr null, i64 %t33)
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t35, i64 %t36)
  %t51 = getelementptr i8, ptr %t50, i64 %t36
  call void @olang_textcopy(ptr %t51, ptr %t37, i64 %t38)
  %t52 = getelementptr i8, ptr %t51, i64 %t38
  call void @olang_textcopy(ptr %t52, ptr %t41, i64 %t42)
  %t53 = getelementptr i8, ptr %t52, i64 %t42
  call void @olang_textcopy(ptr %t53, ptr %t44, i64 %t45)
  %t54 = getelementptr i8, ptr %t53, i64 %t45
  %t55 = call i64 @__olang_fmt_i64(ptr %t54, i64 %t33)
  %t56 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t50, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t30, { i64, ptr } %t64)
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/bindgen:gen", ptr %t67, i32 0, i32 7
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = extractvalue { i64, ptr } %t70, 0
  %t74 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t72, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = extractvalue { i64, ptr } %t76, 1
  %t80 = mul i64 %t78, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t80)
  call void @llvm.memcpy.p0.p0.i64(ptr %t81, ptr %t79, i64 %t80, i1 false)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t69, { i64, ptr } %t83, i64 0)
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/bindgen:gen", ptr %t86, i32 0, i32 11
  %t89 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t91, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = extractvalue { i64, ptr } %t95, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t88, { i64, ptr } %t102, i64 0)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edeclarator(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"compiler/bindgen:ctype"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca i1
  %l49 = alloca { i64, ptr }
  %l51 = alloca i1
  %l52 = alloca i1
  %l54 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca i1
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l64 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i1
  %l76 = alloca { i64, ptr }
  %l78 = alloca i1
  %l79 = alloca i1
  %l81 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca i1
  %l86 = alloca { i64, ptr }
  %l88 = alloca i1
  %l100 = alloca { i64, ptr }
  %l102 = alloca i1
  %l106 = alloca { i64, ptr }
  %l108 = alloca i1
  %l113 = alloca ptr
  %l116 = alloca ptr
  %l119 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l121 = alloca { i64, ptr }
  %l123 = alloca i1
  %l124 = alloca ptr
  %l127 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l134 = alloca i1
  %l136 = alloca { i64, ptr }
  %l138 = alloca i1
  %l142 = alloca { i64, ptr }
  %l144 = alloca i1
  %l145 = alloca ptr
  %l151 = alloca i64
  %l155 = alloca %"compiler/bindgen:ctype"
  %l158 = alloca i1
  %l160 = alloca i64
  %l162 = alloca i1
  %l164 = alloca { i64, ptr }
  %l166 = alloca i1
  %l171 = alloca { i64, ptr }
  %l173 = alloca i1
  %l174 = alloca ptr
  %l177 = alloca ptr
  %l182 = alloca i64
  %l184 = alloca i64
  %l186 = alloca i64
  %l191 = alloca i64
  %l197 = alloca ptr
  %l198 = alloca i32
  %l200 = alloca { i64, ptr }
  %l201 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i64
  %l209 = alloca %"compiler/bindgen:ctype"
  %l217 = alloca { i64, ptr }
  %l219 = alloca i1
  %l220 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l226 = alloca i1
  %l228 = alloca i64
  %l230 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l232 = alloca i64
  %l233 = alloca i32
  %l234 = alloca i64
  %l235 = alloca i32
  %l236 = alloca ptr
  %l239 = alloca ptr
  %l245 = alloca i64
  %l249 = alloca i64
  %l252 = alloca i64
  %l270 = alloca ptr
  %l271 = alloca i32
  %l272 = alloca i64
  %l273 = alloca ptr
  %l275 = alloca i64
  %l279 = alloca i64
  %l280 = alloca i64
  %l293 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a2, ptr %l5, !tbaa !24
  store i1 %a3, ptr %l6, !tbaa !21
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s1, ptr %t5, i64 0)
  store { i64, ptr } %t7, ptr %l31
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t14, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t16, ptr %l33
  br label %bb3
bb3:
  %t17 = load i1, ptr %l33, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb34
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i1, ptr %l6, !tbaa !21
  %t27 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t20, i32 3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, i64 %t21, i1 %t22, i64 0)
  store i64 %t27, ptr %l39
  br label %bb7
bb7:
  %t28 = load i64, ptr %l39, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l40, !tbaa !29
  %t30 = load ptr, ptr %l40, !tbaa !29
  %t31 = getelementptr %"compiler/bindgen:ctp", ptr %t30, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = add i64 %t32, 1
  %t36 = load ptr, ptr %l40, !tbaa !29
  %t37 = getelementptr %"compiler/bindgen:ctp", ptr %t36, i32 0, i32 1
  store i64 %t34, ptr %t37, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t38, i64 0)
  store { i64, ptr } %t40, ptr %l44
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t47, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t49, ptr %l46
  br label %bb10
bb10:
  %t50 = load i1, ptr %l46, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb15
bb12:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t51, i64 0)
  store { i64, ptr } %t53, ptr %l49
  br label %bb13
bb13:
  %t54 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t60, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t62, ptr %l51
  br label %bb14
bb14:
  %t63 = load i1, ptr %l51, !tbaa !21
  store i1 %t63, ptr %l47, !tbaa !21
  br label %bb15
bb15:
  %t64 = load i1, ptr %l47, !tbaa !21
  br i1 %t64, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb20
bb17:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t65, i64 0)
  store { i64, ptr } %t67, ptr %l54
  br label %bb18
bb18:
  %t68 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t74, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t76, ptr %l56
  br label %bb19
bb19:
  %t77 = load i1, ptr %l56, !tbaa !21
  store i1 %t77, ptr %l52, !tbaa !21
  br label %bb20
bb20:
  %t78 = load i1, ptr %l52, !tbaa !21
  br i1 %t78, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb25
bb22:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t79, i64 0)
  store { i64, ptr } %t81, ptr %l59
  br label %bb23
bb23:
  %t82 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  %t84 = extractvalue { i64, ptr } %t82, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t88, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t90, ptr %l61
  br label %bb24
bb24:
  %t91 = load i1, ptr %l61, !tbaa !21
  store i1 %t91, ptr %l57, !tbaa !21
  br label %bb25
bb25:
  %t92 = load i1, ptr %l57, !tbaa !21
  %t93 = xor i1 %t92, true
  br i1 %t93, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s2, ptr %t95, i64 0)
  store { i64, ptr } %t97, ptr %l64
  br label %bb29
bb29:
  %t98 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t104, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t106, ptr %l66
  br label %bb30
bb30:
  %t107 = load i1, ptr %l66, !tbaa !21
  store i1 %t107, ptr %l6, !tbaa !21
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l67, !tbaa !29
  %t109 = load ptr, ptr %l67, !tbaa !29
  %t110 = getelementptr %"compiler/bindgen:ctp", ptr %t109, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  %t113 = add i64 %t111, 1
  %t115 = load ptr, ptr %l67, !tbaa !29
  %t116 = getelementptr %"compiler/bindgen:ctp", ptr %t115, i32 0, i32 1
  store i64 %t113, ptr %t116, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  br label %bb8
bb32:
  call void @__olang_scope_close(ptr %s1)
  br label %bb33
bb33:
  br label %bb1
bb34:
  store i64 -1, ptr %l7, !tbaa !24
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t117, i64 0)
  store { i64, ptr } %t119, ptr %l71
  br label %bb35
bb35:
  %t120 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t126, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t128, ptr %l73
  br label %bb36
bb36:
  %t129 = load i1, ptr %l73, !tbaa !21
  br i1 %t129, label %bb37, label %bb38
bb37:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t130, i64 1)
  store { i64, ptr } %t132, ptr %l76
  br label %bb39
bb38:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb51
bb39:
  %t133 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t139, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t141, ptr %l78
  br label %bb40
bb40:
  %t142 = load i1, ptr %l78, !tbaa !21
  br i1 %t142, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb45
bb42:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t143, i64 1)
  store { i64, ptr } %t145, ptr %l81
  br label %bb43
bb43:
  %t146 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t152, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t154, ptr %l83
  br label %bb44
bb44:
  %t155 = load i1, ptr %l83, !tbaa !21
  store i1 %t155, ptr %l79, !tbaa !21
  br label %bb45
bb45:
  %t156 = load i1, ptr %l79, !tbaa !21
  br i1 %t156, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb50
bb47:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t157, i64 1)
  store { i64, ptr } %t159, ptr %l86
  br label %bb48
bb48:
  %t160 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t168 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t166, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t168, ptr %l88
  br label %bb49
bb49:
  %t169 = load i1, ptr %l88, !tbaa !21
  store i1 %t169, ptr %l84, !tbaa !21
  br label %bb50
bb50:
  %t170 = load i1, ptr %l84, !tbaa !21
  store i1 %t170, ptr %l74, !tbaa !21
  br label %bb51
bb51:
  %t171 = load i1, ptr %l74, !tbaa !21
  br i1 %t171, label %bb52, label %bb53
bb52:
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr %"compiler/bindgen:ctp", ptr %t172, i32 0, i32 1
  %t175 = load i64, ptr %t174, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb54
bb53:
  br label %bb73
bb54:
  store %olang.scope zeroinitializer, ptr %s4
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr %"compiler/bindgen:ctp", ptr %t179, i32 0, i32 1
  %t182 = load i64, ptr %t181, !tbaa !24
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/bindgen:ctp", ptr %t183, i32 0, i32 0
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t191 = icmp slt i64 %t182, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s4)
  br label %bb72
bb56:
  br label %bb57
bb57:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s4, ptr %t195, i64 0)
  store { i64, ptr } %t197, ptr %l100
  br label %bb58
bb58:
  %t198 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t200 = extractvalue { i64, ptr } %t198, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  %t206 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t204, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t206, ptr %l102
  br label %bb59
bb59:
  %t207 = load i1, ptr %l102, !tbaa !21
  br i1 %t207, label %bb60, label %bb61
bb60:
  %t208 = load i64, ptr %l8, !tbaa !24
  %t210 = add i64 %t208, 1
  store i64 %t210, ptr %l8, !tbaa !24
  br label %bb62
bb61:
  br label %bb62
bb62:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s4, ptr %t212, i64 0)
  store { i64, ptr } %t214, ptr %l106
  br label %bb63
bb63:
  %t215 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t223 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t221, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t223, ptr %l108
  br label %bb64
bb64:
  %t224 = load i1, ptr %l108, !tbaa !21
  br i1 %t224, label %bb65, label %bb66
bb65:
  %t225 = load i64, ptr %l8, !tbaa !24
  %t227 = sub i64 %t225, 1
  store i64 %t227, ptr %l8, !tbaa !24
  %t229 = load i64, ptr %l8, !tbaa !24
  %t231 = icmp eq i64 %t229, 0
  br i1 %t231, label %bb67, label %bb68
bb66:
  br label %bb70
bb67:
  call void @__olang_scope_close(ptr %s4)
  br label %bb72
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t233 = load ptr, ptr %l1, !tbaa !29
  store ptr %t233, ptr %l113, !tbaa !29
  %t234 = load ptr, ptr %l113, !tbaa !29
  %t235 = getelementptr %"compiler/bindgen:ctp", ptr %t234, i32 0, i32 1
  %t236 = load i64, ptr %t235, !tbaa !24
  %t238 = add i64 %t236, 1
  %t240 = load ptr, ptr %l113, !tbaa !29
  %t241 = getelementptr %"compiler/bindgen:ctp", ptr %t240, i32 0, i32 1
  store i64 %t238, ptr %t241, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb71
bb71:
  br label %bb54
bb72:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l116, !tbaa !29
  %t243 = load ptr, ptr %l116, !tbaa !29
  %t244 = getelementptr %"compiler/bindgen:ctp", ptr %t243, i32 0, i32 1
  %t245 = load i64, ptr %t244, !tbaa !24
  %t247 = add i64 %t245, 1
  %t249 = load ptr, ptr %l116, !tbaa !29
  %t250 = getelementptr %"compiler/bindgen:ctp", ptr %t249, i32 0, i32 1
  store i64 %t247, ptr %t250, !tbaa !24
  br label %bb73
bb73:
  %t251 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t251, ptr %l119
  br label %bb74
bb74:
  %t252 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l119
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t252, ptr %l9
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s8
  %t253 = load ptr, ptr %l1, !tbaa !29
  %t255 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s8, ptr %t253, i64 0)
  store { i64, ptr } %t255, ptr %l121
  br label %bb76
bb76:
  %t256 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 0
  %t258 = extractvalue { i64, ptr } %t256, 1
  %t259 = mul i64 %t257, 1
  %t260 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t259)
  call void @llvm.memcpy.p0.p0.i64(ptr %t260, ptr %t258, i64 %t259, i1 false)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  %t264 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s8, { i64, ptr } %t262, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t264, ptr %l123
  br label %bb77
bb77:
  %t265 = load i1, ptr %l123, !tbaa !21
  br i1 %t265, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s9
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l124, !tbaa !29
  %t267 = load ptr, ptr %l124, !tbaa !29
  %t268 = getelementptr %"compiler/bindgen:ctp", ptr %t267, i32 0, i32 1
  %t269 = load i64, ptr %t268, !tbaa !24
  %t271 = add i64 %t269, 1
  %t273 = load ptr, ptr %l124, !tbaa !29
  %t274 = getelementptr %"compiler/bindgen:ctp", ptr %t273, i32 0, i32 1
  store i64 %t271, ptr %t274, !tbaa !24
  %t275 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s9, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t275, ptr %l127
  br label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s18
  %t276 = load ptr, ptr %l1, !tbaa !29
  %t278 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s18, ptr %t276, i64 0)
  store { i64, ptr } %t278, ptr %l217
  br label %bb134
bb80:
  %t279 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l127
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t279, ptr %l10
  store i1 false, ptr %l11, !tbaa !21
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s10
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t282 = getelementptr %"compiler/bindgen:ctp", ptr %t280, i32 0, i32 1
  %t283 = load i64, ptr %t282, !tbaa !24
  %t284 = load ptr, ptr %l1, !tbaa !29
  %t286 = getelementptr %"compiler/bindgen:ctp", ptr %t284, i32 0, i32 0
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t292 = icmp slt i64 %t283, %t289
  br i1 %t292, label %bb82, label %bb83
bb82:
  %t294 = load ptr, ptr %l1, !tbaa !29
  %t296 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s10, ptr %t294, i64 0)
  store { i64, ptr } %t296, ptr %l136
  br label %bb84
bb83:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb86
bb84:
  %t297 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 0
  %t299 = extractvalue { i64, ptr } %t297, 1
  %t300 = mul i64 %t298, 1
  %t301 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t300)
  call void @llvm.memcpy.p0.p0.i64(ptr %t301, ptr %t299, i64 %t300, i1 false)
  %t302 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t301, 1
  %t305 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t303, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t305, ptr %l138
  br label %bb85
bb85:
  %t306 = load i1, ptr %l138, !tbaa !21
  %t307 = xor i1 %t306, true
  store i1 %t307, ptr %l134, !tbaa !21
  br label %bb86
bb86:
  %t309 = load i1, ptr %l134, !tbaa !21
  %t310 = xor i1 %t309, true
  br i1 %t310, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s10)
  br label %bb116
bb88:
  br label %bb89
bb89:
  %t312 = load ptr, ptr %l1, !tbaa !29
  %t314 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s10, ptr %t312, i64 0)
  store { i64, ptr } %t314, ptr %l142
  br label %bb90
bb90:
  %t315 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 0
  %t317 = extractvalue { i64, ptr } %t315, 1
  %t318 = mul i64 %t316, 1
  %t319 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t318)
  call void @llvm.memcpy.p0.p0.i64(ptr %t319, ptr %t317, i64 %t318, i1 false)
  %t320 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  %t323 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t321, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t323, ptr %l144
  br label %bb91
bb91:
  %t324 = load i1, ptr %l144, !tbaa !21
  br i1 %t324, label %bb92, label %bb93
bb92:
  store i1 true, ptr %l11, !tbaa !21
  %t325 = load ptr, ptr %l1, !tbaa !29
  store ptr %t325, ptr %l145, !tbaa !29
  %t326 = load ptr, ptr %l145, !tbaa !29
  %t327 = getelementptr %"compiler/bindgen:ctp", ptr %t326, i32 0, i32 1
  %t328 = load i64, ptr %t327, !tbaa !24
  %t330 = add i64 %t328, 1
  %t332 = load ptr, ptr %l145, !tbaa !29
  %t333 = getelementptr %"compiler/bindgen:ctp", ptr %t332, i32 0, i32 1
  store i64 %t330, ptr %t333, !tbaa !24
  br label %bb109
bb93:
  store %olang.scope zeroinitializer, ptr %s12
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t336 = load i64, ptr %l4, !tbaa !24
  %t340 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etypeName(ptr %v0, ptr %v1, ptr %t334, ptr %t335, i64 %t336)
  store i64 %t340, ptr %l151
  br label %bb94
bb94:
  %t341 = load i64, ptr %l151, !tbaa !24
  store i64 %t341, ptr %l12, !tbaa !24
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/bindgen:gen", ptr %t342, i32 0, i32 8
  %t345 = load i64, ptr %l12, !tbaa !24
  %t348 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s12, ptr %t344, i64 %t345)
  store %"compiler/bindgen:ctype" %t348, ptr %l155
  br label %bb95
bb95:
  %t349 = getelementptr %"compiler/bindgen:ctype", ptr %l155, i32 0, i32 0
  %t350 = load i32, ptr %t349
  %t352 = trunc i64 0 to i32
  %t353 = icmp eq i32 %t350, %t352
  br i1 %t353, label %bb96, label %bb97
bb96:
  %t356 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %l10)
  store i64 %t356, ptr %l160
  br label %bb98
bb97:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb99
bb98:
  %t357 = load i64, ptr %l160, !tbaa !24
  %t358 = icmp eq i64 %t357, 0
  store i1 %t358, ptr %l158, !tbaa !21
  br label %bb99
bb99:
  %t360 = load i1, ptr %l158, !tbaa !21
  br i1 %t360, label %bb100, label %bb101
bb100:
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t363 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s12, ptr %t361, i64 0)
  store { i64, ptr } %t363, ptr %l164
  br label %bb102
bb101:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb104
bb102:
  %t364 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = extractvalue { i64, ptr } %t364, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  %t372 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s12, ptr %s12, { i64, ptr } %t370, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t372, ptr %l166
  br label %bb103
bb103:
  %t373 = load i1, ptr %l166, !tbaa !21
  store i1 %t373, ptr %l162, !tbaa !21
  br label %bb104
bb104:
  %t374 = load i1, ptr %l162, !tbaa !21
  %t375 = xor i1 %t374, true
  br i1 %t375, label %bb105, label %bb106
bb105:
  %t377 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s9, ptr %l10, i64 %t377)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s12)
  br label %bb109
bb109:
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s10, ptr %t380, i64 0)
  store { i64, ptr } %t382, ptr %l171
  br label %bb110
bb110:
  %t383 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 0
  %t385 = extractvalue { i64, ptr } %t383, 1
  %t386 = mul i64 %t384, 1
  %t387 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t386)
  call void @llvm.memcpy.p0.p0.i64(ptr %t387, ptr %t385, i64 %t386, i1 false)
  %t388 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t387, 1
  %t391 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t389, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t391, ptr %l173
  br label %bb111
bb111:
  %t392 = load i1, ptr %l173, !tbaa !21
  br i1 %t392, label %bb112, label %bb113
bb112:
  %t393 = load ptr, ptr %l1, !tbaa !29
  store ptr %t393, ptr %l174, !tbaa !29
  %t394 = load ptr, ptr %l174, !tbaa !29
  %t395 = getelementptr %"compiler/bindgen:ctp", ptr %t394, i32 0, i32 1
  %t396 = load i64, ptr %t395, !tbaa !24
  %t398 = add i64 %t396, 1
  %t400 = load ptr, ptr %l174, !tbaa !29
  %t401 = getelementptr %"compiler/bindgen:ctp", ptr %t400, i32 0, i32 1
  store i64 %t398, ptr %t401, !tbaa !24
  br label %bb114
bb113:
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb115:
  br label %bb81
bb116:
  %t402 = load ptr, ptr %l1, !tbaa !29
  store ptr %t402, ptr %l177, !tbaa !29
  %t403 = load ptr, ptr %l177, !tbaa !29
  %t404 = getelementptr %"compiler/bindgen:ctp", ptr %t403, i32 0, i32 1
  %t405 = load i64, ptr %t404, !tbaa !24
  %t407 = add i64 %t405, 1
  %t409 = load ptr, ptr %l177, !tbaa !29
  %t410 = getelementptr %"compiler/bindgen:ctp", ptr %t409, i32 0, i32 1
  store i64 %t407, ptr %t410, !tbaa !24
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/bindgen:gen", ptr %t411, i32 0, i32 9
  %t415 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t413)
  store i64 %t415, ptr %l182
  br label %bb117
bb117:
  %t416 = load i64, ptr %l182, !tbaa !24
  store i64 %t416, ptr %l13, !tbaa !24
  store ptr %l10, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb118
bb118:
  %t418 = load i64, ptr %l15, !tbaa !24
  store i64 %t418, ptr %l184, !tbaa !24
  %t419 = load ptr, ptr %l14, !tbaa !29
  %t421 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %t419)
  store i64 %t421, ptr %l186
  br label %bb119
bb119:
  %t422 = load i64, ptr %l184, !tbaa !24
  %t423 = load i64, ptr %l186, !tbaa !24
  %t424 = icmp slt i64 %t422, %t423
  %t426 = xor i1 %t424, true
  br i1 %t426, label %bb120, label %bb121
bb120:
  br label %bb126
bb121:
  br label %bb122
bb122:
  %t428 = load ptr, ptr %l14, !tbaa !29
  %t429 = load i64, ptr %l15, !tbaa !24
  %t432 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s9, ptr %t428, i64 %t429)
  store i64 %t432, ptr %l191
  br label %bb123
bb123:
  %t433 = load i64, ptr %l191, !tbaa !24
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/bindgen:gen", ptr %t434, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t436, i64 %t433)
  br label %bb124
bb124:
  br label %bb125
bb125:
  %t440 = load i64, ptr %l15, !tbaa !24
  %t442 = add i64 %t440, 1
  store i64 %t442, ptr %l15, !tbaa !24
  br label %bb118
bb126:
  %t444 = load ptr, ptr %l0, !tbaa !29
  store ptr %t444, ptr %l197, !tbaa !29
  store i32 5, ptr %l198
  %t445 = load i1, ptr %l11, !tbaa !21
  br i1 %t445, label %bb127, label %bb128
bb127:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l200, !tbaa !27
  br label %bb129
bb128:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l200, !tbaa !27
  br label %bb129
bb129:
  %t447 = load i64, ptr %l5, !tbaa !24
  store i64 %t447, ptr %l201, !tbaa !24
  %t449 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %l10)
  store i64 %t449, ptr %l203
  br label %bb130
bb130:
  %t450 = load ptr, ptr %l197, !tbaa !29
  %t451 = load i32, ptr %l198
  %t452 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t453 = load i64, ptr %l201, !tbaa !24
  %t454 = load i64, ptr %l203, !tbaa !24
  %t455 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t450, i32 %t451, { i64, ptr } %t452, i64 %t453, i1 false, i64 %t454)
  store i64 %t455, ptr %l204
  br label %bb131
bb131:
  %t456 = load i64, ptr %l204, !tbaa !24
  store i64 %t456, ptr %l17, !tbaa !24
  %t457 = load i64, ptr %l17, !tbaa !24
  store i64 %t457, ptr %l18, !tbaa !24
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/bindgen:gen", ptr %t459, i32 0, i32 8
  %t462 = load i64, ptr %l18, !tbaa !24
  %t465 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t461, i64 %t462)
  store %"compiler/bindgen:ctype" %t465, ptr %l209
  br label %bb132
bb132:
  %t466 = load %"compiler/bindgen:ctype", ptr %l209
  store %"compiler/bindgen:ctype" %t466, ptr %l19
  %t467 = load i64, ptr %l13, !tbaa !24
  %t469 = getelementptr %"compiler/bindgen:ctype", ptr %l19, i32 0, i32 5
  store i64 %t467, ptr %t469, !tbaa !24
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/bindgen:gen", ptr %t470, i32 0, i32 8
  %t473 = load i64, ptr %l18, !tbaa !24
  %t474 = load %"compiler/bindgen:ctype", ptr %l19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eSetAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t472, i64 %t473, %"compiler/bindgen:ctype" %t474)
  br label %bb133
bb133:
  %t478 = load i64, ptr %l17, !tbaa !24
  store i64 %t478, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb152
bb134:
  %t480 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t480, 0
  %t482 = extractvalue { i64, ptr } %t480, 1
  %t483 = mul i64 %t481, 1
  %t484 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t483)
  call void @llvm.memcpy.p0.p0.i64(ptr %t484, ptr %t482, i64 %t483, i1 false)
  %t485 = insertvalue { i64, ptr } undef, i64 %t481, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t484, 1
  %t488 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s18, ptr %s18, { i64, ptr } %t486, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t488, ptr %l219
  br label %bb135
bb135:
  %t489 = load i1, ptr %l219, !tbaa !21
  br i1 %t489, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s19
  %t490 = load ptr, ptr %l1, !tbaa !29
  store ptr %t490, ptr %l220, !tbaa !29
  %t491 = load ptr, ptr %l220, !tbaa !29
  %t492 = getelementptr %"compiler/bindgen:ctp", ptr %t491, i32 0, i32 1
  %t493 = load i64, ptr %t492, !tbaa !24
  %t495 = add i64 %t493, 1
  %t497 = load ptr, ptr %l220, !tbaa !29
  %t498 = getelementptr %"compiler/bindgen:ctp", ptr %t497, i32 0, i32 1
  store i64 %t495, ptr %t498, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s19, ptr %t499, i64 0)
  store { i64, ptr } %t501, ptr %l224
  br label %bb138
bb137:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s8)
  br label %bb154
bb138:
  %t502 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 0
  %t504 = extractvalue { i64, ptr } %t502, 1
  %t505 = mul i64 %t503, 1
  %t506 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t505)
  call void @llvm.memcpy.p0.p0.i64(ptr %t506, ptr %t504, i64 %t505, i1 false)
  %t507 = insertvalue { i64, ptr } undef, i64 %t503, 0
  %t508 = insertvalue { i64, ptr } %t507, ptr %t506, 1
  %t510 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s19, ptr %s19, { i64, ptr } %t508, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t510, ptr %l226
  br label %bb139
bb139:
  %t511 = load i1, ptr %l226, !tbaa !21
  %t512 = xor i1 %t511, true
  br i1 %t512, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s20
  %t514 = load ptr, ptr %l1, !tbaa !29
  %t516 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s20, ptr %t514, i64 0)
  store { i64, ptr } %t516, ptr %l230
  br label %bb142
bb141:
  br label %bb149
bb142:
  %t517 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t518 = extractvalue { i64, ptr } %t517, 0
  %t519 = extractvalue { i64, ptr } %t517, 1
  %t520 = mul i64 %t518, 1
  %t521 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t520)
  call void @llvm.memcpy.p0.p0.i64(ptr %t521, ptr %t519, i64 %t520, i1 false)
  %t522 = insertvalue { i64, ptr } undef, i64 %t518, 0
  %t523 = insertvalue { i64, ptr } %t522, ptr %t521, 1
  store { i64, ptr } %t523, ptr %l231, !tbaa !27
  %t524 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s20, i64 10)
  %t525 = extractvalue { i32, i64 } %t524, 1
  %t526 = extractvalue { i32, i64 } %t524, 0
  store i32 %t526, ptr %l233
  %t527 = icmp ne i32 %t526, 0
  br i1 %t527, label %bb144, label %ok.528
ok.528:
  store i64 %t525, ptr %l232
  br label %bb143
bb143:
  %t529 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t530 = load i64, ptr %l232, !tbaa !24
  %t531 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s20, { i64, ptr } %t529, i64 %t530)
  %t532 = extractvalue { i32, i64 } %t531, 1
  %t533 = extractvalue { i32, i64 } %t531, 0
  store i32 %t533, ptr %l235
  %t534 = icmp ne i32 %t533, 0
  br i1 %t534, label %bb147, label %ok.535
ok.535:
  store i64 %t532, ptr %l234
  br label %bb146
bb144:
  br label %bb145
bb145:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l228, !tbaa !24
  br label %bb148
bb146:
  %t536 = load i64, ptr %l234, !tbaa !24
  store i64 %t536, ptr %l228, !tbaa !24
  br label %bb148
bb147:
  br label %bb145
bb148:
  %t537 = load i64, ptr %l228, !tbaa !24
  store i64 %t537, ptr %l20, !tbaa !24
  %t538 = load ptr, ptr %l1, !tbaa !29
  store ptr %t538, ptr %l236, !tbaa !29
  %t539 = load ptr, ptr %l236, !tbaa !29
  %t540 = getelementptr %"compiler/bindgen:ctp", ptr %t539, i32 0, i32 1
  %t541 = load i64, ptr %t540, !tbaa !24
  %t543 = add i64 %t541, 1
  %t545 = load ptr, ptr %l236, !tbaa !29
  %t546 = getelementptr %"compiler/bindgen:ctp", ptr %t545, i32 0, i32 1
  store i64 %t543, ptr %t546, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb149
bb149:
  %t547 = load ptr, ptr %l1, !tbaa !29
  store ptr %t547, ptr %l239, !tbaa !29
  %t548 = load ptr, ptr %l239, !tbaa !29
  %t549 = getelementptr %"compiler/bindgen:ctp", ptr %t548, i32 0, i32 1
  %t550 = load i64, ptr %t549, !tbaa !24
  %t552 = add i64 %t550, 1
  %t554 = load ptr, ptr %l239, !tbaa !29
  %t555 = getelementptr %"compiler/bindgen:ctp", ptr %t554, i32 0, i32 1
  store i64 %t552, ptr %t555, !tbaa !24
  %t556 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t556)
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s19)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s18)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s8)
  br label %bb153
bb153:
  br label %bb75
bb154:
  store i64 0, ptr %l21, !tbaa !24
  %t560 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l9)
  store i64 %t560, ptr %l245
  br label %bb155
bb155:
  %t561 = load i64, ptr %l245, !tbaa !24
  store i64 %t561, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t562 = load i64, ptr %l22, !tbaa !24
  %t563 = load i64, ptr %l21, !tbaa !24
  %t566 = icmp sgt i64 %t562, %t563
  br i1 %t566, label %bb156, label %bb157
bb156:
  %t568 = load i64, ptr %l23, !tbaa !24
  %t570 = icmp sgt i64 %t568, 0
  br i1 %t570, label %bb158, label %bb159
bb157:
  store i64 0, ptr %l249, !tbaa !24
  br label %bb161
bb158:
  %t572 = load i64, ptr %l22, !tbaa !24
  %t573 = load i64, ptr %l21, !tbaa !24
  %t576 = sub i64 %t572, %t573
  %t577 = load i64, ptr %l23, !tbaa !24
  %t580 = add i64 %t576, %t577
  %t582 = sub i64 %t580, 1
  %t583 = load i64, ptr %l23, !tbaa !24
  %t586 = sdiv i64 %t582, %t583
  store i64 %t586, ptr %l252, !tbaa !24
  br label %bb160
bb159:
  store i64 0, ptr %l252, !tbaa !24
  br label %bb160
bb160:
  %t588 = load i64, ptr %l252, !tbaa !24
  store i64 %t588, ptr %l249, !tbaa !24
  br label %bb161
bb161:
  %t589 = load i64, ptr %l249, !tbaa !24
  store i64 %t589, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb162
bb162:
  %t590 = load i64, ptr %l25, !tbaa !24
  %t591 = load i64, ptr %l24, !tbaa !24
  %t594 = icmp slt i64 %t590, %t591
  %t596 = xor i1 %t594, true
  br i1 %t596, label %bb163, label %bb164
bb163:
  br label %bb170
bb164:
  br label %bb165
bb165:
  %t598 = load i64, ptr %l21, !tbaa !24
  %t599 = load i64, ptr %l25, !tbaa !24
  %t600 = load i64, ptr %l23, !tbaa !24
  %t603 = mul i64 %t599, %t600
  %t606 = add i64 %t598, %t603
  store i64 %t606, ptr %l26, !tbaa !24
  %t608 = load ptr, ptr %l0, !tbaa !29
  store ptr %t608, ptr %l270, !tbaa !29
  store i32 4, ptr %l271
  %t609 = load i64, ptr %l5, !tbaa !24
  store i64 %t609, ptr %l272, !tbaa !24
  store ptr %l9, ptr %l273, !tbaa !29
  %t611 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l9)
  store i64 %t611, ptr %l275
  br label %bb166
bb166:
  %t612 = load i64, ptr %l275, !tbaa !24
  %t613 = sub i64 %t612, 1
  %t614 = load i64, ptr %l26, !tbaa !24
  %t617 = sub i64 %t613, %t614
  %t618 = load ptr, ptr %l273, !tbaa !29
  %t620 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t618, i64 %t617)
  store i64 %t620, ptr %l279
  br label %bb167
bb167:
  %t621 = load ptr, ptr %l270, !tbaa !29
  %t622 = load i32, ptr %l271
  %t623 = load i64, ptr %l272, !tbaa !24
  %t624 = load i64, ptr %l279, !tbaa !24
  %t625 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t621, i32 %t622, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, i64 %t623, i1 false, i64 %t624)
  store i64 %t625, ptr %l280
  br label %bb168
bb168:
  %t626 = load i64, ptr %l280, !tbaa !24
  store i64 %t626, ptr %l5, !tbaa !24
  br label %bb169
bb169:
  %t627 = load i64, ptr %l25, !tbaa !24
  %t629 = add i64 %t627, 1
  store i64 %t629, ptr %l25, !tbaa !24
  br label %bb162
bb170:
  %t631 = load i64, ptr %l7, !tbaa !24
  %t633 = icmp sge i64 %t631, 0
  br i1 %t633, label %bb171, label %bb172
bb171:
  %t635 = load ptr, ptr %l1, !tbaa !29
  %t637 = getelementptr %"compiler/bindgen:ctp", ptr %t635, i32 0, i32 1
  %t638 = load i64, ptr %t637, !tbaa !24
  store i64 %t638, ptr %l27, !tbaa !24
  %t640 = load ptr, ptr %l1, !tbaa !29
  %t641 = load i64, ptr %l7, !tbaa !24
  %t644 = getelementptr %"compiler/bindgen:ctp", ptr %t640, i32 0, i32 1
  store i64 %t641, ptr %t644, !tbaa !24
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t646 = load ptr, ptr %l1, !tbaa !29
  %t647 = load i64, ptr %l5, !tbaa !24
  %t648 = load i64, ptr %l4, !tbaa !24
  %t653 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edeclarator(ptr %v0, ptr %v1, ptr %t645, ptr %t646, i64 %t647, i1 false, i64 %t648)
  store i64 %t653, ptr %l293
  br label %bb173
bb172:
  br label %bb174
bb173:
  %t654 = load i64, ptr %l293, !tbaa !24
  store i64 %t654, ptr %l5, !tbaa !24
  %t655 = load ptr, ptr %l1, !tbaa !29
  %t656 = load i64, ptr %l27, !tbaa !24
  %t659 = getelementptr %"compiler/bindgen:ctp", ptr %t655, i32 0, i32 1
  store i64 %t656, ptr %t659, !tbaa !24
  br label %bb174
bb174:
  %t660 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t660, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/bindgen:ctype"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/bindgen:ctype"
  %l6 = alloca i64
  %l10 = alloca %"compiler/bindgen:ctype"
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i32
  %l37 = alloca { i64, ptr }
  %l43 = alloca %"compiler/bindgen:ctype"
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l55 = alloca i64
  %l58 = alloca i1
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca i32
  %l73 = alloca i32
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 8
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/bindgen:ctype" %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l10
  store %"compiler/bindgen:ctype" %t8, ptr %l2
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 0
  %t10 = load i32, ptr %t9
  store i32 %t10, ptr %l3
  %t12 = load i32, ptr %l3
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb9
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l16, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l21, !tbaa !24
  %t35 = load i64, ptr %l21, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l22, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l21, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t46, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t47 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t48 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t47, 1
  store { i32, { i64, ptr } } %t48, ptr %rv
  br label %ret
bb9:
  %t49 = load i32, ptr %l3
  %t51 = trunc i64 2 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t59 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t54, { i64, ptr } %t56)
  store i64 %t59, ptr %l27
  br label %bb13
bb13:
  %t60 = load i64, ptr %l27, !tbaa !24
  store i64 %t60, ptr %l4, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t61, i64 %t62)
  store i1 %t65, ptr %l30
  br label %bb14
bb14:
  %t66 = load i1, ptr %l30, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s4, ptr %t69, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i32 %t71, ptr %l33
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb18, label %ok.73
ok.73:
  br label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb19
bb18:
  %t74 = load i32, ptr %l33, !tbaa !23
  %t75 = lshr i32 %t74, 16
  %t76 = and i32 %t74, 65535
  %t77 = icmp eq i32 %t75, 1
  %t78 = select i1 %t77, i32 1, i32 0
  %t79 = icmp eq i32 %t74, 0
  %t80 = shl i32 %t78, 16
  %t81 = or i32 %t80, %t76
  %t82 = select i1 %t79, i32 0, i32 %t81
  call void @__olang_scope_close(ptr %s4)
  %t84 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t82, 0
  store { i32, { i64, ptr } } %t84, ptr %rv
  br label %ret
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l4, !tbaa !24
  %t89 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %v1, ptr %t85, i64 %t86)
  store { i64, ptr } %t89, ptr %l37
  br label %bb21
bb21:
  %t90 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
bb22:
  %t92 = load i32, ptr %l3
  %t94 = trunc i64 3 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb41
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/bindgen:gen", ptr %t97, i32 0, i32 8
  %t100 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  %t104 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t99, i64 %t101)
  store %"compiler/bindgen:ctype" %t104, ptr %l43
  br label %bb26
bb26:
  %t105 = load %"compiler/bindgen:ctype", ptr %l43
  store %"compiler/bindgen:ctype" %t105, ptr %l5
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t108 = load i64, ptr %t107, !tbaa !24
  %t111 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisByte(ptr %v0, ptr %t106, i64 %t108)
  store i1 %t111, ptr %l46
  br label %bb27
bb27:
  %t112 = load i1, ptr %l46, !tbaa !21
  br i1 %t112, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t113, ptr %l48, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l49, !tbaa !24
  %t116 = load i64, ptr %l49, !tbaa !24
  %t117 = mul i64 %t116, 1
  %t118 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t117)
  %t119 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  store { i64, ptr } %t120, ptr %l50, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l49, !tbaa !24
  %t126 = mul i64 %t125, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t122, ptr %t124, i64 %t126, i1 false)
  %t127 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t127, ptr %l48, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t129 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t128, 1
  store { i32, { i64, ptr } } %t129, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t130 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t131 = load i32, ptr %t130
  %t133 = trunc i64 2 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb31, label %bb32
bb31:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t141 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t136, { i64, ptr } %t138)
  store i64 %t141, ptr %l55
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t142 = load i64, ptr %l55, !tbaa !24
  store i64 %t142, ptr %l6, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i64, ptr %l6, !tbaa !24
  %t147 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t143, i64 %t144)
  store i1 %t147, ptr %l58
  br label %bb34
bb34:
  %t148 = load i1, ptr %l58, !tbaa !21
  %t149 = xor i1 %t148, true
  br i1 %t149, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l6, !tbaa !24
  %t155 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s8, ptr %t151, i64 %t152)
  store { i64, ptr } %t155, ptr %l62
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t156 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t157, i64 %t158)
  %t163 = getelementptr i8, ptr %t162, i64 %t158
  call void @olang_textcopy(ptr %t163, ptr %t159, i64 %t160)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t162, 1
  call void @__olang_scope_close(ptr %s8)
  %t167 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t165, 1
  store { i32, { i64, ptr } } %t167, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evoidRef(ptr %v0, ptr %v1, ptr %t168)
  store { i64, ptr } %t170, ptr %l65
  br label %bb40
bb40:
  %t171 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t172 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t171, 1
  store { i32, { i64, ptr } } %t172, ptr %rv
  br label %ret
bb41:
  %t173 = load i32, ptr %l3
  %t175 = trunc i64 6 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb48
bb44:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  %t183 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t178, { i64, ptr } %t180)
  store i32 %t183, ptr %l70
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb46, label %ok.185
ok.185:
  br label %bb45
bb45:
  br label %bb47
bb46:
  %t186 = load i32, ptr %l70, !tbaa !23
  %t187 = lshr i32 %t186, 16
  %t188 = and i32 %t186, 65535
  %t189 = icmp eq i32 %t187, 1
  %t190 = select i1 %t189, i32 1, i32 0
  %t191 = icmp eq i32 %t186, 0
  %t192 = shl i32 %t190, 16
  %t193 = or i32 %t192, %t188
  %t194 = select i1 %t191, i32 0, i32 %t193
  %t196 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t194, 0
  store { i32, { i64, ptr } } %t196, ptr %rv
  br label %ret
bb47:
  br label %bb56
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb55
bb51:
  store %olang.scope zeroinitializer, ptr %s11
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s11, ptr %t197, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i32 %t199, ptr %l73
  %t200 = icmp ne i32 %t199, 0
  br i1 %t200, label %bb53, label %ok.201
ok.201:
  br label %bb52
bb52:
  br label %bb54
bb53:
  %t202 = load i32, ptr %l73, !tbaa !23
  %t203 = lshr i32 %t202, 16
  %t204 = and i32 %t202, 65535
  %t205 = icmp eq i32 %t203, 1
  %t206 = select i1 %t205, i32 1, i32 0
  %t207 = icmp eq i32 %t202, 0
  %t208 = shl i32 %t206, 16
  %t209 = or i32 %t208, %t204
  %t210 = select i1 %t207, i32 0, i32 %t209
  call void @__olang_scope_close(ptr %s11)
  %t212 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t210, 0
  store { i32, { i64, ptr } } %t212, ptr %rv
  br label %ret
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_582986fcdf40d11c_2a39a940a03de888)
  unreachable
bb56:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l75, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t213, ptr %l76, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 0
  store i64 %t215, ptr %l77, !tbaa !24
  %t216 = load i64, ptr %l77, !tbaa !24
  %t217 = mul i64 %t216, 1
  %t218 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t217)
  %t219 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  store { i64, ptr } %t220, ptr %l78, !tbaa !27
  %t221 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = load i64, ptr %l77, !tbaa !24
  %t226 = mul i64 %t225, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t222, ptr %t224, i64 %t226, i1 false)
  %t227 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t227, ptr %l76, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t229 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t228, 1
  store { i32, { i64, ptr } } %t229, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efunction(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/bindgen:ctype"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca %"compiler/bindgen:ctype"
  %l25 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i1
  %l36 = alloca i32
  %l38 = alloca %"std/prelude/text:StringBuilder"
  %l44 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca i64
  %l52 = alloca i64
  %l73 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l98 = alloca i32
  %l108 = alloca %"compiler/bindgen:ctype"
  %l112 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l122 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/bindgen:cFunc", ptr %t2, i32 0, i32 1
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t8 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t5, i64 0)
  store i64 %t8, ptr %l16
  br label %bb1
bb1:
  %t9 = load i64, ptr %l16, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/bindgen:gen", ptr %t10, i32 0, i32 8
  %t16 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t12, i64 %t9)
  store %"compiler/bindgen:ctype" %t16, ptr %l20
  br label %bb2
bb2:
  %t17 = load %"compiler/bindgen:ctype", ptr %l20
  store %"compiler/bindgen:ctype" %t17, ptr %l3
  %t18 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 0
  %t19 = load i32, ptr %t18
  %t21 = trunc i64 6 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t29 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t24, { i64, ptr } %t26)
  store i32 %t29, ptr %l25
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31
ok.31:
  br label %bb5
bb4:
  br label %bb8
bb5:
  br label %bb7
bb6:
  %t32 = load i32, ptr %l25, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 1, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  call void @__olang_scope_close(ptr %s0)
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t40, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t43 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 0
  %t44 = load i32, ptr %t43
  %t46 = trunc i64 5 to i32
  %t47 = icmp eq i32 %t44, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s2, ptr %t51, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i32 %t53, ptr %l31
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb12, label %ok.55
ok.55:
  br label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb13
bb12:
  %t56 = load i32, ptr %l31, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t66 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t64, 0
  store { i32, { i64, ptr } } %t66, ptr %rv
  br label %ret
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t67 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t68, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t70, ptr %l34
  br label %bb15
bb15:
  %t71 = load i1, ptr %l34, !tbaa !21
  br i1 %t71, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s3, ptr %t72, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i32 %t74, ptr %l36
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb19, label %ok.76
ok.76:
  br label %bb18
bb17:
  br label %bb21
bb18:
  br label %bb20
bb19:
  %t77 = load i32, ptr %l36, !tbaa !23
  %t78 = lshr i32 %t77, 16
  %t79 = and i32 %t77, 65535
  %t80 = icmp eq i32 %t78, 1
  %t81 = select i1 %t80, i32 1, i32 0
  %t82 = icmp eq i32 %t77, 0
  %t83 = shl i32 %t81, 16
  %t84 = or i32 %t83, %t79
  %t85 = select i1 %t82, i32 0, i32 %t84
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t87 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t85, 0
  store { i32, { i64, ptr } } %t87, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t88 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t88, ptr %l38
  br label %bb22
bb22:
  %t89 = load %"std/prelude/text:StringBuilder", ptr %l38
  store %"std/prelude/text:StringBuilder" %t89, ptr %l4
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/bindgen:cFunc", ptr %t90, i32 0, i32 0
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t94 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t97 = extractvalue { i64, ptr } %t93, 1
  %t98 = extractvalue { i64, ptr } %t93, 0
  %t99 = add i64 %t95, %t98
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t102 = add i64 %t99, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t94, i64 %t95)
  %t104 = getelementptr i8, ptr %t103, i64 %t95
  call void @olang_textcopy(ptr %t104, ptr %t97, i64 %t98)
  %t105 = getelementptr i8, ptr %t104, i64 %t98
  call void @olang_textcopy(ptr %t105, ptr %t100, i64 %t101)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t103, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = extractvalue { i64, ptr } %t107, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t114)
  br label %bb23
bb23:
  %t117 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t117, ptr %l44
  br label %bb24
bb24:
  %t118 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t119 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 4
  %t120 = load i64, ptr %t119, !tbaa !24
  store i64 %t120, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t122 = load i64, ptr %l7, !tbaa !24
  %t123 = load i64, ptr %l6, !tbaa !24
  %t126 = icmp sgt i64 %t122, %t123
  br i1 %t126, label %bb25, label %bb26
bb25:
  %t128 = load i64, ptr %l8, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb30
bb27:
  %t132 = load i64, ptr %l7, !tbaa !24
  %t133 = load i64, ptr %l6, !tbaa !24
  %t136 = sub i64 %t132, %t133
  %t137 = load i64, ptr %l8, !tbaa !24
  %t140 = add i64 %t136, %t137
  %t142 = sub i64 %t140, 1
  %t143 = load i64, ptr %l8, !tbaa !24
  %t146 = sdiv i64 %t142, %t143
  store i64 %t146, ptr %l52, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb29
bb29:
  %t148 = load i64, ptr %l52, !tbaa !24
  store i64 %t148, ptr %l49, !tbaa !24
  br label %bb30
bb30:
  %t149 = load i64, ptr %l49, !tbaa !24
  store i64 %t149, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t150 = load i64, ptr %l10, !tbaa !24
  %t151 = load i64, ptr %l9, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb33:
  br label %bb34
bb34:
  %t158 = load i64, ptr %l6, !tbaa !24
  %t159 = load i64, ptr %l10, !tbaa !24
  %t160 = load i64, ptr %l8, !tbaa !24
  %t163 = mul i64 %t159, %t160
  %t166 = add i64 %t158, %t163
  store i64 %t166, ptr %l11, !tbaa !24
  %t168 = load i64, ptr %l11, !tbaa !24
  %t170 = icmp sgt i64 %t168, 0
  br i1 %t170, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l4, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb38:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l73, !tbaa !29
  %t174 = load i64, ptr %l11, !tbaa !24
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/bindgen:cFunc", ptr %t175, i32 0, i32 2
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp slt i64 %t174, %t180
  br i1 %t183, label %bb39, label %bb40
bb39:
  %t185 = load ptr, ptr %l1, !tbaa !29
  %t187 = getelementptr %"compiler/bindgen:cFunc", ptr %t185, i32 0, i32 2
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l81, !tbaa !27
  %t189 = load i64, ptr %l11, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %t192, i64 %t189
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !37
  store { i64, ptr } %t194, ptr %l79, !tbaa !27
  br label %bb41
bb40:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l79, !tbaa !27
  br label %bb41
bb41:
  %t196 = load i64, ptr %l11, !tbaa !24
  %t197 = load ptr, ptr %l73, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t201 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v1, ptr %s0, ptr %s6, ptr %t197, { i64, ptr } %t198, i64 %t196, ptr %l5)
  store { i64, ptr } %t201, ptr %l86
  br label %bb42
bb42:
  %t202 = load { i64, ptr }, ptr %l86, !tbaa !27
  store ptr %l4, ptr %l87, !tbaa !29
  store { i64, ptr } %t202, ptr %l88, !tbaa !27
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l90, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/bindgen:gen", ptr %t205, i32 0, i32 9
  %t208 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 5
  %t209 = load i64, ptr %t208, !tbaa !24
  %t210 = load i64, ptr %l11, !tbaa !24
  %t213 = add i64 %t209, %t210
  %t216 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t207, i64 %t213)
  store i64 %t216, ptr %l96
  br label %bb43
bb43:
  %t217 = load ptr, ptr %l90, !tbaa !29
  %t218 = load i64, ptr %l96, !tbaa !24
  %t219 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamType(ptr %v0, ptr %s6, ptr %t217, i64 %t218)
  %t220 = extractvalue { i32, { i64, ptr } } %t219, 1
  %t221 = extractvalue { i32, { i64, ptr } } %t219, 0
  store i32 %t221, ptr %l98
  %t222 = icmp ne i32 %t221, 0
  br i1 %t222, label %bb45, label %ok.223
ok.223:
  store { i64, ptr } %t220, ptr %l97
  br label %bb44
bb44:
  %t224 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t224, ptr %l89, !tbaa !27
  br label %bb46
bb45:
  %t225 = load i32, ptr %l98, !tbaa !23
  %t226 = lshr i32 %t225, 16
  %t227 = and i32 %t225, 65535
  %t228 = icmp eq i32 %t226, 1
  %t229 = select i1 %t228, i32 1, i32 0
  %t230 = icmp eq i32 %t225, 0
  %t231 = shl i32 %t229, 16
  %t232 = or i32 %t231, %t227
  %t233 = select i1 %t230, i32 0, i32 %t232
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t235 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t233, 0
  store { i32, { i64, ptr } } %t235, ptr %rv
  br label %ret
bb46:
  %t236 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t241 = add i64 %t238, %t240
  %t242 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = add i64 %t241, %t244
  %t246 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t245)
  call void @olang_textcopy(ptr %t246, ptr %t237, i64 %t238)
  %t247 = getelementptr i8, ptr %t246, i64 %t238
  call void @olang_textcopy(ptr %t247, ptr %t239, i64 %t240)
  %t248 = getelementptr i8, ptr %t247, i64 %t240
  call void @olang_textcopy(ptr %t248, ptr %t243, i64 %t244)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t246, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = extractvalue { i64, ptr } %t250, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  %t258 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t258, { i64, ptr } %t257)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb48:
  %t260 = load i64, ptr %l10, !tbaa !24
  %t262 = add i64 %t260, 1
  store i64 %t262, ptr %l10, !tbaa !24
  br label %bb31
bb49:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb50
bb50:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/bindgen:gen", ptr %t265, i32 0, i32 8
  %t268 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t269 = load i64, ptr %t268, !tbaa !24
  %t272 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t267, i64 %t269)
  store %"compiler/bindgen:ctype" %t272, ptr %l108
  br label %bb51
bb51:
  %t273 = getelementptr %"compiler/bindgen:ctype", ptr %l108, i32 0, i32 0
  %t274 = load i32, ptr %t273
  %t276 = trunc i64 0 to i32
  %t277 = icmp eq i32 %t274, %t276
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l4, ptr %l112, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t283 = load i64, ptr %t282, !tbaa !24
  %t286 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %s10, ptr %t281, i64 %t283, i1 false)
  %t287 = extractvalue { i32, { i64, ptr } } %t286, 1
  %t288 = extractvalue { i32, { i64, ptr } } %t286, 0
  store i32 %t288, ptr %l117
  %t289 = icmp ne i32 %t288, 0
  br i1 %t289, label %bb55, label %ok.290
ok.290:
  store { i64, ptr } %t287, ptr %l116
  br label %bb54
bb53:
  br label %bb58
bb54:
  %t291 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t291, ptr %l113, !tbaa !27
  br label %bb56
bb55:
  %t292 = load i32, ptr %l117, !tbaa !23
  %t293 = lshr i32 %t292, 16
  %t294 = and i32 %t292, 65535
  %t295 = icmp eq i32 %t293, 1
  %t296 = select i1 %t295, i32 1, i32 0
  %t297 = icmp eq i32 %t292, 0
  %t298 = shl i32 %t296, 16
  %t299 = or i32 %t298, %t294
  %t300 = select i1 %t297, i32 0, i32 %t299
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t302 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t300, 0
  store { i32, { i64, ptr } } %t302, ptr %rv
  br label %ret
bb56:
  %t303 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t305 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t305, 1
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t308 = add i64 %t304, %t307
  %t309 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t308)
  call void @olang_textcopy(ptr %t309, ptr %t303, i64 %t304)
  %t310 = getelementptr i8, ptr %t309, i64 %t304
  call void @olang_textcopy(ptr %t310, ptr %t306, i64 %t307)
  %t311 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t309, 1
  %t314 = extractvalue { i64, ptr } %t312, 0
  %t315 = extractvalue { i64, ptr } %t312, 1
  %t316 = mul i64 %t314, 1
  %t317 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t316)
  call void @llvm.memcpy.p0.p0.i64(ptr %t317, ptr %t315, i64 %t316, i1 false)
  %t318 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t317, 1
  %t320 = load ptr, ptr %l112, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t320, { i64, ptr } %t319)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb58:
  %t323 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l4)
  store { i64, ptr } %t323, ptr %l122
  br label %bb59
bb59:
  %t324 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t324, ptr %l123, !tbaa !27
  %t325 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t325, 0
  store i64 %t326, ptr %l124, !tbaa !24
  %t327 = load i64, ptr %l124, !tbaa !24
  %t328 = mul i64 %t327, 1
  %t329 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t328)
  %t330 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t329, 1
  store { i64, ptr } %t331, ptr %l125, !tbaa !27
  %t332 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = load i64, ptr %l124, !tbaa !24
  %t337 = mul i64 %t336, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t333, ptr %t335, i64 %t337, i1 false)
  %t338 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t338, ptr %l123, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t339 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t340 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t339, 1
  store { i32, { i64, ptr } } %t340, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisByte(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca %"compiler/bindgen:ctype"
  %l9 = alloca i1
  %l13 = alloca %"compiler/bindgen:ctype"
  %l16 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 8
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t3, i64 %t4)
  store %"compiler/bindgen:ctype" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/bindgen:ctype", ptr %l6, i32 0, i32 0
  %t9 = load i32, ptr %t8
  %t11 = trunc i64 1 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/bindgen:gen", ptr %t14, i32 0, i32 8
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/bindgen:ctype" %t20, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb4:
  %t21 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t26 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0, ptr %v0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x { i64, ptr }] }>, ptr @.d45, i32 0, i32 1) }, { i64, ptr } %t22)
  store i1 %t26, ptr %l16
  br label %bb5
bb5:
  %t27 = load i1, ptr %l16, !tbaa !21
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l9, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisChar(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca %"compiler/bindgen:ctype"
  %l8 = alloca i1
  %l12 = alloca %"compiler/bindgen:ctype"
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 8
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t3, i64 %t4)
  store %"compiler/bindgen:ctype" %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t9 = load i32, ptr %t8
  %t11 = trunc i64 1 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/bindgen:gen", ptr %t14, i32 0, i32 8
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/bindgen:ctype" %t20, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t21 = getelementptr %"compiler/bindgen:ctype", ptr %l12, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t24, ptr %l14
  br label %bb5
bb5:
  %t25 = load i1, ptr %l14, !tbaa !21
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i1, ptr %l8, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca %"compiler/bindgen:record"
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 2
  %t7 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/bindgen:record" %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/bindgen:record", ptr %l5, i32 0, i32 7
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = extractvalue { i64, ptr } %t9, 0
  %t13 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t11, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecords(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"compiler/bindgen:record"
  %l18 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450"
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i1
  %l47 = alloca i1
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca %"compiler/bindgen:record"
  %l88 = alloca i1
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i32
  %l95 = alloca i1
  %l96 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i32
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l120 = alloca i1
  %l128 = alloca i1
  %l140 = alloca %"compiler/bindgen:record"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/bindgen:gen", ptr %t3, i32 0, i32 1
  %t7 = call %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd80cb4cbc6ceb8a13686fbc19b8451b4(ptr %v0, ptr %v0, ptr %t5)
  store %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" %t7, ptr %l21
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %l21
  store %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" %t8, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H116ed76223103781f5a7340c80f3d0f3(ptr %v0, ptr %v0, ptr %l2)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l25
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14
ok.14:
  store { i64, ptr } %t11, ptr %l24
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t15, ptr %l22, !tbaa !27
  br label %bb9
bb5:
  %t16 = load i32, ptr %l25, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_a14853be10f42619_d5c3261a58ff8505)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb9:
  %t21 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t21, ptr %l3, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/bindgen:gen", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v0, ptr %v0, ptr %t24, { i64, ptr } %t25)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l33
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb11, label %ok.32
ok.32:
  store { i64, ptr } %t29, ptr %l32
  br label %bb10
bb10:
  %t33 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t33, ptr %l28, !tbaa !27
  br label %bb13
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l28, !tbaa !27
  br label %bb13
bb13:
  %t34 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t35, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t37, ptr %l35
  br label %bb14
bb14:
  %t38 = load i1, ptr %l35, !tbaa !21
  br i1 %t38, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb18
bb16:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t39, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t41, ptr %l38
  br label %bb17
bb17:
  %t42 = load i1, ptr %l38, !tbaa !21
  store i1 %t42, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  %t43 = load i1, ptr %l36, !tbaa !21
  br i1 %t43, label %bb19, label %bb20
bb19:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t44)
  store i1 %t49, ptr %l43
  br label %bb21
bb20:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb22
bb21:
  %t50 = load i1, ptr %l43, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l39, !tbaa !21
  br label %bb22
bb22:
  %t53 = load i1, ptr %l39, !tbaa !21
  br i1 %t53, label %bb23, label %bb24
bb23:
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t56 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t54)
  store i1 %t56, ptr %l47
  br label %bb25
bb24:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb26
bb25:
  %t57 = load i1, ptr %l47, !tbaa !21
  store i1 %t57, ptr %l45, !tbaa !21
  br label %bb26
bb26:
  %t58 = load i1, ptr %l45, !tbaa !21
  br i1 %t58, label %bb27, label %bb28
bb27:
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = extractvalue { i64, ptr } %t59, 0
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t61, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } %t65, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 1
  %t76 = extractvalue { i64, ptr } %t73, 0
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t75, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %s0, ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t72, { i64, ptr } %t86)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  br label %bb3
bb32:
  store i64 0, ptr %l6, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/bindgen:gen", ptr %t90, i32 0, i32 2
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t92)
  store i64 %t94, ptr %l57
  br label %bb33
bb33:
  %t95 = load i64, ptr %l57, !tbaa !24
  store i64 %t95, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = icmp sgt i64 %t96, %t97
  br i1 %t100, label %bb34, label %bb35
bb34:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb39
bb36:
  %t106 = load i64, ptr %l7, !tbaa !24
  %t107 = load i64, ptr %l6, !tbaa !24
  %t110 = sub i64 %t106, %t107
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = add i64 %t110, %t111
  %t116 = sub i64 %t114, 1
  %t117 = load i64, ptr %l8, !tbaa !24
  %t120 = sdiv i64 %t116, %t117
  store i64 %t120, ptr %l64, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb38
bb38:
  %t122 = load i64, ptr %l64, !tbaa !24
  store i64 %t122, ptr %l61, !tbaa !24
  br label %bb39
bb39:
  %t123 = load i64, ptr %l61, !tbaa !24
  store i64 %t123, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t124 = load i64, ptr %l10, !tbaa !24
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = icmp slt i64 %t124, %t125
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb85
bb42:
  br label %bb43
bb43:
  %t132 = load i64, ptr %l6, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load i64, ptr %l8, !tbaa !24
  %t137 = mul i64 %t133, %t134
  %t140 = add i64 %t132, %t137
  store i64 %t140, ptr %l11, !tbaa !24
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/bindgen:gen", ptr %t142, i32 0, i32 2
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t144, i64 %t145)
  store %"compiler/bindgen:record" %t148, ptr %l85
  br label %bb44
bb44:
  %t149 = getelementptr %"compiler/bindgen:record", ptr %l85, i32 0, i32 0
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  store { i64, ptr } %t150, ptr %l12, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t152, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t154, ptr %l88
  br label %bb45
bb45:
  %t155 = load i1, ptr %l88, !tbaa !21
  br i1 %t155, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb84
bb47:
  br label %bb48
bb48:
  %t156 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t159 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %s0, ptr %v0, ptr %s0, ptr %l1, { i64, ptr } %t156)
  %t160 = extractvalue { i32, { i64, ptr } } %t159, 1
  %t161 = extractvalue { i32, { i64, ptr } } %t159, 0
  store i32 %t161, ptr %l93
  %t162 = icmp ne i32 %t161, 0
  br i1 %t162, label %bb50, label %ok.163
ok.163:
  store { i64, ptr } %t160, ptr %l92
  br label %bb49
bb49:
  %t164 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t164, ptr %l89, !tbaa !27
  br label %bb52
bb50:
  br label %bb51
bb51:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l89, !tbaa !27
  br label %bb52
bb52:
  %t165 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t165, ptr %l13, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t168 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t166, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t168, ptr %l95
  br label %bb53
bb53:
  %t169 = load i1, ptr %l95, !tbaa !21
  br i1 %t169, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t170 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t172 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s9, { i64, ptr } %t170, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) })
  %t173 = extractvalue { i32, i64 } %t172, 1
  %t174 = extractvalue { i32, i64 } %t172, 0
  store i32 %t174, ptr %l99
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb57, label %ok.176
ok.176:
  store i64 %t173, ptr %l98
  br label %bb56
bb55:
  br label %bb69
bb56:
  %t177 = load i64, ptr %l98, !tbaa !24
  store i64 %t177, ptr %l96, !tbaa !24
  br label %bb59
bb57:
  br label %bb58
bb58:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l96, !tbaa !24
  br label %bb59
bb59:
  %t178 = load i64, ptr %l96, !tbaa !24
  store i64 %t178, ptr %l14, !tbaa !24
  %t179 = load i64, ptr %l14, !tbaa !24
  %t181 = icmp sge i64 %t179, 0
  br i1 %t181, label %bb60, label %bb61
bb60:
  %t183 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t183, ptr %l103, !tbaa !27
  %t184 = load i64, ptr %l14, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l105, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t187, 0
  store i64 %t190, ptr %l108, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l109, !tbaa !24
  %t193 = load i64, ptr %l105, !tbaa !24
  %t194 = icmp sge i64 %t193, 0
  br i1 %t194, label %bb62, label %bb63
bb61:
  %t196 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 1
  %t199 = extractvalue { i64, ptr } %t196, 0
  %t200 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t199)
  call void @olang_textcopy(ptr %t200, ptr %t198, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  store { i64, ptr } %t209, ptr %l102, !tbaa !27
  br label %bb68
bb62:
  %t211 = load i64, ptr %l105, !tbaa !24
  %t212 = load i64, ptr %l108, !tbaa !24
  %t213 = icmp sle i64 %t211, %t212
  br i1 %t213, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_31d0fb4875bfcdcf_cab745411c3f21db)
  unreachable
bb64:
  %t215 = load i64, ptr %l108, !tbaa !24
  %t216 = load i64, ptr %l109, !tbaa !24
  %t217 = icmp sle i64 %t215, %t216
  br i1 %t217, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_31d0fb4875bfcdcf_cab745411c3f21db)
  unreachable
bb66:
  %t219 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = load i64, ptr %l105, !tbaa !24
  %t222 = load i64, ptr %l108, !tbaa !24
  %t223 = getelementptr i8, ptr %t220, i64 %t221
  %t224 = sub i64 %t222, %t221
  %t225 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t223, 1
  %t228 = extractvalue { i64, ptr } %t226, 1
  %t229 = extractvalue { i64, ptr } %t226, 0
  %t230 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t229)
  call void @olang_textcopy(ptr %t230, ptr %t228, i64 %t229)
  %t231 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = extractvalue { i64, ptr } %t232, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  store { i64, ptr } %t239, ptr %l102, !tbaa !27
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_31d0fb4875bfcdcf_cab745411c3f21db)
  unreachable
bb68:
  %t241 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t241, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb69
bb69:
  %t242 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t244 = call i1 @compiler_2fbindgen_2eusable(ptr %s0, { i64, ptr } %t242)
  store i1 %t244, ptr %l120
  br label %bb70
bb70:
  %t245 = load i1, ptr %l120, !tbaa !21
  %t246 = xor i1 %t245, true
  br i1 %t246, label %bb71, label %bb72
bb71:
  %t248 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t249 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t252 = extractvalue { i64, ptr } %t248, 1
  %t253 = extractvalue { i64, ptr } %t248, 0
  %t254 = add i64 %t250, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t249, i64 %t250)
  %t256 = getelementptr i8, ptr %t255, i64 %t250
  call void @olang_textcopy(ptr %t256, ptr %t252, i64 %t253)
  %t257 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t255, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = extractvalue { i64, ptr } %t258, 1
  %t262 = mul i64 %t260, 1
  %t263 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t262)
  call void @llvm.memcpy.p0.p0.i64(ptr %t263, ptr %t261, i64 %t262, i1 false)
  %t264 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  store { i64, ptr } %t265, ptr %l13, !tbaa !27
  br label %bb73
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/bindgen:gen", ptr %t267, i32 0, i32 11
  %t270 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t273 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %s0, ptr %t269, { i64, ptr } %t270)
  store i1 %t273, ptr %l128
  br label %bb75
bb75:
  %t274 = load i1, ptr %l128, !tbaa !21
  %t275 = xor i1 %t274, true
  br i1 %t275, label %bb76, label %bb77
bb76:
  br label %bb80
bb77:
  br label %bb78
bb78:
  %t277 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t277, 1
  %t280 = extractvalue { i64, ptr } %t277, 0
  %t281 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t283 = add i64 %t280, %t282
  %t284 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t283)
  call void @olang_textcopy(ptr %t284, ptr %t279, i64 %t280)
  %t285 = getelementptr i8, ptr %t284, i64 %t280
  call void @olang_textcopy(ptr %t285, ptr %t281, i64 %t282)
  %t286 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t284, 1
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t290 = extractvalue { i64, ptr } %t287, 1
  %t291 = mul i64 %t289, 1
  %t292 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t291)
  call void @llvm.memcpy.p0.p0.i64(ptr %t292, ptr %t290, i64 %t291, i1 false)
  %t293 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  store { i64, ptr } %t294, ptr %l13, !tbaa !27
  br label %bb79
bb79:
  br label %bb74
bb80:
  %t296 = load i64, ptr %l11, !tbaa !24
  store i64 %t296, ptr %l15, !tbaa !24
  %t298 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t298, 1
  %t301 = extractvalue { i64, ptr } %t298, 0
  %t302 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t301)
  call void @olang_textcopy(ptr %t302, ptr %t300, i64 %t301)
  %t303 = insertvalue { i64, ptr } undef, i64 %t301, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t307 = extractvalue { i64, ptr } %t304, 1
  %t308 = mul i64 %t306, 1
  %t309 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t308)
  call void @llvm.memcpy.p0.p0.i64(ptr %t309, ptr %t307, i64 %t308, i1 false)
  %t310 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t309, 1
  store { i64, ptr } %t311, ptr %l16, !tbaa !27
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/bindgen:gen", ptr %t313, i32 0, i32 2
  %t316 = load i64, ptr %l15, !tbaa !24
  %t319 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t315, i64 %t316)
  store %"compiler/bindgen:record" %t319, ptr %l140
  br label %bb81
bb81:
  %t320 = load %"compiler/bindgen:record", ptr %l140
  store %"compiler/bindgen:record" %t320, ptr %l17
  %t321 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t323 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 7
  store { i64, ptr } %t321, ptr %t323, !tbaa !27
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/bindgen:gen", ptr %t324, i32 0, i32 2
  %t327 = load i64, ptr %l15, !tbaa !24
  %t328 = load %"compiler/bindgen:record", ptr %l17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v0, ptr %t326, i64 %t327, %"compiler/bindgen:record" %t328)
  br label %bb82
bb82:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/bindgen:gen", ptr %t332, i32 0, i32 11
  %t335 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 1
  %t338 = extractvalue { i64, ptr } %t335, 0
  %t339 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t338)
  call void @olang_textcopy(ptr %t339, ptr %t337, i64 %t338)
  %t340 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t344 = extractvalue { i64, ptr } %t341, 1
  %t345 = mul i64 %t343, 1
  %t346 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t345)
  call void @llvm.memcpy.p0.p0.i64(ptr %t346, ptr %t344, i64 %t345, i1 false)
  %t347 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t334, { i64, ptr } %t348, i64 0)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s7)
  br label %bb84
bb84:
  %t351 = load i64, ptr %l10, !tbaa !24
  %t353 = add i64 %t351, 1
  store i64 %t353, ptr %l10, !tbaa !24
  br label %bb40
bb85:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, i1 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca ptr
  %l13 = alloca %"compiler/bindgen:ctype"
  %l16 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l7, !tbaa !29
  %t14 = call %"compiler/bindgen:ctype" @compiler_2fbindgen_3actype_2ector(ptr %v1, ptr %v0, i32 %a1, { i64, ptr } %a2, i64 %a3, i1 %a4, i64 %a5)
  store %"compiler/bindgen:ctype" %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = load %"compiler/bindgen:ctype", ptr %l13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ePush_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t15, %"compiler/bindgen:ctype" %t16)
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/bindgen:gen", ptr %t17, i32 0, i32 8
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eLen_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l16
  br label %bb3
bb3:
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = sub i64 %t22, 1
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enumType(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i64
  %l35 = alloca i1
  %l38 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l45 = alloca i1
  %l48 = alloca i64
  %l50 = alloca i1
  %l53 = alloca i64
  %l55 = alloca i1
  %l57 = alloca i64
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i32
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca i32
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t5, i32 0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t8, ptr %l9
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i64, ptr %l9, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
bb5:
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t12, ptr %l11
  br label %bb6
bb6:
  %t13 = load i1, ptr %l11, !tbaa !21
  br i1 %t13, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb8:
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t16, ptr %l14
  br label %bb9
bb9:
  %t17 = load i1, ptr %l14, !tbaa !21
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb11, label %bb12
bb11:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t19, i32 1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t22, ptr %l17
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i64, ptr %l17, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
bb14:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t26, ptr %l19
  br label %bb15
bb15:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb16, label %bb17
bb16:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i32 1, ptr %l21
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp eq i64 %t29, 1
  br i1 %t31, label %bb18, label %bb19
bb17:
  br label %bb25
bb18:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l24, !tbaa !27
  br label %bb23
bb19:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = icmp eq i64 %t33, 2
  br i1 %t35, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb22
bb22:
  %t37 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  br label %bb23
bb23:
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = load i32, ptr %l21
  %t40 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t41 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t38, i32 %t39, { i64, ptr } %t40, i64 -1, i1 false, i64 0)
  store i64 %t41, ptr %l28
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb25:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t43, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t45, ptr %l30
  br label %bb26
bb26:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb27, label %bb28
bb27:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t50 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t47, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d66, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t50, ptr %l33
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load i64, ptr %l33, !tbaa !24
  store i64 %t51, ptr %rv
  br label %ret
bb30:
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d67, i32 0, i32 1) })
  store i1 %t54, ptr %l35
  br label %bb31
bb31:
  %t55 = load i1, ptr %l35, !tbaa !21
  br i1 %t55, label %bb32, label %bb33
bb32:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb34, label %bb35
bb33:
  br label %bb39
bb34:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t60, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store i64 %t62, ptr %l40
  br label %bb36
bb35:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t63, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d69, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t66, ptr %l43
  br label %bb37
bb36:
  %t67 = load i64, ptr %l40, !tbaa !24
  store i64 %t67, ptr %l38, !tbaa !24
  br label %bb38
bb37:
  %t68 = load i64, ptr %l43, !tbaa !24
  store i64 %t68, ptr %l38, !tbaa !24
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i64, ptr %l38, !tbaa !24
  store i64 %t69, ptr %rv
  br label %ret
bb39:
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t70, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t72, ptr %l45
  br label %bb40
bb40:
  %t73 = load i1, ptr %l45, !tbaa !21
  br i1 %t73, label %bb41, label %bb42
bb41:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t74, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d71, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t77, ptr %l48
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t78 = load i64, ptr %l48, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
bb44:
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t81 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t79, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t81, ptr %l50
  br label %bb45
bb45:
  %t82 = load i1, ptr %l50, !tbaa !21
  br i1 %t82, label %bb46, label %bb47
bb46:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t86 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t83, i32 1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d73, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t86, ptr %l53
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i64, ptr %l53, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
bb49:
  %t88 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t88, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t90, ptr %l55
  br label %bb50
bb50:
  %t91 = load i1, ptr %l55, !tbaa !21
  br i1 %t91, label %bb51, label %bb52
bb51:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t92, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i64 %t94, ptr %l57
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t95 = load i64, ptr %l57, !tbaa !24
  store i64 %t95, ptr %rv
  br label %ret
bb54:
  %t96 = load i64, ptr %l2, !tbaa !24
  %t98 = icmp eq i64 %t96, 2
  store i1 %t98, ptr %l4, !tbaa !21
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t100, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d76, i32 0, i32 1) })
  store i1 %t102, ptr %l61
  br label %bb55
bb55:
  %t103 = load i1, ptr %l61, !tbaa !21
  br i1 %t103, label %bb56, label %bb57
bb56:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l62, !tbaa !29
  store i32 1, ptr %l63
  %t105 = load i1, ptr %l4, !tbaa !21
  br i1 %t105, label %bb58, label %bb59
bb57:
  br label %bb62
bb58:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l65, !tbaa !27
  br label %bb60
bb59:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l65, !tbaa !27
  br label %bb60
bb60:
  %t107 = load ptr, ptr %l62, !tbaa !29
  %t108 = load i32, ptr %l63
  %t109 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t110 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t107, i32 %t108, { i64, ptr } %t109, i64 -1, i1 false, i64 0)
  store i64 %t110, ptr %l66
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i64, ptr %l66, !tbaa !24
  store i64 %t111, ptr %rv
  br label %ret
bb62:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t114 = icmp sgt i64 %t112, 0
  br i1 %t114, label %bb63, label %bb64
bb63:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l69, !tbaa !29
  store i32 1, ptr %l70
  %t117 = load i1, ptr %l4, !tbaa !21
  br i1 %t117, label %bb65, label %bb66
bb64:
  br label %bb69
bb65:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l72, !tbaa !27
  br label %bb67
bb66:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l72, !tbaa !27
  br label %bb67
bb67:
  %t119 = load ptr, ptr %l69, !tbaa !29
  %t120 = load i32, ptr %l70
  %t121 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t122 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t119, i32 %t120, { i64, ptr } %t121, i64 -1, i1 false, i64 0)
  store i64 %t122, ptr %l73
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t123 = load i64, ptr %l73, !tbaa !24
  store i64 %t123, ptr %rv
  br label %ret
bb69:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l74, !tbaa !29
  store i32 1, ptr %l75
  %t125 = load i1, ptr %l4, !tbaa !21
  br i1 %t125, label %bb70, label %bb71
bb70:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb72
bb71:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb72
bb72:
  %t127 = load ptr, ptr %l74, !tbaa !29
  %t128 = load i32, ptr %l75
  %t129 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t130 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t127, i32 %t128, { i64, ptr } %t129, i64 -1, i1 false, i64 0)
  store i64 %t130, ptr %l78
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  %t131 = load i64, ptr %l78, !tbaa !24
  store i64 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l10 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a1, 1
  %t4 = extractvalue { i64, ptr } %a1, 0
  %t5 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t4)
  call void @olang_textcopy(ptr %t5, ptr %t3, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t8, ptr %lp4
  %t10 = load ptr, ptr %lp4
  store { i64, ptr } %t7, ptr %t10, !tbaa !27
  %t11 = load ptr, ptr %lp4
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = call i1 @compiler_2fbindgen_2eusable(ptr %v3, { i64, ptr } %t12)
  store i1 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i1, ptr %l10, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb5
bb3:
  %t18 = load ptr, ptr %lp4
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l14, !tbaa !24
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = mul i64 %t22, 1
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l15, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l14, !tbaa !24
  %t32 = mul i64 %t31, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %t30, i64 %t32, i1 false)
  %t33 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t36 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 11
  %t40 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %s0, ptr %t36, { i64, ptr } %t33)
  store i1 %t40, ptr %l19
  br label %bb4
bb4:
  %t41 = load i1, ptr %l19, !tbaa !21
  store i1 %t41, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t42 = load i1, ptr %l12, !tbaa !21
  br i1 %t42, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb7:
  %t43 = load ptr, ptr %lp4
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l21, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l22, !tbaa !24
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l23, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l22, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t63 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v2, ptr %s0, ptr %t59, { i64, ptr } %t58)
  store i1 %t63, ptr %l26
  br label %bb8
bb8:
  %t64 = load i1, ptr %l26, !tbaa !21
  store i1 %t64, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t65 = load i1, ptr %l20, !tbaa !21
  br i1 %t65, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb13
bb11:
  %t66 = load ptr, ptr %lp4
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t69 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t67, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t69, ptr %l29
  br label %bb12
bb12:
  %t70 = load i1, ptr %l29, !tbaa !21
  store i1 %t70, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t71 = load i1, ptr %l27, !tbaa !21
  br i1 %t71, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb15:
  %t72 = load ptr, ptr %lp4
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t75, ptr %l32
  br label %bb16
bb16:
  %t76 = load i1, ptr %l32, !tbaa !21
  store i1 %t76, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t77 = load i1, ptr %l30, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t82 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = getelementptr i8, ptr %t84, i64 %t80
  %t86 = call i64 @__olang_fmt_i64(ptr %t85, i64 %a2)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t84, 1
  store { i64, ptr } %t88, ptr %l34, !tbaa !27
  %t89 = load ptr, ptr %lp4
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l36, !tbaa !24
  %t95 = load i64, ptr %l36, !tbaa !24
  %t96 = icmp eq i64 %t91, %t95
  br i1 %t96, label %bb20, label %bb21
bb19:
  br label %bb23
bb20:
  %t98 = load ptr, ptr %lp4
  %t99 = getelementptr { i64, ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l36, !tbaa !24
  %t104 = mul i64 %t103, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t100, ptr %t102, i64 %t104, i1 false)
  br label %bb22
bb21:
  %t105 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t106 = load ptr, ptr %lp4
  store { i64, ptr } %t105, ptr %t106, !tbaa !27
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t108 = load ptr, ptr %lp4
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t111, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } %t115, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v2, ptr %v2, ptr %t107, { i64, ptr } %t122, i64 0)
  br label %bb24
bb24:
  %t125 = load ptr, ptr %lp4
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t126, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamType(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/bindgen:ctype"
  %l6 = alloca %"compiler/bindgen:ctype"
  %l9 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 8
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/bindgen:ctype" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l6
  store %"compiler/bindgen:ctype" %t8, ptr %l2
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 0
  %t10 = load i32, ptr %t9
  %t12 = trunc i64 3 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 3
  %t19 = load i1, ptr %t18, !tbaa !21
  %t23 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epointerParam(ptr %v0, ptr %v1, ptr %t15, i64 %t17, i1 %t19)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l14
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb5, label %ok.27
ok.27:
  store { i64, ptr } %t24, ptr %l13
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t28 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t28, ptr %l9, !tbaa !27
  br label %bb6
bb5:
  %t29 = load i32, ptr %l14, !tbaa !23
  %t30 = lshr i32 %t29, 16
  %t31 = and i32 %t29, 65535
  %t32 = icmp eq i32 %t30, 1
  %t33 = select i1 %t32, i32 1, i32 0
  %t34 = icmp eq i32 %t29, 0
  %t35 = shl i32 %t33, 16
  %t36 = or i32 %t35, %t31
  %t37 = select i1 %t34, i32 0, i32 %t36
  %t39 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t37, 0
  store { i32, { i64, ptr } } %t39, ptr %rv
  br label %ret
bb6:
  %t40 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t41 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t40, 1
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb7:
  %t42 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 0
  %t43 = load i32, ptr %t42
  %t45 = trunc i64 4 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t50 = load i64, ptr %t49, !tbaa !24
  %t53 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epointerParam(ptr %v0, ptr %v1, ptr %t48, i64 %t50, i1 false)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l22
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb11, label %ok.57
ok.57:
  store { i64, ptr } %t54, ptr %l21
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t58 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t58, ptr %l18, !tbaa !27
  br label %bb12
bb11:
  %t59 = load i32, ptr %l22, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t59, 0
  %t65 = shl i32 %t63, 16
  %t66 = or i32 %t65, %t61
  %t67 = select i1 %t64, i32 0, i32 %t66
  %t69 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t67, 0
  store { i32, { i64, ptr } } %t69, ptr %rv
  br label %ret
bb12:
  %t70 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t71 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t70, 1
  store { i32, { i64, ptr } } %t71, ptr %rv
  br label %ret
bb13:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i64, ptr %l1, !tbaa !24
  %t76 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %v1, ptr %t72, i64 %t73, i1 false)
  %t77 = extractvalue { i32, { i64, ptr } } %t76, 1
  %t78 = extractvalue { i32, { i64, ptr } } %t76, 0
  store i32 %t78, ptr %l28
  %t79 = icmp ne i32 %t78, 0
  br i1 %t79, label %bb15, label %ok.80
ok.80:
  store { i64, ptr } %t77, ptr %l27
  br label %bb14
bb14:
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t81, ptr %l24, !tbaa !27
  br label %bb16
bb15:
  %t82 = load i32, ptr %l28, !tbaa !23
  %t83 = lshr i32 %t82, 16
  %t84 = and i32 %t82, 65535
  %t85 = icmp eq i32 %t83, 1
  %t86 = select i1 %t85, i32 1, i32 0
  %t87 = icmp eq i32 %t82, 0
  %t88 = shl i32 %t86, 16
  %t89 = or i32 %t88, %t84
  %t90 = select i1 %t87, i32 0, i32 %t89
  %t92 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t90, 0
  store { i32, { i64, ptr } } %t92, ptr %rv
  br label %ret
bb16:
  %t93 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t94 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t93, 1
  store { i32, { i64, ptr } } %t94, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca %"compiler/bindgen:ctp"
  %l4 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l12 = alloca %"compiler/bindgen:ctp"
  %l16 = alloca i64
  %l25 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t5, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store i64 %t7, ptr %l8
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
bb4:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = call { i64, ptr } @compiler_2fbindgen_2ectokens(ptr %v1, ptr %s0, { i64, ptr } %t9)
  store { i64, ptr } %t11, ptr %l10
  br label %bb5
bb5:
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 16
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t20 = call %"compiler/bindgen:ctp" @compiler_2fbindgen_3actp_2ector(ptr %s0, ptr %s0, { i64, ptr } %t18)
  store %"compiler/bindgen:ctp" %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load %"compiler/bindgen:ctp", ptr %l12
  store %"compiler/bindgen:ctp" %t21, ptr %l3
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  %t27 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etypeName(ptr %v0, ptr %s0, ptr %t22, ptr %l3, i64 %t23)
  store i64 %t27, ptr %l16
  br label %bb7
bb7:
  %t28 = load i64, ptr %l16, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  %t29 = getelementptr %"compiler/bindgen:ctp", ptr %l3, i32 0, i32 1
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = getelementptr %"compiler/bindgen:ctp", ptr %l3, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t37 = icmp slt i64 %t30, %t34
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t44 = extractvalue { i64, ptr } %t40, 1
  %t45 = extractvalue { i64, ptr } %t40, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = getelementptr i8, ptr %t51, i64 %t45
  call void @olang_textcopy(ptr %t52, ptr %t47, i64 %t48)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t50, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t64 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t39, { i64, ptr } %t61)
  store i64 %t64, ptr %l25
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t65 = load i64, ptr %l25, !tbaa !24
  store i64 %t65, ptr %rv
  br label %ret
bb11:
  %t66 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/bindgen:record"
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/bindgen:record"
  %l17 = alloca %"compiler/bindgen:record"
  %l29 = alloca %"compiler/bindgen:record"
  %l38 = alloca %"compiler/bindgen:record"
  %l40 = alloca i1
  %l44 = alloca %"compiler/bindgen:record"
  %l47 = alloca i1
  %l51 = alloca %"compiler/bindgen:record"
  %l58 = alloca %"compiler/bindgen:record"
  %l60 = alloca i64
  %l62 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca i64
  %l74 = alloca %"compiler/bindgen:ctype"
  %l80 = alloca %"compiler/bindgen:ctype"
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i32
  %l93 = alloca i64
  %l97 = alloca %"compiler/bindgen:record"
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/bindgen:record" %t7, ptr %l17
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 9
  %t9 = load i64, ptr %t8, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp eq i64 %t11, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = icmp sge i64 %t16, 1
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load i64, ptr %l1, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/bindgen:gen", ptr %t23, i32 0, i32 2
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t25, i64 %t26)
  store %"compiler/bindgen:record" %t29, ptr %l29
  br label %bb8
bb8:
  %t30 = load %"compiler/bindgen:record", ptr %l29
  store %"compiler/bindgen:record" %t30, ptr %l5
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = getelementptr %"compiler/bindgen:record", ptr %l5, i32 0, i32 9
  store i64 %t31, ptr %t33, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/bindgen:gen", ptr %t34, i32 0, i32 2
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load %"compiler/bindgen:record", ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v0, ptr %t36, i64 %t37, %"compiler/bindgen:record" %t38)
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/bindgen:gen", ptr %t42, i32 0, i32 2
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t44, i64 %t45)
  store %"compiler/bindgen:record" %t48, ptr %l38
  br label %bb10
bb10:
  %t49 = getelementptr %"compiler/bindgen:record", ptr %l38, i32 0, i32 2
  %t50 = load i1, ptr %t49, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/bindgen:gen", ptr %t52, i32 0, i32 2
  %t55 = load i64, ptr %l1, !tbaa !24
  %t58 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t54, i64 %t55)
  store %"compiler/bindgen:record" %t58, ptr %l44
  br label %bb13
bb12:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb14
bb13:
  %t59 = getelementptr %"compiler/bindgen:record", ptr %l44, i32 0, i32 3
  %t60 = load i1, ptr %t59, !tbaa !21
  %t62 = xor i1 %t60, true
  store i1 %t62, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t64 = load i1, ptr %l40, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/bindgen:gen", ptr %t65, i32 0, i32 2
  %t68 = load i64, ptr %l1, !tbaa !24
  %t71 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store %"compiler/bindgen:record" %t71, ptr %l51
  br label %bb17
bb16:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb18
bb17:
  %t72 = getelementptr %"compiler/bindgen:record", ptr %l51, i32 0, i32 1
  %t73 = load i1, ptr %t72, !tbaa !21
  %t75 = xor i1 %t73, true
  store i1 %t75, ptr %l47, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l47, !tbaa !21
  store i1 %t77, ptr %l6, !tbaa !21
  %t78 = load i1, ptr %l6, !tbaa !21
  br i1 %t78, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/bindgen:gen", ptr %t80, i32 0, i32 2
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t82, i64 %t83)
  store %"compiler/bindgen:record" %t86, ptr %l58
  br label %bb21
bb20:
  br label %bb42
bb21:
  %t87 = getelementptr %"compiler/bindgen:record", ptr %l58, i32 0, i32 5
  store ptr %t87, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t89 = load i64, ptr %l8, !tbaa !24
  store i64 %t89, ptr %l60, !tbaa !24
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s4, ptr %t90)
  store i64 %t92, ptr %l62
  br label %bb23
bb23:
  %t93 = load i64, ptr %l60, !tbaa !24
  %t94 = load i64, ptr %l62, !tbaa !24
  %t95 = icmp slt i64 %t93, %t94
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb25:
  br label %bb26
bb26:
  %t99 = load ptr, ptr %l7, !tbaa !29
  %t100 = load i64, ptr %l8, !tbaa !24
  %t103 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s4, ptr %s4, ptr %t99, i64 %t100)
  store { i64, ptr } %t103, ptr %l67
  br label %bb27
bb27:
  %t104 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t109 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s4, ptr %t105, { i64, ptr } %t104, i64 0)
  store i64 %t109, ptr %l70
  br label %bb28
bb28:
  %t110 = load i64, ptr %l70, !tbaa !24
  store i64 %t110, ptr %l10, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/bindgen:gen", ptr %t111, i32 0, i32 8
  %t114 = load i64, ptr %l10, !tbaa !24
  %t117 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s5, ptr %t113, i64 %t114)
  store %"compiler/bindgen:ctype" %t117, ptr %l74
  br label %bb29
bb29:
  %t118 = getelementptr %"compiler/bindgen:ctype", ptr %l74, i32 0, i32 0
  %t119 = load i32, ptr %t118
  %t121 = trunc i64 4 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/bindgen:gen", ptr %t124, i32 0, i32 8
  %t127 = load i64, ptr %l10, !tbaa !24
  %t130 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s6, ptr %t126, i64 %t127)
  store %"compiler/bindgen:ctype" %t130, ptr %l80
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t131 = getelementptr %"compiler/bindgen:ctype", ptr %l80, i32 0, i32 2
  %t132 = load i64, ptr %t131, !tbaa !24
  store i64 %t132, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l10, !tbaa !24
  %t138 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %s5, ptr %t134, i64 %t135)
  %t139 = extractvalue { i32, { i64, ptr } } %t138, 1
  %t140 = extractvalue { i32, { i64, ptr } } %t138, 0
  store i32 %t140, ptr %l86
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb35, label %ok.142
ok.142:
  store { i64, ptr } %t139, ptr %l85
  br label %bb34
bb34:
  %t143 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t143, ptr %l82, !tbaa !27
  br label %bb39
bb35:
  %t144 = load i32, ptr %l86, !tbaa !23
  %t145 = ashr i32 %t144, 16
  %t147 = icmp eq i32 %t145, 1
  br i1 %t147, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_e8c29cca38e7747c_62862859d6377258)
  unreachable
bb38:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb40:
  %t149 = load i64, ptr %l8, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l8, !tbaa !24
  br label %bb22
bb41:
  call void @__olang_scope_close(ptr %s4)
  br label %bb42
bb42:
  %t153 = load i64, ptr %l1, !tbaa !24
  store i64 %t153, ptr %l11, !tbaa !24
  %t155 = load i1, ptr %l6, !tbaa !21
  br i1 %t155, label %bb43, label %bb44
bb43:
  store i64 1, ptr %l93, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb45
bb45:
  %t157 = load i64, ptr %l93, !tbaa !24
  store i64 %t157, ptr %l12, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/bindgen:gen", ptr %t158, i32 0, i32 2
  %t161 = load i64, ptr %l11, !tbaa !24
  %t164 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t160, i64 %t161)
  store %"compiler/bindgen:record" %t164, ptr %l97
  br label %bb46
bb46:
  %t165 = load %"compiler/bindgen:record", ptr %l97
  store %"compiler/bindgen:record" %t165, ptr %l13
  %t166 = load i64, ptr %l12, !tbaa !24
  %t168 = getelementptr %"compiler/bindgen:record", ptr %l13, i32 0, i32 9
  store i64 %t166, ptr %t168, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/bindgen:gen", ptr %t169, i32 0, i32 2
  %t172 = load i64, ptr %l11, !tbaa !24
  %t173 = load %"compiler/bindgen:record", ptr %l13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v0, ptr %t171, i64 %t172, %"compiler/bindgen:record" %t173)
  br label %bb47
bb47:
  %t177 = load i1, ptr %l6, !tbaa !21
  store i1 %t177, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epointerParam(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/bindgen:ctype"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca %"compiler/bindgen:ctype"
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca %"compiler/bindgen:ctype"
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l39 = alloca i64
  %l41 = alloca i1
  %l44 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l56 = alloca %"compiler/bindgen:ctype"
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l68 = alloca i64
  %l71 = alloca i1
  %l75 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l89 = alloca i1
  %l91 = alloca i32
  %l93 = alloca %"std/prelude/text:StringBuilder"
  %l99 = alloca i64
  %l102 = alloca i64
  %l123 = alloca ptr
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l132 = alloca i64
  %l133 = alloca { i64, ptr }
  %l134 = alloca i32
  %l144 = alloca %"compiler/bindgen:ctype"
  %l148 = alloca ptr
  %l149 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l153 = alloca i32
  %l158 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l160 = alloca i64
  %l161 = alloca { i64, ptr }
  %l166 = alloca i32
  %l169 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 8
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/bindgen:ctype" %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l19
  store %"compiler/bindgen:ctype" %t8, ptr %l3
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 0
  %t10 = load i32, ptr %t9
  store i32 %t10, ptr %l4
  %t12 = load i32, ptr %l4
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb12
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t20, ptr %l24
  br label %bb5
bb5:
  %t21 = load i1, ptr %l24, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l25, !tbaa !27
  br label %bb8
bb7:
  %t22 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l25, !tbaa !27
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  %t39 = load i1, ptr %l2, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t42 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = extractvalue { i64, ptr } %t41, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t42, i64 %t43)
  %t52 = getelementptr i8, ptr %t51, i64 %t43
  call void @olang_textcopy(ptr %t52, ptr %t45, i64 %t46)
  %t53 = getelementptr i8, ptr %t52, i64 %t46
  call void @olang_textcopy(ptr %t53, ptr %t48, i64 %t49)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t51, 1
  store { i64, ptr } %t55, ptr %l30, !tbaa !27
  br label %bb11
bb10:
  %t57 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t58 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t61 = extractvalue { i64, ptr } %t57, 1
  %t62 = extractvalue { i64, ptr } %t57, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t58, i64 %t59)
  %t68 = getelementptr i8, ptr %t67, i64 %t59
  call void @olang_textcopy(ptr %t68, ptr %t61, i64 %t62)
  %t69 = getelementptr i8, ptr %t68, i64 %t62
  call void @olang_textcopy(ptr %t69, ptr %t64, i64 %t65)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t67, 1
  store { i64, ptr } %t71, ptr %l30, !tbaa !27
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  %t73 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t74 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t73, 1
  store { i32, { i64, ptr } } %t74, ptr %rv
  br label %ret
bb12:
  %t75 = load i32, ptr %l4
  %t77 = trunc i64 2 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb25
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t85 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t80, { i64, ptr } %t82)
  store i64 %t85, ptr %l39
  br label %bb16
bb16:
  %t86 = load i64, ptr %l39, !tbaa !24
  store i64 %t86, ptr %l6, !tbaa !24
  %t87 = load i1, ptr %l2, !tbaa !21
  br i1 %t87, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb20
bb18:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t93, ptr %l44
  br label %bb19
bb19:
  %t94 = load i1, ptr %l44, !tbaa !21
  %t95 = xor i1 %t94, true
  store i1 %t95, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t97 = load i1, ptr %l41, !tbaa !21
  br i1 %t97, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l46, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d96, i32 0, i32 1) }, ptr %l46, !tbaa !27
  br label %bb23
bb23:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s5, ptr %t98, i64 %t99)
  store { i64, ptr } %t102, ptr %l49
  br label %bb24
bb24:
  %t103 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = add i64 %t105, %t108
  %t110 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t112 = add i64 %t109, %t111
  %t113 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t104, i64 %t105)
  %t114 = getelementptr i8, ptr %t113, i64 %t105
  call void @olang_textcopy(ptr %t114, ptr %t107, i64 %t108)
  %t115 = getelementptr i8, ptr %t114, i64 %t108
  call void @olang_textcopy(ptr %t115, ptr %t110, i64 %t111)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t113, 1
  call void @__olang_scope_close(ptr %s5)
  %t119 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t117, 1
  store { i32, { i64, ptr } } %t119, ptr %rv
  br label %ret
bb25:
  %t120 = load i32, ptr %l4
  %t122 = trunc i64 3 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb47
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/bindgen:gen", ptr %t125, i32 0, i32 8
  %t128 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t129 = load i64, ptr %t128, !tbaa !24
  %t132 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t127, i64 %t129)
  store %"compiler/bindgen:ctype" %t132, ptr %l56
  br label %bb29
bb29:
  %t133 = load %"compiler/bindgen:ctype", ptr %l56
  store %"compiler/bindgen:ctype" %t133, ptr %l7
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t136 = load i64, ptr %t135, !tbaa !24
  %t139 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisChar(ptr %v0, ptr %t134, i64 %t136)
  store i1 %t139, ptr %l59
  br label %bb30
bb30:
  %t140 = load i1, ptr %l59, !tbaa !21
  br i1 %t140, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l60, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t141, ptr %l61, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l62, !tbaa !24
  %t144 = load i64, ptr %l62, !tbaa !24
  %t145 = mul i64 %t144, 1
  %t146 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l63, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l62, !tbaa !24
  %t154 = mul i64 %t153, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %t152, i64 %t154, i1 false)
  %t155 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t155, ptr %l61, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t157 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t156, 1
  store { i32, { i64, ptr } } %t157, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t158 = getelementptr %"compiler/bindgen:ctype", ptr %l7, i32 0, i32 0
  %t159 = load i32, ptr %t158
  %t161 = trunc i64 2 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb34, label %bb35
bb34:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/bindgen:ctype", ptr %l7, i32 0, i32 1
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  %t169 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t164, { i64, ptr } %t166)
  store i64 %t169, ptr %l68
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t170 = load i64, ptr %l68, !tbaa !24
  store i64 %t170, ptr %l8, !tbaa !24
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i64, ptr %l8, !tbaa !24
  %t175 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t171, i64 %t172)
  store i1 %t175, ptr %l71
  br label %bb37
bb37:
  %t176 = load i1, ptr %l71, !tbaa !21
  %t177 = xor i1 %t176, true
  br i1 %t177, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l8, !tbaa !24
  %t183 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s10, ptr %t179, i64 %t180)
  store { i64, ptr } %t183, ptr %l75
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t184 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t186 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t184, i64 %t185)
  %t194 = getelementptr i8, ptr %t193, i64 %t185
  call void @olang_textcopy(ptr %t194, ptr %t187, i64 %t188)
  %t195 = getelementptr i8, ptr %t194, i64 %t188
  call void @olang_textcopy(ptr %t195, ptr %t190, i64 %t191)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t193, 1
  call void @__olang_scope_close(ptr %s10)
  %t199 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t197, 1
  store { i32, { i64, ptr } } %t199, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t200 = getelementptr %"compiler/bindgen:ctype", ptr %l7, i32 0, i32 0
  %t201 = load i32, ptr %t200
  %t203 = trunc i64 0 to i32
  %t204 = icmp eq i32 %t201, %t203
  br i1 %t204, label %bb43, label %bb44
bb43:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/bindgen:gen", ptr %t206, i32 0, i32 12
  store i1 true, ptr %t208, !tbaa !21
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d101, i32 0, i32 1) }, ptr %l80, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t209, ptr %l81, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  store i64 %t211, ptr %l82, !tbaa !24
  %t212 = load i64, ptr %l82, !tbaa !24
  %t213 = mul i64 %t212, 1
  %t214 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t213)
  %t215 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  store { i64, ptr } %t216, ptr %l83, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = load i64, ptr %l82, !tbaa !24
  %t222 = mul i64 %t221, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t218, ptr %t220, i64 %t222, i1 false)
  %t223 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t223, ptr %l81, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t225 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t224, 1
  store { i32, { i64, ptr } } %t225, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evoidRef(ptr %v0, ptr %v1, ptr %t226)
  store { i64, ptr } %t228, ptr %l85
  br label %bb46
bb46:
  %t229 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t230 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t229, 1
  store { i32, { i64, ptr } } %t230, ptr %rv
  br label %ret
bb47:
  %t231 = load i32, ptr %l4
  %t233 = trunc i64 5 to i32
  %t234 = icmp eq i32 %t231, %t233
  br i1 %t234, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb91
bb50:
  store %olang.scope zeroinitializer, ptr %s13
  %t236 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  %t239 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s13, { i64, ptr } %t237, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i1 %t239, ptr %l89
  br label %bb51
bb51:
  %t240 = load i1, ptr %l89, !tbaa !21
  br i1 %t240, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s14
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s14, ptr %t241, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store i32 %t243, ptr %l91
  %t244 = icmp ne i32 %t243, 0
  br i1 %t244, label %bb55, label %ok.245
ok.245:
  br label %bb54
bb53:
  br label %bb57
bb54:
  br label %bb56
bb55:
  %t246 = load i32, ptr %l91, !tbaa !23
  %t247 = lshr i32 %t246, 16
  %t248 = and i32 %t246, 65535
  %t249 = icmp eq i32 %t247, 1
  %t250 = select i1 %t249, i32 1, i32 0
  %t251 = icmp eq i32 %t246, 0
  %t252 = shl i32 %t250, 16
  %t253 = or i32 %t252, %t248
  %t254 = select i1 %t251, i32 0, i32 %t253
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  %t256 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t254, 0
  store { i32, { i64, ptr } } %t256, ptr %rv
  br label %ret
bb56:
  call void @__olang_scope_close(ptr %s14)
  br label %bb57
bb57:
  %t257 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s13)
  store %"std/prelude/text:StringBuilder" %t257, ptr %l93
  br label %bb58
bb58:
  %t258 = load %"std/prelude/text:StringBuilder", ptr %l93
  store %"std/prelude/text:StringBuilder" %t258, ptr %l9
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l9, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb59
bb59:
  store i64 0, ptr %l10, !tbaa !24
  %t260 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 4
  %t261 = load i64, ptr %t260, !tbaa !24
  store i64 %t261, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t263 = load i64, ptr %l11, !tbaa !24
  %t264 = load i64, ptr %l10, !tbaa !24
  %t267 = icmp sgt i64 %t263, %t264
  br i1 %t267, label %bb60, label %bb61
bb60:
  %t269 = load i64, ptr %l12, !tbaa !24
  %t271 = icmp sgt i64 %t269, 0
  br i1 %t271, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb65
bb62:
  %t273 = load i64, ptr %l11, !tbaa !24
  %t274 = load i64, ptr %l10, !tbaa !24
  %t277 = sub i64 %t273, %t274
  %t278 = load i64, ptr %l12, !tbaa !24
  %t281 = add i64 %t277, %t278
  %t283 = sub i64 %t281, 1
  %t284 = load i64, ptr %l12, !tbaa !24
  %t287 = sdiv i64 %t283, %t284
  store i64 %t287, ptr %l102, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb64
bb64:
  %t289 = load i64, ptr %l102, !tbaa !24
  store i64 %t289, ptr %l99, !tbaa !24
  br label %bb65
bb65:
  %t290 = load i64, ptr %l99, !tbaa !24
  store i64 %t290, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s16
  %t291 = load i64, ptr %l14, !tbaa !24
  %t292 = load i64, ptr %l13, !tbaa !24
  %t295 = icmp slt i64 %t291, %t292
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s16)
  br label %bb80
bb68:
  br label %bb69
bb69:
  %t299 = load i64, ptr %l10, !tbaa !24
  %t300 = load i64, ptr %l14, !tbaa !24
  %t301 = load i64, ptr %l12, !tbaa !24
  %t304 = mul i64 %t300, %t301
  %t307 = add i64 %t299, %t304
  store i64 %t307, ptr %l15, !tbaa !24
  %t309 = load i64, ptr %l15, !tbaa !24
  %t311 = icmp sgt i64 %t309, 0
  br i1 %t311, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s17
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s17, ptr %l9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s17)
  br label %bb73
bb73:
  store ptr %l9, ptr %l123, !tbaa !29
  %t314 = load i64, ptr %l15, !tbaa !24
  store i64 %t314, ptr %l124, !tbaa !24
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l126, !tbaa !29
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/bindgen:gen", ptr %t316, i32 0, i32 9
  %t319 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 5
  %t320 = load i64, ptr %t319, !tbaa !24
  %t321 = load i64, ptr %l15, !tbaa !24
  %t324 = add i64 %t320, %t321
  %t327 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t318, i64 %t324)
  store i64 %t327, ptr %l132
  br label %bb74
bb74:
  %t328 = load ptr, ptr %l126, !tbaa !29
  %t329 = load i64, ptr %l132, !tbaa !24
  %t330 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %s16, ptr %t328, i64 %t329, i1 true)
  %t331 = extractvalue { i32, { i64, ptr } } %t330, 1
  %t332 = extractvalue { i32, { i64, ptr } } %t330, 0
  store i32 %t332, ptr %l134
  %t333 = icmp ne i32 %t332, 0
  br i1 %t333, label %bb76, label %ok.334
ok.334:
  store { i64, ptr } %t331, ptr %l133
  br label %bb75
bb75:
  %t335 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t335, ptr %l125, !tbaa !27
  br label %bb77
bb76:
  %t336 = load i32, ptr %l134, !tbaa !23
  %t337 = lshr i32 %t336, 16
  %t338 = and i32 %t336, 65535
  %t339 = icmp eq i32 %t337, 1
  %t340 = select i1 %t339, i32 1, i32 0
  %t341 = icmp eq i32 %t336, 0
  %t342 = shl i32 %t340, 16
  %t343 = or i32 %t342, %t338
  %t344 = select i1 %t341, i32 0, i32 %t343
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s13)
  %t346 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t344, 0
  store { i32, { i64, ptr } } %t346, ptr %rv
  br label %ret
bb77:
  %t347 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t349 = load i64, ptr %l124, !tbaa !24
  %t350 = call i64 @__olang_fmt_i64(ptr null, i64 %t349)
  %t351 = add i64 %t348, %t350
  %t352 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t353 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t354 = add i64 %t351, %t353
  %t355 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t355, 1
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t358 = add i64 %t354, %t357
  %t359 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t358)
  call void @olang_textcopy(ptr %t359, ptr %t347, i64 %t348)
  %t360 = getelementptr i8, ptr %t359, i64 %t348
  %t361 = call i64 @__olang_fmt_i64(ptr %t360, i64 %t349)
  %t362 = getelementptr i8, ptr %t360, i64 %t350
  call void @olang_textcopy(ptr %t362, ptr %t352, i64 %t353)
  %t363 = getelementptr i8, ptr %t362, i64 %t353
  call void @olang_textcopy(ptr %t363, ptr %t356, i64 %t357)
  %t364 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t359, 1
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t368 = extractvalue { i64, ptr } %t365, 1
  %t369 = mul i64 %t367, 1
  %t370 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t370, ptr %t368, i64 %t369, i1 false)
  %t371 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  %t373 = load ptr, ptr %l123, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s16, ptr %t373, { i64, ptr } %t372)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s16)
  br label %bb79
bb79:
  %t375 = load i64, ptr %l14, !tbaa !24
  %t377 = add i64 %t375, 1
  store i64 %t377, ptr %l14, !tbaa !24
  br label %bb66
bb80:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb81
bb81:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/bindgen:gen", ptr %t380, i32 0, i32 8
  %t383 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t384 = load i64, ptr %t383, !tbaa !24
  %t387 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s13, ptr %t382, i64 %t384)
  store %"compiler/bindgen:ctype" %t387, ptr %l144
  br label %bb82
bb82:
  %t388 = getelementptr %"compiler/bindgen:ctype", ptr %l144, i32 0, i32 0
  %t389 = load i32, ptr %t388
  %t391 = trunc i64 0 to i32
  %t392 = icmp eq i32 %t389, %t391
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s20
  store ptr %l9, ptr %l148, !tbaa !29
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t398 = load i64, ptr %t397, !tbaa !24
  %t401 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %s20, ptr %t396, i64 %t398, i1 true)
  %t402 = extractvalue { i32, { i64, ptr } } %t401, 1
  %t403 = extractvalue { i32, { i64, ptr } } %t401, 0
  store i32 %t403, ptr %l153
  %t404 = icmp ne i32 %t403, 0
  br i1 %t404, label %bb86, label %ok.405
ok.405:
  store { i64, ptr } %t402, ptr %l152
  br label %bb85
bb84:
  br label %bb89
bb85:
  %t406 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t406, ptr %l149, !tbaa !27
  br label %bb87
bb86:
  %t407 = load i32, ptr %l153, !tbaa !23
  %t408 = lshr i32 %t407, 16
  %t409 = and i32 %t407, 65535
  %t410 = icmp eq i32 %t408, 1
  %t411 = select i1 %t410, i32 1, i32 0
  %t412 = icmp eq i32 %t407, 0
  %t413 = shl i32 %t411, 16
  %t414 = or i32 %t413, %t409
  %t415 = select i1 %t412, i32 0, i32 %t414
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s13)
  %t417 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t415, 0
  store { i32, { i64, ptr } } %t417, ptr %rv
  br label %ret
bb87:
  %t418 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t420 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t421 = extractvalue { i64, ptr } %t420, 1
  %t422 = extractvalue { i64, ptr } %t420, 0
  %t423 = add i64 %t419, %t422
  %t424 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t423)
  call void @olang_textcopy(ptr %t424, ptr %t418, i64 %t419)
  %t425 = getelementptr i8, ptr %t424, i64 %t419
  call void @olang_textcopy(ptr %t425, ptr %t421, i64 %t422)
  %t426 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t424, 1
  %t429 = extractvalue { i64, ptr } %t427, 0
  %t430 = extractvalue { i64, ptr } %t427, 1
  %t431 = mul i64 %t429, 1
  %t432 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t431)
  call void @llvm.memcpy.p0.p0.i64(ptr %t432, ptr %t430, i64 %t431, i1 false)
  %t433 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t434 = insertvalue { i64, ptr } %t433, ptr %t432, 1
  %t435 = load ptr, ptr %l148, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s20, ptr %t435, { i64, ptr } %t434)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s20)
  br label %bb89
bb89:
  %t438 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s13, ptr %v1, ptr %l9)
  store { i64, ptr } %t438, ptr %l158
  br label %bb90
bb90:
  %t439 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t439, ptr %l159, !tbaa !27
  %t440 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t440, 0
  store i64 %t441, ptr %l160, !tbaa !24
  %t442 = load i64, ptr %l160, !tbaa !24
  %t443 = mul i64 %t442, 1
  %t444 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t443)
  %t445 = insertvalue { i64, ptr } undef, i64 %t442, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr %t444, 1
  store { i64, ptr } %t446, ptr %l161, !tbaa !27
  %t447 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !27
  %t451 = load i64, ptr %l160, !tbaa !24
  %t452 = mul i64 %t451, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t448, ptr %t450, i64 %t452, i1 false)
  %t453 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t453, ptr %l159, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  %t454 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t455 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t454, 1
  store { i32, { i64, ptr } } %t455, ptr %rv
  br label %ret
bb91:
  %t456 = load i32, ptr %l4
  %t458 = trunc i64 6 to i32
  %t459 = icmp eq i32 %t456, %t458
  br i1 %t459, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb98
bb94:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  %t466 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t461, { i64, ptr } %t463)
  store i32 %t466, ptr %l166
  %t467 = icmp ne i32 %t466, 0
  br i1 %t467, label %bb96, label %ok.468
ok.468:
  br label %bb95
bb95:
  br label %bb97
bb96:
  %t469 = load i32, ptr %l166, !tbaa !23
  %t470 = lshr i32 %t469, 16
  %t471 = and i32 %t469, 65535
  %t472 = icmp eq i32 %t470, 1
  %t473 = select i1 %t472, i32 1, i32 0
  %t474 = icmp eq i32 %t469, 0
  %t475 = shl i32 %t473, 16
  %t476 = or i32 %t475, %t471
  %t477 = select i1 %t474, i32 0, i32 %t476
  %t479 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t477, 0
  store { i32, { i64, ptr } } %t479, ptr %rv
  br label %ret
bb97:
  br label %bb103
bb98:
  br i1 true, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_55ef846781ac27aa_5519550b25564c26)
  unreachable
bb103:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evoidRef(ptr %v0, ptr %v1, ptr %t480)
  store { i64, ptr } %t482, ptr %l169
  br label %bb104
bb104:
  %t483 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t484 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t483, 1
  store { i32, { i64, ptr } } %t484, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca %"compiler/bindgen:record"
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l39 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l73 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l87 = alloca i1
  %l89 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l114 = alloca i64
  %l116 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca i32
  %l124 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i1
  %l129 = alloca i1
  %l143 = alloca %"compiler/bindgen:record"
  %l152 = alloca i1
  %l159 = alloca i1
  %l163 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l177 = alloca i1
  %l180 = alloca { i64, ptr }
  %l182 = alloca i1
  %l184 = alloca i64
  %l185 = alloca { i64, ptr }
  %l186 = alloca i64
  %l187 = alloca i32
  %l188 = alloca i64
  %l189 = alloca i32
  %l191 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l201 = alloca i1
  %l202 = alloca i1
  %l205 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l208 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l222 = alloca i1
  %l223 = alloca ptr
  %l225 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l232 = alloca i1
  %l233 = alloca i1
  %l235 = alloca i1
  %l237 = alloca ptr
  %l240 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l247 = alloca %"compiler/bindgen:cFunc"
  %l249 = alloca i1
  %l250 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %v1, ptr %s1, ptr %a1)
  store { i64, ptr } %t3, ptr %l39
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 8
  %t8 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb138
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l47, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 %t25
  %t30 = load ptr, ptr %t29, !tbaa !39
  store ptr %t30, ptr %l6, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = call ptr @compiler_2fbindgen_2emember(ptr %s1, ptr %s2, ptr %t32, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store ptr %t34, ptr %l51
  br label %bb6
bb6:
  %t35 = load ptr, ptr %l51, !tbaa !29
  store ptr %t35, ptr %l7, !tbaa !29
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %s1, ptr %v2, ptr %t42, ptr %t43, { i64, ptr } %t44)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/bindgen:gen", ptr %t48, i32 0, i32 14
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l8, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s4
  %t53 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t54 = insertvalue [3 x { i64, ptr }] %t53, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t55 = insertvalue [3 x { i64, ptr }] %t54, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d113, i32 0, i32 1) }, 2
  %t57 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 48, i64 8)
  store [3 x { i64, ptr }] %t55, ptr %t57
  store ptr %t57, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t59 = load ptr, ptr %l9
  store i64 3, ptr %l11, !tbaa !24
  br label %bb11
bb11:
  %t62 = load i64, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l11, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t70 = load ptr, ptr %l9
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = getelementptr [3 x { i64, ptr }], ptr %t70, i64 0, i64 %t71
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !37
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = load ptr, ptr @__olang_prog_scope
  %t82 = call ptr @compiler_2fbindgen_2emember(ptr %s1, ptr %t79, ptr %t77, { i64, ptr } %t75)
  store ptr %t82, ptr %l73
  br label %bb15
bb15:
  %t83 = load ptr, ptr %l73, !tbaa !29
  store ptr %t83, ptr %l13, !tbaa !29
  %t84 = load ptr, ptr %l13, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb16, label %bb17
bb16:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l13, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %s1, ptr %v2, ptr %t90, ptr %t91, { i64, ptr } %t92)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t96 = load i64, ptr %l10, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l10, !tbaa !24
  br label %bb11
bb21:
  call void @__olang_scope_close(ptr %s4)
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t102 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s2, ptr %s2, ptr %t100, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d114, i32 0, i32 1) })
  store { i64, ptr } %t102, ptr %l83
  br label %bb22
bb22:
  %t103 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t103, ptr %l14, !tbaa !27
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s2, ptr %s2, ptr %t104, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d115, i32 0, i32 1) })
  store { i64, ptr } %t106, ptr %l85
  br label %bb23
bb23:
  %t107 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t107, ptr %l15, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t110 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t108, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d116, i32 0, i32 1) })
  store i1 %t110, ptr %l87
  br label %bb24
bb24:
  %t111 = load i1, ptr %l87, !tbaa !21
  br i1 %t111, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t114 = call { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %s1, ptr %s8, ptr %t112)
  store { i64, ptr } %t114, ptr %l89
  br label %bb27
bb26:
  br label %bb59
bb27:
  %t115 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t115, ptr %l16, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/bindgen:gen", ptr %t116, i32 0, i32 1
  %t119 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = extractvalue { i64, ptr } %t119, 0
  %t123 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t121, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  %t133 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = extractvalue { i64, ptr } %t133, 0
  %t137 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t135, i64 %t136)
  %t138 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = extractvalue { i64, ptr } %t139, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t118, { i64, ptr } %t132, { i64, ptr } %t146)
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s11
  %t150 = load ptr, ptr %l6, !tbaa !29
  %t152 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s1, ptr %s11, ptr %t150)
  store { i64, ptr } %t152, ptr %l99
  br label %bb29
bb29:
  %t153 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = mul i64 %t154, 8
  %t157 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  store i64 %t163, ptr %l19, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s12
  %t165 = load i64, ptr %l18, !tbaa !24
  %t166 = load i64, ptr %l19, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s12)
  br label %bb58
bb32:
  br label %bb33
bb33:
  %t173 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t173, ptr %l107, !tbaa !27
  %t174 = load i64, ptr %l18, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr ptr, ptr %t177, i64 %t174
  %t179 = load ptr, ptr %t178, !tbaa !39
  %t183 = call ptr @compiler_2fbindgen_2emember(ptr %s11, ptr %s12, ptr %t179, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d117, i32 0, i32 1) })
  store ptr %t183, ptr %l111
  br label %bb34
bb34:
  %t184 = load ptr, ptr %l111, !tbaa !29
  store ptr %t184, ptr %l21, !tbaa !29
  %t185 = load ptr, ptr %l21, !tbaa !29
  %t187 = icmp eq ptr %t185, null
  br i1 %t187, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s12)
  br label %bb57
bb36:
  br label %bb37
bb37:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/bindgen:gen", ptr %t189, i32 0, i32 4
  store ptr %t191, ptr %l116, !tbaa !29
  %t192 = load ptr, ptr %l21, !tbaa !29
  %t194 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s11, ptr %s12, ptr %s12, ptr %t192, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d118, i32 0, i32 1) })
  store { i64, ptr } %t194, ptr %l118
  br label %bb38
bb38:
  %t195 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  %t197 = extractvalue { i64, ptr } %t195, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  %t202 = load ptr, ptr %l116, !tbaa !29
  %t204 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %s12, ptr %t202, { i64, ptr } %t201)
  %t205 = extractvalue { i32, i64 } %t204, 1
  %t206 = extractvalue { i32, i64 } %t204, 0
  store i32 %t206, ptr %l121
  %t207 = icmp ne i32 %t206, 0
  br i1 %t207, label %bb40, label %ok.208
ok.208:
  store i64 %t205, ptr %l120
  br label %bb39
bb39:
  %t209 = load i64, ptr %l120, !tbaa !24
  store i64 %t209, ptr %l114, !tbaa !24
  br label %bb42
bb40:
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l114, !tbaa !24
  br label %bb42
bb42:
  %t210 = load i64, ptr %l114, !tbaa !24
  store i64 %t210, ptr %l22, !tbaa !24
  %t211 = load i64, ptr %l22, !tbaa !24
  %t213 = icmp sge i64 %t211, 0
  br i1 %t213, label %bb43, label %bb44
bb43:
  %t215 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t217 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s8, ptr %s12, { i64, ptr } %t215, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d119, i32 0, i32 1) })
  store i1 %t217, ptr %l126
  br label %bb45
bb44:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb50
bb45:
  %t218 = load i1, ptr %l126, !tbaa !21
  br i1 %t218, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb49
bb47:
  %t219 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t221 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s8, ptr %s12, { i64, ptr } %t219, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d120, i32 0, i32 1) })
  store i1 %t221, ptr %l129
  br label %bb48
bb48:
  %t222 = load i1, ptr %l129, !tbaa !21
  store i1 %t222, ptr %l127, !tbaa !21
  br label %bb49
bb49:
  %t223 = load i1, ptr %l127, !tbaa !21
  store i1 %t223, ptr %l124, !tbaa !21
  br label %bb50
bb50:
  %t224 = load i1, ptr %l124, !tbaa !21
  br i1 %t224, label %bb51, label %bb52
bb51:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/bindgen:gen", ptr %t225, i32 0, i32 3
  %t228 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 1
  %t231 = extractvalue { i64, ptr } %t228, 0
  %t232 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t231)
  call void @olang_textcopy(ptr %t232, ptr %t230, i64 %t231)
  %t233 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  %t236 = extractvalue { i64, ptr } %t234, 0
  %t237 = extractvalue { i64, ptr } %t234, 1
  %t238 = mul i64 %t236, 1
  %t239 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t238)
  call void @llvm.memcpy.p0.p0.i64(ptr %t239, ptr %t237, i64 %t238, i1 false)
  %t240 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  %t242 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t227, { i64, ptr } %t241, i64 %t242)
  br label %bb53
bb52:
  br label %bb56
bb53:
  %t246 = load i64, ptr %l22, !tbaa !24
  store i64 %t246, ptr %l23, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t248, 1
  %t251 = extractvalue { i64, ptr } %t248, 0
  %t252 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t251)
  call void @olang_textcopy(ptr %t252, ptr %t250, i64 %t251)
  %t253 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t252, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = extractvalue { i64, ptr } %t254, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  store { i64, ptr } %t261, ptr %l24, !tbaa !27
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/bindgen:gen", ptr %t263, i32 0, i32 2
  %t266 = load i64, ptr %l23, !tbaa !24
  %t269 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t265, i64 %t266)
  store %"compiler/bindgen:record" %t269, ptr %l143
  br label %bb54
bb54:
  %t270 = load %"compiler/bindgen:record", ptr %l143
  store %"compiler/bindgen:record" %t270, ptr %l25
  %t271 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t273 = getelementptr %"compiler/bindgen:record", ptr %l25, i32 0, i32 0
  store { i64, ptr } %t271, ptr %t273, !tbaa !27
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/bindgen:gen", ptr %t274, i32 0, i32 2
  %t277 = load i64, ptr %l23, !tbaa !24
  %t278 = load %"compiler/bindgen:record", ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v0, ptr %t276, i64 %t277, %"compiler/bindgen:record" %t278)
  br label %bb55
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s12)
  br label %bb57
bb57:
  %t282 = load i64, ptr %l18, !tbaa !24
  %t284 = add i64 %t282, 1
  store i64 %t284, ptr %l18, !tbaa !24
  br label %bb30
bb58:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s2)
  br label %bb137
bb59:
  %t286 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t288 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t286, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d121, i32 0, i32 1) })
  store i1 %t288, ptr %l152
  br label %bb60
bb60:
  %t289 = load i1, ptr %l152, !tbaa !21
  br i1 %t289, label %bb61, label %bb62
bb61:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load ptr, ptr %l6, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t293 = load i64, ptr %l8, !tbaa !24
  %t295 = icmp eq i64 %t293, 1
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordDecl(ptr %v0, ptr %s1, ptr %s2, ptr %t290, ptr %t291, { i64, ptr } %t292, i1 %t295)
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_scope_close(ptr %s2)
  br label %bb137
bb64:
  %t300 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t302 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t300, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store i1 %t302, ptr %l159
  br label %bb65
bb65:
  %t303 = load i1, ptr %l159, !tbaa !21
  br i1 %t303, label %bb66, label %bb67
bb66:
  %t304 = load i64, ptr %l8, !tbaa !24
  %t306 = icmp ne i64 %t304, 1
  br i1 %t306, label %bb68, label %bb69
bb67:
  br label %bb96
bb68:
  call void @__olang_scope_close(ptr %s2)
  br label %bb137
bb69:
  br label %bb70
bb70:
  store i64 0, ptr %l26, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s21
  %t308 = load ptr, ptr %l6, !tbaa !29
  %t310 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s1, ptr %s21, ptr %t308)
  store { i64, ptr } %t310, ptr %l163
  br label %bb71
bb71:
  %t311 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  %t313 = extractvalue { i64, ptr } %t311, 1
  %t314 = mul i64 %t312, 8
  %t315 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t314)
  call void @llvm.memcpy.p0.p0.i64(ptr %t315, ptr %t313, i64 %t314, i1 false)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t315, 1
  store { i64, ptr } %t317, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t319 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t319, 0
  store i64 %t321, ptr %l29, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s22
  %t323 = load i64, ptr %l28, !tbaa !24
  %t324 = load i64, ptr %l29, !tbaa !24
  %t327 = icmp slt i64 %t323, %t324
  %t329 = xor i1 %t327, true
  br i1 %t329, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s22)
  br label %bb95
bb74:
  br label %bb75
bb75:
  %t331 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t331, ptr %l171, !tbaa !27
  %t332 = load i64, ptr %l28, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr ptr, ptr %t335, i64 %t332
  %t337 = load ptr, ptr %t336, !tbaa !39
  store ptr %t337, ptr %l30, !tbaa !29
  %t339 = load ptr, ptr %l30, !tbaa !29
  %t341 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s21, ptr %s22, ptr %s22, ptr %t339, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d123, i32 0, i32 1) })
  store { i64, ptr } %t341, ptr %l175
  br label %bb76
bb76:
  %t342 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t342, 0
  %t344 = extractvalue { i64, ptr } %t342, 1
  %t345 = mul i64 %t343, 1
  %t346 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t345)
  call void @llvm.memcpy.p0.p0.i64(ptr %t346, ptr %t344, i64 %t345, i1 false)
  %t347 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  %t350 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s22, ptr %s22, { i64, ptr } %t348, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d124, i32 0, i32 1) })
  store i1 %t350, ptr %l177
  br label %bb77
bb77:
  %t351 = load i1, ptr %l177, !tbaa !21
  %t352 = xor i1 %t351, true
  br i1 %t352, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s22)
  br label %bb94
bb79:
  br label %bb80
bb80:
  %t354 = load ptr, ptr %l30, !tbaa !29
  %t356 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s21, ptr %s22, ptr %t354)
  store { i64, ptr } %t356, ptr %l180
  br label %bb81
bb81:
  %t357 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t357, ptr %l31, !tbaa !27
  %t358 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t360 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s22, ptr %s22, { i64, ptr } %t358, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d125, i32 0, i32 1) })
  store i1 %t360, ptr %l182
  br label %bb82
bb82:
  %t361 = load i1, ptr %l182, !tbaa !21
  %t362 = xor i1 %t361, true
  br i1 %t362, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s24
  %t364 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t364, ptr %l185, !tbaa !27
  %t365 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s24, i64 10)
  %t366 = extractvalue { i32, i64 } %t365, 1
  %t367 = extractvalue { i32, i64 } %t365, 0
  store i32 %t367, ptr %l187
  %t368 = icmp ne i32 %t367, 0
  br i1 %t368, label %bb86, label %ok.369
ok.369:
  store i64 %t366, ptr %l186
  br label %bb85
bb84:
  br label %bb91
bb85:
  %t370 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t371 = load i64, ptr %l186, !tbaa !24
  %t372 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s22, { i64, ptr } %t370, i64 %t371)
  %t373 = extractvalue { i32, i64 } %t372, 1
  %t374 = extractvalue { i32, i64 } %t372, 0
  store i32 %t374, ptr %l189
  %t375 = icmp ne i32 %t374, 0
  br i1 %t375, label %bb89, label %ok.376
ok.376:
  store i64 %t373, ptr %l188
  br label %bb88
bb86:
  br label %bb87
bb87:
  call void @__olang_ert_req_clear()
  %t377 = load i64, ptr %l26, !tbaa !24
  store i64 %t377, ptr %l184, !tbaa !24
  br label %bb90
bb88:
  %t379 = load i64, ptr %l188, !tbaa !24
  store i64 %t379, ptr %l184, !tbaa !24
  br label %bb90
bb89:
  br label %bb87
bb90:
  %t380 = load i64, ptr %l184, !tbaa !24
  store i64 %t380, ptr %l26, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb91
bb91:
  %t381 = load ptr, ptr %l0, !tbaa !29
  store ptr %t381, ptr %l191, !tbaa !29
  %t382 = load ptr, ptr %l30, !tbaa !29
  %t384 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s21, ptr %s22, ptr %s22, ptr %t382, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) })
  store { i64, ptr } %t384, ptr %l193
  br label %bb92
bb92:
  %t385 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t385, 0
  %t387 = extractvalue { i64, ptr } %t385, 1
  %t388 = mul i64 %t386, 1
  %t389 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t388)
  call void @llvm.memcpy.p0.p0.i64(ptr %t389, ptr %t387, i64 %t388, i1 false)
  %t390 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  %t392 = load i64, ptr %l26, !tbaa !24
  %t393 = load ptr, ptr %l191, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %v0, ptr %s22, ptr %t393, { i64, ptr } %t391, i64 %t392)
  br label %bb93
bb93:
  %t396 = load i64, ptr %l26, !tbaa !24
  %t398 = add i64 %t396, 1
  store i64 %t398, ptr %l26, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb94
bb94:
  %t400 = load i64, ptr %l28, !tbaa !24
  %t402 = add i64 %t400, 1
  store i64 %t402, ptr %l28, !tbaa !24
  br label %bb72
bb95:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s2)
  br label %bb137
bb96:
  %t404 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t406 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t404, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d127, i32 0, i32 1) })
  store i1 %t406, ptr %l201
  br label %bb97
bb97:
  %t407 = load i1, ptr %l201, !tbaa !21
  br i1 %t407, label %bb98, label %bb99
bb98:
  %t408 = load i64, ptr %l8, !tbaa !24
  %t410 = icmp eq i64 %t408, 1
  store i1 %t410, ptr %l202, !tbaa !21
  br label %bb100
bb99:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb100
bb100:
  %t412 = load i1, ptr %l202, !tbaa !21
  br i1 %t412, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s26
  %t413 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t413, ptr %l205
  br label %bb103
bb102:
  br label %bb128
bb103:
  %t414 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l205
  %t415 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t414, ptr %t415
  store ptr %t415, ptr %l32, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s27
  %t417 = load ptr, ptr %l6, !tbaa !29
  %t419 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s1, ptr %s27, ptr %t417)
  store { i64, ptr } %t419, ptr %l208
  br label %bb104
bb104:
  %t420 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t421 = extractvalue { i64, ptr } %t420, 0
  %t422 = extractvalue { i64, ptr } %t420, 1
  %t423 = mul i64 %t421, 8
  %t424 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t423)
  call void @llvm.memcpy.p0.p0.i64(ptr %t424, ptr %t422, i64 %t423, i1 false)
  %t425 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t424, 1
  store { i64, ptr } %t426, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t428 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t428, 0
  store i64 %t430, ptr %l35, !tbaa !24
  br label %bb105
bb105:
  store %olang.scope zeroinitializer, ptr %s28
  %t432 = load i64, ptr %l34, !tbaa !24
  %t433 = load i64, ptr %l35, !tbaa !24
  %t436 = icmp slt i64 %t432, %t433
  %t438 = xor i1 %t436, true
  br i1 %t438, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s28)
  br label %bb117
bb107:
  br label %bb108
bb108:
  %t440 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t440, ptr %l216, !tbaa !27
  %t441 = load i64, ptr %l34, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr ptr, ptr %t444, i64 %t441
  %t446 = load ptr, ptr %t445, !tbaa !39
  store ptr %t446, ptr %l36, !tbaa !29
  %t448 = load ptr, ptr %l36, !tbaa !29
  %t450 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s27, ptr %s28, ptr %s28, ptr %t448, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d128, i32 0, i32 1) })
  store { i64, ptr } %t450, ptr %l220
  br label %bb109
bb109:
  %t451 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 0
  %t453 = extractvalue { i64, ptr } %t451, 1
  %t454 = mul i64 %t452, 1
  %t455 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t454)
  call void @llvm.memcpy.p0.p0.i64(ptr %t455, ptr %t453, i64 %t454, i1 false)
  %t456 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t457 = insertvalue { i64, ptr } %t456, ptr %t455, 1
  %t459 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s28, ptr %s28, { i64, ptr } %t457, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d129, i32 0, i32 1) })
  store i1 %t459, ptr %l222
  br label %bb110
bb110:
  %t460 = load i1, ptr %l222, !tbaa !21
  br i1 %t460, label %bb111, label %bb112
bb111:
  %t461 = load ptr, ptr %l32, !tbaa !29
  store ptr %t461, ptr %l223, !tbaa !29
  %t462 = load ptr, ptr %l36, !tbaa !29
  %t464 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s27, ptr %v0, ptr %v0, ptr %t462, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d130, i32 0, i32 1) })
  store { i64, ptr } %t464, ptr %l225
  br label %bb113
bb112:
  br label %bb115
bb113:
  %t465 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 0
  %t467 = extractvalue { i64, ptr } %t465, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  %t472 = load ptr, ptr %l223, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t472, { i64, ptr } %t471)
  br label %bb114
bb114:
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s28)
  br label %bb116
bb116:
  %t474 = load i64, ptr %l34, !tbaa !24
  %t476 = add i64 %t474, 1
  store i64 %t476, ptr %l34, !tbaa !24
  br label %bb105
bb117:
  call void @__olang_scope_close(ptr %s27)
  %t478 = load ptr, ptr %l6, !tbaa !29
  %t480 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s26, ptr %s26, ptr %t478, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d131, i32 0, i32 1) })
  store { i64, ptr } %t480, ptr %l230
  br label %bb118
bb118:
  %t481 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t481, 0
  %t483 = extractvalue { i64, ptr } %t481, 1
  %t484 = mul i64 %t482, 1
  %t485 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t484)
  call void @llvm.memcpy.p0.p0.i64(ptr %t485, ptr %t483, i64 %t484, i1 false)
  %t486 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t485, 1
  %t489 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s26, ptr %s26, { i64, ptr } %t487, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d132, i32 0, i32 1) })
  store i1 %t489, ptr %l232
  br label %bb119
bb119:
  %t490 = load i1, ptr %l232, !tbaa !21
  br i1 %t490, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l233, !tbaa !21
  br label %bb123
bb121:
  %t491 = load ptr, ptr %l6, !tbaa !29
  %t493 = call i1 @compiler_2fbindgen_2eflag(ptr %s1, ptr %s26, ptr %t491, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d133, i32 0, i32 1) })
  store i1 %t493, ptr %l235
  br label %bb122
bb122:
  %t494 = load i1, ptr %l235, !tbaa !21
  store i1 %t494, ptr %l233, !tbaa !21
  br label %bb123
bb123:
  %t495 = load i1, ptr %l233, !tbaa !21
  store i1 %t495, ptr %l37, !tbaa !21
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/bindgen:gen", ptr %t496, i32 0, i32 5
  store ptr %t498, ptr %l237, !tbaa !29
  %t499 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t501 = extractvalue { i64, ptr } %t499, 1
  %t502 = extractvalue { i64, ptr } %t499, 0
  %t503 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t502)
  call void @olang_textcopy(ptr %t503, ptr %t501, i64 %t502)
  %t504 = insertvalue { i64, ptr } undef, i64 %t502, 0
  %t505 = insertvalue { i64, ptr } %t504, ptr %t503, 1
  %t507 = extractvalue { i64, ptr } %t505, 0
  %t508 = extractvalue { i64, ptr } %t505, 1
  %t509 = mul i64 %t507, 1
  %t510 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t509)
  call void @llvm.memcpy.p0.p0.i64(ptr %t510, ptr %t508, i64 %t509, i1 false)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t510, 1
  store { i64, ptr } %t512, ptr %l240, !tbaa !27
  %t513 = load ptr, ptr %l6, !tbaa !29
  %t515 = call { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %s1, ptr %v0, ptr %t513)
  store { i64, ptr } %t515, ptr %l242
  br label %bb124
bb124:
  %t516 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t516, 0
  %t518 = extractvalue { i64, ptr } %t516, 1
  %t519 = mul i64 %t517, 1
  %t520 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t519)
  call void @llvm.memcpy.p0.p0.i64(ptr %t520, ptr %t518, i64 %t519, i1 false)
  %t521 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t520, 1
  store { i64, ptr } %t522, ptr %l243, !tbaa !27
  %t523 = load ptr, ptr %l32, !tbaa !29
  %t525 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %t523)
  store { i64, ptr } %t525, ptr %l245
  br label %bb125
bb125:
  %t526 = load i1, ptr %l37, !tbaa !21
  %t527 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t528 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t529 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t531 = call %"compiler/bindgen:cFunc" @compiler_2fbindgen_3acFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t527, { i64, ptr } %t528, { i64, ptr } %t529, i1 %t526)
  store %"compiler/bindgen:cFunc" %t531, ptr %l247
  br label %bb126
bb126:
  %t532 = load ptr, ptr %l237, !tbaa !29
  %t533 = load %"compiler/bindgen:cFunc", ptr %l247
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ePush_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t532, %"compiler/bindgen:cFunc" %t533)
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s2)
  br label %bb137
bb128:
  %t534 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t536 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t534, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d134, i32 0, i32 1) })
  store i1 %t536, ptr %l249
  br label %bb129
bb129:
  %t537 = load i1, ptr %l249, !tbaa !21
  br i1 %t537, label %bb130, label %bb131
bb130:
  %t538 = load i64, ptr %l8, !tbaa !24
  %t540 = icmp eq i64 %t538, 1
  store i1 %t540, ptr %l250, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l250, !tbaa !21
  br label %bb132
bb132:
  %t542 = load i1, ptr %l250, !tbaa !21
  br i1 %t542, label %bb133, label %bb134
bb133:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t545 = getelementptr %"compiler/bindgen:gen", ptr %t543, i32 0, i32 10
  %t546 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t546, 1
  %t549 = extractvalue { i64, ptr } %t546, 0
  %t550 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t551 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t552 = add i64 %t549, %t551
  %t553 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t552)
  call void @olang_textcopy(ptr %t553, ptr %t548, i64 %t549)
  %t554 = getelementptr i8, ptr %t553, i64 %t549
  call void @olang_textcopy(ptr %t554, ptr %t550, i64 %t551)
  %t555 = insertvalue { i64, ptr } undef, i64 %t552, 0
  %t556 = insertvalue { i64, ptr } %t555, ptr %t553, 1
  %t558 = extractvalue { i64, ptr } %t556, 0
  %t559 = extractvalue { i64, ptr } %t556, 1
  %t560 = mul i64 %t558, 1
  %t561 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t560)
  call void @llvm.memcpy.p0.p0.i64(ptr %t561, ptr %t559, i64 %t560, i1 false)
  %t562 = insertvalue { i64, ptr } undef, i64 %t558, 0
  %t563 = insertvalue { i64, ptr } %t562, ptr %t561, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t545, { i64, ptr } %t563)
  br label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s2)
  br label %bb137
bb137:
  %t566 = load i64, ptr %l4, !tbaa !24
  %t568 = add i64 %t566, 1
  store i64 %t568, ptr %l4, !tbaa !24
  br label %bb2
bb138:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca %"compiler/bindgen:record"
  %l8 = alloca i64
  %l13 = alloca %"compiler/bindgen:record"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i1 true, ptr %l4, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:gen", ptr %t9, i32 0, i32 2
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store %"compiler/bindgen:record" %t15, ptr %l13
  br label %bb2
bb2:
  %t16 = load %"compiler/bindgen:record", ptr %l13
  store %"compiler/bindgen:record" %t16, ptr %l5
  %t17 = load i1, ptr %l4, !tbaa !21
  %t19 = getelementptr %"compiler/bindgen:record", ptr %l5, i32 0, i32 8
  store i1 %t17, ptr %t19, !tbaa !21
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/bindgen:gen", ptr %t20, i32 0, i32 2
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load %"compiler/bindgen:record", ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v0, ptr %t22, i64 %t23, %"compiler/bindgen:record" %t24)
  br label %bb3
bb3:
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l13 = alloca ptr
  %l17 = alloca %"compiler/bindgen:record"
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l29 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/bindgen:gen", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = call %"compiler/bindgen:record" @compiler_2fbindgen_3arecord_2ector(ptr %v0, ptr %v0, { i64, ptr } %t36)
  store %"compiler/bindgen:record" %t38, ptr %l17
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l13, !tbaa !29
  %t40 = load %"compiler/bindgen:record", ptr %l17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ePush_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t39, %"compiler/bindgen:record" %t40)
  br label %bb9
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/bindgen:gen", ptr %t41, i32 0, i32 3
  store ptr %t43, ptr %l19, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l22, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/bindgen:gen", ptr %t58, i32 0, i32 2
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l25
  br label %bb10
bb10:
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = sub i64 %t63, 1
  %t65 = load ptr, ptr %l19, !tbaa !29
  %t66 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t65, { i64, ptr } %t66, i64 %t64)
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/bindgen:gen", ptr %t68, i32 0, i32 2
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t70)
  store i64 %t72, ptr %l29
  br label %bb12
bb12:
  %t73 = load i64, ptr %l29, !tbaa !24
  %t74 = sub i64 %t73, 1
  store i64 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/bindgen:record"
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca %"compiler/bindgen:record"
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca %"compiler/bindgen:record"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca %"compiler/bindgen:record"
  %l23 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca %"compiler/bindgen:record"
  %l33 = alloca i64
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l47 = alloca i64
  %l52 = alloca %"compiler/bindgen:record"
  %l63 = alloca %"compiler/bindgen:record"
  %l70 = alloca i1
  %l72 = alloca i1
  %l76 = alloca %"compiler/bindgen:record"
  %l82 = alloca %"compiler/bindgen:record"
  %l89 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l111 = alloca i1
  %l114 = alloca i1
  %l119 = alloca %"compiler/bindgen:record"
  %l128 = alloca %"compiler/bindgen:record"
  %l129 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l136 = alloca %"compiler/bindgen:record"
  %l137 = alloca ptr
  %l139 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %v1, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d136, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d137, i32 0, i32 1) })
  store i1 %t12, ptr %l25
  br label %bb2
bb2:
  %t13 = load i1, ptr %l25, !tbaa !21
  store i1 %t13, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d138, i32 0, i32 1) })
  store i1 %t16, ptr %l27
  br label %bb3
bb3:
  %t17 = load i1, ptr %l27, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/bindgen:gen", ptr %t18, i32 0, i32 2
  store ptr %t20, ptr %l29, !tbaa !29
  %t21 = call %"compiler/bindgen:record" @compiler_2fbindgen_3arecord_2ector(ptr %v0, ptr %v0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d139, i32 0, i32 1) })
  store %"compiler/bindgen:record" %t21, ptr %l30
  br label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l41, !tbaa !29
  %t23 = load i1, ptr %l4, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb6:
  %t25 = load ptr, ptr %l29, !tbaa !29
  %t26 = load %"compiler/bindgen:record", ptr %l30
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ePush_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t25, %"compiler/bindgen:record" %t26)
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/bindgen:gen", ptr %t27, i32 0, i32 2
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l33
  br label %bb8
bb8:
  %t32 = load i64, ptr %l33, !tbaa !24
  %t33 = sub i64 %t32, 1
  store i64 %t33, ptr %l5, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/bindgen:gen", ptr %t35, i32 0, i32 4
  store ptr %t37, ptr %l36, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %v1, ptr %v0, ptr %v0, ptr %t38, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d140, i32 0, i32 1) })
  store { i64, ptr } %t40, ptr %l38
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t49, { i64, ptr } %t47, i64 %t48)
  br label %bb10
bb10:
  br label %bb15
bb11:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d141, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb13
bb12:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d142, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = extractvalue { i64, ptr } %t52, 1
  %t58 = extractvalue { i64, ptr } %t52, 0
  %t59 = add i64 %t55, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t54, i64 %t55)
  %t61 = getelementptr i8, ptr %t60, i64 %t55
  call void @olang_textcopy(ptr %t61, ptr %t57, i64 %t58)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } %t63, 1
  %t67 = mul i64 %t65, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t67)
  call void @llvm.memcpy.p0.p0.i64(ptr %t68, ptr %t66, i64 %t67, i1 false)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t73 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %s2, ptr %t71, { i64, ptr } %t70)
  store i64 %t73, ptr %l47
  br label %bb14
bb14:
  %t74 = load i64, ptr %l47, !tbaa !24
  store i64 %t74, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t75 = load i64, ptr %l5, !tbaa !24
  store i64 %t75, ptr %l6, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/bindgen:gen", ptr %t77, i32 0, i32 2
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store %"compiler/bindgen:record" %t83, ptr %l52
  br label %bb16
bb16:
  %t84 = load %"compiler/bindgen:record", ptr %l52
  store %"compiler/bindgen:record" %t84, ptr %l7
  %t85 = load i1, ptr %l4, !tbaa !21
  %t87 = getelementptr %"compiler/bindgen:record", ptr %l7, i32 0, i32 1
  store i1 %t85, ptr %t87, !tbaa !21
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/bindgen:gen", ptr %t88, i32 0, i32 2
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load %"compiler/bindgen:record", ptr %l7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v0, ptr %t90, i64 %t91, %"compiler/bindgen:record" %t92)
  br label %bb17
bb17:
  %t96 = load i1, ptr %l3, !tbaa !21
  br i1 %t96, label %bb18, label %bb19
bb18:
  %t98 = load i64, ptr %l5, !tbaa !24
  store i64 %t98, ptr %l8, !tbaa !24
  store i1 true, ptr %l9, !tbaa !21
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/bindgen:gen", ptr %t100, i32 0, i32 2
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t102, i64 %t103)
  store %"compiler/bindgen:record" %t106, ptr %l63
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t107 = load %"compiler/bindgen:record", ptr %l63
  store %"compiler/bindgen:record" %t107, ptr %l10
  %t108 = load i1, ptr %l9, !tbaa !21
  %t110 = getelementptr %"compiler/bindgen:record", ptr %l10, i32 0, i32 6
  store i1 %t108, ptr %t110, !tbaa !21
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/bindgen:gen", ptr %t111, i32 0, i32 2
  %t114 = load i64, ptr %l8, !tbaa !24
  %t115 = load %"compiler/bindgen:record", ptr %l10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v0, ptr %t113, i64 %t114, %"compiler/bindgen:record" %t115)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = call i1 @compiler_2fbindgen_2eflag(ptr %v1, ptr %s0, ptr %t119, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d143, i32 0, i32 1) })
  store i1 %t121, ptr %l70
  br label %bb23
bb23:
  %t122 = load i1, ptr %l70, !tbaa !21
  %t123 = xor i1 %t122, true
  br i1 %t123, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb27
bb25:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/bindgen:gen", ptr %t125, i32 0, i32 2
  %t128 = load i64, ptr %l5, !tbaa !24
  %t131 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t127, i64 %t128)
  store %"compiler/bindgen:record" %t131, ptr %l76
  br label %bb26
bb26:
  %t132 = getelementptr %"compiler/bindgen:record", ptr %l76, i32 0, i32 2
  %t133 = load i1, ptr %t132, !tbaa !21
  store i1 %t133, ptr %l72, !tbaa !21
  br label %bb27
bb27:
  %t135 = load i1, ptr %l72, !tbaa !21
  br i1 %t135, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t136 = load i64, ptr %l5, !tbaa !24
  store i64 %t136, ptr %l11, !tbaa !24
  store i1 true, ptr %l12, !tbaa !21
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/bindgen:gen", ptr %t138, i32 0, i32 2
  %t141 = load i64, ptr %l11, !tbaa !24
  %t144 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store %"compiler/bindgen:record" %t144, ptr %l82
  br label %bb31
bb31:
  %t145 = load %"compiler/bindgen:record", ptr %l82
  store %"compiler/bindgen:record" %t145, ptr %l13
  %t146 = load i1, ptr %l12, !tbaa !21
  %t148 = getelementptr %"compiler/bindgen:record", ptr %l13, i32 0, i32 2
  store i1 %t146, ptr %t148, !tbaa !21
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/bindgen:gen", ptr %t149, i32 0, i32 2
  %t152 = load i64, ptr %l11, !tbaa !24
  %t153 = load %"compiler/bindgen:record", ptr %l13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v0, ptr %t151, i64 %t152, %"compiler/bindgen:record" %t153)
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %v1, ptr %s6, ptr %t157)
  store { i64, ptr } %t159, ptr %l89
  br label %bb33
bb33:
  %t160 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  %t163 = mul i64 %t161, 8
  %t164 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l16, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t172 = load i64, ptr %l15, !tbaa !24
  %t173 = load i64, ptr %l16, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb62
bb36:
  br label %bb37
bb37:
  %t180 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t180, ptr %l97, !tbaa !27
  %t181 = load i64, ptr %l15, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr ptr, ptr %t184, i64 %t181
  %t186 = load ptr, ptr %t185, !tbaa !39
  store ptr %t186, ptr %l17, !tbaa !29
  %t188 = load ptr, ptr %l17, !tbaa !29
  %t190 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s6, ptr %s7, ptr %s7, ptr %t188, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d144, i32 0, i32 1) })
  store { i64, ptr } %t190, ptr %l101
  br label %bb38
bb38:
  %t191 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t191, ptr %l18, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t194 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t192, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d145, i32 0, i32 1) })
  store i1 %t194, ptr %l103
  br label %bb39
bb39:
  %t195 = load i1, ptr %l103, !tbaa !21
  br i1 %t195, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l104, !tbaa !29
  %t197 = load ptr, ptr %l17, !tbaa !29
  store ptr %t197, ptr %l105, !tbaa !29
  %t198 = load ptr, ptr %l17, !tbaa !29
  %t200 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s6, ptr %s8, ptr %s8, ptr %t198, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d146, i32 0, i32 1) })
  store { i64, ptr } %t200, ptr %l107
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t201 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 0
  %t203 = extractvalue { i64, ptr } %t201, 1
  %t204 = mul i64 %t202, 1
  %t205 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t204)
  call void @llvm.memcpy.p0.p0.i64(ptr %t205, ptr %t203, i64 %t204, i1 false)
  %t206 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  %t208 = load i1, ptr %l3, !tbaa !21
  %t209 = load ptr, ptr %l104, !tbaa !29
  %t210 = load ptr, ptr %l105, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordDecl(ptr %v0, ptr %s6, ptr %s8, ptr %t209, ptr %t210, { i64, ptr } %t207, i1 %t208)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s8)
  br label %bb44
bb44:
  %t213 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t215 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t213, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d147, i32 0, i32 1) })
  store i1 %t215, ptr %l111
  br label %bb45
bb45:
  %t216 = load i1, ptr %l111, !tbaa !21
  %t217 = xor i1 %t216, true
  br i1 %t217, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb61
bb47:
  br label %bb48
bb48:
  %t219 = load ptr, ptr %l17, !tbaa !29
  %t221 = call i1 @compiler_2fbindgen_2eflag(ptr %s6, ptr %s7, ptr %t219, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d148, i32 0, i32 1) })
  store i1 %t221, ptr %l114
  br label %bb49
bb49:
  %t222 = load i1, ptr %l114, !tbaa !21
  br i1 %t222, label %bb50, label %bb51
bb50:
  %t223 = load i64, ptr %l5, !tbaa !24
  store i64 %t223, ptr %l19, !tbaa !24
  store i1 true, ptr %l20, !tbaa !21
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/bindgen:gen", ptr %t225, i32 0, i32 2
  %t228 = load i64, ptr %l19, !tbaa !24
  %t231 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t227, i64 %t228)
  store %"compiler/bindgen:record" %t231, ptr %l119
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t232 = load %"compiler/bindgen:record", ptr %l119
  store %"compiler/bindgen:record" %t232, ptr %l21
  %t233 = load i1, ptr %l20, !tbaa !21
  %t235 = getelementptr %"compiler/bindgen:record", ptr %l21, i32 0, i32 3
  store i1 %t233, ptr %t235, !tbaa !21
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/bindgen:gen", ptr %t236, i32 0, i32 2
  %t239 = load i64, ptr %l19, !tbaa !24
  %t240 = load %"compiler/bindgen:record", ptr %l21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v0, ptr %t238, i64 %t239, %"compiler/bindgen:record" %t240)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/bindgen:gen", ptr %t244, i32 0, i32 2
  %t247 = load i64, ptr %l5, !tbaa !24
  %t250 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t246, i64 %t247)
  store %"compiler/bindgen:record" %t250, ptr %l128
  br label %bb55
bb55:
  %t251 = getelementptr %"compiler/bindgen:record", ptr %l128, i32 0, i32 4
  store ptr %t251, ptr %l129, !tbaa !29
  %t252 = load ptr, ptr %l17, !tbaa !29
  %t254 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s6, ptr %v0, ptr %v0, ptr %t252, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d149, i32 0, i32 1) })
  store { i64, ptr } %t254, ptr %l131
  br label %bb56
bb56:
  %t255 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 0
  %t257 = extractvalue { i64, ptr } %t255, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  %t262 = load ptr, ptr %l129, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t262, { i64, ptr } %t261)
  br label %bb57
bb57:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/bindgen:gen", ptr %t264, i32 0, i32 2
  %t267 = load i64, ptr %l5, !tbaa !24
  %t270 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t266, i64 %t267)
  store %"compiler/bindgen:record" %t270, ptr %l136
  br label %bb58
bb58:
  %t271 = getelementptr %"compiler/bindgen:record", ptr %l136, i32 0, i32 5
  store ptr %t271, ptr %l137, !tbaa !29
  %t272 = load ptr, ptr %l17, !tbaa !29
  %t274 = call { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %s6, ptr %v0, ptr %t272)
  store { i64, ptr } %t274, ptr %l139
  br label %bb59
bb59:
  %t275 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 0
  %t277 = extractvalue { i64, ptr } %t275, 1
  %t278 = mul i64 %t276, 1
  %t279 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t278)
  call void @llvm.memcpy.p0.p0.i64(ptr %t279, ptr %t277, i64 %t278, i1 false)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  %t282 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t282, { i64, ptr } %t281)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s7)
  br label %bb61
bb61:
  %t284 = load i64, ptr %l15, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l15, !tbaa !24
  br label %bb34
bb62:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a1, 1
  %t5 = extractvalue { i64, ptr } %a1, 0
  %t6 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t5)
  call void @olang_textcopy(ptr %t6, ptr %t4, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = extractvalue { i64, ptr } %t8, 1
  %t12 = mul i64 %t10, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @llvm.memcpy.p0.p0.i64(ptr %t13, ptr %t11, i64 %t12, i1 false)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t18 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 13
  store { i64, ptr } %t15, ptr %t18, !tbaa !27
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2estructDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"compiler/bindgen:record"
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l19 = alloca %"compiler/bindgen:record"
  %l24 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l66 = alloca %"compiler/bindgen:ctype"
  %l69 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l74 = alloca %"compiler/bindgen:ctype"
  %l76 = alloca { i64, ptr }
  %l77 = alloca i32
  %l80 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l88 = alloca %"compiler/bindgen:ctype"
  %l92 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i32
  %l99 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l15
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/bindgen:gen", ptr %t3, i32 0, i32 2
  %t9 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t5, i64 %a1)
  store %"compiler/bindgen:record" %t9, ptr %l19
  br label %bb2
bb2:
  %t10 = load %"compiler/bindgen:record", ptr %l19
  store %"compiler/bindgen:record" %t10, ptr %l3
  %t11 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 7
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t13 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t16 = extractvalue { i64, ptr } %t12, 1
  %t17 = extractvalue { i64, ptr } %t12, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = getelementptr i8, ptr %t23, i64 %t17
  call void @olang_textcopy(ptr %t24, ptr %t19, i64 %t20)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t22, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } %t26, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t33)
  br label %bb3
bb3:
  %t36 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l24
  br label %bb4
bb4:
  %t37 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t38 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 4
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l26
  br label %bb5
bb5:
  %t41 = load i64, ptr %l26, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb6, label %bb7
bb6:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb11
bb8:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l33, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb10
bb10:
  %t68 = load i64, ptr %l33, !tbaa !24
  store i64 %t68, ptr %l30, !tbaa !24
  br label %bb11
bb11:
  %t69 = load i64, ptr %l30, !tbaa !24
  store i64 %t69, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb14:
  br label %bb15
bb15:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  store i64 %t86, ptr %l10, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  %t89 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 4
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t89, i64 %t90)
  store { i64, ptr } %t93, ptr %l54
  br label %bb16
bb16:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load ptr, ptr %l51, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t99 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v0, ptr %s0, ptr %s3, ptr %t95, { i64, ptr } %t96, i64 %t94, ptr %l4)
  store { i64, ptr } %t99, ptr %l57
  br label %bb17
bb17:
  %t100 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t100, ptr %l11, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l58, !tbaa !29
  %t102 = getelementptr %"compiler/bindgen:record", ptr %l3, i32 0, i32 5
  %t103 = load i64, ptr %l10, !tbaa !24
  %t106 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t102, i64 %t103)
  store { i64, ptr } %t106, ptr %l61
  br label %bb18
bb18:
  %t107 = load ptr, ptr %l58, !tbaa !29
  %t108 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t109 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v0, ptr %t107, { i64, ptr } %t108, i64 0)
  store i64 %t109, ptr %l62
  br label %bb19
bb19:
  %t110 = load i64, ptr %l62, !tbaa !24
  store i64 %t110, ptr %l12, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/bindgen:gen", ptr %t111, i32 0, i32 8
  %t114 = load i64, ptr %l12, !tbaa !24
  %t117 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s3, ptr %t113, i64 %t114)
  store %"compiler/bindgen:ctype" %t117, ptr %l66
  br label %bb20
bb20:
  %t118 = getelementptr %"compiler/bindgen:ctype", ptr %l66, i32 0, i32 0
  %t119 = load i32, ptr %t118
  %t121 = trunc i64 4 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l70, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/bindgen:gen", ptr %t125, i32 0, i32 8
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s4, ptr %t127, i64 %t128)
  store %"compiler/bindgen:ctype" %t131, ptr %l74
  br label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %s6, ptr %t132, i64 %t133)
  %t137 = extractvalue { i32, { i64, ptr } } %t136, 1
  %t138 = extractvalue { i32, { i64, ptr } } %t136, 0
  store i32 %t138, ptr %l96
  %t139 = icmp ne i32 %t138, 0
  br i1 %t139, label %bb33, label %ok.140
ok.140:
  store { i64, ptr } %t137, ptr %l95
  br label %bb32
bb23:
  %t141 = getelementptr %"compiler/bindgen:ctype", ptr %l74, i32 0, i32 2
  %t142 = load i64, ptr %t141, !tbaa !24
  %t143 = load ptr, ptr %l70, !tbaa !29
  %t145 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %s4, ptr %t143, i64 %t142)
  %t146 = extractvalue { i32, { i64, ptr } } %t145, 1
  %t147 = extractvalue { i32, { i64, ptr } } %t145, 0
  store i32 %t147, ptr %l77
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb25, label %ok.149
ok.149:
  store { i64, ptr } %t146, ptr %l76
  br label %bb24
bb24:
  %t150 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t150, ptr %l69, !tbaa !27
  br label %bb29
bb25:
  %t151 = load i32, ptr %l77, !tbaa !23
  %t152 = ashr i32 %t151, 16
  %t154 = icmp eq i32 %t152, 1
  br i1 %t154, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_15971967adc848fb_c06c6f64909b248f)
  unreachable
bb28:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d152, i32 0, i32 1) }, ptr %l80, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t156, ptr %l69, !tbaa !27
  br label %bb29
bb29:
  %t158 = load { i64, ptr }, ptr %l69, !tbaa !27
  store ptr %l2, ptr %l82, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t159, ptr %l83, !tbaa !27
  store { i64, ptr } %t158, ptr %l84, !tbaa !27
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/bindgen:gen", ptr %t161, i32 0, i32 8
  %t164 = load i64, ptr %l12, !tbaa !24
  %t167 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s4, ptr %t163, i64 %t164)
  store %"compiler/bindgen:ctype" %t167, ptr %l88
  br label %bb30
bb30:
  %t168 = getelementptr %"compiler/bindgen:ctype", ptr %l88, i32 0, i32 4
  %t169 = load i64, ptr %t168, !tbaa !24
  %t170 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t172 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = add i64 %t171, %t174
  %t176 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t178 = add i64 %t175, %t177
  %t179 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = add i64 %t178, %t181
  %t183 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t185 = add i64 %t182, %t184
  %t187 = call i64 @__olang_fmt_i64(ptr null, i64 %t169)
  %t188 = add i64 %t185, %t187
  %t189 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t191 = add i64 %t188, %t190
  %t192 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t191)
  call void @olang_textcopy(ptr %t192, ptr %t170, i64 %t171)
  %t193 = getelementptr i8, ptr %t192, i64 %t171
  call void @olang_textcopy(ptr %t193, ptr %t173, i64 %t174)
  %t194 = getelementptr i8, ptr %t193, i64 %t174
  call void @olang_textcopy(ptr %t194, ptr %t176, i64 %t177)
  %t195 = getelementptr i8, ptr %t194, i64 %t177
  call void @olang_textcopy(ptr %t195, ptr %t180, i64 %t181)
  %t196 = getelementptr i8, ptr %t195, i64 %t181
  call void @olang_textcopy(ptr %t196, ptr %t183, i64 %t184)
  %t197 = getelementptr i8, ptr %t196, i64 %t184
  %t198 = call i64 @__olang_fmt_i64(ptr %t197, i64 %t169)
  %t199 = getelementptr i8, ptr %t197, i64 %t187
  call void @olang_textcopy(ptr %t199, ptr %t189, i64 %t190)
  %t200 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t192, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } %t201, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  %t209 = load ptr, ptr %l82, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t209, { i64, ptr } %t208)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb32:
  %t211 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t211, ptr %l92, !tbaa !27
  br label %bb37
bb33:
  %t212 = load i32, ptr %l96, !tbaa !23
  %t213 = ashr i32 %t212, 16
  %t215 = icmp eq i32 %t213, 1
  br i1 %t215, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_66f8b08a9932247a_88b90d6010cc404e)
  unreachable
bb36:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d157, i32 0, i32 1) }, ptr %l99, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t217, ptr %l92, !tbaa !27
  br label %bb37
bb37:
  %t219 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t222 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t225 = extractvalue { i64, ptr } %t220, 1
  %t226 = extractvalue { i64, ptr } %t220, 0
  %t227 = add i64 %t223, %t226
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t230 = add i64 %t227, %t229
  %t232 = extractvalue { i64, ptr } %t219, 1
  %t233 = extractvalue { i64, ptr } %t219, 0
  %t234 = add i64 %t230, %t233
  %t235 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t237 = add i64 %t234, %t236
  %t238 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t237)
  call void @olang_textcopy(ptr %t238, ptr %t222, i64 %t223)
  %t239 = getelementptr i8, ptr %t238, i64 %t223
  call void @olang_textcopy(ptr %t239, ptr %t225, i64 %t226)
  %t240 = getelementptr i8, ptr %t239, i64 %t226
  call void @olang_textcopy(ptr %t240, ptr %t228, i64 %t229)
  %t241 = getelementptr i8, ptr %t240, i64 %t229
  call void @olang_textcopy(ptr %t241, ptr %t232, i64 %t233)
  %t242 = getelementptr i8, ptr %t241, i64 %t233
  call void @olang_textcopy(ptr %t242, ptr %t235, i64 %t236)
  %t243 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t238, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = extractvalue { i64, ptr } %t244, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l2, { i64, ptr } %t251)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb40:
  %t254 = load i64, ptr %l9, !tbaa !24
  %t256 = add i64 %t254, 1
  store i64 %t256, ptr %l9, !tbaa !24
  br label %bb12
bb41:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d161, i32 0, i32 1) })
  br label %bb42
bb42:
  %t260 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t260, ptr %l110
  br label %bb43
bb43:
  %t261 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t261, ptr %l111, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  store i64 %t263, ptr %l112, !tbaa !24
  %t264 = load i64, ptr %l112, !tbaa !24
  %t265 = mul i64 %t264, 1
  %t266 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t265)
  %t267 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l113, !tbaa !27
  %t269 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = load i64, ptr %l112, !tbaa !24
  %t274 = mul i64 %t273, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t270, ptr %t272, i64 %t274, i1 false)
  %t275 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t275, ptr %l111, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t276 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t276, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l50 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca i1
  %l59 = alloca { i64, ptr }
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l73 = alloca i1
  %l74 = alloca i64
  %l77 = alloca i1
  %l78 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i1
  %l97 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb47
bb5:
  store i64 0, ptr %l4, !tbaa !24
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v1, ptr %t16)
  store i64 %t18, ptr %l24
  br label %bb6
bb6:
  %t19 = load i64, ptr %l24, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb12
bb9:
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l31, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb11
bb11:
  %t46 = load i64, ptr %l31, !tbaa !24
  store i64 %t46, ptr %l28, !tbaa !24
  br label %bb12
bb12:
  %t47 = load i64, ptr %l28, !tbaa !24
  store i64 %t47, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb15:
  br label %bb16
bb16:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l9, !tbaa !24
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"std/json:Object", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l50, !tbaa !27
  %t70 = load i64, ptr %l9, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l10, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = getelementptr %"std/json:Object", ptr %t77, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l54, !tbaa !27
  %t81 = load i64, ptr %l9, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %t84, i64 %t81
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !37
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t86, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d162, i32 0, i32 1) })
  store i1 %t88, ptr %l57
  br label %bb17
bb17:
  %t89 = load i1, ptr %l57, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb19:
  br label %bb20
bb20:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr %"std/json:Object", ptr %t90, i32 0, i32 0
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l59, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %t97, i64 %t94
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !37
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t99, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d163, i32 0, i32 1) })
  store i1 %t101, ptr %l62
  br label %bb21
bb21:
  %t102 = load i1, ptr %l62, !tbaa !21
  br i1 %t102, label %bb22, label %bb23
bb22:
  %t103 = load ptr, ptr %l10, !tbaa !29
  store ptr %t103, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t104 = load ptr, ptr %l63, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb24, label %bb25
bb23:
  br label %bb43
bb24:
  %t107 = load ptr, ptr %l63, !tbaa !29
  %t108 = load i64, ptr %t107
  %t110 = icmp eq i64 %t108, 5
  store i1 %t110, ptr %l64, !tbaa !21
  br label %bb25
bb25:
  %t111 = load i1, ptr %l64, !tbaa !21
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t112 = load ptr, ptr %l10, !tbaa !29
  %t114 = getelementptr { i64, [2 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { { i64, ptr } }, ptr %t114, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115
  store { i64, ptr } %t116, ptr %l11, !tbaa !27
  br label %bb28
bb27:
  br label %bb37
bb28:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l69, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/bindgen:gen", ptr %t120, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %v0, { i64, ptr } %t119, { i64, ptr } %t123)
  store i1 %t126, ptr %l73
  br label %bb29
bb29:
  %t127 = load i1, ptr %l73, !tbaa !21
  br i1 %t127, label %bb30, label %bb31
bb30:
  store i64 1, ptr %l74, !tbaa !24
  br label %bb36
bb31:
  %t128 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %v2, { i64, ptr } %t128, { i64, ptr } %t129)
  store i1 %t132, ptr %l77
  br label %bb32
bb32:
  %t133 = load i1, ptr %l77, !tbaa !21
  br i1 %t133, label %bb33, label %bb34
bb33:
  store i64 2, ptr %l78, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb35
bb35:
  %t134 = load i64, ptr %l78, !tbaa !24
  store i64 %t134, ptr %l74, !tbaa !24
  br label %bb36
bb36:
  %t135 = load i64, ptr %l74, !tbaa !24
  %t136 = load ptr, ptr %l69, !tbaa !29
  %t137 = getelementptr %"compiler/bindgen:gen", ptr %t136, i32 0, i32 14
  store i64 %t135, ptr %t137, !tbaa !24
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_c54e19abcb0a74ad_a74456fc2d527de1)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb43:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l10, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %v1, ptr %v2, ptr %t138, ptr %t139, { i64, ptr } %t140)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb45:
  %t144 = load i64, ptr %l8, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l8, !tbaa !24
  br label %bb13
bb46:
  br label %bb65
bb47:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t149 = load ptr, ptr %l84, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb48, label %bb49
bb48:
  %t152 = load ptr, ptr %l84, !tbaa !29
  %t153 = load i64, ptr %t152
  %t155 = icmp eq i64 %t153, 6
  store i1 %t155, ptr %l85, !tbaa !21
  br label %bb49
bb49:
  %t156 = load i1, ptr %l85, !tbaa !21
  br i1 %t156, label %bb50, label %bb51
bb50:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [2 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { { i64, ptr } }, ptr %t159, i32 0, i32 0
  %t161 = load { i64, ptr }, ptr %t160
  store { i64, ptr } %t161, ptr %l12, !tbaa !27
  br label %bb52
bb51:
  br label %bb60
bb52:
  %t163 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t163, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l15, !tbaa !24
  br label %bb53
bb53:
  %t169 = load i64, ptr %l14, !tbaa !24
  %t170 = load i64, ptr %l15, !tbaa !24
  %t173 = icmp slt i64 %t169, %t170
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb54, label %bb55
bb54:
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t177 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t177, ptr %l97, !tbaa !27
  %t178 = load i64, ptr %l14, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr ptr, ptr %t181, i64 %t178
  %t183 = load ptr, ptr %t182, !tbaa !39
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %v1, ptr %v2, ptr %t185, ptr %t183, { i64, ptr } %t187)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t191 = load i64, ptr %l14, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l14, !tbaa !24
  br label %bb53
bb59:
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_302d290203cc94fc_f1ac1451fbe7e850)
  unreachable
bb65:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etypeName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l62 = alloca i1
  %l64 = alloca { i64, ptr }
  %l66 = alloca i64
  %l69 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l75 = alloca i1
  %l77 = alloca { i64, ptr }
  %l79 = alloca i64
  %l81 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca i1
  %l91 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i1
  %l96 = alloca i1
  %l97 = alloca i1
  %l100 = alloca i1
  %l103 = alloca i1
  %l107 = alloca i1
  %l109 = alloca i1
  %l110 = alloca i1
  %l114 = alloca { i64, ptr }
  %l116 = alloca i64
  %l118 = alloca ptr
  %l122 = alloca i1
  %l125 = alloca i64
  %l127 = alloca i1
  %l130 = alloca i1
  %l138 = alloca i64
  %l145 = alloca i64
  %l147 = alloca i1
  %l149 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l154 = alloca i32
  %l156 = alloca i1
  %l161 = alloca i64
  %l166 = alloca i64
  %l171 = alloca i64
  %l177 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d164, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t1, ptr %l14, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l15, !tbaa !24
  %t4 = load i64, ptr %l15, !tbaa !24
  %t5 = mul i64 %t4, 1
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l16, !tbaa !27
  %t9 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = mul i64 %t13, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t10, ptr %t12, i64 %t14, i1 false)
  %t15 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  store i1 false, ptr %l6, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d165, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t16, ptr %l18, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l19, !tbaa !24
  %t19 = load i64, ptr %l19, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t30, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d166, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = mul i64 %t34, 1
  %t36 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l24, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l23, !tbaa !24
  %t44 = mul i64 %t43, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %t42, i64 %t44, i1 false)
  %t45 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t45, ptr %l8, !tbaa !27
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/bindgen:ctp", ptr %t46, i32 0, i32 1
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/bindgen:ctp", ptr %t50, i32 0, i32 0
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t58 = icmp slt i64 %t49, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb100
bb3:
  br label %bb4
bb4:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s1, ptr %t62, i64 0)
  store { i64, ptr } %t64, ptr %l33
  br label %bb5
bb5:
  %t65 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t65, ptr %l9, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t66, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d167, i32 0, i32 1) })
  store i1 %t68, ptr %l35
  br label %bb6
bb6:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb98
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t70 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s3, { i64, ptr } %t70, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d168, i32 0, i32 1) })
  store i1 %t72, ptr %l37
  br label %bb9
bb9:
  %t73 = load i1, ptr %l37, !tbaa !21
  br i1 %t73, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb13
bb11:
  %t74 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s3, { i64, ptr } %t74, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d169, i32 0, i32 1) })
  store i1 %t76, ptr %l40
  br label %bb12
bb12:
  %t77 = load i1, ptr %l40, !tbaa !21
  store i1 %t77, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  %t78 = load i1, ptr %l38, !tbaa !21
  br i1 %t78, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb17
bb15:
  %t79 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t81 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s3, { i64, ptr } %t79, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d170, i32 0, i32 1) })
  store i1 %t81, ptr %l43
  br label %bb16
bb16:
  %t82 = load i1, ptr %l43, !tbaa !21
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t83 = load i1, ptr %l41, !tbaa !21
  br i1 %t83, label %bb18, label %bb19
bb18:
  br label %bb97
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s5, { i64, ptr } %t84, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d171, i32 0, i32 1) })
  store i1 %t86, ptr %l45
  br label %bb20
bb20:
  %t87 = load i1, ptr %l45, !tbaa !21
  br i1 %t87, label %bb21, label %bb22
bb21:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb96
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t88 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s7, { i64, ptr } %t88, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d172, i32 0, i32 1) })
  store i1 %t90, ptr %l47
  br label %bb23
bb23:
  %t91 = load i1, ptr %l47, !tbaa !21
  br i1 %t91, label %bb24, label %bb25
bb24:
  store i64 2, ptr %l3, !tbaa !24
  br label %bb95
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t92 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t94 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s9, { i64, ptr } %t92, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d173, i32 0, i32 1) })
  store i1 %t94, ptr %l49
  br label %bb26
bb26:
  %t95 = load i1, ptr %l49, !tbaa !21
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l4, !tbaa !24
  br label %bb94
bb28:
  store %olang.scope zeroinitializer, ptr %s11
  %t100 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t100, ptr %l52, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l53, !tbaa !24
  %t103 = load i64, ptr %l53, !tbaa !24
  %t104 = mul i64 %t103, 1
  %t105 = call ptr @__olang_scope_alloc_zeroed(ptr %s11, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l54, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l53, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  %t114 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t117 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s11, ptr %s11, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x { i64, ptr }] }>, ptr @.d174, i32 0, i32 1) }, { i64, ptr } %t114)
  store i1 %t117, ptr %l56
  br label %bb29
bb29:
  %t118 = load i1, ptr %l56, !tbaa !21
  br i1 %t118, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s12
  %t119 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s12, { i64, ptr } %t119, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d175, i32 0, i32 1) })
  store i1 %t121, ptr %l58
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s15
  %t122 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s15, { i64, ptr } %t122, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d176, i32 0, i32 1) })
  store i1 %t124, ptr %l69
  br label %bb43
bb32:
  %t125 = load i1, ptr %l58, !tbaa !21
  %t126 = xor i1 %t125, true
  br i1 %t126, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb36
bb34:
  %t128 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t130 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s12, { i64, ptr } %t128, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d177, i32 0, i32 1) })
  store i1 %t130, ptr %l62
  br label %bb35
bb35:
  %t131 = load i1, ptr %l62, !tbaa !21
  store i1 %t131, ptr %l60, !tbaa !21
  br label %bb36
bb36:
  %t132 = load i1, ptr %l60, !tbaa !21
  br i1 %t132, label %bb37, label %bb38
bb37:
  %t133 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = extractvalue { i64, ptr } %t133, 0
  %t137 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t135, i64 %t136)
  %t138 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  store { i64, ptr } %t139, ptr %l64, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 0
  %t142 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l66, !tbaa !24
  %t145 = load i64, ptr %l66, !tbaa !24
  %t146 = icmp eq i64 %t141, %t145
  br i1 %t146, label %bb39, label %bb40
bb38:
  br label %bb42
bb39:
  %t148 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = load i64, ptr %l66, !tbaa !24
  %t153 = mul i64 %t152, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t149, ptr %t151, i64 %t153, i1 false)
  br label %bb41
bb40:
  %t154 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t154, ptr %l5, !tbaa !27
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb43:
  %t155 = load i1, ptr %l69, !tbaa !21
  br i1 %t155, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb47
bb45:
  %t156 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t158 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s15, { i64, ptr } %t156, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d178, i32 0, i32 1) })
  store i1 %t158, ptr %l72
  br label %bb46
bb46:
  %t159 = load i1, ptr %l72, !tbaa !21
  store i1 %t159, ptr %l70, !tbaa !21
  br label %bb47
bb47:
  %t160 = load i1, ptr %l70, !tbaa !21
  br i1 %t160, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb51
bb49:
  %t161 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t163 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s15, { i64, ptr } %t161, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store i1 %t163, ptr %l75
  br label %bb50
bb50:
  %t164 = load i1, ptr %l75, !tbaa !21
  store i1 %t164, ptr %l73, !tbaa !21
  br label %bb51
bb51:
  %t165 = load i1, ptr %l73, !tbaa !21
  br i1 %t165, label %bb52, label %bb53
bb52:
  %t166 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 1
  %t169 = extractvalue { i64, ptr } %t166, 0
  %t170 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t169)
  call void @olang_textcopy(ptr %t170, ptr %t168, i64 %t169)
  %t171 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l77, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  %t175 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  store i64 %t176, ptr %l79, !tbaa !24
  %t178 = load i64, ptr %l79, !tbaa !24
  %t179 = icmp eq i64 %t174, %t178
  br i1 %t179, label %bb54, label %bb55
bb53:
  store %olang.scope zeroinitializer, ptr %s18
  %t181 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t183 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s18, { i64, ptr } %t181, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d180, i32 0, i32 1) })
  store i1 %t183, ptr %l90
  br label %bb61
bb54:
  %t184 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = load i64, ptr %l79, !tbaa !24
  %t189 = mul i64 %t188, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t185, ptr %t187, i64 %t189, i1 false)
  br label %bb56
bb55:
  %t190 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t190, ptr %l7, !tbaa !27
  br label %bb56
bb56:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l81, !tbaa !29
  %t192 = load ptr, ptr %l81, !tbaa !29
  %t193 = getelementptr %"compiler/bindgen:ctp", ptr %t192, i32 0, i32 1
  %t194 = load i64, ptr %t193, !tbaa !24
  %t196 = add i64 %t194, 1
  %t198 = load ptr, ptr %l81, !tbaa !29
  %t199 = getelementptr %"compiler/bindgen:ctp", ptr %t198, i32 0, i32 1
  store i64 %t196, ptr %t199, !tbaa !24
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v1, ptr %s0, ptr %t200, i64 0)
  store { i64, ptr } %t202, ptr %l85
  br label %bb57
bb57:
  %t203 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  %t205 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 0
  store i64 %t206, ptr %l87, !tbaa !24
  %t208 = load i64, ptr %l87, !tbaa !24
  %t209 = icmp eq i64 %t204, %t208
  br i1 %t209, label %bb58, label %bb59
bb58:
  %t211 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = load i64, ptr %l87, !tbaa !24
  %t216 = mul i64 %t215, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t212, ptr %t214, i64 %t216, i1 false)
  br label %bb60
bb59:
  %t217 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t217, ptr %l8, !tbaa !27
  br label %bb60
bb60:
  br label %bb92
bb61:
  %t218 = load i1, ptr %l90, !tbaa !21
  br i1 %t218, label %bb62, label %bb63
bb62:
  %t219 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t221 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s18, { i64, ptr } %t219, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d181, i32 0, i32 1) })
  store i1 %t221, ptr %l93
  br label %bb64
bb63:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb65
bb64:
  %t222 = load i1, ptr %l93, !tbaa !21
  store i1 %t222, ptr %l91, !tbaa !21
  br label %bb65
bb65:
  %t223 = load i1, ptr %l91, !tbaa !21
  br i1 %t223, label %bb66, label %bb67
bb66:
  %t224 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t226 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s18, { i64, ptr } %t224, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d182, i32 0, i32 1) })
  store i1 %t226, ptr %l96
  br label %bb68
bb67:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb69
bb68:
  %t227 = load i1, ptr %l96, !tbaa !21
  store i1 %t227, ptr %l94, !tbaa !21
  br label %bb69
bb69:
  %t228 = load i1, ptr %l94, !tbaa !21
  br i1 %t228, label %bb70, label %bb71
bb70:
  %t229 = load i64, ptr %l3, !tbaa !24
  %t231 = icmp eq i64 %t229, 0
  store i1 %t231, ptr %l97, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb72
bb72:
  %t233 = load i1, ptr %l97, !tbaa !21
  br i1 %t233, label %bb73, label %bb74
bb73:
  %t234 = load i64, ptr %l4, !tbaa !24
  %t236 = icmp eq i64 %t234, 0
  store i1 %t236, ptr %l100, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb75
bb75:
  %t238 = load i1, ptr %l100, !tbaa !21
  br i1 %t238, label %bb76, label %bb77
bb76:
  %t239 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t243 = icmp sgt i64 %t241, 0
  store i1 %t243, ptr %l103, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb78
bb78:
  %t245 = load i1, ptr %l103, !tbaa !21
  br i1 %t245, label %bb79, label %bb80
bb79:
  %t246 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr i8, ptr %t247, i64 0
  %t249 = load i8, ptr %t248, !tbaa !32
  %t251 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t249)
  store i1 %t251, ptr %l109
  br label %bb81
bb80:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb85
bb81:
  %t252 = load i1, ptr %l109, !tbaa !21
  br i1 %t252, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb84
bb83:
  %t253 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr i8, ptr %t254, i64 0
  %t256 = load i8, ptr %t255, !tbaa !32
  %t258 = icmp eq i8 %t256, 95
  store i1 %t258, ptr %l110, !tbaa !21
  br label %bb84
bb84:
  %t260 = load i1, ptr %l110, !tbaa !21
  store i1 %t260, ptr %l107, !tbaa !21
  br label %bb85
bb85:
  %t261 = load i1, ptr %l107, !tbaa !21
  br i1 %t261, label %bb86, label %bb87
bb86:
  %t262 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 1
  %t265 = extractvalue { i64, ptr } %t262, 0
  %t266 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t265)
  call void @olang_textcopy(ptr %t266, ptr %t264, i64 %t265)
  %t267 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l114, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  %t271 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  store i64 %t272, ptr %l116, !tbaa !24
  %t274 = load i64, ptr %l116, !tbaa !24
  %t275 = icmp eq i64 %t270, %t274
  br i1 %t275, label %bb88, label %bb89
bb87:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  br label %bb100
bb88:
  %t277 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = load i64, ptr %l116, !tbaa !24
  %t282 = mul i64 %t281, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t278, ptr %t280, i64 %t282, i1 false)
  br label %bb90
bb89:
  %t283 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t283, ptr %l8, !tbaa !27
  br label %bb90
bb90:
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s18)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s15)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s11)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s9)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s7)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s5)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s3)
  br label %bb98
bb98:
  %t284 = load ptr, ptr %l1, !tbaa !29
  store ptr %t284, ptr %l118, !tbaa !29
  %t285 = load ptr, ptr %l118, !tbaa !29
  %t286 = getelementptr %"compiler/bindgen:ctp", ptr %t285, i32 0, i32 1
  %t287 = load i64, ptr %t286, !tbaa !24
  %t289 = add i64 %t287, 1
  %t291 = load ptr, ptr %l118, !tbaa !29
  %t292 = getelementptr %"compiler/bindgen:ctp", ptr %t291, i32 0, i32 1
  store i64 %t289, ptr %t292, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb99
bb99:
  br label %bb1
bb100:
  store i64 0, ptr %l11, !tbaa !24
  %t293 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t295 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t293, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d183, i32 0, i32 1) })
  store i1 %t295, ptr %l122
  br label %bb101
bb101:
  %t296 = load i1, ptr %l122, !tbaa !21
  br i1 %t296, label %bb102, label %bb103
bb102:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t300 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t297, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d184, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t300, ptr %l125
  br label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s23
  %t301 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t303 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s23, { i64, ptr } %t301, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d185, i32 0, i32 1) })
  store i1 %t303, ptr %l127
  br label %bb105
bb104:
  %t304 = load i64, ptr %l125, !tbaa !24
  store i64 %t304, ptr %l11, !tbaa !24
  br label %bb130
bb105:
  %t305 = load i1, ptr %l127, !tbaa !21
  %t306 = xor i1 %t305, true
  br i1 %t306, label %bb106, label %bb107
bb106:
  %t308 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t310 = call i1 @compiler_2fbindgen_2eusable(ptr %s0, { i64, ptr } %t308)
  store i1 %t310, ptr %l130
  br label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s28
  %t311 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t313 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s28, { i64, ptr } %t311, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d186, i32 0, i32 1) })
  store i1 %t313, ptr %l147
  br label %bb114
bb108:
  %t314 = load i1, ptr %l130, !tbaa !21
  %t315 = xor i1 %t314, true
  br i1 %t315, label %bb109, label %bb110
bb109:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t319 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t321 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t322 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t324 = extractvalue { i64, ptr } %t318, 1
  %t325 = extractvalue { i64, ptr } %t318, 0
  %t326 = add i64 %t322, %t325
  %t327 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t328 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t329 = add i64 %t326, %t328
  %t331 = extractvalue { i64, ptr } %t319, 1
  %t332 = extractvalue { i64, ptr } %t319, 0
  %t333 = add i64 %t329, %t332
  %t334 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t335 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t336 = add i64 %t333, %t335
  %t338 = extractvalue { i64, ptr } %t320, 1
  %t339 = extractvalue { i64, ptr } %t320, 0
  %t340 = add i64 %t336, %t339
  %t341 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t343 = add i64 %t340, %t342
  %t344 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t343)
  call void @olang_textcopy(ptr %t344, ptr %t321, i64 %t322)
  %t345 = getelementptr i8, ptr %t344, i64 %t322
  call void @olang_textcopy(ptr %t345, ptr %t324, i64 %t325)
  %t346 = getelementptr i8, ptr %t345, i64 %t325
  call void @olang_textcopy(ptr %t346, ptr %t327, i64 %t328)
  %t347 = getelementptr i8, ptr %t346, i64 %t328
  call void @olang_textcopy(ptr %t347, ptr %t331, i64 %t332)
  %t348 = getelementptr i8, ptr %t347, i64 %t332
  call void @olang_textcopy(ptr %t348, ptr %t334, i64 %t335)
  %t349 = getelementptr i8, ptr %t348, i64 %t335
  call void @olang_textcopy(ptr %t349, ptr %t338, i64 %t339)
  %t350 = getelementptr i8, ptr %t349, i64 %t339
  call void @olang_textcopy(ptr %t350, ptr %t341, i64 %t342)
  %t351 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t344, 1
  %t354 = extractvalue { i64, ptr } %t352, 0
  %t355 = extractvalue { i64, ptr } %t352, 1
  %t356 = mul i64 %t354, 1
  %t357 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t356)
  call void @llvm.memcpy.p0.p0.i64(ptr %t357, ptr %t355, i64 %t356, i1 false)
  %t358 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  %t362 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t317, { i64, ptr } %t359)
  store i64 %t362, ptr %l138
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t363 = load i64, ptr %l138, !tbaa !24
  store i64 %t363, ptr %rv
  br label %ret
bb112:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t366 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t365, 1
  %t369 = extractvalue { i64, ptr } %t365, 0
  %t370 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t372 = add i64 %t369, %t371
  %t374 = extractvalue { i64, ptr } %t366, 1
  %t375 = extractvalue { i64, ptr } %t366, 0
  %t376 = add i64 %t372, %t375
  %t377 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t376)
  call void @olang_textcopy(ptr %t377, ptr %t368, i64 %t369)
  %t378 = getelementptr i8, ptr %t377, i64 %t369
  call void @olang_textcopy(ptr %t378, ptr %t370, i64 %t371)
  %t379 = getelementptr i8, ptr %t378, i64 %t371
  call void @olang_textcopy(ptr %t379, ptr %t374, i64 %t375)
  %t380 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t377, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  %t384 = extractvalue { i64, ptr } %t381, 1
  %t385 = mul i64 %t383, 1
  %t386 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t385)
  call void @llvm.memcpy.p0.p0.i64(ptr %t386, ptr %t384, i64 %t385, i1 false)
  %t387 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t386, 1
  %t392 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t364, i32 2, { i64, ptr } %t388, i64 -1, i1 false, i64 0)
  store i64 %t392, ptr %l145
  br label %bb113
bb113:
  %t393 = load i64, ptr %l145, !tbaa !24
  store i64 %t393, ptr %l11, !tbaa !24
  br label %bb129
bb114:
  %t394 = load i1, ptr %l147, !tbaa !21
  %t395 = xor i1 %t394, true
  br i1 %t395, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s29
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/bindgen:gen", ptr %t397, i32 0, i32 1
  %t400 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t403 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %s0, ptr %v0, ptr %t399, { i64, ptr } %t400)
  %t404 = extractvalue { i32, { i64, ptr } } %t403, 1
  %t405 = extractvalue { i32, { i64, ptr } } %t403, 0
  store i32 %t405, ptr %l154
  %t406 = icmp ne i32 %t405, 0
  br i1 %t406, label %bb118, label %ok.407
ok.407:
  store { i64, ptr } %t404, ptr %l153
  br label %bb117
bb116:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t410 = load i64, ptr %l3, !tbaa !24
  %t411 = load i64, ptr %l4, !tbaa !24
  %t416 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enumType(ptr %v0, ptr %s0, ptr %t408, { i64, ptr } %t409, i64 %t410, i64 %t411)
  store i64 %t416, ptr %l171
  br label %bb127
bb117:
  %t417 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t417, ptr %l149, !tbaa !27
  br label %bb120
bb118:
  br label %bb119
bb119:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d192, i32 0, i32 1) }, ptr %l149, !tbaa !27
  br label %bb120
bb120:
  %t418 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t418, ptr %l12, !tbaa !27
  %t419 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t421 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s29, { i64, ptr } %t419, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d193, i32 0, i32 1) })
  store i1 %t421, ptr %l156
  br label %bb121
bb121:
  %t422 = load i1, ptr %l156, !tbaa !21
  br i1 %t422, label %bb122, label %bb123
bb122:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t425 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t426 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t428 = extractvalue { i64, ptr } %t424, 1
  %t429 = extractvalue { i64, ptr } %t424, 0
  %t430 = add i64 %t426, %t429
  %t431 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t432 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t433 = add i64 %t430, %t432
  %t434 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t433)
  call void @olang_textcopy(ptr %t434, ptr %t425, i64 %t426)
  %t435 = getelementptr i8, ptr %t434, i64 %t426
  call void @olang_textcopy(ptr %t435, ptr %t428, i64 %t429)
  %t436 = getelementptr i8, ptr %t435, i64 %t429
  call void @olang_textcopy(ptr %t436, ptr %t431, i64 %t432)
  %t437 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t434, 1
  %t440 = extractvalue { i64, ptr } %t438, 0
  %t441 = extractvalue { i64, ptr } %t438, 1
  %t442 = mul i64 %t440, 1
  %t443 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t442)
  call void @llvm.memcpy.p0.p0.i64(ptr %t443, ptr %t441, i64 %t442, i1 false)
  %t444 = insertvalue { i64, ptr } undef, i64 %t440, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr %t443, 1
  %t448 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t423, { i64, ptr } %t445)
  store i64 %t448, ptr %l161
  br label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t449 = load i64, ptr %l161, !tbaa !24
  store i64 %t449, ptr %rv
  br label %ret
bb125:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t452 = load i64, ptr %l2, !tbaa !24
  %t454 = add i64 %t452, 1
  %t458 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v0, ptr %t450, { i64, ptr } %t451, i64 %t454)
  store i64 %t458, ptr %l166
  br label %bb126
bb126:
  %t459 = load i64, ptr %l166, !tbaa !24
  store i64 %t459, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s29)
  br label %bb128
bb127:
  %t460 = load i64, ptr %l171, !tbaa !24
  store i64 %t460, ptr %l11, !tbaa !24
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s28)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s23)
  br label %bb130
bb130:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load ptr, ptr %l1, !tbaa !29
  %t463 = load i64, ptr %l11, !tbaa !24
  %t464 = load i1, ptr %l6, !tbaa !21
  %t465 = load i64, ptr %l2, !tbaa !24
  %t471 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edeclarator(ptr %v0, ptr %v1, ptr %t461, ptr %t462, i64 %t463, i1 %t464, i64 %t465)
  store i64 %t471, ptr %l177
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s0)
  %t472 = load i64, ptr %l177, !tbaa !24
  store i64 %t472, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/bindgen:ctype"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/bindgen:ctype"
  %l7 = alloca i64
  %l11 = alloca %"compiler/bindgen:ctype"
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l28 = alloca i64
  %l31 = alloca i1
  %l34 = alloca i32
  %l38 = alloca { i64, ptr }
  %l44 = alloca %"compiler/bindgen:ctype"
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i1
  %l63 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l78 = alloca i32
  %l81 = alloca { i64, ptr }
  %l86 = alloca i32
  %l89 = alloca i32
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 8
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/bindgen:ctype" %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l11
  store %"compiler/bindgen:ctype" %t8, ptr %l3
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 0
  %t10 = load i32, ptr %t9
  store i32 %t10, ptr %l4
  %t12 = load i32, ptr %l4
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb9
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d196, i32 0, i32 1) })
  store i1 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load i1, ptr %l16, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d197, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l17, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l22, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l23, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l22, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t46, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t47 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t48 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t47, 1
  store { i32, { i64, ptr } } %t48, ptr %rv
  br label %ret
bb9:
  %t49 = load i32, ptr %l4
  %t51 = trunc i64 2 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t59 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t54, { i64, ptr } %t56)
  store i64 %t59, ptr %l28
  br label %bb13
bb13:
  %t60 = load i64, ptr %l28, !tbaa !24
  store i64 %t60, ptr %l5, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t61, i64 %t62)
  store i1 %t65, ptr %l31
  br label %bb14
bb14:
  %t66 = load i1, ptr %l31, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s4, ptr %t69, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d198, i32 0, i32 1) })
  store i32 %t71, ptr %l34
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb18, label %ok.73
ok.73:
  br label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb19
bb18:
  %t74 = load i32, ptr %l34, !tbaa !23
  %t75 = lshr i32 %t74, 16
  %t76 = and i32 %t74, 65535
  %t77 = icmp eq i32 %t75, 1
  %t78 = select i1 %t77, i32 1, i32 0
  %t79 = icmp eq i32 %t74, 0
  %t80 = shl i32 %t78, 16
  %t81 = or i32 %t80, %t76
  %t82 = select i1 %t79, i32 0, i32 %t81
  call void @__olang_scope_close(ptr %s4)
  %t84 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t82, 0
  store { i32, { i64, ptr } } %t84, ptr %rv
  br label %ret
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %v1, ptr %t85, i64 %t86)
  store { i64, ptr } %t89, ptr %l38
  br label %bb21
bb21:
  %t90 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
bb22:
  %t92 = load i32, ptr %l4
  %t94 = trunc i64 3 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb52
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/bindgen:gen", ptr %t97, i32 0, i32 8
  %t100 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  %t104 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t99, i64 %t101)
  store %"compiler/bindgen:ctype" %t104, ptr %l44
  br label %bb26
bb26:
  %t105 = load %"compiler/bindgen:ctype", ptr %l44
  store %"compiler/bindgen:ctype" %t105, ptr %l6
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t108 = load i64, ptr %t107, !tbaa !24
  %t111 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisByte(ptr %v0, ptr %t106, i64 %t108)
  store i1 %t111, ptr %l47
  br label %bb27
bb27:
  %t112 = load i1, ptr %l47, !tbaa !21
  br i1 %t112, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d199, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t113, ptr %l49, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l50, !tbaa !24
  %t116 = load i64, ptr %l50, !tbaa !24
  %t117 = mul i64 %t116, 1
  %t118 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t117)
  %t119 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  store { i64, ptr } %t120, ptr %l51, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l50, !tbaa !24
  %t126 = mul i64 %t125, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t122, ptr %t124, i64 %t126, i1 false)
  %t127 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t127, ptr %l49, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t129 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t128, 1
  store { i32, { i64, ptr } } %t129, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t130 = getelementptr %"compiler/bindgen:ctype", ptr %l6, i32 0, i32 0
  %t131 = load i32, ptr %t130
  %t133 = trunc i64 2 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/bindgen:ctype", ptr %l6, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t141 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t136, { i64, ptr } %t138)
  store i64 %t141, ptr %l56
  br label %bb33
bb32:
  br label %bb50
bb33:
  %t142 = load i64, ptr %l56, !tbaa !24
  store i64 %t142, ptr %l7, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i64, ptr %l7, !tbaa !24
  %t147 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t143, i64 %t144)
  store i1 %t147, ptr %l59
  br label %bb34
bb34:
  %t148 = load i1, ptr %l59, !tbaa !21
  %t149 = xor i1 %t148, true
  br i1 %t149, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l7, !tbaa !24
  %t155 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s8, ptr %t151, i64 %t152)
  store { i64, ptr } %t155, ptr %l63
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t156 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t157, i64 %t158)
  %t163 = getelementptr i8, ptr %t162, i64 %t158
  call void @olang_textcopy(ptr %t163, ptr %t159, i64 %t160)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t162, 1
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  %t167 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t165, 1
  store { i32, { i64, ptr } } %t167, ptr %rv
  br label %ret
bb38:
  br i1 %a2, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  %t170 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 3
  %t171 = load i1, ptr %t170, !tbaa !21
  br i1 %t171, label %bb41, label %bb42
bb40:
  br label %bb45
bb41:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d201, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb43
bb42:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d202, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb43
bb43:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l7, !tbaa !24
  %t177 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s10, ptr %t173, i64 %t174)
  store { i64, ptr } %t177, ptr %l70
  br label %bb44
bb44:
  %t178 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = add i64 %t180, %t183
  %t185 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t187 = add i64 %t184, %t186
  %t188 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t187)
  call void @olang_textcopy(ptr %t188, ptr %t179, i64 %t180)
  %t189 = getelementptr i8, ptr %t188, i64 %t180
  call void @olang_textcopy(ptr %t189, ptr %t182, i64 %t183)
  %t190 = getelementptr i8, ptr %t189, i64 %t183
  call void @olang_textcopy(ptr %t190, ptr %t185, i64 %t186)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t188, 1
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s7)
  %t194 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t192, 1
  store { i32, { i64, ptr } } %t194, ptr %rv
  br label %ret
bb45:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l72, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i64, ptr %l7, !tbaa !24
  %t200 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s7, ptr %t196, i64 %t197)
  store { i64, ptr } %t200, ptr %l75
  br label %bb46
bb46:
  %t201 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t203 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = add i64 %t202, %t205
  %t207 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t209 = add i64 %t206, %t208
  %t210 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t209)
  call void @olang_textcopy(ptr %t210, ptr %t201, i64 %t202)
  %t211 = getelementptr i8, ptr %t210, i64 %t202
  call void @olang_textcopy(ptr %t211, ptr %t204, i64 %t205)
  %t212 = getelementptr i8, ptr %t211, i64 %t205
  call void @olang_textcopy(ptr %t212, ptr %t207, i64 %t208)
  %t213 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t210, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = extractvalue { i64, ptr } %t214, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t222 = load ptr, ptr %l72, !tbaa !29
  %t224 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s7, ptr %t222, { i64, ptr } %t221)
  store i32 %t224, ptr %l78
  %t225 = icmp ne i32 %t224, 0
  br i1 %t225, label %bb48, label %ok.226
ok.226:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t227 = load i32, ptr %l78, !tbaa !23
  %t228 = lshr i32 %t227, 16
  %t229 = and i32 %t227, 65535
  %t230 = icmp eq i32 %t228, 1
  %t231 = select i1 %t230, i32 1, i32 0
  %t232 = icmp eq i32 %t227, 0
  %t233 = shl i32 %t231, 16
  %t234 = or i32 %t233, %t229
  %t235 = select i1 %t232, i32 0, i32 %t234
  call void @__olang_scope_close(ptr %s7)
  %t237 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t235, 0
  store { i32, { i64, ptr } } %t237, ptr %rv
  br label %ret
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb50:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evoidRef(ptr %v0, ptr %v1, ptr %t238)
  store { i64, ptr } %t240, ptr %l81
  br label %bb51
bb51:
  %t241 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t242 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t241, 1
  store { i32, { i64, ptr } } %t242, ptr %rv
  br label %ret
bb52:
  %t243 = load i32, ptr %l4
  %t245 = trunc i64 6 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb59
bb55:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  %t253 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t248, { i64, ptr } %t250)
  store i32 %t253, ptr %l86
  %t254 = icmp ne i32 %t253, 0
  br i1 %t254, label %bb57, label %ok.255
ok.255:
  br label %bb56
bb56:
  br label %bb58
bb57:
  %t256 = load i32, ptr %l86, !tbaa !23
  %t257 = lshr i32 %t256, 16
  %t258 = and i32 %t256, 65535
  %t259 = icmp eq i32 %t257, 1
  %t260 = select i1 %t259, i32 1, i32 0
  %t261 = icmp eq i32 %t256, 0
  %t262 = shl i32 %t260, 16
  %t263 = or i32 %t262, %t258
  %t264 = select i1 %t261, i32 0, i32 %t263
  %t266 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t264, 0
  store { i32, { i64, ptr } } %t266, ptr %rv
  br label %ret
bb58:
  br label %bb67
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb66
bb62:
  store %olang.scope zeroinitializer, ptr %s14
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s14, ptr %t267, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d206, i32 0, i32 1) })
  store i32 %t269, ptr %l89
  %t270 = icmp ne i32 %t269, 0
  br i1 %t270, label %bb64, label %ok.271
ok.271:
  br label %bb63
bb63:
  br label %bb65
bb64:
  %t272 = load i32, ptr %l89, !tbaa !23
  %t273 = lshr i32 %t272, 16
  %t274 = and i32 %t272, 65535
  %t275 = icmp eq i32 %t273, 1
  %t276 = select i1 %t275, i32 1, i32 0
  %t277 = icmp eq i32 %t272, 0
  %t278 = shl i32 %t276, 16
  %t279 = or i32 %t278, %t274
  %t280 = select i1 %t277, i32 0, i32 %t279
  call void @__olang_scope_close(ptr %s14)
  %t282 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t280, 0
  store { i32, { i64, ptr } } %t282, ptr %rv
  br label %ret
bb65:
  call void @__olang_scope_close(ptr %s14)
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_383dad6bbc51ebc3_b2d1cf432887049f)
  unreachable
bb67:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d207, i32 0, i32 1) }, ptr %l91, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t283, ptr %l92, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  store i64 %t285, ptr %l93, !tbaa !24
  %t286 = load i64, ptr %l93, !tbaa !24
  %t287 = mul i64 %t286, 1
  %t288 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t287)
  %t289 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  store { i64, ptr } %t290, ptr %l94, !tbaa !27
  %t291 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = load i64, ptr %l93, !tbaa !24
  %t296 = mul i64 %t295, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t292, ptr %t294, i64 %t296, i1 false)
  %t297 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t297, ptr %l92, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t299 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t298, 1
  store { i32, { i64, ptr } } %t299, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evoidRef(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 12
  store i1 true, ptr %t3, !tbaa !21
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d208, i32 0, i32 1) }, ptr %l2, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/bindgen:cFunc"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/bindgen:cFunc"
  %l8 = alloca i64
  %l9 = alloca %"compiler/bindgen:ctype"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/bindgen:record"
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/bindgen:cFunc"
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca %"compiler/bindgen:record"
  %l30 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca i64
  %l40 = alloca i64
  %l45 = alloca %"compiler/bindgen:cFunc"
  %l55 = alloca i64
  %l57 = alloca i64
  %l62 = alloca %"compiler/bindgen:cFunc"
  %l65 = alloca i64
  %l69 = alloca %"compiler/bindgen:ctype"
  %l74 = alloca ptr
  %l78 = alloca %"compiler/bindgen:ctype"
  %l80 = alloca %"compiler/bindgen:ctype"
  %l83 = alloca i1
  %l87 = alloca %"compiler/bindgen:ctype"
  %l90 = alloca ptr
  %l94 = alloca %"compiler/bindgen:ctype"
  %l96 = alloca i64
  %l100 = alloca %"compiler/bindgen:record"
  %l109 = alloca %"std/prelude/text:StringBuilder"
  %l110 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca i64
  %l115 = alloca i64
  %l120 = alloca %"compiler/bindgen:cFunc"
  %l124 = alloca i1
  %l140 = alloca i1
  %l147 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i32
  %l167 = alloca %"std/prelude/text:StringBuilder"
  %l177 = alloca %"std/prelude/text:StringBuilder"
  %l178 = alloca %"std/prelude/text:StringBuilder"
  %l181 = alloca i64
  %l185 = alloca i64
  %l188 = alloca i64
  %l209 = alloca %"compiler/bindgen:record"
  %l211 = alloca i1
  %l212 = alloca i1
  %l215 = alloca i1
  %l217 = alloca i1
  %l222 = alloca i1
  %l223 = alloca ptr
  %l226 = alloca { i64, ptr }
  %l236 = alloca i64
  %l238 = alloca ptr
  %l240 = alloca { i64, ptr }
  %l243 = alloca ptr
  %l245 = alloca { i64, ptr }
  %l248 = alloca i64
  %l253 = alloca i64
  %l255 = alloca i64
  %l260 = alloca { i64, ptr }
  %l268 = alloca i64
  %l270 = alloca ptr
  %l272 = alloca { i64, ptr }
  %l277 = alloca i64
  %l282 = alloca i64
  %l284 = alloca i64
  %l289 = alloca { i64, ptr }
  %l297 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l299 = alloca i64
  %l300 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 5
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l38, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l40
  br label %bb2
bb2:
  %t9 = load i64, ptr %l38, !tbaa !24
  %t10 = load i64, ptr %l40, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/bindgen:cFunc" %t19, ptr %l45
  br label %bb6
bb6:
  %t20 = load %"compiler/bindgen:cFunc", ptr %l45
  store %"compiler/bindgen:cFunc" %t20, ptr %l4
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/bindgen:gen", ptr %t21, i32 0, i32 11
  %t24 = getelementptr %"compiler/bindgen:cFunc", ptr %l4, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t23, { i64, ptr } %t38, i64 0)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb1
bb9:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/bindgen:gen", ptr %t45, i32 0, i32 5
  store ptr %t47, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s6
  %t49 = load i64, ptr %l6, !tbaa !24
  store i64 %t49, ptr %l55, !tbaa !24
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l57
  br label %bb11
bb11:
  %t53 = load i64, ptr %l55, !tbaa !24
  %t54 = load i64, ptr %l57, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = call %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store %"compiler/bindgen:cFunc" %t63, ptr %l62
  br label %bb15
bb15:
  %t64 = load %"compiler/bindgen:cFunc", ptr %l62
  store %"compiler/bindgen:cFunc" %t64, ptr %l7
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/bindgen:cFunc", ptr %l7, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t70 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v0, ptr %t65, { i64, ptr } %t67, i64 0)
  store i64 %t70, ptr %l65
  br label %bb16
bb16:
  %t71 = load i64, ptr %l65, !tbaa !24
  store i64 %t71, ptr %l8, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/bindgen:gen", ptr %t72, i32 0, i32 8
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s6, ptr %t74, i64 %t75)
  store %"compiler/bindgen:ctype" %t78, ptr %l69
  br label %bb17
bb17:
  %t79 = getelementptr %"compiler/bindgen:ctype", ptr %l69, i32 0, i32 0
  %t80 = load i32, ptr %t79
  %t82 = trunc i64 5 to i32
  %t83 = icmp eq i32 %t80, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb19:
  br label %bb20
bb20:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/bindgen:gen", ptr %t87, i32 0, i32 8
  store ptr %t89, ptr %l74, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/bindgen:gen", ptr %t90, i32 0, i32 8
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s6, ptr %t92, i64 %t93)
  store %"compiler/bindgen:ctype" %t96, ptr %l78
  br label %bb21
bb21:
  %t97 = getelementptr %"compiler/bindgen:ctype", ptr %l78, i32 0, i32 2
  %t98 = load i64, ptr %t97, !tbaa !24
  %t99 = load ptr, ptr %l74, !tbaa !29
  %t101 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t99, i64 %t98)
  store %"compiler/bindgen:ctype" %t101, ptr %l80
  br label %bb22
bb22:
  %t102 = load %"compiler/bindgen:ctype", ptr %l80
  store %"compiler/bindgen:ctype" %t102, ptr %l9
  %t103 = getelementptr %"compiler/bindgen:ctype", ptr %l9, i32 0, i32 0
  %t104 = load i32, ptr %t103
  %t106 = trunc i64 3 to i32
  %t107 = icmp eq i32 %t104, %t106
  br i1 %t107, label %bb23, label %bb24
bb23:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/bindgen:gen", ptr %t109, i32 0, i32 8
  %t112 = getelementptr %"compiler/bindgen:ctype", ptr %l9, i32 0, i32 2
  %t113 = load i64, ptr %t112, !tbaa !24
  %t116 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s6, ptr %t111, i64 %t113)
  store %"compiler/bindgen:ctype" %t116, ptr %l87
  br label %bb25
bb24:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb26
bb25:
  %t117 = getelementptr %"compiler/bindgen:ctype", ptr %l87, i32 0, i32 0
  %t118 = load i32, ptr %t117
  %t120 = trunc i64 2 to i32
  %t121 = icmp eq i32 %t118, %t120
  store i1 %t121, ptr %l83, !tbaa !21
  br label %bb26
bb26:
  %t123 = load i1, ptr %l83, !tbaa !21
  br i1 %t123, label %bb27, label %bb28
bb27:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l90, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/bindgen:gen", ptr %t125, i32 0, i32 8
  %t128 = getelementptr %"compiler/bindgen:ctype", ptr %l9, i32 0, i32 2
  %t129 = load i64, ptr %t128, !tbaa !24
  %t132 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t127, i64 %t129)
  store %"compiler/bindgen:ctype" %t132, ptr %l94
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t133 = getelementptr %"compiler/bindgen:ctype", ptr %l94, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t135 = load ptr, ptr %l90, !tbaa !29
  %t137 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v0, ptr %t135, { i64, ptr } %t134)
  store i64 %t137, ptr %l96
  br label %bb30
bb30:
  %t138 = load i64, ptr %l96, !tbaa !24
  store i64 %t138, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/bindgen:gen", ptr %t139, i32 0, i32 2
  %t142 = load i64, ptr %l10, !tbaa !24
  %t145 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t141, i64 %t142)
  store %"compiler/bindgen:record" %t145, ptr %l100
  br label %bb31
bb31:
  %t146 = load %"compiler/bindgen:record", ptr %l100
  store %"compiler/bindgen:record" %t146, ptr %l12
  %t147 = load i64, ptr %l11, !tbaa !24
  %t149 = getelementptr %"compiler/bindgen:record", ptr %l12, i32 0, i32 9
  store i64 %t147, ptr %t149, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/bindgen:gen", ptr %t150, i32 0, i32 2
  %t153 = load i64, ptr %l10, !tbaa !24
  %t154 = load %"compiler/bindgen:record", ptr %l12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v0, ptr %t152, i64 %t153, %"compiler/bindgen:record" %t154)
  br label %bb32
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  %t158 = load i64, ptr %l6, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l6, !tbaa !24
  br label %bb10
bb35:
  %t162 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecords(ptr %v0, ptr %t162)
  br label %bb36
bb36:
  %t164 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t164, ptr %l109
  br label %bb37
bb37:
  %t165 = load %"std/prelude/text:StringBuilder", ptr %l109
  store %"std/prelude/text:StringBuilder" %t165, ptr %l13
  %t166 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t166, ptr %l110
  br label %bb38
bb38:
  %t167 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t167, ptr %l14
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/bindgen:gen", ptr %t168, i32 0, i32 5
  store ptr %t170, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t172 = load i64, ptr %l16, !tbaa !24
  store i64 %t172, ptr %l113, !tbaa !24
  %t173 = load ptr, ptr %l15, !tbaa !29
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %t173)
  store i64 %t175, ptr %l115
  br label %bb40
bb40:
  %t176 = load i64, ptr %l113, !tbaa !24
  %t177 = load i64, ptr %l115, !tbaa !24
  %t178 = icmp slt i64 %t176, %t177
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s11)
  br label %bb69
bb42:
  br label %bb43
bb43:
  %t182 = load ptr, ptr %l15, !tbaa !29
  %t183 = load i64, ptr %l16, !tbaa !24
  %t186 = call %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t182, i64 %t183)
  store %"compiler/bindgen:cFunc" %t186, ptr %l120
  br label %bb44
bb44:
  %t187 = load %"compiler/bindgen:cFunc", ptr %l120
  store %"compiler/bindgen:cFunc" %t187, ptr %l17
  %t188 = getelementptr %"compiler/bindgen:cFunc", ptr %l17, i32 0, i32 0
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  %t194 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %s0, ptr %v0, ptr %l14, { i64, ptr } %t189)
  store i1 %t194, ptr %l124
  br label %bb45
bb45:
  %t195 = load i1, ptr %l124, !tbaa !21
  br i1 %t195, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb47:
  br label %bb48
bb48:
  %t196 = getelementptr %"compiler/bindgen:cFunc", ptr %l17, i32 0, i32 3
  %t197 = load i1, ptr %t196, !tbaa !21
  br i1 %t197, label %bb49, label %bb50
bb49:
  %t199 = getelementptr %"compiler/bindgen:cFunc", ptr %l17, i32 0, i32 0
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = extractvalue { i64, ptr } %t200, 0
  %t204 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t202, i64 %t203)
  %t205 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = extractvalue { i64, ptr } %t206, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %s0, ptr %s0, ptr %l14, { i64, ptr } %t213, i64 0)
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/bindgen:gen", ptr %t216, i32 0, i32 10
  %t219 = getelementptr %"compiler/bindgen:cFunc", ptr %l17, i32 0, i32 0
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 1
  %t223 = extractvalue { i64, ptr } %t220, 0
  %t224 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t227 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t226)
  call void @olang_textcopy(ptr %t227, ptr %t222, i64 %t223)
  %t228 = getelementptr i8, ptr %t227, i64 %t223
  call void @olang_textcopy(ptr %t228, ptr %t224, i64 %t225)
  %t229 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t227, 1
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t233 = extractvalue { i64, ptr } %t230, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t218, { i64, ptr } %t237)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb53:
  %t240 = getelementptr %"compiler/bindgen:cFunc", ptr %l17, i32 0, i32 0
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 1
  %t244 = extractvalue { i64, ptr } %t241, 0
  %t245 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t244)
  call void @olang_textcopy(ptr %t245, ptr %t243, i64 %t244)
  %t246 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t250 = extractvalue { i64, ptr } %t247, 1
  %t251 = mul i64 %t249, 1
  %t252 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t251)
  call void @llvm.memcpy.p0.p0.i64(ptr %t252, ptr %t250, i64 %t251, i1 false)
  %t253 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t252, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %s0, ptr %s0, ptr %l14, { i64, ptr } %t254, i64 0)
  br label %bb54
bb54:
  %t257 = getelementptr %"compiler/bindgen:cFunc", ptr %l17, i32 0, i32 0
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  %t260 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t258)
  store i1 %t260, ptr %l140
  br label %bb55
bb55:
  %t261 = load i1, ptr %l140, !tbaa !21
  %t262 = xor i1 %t261, true
  br i1 %t262, label %bb56, label %bb57
bb56:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/bindgen:gen", ptr %t264, i32 0, i32 10
  %t267 = getelementptr %"compiler/bindgen:cFunc", ptr %l17, i32 0, i32 0
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t268, 1
  %t271 = extractvalue { i64, ptr } %t268, 0
  %t272 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t274 = add i64 %t271, %t273
  %t275 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t274)
  call void @olang_textcopy(ptr %t275, ptr %t270, i64 %t271)
  %t276 = getelementptr i8, ptr %t275, i64 %t271
  call void @olang_textcopy(ptr %t276, ptr %t272, i64 %t273)
  %t277 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t275, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = extractvalue { i64, ptr } %t278, 1
  %t282 = mul i64 %t280, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t282)
  call void @llvm.memcpy.p0.p0.i64(ptr %t283, ptr %t281, i64 %t282, i1 false)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t266, { i64, ptr } %t285)
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb59:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t291 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efunction(ptr %v0, ptr %s11, ptr %s11, ptr %t288, ptr %l17)
  %t292 = extractvalue { i32, { i64, ptr } } %t291, 1
  %t293 = extractvalue { i32, { i64, ptr } } %t291, 0
  store i32 %t293, ptr %l151
  %t294 = icmp ne i32 %t293, 0
  br i1 %t294, label %bb61, label %ok.295
ok.295:
  store { i64, ptr } %t292, ptr %l150
  br label %bb60
bb60:
  %t296 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t296, ptr %l147, !tbaa !27
  br label %bb66
bb61:
  %t297 = load i32, ptr %l151, !tbaa !23
  %t298 = ashr i32 %t297, 16
  %t300 = icmp eq i32 %t298, 1
  br i1 %t300, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_23d1865e1592def5_3b70fe728274d559)
  unreachable
bb64:
  call void @__olang_ert_req_clear()
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/bindgen:gen", ptr %t302, i32 0, i32 10
  %t305 = getelementptr %"compiler/bindgen:cFunc", ptr %l17, i32 0, i32 0
  %t306 = load { i64, ptr }, ptr %t305, !tbaa !27
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/bindgen:gen", ptr %t307, i32 0, i32 13
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t306, 1
  %t313 = extractvalue { i64, ptr } %t306, 0
  %t314 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t315 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t316 = add i64 %t313, %t315
  %t318 = extractvalue { i64, ptr } %t310, 1
  %t319 = extractvalue { i64, ptr } %t310, 0
  %t320 = add i64 %t316, %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t320)
  call void @olang_textcopy(ptr %t321, ptr %t312, i64 %t313)
  %t322 = getelementptr i8, ptr %t321, i64 %t313
  call void @olang_textcopy(ptr %t322, ptr %t314, i64 %t315)
  %t323 = getelementptr i8, ptr %t322, i64 %t315
  call void @olang_textcopy(ptr %t323, ptr %t318, i64 %t319)
  %t324 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t321, 1
  %t327 = extractvalue { i64, ptr } %t325, 0
  %t328 = extractvalue { i64, ptr } %t325, 1
  %t329 = mul i64 %t327, 1
  %t330 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t329)
  call void @llvm.memcpy.p0.p0.i64(ptr %t330, ptr %t328, i64 %t329, i1 false)
  %t331 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t330, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t304, { i64, ptr } %t332)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb66:
  %t335 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t335, 1
  %t339 = extractvalue { i64, ptr } %t335, 0
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t341 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t342 = add i64 %t339, %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t342)
  call void @olang_textcopy(ptr %t343, ptr %t338, i64 %t339)
  %t344 = getelementptr i8, ptr %t343, i64 %t339
  call void @olang_textcopy(ptr %t344, ptr %t340, i64 %t341)
  %t345 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t343, 1
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t349 = extractvalue { i64, ptr } %t346, 1
  %t350 = mul i64 %t348, 1
  %t351 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t350)
  call void @llvm.memcpy.p0.p0.i64(ptr %t351, ptr %t349, i64 %t350, i1 false)
  %t352 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t351, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %l13, { i64, ptr } %t353)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb68:
  %t356 = load i64, ptr %l16, !tbaa !24
  %t358 = add i64 %t356, 1
  store i64 %t358, ptr %l16, !tbaa !24
  br label %bb39
bb69:
  %t360 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t360, ptr %l167
  br label %bb70
bb70:
  %t361 = load %"std/prelude/text:StringBuilder", ptr %l167
  store %"std/prelude/text:StringBuilder" %t361, ptr %l20
  %t363 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t366 = extractvalue { i64, ptr } %a1, 1
  %t367 = extractvalue { i64, ptr } %a1, 0
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t363, i64 %t364)
  %t373 = getelementptr i8, ptr %t372, i64 %t364
  call void @olang_textcopy(ptr %t373, ptr %t366, i64 %t367)
  %t374 = getelementptr i8, ptr %t373, i64 %t367
  call void @olang_textcopy(ptr %t374, ptr %t369, i64 %t370)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t372, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = extractvalue { i64, ptr } %t376, 1
  %t380 = mul i64 %t378, 1
  %t381 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t380)
  call void @llvm.memcpy.p0.p0.i64(ptr %t381, ptr %t379, i64 %t380, i1 false)
  %t382 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr %t381, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l20, { i64, ptr } %t383)
  br label %bb71
bb71:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l20, { i64, ptr } { i64 99, ptr getelementptr inbounds (<{ i64, [99 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb72
bb72:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l20, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d216, i32 0, i32 1) })
  br label %bb73
bb73:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/bindgen:gen", ptr %t388, i32 0, i32 12
  %t391 = load i1, ptr %t390, !tbaa !21
  br i1 %t391, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s24, ptr %l20, { i64, ptr } { i64 109, ptr getelementptr inbounds (<{ i64, [109 x i8] }>, ptr @.d217, i32 0, i32 1) })
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_scope_close(ptr %s24)
  br label %bb77
bb77:
  %t394 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t394, ptr %l177
  br label %bb78
bb78:
  %t395 = load %"std/prelude/text:StringBuilder", ptr %l177
  store %"std/prelude/text:StringBuilder" %t395, ptr %l21
  %t396 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t396, ptr %l178
  br label %bb79
bb79:
  %t397 = load %"std/prelude/text:StringBuilder", ptr %l178
  store %"std/prelude/text:StringBuilder" %t397, ptr %l22
  store i64 0, ptr %l23, !tbaa !24
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/bindgen:gen", ptr %t398, i32 0, i32 2
  %t402 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t400)
  store i64 %t402, ptr %l181
  br label %bb80
bb80:
  %t403 = load i64, ptr %l181, !tbaa !24
  store i64 %t403, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t404 = load i64, ptr %l24, !tbaa !24
  %t405 = load i64, ptr %l23, !tbaa !24
  %t408 = icmp sgt i64 %t404, %t405
  br i1 %t408, label %bb81, label %bb82
bb81:
  %t410 = load i64, ptr %l25, !tbaa !24
  %t412 = icmp sgt i64 %t410, 0
  br i1 %t412, label %bb83, label %bb84
bb82:
  store i64 0, ptr %l185, !tbaa !24
  br label %bb86
bb83:
  %t414 = load i64, ptr %l24, !tbaa !24
  %t415 = load i64, ptr %l23, !tbaa !24
  %t418 = sub i64 %t414, %t415
  %t419 = load i64, ptr %l25, !tbaa !24
  %t422 = add i64 %t418, %t419
  %t424 = sub i64 %t422, 1
  %t425 = load i64, ptr %l25, !tbaa !24
  %t428 = sdiv i64 %t424, %t425
  store i64 %t428, ptr %l188, !tbaa !24
  br label %bb85
bb84:
  store i64 0, ptr %l188, !tbaa !24
  br label %bb85
bb85:
  %t430 = load i64, ptr %l188, !tbaa !24
  store i64 %t430, ptr %l185, !tbaa !24
  br label %bb86
bb86:
  %t431 = load i64, ptr %l185, !tbaa !24
  store i64 %t431, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb87
bb87:
  store %olang.scope zeroinitializer, ptr %s26
  %t432 = load i64, ptr %l27, !tbaa !24
  %t433 = load i64, ptr %l26, !tbaa !24
  %t436 = icmp slt i64 %t432, %t433
  %t438 = xor i1 %t436, true
  br i1 %t438, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s26)
  br label %bb113
bb89:
  br label %bb90
bb90:
  %t440 = load i64, ptr %l23, !tbaa !24
  %t441 = load i64, ptr %l27, !tbaa !24
  %t442 = load i64, ptr %l25, !tbaa !24
  %t445 = mul i64 %t441, %t442
  %t448 = add i64 %t440, %t445
  store i64 %t448, ptr %l28, !tbaa !24
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/bindgen:gen", ptr %t450, i32 0, i32 2
  %t453 = load i64, ptr %l28, !tbaa !24
  %t456 = call %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t452, i64 %t453)
  store %"compiler/bindgen:record" %t456, ptr %l209
  br label %bb91
bb91:
  %t457 = load %"compiler/bindgen:record", ptr %l209
  store %"compiler/bindgen:record" %t457, ptr %l29
  %t458 = getelementptr %"compiler/bindgen:record", ptr %l29, i32 0, i32 7
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  %t461 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s26, { i64, ptr } %t459, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d218, i32 0, i32 1) })
  store i1 %t461, ptr %l211
  br label %bb92
bb92:
  %t462 = load i1, ptr %l211, !tbaa !21
  br i1 %t462, label %bb93, label %bb94
bb93:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb101
bb94:
  %t463 = getelementptr %"compiler/bindgen:record", ptr %l29, i32 0, i32 8
  %t464 = load i1, ptr %t463, !tbaa !21
  %t466 = xor i1 %t464, true
  br i1 %t466, label %bb95, label %bb96
bb95:
  %t468 = getelementptr %"compiler/bindgen:record", ptr %l29, i32 0, i32 6
  %t469 = load i1, ptr %t468, !tbaa !21
  br i1 %t469, label %bb97, label %bb98
bb96:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb100
bb97:
  %t471 = getelementptr %"compiler/bindgen:record", ptr %l29, i32 0, i32 2
  %t472 = load i1, ptr %t471, !tbaa !21
  store i1 %t472, ptr %l217, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l217, !tbaa !21
  br label %bb99
bb99:
  %t474 = load i1, ptr %l217, !tbaa !21
  %t475 = xor i1 %t474, true
  store i1 %t475, ptr %l215, !tbaa !21
  br label %bb100
bb100:
  %t477 = load i1, ptr %l215, !tbaa !21
  store i1 %t477, ptr %l212, !tbaa !21
  br label %bb101
bb101:
  %t478 = load i1, ptr %l212, !tbaa !21
  br i1 %t478, label %bb102, label %bb103
bb102:
  call void @__olang_scope_close(ptr %s26)
  br label %bb112
bb103:
  br label %bb104
bb104:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load i64, ptr %l28, !tbaa !24
  %t483 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t479, i64 %t480)
  store i1 %t483, ptr %l222
  br label %bb105
bb105:
  %t484 = load i1, ptr %l222, !tbaa !21
  br i1 %t484, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s28
  store ptr %l22, ptr %l223, !tbaa !29
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load i64, ptr %l28, !tbaa !24
  %t489 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2estructDecl(ptr %v0, ptr %s28, ptr %t485, i64 %t486)
  store { i64, ptr } %t489, ptr %l226
  br label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s30
  %t490 = getelementptr %"compiler/bindgen:record", ptr %l29, i32 0, i32 7
  %t491 = load { i64, ptr }, ptr %t490, !tbaa !27
  %t492 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t493 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t495 = extractvalue { i64, ptr } %t491, 1
  %t496 = extractvalue { i64, ptr } %t491, 0
  %t497 = add i64 %t493, %t496
  %t498 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t499 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t500 = add i64 %t497, %t499
  %t501 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t500)
  call void @olang_textcopy(ptr %t501, ptr %t492, i64 %t493)
  %t502 = getelementptr i8, ptr %t501, i64 %t493
  call void @olang_textcopy(ptr %t502, ptr %t495, i64 %t496)
  %t503 = getelementptr i8, ptr %t502, i64 %t496
  call void @olang_textcopy(ptr %t503, ptr %t498, i64 %t499)
  %t504 = insertvalue { i64, ptr } undef, i64 %t500, 0
  %t505 = insertvalue { i64, ptr } %t504, ptr %t501, 1
  %t507 = extractvalue { i64, ptr } %t505, 0
  %t508 = extractvalue { i64, ptr } %t505, 1
  %t509 = mul i64 %t507, 1
  %t510 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t509)
  call void @llvm.memcpy.p0.p0.i64(ptr %t510, ptr %t508, i64 %t509, i1 false)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t510, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s30, ptr %l21, { i64, ptr } %t512)
  br label %bb110
bb108:
  %t515 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t516 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t517 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t518 = extractvalue { i64, ptr } %t517, 1
  %t519 = extractvalue { i64, ptr } %t517, 0
  %t520 = add i64 %t516, %t519
  %t521 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t520)
  call void @olang_textcopy(ptr %t521, ptr %t515, i64 %t516)
  %t522 = getelementptr i8, ptr %t521, i64 %t516
  call void @olang_textcopy(ptr %t522, ptr %t518, i64 %t519)
  %t523 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t524 = insertvalue { i64, ptr } %t523, ptr %t521, 1
  %t526 = extractvalue { i64, ptr } %t524, 0
  %t527 = extractvalue { i64, ptr } %t524, 1
  %t528 = mul i64 %t526, 1
  %t529 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t528)
  call void @llvm.memcpy.p0.p0.i64(ptr %t529, ptr %t527, i64 %t528, i1 false)
  %t530 = insertvalue { i64, ptr } undef, i64 %t526, 0
  %t531 = insertvalue { i64, ptr } %t530, ptr %t529, 1
  %t532 = load ptr, ptr %l223, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s28, ptr %t532, { i64, ptr } %t531)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s28)
  br label %bb111
bb110:
  call void @__olang_scope_close(ptr %s30)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s26)
  br label %bb112
bb112:
  %t534 = load i64, ptr %l27, !tbaa !24
  %t536 = add i64 %t534, 1
  store i64 %t536, ptr %l27, !tbaa !24
  br label %bb87
bb113:
  %t539 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l21)
  store i64 %t539, ptr %l236
  br label %bb114
bb114:
  %t540 = load i64, ptr %l236, !tbaa !24
  %t541 = icmp sgt i64 %t540, 0
  br i1 %t541, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s33
  store ptr %l20, ptr %l238, !tbaa !29
  %t544 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s33, ptr %l21)
  store { i64, ptr } %t544, ptr %l240
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t545 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t546 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t547 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t547, 1
  %t549 = extractvalue { i64, ptr } %t547, 0
  %t550 = add i64 %t546, %t549
  %t551 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t550)
  call void @olang_textcopy(ptr %t551, ptr %t545, i64 %t546)
  %t552 = getelementptr i8, ptr %t551, i64 %t546
  call void @olang_textcopy(ptr %t552, ptr %t548, i64 %t549)
  %t553 = insertvalue { i64, ptr } undef, i64 %t550, 0
  %t554 = insertvalue { i64, ptr } %t553, ptr %t551, 1
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t557 = extractvalue { i64, ptr } %t554, 1
  %t558 = mul i64 %t556, 1
  %t559 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t558)
  call void @llvm.memcpy.p0.p0.i64(ptr %t559, ptr %t557, i64 %t558, i1 false)
  %t560 = insertvalue { i64, ptr } undef, i64 %t556, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t559, 1
  %t562 = load ptr, ptr %l238, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s33, ptr %t562, { i64, ptr } %t561)
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s33)
  br label %bb119
bb119:
  store ptr %l20, ptr %l243, !tbaa !29
  %t565 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l22)
  store { i64, ptr } %t565, ptr %l245
  br label %bb120
bb120:
  %t566 = load ptr, ptr %l243, !tbaa !29
  %t567 = load { i64, ptr }, ptr %l245, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t566, { i64, ptr } %t567)
  br label %bb121
bb121:
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = getelementptr %"compiler/bindgen:gen", ptr %t568, i32 0, i32 6
  %t572 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t570)
  store i64 %t572, ptr %l248
  br label %bb122
bb122:
  %t573 = load i64, ptr %l248, !tbaa !24
  %t574 = icmp sgt i64 %t573, 0
  br i1 %t574, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s35
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s35, ptr %l20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d223, i32 0, i32 1) })
  br label %bb125
bb124:
  br label %bb135
bb125:
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t579 = getelementptr %"compiler/bindgen:gen", ptr %t577, i32 0, i32 6
  store ptr %t579, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb126
bb126:
  store %olang.scope zeroinitializer, ptr %s37
  %t581 = load i64, ptr %l31, !tbaa !24
  store i64 %t581, ptr %l253, !tbaa !24
  %t582 = load ptr, ptr %l30, !tbaa !29
  %t584 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t582)
  store i64 %t584, ptr %l255
  br label %bb127
bb127:
  %t585 = load i64, ptr %l253, !tbaa !24
  %t586 = load i64, ptr %l255, !tbaa !24
  %t587 = icmp slt i64 %t585, %t586
  %t589 = xor i1 %t587, true
  br i1 %t589, label %bb128, label %bb129
bb128:
  call void @__olang_scope_close(ptr %s37)
  br label %bb134
bb129:
  br label %bb130
bb130:
  %t591 = load ptr, ptr %l30, !tbaa !29
  %t592 = load i64, ptr %l31, !tbaa !24
  %t595 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t591, i64 %t592)
  store { i64, ptr } %t595, ptr %l260
  br label %bb131
bb131:
  %t596 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t596, 1
  %t600 = extractvalue { i64, ptr } %t596, 0
  %t601 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t602 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t603 = add i64 %t600, %t602
  %t604 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t603)
  call void @olang_textcopy(ptr %t604, ptr %t599, i64 %t600)
  %t605 = getelementptr i8, ptr %t604, i64 %t600
  call void @olang_textcopy(ptr %t605, ptr %t601, i64 %t602)
  %t606 = insertvalue { i64, ptr } undef, i64 %t603, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t604, 1
  %t609 = extractvalue { i64, ptr } %t607, 0
  %t610 = extractvalue { i64, ptr } %t607, 1
  %t611 = mul i64 %t609, 1
  %t612 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t611)
  call void @llvm.memcpy.p0.p0.i64(ptr %t612, ptr %t610, i64 %t611, i1 false)
  %t613 = insertvalue { i64, ptr } undef, i64 %t609, 0
  %t614 = insertvalue { i64, ptr } %t613, ptr %t612, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s37, ptr %l20, { i64, ptr } %t614)
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s37)
  br label %bb133
bb133:
  %t617 = load i64, ptr %l31, !tbaa !24
  %t619 = add i64 %t617, 1
  store i64 %t619, ptr %l31, !tbaa !24
  br label %bb126
bb134:
  call void @__olang_scope_close(ptr %s35)
  br label %bb135
bb135:
  %t622 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l13)
  store i64 %t622, ptr %l268
  br label %bb136
bb136:
  %t623 = load i64, ptr %l268, !tbaa !24
  %t624 = icmp sgt i64 %t623, 0
  br i1 %t624, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s40
  store ptr %l20, ptr %l270, !tbaa !29
  %t627 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s40, ptr %l13)
  store { i64, ptr } %t627, ptr %l272
  br label %bb139
bb138:
  br label %bb141
bb139:
  %t628 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t629 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t630 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t631 = extractvalue { i64, ptr } %t630, 1
  %t632 = extractvalue { i64, ptr } %t630, 0
  %t633 = add i64 %t629, %t632
  %t634 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t633)
  call void @olang_textcopy(ptr %t634, ptr %t628, i64 %t629)
  %t635 = getelementptr i8, ptr %t634, i64 %t629
  call void @olang_textcopy(ptr %t635, ptr %t631, i64 %t632)
  %t636 = insertvalue { i64, ptr } undef, i64 %t633, 0
  %t637 = insertvalue { i64, ptr } %t636, ptr %t634, 1
  %t639 = extractvalue { i64, ptr } %t637, 0
  %t640 = extractvalue { i64, ptr } %t637, 1
  %t641 = mul i64 %t639, 1
  %t642 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t641)
  call void @llvm.memcpy.p0.p0.i64(ptr %t642, ptr %t640, i64 %t641, i1 false)
  %t643 = insertvalue { i64, ptr } undef, i64 %t639, 0
  %t644 = insertvalue { i64, ptr } %t643, ptr %t642, 1
  %t645 = load ptr, ptr %l270, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s40, ptr %t645, { i64, ptr } %t644)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s40)
  br label %bb141
bb141:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"compiler/bindgen:gen", ptr %t647, i32 0, i32 10
  %t651 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t649)
  store i64 %t651, ptr %l277
  br label %bb142
bb142:
  %t652 = load i64, ptr %l277, !tbaa !24
  %t653 = icmp sgt i64 %t652, 0
  br i1 %t653, label %bb143, label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s42
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s42, ptr %l20, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d226, i32 0, i32 1) })
  br label %bb145
bb144:
  br label %bb155
bb145:
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t658 = getelementptr %"compiler/bindgen:gen", ptr %t656, i32 0, i32 10
  store ptr %t658, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s44
  %t660 = load i64, ptr %l34, !tbaa !24
  store i64 %t660, ptr %l282, !tbaa !24
  %t661 = load ptr, ptr %l33, !tbaa !29
  %t663 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t661)
  store i64 %t663, ptr %l284
  br label %bb147
bb147:
  %t664 = load i64, ptr %l282, !tbaa !24
  %t665 = load i64, ptr %l284, !tbaa !24
  %t666 = icmp slt i64 %t664, %t665
  %t668 = xor i1 %t666, true
  br i1 %t668, label %bb148, label %bb149
bb148:
  call void @__olang_scope_close(ptr %s44)
  br label %bb154
bb149:
  br label %bb150
bb150:
  %t670 = load ptr, ptr %l33, !tbaa !29
  %t671 = load i64, ptr %l34, !tbaa !24
  %t674 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t670, i64 %t671)
  store { i64, ptr } %t674, ptr %l289
  br label %bb151
bb151:
  %t675 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t677 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t678 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t680 = extractvalue { i64, ptr } %t675, 1
  %t681 = extractvalue { i64, ptr } %t675, 0
  %t682 = add i64 %t678, %t681
  %t683 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t684 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t685 = add i64 %t682, %t684
  %t686 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t685)
  call void @olang_textcopy(ptr %t686, ptr %t677, i64 %t678)
  %t687 = getelementptr i8, ptr %t686, i64 %t678
  call void @olang_textcopy(ptr %t687, ptr %t680, i64 %t681)
  %t688 = getelementptr i8, ptr %t687, i64 %t681
  call void @olang_textcopy(ptr %t688, ptr %t683, i64 %t684)
  %t689 = insertvalue { i64, ptr } undef, i64 %t685, 0
  %t690 = insertvalue { i64, ptr } %t689, ptr %t686, 1
  %t692 = extractvalue { i64, ptr } %t690, 0
  %t693 = extractvalue { i64, ptr } %t690, 1
  %t694 = mul i64 %t692, 1
  %t695 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t694)
  call void @llvm.memcpy.p0.p0.i64(ptr %t695, ptr %t693, i64 %t694, i1 false)
  %t696 = insertvalue { i64, ptr } undef, i64 %t692, 0
  %t697 = insertvalue { i64, ptr } %t696, ptr %t695, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s44, ptr %l20, { i64, ptr } %t697)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s44)
  br label %bb153
bb153:
  %t700 = load i64, ptr %l34, !tbaa !24
  %t702 = add i64 %t700, 1
  store i64 %t702, ptr %l34, !tbaa !24
  br label %bb146
bb154:
  call void @__olang_scope_close(ptr %s42)
  br label %bb155
bb155:
  %t705 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l20)
  store { i64, ptr } %t705, ptr %l297
  br label %bb156
bb156:
  %t706 = load { i64, ptr }, ptr %l297, !tbaa !27
  store { i64, ptr } %t706, ptr %l298, !tbaa !27
  %t707 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t708 = extractvalue { i64, ptr } %t707, 0
  store i64 %t708, ptr %l299, !tbaa !24
  %t709 = load i64, ptr %l299, !tbaa !24
  %t710 = mul i64 %t709, 1
  %t711 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t710)
  %t712 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t711, 1
  store { i64, ptr } %t713, ptr %l300, !tbaa !27
  %t714 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t715 = load ptr, ptr %t714, !tbaa !27
  %t716 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t717 = load ptr, ptr %t716, !tbaa !27
  %t718 = load i64, ptr %l299, !tbaa !24
  %t719 = mul i64 %t718, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t715, ptr %t717, i64 %t719, i1 false)
  %t720 = load { i64, ptr }, ptr %l300, !tbaa !27
  store { i64, ptr } %t720, ptr %l298, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t721 = load { i64, ptr }, ptr %l298, !tbaa !27
  store { i64, ptr } %t721, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %lp6 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %v0, ptr %v1, ptr %v1, ptr %t1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d229, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t4, ptr %lp1
  %t5 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t6 = load ptr, ptr %lp1
  store { i64, ptr } %t5, ptr %t6, !tbaa !27
  %t7 = load ptr, ptr %lp1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d230, i32 0, i32 1) })
  store i1 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i1, ptr %l10, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %lp1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t15, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %v0, ptr %s2, ptr %t17)
  store { i64, ptr } %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = mul i64 %t21, 8
  %t24 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l22, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr ptr, ptr %t44, i64 %t41
  %t46 = load ptr, ptr %t45, !tbaa !39
  %t50 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s2, ptr %v1, ptr %t46)
  store { i64, ptr } %t50, ptr %l26
  br label %bb11
bb11:
  %t51 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t51, ptr %lp6
  %t52 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t53 = load ptr, ptr %lp6
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load ptr, ptr %lp6
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t55, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d231, i32 0, i32 1) })
  store i1 %t57, ptr %l28
  br label %bb12
bb12:
  %t58 = load i1, ptr %l28, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = load ptr, ptr %lp6
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t62, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l3, !tbaa !24
  br label %bb7
bb17:
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d232, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t68, ptr %l34, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l35, !tbaa !24
  %t71 = load i64, ptr %l35, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l36, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l35, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t82, ptr %l34, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ectokens(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store i64 0, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t11 = icmp slt i64 %t5, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb57
bb4:
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l3, !tbaa !22
  %t23 = load i8, ptr %l3, !tbaa !22
  %t25 = icmp eq i8 %t23, 32
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb56
bb7:
  br label %bb8
bb8:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l4, !tbaa !24
  %t35 = load i8, ptr %l3, !tbaa !22
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t35)
  store i1 %t37, ptr %l21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb13
bb11:
  %t39 = load i8, ptr %l3, !tbaa !22
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t39)
  store i1 %t41, ptr %l24
  br label %bb12
bb12:
  %t42 = load i1, ptr %l24, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb16
bb15:
  %t44 = load i8, ptr %l3, !tbaa !22
  %t46 = icmp eq i8 %t44, 95
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  %t49 = load i8, ptr %l3, !tbaa !22
  %t51 = icmp eq i8 %t49, 46
  br i1 %t51, label %bb36, label %bb37
bb19:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t59 = icmp slt i64 %t53, %t56
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  %t62 = load i64, ptr %l4, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i8, ptr %t65, i64 %t62
  %t67 = load i8, ptr %t66, !tbaa !32
  %t69 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t67)
  store i1 %t69, ptr %l36
  br label %bb22
bb21:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb30
bb22:
  %t70 = load i1, ptr %l36, !tbaa !21
  br i1 %t70, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb26
bb24:
  %t71 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t71, ptr %l38, !tbaa !27
  %t72 = load i64, ptr %l4, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i8, ptr %t75, i64 %t72
  %t77 = load i8, ptr %t76, !tbaa !32
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t77)
  store i1 %t79, ptr %l41
  br label %bb25
bb25:
  %t80 = load i1, ptr %l41, !tbaa !21
  store i1 %t80, ptr %l37, !tbaa !21
  br label %bb26
bb26:
  %t81 = load i1, ptr %l37, !tbaa !21
  br i1 %t81, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb29
bb28:
  %t82 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t82, ptr %l43, !tbaa !27
  %t83 = load i64, ptr %l4, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i8, ptr %t86, i64 %t83
  %t88 = load i8, ptr %t87, !tbaa !32
  %t90 = icmp eq i8 %t88, 95
  store i1 %t90, ptr %l42, !tbaa !21
  br label %bb29
bb29:
  %t92 = load i1, ptr %l42, !tbaa !21
  store i1 %t92, ptr %l32, !tbaa !21
  br label %bb30
bb30:
  %t93 = load i1, ptr %l32, !tbaa !21
  %t94 = xor i1 %t93, true
  br i1 %t94, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l4, !tbaa !24
  br label %bb34
bb34:
  br label %bb19
bb35:
  br label %bb48
bb36:
  br label %bb38
bb37:
  br label %bb47
bb38:
  %t100 = load i64, ptr %l4, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t106 = icmp slt i64 %t100, %t103
  br i1 %t106, label %bb39, label %bb40
bb39:
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t108, ptr %l57, !tbaa !27
  %t109 = load i64, ptr %l4, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 %t109
  %t114 = load i8, ptr %t113, !tbaa !32
  %t116 = icmp eq i8 %t114, 46
  store i1 %t116, ptr %l56, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb41
bb41:
  %t118 = load i1, ptr %l56, !tbaa !21
  %t119 = xor i1 %t118, true
  br i1 %t119, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb44
bb44:
  %t121 = load i64, ptr %l4, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l4, !tbaa !24
  br label %bb45
bb45:
  br label %bb38
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t125 = load ptr, ptr %lp1
  store ptr %t125, ptr %l64, !tbaa !29
  %t126 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t126, ptr %l65, !tbaa !27
  %t127 = load i64, ptr %l2, !tbaa !24
  store i64 %t127, ptr %l66, !tbaa !24
  %t128 = load i64, ptr %l4, !tbaa !24
  store i64 %t128, ptr %l67, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  store i64 %t130, ptr %l68, !tbaa !24
  %t131 = load i64, ptr %l66, !tbaa !24
  %t132 = icmp sge i64 %t131, 0
  br i1 %t132, label %bb49, label %bb50
bb49:
  %t134 = load i64, ptr %l66, !tbaa !24
  %t135 = load i64, ptr %l67, !tbaa !24
  %t136 = icmp sle i64 %t134, %t135
  br i1 %t136, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2)
  unreachable
bb51:
  %t138 = load i64, ptr %l67, !tbaa !24
  %t139 = load i64, ptr %l68, !tbaa !24
  %t140 = icmp sle i64 %t138, %t139
  br i1 %t140, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2)
  unreachable
bb53:
  %t142 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l66, !tbaa !24
  %t145 = load i64, ptr %l67, !tbaa !24
  %t146 = getelementptr i8, ptr %t143, i64 %t144
  %t147 = sub i64 %t145, %t144
  %t148 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t146, 1
  %t151 = extractvalue { i64, ptr } %t149, 1
  %t152 = extractvalue { i64, ptr } %t149, 0
  %t153 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t151, i64 %t152)
  %t154 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t163, { i64, ptr } %t162)
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2)
  unreachable
bb55:
  %t165 = load i64, ptr %l4, !tbaa !24
  store i64 %t165, ptr %l2, !tbaa !24
  br label %bb56
bb56:
  br label %bb2
bb57:
  %t167 = load ptr, ptr %lp1
  %t169 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t167)
  store { i64, ptr } %t169, ptr %l77
  br label %bb58
bb58:
  %t170 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t170, ptr %l78, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  store i64 %t172, ptr %l79, !tbaa !24
  %t173 = load i64, ptr %l79, !tbaa !24
  %t174 = mul i64 %t173, 16
  %t175 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t174)
  %t176 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  store { i64, ptr } %t177, ptr %l80, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = load i64, ptr %l79, !tbaa !24
  %t183 = mul i64 %t182, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t179, ptr %t181, i64 %t183, i1 false)
  %t184 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t184, ptr %l78, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t185, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbindgen_2eflag(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t13 = load ptr, ptr %l10, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l10, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 1
  store i1 %t19, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l11, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { i1 }, ptr %t23, i32 0, i32 0
  %t25 = load i1, ptr %t24
  store i1 %t25, ptr %l3, !tbaa !21
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t27 = load i1, ptr %l3, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_c89c4e9e31b29b9e_9d77991e4d65189a)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2einner(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %s0, ptr %a0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d233, i32 0, i32 1) })
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb15
bb4:
  %t15 = load ptr, ptr %l8, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 6
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { { i64, ptr } }, ptr %t22, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l15, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l16, !tbaa !24
  %t30 = load i64, ptr %l16, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l16, !tbaa !24
  %t40 = mul i64 %t39, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t41, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t42 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t42, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_6ea08524187c2be0_2ef7bb2e3d9cc7b4)
  unreachable
bb14:
  br label %bb15
bb15:
  %t43 = icmp sge i64 0, 0
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = icmp sle i64 0, 1152921504606846975
  br i1 %t45, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_feb39f4cfa8fb0e2_4824786a1f7bac1e)
  unreachable
bb18:
  %t47 = mul i64 0, 8
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 0, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb19:
  call void @__olang_check_failed(ptr @olang_loc_feb39f4cfa8fb0e2_4824786a1f7bac1e)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbindgen_2emacroNames(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/text:LineIter"
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l16 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l60 = alloca i1
  %l61 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca i1
  %l71 = alloca { i64, ptr }
  %l80 = alloca i1
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca i64
  %l97 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t7 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t7, ptr %l8
  br label %bb2
bb2:
  %t8 = load %"std/prelude/text:LineIter", ptr %l8
  store %"std/prelude/text:LineIter" %t8, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l2)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l12
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14
ok.14:
  store { i64, ptr } %t11, ptr %l11
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  br label %bb9
bb5:
  %t16 = load i32, ptr %l12, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_a7c60743b5b597e4_82f0175d19c7c2b0)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb86
bb9:
  %t21 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t24 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t21)
  store { i64, ptr } %t24, ptr %l16
  br label %bb10
bb10:
  %t25 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t26, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d234, i32 0, i32 1) })
  store i1 %t28, ptr %l18
  br label %bb11
bb11:
  %t29 = load i1, ptr %l18, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb13:
  br label %bb14
bb14:
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t32, ptr %l20, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t33, 0
  store i64 %t36, ptr %l23, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l24, !tbaa !24
  %t39 = icmp sge i64 1, 0
  br i1 %t39, label %bb15, label %bb16
bb15:
  %t41 = load i64, ptr %l23, !tbaa !24
  %t42 = icmp sle i64 1, %t41
  br i1 %t42, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_781c284b896a8fce_cdc9de06e02cea)
  unreachable
bb17:
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = load i64, ptr %l24, !tbaa !24
  %t46 = icmp sle i64 %t44, %t45
  br i1 %t46, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_781c284b896a8fce_cdc9de06e02cea)
  unreachable
bb19:
  %t48 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = getelementptr i8, ptr %t49, i64 1
  %t52 = sub i64 %t50, 1
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  %t56 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t54)
  store { i64, ptr } %t56, ptr %l29
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_781c284b896a8fce_cdc9de06e02cea)
  unreachable
bb21:
  %t57 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t57, ptr %l4, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t58, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d235, i32 0, i32 1) })
  store i1 %t60, ptr %l31
  br label %bb22
bb22:
  %t61 = load i1, ptr %l31, !tbaa !21
  %t62 = xor i1 %t61, true
  br i1 %t62, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb24:
  br label %bb25
bb25:
  %t64 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t64, ptr %l33, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t65, 0
  store i64 %t68, ptr %l36, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l37, !tbaa !24
  %t71 = icmp sge i64 6, 0
  br i1 %t71, label %bb26, label %bb27
bb26:
  %t73 = load i64, ptr %l36, !tbaa !24
  %t74 = icmp sle i64 6, %t73
  br i1 %t74, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_d037eabd3d0bc2d_e7dbd50ce824989)
  unreachable
bb28:
  %t76 = load i64, ptr %l36, !tbaa !24
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_d037eabd3d0bc2d_e7dbd50ce824989)
  unreachable
bb30:
  %t80 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l36, !tbaa !24
  %t83 = getelementptr i8, ptr %t81, i64 6
  %t84 = sub i64 %t82, 6
  %t85 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  store { i64, ptr } %t86, ptr %l4, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t92 = icmp eq i64 %t90, 0
  br i1 %t92, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_d037eabd3d0bc2d_e7dbd50ce824989)
  unreachable
bb32:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb37
bb33:
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t94, ptr %l46, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i8, ptr %t96, i64 0
  %t98 = load i8, ptr %t97, !tbaa !32
  %t100 = icmp eq i8 %t98, 32
  br i1 %t100, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb36
bb35:
  %t102 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t102, ptr %l50, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr i8, ptr %t104, i64 0
  %t106 = load i8, ptr %t105, !tbaa !32
  %t108 = icmp eq i8 %t106, 9
  store i1 %t108, ptr %l49, !tbaa !21
  br label %bb36
bb36:
  %t110 = load i1, ptr %l49, !tbaa !21
  %t111 = xor i1 %t110, true
  store i1 %t111, ptr %l45, !tbaa !21
  br label %bb37
bb37:
  %t113 = load i1, ptr %l45, !tbaa !21
  br i1 %t113, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb39:
  br label %bb40
bb40:
  %t114 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t116 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t114)
  store { i64, ptr } %t116, ptr %l55
  br label %bb41
bb41:
  %t117 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t117, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  br label %bb42
bb42:
  %t118 = load i64, ptr %l5, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  br i1 %t124, label %bb43, label %bb44
bb43:
  %t126 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t126, ptr %l61, !tbaa !27
  %t127 = load i64, ptr %l5, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i8, ptr %t130, i64 %t127
  %t132 = load i8, ptr %t131, !tbaa !32
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t132)
  store i1 %t134, ptr %l64
  br label %bb45
bb44:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb53
bb45:
  %t135 = load i1, ptr %l64, !tbaa !21
  br i1 %t135, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb49
bb47:
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t136, ptr %l66, !tbaa !27
  %t137 = load i64, ptr %l5, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i8, ptr %t140, i64 %t137
  %t142 = load i8, ptr %t141, !tbaa !32
  %t144 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t142)
  store i1 %t144, ptr %l69
  br label %bb48
bb48:
  %t145 = load i1, ptr %l69, !tbaa !21
  store i1 %t145, ptr %l65, !tbaa !21
  br label %bb49
bb49:
  %t146 = load i1, ptr %l65, !tbaa !21
  br i1 %t146, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb52
bb51:
  %t147 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t147, ptr %l71, !tbaa !27
  %t148 = load i64, ptr %l5, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i8, ptr %t151, i64 %t148
  %t153 = load i8, ptr %t152, !tbaa !32
  %t155 = icmp eq i8 %t153, 95
  store i1 %t155, ptr %l70, !tbaa !21
  br label %bb52
bb52:
  %t157 = load i1, ptr %l70, !tbaa !21
  store i1 %t157, ptr %l60, !tbaa !21
  br label %bb53
bb53:
  %t158 = load i1, ptr %l60, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb54, label %bb55
bb54:
  br label %bb58
bb55:
  br label %bb56
bb56:
  %t161 = load i64, ptr %l5, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l5, !tbaa !24
  br label %bb57
bb57:
  br label %bb42
bb58:
  %t165 = load i64, ptr %l5, !tbaa !24
  %t167 = icmp eq i64 %t165, 0
  br i1 %t167, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb61
bb60:
  %t169 = load i64, ptr %l5, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t175 = icmp eq i64 %t169, %t172
  store i1 %t175, ptr %l80, !tbaa !21
  br label %bb61
bb61:
  %t177 = load i1, ptr %l80, !tbaa !21
  br i1 %t177, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb64
bb63:
  %t178 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t178, ptr %l86, !tbaa !27
  %t179 = load i64, ptr %l5, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr i8, ptr %t182, i64 %t179
  %t184 = load i8, ptr %t183, !tbaa !32
  %t186 = icmp eq i8 %t184, 40
  store i1 %t186, ptr %l85, !tbaa !21
  br label %bb64
bb64:
  %t188 = load i1, ptr %l85, !tbaa !21
  br i1 %t188, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb66:
  br label %bb67
bb67:
  %t189 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t189, ptr %l90, !tbaa !27
  %t190 = load i64, ptr %l5, !tbaa !24
  store i64 %t190, ptr %l91, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l92, !tbaa !24
  %t193 = icmp sge i64 0, 0
  br i1 %t193, label %bb68, label %bb69
bb68:
  %t195 = load i64, ptr %l91, !tbaa !24
  %t196 = icmp sle i64 0, %t195
  br i1 %t196, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_45e5c64e9ba550_8364d6509df24c1c)
  unreachable
bb70:
  %t198 = load i64, ptr %l91, !tbaa !24
  %t199 = load i64, ptr %l92, !tbaa !24
  %t200 = icmp sle i64 %t198, %t199
  br i1 %t200, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_45e5c64e9ba550_8364d6509df24c1c)
  unreachable
bb72:
  %t202 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = load i64, ptr %l91, !tbaa !24
  %t205 = getelementptr i8, ptr %t203, i64 0
  %t206 = sub i64 %t204, 0
  %t207 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t205, 1
  %t210 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t208)
  store i1 %t210, ptr %l97
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_45e5c64e9ba550_8364d6509df24c1c)
  unreachable
bb74:
  %t211 = load i1, ptr %l97, !tbaa !21
  br i1 %t211, label %bb75, label %bb76
bb75:
  %t212 = load ptr, ptr %lp1
  store ptr %t212, ptr %l98, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t213, ptr %l99, !tbaa !27
  %t214 = load i64, ptr %l5, !tbaa !24
  store i64 %t214, ptr %l100, !tbaa !24
  %t215 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  store i64 %t216, ptr %l101, !tbaa !24
  %t217 = icmp sge i64 0, 0
  br i1 %t217, label %bb77, label %bb78
bb76:
  br label %bb84
bb77:
  %t219 = load i64, ptr %l100, !tbaa !24
  %t220 = icmp sle i64 0, %t219
  br i1 %t220, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_45e5c64e9ba550_8364d6509df24c1c)
  unreachable
bb79:
  %t222 = load i64, ptr %l100, !tbaa !24
  %t223 = load i64, ptr %l101, !tbaa !24
  %t224 = icmp sle i64 %t222, %t223
  br i1 %t224, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @olang_loc_45e5c64e9ba550_8364d6509df24c1c)
  unreachable
bb81:
  %t226 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = load i64, ptr %l100, !tbaa !24
  %t229 = getelementptr i8, ptr %t227, i64 0
  %t230 = sub i64 %t228, 0
  %t231 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t229, 1
  %t234 = extractvalue { i64, ptr } %t232, 1
  %t235 = extractvalue { i64, ptr } %t232, 0
  %t236 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t234, i64 %t235)
  %t237 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = extractvalue { i64, ptr } %t238, 1
  %t242 = mul i64 %t240, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  %t246 = load ptr, ptr %l98, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t246, { i64, ptr } %t245)
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_45e5c64e9ba550_8364d6509df24c1c)
  unreachable
bb83:
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb85:
  br label %bb3
bb86:
  %t248 = load ptr, ptr %lp1
  %t249 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t248
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t249, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca i1
  %l48 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb23
bb5:
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l16
  br label %bb6
bb6:
  %t19 = load i64, ptr %l16, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb12
bb9:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l23, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb11
bb11:
  %t46 = load i64, ptr %l23, !tbaa !24
  store i64 %t46, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t47 = load i64, ptr %l20, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  br label %bb22
bb15:
  br label %bb16
bb16:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l8, !tbaa !24
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"std/json:Object", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l42, !tbaa !27
  %t70 = load i64, ptr %l8, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %t73, i64 %t70
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !37
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t75, { i64, ptr } %a1)
  store i1 %t79, ptr %l46
  br label %bb17
bb17:
  %t80 = load i1, ptr %l46, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr %"std/json:Object", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l48, !tbaa !27
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr ptr, ptr %t88, i64 %t85
  %t90 = load ptr, ptr %t89, !tbaa !39
  store ptr %t90, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb13
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_76a363c24681a0e6_dedc35590a663c5a)
  unreachable
bb28:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fbindgen_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"std/os:Output"
  %l17 = alloca ptr
  %l18 = alloca %"compiler/bindgen:gen"
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l35 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l49 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i32
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l67 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca %"std/prelude/text:StringBuilder"
  %l79 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca i64
  %l106 = alloca i64
  %l109 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l118 = alloca i32
  %l126 = alloca i32
  %l128 = alloca i32
  %l131 = alloca %"std/os:Output"
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca %"std/os:Output"
  %l137 = alloca i32
  %l141 = alloca { i64, ptr }
  %l142 = alloca i32
  %l144 = alloca i32
  %l156 = alloca i32
  %l158 = alloca i32
  %l161 = alloca ptr
  %l163 = alloca ptr
  %l164 = alloca i32
  %l172 = alloca i32
  %l174 = alloca i32
  %l178 = alloca %"compiler/bindgen:gen"
  %l183 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l199 = alloca i1
  %l201 = alloca i1
  %l203 = alloca i1
  %l205 = alloca i64
  %l207 = alloca i64
  %l208 = alloca i64
  %l212 = alloca { i64, ptr }
  %l213 = alloca i64
  %l214 = alloca i32
  %l215 = alloca i64
  %l216 = alloca i32
  %l219 = alloca i1
  %l220 = alloca i64
  %l222 = alloca i64
  %l225 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l239 = alloca i1
  %l240 = alloca i64
  %l241 = alloca { i64, ptr }
  %l242 = alloca i64
  %l243 = alloca i32
  %l244 = alloca i64
  %l245 = alloca i32
  %l246 = alloca ptr
  %l249 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l259 = alloca i1
  %l261 = alloca i32
  %l264 = alloca i32
  %l266 = alloca i32
  %l269 = alloca i32
  %l271 = alloca i32
  %l276 = alloca i32
  %l284 = alloca i32
  %l286 = alloca i32
  %l289 = alloca i32
  %l291 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %rv = alloca i32
  %t459 = alloca %"compiler/bindgen:gen", align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d236, i32 0, i32 1) })
  store i1 %t3, ptr %l33
  br label %bb1
bb1:
  %t4 = load i1, ptr %l33, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d237, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l35, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s1, ptr %t5, { i64, ptr } %t7)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb5:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t9)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l40
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb7, label %ok.15
ok.15:
  store { i64, ptr } %t12, ptr %l39
  br label %bb6
bb6:
  %t16 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t16, ptr %l37, !tbaa !27
  br label %bb12
bb7:
  %t17 = load i32, ptr %l40, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  br i1 %t20, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_735249e9ceddf5f_d7039875715975bb)
  unreachable
bb10:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t27 = extractvalue { i64, ptr } %t23, 1
  %t28 = extractvalue { i64, ptr } %t23, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = getelementptr i8, ptr %t33, i64 %t25
  call void @olang_textcopy(ptr %t34, ptr %t27, i64 %t28)
  %t35 = getelementptr i8, ptr %t34, i64 %t28
  call void @olang_textcopy(ptr %t35, ptr %t30, i64 %t31)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t33, 1
  %t40 = extractvalue { i64, ptr } %t37, 0
  %t41 = extractvalue { i64, ptr } %t37, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s2, ptr %t22, { i64, ptr } %t45)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb12:
  %t49 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t49, ptr %l4, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t50)
  %t53 = extractvalue { i32, { i64, ptr } } %t52, 1
  %t54 = extractvalue { i32, { i64, ptr } } %t52, 0
  store i32 %t54, ptr %l52
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb14, label %ok.56
ok.56:
  store { i64, ptr } %t53, ptr %l51
  br label %bb13
bb13:
  %t57 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t57, ptr %l49, !tbaa !27
  br label %bb19
bb14:
  %t58 = load i32, ptr %l52, !tbaa !23
  %t59 = ashr i32 %t58, 16
  %t61 = icmp eq i32 %t59, 1
  br i1 %t61, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_eab50b55b0b012de_9795516d577fe93a)
  unreachable
bb17:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t65 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t68 = extractvalue { i64, ptr } %t64, 1
  %t69 = extractvalue { i64, ptr } %t64, 0
  %t70 = add i64 %t66, %t69
  %t71 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t65, i64 %t66)
  %t75 = getelementptr i8, ptr %t74, i64 %t66
  call void @olang_textcopy(ptr %t75, ptr %t68, i64 %t69)
  %t76 = getelementptr i8, ptr %t75, i64 %t69
  call void @olang_textcopy(ptr %t76, ptr %t71, i64 %t72)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t74, 1
  %t81 = extractvalue { i64, ptr } %t78, 0
  %t82 = extractvalue { i64, ptr } %t78, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s4, ptr %t63, { i64, ptr } %t86)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb19:
  %t90 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t90, ptr %l5, !tbaa !27
  %t91 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d242, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d243, i32 0, i32 1) })
  %t92 = extractvalue { i32, { i64, ptr } } %t91, 1
  %t93 = extractvalue { i32, { i64, ptr } } %t91, 0
  store i32 %t93, ptr %l63
  %t94 = icmp ne i32 %t93, 0
  br i1 %t94, label %bb21, label %ok.95
ok.95:
  store { i64, ptr } %t92, ptr %l62
  br label %bb20
bb20:
  %t96 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t96, ptr %l61, !tbaa !27
  br label %bb26
bb21:
  %t97 = load i32, ptr %l63, !tbaa !23
  %t98 = ashr i32 %t97, 16
  %t100 = icmp eq i32 %t98, 1
  br i1 %t100, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_d1474ea2005c0415_1a999b446b4483d1)
  unreachable
bb24:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s6
  %t102 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d244, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l67, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s6, ptr %t102, { i64, ptr } %t104)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb26:
  %t106 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t106, ptr %l6, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t109 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t107, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d245, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d246, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d247, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d248, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d249, i32 0, i32 1) })
  store { i64, ptr } %t109, ptr %l70
  br label %bb27
bb27:
  %t110 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t110, ptr %l7, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t113 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbindgen_2emacroNames(ptr %s0, ptr %s0, { i64, ptr } %t111)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t113, ptr %l72
  br label %bb28
bb28:
  %t114 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l72
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %l8
  %t115 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t115, ptr %l73
  br label %bb29
bb29:
  %t116 = load %"std/prelude/text:StringBuilder", ptr %l73
  store %"std/prelude/text:StringBuilder" %t116, ptr %l9
  %t117 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t118 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t121 = extractvalue { i64, ptr } %t117, 1
  %t122 = extractvalue { i64, ptr } %t117, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @olang_textcopy(ptr %t127, ptr %t118, i64 %t119)
  %t128 = getelementptr i8, ptr %t127, i64 %t119
  call void @olang_textcopy(ptr %t128, ptr %t121, i64 %t122)
  %t129 = getelementptr i8, ptr %t128, i64 %t122
  call void @olang_textcopy(ptr %t129, ptr %t124, i64 %t125)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t127, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = extractvalue { i64, ptr } %t131, 1
  %t135 = mul i64 %t133, 1
  %t136 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t135)
  call void @llvm.memcpy.p0.p0.i64(ptr %t136, ptr %t134, i64 %t135, i1 false)
  %t137 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l9, { i64, ptr } %t138)
  br label %bb30
bb30:
  store i64 0, ptr %l10, !tbaa !24
  %t142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l8)
  store i64 %t142, ptr %l79
  br label %bb31
bb31:
  %t143 = load i64, ptr %l79, !tbaa !24
  store i64 %t143, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t144 = load i64, ptr %l11, !tbaa !24
  %t145 = load i64, ptr %l10, !tbaa !24
  %t148 = icmp sgt i64 %t144, %t145
  br i1 %t148, label %bb32, label %bb33
bb32:
  %t150 = load i64, ptr %l12, !tbaa !24
  %t152 = icmp sgt i64 %t150, 0
  br i1 %t152, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb37
bb34:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t155 = load i64, ptr %l10, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l12, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t164 = sub i64 %t162, 1
  %t165 = load i64, ptr %l12, !tbaa !24
  %t168 = sdiv i64 %t164, %t165
  store i64 %t168, ptr %l86, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb36
bb36:
  %t170 = load i64, ptr %l86, !tbaa !24
  store i64 %t170, ptr %l83, !tbaa !24
  br label %bb37
bb37:
  %t171 = load i64, ptr %l83, !tbaa !24
  store i64 %t171, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  %t172 = load i64, ptr %l14, !tbaa !24
  %t173 = load i64, ptr %l13, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s9)
  br label %bb45
bb40:
  br label %bb41
bb41:
  %t180 = load i64, ptr %l10, !tbaa !24
  %t181 = load i64, ptr %l14, !tbaa !24
  %t182 = load i64, ptr %l12, !tbaa !24
  %t185 = mul i64 %t181, %t182
  %t188 = add i64 %t180, %t185
  store i64 %t188, ptr %l15, !tbaa !24
  store ptr %l9, ptr %l104, !tbaa !29
  %t190 = load i64, ptr %l15, !tbaa !24
  store i64 %t190, ptr %l105, !tbaa !24
  %t191 = load i64, ptr %l15, !tbaa !24
  store i64 %t191, ptr %l106, !tbaa !24
  %t192 = load i64, ptr %l15, !tbaa !24
  %t195 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s9, ptr %l8, i64 %t192)
  store { i64, ptr } %t195, ptr %l109
  br label %bb42
bb42:
  %t196 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t197 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t198 = load i64, ptr %l105, !tbaa !24
  %t199 = call i64 @__olang_fmt_i64(ptr null, i64 %t198)
  %t200 = add i64 %t197, %t199
  %t201 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t203 = add i64 %t200, %t202
  %t204 = load i64, ptr %l106, !tbaa !24
  %t205 = call i64 @__olang_fmt_i64(ptr null, i64 %t204)
  %t206 = add i64 %t203, %t205
  %t207 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t209 = add i64 %t206, %t208
  %t210 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t215 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t216 = add i64 %t213, %t215
  %t217 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t216)
  call void @olang_textcopy(ptr %t217, ptr %t196, i64 %t197)
  %t218 = getelementptr i8, ptr %t217, i64 %t197
  %t219 = call i64 @__olang_fmt_i64(ptr %t218, i64 %t198)
  %t220 = getelementptr i8, ptr %t218, i64 %t199
  call void @olang_textcopy(ptr %t220, ptr %t201, i64 %t202)
  %t221 = getelementptr i8, ptr %t220, i64 %t202
  %t222 = call i64 @__olang_fmt_i64(ptr %t221, i64 %t204)
  %t223 = getelementptr i8, ptr %t221, i64 %t205
  call void @olang_textcopy(ptr %t223, ptr %t207, i64 %t208)
  %t224 = getelementptr i8, ptr %t223, i64 %t208
  call void @olang_textcopy(ptr %t224, ptr %t211, i64 %t212)
  %t225 = getelementptr i8, ptr %t224, i64 %t212
  call void @olang_textcopy(ptr %t225, ptr %t214, i64 %t215)
  %t226 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t217, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = extractvalue { i64, ptr } %t227, 1
  %t231 = mul i64 %t229, 1
  %t232 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t232, ptr %t230, i64 %t231, i1 false)
  %t233 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  %t235 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t235, { i64, ptr } %t234)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s9)
  br label %bb44
bb44:
  %t237 = load i64, ptr %l14, !tbaa !24
  %t239 = add i64 %t237, 1
  store i64 %t239, ptr %l14, !tbaa !24
  br label %bb38
bb45:
  %t241 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t241, ptr %l114, !tbaa !27
  %t243 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l9)
  store { i64, ptr } %t243, ptr %l116
  br label %bb46
bb46:
  %t244 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t247 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t245, { i64, ptr } %t244)
  store i32 %t247, ptr %l118
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb48, label %ok.249
ok.249:
  br label %bb47
bb47:
  br label %bb59
bb48:
  %t250 = load i32, ptr %l118, !tbaa !23
  %t251 = ashr i32 %t250, 16
  %t253 = icmp eq i32 %t251, 1
  br i1 %t253, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_883df75978b19524_14c3f49651dc1b40)
  unreachable
bb51:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s12
  %t255 = load ptr, ptr %l3, !tbaa !29
  %t256 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t257 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t260 = extractvalue { i64, ptr } %t256, 1
  %t261 = extractvalue { i64, ptr } %t256, 0
  %t262 = add i64 %t258, %t261
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t265 = add i64 %t262, %t264
  %t266 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t265)
  call void @olang_textcopy(ptr %t266, ptr %t257, i64 %t258)
  %t267 = getelementptr i8, ptr %t266, i64 %t258
  call void @olang_textcopy(ptr %t267, ptr %t260, i64 %t261)
  %t268 = getelementptr i8, ptr %t267, i64 %t261
  call void @olang_textcopy(ptr %t268, ptr %t263, i64 %t264)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t266, 1
  %t273 = extractvalue { i64, ptr } %t270, 0
  %t274 = extractvalue { i64, ptr } %t270, 1
  %t275 = mul i64 %t273, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t276, ptr %t274, i64 %t275, i1 false)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s12, ptr %t255, { i64, ptr } %t278)
  br label %bb52
bb52:
  store i32 2, ptr %l126, !tbaa !23
  call void @__olang_scope_close(ptr %s12)
  %t281 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t283 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t281)
  store i32 %t283, ptr %l128
  %t284 = icmp ne i32 %t283, 0
  br i1 %t284, label %bb54, label %ok.285
ok.285:
  br label %bb53
bb53:
  br label %bb58
bb54:
  %t286 = load i32, ptr %l128, !tbaa !23
  %t287 = ashr i32 %t286, 16
  %t289 = icmp eq i32 %t287, 1
  br i1 %t289, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_e5d149819eaf9bc3_77be55e8f180b557)
  unreachable
bb57:
  call void @__olang_ert_req_clear()
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t291 = load i32, ptr %l126, !tbaa !23
  store i32 %t291, ptr %rv
  br label %ret
bb59:
  %t292 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t293 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t294 = mul i64 9, 16
  %t295 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t294)
  %t296 = insertvalue { i64, ptr } undef, i64 9, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  store { i64, ptr } %t297, ptr %l134, !tbaa !27
  %t299 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr { i64, ptr }, ptr %t300, i64 0
  store { i64, ptr } %t292, ptr %t301, !tbaa !37
  %t302 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr { i64, ptr }, ptr %t303, i64 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d258, i32 0, i32 1) }, ptr %t304, !tbaa !37
  %t305 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %t306, i64 2
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d259, i32 0, i32 1) }, ptr %t307, !tbaa !37
  %t308 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr { i64, ptr }, ptr %t309, i64 3
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d260, i32 0, i32 1) }, ptr %t310, !tbaa !37
  %t311 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %t312, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d261, i32 0, i32 1) }, ptr %t313, !tbaa !37
  %t314 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr { i64, ptr }, ptr %t315, i64 5
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d262, i32 0, i32 1) }, ptr %t316, !tbaa !37
  %t317 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr { i64, ptr }, ptr %t318, i64 6
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d263, i32 0, i32 1) }, ptr %t319, !tbaa !37
  %t320 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr { i64, ptr }, ptr %t321, i64 7
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d264, i32 0, i32 1) }, ptr %t322, !tbaa !37
  %t324 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr { i64, ptr }, ptr %t325, i64 8
  store { i64, ptr } %t293, ptr %t326, !tbaa !37
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d265, i32 0, i32 1) }, ptr %l135, !tbaa !27
  %t327 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t329 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t327, { i64, ptr } %t328, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d266, i32 0, i32 1) })
  %t330 = extractvalue { i32, %"std/os:Output" } %t329, 1
  %t331 = extractvalue { i32, %"std/os:Output" } %t329, 0
  store i32 %t331, ptr %l137
  %t332 = icmp ne i32 %t331, 0
  br i1 %t332, label %bb61, label %ok.333
ok.333:
  store %"std/os:Output" %t330, ptr %l136
  br label %bb60
bb60:
  %t334 = load %"std/os:Output", ptr %l136
  store %"std/os:Output" %t334, ptr %l131
  br label %bb72
bb61:
  %t335 = load i32, ptr %l137, !tbaa !23
  %t336 = ashr i32 %t335, 16
  %t338 = icmp eq i32 %t336, 1
  br i1 %t338, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_a9d4a365d2ff5442_94c7a520dca621b6)
  unreachable
bb64:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s17
  %t340 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d267, i32 0, i32 1) }, ptr %l141, !tbaa !27
  %t342 = load { i64, ptr }, ptr %l141, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s17, ptr %t340, { i64, ptr } %t342)
  br label %bb65
bb65:
  store i32 2, ptr %l142, !tbaa !23
  call void @__olang_scope_close(ptr %s17)
  %t343 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t345 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t343)
  store i32 %t345, ptr %l144
  %t346 = icmp ne i32 %t345, 0
  br i1 %t346, label %bb67, label %ok.347
ok.347:
  br label %bb66
bb66:
  br label %bb71
bb67:
  %t348 = load i32, ptr %l144, !tbaa !23
  %t349 = ashr i32 %t348, 16
  %t351 = icmp eq i32 %t349, 1
  br i1 %t351, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_e5d149819eaf9bc3_77be55e8f180b557)
  unreachable
bb70:
  call void @__olang_ert_req_clear()
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s0)
  %t353 = load i32, ptr %l142, !tbaa !23
  store i32 %t353, ptr %rv
  br label %ret
bb72:
  %t354 = load %"std/os:Output", ptr %l131
  store %"std/os:Output" %t354, ptr %l16
  %t355 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 1
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t356, 0
  %t360 = icmp eq i64 %t358, 0
  br i1 %t360, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s21
  %t362 = load ptr, ptr %l3, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t364 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 2
  %t365 = load { i64, ptr }, ptr %t364, !tbaa !27
  %t366 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t367 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t369 = extractvalue { i64, ptr } %t363, 1
  %t370 = extractvalue { i64, ptr } %t363, 0
  %t371 = add i64 %t367, %t370
  %t372 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t374 = add i64 %t371, %t373
  %t376 = extractvalue { i64, ptr } %t365, 1
  %t377 = extractvalue { i64, ptr } %t365, 0
  %t378 = add i64 %t374, %t377
  %t379 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t378)
  call void @olang_textcopy(ptr %t379, ptr %t366, i64 %t367)
  %t380 = getelementptr i8, ptr %t379, i64 %t367
  call void @olang_textcopy(ptr %t380, ptr %t369, i64 %t370)
  %t381 = getelementptr i8, ptr %t380, i64 %t370
  call void @olang_textcopy(ptr %t381, ptr %t372, i64 %t373)
  %t382 = getelementptr i8, ptr %t381, i64 %t373
  call void @olang_textcopy(ptr %t382, ptr %t376, i64 %t377)
  %t383 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t379, 1
  %t387 = extractvalue { i64, ptr } %t384, 0
  %t388 = extractvalue { i64, ptr } %t384, 1
  %t389 = mul i64 %t387, 1
  %t390 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t389)
  call void @llvm.memcpy.p0.p0.i64(ptr %t390, ptr %t388, i64 %t389, i1 false)
  %t391 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t392 = insertvalue { i64, ptr } %t391, ptr %t390, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s21, ptr %t362, { i64, ptr } %t392)
  br label %bb75
bb74:
  br label %bb82
bb75:
  store i32 1, ptr %l156, !tbaa !23
  call void @__olang_scope_close(ptr %s21)
  %t395 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t397 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t395)
  store i32 %t397, ptr %l158
  %t398 = icmp ne i32 %t397, 0
  br i1 %t398, label %bb77, label %ok.399
ok.399:
  br label %bb76
bb76:
  br label %bb81
bb77:
  %t400 = load i32, ptr %l158, !tbaa !23
  %t401 = ashr i32 %t400, 16
  %t403 = icmp eq i32 %t401, 1
  br i1 %t403, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_e5d149819eaf9bc3_77be55e8f180b557)
  unreachable
bb80:
  call void @__olang_ert_req_clear()
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s0)
  %t405 = load i32, ptr %l156, !tbaa !23
  store i32 %t405, ptr %rv
  br label %ret
bb82:
  %t406 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 1
  %t407 = load { i64, ptr }, ptr %t406, !tbaa !27
  %t409 = call { i32, ptr } @std_2fjson_2eParse(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t407, ptr null)
  %t410 = extractvalue { i32, ptr } %t409, 1
  %t411 = extractvalue { i32, ptr } %t409, 0
  store i32 %t411, ptr %l164
  %t412 = icmp ne i32 %t411, 0
  br i1 %t412, label %bb84, label %ok.413
ok.413:
  store ptr %t410, ptr %l163
  br label %bb83
bb83:
  %t414 = load ptr, ptr %l163, !tbaa !29
  store ptr %t414, ptr %l161, !tbaa !29
  br label %bb95
bb84:
  %t415 = load i32, ptr %l164, !tbaa !23
  %t416 = ashr i32 %t415, 16
  %t418 = icmp eq i32 %t416, 1
  br i1 %t418, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_5511421d896f74b9_e721aeb44849284d)
  unreachable
bb87:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s26
  %t420 = load ptr, ptr %l3, !tbaa !29
  %t421 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t422 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t423 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t425 = extractvalue { i64, ptr } %t421, 1
  %t426 = extractvalue { i64, ptr } %t421, 0
  %t427 = add i64 %t423, %t426
  %t428 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t429 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t430 = add i64 %t427, %t429
  %t431 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t430)
  call void @olang_textcopy(ptr %t431, ptr %t422, i64 %t423)
  %t432 = getelementptr i8, ptr %t431, i64 %t423
  call void @olang_textcopy(ptr %t432, ptr %t425, i64 %t426)
  %t433 = getelementptr i8, ptr %t432, i64 %t426
  call void @olang_textcopy(ptr %t433, ptr %t428, i64 %t429)
  %t434 = insertvalue { i64, ptr } undef, i64 %t430, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t431, 1
  %t438 = extractvalue { i64, ptr } %t435, 0
  %t439 = extractvalue { i64, ptr } %t435, 1
  %t440 = mul i64 %t438, 1
  %t441 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t440)
  call void @llvm.memcpy.p0.p0.i64(ptr %t441, ptr %t439, i64 %t440, i1 false)
  %t442 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t441, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s26, ptr %t420, { i64, ptr } %t443)
  br label %bb88
bb88:
  store i32 2, ptr %l172, !tbaa !23
  call void @__olang_scope_close(ptr %s26)
  %t446 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t448 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t446)
  store i32 %t448, ptr %l174
  %t449 = icmp ne i32 %t448, 0
  br i1 %t449, label %bb90, label %ok.450
ok.450:
  br label %bb89
bb89:
  br label %bb94
bb90:
  %t451 = load i32, ptr %l174, !tbaa !23
  %t452 = ashr i32 %t451, 16
  %t454 = icmp eq i32 %t452, 1
  br i1 %t454, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_e5d149819eaf9bc3_77be55e8f180b557)
  unreachable
bb93:
  call void @__olang_ert_req_clear()
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s0)
  %t456 = load i32, ptr %l172, !tbaa !23
  store i32 %t456, ptr %rv
  br label %ret
bb95:
  %t457 = load ptr, ptr %l161, !tbaa !29
  store ptr %t457, ptr %l17, !tbaa !29
  %t458 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fbindgen_3agen_2ector(ptr %t459, ptr %s0, ptr %s0, { i64, ptr } %t458)
  call void @llvm.memmove.p0.p0.i64(ptr %l178, ptr %t459, i64 136, i1 false)
  br label %bb96
bb96:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l178, i64 136, i1 false)
  %t461 = load ptr, ptr %l17, !tbaa !29
  %t462 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eread(ptr %s0, ptr %s0, ptr %s0, ptr %l18, ptr %t461, { i64, ptr } %t462)
  br label %bb97
bb97:
  %t466 = getelementptr %"compiler/bindgen:gen", ptr %l18, i32 0, i32 14
  store i64 0, ptr %t466, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s31
  %t467 = load ptr, ptr %l17, !tbaa !29
  %t469 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s0, ptr %s31, ptr %t467)
  store { i64, ptr } %t469, ptr %l183
  br label %bb98
bb98:
  %t470 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t471 = extractvalue { i64, ptr } %t470, 0
  %t472 = extractvalue { i64, ptr } %t470, 1
  %t473 = mul i64 %t471, 8
  %t474 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t473)
  call void @llvm.memcpy.p0.p0.i64(ptr %t474, ptr %t472, i64 %t473, i1 false)
  %t475 = insertvalue { i64, ptr } undef, i64 %t471, 0
  %t476 = insertvalue { i64, ptr } %t475, ptr %t474, 1
  store { i64, ptr } %t476, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t478 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t478, 0
  store i64 %t480, ptr %l21, !tbaa !24
  br label %bb99
bb99:
  store %olang.scope zeroinitializer, ptr %s32
  %t482 = load i64, ptr %l20, !tbaa !24
  %t483 = load i64, ptr %l21, !tbaa !24
  %t486 = icmp slt i64 %t482, %t483
  %t488 = xor i1 %t486, true
  br i1 %t488, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s32)
  br label %bb153
bb101:
  br label %bb102
bb102:
  %t490 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t490, ptr %l191, !tbaa !27
  %t491 = load i64, ptr %l20, !tbaa !24
  %t493 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = getelementptr ptr, ptr %t494, i64 %t491
  %t496 = load ptr, ptr %t495, !tbaa !39
  store ptr %t496, ptr %l22, !tbaa !29
  %t498 = load ptr, ptr %l22, !tbaa !29
  %t500 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s31, ptr %s32, ptr %s32, ptr %t498, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d272, i32 0, i32 1) })
  store { i64, ptr } %t500, ptr %l195
  br label %bb103
bb103:
  %t501 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t501, ptr %l23, !tbaa !27
  %t502 = load ptr, ptr %l22, !tbaa !29
  %t504 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s31, ptr %s32, ptr %s32, ptr %t502, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d273, i32 0, i32 1) })
  store { i64, ptr } %t504, ptr %l197
  br label %bb104
bb104:
  %t505 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t505, 0
  %t507 = extractvalue { i64, ptr } %t505, 1
  %t508 = mul i64 %t506, 1
  %t509 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t508)
  call void @llvm.memcpy.p0.p0.i64(ptr %t509, ptr %t507, i64 %t508, i1 false)
  %t510 = insertvalue { i64, ptr } undef, i64 %t506, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t509, 1
  %t513 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s32, ptr %s32, { i64, ptr } %t511, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d274, i32 0, i32 1) })
  store i1 %t513, ptr %l199
  br label %bb105
bb105:
  %t514 = load i1, ptr %l199, !tbaa !21
  %t515 = xor i1 %t514, true
  br i1 %t515, label %bb106, label %bb107
bb106:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb109
bb107:
  %t517 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t519 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s32, ptr %s32, { i64, ptr } %t517, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d275, i32 0, i32 1) })
  store i1 %t519, ptr %l203
  br label %bb108
bb108:
  %t520 = load i1, ptr %l203, !tbaa !21
  %t521 = xor i1 %t520, true
  store i1 %t521, ptr %l201, !tbaa !21
  br label %bb109
bb109:
  %t523 = load i1, ptr %l201, !tbaa !21
  br i1 %t523, label %bb110, label %bb111
bb110:
  call void @__olang_scope_close(ptr %s32)
  br label %bb152
bb111:
  br label %bb112
bb112:
  %t524 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t526 = extractvalue { i64, ptr } %t524, 0
  store i64 %t526, ptr %l207, !tbaa !24
  %t527 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t527, 0
  store i64 %t528, ptr %l208, !tbaa !24
  %t529 = icmp sge i64 9, 0
  br i1 %t529, label %bb113, label %bb114
bb113:
  %t531 = load i64, ptr %l207, !tbaa !24
  %t532 = icmp sle i64 9, %t531
  br i1 %t532, label %bb115, label %bb116
bb114:
  call void @__olang_check_failed(ptr @olang_loc_d2547e7fa6ec69ef_6f5f269cee95a513)
  unreachable
bb115:
  %t534 = load i64, ptr %l207, !tbaa !24
  %t535 = load i64, ptr %l208, !tbaa !24
  %t536 = icmp sle i64 %t534, %t535
  br i1 %t536, label %bb117, label %bb118
bb116:
  call void @__olang_check_failed(ptr @olang_loc_d2547e7fa6ec69ef_6f5f269cee95a513)
  unreachable
bb117:
  %t538 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t539 = load ptr, ptr %t538, !tbaa !27
  %t540 = load i64, ptr %l207, !tbaa !24
  %t541 = getelementptr i8, ptr %t539, i64 9
  %t542 = sub i64 %t540, 9
  %t543 = insertvalue { i64, ptr } undef, i64 %t542, 0
  %t544 = insertvalue { i64, ptr } %t543, ptr %t541, 1
  store { i64, ptr } %t544, ptr %l212, !tbaa !27
  %t545 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s32, i64 10)
  %t546 = extractvalue { i32, i64 } %t545, 1
  %t547 = extractvalue { i32, i64 } %t545, 0
  store i32 %t547, ptr %l214
  %t548 = icmp ne i32 %t547, 0
  br i1 %t548, label %bb120, label %ok.549
ok.549:
  store i64 %t546, ptr %l213
  br label %bb119
bb118:
  call void @__olang_check_failed(ptr @olang_loc_d2547e7fa6ec69ef_6f5f269cee95a513)
  unreachable
bb119:
  %t550 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t551 = load i64, ptr %l213, !tbaa !24
  %t552 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s32, { i64, ptr } %t550, i64 %t551)
  %t553 = extractvalue { i32, i64 } %t552, 1
  %t554 = extractvalue { i32, i64 } %t552, 0
  store i32 %t554, ptr %l216
  %t555 = icmp ne i32 %t554, 0
  br i1 %t555, label %bb123, label %ok.556
ok.556:
  store i64 %t553, ptr %l215
  br label %bb122
bb120:
  br label %bb121
bb121:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l205, !tbaa !24
  br label %bb124
bb122:
  %t557 = load i64, ptr %l215, !tbaa !24
  store i64 %t557, ptr %l205, !tbaa !24
  br label %bb124
bb123:
  br label %bb121
bb124:
  %t558 = load i64, ptr %l205, !tbaa !24
  store i64 %t558, ptr %l24, !tbaa !24
  %t559 = load i64, ptr %l24, !tbaa !24
  %t561 = icmp slt i64 %t559, 0
  br i1 %t561, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l219, !tbaa !21
  br label %bb128
bb126:
  %t563 = load i64, ptr %l24, !tbaa !24
  store i64 %t563, ptr %l220, !tbaa !24
  %t565 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l8)
  store i64 %t565, ptr %l222
  br label %bb127
bb127:
  %t566 = load i64, ptr %l220, !tbaa !24
  %t567 = load i64, ptr %l222, !tbaa !24
  %t568 = icmp sge i64 %t566, %t567
  store i1 %t568, ptr %l219, !tbaa !21
  br label %bb128
bb128:
  %t570 = load i1, ptr %l219, !tbaa !21
  br i1 %t570, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s32)
  br label %bb152
bb130:
  br label %bb131
bb131:
  store %olang.scope zeroinitializer, ptr %s35
  %t571 = load ptr, ptr %l22, !tbaa !29
  %t573 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s31, ptr %s35, ptr %t571)
  store { i64, ptr } %t573, ptr %l225
  br label %bb132
bb132:
  %t574 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t575 = extractvalue { i64, ptr } %t574, 0
  %t576 = extractvalue { i64, ptr } %t574, 1
  %t577 = mul i64 %t575, 8
  %t578 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t577)
  call void @llvm.memcpy.p0.p0.i64(ptr %t578, ptr %t576, i64 %t577, i1 false)
  %t579 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t578, 1
  store { i64, ptr } %t580, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t582 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t584 = extractvalue { i64, ptr } %t582, 0
  store i64 %t584, ptr %l27, !tbaa !24
  br label %bb133
bb133:
  store %olang.scope zeroinitializer, ptr %s36
  %t586 = load i64, ptr %l26, !tbaa !24
  %t587 = load i64, ptr %l27, !tbaa !24
  %t590 = icmp slt i64 %t586, %t587
  %t592 = xor i1 %t590, true
  br i1 %t592, label %bb134, label %bb135
bb134:
  call void @__olang_scope_close(ptr %s36)
  br label %bb151
bb135:
  br label %bb136
bb136:
  %t594 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t594, ptr %l233, !tbaa !27
  %t595 = load i64, ptr %l26, !tbaa !24
  %t597 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t598 = load ptr, ptr %t597, !tbaa !27
  %t599 = getelementptr ptr, ptr %t598, i64 %t595
  %t600 = load ptr, ptr %t599, !tbaa !39
  %t604 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s35, ptr %s36, ptr %t600)
  store { i64, ptr } %t604, ptr %l237
  br label %bb137
bb137:
  %t605 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t605, ptr %l29, !tbaa !27
  %t606 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t608 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s36, ptr %s36, { i64, ptr } %t606, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d276, i32 0, i32 1) })
  store i1 %t608, ptr %l239
  br label %bb138
bb138:
  %t609 = load i1, ptr %l239, !tbaa !21
  br i1 %t609, label %bb139, label %bb140
bb139:
  call void @__olang_scope_close(ptr %s36)
  br label %bb150
bb140:
  br label %bb141
bb141:
  %t610 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t610, ptr %l241, !tbaa !27
  %t611 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s36, i64 10)
  %t612 = extractvalue { i32, i64 } %t611, 1
  %t613 = extractvalue { i32, i64 } %t611, 0
  store i32 %t613, ptr %l243
  %t614 = icmp ne i32 %t613, 0
  br i1 %t614, label %bb143, label %ok.615
ok.615:
  store i64 %t612, ptr %l242
  br label %bb142
bb142:
  %t616 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t617 = load i64, ptr %l242, !tbaa !24
  %t618 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s36, { i64, ptr } %t616, i64 %t617)
  %t619 = extractvalue { i32, i64 } %t618, 1
  %t620 = extractvalue { i32, i64 } %t618, 0
  store i32 %t620, ptr %l245
  %t621 = icmp ne i32 %t620, 0
  br i1 %t621, label %bb146, label %ok.622
ok.622:
  store i64 %t619, ptr %l244
  br label %bb145
bb143:
  br label %bb144
bb144:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s36)
  br label %bb150
bb145:
  %t623 = load i64, ptr %l244, !tbaa !24
  store i64 %t623, ptr %l240, !tbaa !24
  br label %bb147
bb146:
  br label %bb144
bb147:
  %t624 = load i64, ptr %l240, !tbaa !24
  store i64 %t624, ptr %l30, !tbaa !24
  store ptr %l18, ptr %l246, !tbaa !29
  %t625 = load i64, ptr %l24, !tbaa !24
  %t628 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l8, i64 %t625)
  store { i64, ptr } %t628, ptr %l249
  br label %bb148
bb148:
  %t629 = load i64, ptr %l30, !tbaa !24
  %t630 = load ptr, ptr %l246, !tbaa !29
  %t631 = load { i64, ptr }, ptr %l249, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %s0, ptr %s0, ptr %t630, { i64, ptr } %t631, i64 %t629)
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s36)
  br label %bb150
bb150:
  %t633 = load i64, ptr %l26, !tbaa !24
  %t635 = add i64 %t633, 1
  store i64 %t635, ptr %l26, !tbaa !24
  br label %bb133
bb151:
  call void @__olang_scope_close(ptr %s35)
  call void @__olang_scope_close(ptr %s32)
  br label %bb152
bb152:
  %t637 = load i64, ptr %l20, !tbaa !24
  %t639 = add i64 %t637, 1
  store i64 %t639, ptr %l20, !tbaa !24
  br label %bb99
bb153:
  call void @__olang_scope_close(ptr %s31)
  %t641 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t644 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrite(ptr %s0, ptr %v0, ptr %s0, ptr %l18, { i64, ptr } %t641)
  store { i64, ptr } %t644, ptr %l257
  br label %bb154
bb154:
  %t645 = load { i64, ptr }, ptr %l257, !tbaa !27
  store { i64, ptr } %t645, ptr %l31, !tbaa !27
  %t646 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t648 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t646, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d277, i32 0, i32 1) })
  store i1 %t648, ptr %l259
  br label %bb155
bb155:
  %t649 = load i1, ptr %l259, !tbaa !21
  br i1 %t649, label %bb156, label %bb157
bb156:
  %t650 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t652 = call i32 @std_2fio_2ePrint(ptr %s0, { i64, ptr } %t650)
  store i32 %t652, ptr %l261
  %t653 = icmp ne i32 %t652, 0
  br i1 %t653, label %bb159, label %ok.654
ok.654:
  br label %bb158
bb157:
  br label %bb176
bb158:
  br label %bb169
bb159:
  %t655 = load i32, ptr %l261, !tbaa !23
  %t656 = ashr i32 %t655, 16
  %t658 = icmp eq i32 %t656, 1
  br i1 %t658, label %bb160, label %bb161
bb160:
  br label %bb162
bb161:
  call void @__olang_check_failed(ptr @olang_loc_4f5e3b4e248943b7_ce5257eefd522463)
  unreachable
bb162:
  call void @__olang_ert_req_clear()
  store i32 1, ptr %l264, !tbaa !23
  %t660 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t662 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t660)
  store i32 %t662, ptr %l266
  %t663 = icmp ne i32 %t662, 0
  br i1 %t663, label %bb164, label %ok.664
ok.664:
  br label %bb163
bb163:
  br label %bb168
bb164:
  %t665 = load i32, ptr %l266, !tbaa !23
  %t666 = ashr i32 %t665, 16
  %t668 = icmp eq i32 %t666, 1
  br i1 %t668, label %bb165, label %bb166
bb165:
  br label %bb167
bb166:
  call void @__olang_check_failed(ptr @olang_loc_e5d149819eaf9bc3_77be55e8f180b557)
  unreachable
bb167:
  call void @__olang_ert_req_clear()
  br label %bb168
bb168:
  call void @__olang_scope_close(ptr %s0)
  %t670 = load i32, ptr %l264, !tbaa !23
  store i32 %t670, ptr %rv
  br label %ret
bb169:
  store i32 0, ptr %l269, !tbaa !23
  %t671 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t673 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t671)
  store i32 %t673, ptr %l271
  %t674 = icmp ne i32 %t673, 0
  br i1 %t674, label %bb171, label %ok.675
ok.675:
  br label %bb170
bb170:
  br label %bb175
bb171:
  %t676 = load i32, ptr %l271, !tbaa !23
  %t677 = ashr i32 %t676, 16
  %t679 = icmp eq i32 %t677, 1
  br i1 %t679, label %bb172, label %bb173
bb172:
  br label %bb174
bb173:
  call void @__olang_check_failed(ptr @olang_loc_e5d149819eaf9bc3_77be55e8f180b557)
  unreachable
bb174:
  call void @__olang_ert_req_clear()
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s0)
  %t681 = load i32, ptr %l269, !tbaa !23
  store i32 %t681, ptr %rv
  br label %ret
bb176:
  %t682 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t683 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t686 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s0, { i64, ptr } %t682, { i64, ptr } %t683)
  store i32 %t686, ptr %l276
  %t687 = icmp ne i32 %t686, 0
  br i1 %t687, label %bb178, label %ok.688
ok.688:
  br label %bb177
bb177:
  br label %bb189
bb178:
  %t689 = load i32, ptr %l276, !tbaa !23
  %t690 = ashr i32 %t689, 16
  %t692 = icmp eq i32 %t690, 1
  br i1 %t692, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  call void @__olang_check_failed(ptr @olang_loc_3fac94b3e5d2b496_322e3413c3c14662)
  unreachable
bb181:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s49
  %t694 = load ptr, ptr %l3, !tbaa !29
  %t695 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t696 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t697 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  %t699 = extractvalue { i64, ptr } %t695, 1
  %t700 = extractvalue { i64, ptr } %t695, 0
  %t701 = add i64 %t697, %t700
  %t702 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t703 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  %t704 = add i64 %t701, %t703
  %t705 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t704)
  call void @olang_textcopy(ptr %t705, ptr %t696, i64 %t697)
  %t706 = getelementptr i8, ptr %t705, i64 %t697
  call void @olang_textcopy(ptr %t706, ptr %t699, i64 %t700)
  %t707 = getelementptr i8, ptr %t706, i64 %t700
  call void @olang_textcopy(ptr %t707, ptr %t702, i64 %t703)
  %t708 = insertvalue { i64, ptr } undef, i64 %t704, 0
  %t709 = insertvalue { i64, ptr } %t708, ptr %t705, 1
  %t712 = extractvalue { i64, ptr } %t709, 0
  %t713 = extractvalue { i64, ptr } %t709, 1
  %t714 = mul i64 %t712, 1
  %t715 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t714)
  call void @llvm.memcpy.p0.p0.i64(ptr %t715, ptr %t713, i64 %t714, i1 false)
  %t716 = insertvalue { i64, ptr } undef, i64 %t712, 0
  %t717 = insertvalue { i64, ptr } %t716, ptr %t715, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v3, ptr %s49, ptr %t694, { i64, ptr } %t717)
  br label %bb182
bb182:
  store i32 2, ptr %l284, !tbaa !23
  call void @__olang_scope_close(ptr %s49)
  %t720 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t722 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t720)
  store i32 %t722, ptr %l286
  %t723 = icmp ne i32 %t722, 0
  br i1 %t723, label %bb184, label %ok.724
ok.724:
  br label %bb183
bb183:
  br label %bb188
bb184:
  %t725 = load i32, ptr %l286, !tbaa !23
  %t726 = ashr i32 %t725, 16
  %t728 = icmp eq i32 %t726, 1
  br i1 %t728, label %bb185, label %bb186
bb185:
  br label %bb187
bb186:
  call void @__olang_check_failed(ptr @olang_loc_e5d149819eaf9bc3_77be55e8f180b557)
  unreachable
bb187:
  call void @__olang_ert_req_clear()
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s0)
  %t730 = load i32, ptr %l284, !tbaa !23
  store i32 %t730, ptr %rv
  br label %ret
bb189:
  store i32 0, ptr %l289, !tbaa !23
  %t731 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t733 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t731)
  store i32 %t733, ptr %l291
  %t734 = icmp ne i32 %t733, 0
  br i1 %t734, label %bb191, label %ok.735
ok.735:
  br label %bb190
bb190:
  br label %bb195
bb191:
  %t736 = load i32, ptr %l291, !tbaa !23
  %t737 = ashr i32 %t736, 16
  %t739 = icmp eq i32 %t737, 1
  br i1 %t739, label %bb192, label %bb193
bb192:
  br label %bb194
bb193:
  call void @__olang_check_failed(ptr @olang_loc_e5d149819eaf9bc3_77be55e8f180b557)
  unreachable
bb194:
  call void @__olang_ert_req_clear()
  br label %bb195
bb195:
  call void @__olang_scope_close(ptr %s0)
  %t741 = load i32, ptr %l289, !tbaa !23
  store i32 %t741, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2etext(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d280, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l11, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t28 = load ptr, ptr %l13, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l13, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 5
  store i1 %t34, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t35 = load i1, ptr %l14, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { { i64, ptr } }, ptr %t38, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = extractvalue { i64, ptr } %t42, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d281, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t50, ptr %l22, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l23, !tbaa !24
  %t53 = load i64, ptr %l23, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l24, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l23, !tbaa !24
  %t63 = mul i64 %t62, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %t61, i64 %t63, i1 false)
  %t64 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t64, ptr %l22, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_433ff8d12b25a21d_ce9dc62322af2169)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %s0, ptr %a0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d282, i32 0, i32 1) })
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d283, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %v0, ptr %v1, ptr %v1, ptr %t25, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d284, i32 0, i32 1) })
  store { i64, ptr } %t27, ptr %l11
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l37 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d285, i32 0, i32 1) })
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  %t6 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr i8, ptr %t7, i64 0
  %t9 = load i8, ptr %t8, !tbaa !32
  %t11 = icmp eq i8 %t9, 95
  store i1 %t11, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb9, label %bb10
bb9:
  br label %bb24
bb10:
  br label %bb11
bb11:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  store i8 %t35, ptr %l4, !tbaa !22
  %t37 = load i8, ptr %l4, !tbaa !22
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t37)
  store i1 %t39, ptr %l23
  br label %bb12
bb12:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb16
bb14:
  %t41 = load i8, ptr %l4, !tbaa !22
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t41)
  store i1 %t43, ptr %l26
  br label %bb15
bb15:
  %t44 = load i1, ptr %l26, !tbaa !21
  store i1 %t44, ptr %l24, !tbaa !21
  br label %bb16
bb16:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb19
bb18:
  %t46 = load i8, ptr %l4, !tbaa !22
  %t48 = icmp eq i8 %t46, 95
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb19
bb19:
  %t50 = load i1, ptr %l27, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t54 = load i64, ptr %l2, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l2, !tbaa !24
  br label %bb8
bb24:
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = call i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %t58, i64 0, i64 %t61)
  store i32 %t64, ptr %l37
  br label %bb25
bb25:
  %t65 = load i32, ptr %l37
  %t67 = trunc i64 1 to i32
  %t68 = icmp eq i32 %t65, %t67
  call void @__olang_scope_close(ptr %s0)
  store i1 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/bindgen:cFunc" @compiler_2fbindgen_3acFunc_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/bindgen:cFunc"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/bindgen:cFunc" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/bindgen:cFunc" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/bindgen:cFunc" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/bindgen:cFunc" %t14, i1 %a3, 3
  store %"compiler/bindgen:cFunc" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cFunc", ptr %rv
  ret %"compiler/bindgen:cFunc" %rr
}

define dso_local %"compiler/bindgen:ctp" @compiler_2fbindgen_3actp_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %rv = alloca %"compiler/bindgen:ctp"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"compiler/bindgen:ctp" undef, { i64, ptr } %a0, 0
  %t6 = insertvalue %"compiler/bindgen:ctp" %t4, i64 0, 1
  store %"compiler/bindgen:ctp" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:ctp", ptr %rv
  ret %"compiler/bindgen:ctp" %rr
}

define dso_local %"compiler/bindgen:ctype" @compiler_2fbindgen_3actype_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1, i64 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/bindgen:ctype"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/bindgen:ctype" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/bindgen:ctype" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/bindgen:ctype" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/bindgen:ctype" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/bindgen:ctype" %t18, i64 %a4, 4
  %t22 = insertvalue %"compiler/bindgen:ctype" %t20, i64 0, 5
  store %"compiler/bindgen:ctype" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:ctype", ptr %rv
  ret %"compiler/bindgen:ctype" %rr
}

define dso_local void @compiler_2fbindgen_3agen_2ector(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"compiler/bindgen:gen"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  %t3 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l18
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l3
  %t7 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l19
  br label %bb3
bb3:
  %t8 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l4
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l20
  br label %bb4
bb4:
  %t10 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l5
  %t11 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l21
  br label %bb5
bb5:
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l6
  %t13 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l22
  br label %bb6
bb6:
  %t14 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l7
  %t15 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l23
  br label %bb7
bb7:
  %t16 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l8
  %t17 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l24
  br label %bb8
bb8:
  %t18 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l9
  %t19 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l25
  br label %bb9
bb9:
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l10
  %t21 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l26
  br label %bb10
bb10:
  %t22 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l11
  %t23 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l27
  br label %bb11
bb11:
  %t24 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d286, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t25 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 0
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t26, ptr %t25, !tbaa !27
  %t27 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 1
  %t28 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %t27
  %t29 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 2
  %t30 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %t29
  %t31 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 3
  %t32 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %t31
  %t33 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 4
  %t34 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %t33
  %t35 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 5
  %t36 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %t35
  %t37 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 6
  %t38 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %t37
  %t39 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 7
  %t40 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %t39
  %t41 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 8
  %t42 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %t41
  %t43 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 9
  %t44 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %t43
  %t45 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 10
  %t46 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %t45
  %t47 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %t47
  %t49 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 12
  store i1 false, ptr %t49, !tbaa !21
  %t51 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 13
  %t52 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t52, ptr %t51, !tbaa !27
  %t53 = getelementptr %"compiler/bindgen:gen", ptr %l28, i32 0, i32 14
  store i64 0, ptr %t53, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l28, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/bindgen:record" @compiler_2fbindgen_3arecord_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/bindgen:record"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i1 false, ptr %l2, !tbaa !21
  store i1 false, ptr %l3, !tbaa !21
  store i1 false, ptr %l4, !tbaa !21
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l5
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l13
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d287, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = insertvalue %"compiler/bindgen:record" undef, { i64, ptr } %t7, 0
  %t9 = load i1, ptr %l2, !tbaa !21
  %t10 = insertvalue %"compiler/bindgen:record" %t8, i1 %t9, 1
  %t11 = load i1, ptr %l3, !tbaa !21
  %t12 = insertvalue %"compiler/bindgen:record" %t10, i1 %t11, 2
  %t13 = load i1, ptr %l4, !tbaa !21
  %t14 = insertvalue %"compiler/bindgen:record" %t12, i1 %t13, 3
  %t15 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t16 = insertvalue %"compiler/bindgen:record" %t14, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 4
  %t18 = insertvalue %"compiler/bindgen:record" %t16, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, 5
  %t20 = insertvalue %"compiler/bindgen:record" %t18, i1 false, 6
  %t21 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t22 = insertvalue %"compiler/bindgen:record" %t20, { i64, ptr } %t21, 7
  %t24 = insertvalue %"compiler/bindgen:record" %t22, i1 false, 8
  %t26 = insertvalue %"compiler/bindgen:record" %t24, i64 -1, 9
  store %"compiler/bindgen:record" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:record", ptr %rv
  ret %"compiler/bindgen:record" %rr
}

declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"const" }>, align 8
@.d8 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"volatile" }>, align 8
@.d9 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"restrict" }>, align 8
@.d10 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"__restrict" }>, align 8
@.d11 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"const" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d23 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d29 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d30 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a struct held in place that is not plain data (X11)" }>, align 8
@.d31 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"CStr?&" }>, align 8
@.d32 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d33 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a field of this type, which has no olang form" }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"its type is no function's" }>, align 8
@.d36 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d37 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"it takes a variable number of arguments" }>, align 8
@.d38 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d45 = private constant <{ i64, [3 x { i64, ptr }] }> <{ i64 0, [3 x { i64, ptr }] [{ i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d288, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d289, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d290, i32 0, i32 1) }] }>, align 8
@.d46 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct " }>, align 8
@.d49 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"union " }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c_" }>, align 8
@.d55 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"_t" }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_Bool" }>, align 8
@.d59 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bool" }>, align 8
@.d60 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d61 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d62 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d63 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d64 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d65 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d66 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d67 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d68 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"long double" }>, align 8
@.d69 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d70 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_Float16" }>, align 8
@.d71 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d72 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"__bf16" }>, align 8
@.d73 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d74 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__int128" }>, align 8
@.d75 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__int128" }>, align 8
@.d76 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"short" }>, align 8
@.d77 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d78 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d79 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d80 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d81 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d82 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d83 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"CVoid" }>, align 8
@.d84 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"CStr" }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d86 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"a typedef that names itself" }>, align 8
@.d87 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d88 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"', which is no C type read here" }>, align 8
@.d89 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d90 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d91 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d93 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"mut Array<" }>, align 8
@.d94 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">&" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d97 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d98 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mut Array<CStr?&>&" }>, align 8
@.d99 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"mut Array<" }>, align 8
@.d100 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"?&>&" }>, align 8
@.d101 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mut Array<CVoid?&>&" }>, align 8
@.d102 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d103 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a callback taking a variable number of arguments" }>, align 8
@.d104 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn(" }>, align 8
@.d105 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d106 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d109 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d110 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"loc" }>, align 8
@.d111 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"range" }>, align 8
@.d112 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"type" }>, align 8
@.d113 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"inner" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d114 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d115 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d116 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"TypedefDecl" }>, align 8
@.d117 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"ownedTagDecl" }>, align 8
@.d118 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"id" }>, align 8
@.d119 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct " }>, align 8
@.d120 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"union " }>, align 8
@.d121 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"RecordDecl" }>, align 8
@.d122 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d123 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d124 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"EnumConstantDecl" }>, align 8
@.d125 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d126 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d127 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"FunctionDecl" }>, align 8
@.d128 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d129 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"ParmVarDecl" }>, align 8
@.d130 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d131 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"storageClass" }>, align 8
@.d132 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"static" }>, align 8
@.d133 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"inline" }>, align 8
@.d134 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"VarDecl" }>, align 8
@.d135 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c": a variable - an extern variable has no olang form (X1)" }>, align 8
@.d136 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"tagUsed" }>, align 8
@.d137 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"union" }>, align 8
@.d138 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d139 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d140 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"id" }>, align 8
@.d141 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"union " }>, align 8
@.d142 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct " }>, align 8
@.d143 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"completeDefinition" }>, align 8
@.d144 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d145 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"RecordDecl" }>, align 8
@.d146 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d147 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"FieldDecl" }>, align 8
@.d148 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"isBitfield" }>, align 8
@.d149 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d150 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d151 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" struct() {\0A" }>, align 8
@.d152 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d153 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d154 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" := Array<" }>, align 8
@.d155 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">(" }>, align 8
@.d156 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d157 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d158 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d159 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d160 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d161 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d162 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"includedFrom" }>, align 8
@.d163 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"file" }>, align 8
@.d164 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d165 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d166 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d167 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"const" }>, align 8
@.d168 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"volatile" }>, align 8
@.d169 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"restrict" }>, align 8
@.d170 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"__restrict" }>, align 8
@.d171 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"signed" }>, align 8
@.d172 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"unsigned" }>, align 8
@.d173 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"long" }>, align 8
@.d174 = private constant <{ i64, [11 x { i64, ptr }] }> <{ i64 0, [11 x { i64, ptr }] [{ i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d291, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d292, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d288, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d293, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d294, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d295, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d296, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d297, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d298, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d299, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d300, i32 0, i32 1) }] }>, align 8
@.d175 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"int" }>, align 8
@.d176 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"struct" }>, align 8
@.d177 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d178 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"union" }>, align 8
@.d179 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"enum" }>, align 8
@.d180 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d181 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d182 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d183 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"enum" }>, align 8
@.d184 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d185 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d186 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d187 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d188 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d189 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"', a " }>, align 8
@.d190 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c" with no name of its own, or the C compiler's" }>, align 8
@.d191 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d192 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d193 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d194 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d195 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"', a type no declaration names" }>, align 8
@.d196 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d197 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d198 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a struct by value that is not plain data (X11)" }>, align 8
@.d199 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"CStr?&" }>, align 8
@.d200 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d201 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d202 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d203 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d204 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"a pointer to plain-data struct " }>, align 8
@.d205 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c" as a result - an extern gives only an extern type's reference (X2)" }>, align 8
@.d206 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a value of this type, which has no olang form" }>, align 8
@.d207 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d208 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"CVoid?&" }>, align 8
@.d209 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c": static or inline in the header - no symbol to link" }>, align 8
@.d210 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c": a name olang cannot declare (a keyword, or beginning with '_')" }>, align 8
@.d211 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d212 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d213 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"# Generated by olang bindgen from " }>, align 8
@.d214 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d215 = private constant <{ i64, [99 x i8] }> <{ i64 0, [99 x i8] c"# its C declarations as olang declares them (X1-X13), the library linked by a line beside them, as\0A" }>, align 8
@.d216 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"# `link \22NAME\22` (X9).\0A" }>, align 8
@.d217 = private constant <{ i64, [109 x i8] }> <{ i64 0, [109 x i8] c"\0A# a pointer C passes as it is: \22void *\22, and any other this file gives no form of its own\0Aextern type CVoid\0A" }>, align 8
@.d218 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d219 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"extern type " }>, align 8
@.d220 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d221 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d222 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d223 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d224 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d225 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d226 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"\0A# not declared:\0A" }>, align 8
@.d227 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"#   " }>, align 8
@.d228 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d229 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"value" }>, align 8
@.d230 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d231 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d232 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d233 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"inner" }>, align 8
@.d234 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d235 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"define" }>, align 8
@.d236 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d237 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"olang: bindgen needs clang, which is not on the PATH\0A" }>, align 8
@.d238 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d239 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c": no such file\0A" }>, align 8
@.d240 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d241 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c": cannot be read\0A" }>, align 8
@.d242 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d243 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang-bindgen" }>, align 8
@.d244 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"olang: bindgen: cannot make a temporary directory\0A" }>, align 8
@.d245 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"probe.c" }>, align 8
@.d246 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d247 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d248 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d249 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d250 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"#include \22" }>, align 8
@.d251 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\0A" }>, align 8
@.d252 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"enum __olang_m" }>, align 8
@.d253 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" : long long { __olang_v" }>, align 8
@.d254 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" = (" }>, align 8
@.d255 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c") };\0A" }>, align 8
@.d256 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"olang: bindgen: cannot write " }>, align 8
@.d257 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d258 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d259 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d260 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"-fsyntax-only" }>, align 8
@.d261 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-w" }>, align 8
@.d262 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"-ferror-limit=0" }>, align 8
@.d263 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-Xclang" }>, align 8
@.d264 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"-ast-dump=json" }>, align 8
@.d265 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d266 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d267 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"olang: bindgen: clang could not be run\0A" }>, align 8
@.d268 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"olang: bindgen: clang could not read " }>, align 8
@.d269 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d270 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"olang: bindgen: clang's tree of " }>, align 8
@.d271 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" could not be read\0A" }>, align 8
@.d272 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d273 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d274 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d275 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"__olang_m" }>, align 8
@.d276 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d277 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d278 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d279 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d280 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d281 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d282 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"type" }>, align 8
@.d283 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d284 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"qualType" }>, align 8
@.d285 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d286 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d287 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d288 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d289 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d290 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d291 = private unnamed_addr constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"short" }>, align 8
@.d292 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"int" }>, align 8
@.d293 = private unnamed_addr constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d294 = private unnamed_addr constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d295 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d296 = private unnamed_addr constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_Bool" }>, align 8
@.d297 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bool" }>, align 8
@.d298 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_Float16" }>, align 8
@.d299 = private unnamed_addr constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"__bf16" }>, align 8
@.d300 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__int128" }>, align 8
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
@olang_loc_d0c4be1b37fb70ff_4af1c68652343f9b = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eSetAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/bindgen:ctype" %a2)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_582986fcdf40d11c_2a39a940a03de888 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd80cb4cbc6ceb8a13686fbc19b8451b4(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H116ed76223103781f5a7340c80f3d0f3(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_a14853be10f42619_d5c3261a58ff8505 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_31d0fb4875bfcdcf_cab745411c3f21db = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/bindgen:record" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ePush_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:ctype" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eLen_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_e8c29cca38e7747c_62862859d6377258 = external constant [0 x i8]
@olang_loc_55ef846781ac27aa_5519550b25564c26 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ePush_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:cFunc" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ePush_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:record" %a1)
@olang_loc_15971967adc848fb_c06c6f64909b248f = external constant [0 x i8]
@olang_loc_66f8b08a9932247a_88b90d6010cc404e = external constant [0 x i8]
declare i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %a0)
@olang_loc_c54e19abcb0a74ad_a74456fc2d527de1 = external constant [0 x i8]
@olang_loc_302d290203cc94fc_f1ac1451fbe7e850 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
@olang_loc_383dad6bbc51ebc3_b2d1cf432887049f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %a0)
declare %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_23d1865e1592def5_3b70fe728274d559 = external constant [0 x i8]
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_12d4b4c126d079e6_1af6ce2ce1af3fd2 = external constant [0 x i8]
@olang_loc_c89c4e9e31b29b9e_9d77991e4d65189a = external constant [0 x i8]
@olang_loc_6ea08524187c2be0_2ef7bb2e3d9cc7b4 = external constant [0 x i8]
@olang_loc_feb39f4cfa8fb0e2_4824786a1f7bac1e = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_a7c60743b5b597e4_82f0175d19c7c2b0 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
@olang_loc_781c284b896a8fce_cdc9de06e02cea = external constant [0 x i8]
@olang_loc_d037eabd3d0bc2d_e7dbd50ce824989 = external constant [0 x i8]
@olang_loc_45e5c64e9ba550_8364d6509df24c1c = external constant [0 x i8]
@olang_loc_76a363c24681a0e6_dedc35590a663c5a = external constant [0 x i8]
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_735249e9ceddf5f_d7039875715975bb = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_eab50b55b0b012de_9795516d577fe93a = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d1474ea2005c0415_1a999b446b4483d1 = external constant [0 x i8]
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_883df75978b19524_14c3f49651dc1b40 = external constant [0 x i8]
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_e5d149819eaf9bc3_77be55e8f180b557 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_a9d4a365d2ff5442_94c7a520dca621b6 = external constant [0 x i8]
declare { i32, ptr } @std_2fjson_2eParse(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@olang_loc_5511421d896f74b9_e721aeb44849284d = external constant [0 x i8]
@olang_loc_d2547e7fa6ec69ef_6f5f269cee95a513 = external constant [0 x i8]
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
@olang_loc_4f5e3b4e248943b7_ce5257eefd522463 = external constant [0 x i8]
@olang_loc_3fac94b3e5d2b496_322e3413c3c14662 = external constant [0 x i8]
@olang_loc_433ff8d12b25a21d_ce9dc62322af2169 = external constant [0 x i8]
declare i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
