; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/bindgen:Translation" = type { { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/bindgen:gen" = type { { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/bindgen:cMacro" = type { { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/bindgen:ctp" = type { { i64, ptr }, i64 }
%"compiler/bindgen:cx" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/bindgen:cparse" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/bindgen:ctype" = type { i32, { i64, ptr }, i64, i1, i64, i64 }
%"compiler/bindgen:cFunc" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, { i64, ptr } }
%"compiler/bindgen:record" = type { { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, i1, i64, i1, { i64, ptr }, i1, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/json:Object" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
@G_2ecompiler_2fbindgen_2eKBool = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbindgen_2eKFloat = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbindgen_2eKInt = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbindgen_2eKType = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbindgen_2eKVar = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbindgen_2eNoReturnAttr = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\1A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2eNoReturnAttr.k1 }>, align 8
@G_2ecompiler_2fbindgen_2eNoReturnAttr.k1 = internal global <{ [26 x i8] }> <{ [26 x i8] c"\20\5F\5F\61\74\74\72\69\62\75\74\65\5F\5F\28\28\6E\6F\72\65\74\75\72\6E\29\29" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k1, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k2, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k3, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k5, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k6, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k8, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k9, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k10, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k11, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k12, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k13, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k14, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k15, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k16, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k17, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k18, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbindgen_2epreludeNames.k19 }>, align 64
@G_2ecompiler_2fbindgen_2epreludeNames.k1 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\53\74\72\69\6E\67" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k2 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\41\72\72\61\79" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k3 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\42\6F\6F\6C" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\43\68\61\72" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\56\65\63" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\4D\61\70" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k7 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\53\74\72\69\6E\67\42\75\69\6C\64\65\72" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\43\53\74\72" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k9 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\43\56\6F\69\64" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k10 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\49\74\65\72\61\74\6F\72" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k11 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\45\78\68\61\75\73\74\65\64" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k12 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\50\69" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k13 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\45\75\6C\65\72" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k14 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\6E\66" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k15 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\4E\61\4E" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k16 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\46\6C\6F\61\74" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k17 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\49\6E\74\65\67\65\72" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k18 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\4E\75\6D\62\65\72" }>, align 8
@G_2ecompiler_2fbindgen_2epreludeNames.k19 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\47\65\6E\65\72\61\74\6F\72" }>, align 8
define dso_local %"compiler/bindgen:Translation" @compiler_2fbindgen_2eTranslate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca [2 x { i64, ptr }]
  %l9 = alloca { i64, ptr }
  %lp10 = alloca ptr
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %lp20 = alloca ptr
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca %"compiler/bindgen:Translation"
  %l42 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l48 = alloca i1
  %l56 = alloca { i64, ptr }
  %l62 = alloca i32
  %l64 = alloca i1
  %l67 = alloca %"compiler/bindgen:Translation"
  %l69 = alloca %"compiler/bindgen:Translation"
  %l71 = alloca i32
  %l73 = alloca i1
  %l77 = alloca i1
  %l79 = alloca { i64, ptr }
  %l83 = alloca %"compiler/bindgen:gen"
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca { i64, ptr }
  %l129 = alloca %"std/os:Output"
  %l131 = alloca { i64, ptr }
  %l132 = alloca %"std/os:Output"
  %l133 = alloca i32
  %l135 = alloca i1
  %l136 = alloca %"compiler/bindgen:Translation"
  %l138 = alloca %"compiler/bindgen:Translation"
  %l140 = alloca i32
  %l142 = alloca i1
  %l149 = alloca { i64, ptr }
  %l150 = alloca i1
  %l152 = alloca { i64, ptr }
  %l154 = alloca %"compiler/bindgen:Translation"
  %l156 = alloca %"compiler/bindgen:Translation"
  %l158 = alloca i32
  %l160 = alloca i1
  %l168 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l169 = alloca %"std/prelude/text:StringBuilder"
  %l175 = alloca i64
  %l177 = alloca i64
  %l183 = alloca i64
  %l184 = alloca ptr
  %l185 = alloca i64
  %l186 = alloca i64
  %l189 = alloca %"compiler/bindgen:cMacro"
  %l195 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l200 = alloca i32
  %l202 = alloca i1
  %l205 = alloca %"compiler/bindgen:Translation"
  %l207 = alloca %"compiler/bindgen:Translation"
  %l209 = alloca i32
  %l211 = alloca i1
  %l214 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca i32
  %l222 = alloca i1
  %l224 = alloca %"compiler/bindgen:Translation"
  %l226 = alloca %"compiler/bindgen:Translation"
  %l228 = alloca i32
  %l230 = alloca i1
  %l237 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l251 = alloca { i64, ptr }
  %l253 = alloca i1
  %l255 = alloca i1
  %l257 = alloca i1
  %l259 = alloca i64
  %l261 = alloca i64
  %l262 = alloca i64
  %l266 = alloca { i64, ptr }
  %l267 = alloca i64
  %l268 = alloca i32
  %l269 = alloca i64
  %l270 = alloca i32
  %l273 = alloca i1
  %l274 = alloca i64
  %l276 = alloca i64
  %l279 = alloca { i64, ptr }
  %l287 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l293 = alloca i1
  %l294 = alloca i64
  %l295 = alloca { i64, ptr }
  %l296 = alloca i64
  %l297 = alloca i32
  %l298 = alloca i64
  %l299 = alloca i32
  %l300 = alloca ptr
  %l301 = alloca ptr
  %l304 = alloca i64
  %l305 = alloca %"compiler/bindgen:cMacro"
  %l318 = alloca i32
  %l320 = alloca i1
  %l322 = alloca %"compiler/bindgen:Translation"
  %l324 = alloca %"compiler/bindgen:Translation"
  %l326 = alloca i32
  %l328 = alloca i1
  %l335 = alloca { i64, ptr }
  %l338 = alloca i64
  %l340 = alloca i1
  %l342 = alloca i1
  %l344 = alloca { i64, ptr }
  %l345 = alloca { i64, ptr }
  %l347 = alloca { i64, ptr }
  %l350 = alloca %"compiler/bindgen:Translation"
  %l352 = alloca %"compiler/bindgen:Translation"
  %l354 = alloca i32
  %l356 = alloca i1
  %s0 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %rv = alloca %"compiler/bindgen:Translation"
  %t123 = alloca %"compiler/bindgen:gen", align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/bindgen:Translation" @compiler_2fbindgen_3aTranslation_2ector(ptr %v6)
  store %"compiler/bindgen:Translation" %t1, ptr %l40
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 88, i64 8)
  store ptr %t2, ptr %lp6
  %t3 = load %"compiler/bindgen:Translation", ptr %l40
  %t4 = load ptr, ptr %lp6
  store %"compiler/bindgen:Translation" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t7, ptr %l42
  br label %bb2
bb2:
  %t8 = load i1, ptr %l42, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %lp6
  %t10 = getelementptr %"compiler/bindgen:Translation", ptr %t9, i32 0, i32 3
  store { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %t10, !tbaa !27
  %t11 = load ptr, ptr %lp6
  %t12 = load %"compiler/bindgen:Translation", ptr %t11
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/bindgen:Translation" %t12, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d3, i32 0, i32 1) })
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l46
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb7, label %ok.18, !prof !99
ok.18:
  store { i64, ptr } %t15, ptr %l45
  br label %bb6
bb6:
  %t19 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t19, ptr %l44, !tbaa !27
  br label %bb11
bb7:
  %t20 = load i32, ptr %l46, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l48, !tbaa !21
  %t24 = load i32, ptr %l46, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %lp6
  %t30 = getelementptr %"compiler/bindgen:Translation", ptr %t29, i32 0, i32 3
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %t30, !tbaa !27
  %t31 = load ptr, ptr %lp6
  %t32 = load %"compiler/bindgen:Translation", ptr %t31
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/bindgen:Translation" %t32, ptr %rv
  br label %ret
bb11:
  %t34 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t34, ptr %l7, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t37 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t35, 0
  %t38 = insertvalue [2 x { i64, ptr }] %t37, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t38, ptr %l8
  %t41 = insertvalue { i64, ptr } undef, i64 2, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %l8, 1
  %t44 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t42)
  store { i64, ptr } %t44, ptr %l56
  br label %bb12
bb12:
  %t45 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t45, ptr %l9, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = extractvalue { i64, ptr } %t47, 0
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t49, i64 %t50)
  %t55 = getelementptr i8, ptr %t54, i64 %t50
  call void @olang_textcopy(ptr %t55, ptr %t51, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t60 = extractvalue { i64, ptr } %t57, 0
  %t61 = extractvalue { i64, ptr } %t57, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t68 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t46, { i64, ptr } %t65)
  store i32 %t68, ptr %l62
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb14, label %ok.70, !prof !99
ok.70:
  br label %bb13
bb13:
  br label %bb25
bb14:
  %t71 = load i32, ptr %l62, !tbaa !23
  %t72 = ashr i32 %t71, 16
  %t74 = icmp eq i32 %t72, 1
  store i1 %t74, ptr %l64, !tbaa !21
  %t75 = load i32, ptr %l62, !tbaa !23
  %t76 = ashr i32 %t75, 16
  %t78 = icmp eq i32 %t76, 1
  br i1 %t78, label %bb15, label %bb16
bb15:
  call void @__olang_errpay_pop()
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t80 = load ptr, ptr %lp6
  %t81 = getelementptr %"compiler/bindgen:Translation", ptr %t80, i32 0, i32 3
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %t81, !tbaa !27
  %t82 = load ptr, ptr %lp6
  %t83 = load %"compiler/bindgen:Translation", ptr %t82
  store %"compiler/bindgen:Translation" %t83, ptr %l67
  %t85 = call %"compiler/bindgen:Translation" @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3aTranslation(ptr %v6, ptr %l67)
  store %"compiler/bindgen:Translation" %t85, ptr %l69
  br label %bb18
bb18:
  %t86 = load %"compiler/bindgen:Translation", ptr %l69
  store %"compiler/bindgen:Translation" %t86, ptr %l67
  %t87 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t89 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t87)
  store i32 %t89, ptr %l71
  %t90 = icmp ne i32 %t89, 0
  br i1 %t90, label %bb20, label %ok.91, !prof !99
ok.91:
  br label %bb19
bb19:
  br label %bb24
bb20:
  %t92 = load i32, ptr %l71, !tbaa !23
  %t93 = ashr i32 %t92, 16
  %t95 = icmp eq i32 %t93, 1
  store i1 %t95, ptr %l73, !tbaa !21
  %t96 = load i32, ptr %l71, !tbaa !23
  %t97 = ashr i32 %t96, 16
  %t99 = icmp eq i32 %t97, 1
  br i1 %t99, label %bb21, label %bb22
bb21:
  call void @__olang_errpay_pop()
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t101 = load %"compiler/bindgen:Translation", ptr %l67
  store %"compiler/bindgen:Translation" %t101, ptr %rv
  br label %ret
bb25:
  %t102 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t104 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t102, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t104, ptr %l77
  br label %bb26
bb26:
  %t105 = load i1, ptr %l77, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t108 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = extractvalue { i64, ptr } %t108, 0
  %t112 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t110, i64 %t111)
  %t113 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } %t114, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  store { i64, ptr } %t121, ptr %l79, !tbaa !27
  br label %bb29
bb28:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l79, !tbaa !27
  br label %bb29
bb29:
  %t124 = load { i64, ptr }, ptr %l79, !tbaa !27
  call void @compiler_2fbindgen_3agen_2ector(ptr %t123, ptr %v6, ptr %v6, { i64, ptr } %t124)
  call void @llvm.memmove.p0.p0.i64(ptr %l83, ptr %t123, i64 1128, i1 false)
  br label %bb30
bb30:
  %t125 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 1128, i64 8)
  store ptr %t125, ptr %lp10
  %t126 = load ptr, ptr %lp10
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %l83, i64 1128, i1 false)
  %t127 = load ptr, ptr %lp10
  %t128 = getelementptr %"compiler/bindgen:gen", ptr %t127, i32 0, i32 1
  store i1 true, ptr %t128, !tbaa !21
  %t131 = extractvalue { i64, ptr } %a4, 1
  %t132 = extractvalue { i64, ptr } %a4, 0
  %t133 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t131, i64 %t132)
  %t134 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = extractvalue { i64, ptr } %t135, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t144 = load ptr, ptr %lp10
  %t145 = getelementptr %"compiler/bindgen:gen", ptr %t144, i32 0, i32 2
  store { i64, ptr } %t142, ptr %t145, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = extractvalue { i64, ptr } %t146, 0
  %t150 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t148, i64 %t149)
  %t151 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t161 = load ptr, ptr %lp10
  %t162 = getelementptr %"compiler/bindgen:gen", ptr %t161, i32 0, i32 3
  store { i64, ptr } %t159, ptr %t162, !tbaa !27
  %t163 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %l90
  br label %bb31
bb31:
  %t164 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %l11
  %t165 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t167, i64 %t168)
  %t170 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = extractvalue { i64, ptr } %t171, 1
  %t175 = mul i64 %t173, 1
  %t176 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t174, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l11, { i64, ptr } %t178)
  br label %bb32
bb32:
  %t181 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t181, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  store i64 %t185, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  %t187 = load i64, ptr %l13, !tbaa !24
  %t188 = load i64, ptr %l14, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb34, label %bb35
bb34:
  br label %bb39
bb35:
  br label %bb36
bb36:
  %t195 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t195, ptr %l102, !tbaa !27
  %t196 = load i64, ptr %l13, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, ptr }, ptr %t199, i64 %t196
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !37
  %t205 = extractvalue { i64, ptr } %t201, 1
  %t206 = extractvalue { i64, ptr } %t201, 0
  %t207 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t206)
  call void @olang_textcopy(ptr %t207, ptr %t205, i64 %t206)
  %t208 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t212 = extractvalue { i64, ptr } %t209, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l11, { i64, ptr } %t216)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t219 = load i64, ptr %l13, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l13, !tbaa !24
  br label %bb33
bb39:
  store %olang.scope zeroinitializer, ptr %s16
  %t223 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t224 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t225 = insertvalue [6 x { i64, ptr }] %t224, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t226 = insertvalue [6 x { i64, ptr }] %t225, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 2
  %t227 = insertvalue [6 x { i64, ptr }] %t226, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 3
  %t228 = insertvalue [6 x { i64, ptr }] %t227, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 4
  %t230 = insertvalue [6 x { i64, ptr }] %t228, { i64, ptr } %t223, 5
  %t232 = call ptr @__olang_scope_alloc_a(ptr %s16, i64 96, i64 8)
  store [6 x { i64, ptr }] %t230, ptr %t232
  store ptr %t232, ptr %l16
  store i64 0, ptr %l17, !tbaa !24
  %t234 = load ptr, ptr %l16
  store i64 6, ptr %l18, !tbaa !24
  br label %bb40
bb40:
  %t237 = load i64, ptr %l17, !tbaa !24
  %t238 = load i64, ptr %l18, !tbaa !24
  %t241 = icmp slt i64 %t237, %t238
  %t243 = xor i1 %t241, true
  br i1 %t243, label %bb41, label %bb42
bb41:
  br label %bb46
bb42:
  br label %bb43
bb43:
  %t245 = load ptr, ptr %l16
  %t246 = load i64, ptr %l17, !tbaa !24
  %t249 = getelementptr [6 x { i64, ptr }], ptr %t245, i64 0, i64 %t246
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !37
  %t254 = extractvalue { i64, ptr } %t250, 1
  %t255 = extractvalue { i64, ptr } %t250, 0
  %t256 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t254, i64 %t255)
  %t257 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = extractvalue { i64, ptr } %t258, 1
  %t262 = mul i64 %t260, 1
  %t263 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t262)
  call void @llvm.memcpy.p0.p0.i64(ptr %t263, ptr %t261, i64 %t262, i1 false)
  %t264 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l11, { i64, ptr } %t265)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t268 = load i64, ptr %l17, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l17, !tbaa !24
  br label %bb40
bb46:
  call void @__olang_scope_close(ptr %s16)
  %t273 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l11)
  store { i64, ptr } %t273, ptr %l131
  br label %bb47
bb47:
  %t274 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t275 = call { i32, %"std/os:Output" } @compiler_2fbindgen_2eclangSays(ptr %s0, ptr %v6, { i64, ptr } %t274)
  %t276 = extractvalue { i32, %"std/os:Output" } %t275, 1
  %t277 = extractvalue { i32, %"std/os:Output" } %t275, 0
  store i32 %t277, ptr %l133
  %t278 = icmp ne i32 %t277, 0
  br i1 %t278, label %bb49, label %ok.279, !prof !99
ok.279:
  store %"std/os:Output" %t276, ptr %l132
  br label %bb48
bb48:
  %t280 = load %"std/os:Output", ptr %l132
  store %"std/os:Output" %t280, ptr %l129
  br label %bb58
bb49:
  %t281 = load i32, ptr %l133, !tbaa !23
  %t282 = ashr i32 %t281, 16
  %t284 = icmp eq i32 %t282, 1
  store i1 %t284, ptr %l135, !tbaa !21
  br label %bb50
bb50:
  %t285 = load ptr, ptr %lp6
  %t286 = getelementptr %"compiler/bindgen:Translation", ptr %t285, i32 0, i32 3
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %t286, !tbaa !27
  %t287 = load ptr, ptr %lp6
  %t288 = load %"compiler/bindgen:Translation", ptr %t287
  store %"compiler/bindgen:Translation" %t288, ptr %l136
  %t290 = call %"compiler/bindgen:Translation" @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3aTranslation(ptr %v6, ptr %l136)
  store %"compiler/bindgen:Translation" %t290, ptr %l138
  br label %bb51
bb51:
  %t291 = load %"compiler/bindgen:Translation", ptr %l138
  store %"compiler/bindgen:Translation" %t291, ptr %l136
  %t292 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t294 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t292)
  store i32 %t294, ptr %l140
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb53, label %ok.296, !prof !99
ok.296:
  br label %bb52
bb52:
  br label %bb57
bb53:
  %t297 = load i32, ptr %l140, !tbaa !23
  %t298 = ashr i32 %t297, 16
  %t300 = icmp eq i32 %t298, 1
  store i1 %t300, ptr %l142, !tbaa !21
  %t301 = load i32, ptr %l140, !tbaa !23
  %t302 = ashr i32 %t301, 16
  %t304 = icmp eq i32 %t302, 1
  br i1 %t304, label %bb54, label %bb55
bb54:
  call void @__olang_errpay_pop()
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t306 = load %"compiler/bindgen:Translation", ptr %l136
  store %"compiler/bindgen:Translation" %t306, ptr %rv
  br label %ret
bb58:
  %t307 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 40, i64 8)
  store ptr %t307, ptr %lp20
  %t308 = load %"std/os:Output", ptr %l129
  %t309 = load ptr, ptr %lp20
  store %"std/os:Output" %t308, ptr %t309
  %t310 = load ptr, ptr %lp20
  %t311 = getelementptr %"std/os:Output", ptr %t310, i32 0, i32 0
  %t312 = load i32, ptr %t311, !tbaa !23
  %t314 = icmp ne i32 %t312, 0
  br i1 %t314, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s24
  %t316 = load ptr, ptr %lp20
  %t317 = getelementptr %"std/os:Output", ptr %t316, i32 0, i32 2
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l149, !tbaa !27
  %t321 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t322 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v6, ptr %s24, { i64, ptr } %t318, { i64, ptr } %t321)
  store i1 %t322, ptr %l150
  br label %bb61
bb60:
  br label %bb70
bb61:
  %t323 = load i1, ptr %l150, !tbaa !21
  %t324 = load ptr, ptr %lp6
  %t325 = getelementptr %"compiler/bindgen:Translation", ptr %t324, i32 0, i32 4
  store i1 %t323, ptr %t325, !tbaa !21
  %t326 = load ptr, ptr %lp20
  %t327 = getelementptr %"std/os:Output", ptr %t326, i32 0, i32 2
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  %t330 = call { i64, ptr } @compiler_2fbindgen_2efirstError(ptr %v6, ptr %v6, { i64, ptr } %t328)
  store { i64, ptr } %t330, ptr %l152
  br label %bb62
bb62:
  %t331 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t331, 0
  %t333 = extractvalue { i64, ptr } %t331, 1
  %t334 = mul i64 %t332, 1
  %t335 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t334)
  call void @llvm.memcpy.p0.p0.i64(ptr %t335, ptr %t333, i64 %t334, i1 false)
  %t336 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t335, 1
  %t339 = load ptr, ptr %lp6
  %t340 = getelementptr %"compiler/bindgen:Translation", ptr %t339, i32 0, i32 3
  store { i64, ptr } %t337, ptr %t340, !tbaa !27
  %t341 = load ptr, ptr %lp6
  %t342 = load %"compiler/bindgen:Translation", ptr %t341
  store %"compiler/bindgen:Translation" %t342, ptr %l154
  %t344 = call %"compiler/bindgen:Translation" @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3aTranslation(ptr %v6, ptr %l154)
  store %"compiler/bindgen:Translation" %t344, ptr %l156
  br label %bb63
bb63:
  %t345 = load %"compiler/bindgen:Translation", ptr %l156
  store %"compiler/bindgen:Translation" %t345, ptr %l154
  call void @__olang_scope_close(ptr %s24)
  %t346 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t348 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t346)
  store i32 %t348, ptr %l158
  %t349 = icmp ne i32 %t348, 0
  br i1 %t349, label %bb65, label %ok.350, !prof !99
ok.350:
  br label %bb64
bb64:
  br label %bb69
bb65:
  %t351 = load i32, ptr %l158, !tbaa !23
  %t352 = ashr i32 %t351, 16
  %t354 = icmp eq i32 %t352, 1
  store i1 %t354, ptr %l160, !tbaa !21
  %t355 = load i32, ptr %l158, !tbaa !23
  %t356 = ashr i32 %t355, 16
  %t358 = icmp eq i32 %t356, 1
  br i1 %t358, label %bb66, label %bb67
bb66:
  call void @__olang_errpay_pop()
  br label %bb67
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t360 = load %"compiler/bindgen:Translation", ptr %l154
  store %"compiler/bindgen:Translation" %t360, ptr %rv
  br label %ret
bb70:
  %t361 = load ptr, ptr %lp10
  %t362 = load ptr, ptr %lp20
  %t363 = getelementptr %"std/os:Output", ptr %t362, i32 0, i32 1
  %t364 = load { i64, ptr }, ptr %t363, !tbaa !27
  %t365 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t366 = load ptr, ptr %lp6
  %t367 = getelementptr %"compiler/bindgen:Translation", ptr %t366, i32 0, i32 2
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ereadMacros(ptr %v6, ptr %v6, ptr %s0, ptr %s0, ptr %v6, ptr %t361, { i64, ptr } %t364, { i64, ptr } %t365, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %t367)
  br label %bb71
bb71:
  %t372 = load ptr, ptr %lp10
  %t374 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eintMacros(ptr %v6, ptr %s0, ptr %t372)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t374, ptr %l168
  br label %bb72
bb72:
  %t375 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l168
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t375, ptr %l21
  %t376 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t376, ptr %l169
  br label %bb73
bb73:
  %t377 = load %"std/prelude/text:StringBuilder", ptr %l169
  store %"std/prelude/text:StringBuilder" %t377, ptr %l22
  %t378 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t378, 1
  %t381 = extractvalue { i64, ptr } %t378, 0
  %t382 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t384 = add i64 %t381, %t383
  %t385 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t380, i64 %t381)
  %t386 = getelementptr i8, ptr %t385, i64 %t381
  call void @olang_textcopy(ptr %t386, ptr %t382, i64 %t383)
  %t387 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t385, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = extractvalue { i64, ptr } %t388, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l22, { i64, ptr } %t395)
  br label %bb74
bb74:
  store ptr %l21, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s30
  %t399 = load i64, ptr %l24, !tbaa !24
  store i64 %t399, ptr %l175, !tbaa !24
  %t400 = load ptr, ptr %l23, !tbaa !29
  %t402 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t400)
  store i64 %t402, ptr %l177
  br label %bb76
bb76:
  %t403 = load i64, ptr %l175, !tbaa !24
  %t404 = load i64, ptr %l177, !tbaa !24
  %t405 = icmp slt i64 %t403, %t404
  %t407 = xor i1 %t405, true
  br i1 %t407, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s30)
  br label %bb84
bb78:
  br label %bb79
bb79:
  %t409 = load i64, ptr %l24, !tbaa !24
  store i64 %t409, ptr %l25, !tbaa !24
  %t411 = load ptr, ptr %l23, !tbaa !29
  %t412 = load i64, ptr %l24, !tbaa !24
  %t415 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t411, i64 %t412)
  store i64 %t415, ptr %l183
  br label %bb80
bb80:
  %t416 = load i64, ptr %l183, !tbaa !24
  store ptr %l22, ptr %l184, !tbaa !29
  %t417 = load i64, ptr %l25, !tbaa !24
  store i64 %t417, ptr %l185, !tbaa !24
  %t418 = load i64, ptr %l25, !tbaa !24
  store i64 %t418, ptr %l186, !tbaa !24
  %t419 = load ptr, ptr %lp10
  %t420 = getelementptr %"compiler/bindgen:gen", ptr %t419, i32 0, i32 12
  %t424 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v6, ptr %v6, ptr %t420, i64 %t416)
  store %"compiler/bindgen:cMacro" %t424, ptr %l189
  br label %bb81
bb81:
  %t425 = getelementptr %"compiler/bindgen:cMacro", ptr %l189, i32 0, i32 0
  %t426 = load { i64, ptr }, ptr %t425, !tbaa !27
  %t427 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t428 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t429 = load i64, ptr %l185, !tbaa !24
  %t430 = call i64 @__olang_fmt_i64(ptr null, i64 %t429)
  %t431 = add i64 %t428, %t430
  %t432 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t433 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t434 = add i64 %t431, %t433
  %t435 = load i64, ptr %l186, !tbaa !24
  %t436 = call i64 @__olang_fmt_i64(ptr null, i64 %t435)
  %t437 = add i64 %t434, %t436
  %t438 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t439 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t440 = add i64 %t437, %t439
  %t442 = extractvalue { i64, ptr } %t426, 1
  %t443 = extractvalue { i64, ptr } %t426, 0
  %t444 = add i64 %t440, %t443
  %t445 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t447 = add i64 %t444, %t446
  %t448 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t447)
  call void @olang_textcopy(ptr %t448, ptr %t427, i64 %t428)
  %t449 = getelementptr i8, ptr %t448, i64 %t428
  %t450 = call i64 @__olang_fmt_i64(ptr %t449, i64 %t429)
  %t451 = getelementptr i8, ptr %t449, i64 %t430
  call void @olang_textcopy(ptr %t451, ptr %t432, i64 %t433)
  %t452 = getelementptr i8, ptr %t451, i64 %t433
  %t453 = call i64 @__olang_fmt_i64(ptr %t452, i64 %t435)
  %t454 = getelementptr i8, ptr %t452, i64 %t436
  call void @olang_textcopy(ptr %t454, ptr %t438, i64 %t439)
  %t455 = getelementptr i8, ptr %t454, i64 %t439
  call void @olang_textcopy(ptr %t455, ptr %t442, i64 %t443)
  %t456 = getelementptr i8, ptr %t455, i64 %t443
  call void @olang_textcopy(ptr %t456, ptr %t445, i64 %t446)
  %t457 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t448, 1
  %t460 = extractvalue { i64, ptr } %t458, 0
  %t461 = extractvalue { i64, ptr } %t458, 1
  %t462 = mul i64 %t460, 1
  %t463 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t462)
  call void @llvm.memcpy.p0.p0.i64(ptr %t463, ptr %t461, i64 %t462, i1 false)
  %t464 = insertvalue { i64, ptr } undef, i64 %t460, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t463, 1
  %t466 = load ptr, ptr %l184, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s30, ptr %t466, { i64, ptr } %t465)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s30)
  br label %bb83
bb83:
  %t468 = load i64, ptr %l24, !tbaa !24
  %t470 = add i64 %t468, 1
  store i64 %t470, ptr %l24, !tbaa !24
  br label %bb75
bb84:
  %t472 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t472, ptr %l195, !tbaa !27
  %t474 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l22)
  store { i64, ptr } %t474, ptr %l197
  br label %bb85
bb85:
  %t475 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t477 = extractvalue { i64, ptr } %t475, 0
  %t478 = extractvalue { i64, ptr } %t475, 1
  %t479 = mul i64 %t477, 1
  %t480 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t479)
  call void @llvm.memcpy.p0.p0.i64(ptr %t480, ptr %t478, i64 %t479, i1 false)
  %t481 = insertvalue { i64, ptr } undef, i64 %t477, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t480, 1
  %t483 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t485 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t483, { i64, ptr } %t482)
  store i32 %t485, ptr %l200
  %t486 = icmp ne i32 %t485, 0
  br i1 %t486, label %bb87, label %ok.487, !prof !99
ok.487:
  br label %bb86
bb86:
  br label %bb98
bb87:
  %t488 = load i32, ptr %l200, !tbaa !23
  %t489 = ashr i32 %t488, 16
  %t491 = icmp eq i32 %t489, 1
  store i1 %t491, ptr %l202, !tbaa !21
  %t492 = load i32, ptr %l200, !tbaa !23
  %t493 = ashr i32 %t492, 16
  %t495 = icmp eq i32 %t493, 1
  br i1 %t495, label %bb88, label %bb89
bb88:
  call void @__olang_errpay_pop()
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t497 = load ptr, ptr %lp6
  %t498 = getelementptr %"compiler/bindgen:Translation", ptr %t497, i32 0, i32 3
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %t498, !tbaa !27
  %t499 = load ptr, ptr %lp6
  %t500 = load %"compiler/bindgen:Translation", ptr %t499
  store %"compiler/bindgen:Translation" %t500, ptr %l205
  %t502 = call %"compiler/bindgen:Translation" @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3aTranslation(ptr %v6, ptr %l205)
  store %"compiler/bindgen:Translation" %t502, ptr %l207
  br label %bb91
bb91:
  %t503 = load %"compiler/bindgen:Translation", ptr %l207
  store %"compiler/bindgen:Translation" %t503, ptr %l205
  %t504 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t506 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t504)
  store i32 %t506, ptr %l209
  %t507 = icmp ne i32 %t506, 0
  br i1 %t507, label %bb93, label %ok.508, !prof !99
ok.508:
  br label %bb92
bb92:
  br label %bb97
bb93:
  %t509 = load i32, ptr %l209, !tbaa !23
  %t510 = ashr i32 %t509, 16
  %t512 = icmp eq i32 %t510, 1
  store i1 %t512, ptr %l211, !tbaa !21
  %t513 = load i32, ptr %l209, !tbaa !23
  %t514 = ashr i32 %t513, 16
  %t516 = icmp eq i32 %t514, 1
  br i1 %t516, label %bb94, label %bb95
bb94:
  call void @__olang_errpay_pop()
  br label %bb95
bb95:
  br label %bb96
bb96:
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s0)
  %t518 = load %"compiler/bindgen:Translation", ptr %l205
  store %"compiler/bindgen:Translation" %t518, ptr %rv
  br label %ret
bb98:
  %t519 = load ptr, ptr %lp10
  %t520 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t521 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t522 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t527 = call { i32, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edump(ptr %v6, ptr %v2, ptr %v3, ptr %s0, ptr %s0, ptr %t519, { i64, ptr } %t520, { i64, ptr } %t521, { i64, ptr } %t522)
  %t528 = extractvalue { i32, ptr } %t527, 1
  %t529 = extractvalue { i32, ptr } %t527, 0
  store i32 %t529, ptr %l220
  %t530 = icmp ne i32 %t529, 0
  br i1 %t530, label %bb100, label %ok.531, !prof !99
ok.531:
  store ptr %t528, ptr %l219
  br label %bb99
bb99:
  %t532 = load ptr, ptr %l219, !tbaa !29
  store ptr %t532, ptr %l214, !tbaa !29
  br label %bb109
bb100:
  %t533 = load i32, ptr %l220, !tbaa !23
  %t534 = ashr i32 %t533, 16
  %t536 = icmp eq i32 %t534, 1
  store i1 %t536, ptr %l222, !tbaa !21
  br label %bb101
bb101:
  %t537 = load ptr, ptr %lp10
  %t538 = getelementptr %"compiler/bindgen:gen", ptr %t537, i32 0, i32 25
  %t539 = load { i64, ptr }, ptr %t538, !tbaa !27
  %t541 = load ptr, ptr %lp6
  %t542 = getelementptr %"compiler/bindgen:Translation", ptr %t541, i32 0, i32 3
  store { i64, ptr } %t539, ptr %t542, !tbaa !27
  %t543 = load ptr, ptr %lp6
  %t544 = load %"compiler/bindgen:Translation", ptr %t543
  store %"compiler/bindgen:Translation" %t544, ptr %l224
  %t546 = call %"compiler/bindgen:Translation" @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3aTranslation(ptr %v6, ptr %l224)
  store %"compiler/bindgen:Translation" %t546, ptr %l226
  br label %bb102
bb102:
  %t547 = load %"compiler/bindgen:Translation", ptr %l226
  store %"compiler/bindgen:Translation" %t547, ptr %l224
  %t548 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t550 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t548)
  store i32 %t550, ptr %l228
  %t551 = icmp ne i32 %t550, 0
  br i1 %t551, label %bb104, label %ok.552, !prof !99
ok.552:
  br label %bb103
bb103:
  br label %bb108
bb104:
  %t553 = load i32, ptr %l228, !tbaa !23
  %t554 = ashr i32 %t553, 16
  %t556 = icmp eq i32 %t554, 1
  store i1 %t556, ptr %l230, !tbaa !21
  %t557 = load i32, ptr %l228, !tbaa !23
  %t558 = ashr i32 %t557, 16
  %t560 = icmp eq i32 %t558, 1
  br i1 %t560, label %bb105, label %bb106
bb105:
  call void @__olang_errpay_pop()
  br label %bb106
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s0)
  %t562 = load %"compiler/bindgen:Translation", ptr %l224
  store %"compiler/bindgen:Translation" %t562, ptr %rv
  br label %ret
bb109:
  %t563 = load ptr, ptr %l214, !tbaa !29
  store ptr %t563, ptr %l27, !tbaa !29
  %t564 = load ptr, ptr %lp10
  %t565 = load ptr, ptr %l27, !tbaa !29
  %t566 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eread(ptr %v6, ptr %s0, ptr %s0, ptr %t564, ptr %t565, { i64, ptr } %t566)
  br label %bb110
bb110:
  %t570 = load ptr, ptr %lp10
  %t571 = getelementptr %"compiler/bindgen:gen", ptr %t570, i32 0, i32 26
  store i64 0, ptr %t571, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s41
  %t572 = load ptr, ptr %l27, !tbaa !29
  %t574 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s0, ptr %s41, ptr %t572)
  store { i64, ptr } %t574, ptr %l237
  br label %bb111
bb111:
  %t575 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t576 = extractvalue { i64, ptr } %t575, 0
  %t577 = extractvalue { i64, ptr } %t575, 1
  %t578 = mul i64 %t576, 8
  %t579 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t578)
  call void @llvm.memcpy.p0.p0.i64(ptr %t579, ptr %t577, i64 %t578, i1 false)
  %t580 = insertvalue { i64, ptr } undef, i64 %t576, 0
  %t581 = insertvalue { i64, ptr } %t580, ptr %t579, 1
  store { i64, ptr } %t581, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t583 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t585 = extractvalue { i64, ptr } %t583, 0
  store i64 %t585, ptr %l30, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s42
  %t587 = load i64, ptr %l29, !tbaa !24
  %t588 = load i64, ptr %l30, !tbaa !24
  %t591 = icmp slt i64 %t587, %t588
  %t593 = xor i1 %t591, true
  br i1 %t593, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s42)
  br label %bb167
bb114:
  br label %bb115
bb115:
  %t595 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t595, ptr %l245, !tbaa !27
  %t596 = load i64, ptr %l29, !tbaa !24
  %t598 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t599 = load ptr, ptr %t598, !tbaa !27
  %t600 = getelementptr ptr, ptr %t599, i64 %t596
  %t601 = load ptr, ptr %t600, !tbaa !39
  store ptr %t601, ptr %l31, !tbaa !29
  %t603 = load ptr, ptr %l31, !tbaa !29
  %t605 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s41, ptr %s42, ptr %s42, ptr %t603, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store { i64, ptr } %t605, ptr %l249
  br label %bb116
bb116:
  %t606 = load { i64, ptr }, ptr %l249, !tbaa !27
  store { i64, ptr } %t606, ptr %l32, !tbaa !27
  %t607 = load ptr, ptr %l31, !tbaa !29
  %t609 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s41, ptr %s42, ptr %s42, ptr %t607, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store { i64, ptr } %t609, ptr %l251
  br label %bb117
bb117:
  %t610 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t611 = extractvalue { i64, ptr } %t610, 0
  %t612 = extractvalue { i64, ptr } %t610, 1
  %t613 = mul i64 %t611, 1
  %t614 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t613)
  call void @llvm.memcpy.p0.p0.i64(ptr %t614, ptr %t612, i64 %t613, i1 false)
  %t615 = insertvalue { i64, ptr } undef, i64 %t611, 0
  %t616 = insertvalue { i64, ptr } %t615, ptr %t614, 1
  %t618 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s42, ptr %s42, { i64, ptr } %t616, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t618, ptr %l253
  br label %bb118
bb118:
  %t619 = load i1, ptr %l253, !tbaa !21
  %t620 = xor i1 %t619, true
  br i1 %t620, label %bb119, label %bb120
bb119:
  store i1 true, ptr %l255, !tbaa !21
  br label %bb122
bb120:
  %t622 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t624 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s42, ptr %s42, { i64, ptr } %t622, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t624, ptr %l257
  br label %bb121
bb121:
  %t625 = load i1, ptr %l257, !tbaa !21
  %t626 = xor i1 %t625, true
  store i1 %t626, ptr %l255, !tbaa !21
  br label %bb122
bb122:
  %t628 = load i1, ptr %l255, !tbaa !21
  br i1 %t628, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s42)
  br label %bb166
bb124:
  br label %bb125
bb125:
  %t629 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t631 = extractvalue { i64, ptr } %t629, 0
  store i64 %t631, ptr %l261, !tbaa !24
  %t632 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t633 = extractvalue { i64, ptr } %t632, 0
  store i64 %t633, ptr %l262, !tbaa !24
  %t634 = icmp sge i64 9, 0
  br i1 %t634, label %bb126, label %bb127
bb126:
  %t636 = load i64, ptr %l261, !tbaa !24
  %t637 = icmp sle i64 9, %t636
  br i1 %t637, label %bb128, label %bb129
bb127:
  call void @__olang_check_failed(ptr @olang_loc_489a2a8be26135c1_2fe8a601822a7f65)
  unreachable
bb128:
  %t639 = load i64, ptr %l261, !tbaa !24
  %t640 = load i64, ptr %l262, !tbaa !24
  %t641 = icmp sle i64 %t639, %t640
  br i1 %t641, label %bb130, label %bb131
bb129:
  call void @__olang_check_failed(ptr @olang_loc_489a2a8be26135c1_2fe8a601822a7f65)
  unreachable
bb130:
  %t643 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t644 = load ptr, ptr %t643, !tbaa !27
  %t645 = load i64, ptr %l261, !tbaa !24
  %t646 = getelementptr i8, ptr %t644, i64 9
  %t647 = sub i64 %t645, 9
  %t648 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t649 = insertvalue { i64, ptr } %t648, ptr %t646, 1
  store { i64, ptr } %t649, ptr %l266, !tbaa !27
  %t650 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s42, i64 10)
  %t651 = extractvalue { i32, i64 } %t650, 1
  %t652 = extractvalue { i32, i64 } %t650, 0
  store i32 %t652, ptr %l268
  %t653 = icmp ne i32 %t652, 0
  br i1 %t653, label %bb133, label %ok.654, !prof !99
ok.654:
  store i64 %t651, ptr %l267
  br label %bb132
bb131:
  call void @__olang_check_failed(ptr @olang_loc_489a2a8be26135c1_2fe8a601822a7f65)
  unreachable
bb132:
  %t655 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t656 = load i64, ptr %l267, !tbaa !24
  %t657 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s42, { i64, ptr } %t655, i64 %t656)
  %t658 = extractvalue { i32, i64 } %t657, 1
  %t659 = extractvalue { i32, i64 } %t657, 0
  store i32 %t659, ptr %l270
  %t660 = icmp ne i32 %t659, 0
  br i1 %t660, label %bb136, label %ok.661, !prof !99
ok.661:
  store i64 %t658, ptr %l269
  br label %bb135
bb133:
  br label %bb134
bb134:
  store i64 -1, ptr %l259, !tbaa !24
  br label %bb137
bb135:
  %t662 = load i64, ptr %l269, !tbaa !24
  store i64 %t662, ptr %l259, !tbaa !24
  br label %bb137
bb136:
  br label %bb134
bb137:
  %t663 = load i64, ptr %l259, !tbaa !24
  store i64 %t663, ptr %l33, !tbaa !24
  %t664 = load i64, ptr %l33, !tbaa !24
  %t666 = icmp slt i64 %t664, 0
  br i1 %t666, label %bb138, label %bb139
bb138:
  store i1 true, ptr %l273, !tbaa !21
  br label %bb141
bb139:
  %t668 = load i64, ptr %l33, !tbaa !24
  store i64 %t668, ptr %l274, !tbaa !24
  %t670 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l21)
  store i64 %t670, ptr %l276
  br label %bb140
bb140:
  %t671 = load i64, ptr %l274, !tbaa !24
  %t672 = load i64, ptr %l276, !tbaa !24
  %t673 = icmp sge i64 %t671, %t672
  store i1 %t673, ptr %l273, !tbaa !21
  br label %bb141
bb141:
  %t675 = load i1, ptr %l273, !tbaa !21
  br i1 %t675, label %bb142, label %bb143
bb142:
  call void @__olang_scope_close(ptr %s42)
  br label %bb166
bb143:
  br label %bb144
bb144:
  store %olang.scope zeroinitializer, ptr %s45
  %t676 = load ptr, ptr %l31, !tbaa !29
  %t678 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s41, ptr %s45, ptr %t676)
  store { i64, ptr } %t678, ptr %l279
  br label %bb145
bb145:
  %t679 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 0
  %t681 = extractvalue { i64, ptr } %t679, 1
  %t682 = mul i64 %t680, 8
  %t683 = call ptr @__olang_scope_alloc(ptr %s45, i64 %t682)
  call void @llvm.memcpy.p0.p0.i64(ptr %t683, ptr %t681, i64 %t682, i1 false)
  %t684 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t683, 1
  store { i64, ptr } %t685, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t687 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t689 = extractvalue { i64, ptr } %t687, 0
  store i64 %t689, ptr %l36, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s46
  %t691 = load i64, ptr %l35, !tbaa !24
  %t692 = load i64, ptr %l36, !tbaa !24
  %t695 = icmp slt i64 %t691, %t692
  %t697 = xor i1 %t695, true
  br i1 %t697, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s46)
  br label %bb165
bb148:
  br label %bb149
bb149:
  %t699 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t699, ptr %l287, !tbaa !27
  %t700 = load i64, ptr %l35, !tbaa !24
  %t702 = getelementptr { i64, ptr }, ptr %l287, i32 0, i32 1
  %t703 = load ptr, ptr %t702, !tbaa !27
  %t704 = getelementptr ptr, ptr %t703, i64 %t700
  %t705 = load ptr, ptr %t704, !tbaa !39
  %t709 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s45, ptr %s46, ptr %t705)
  store { i64, ptr } %t709, ptr %l291
  br label %bb150
bb150:
  %t710 = load { i64, ptr }, ptr %l291, !tbaa !27
  store { i64, ptr } %t710, ptr %l38, !tbaa !27
  %t711 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t713 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s46, ptr %s46, { i64, ptr } %t711, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t713, ptr %l293
  br label %bb151
bb151:
  %t714 = load i1, ptr %l293, !tbaa !21
  br i1 %t714, label %bb152, label %bb153
bb152:
  call void @__olang_scope_close(ptr %s46)
  br label %bb164
bb153:
  br label %bb154
bb154:
  %t715 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t715, ptr %l295, !tbaa !27
  %t716 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s46, i64 10)
  %t717 = extractvalue { i32, i64 } %t716, 1
  %t718 = extractvalue { i32, i64 } %t716, 0
  store i32 %t718, ptr %l297
  %t719 = icmp ne i32 %t718, 0
  br i1 %t719, label %bb156, label %ok.720, !prof !99
ok.720:
  store i64 %t717, ptr %l296
  br label %bb155
bb155:
  %t721 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t722 = load i64, ptr %l296, !tbaa !24
  %t723 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s46, { i64, ptr } %t721, i64 %t722)
  %t724 = extractvalue { i32, i64 } %t723, 1
  %t725 = extractvalue { i32, i64 } %t723, 0
  store i32 %t725, ptr %l299
  %t726 = icmp ne i32 %t725, 0
  br i1 %t726, label %bb159, label %ok.727, !prof !99
ok.727:
  store i64 %t724, ptr %l298
  br label %bb158
bb156:
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s46)
  br label %bb164
bb158:
  %t728 = load i64, ptr %l298, !tbaa !24
  store i64 %t728, ptr %l294, !tbaa !24
  br label %bb160
bb159:
  br label %bb157
bb160:
  %t729 = load i64, ptr %l294, !tbaa !24
  store i64 %t729, ptr %l39, !tbaa !24
  %t730 = load ptr, ptr %lp10
  store ptr %t730, ptr %l300, !tbaa !29
  %t731 = load ptr, ptr %lp10
  %t732 = getelementptr %"compiler/bindgen:gen", ptr %t731, i32 0, i32 12
  store ptr %t732, ptr %l301, !tbaa !29
  %t733 = load i64, ptr %l33, !tbaa !24
  %t736 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l21, i64 %t733)
  store i64 %t736, ptr %l304
  br label %bb161
bb161:
  %t737 = load ptr, ptr %l301, !tbaa !29
  %t738 = load i64, ptr %l304, !tbaa !24
  %t739 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v6, ptr %v6, ptr %t737, i64 %t738)
  store %"compiler/bindgen:cMacro" %t739, ptr %l305
  br label %bb162
bb162:
  %t740 = getelementptr %"compiler/bindgen:cMacro", ptr %l305, i32 0, i32 0
  %t741 = load { i64, ptr }, ptr %t740, !tbaa !27
  %t742 = load i64, ptr %l39, !tbaa !24
  %t743 = load ptr, ptr %l300, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %v6, ptr %v6, ptr %t743, { i64, ptr } %t741, i64 %t742)
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s46)
  br label %bb164
bb164:
  %t746 = load i64, ptr %l35, !tbaa !24
  %t748 = add i64 %t746, 1
  store i64 %t748, ptr %l35, !tbaa !24
  br label %bb146
bb165:
  call void @__olang_scope_close(ptr %s45)
  call void @__olang_scope_close(ptr %s42)
  br label %bb166
bb166:
  %t750 = load i64, ptr %l29, !tbaa !24
  %t752 = add i64 %t750, 1
  store i64 %t752, ptr %l29, !tbaa !24
  br label %bb112
bb167:
  call void @__olang_scope_close(ptr %s41)
  %t754 = load ptr, ptr %lp10
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eotherConsts(ptr %v6, ptr %t754)
  br label %bb168
bb168:
  %t756 = load ptr, ptr %lp10
  %t757 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t758 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t759 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t760 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t766 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2esizes(ptr %v6, ptr %v2, ptr %v3, ptr %s0, ptr %v0, ptr %t756, { i64, ptr } %t757, { i64, ptr } %t758, { i64, ptr } %t759, { i64, ptr } %t760)
  store i32 %t766, ptr %l318
  %t767 = icmp ne i32 %t766, 0
  br i1 %t767, label %bb170, label %ok.768, !prof !99
ok.768:
  br label %bb169
bb169:
  br label %bb179
bb170:
  %t769 = load i32, ptr %l318, !tbaa !23
  %t770 = ashr i32 %t769, 16
  %t772 = icmp eq i32 %t770, 1
  store i1 %t772, ptr %l320, !tbaa !21
  br label %bb171
bb171:
  %t773 = load ptr, ptr %lp10
  %t774 = getelementptr %"compiler/bindgen:gen", ptr %t773, i32 0, i32 25
  %t775 = load { i64, ptr }, ptr %t774, !tbaa !27
  %t777 = load ptr, ptr %lp6
  %t778 = getelementptr %"compiler/bindgen:Translation", ptr %t777, i32 0, i32 3
  store { i64, ptr } %t775, ptr %t778, !tbaa !27
  %t779 = load ptr, ptr %lp6
  %t780 = load %"compiler/bindgen:Translation", ptr %t779
  store %"compiler/bindgen:Translation" %t780, ptr %l322
  %t782 = call %"compiler/bindgen:Translation" @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3aTranslation(ptr %v6, ptr %l322)
  store %"compiler/bindgen:Translation" %t782, ptr %l324
  br label %bb172
bb172:
  %t783 = load %"compiler/bindgen:Translation", ptr %l324
  store %"compiler/bindgen:Translation" %t783, ptr %l322
  %t784 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t786 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t784)
  store i32 %t786, ptr %l326
  %t787 = icmp ne i32 %t786, 0
  br i1 %t787, label %bb174, label %ok.788, !prof !99
ok.788:
  br label %bb173
bb173:
  br label %bb178
bb174:
  %t789 = load i32, ptr %l326, !tbaa !23
  %t790 = ashr i32 %t789, 16
  %t792 = icmp eq i32 %t790, 1
  store i1 %t792, ptr %l328, !tbaa !21
  %t793 = load i32, ptr %l326, !tbaa !23
  %t794 = ashr i32 %t793, 16
  %t796 = icmp eq i32 %t794, 1
  br i1 %t796, label %bb175, label %bb176
bb175:
  call void @__olang_errpay_pop()
  br label %bb176
bb176:
  br label %bb177
bb177:
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s0)
  %t798 = load %"compiler/bindgen:Translation", ptr %l322
  store %"compiler/bindgen:Translation" %t798, ptr %rv
  br label %ret
bb179:
  %t799 = load ptr, ptr %lp10
  %t800 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t801 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t802 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t804 = extractvalue { i64, ptr } %t800, 1
  %t805 = extractvalue { i64, ptr } %t800, 0
  %t806 = add i64 %t802, %t805
  %t807 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t808 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t809 = add i64 %t806, %t808
  %t810 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t809)
  call void @olang_textcopy(ptr %t810, ptr %t801, i64 %t802)
  %t811 = getelementptr i8, ptr %t810, i64 %t802
  call void @olang_textcopy(ptr %t811, ptr %t804, i64 %t805)
  %t812 = getelementptr i8, ptr %t811, i64 %t805
  call void @olang_textcopy(ptr %t812, ptr %t807, i64 %t808)
  %t813 = insertvalue { i64, ptr } undef, i64 %t809, 0
  %t814 = insertvalue { i64, ptr } %t813, ptr %t810, 1
  %t816 = extractvalue { i64, ptr } %t814, 0
  %t817 = extractvalue { i64, ptr } %t814, 1
  %t818 = mul i64 %t816, 1
  %t819 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t818)
  call void @llvm.memcpy.p0.p0.i64(ptr %t819, ptr %t817, i64 %t818, i1 false)
  %t820 = insertvalue { i64, ptr } undef, i64 %t816, 0
  %t821 = insertvalue { i64, ptr } %t820, ptr %t819, 1
  %t824 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrite(ptr %v6, ptr %v6, ptr %v6, ptr %t799, { i64, ptr } %t821)
  store { i64, ptr } %t824, ptr %l335
  br label %bb180
bb180:
  %t825 = load { i64, ptr }, ptr %l335, !tbaa !27
  %t826 = extractvalue { i64, ptr } %t825, 0
  %t827 = extractvalue { i64, ptr } %t825, 1
  %t828 = mul i64 %t826, 1
  %t829 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t828)
  call void @llvm.memcpy.p0.p0.i64(ptr %t829, ptr %t827, i64 %t828, i1 false)
  %t830 = insertvalue { i64, ptr } undef, i64 %t826, 0
  %t831 = insertvalue { i64, ptr } %t830, ptr %t829, 1
  %t833 = load ptr, ptr %lp6
  %t834 = getelementptr %"compiler/bindgen:Translation", ptr %t833, i32 0, i32 0
  store { i64, ptr } %t831, ptr %t834, !tbaa !27
  %t835 = load ptr, ptr %lp10
  %t836 = getelementptr %"compiler/bindgen:gen", ptr %t835, i32 0, i32 20
  %t838 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v6, ptr %t836)
  store i64 %t838, ptr %l338
  br label %bb181
bb181:
  %t839 = load i64, ptr %l338, !tbaa !24
  %t840 = icmp sgt i64 %t839, 0
  br i1 %t840, label %bb182, label %bb183
bb182:
  store i1 true, ptr %l340, !tbaa !21
  br label %bb185
bb183:
  %t842 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t844 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t842, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t844, ptr %l342
  br label %bb184
bb184:
  %t845 = load i1, ptr %l342, !tbaa !21
  %t846 = xor i1 %t845, true
  store i1 %t846, ptr %l340, !tbaa !21
  br label %bb185
bb185:
  %t848 = load i1, ptr %l340, !tbaa !21
  br i1 %t848, label %bb186, label %bb187
bb186:
  store %olang.scope zeroinitializer, ptr %s56
  %t849 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t849, ptr %l344, !tbaa !27
  %t850 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t850, ptr %l345, !tbaa !27
  %t851 = load ptr, ptr %lp10
  %t852 = getelementptr %"compiler/bindgen:gen", ptr %t851, i32 0, i32 20
  %t854 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v6, ptr %s56, ptr %t852)
  store { i64, ptr } %t854, ptr %l347
  br label %bb188
bb187:
  br label %bb189
bb188:
  %t855 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t856 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t857 = load { i64, ptr }, ptr %l344, !tbaa !27
  %t858 = extractvalue { i64, ptr } %t857, 1
  %t859 = extractvalue { i64, ptr } %t857, 0
  %t860 = add i64 %t856, %t859
  %t861 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t862 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t863 = add i64 %t860, %t862
  %t864 = load { i64, ptr }, ptr %l345, !tbaa !27
  %t865 = extractvalue { i64, ptr } %t864, 1
  %t866 = extractvalue { i64, ptr } %t864, 0
  %t867 = add i64 %t863, %t866
  %t868 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t869 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t870 = add i64 %t867, %t869
  %t871 = load { i64, ptr }, ptr %l347, !tbaa !27
  %t872 = extractvalue { i64, ptr } %t871, 1
  %t873 = extractvalue { i64, ptr } %t871, 0
  %t874 = add i64 %t870, %t873
  %t875 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t874)
  call void @olang_textcopy(ptr %t875, ptr %t855, i64 %t856)
  %t876 = getelementptr i8, ptr %t875, i64 %t856
  call void @olang_textcopy(ptr %t876, ptr %t858, i64 %t859)
  %t877 = getelementptr i8, ptr %t876, i64 %t859
  call void @olang_textcopy(ptr %t877, ptr %t861, i64 %t862)
  %t878 = getelementptr i8, ptr %t877, i64 %t862
  call void @olang_textcopy(ptr %t878, ptr %t865, i64 %t866)
  %t879 = getelementptr i8, ptr %t878, i64 %t866
  call void @olang_textcopy(ptr %t879, ptr %t868, i64 %t869)
  %t880 = getelementptr i8, ptr %t879, i64 %t869
  call void @olang_textcopy(ptr %t880, ptr %t872, i64 %t873)
  %t881 = insertvalue { i64, ptr } undef, i64 %t874, 0
  %t882 = insertvalue { i64, ptr } %t881, ptr %t875, 1
  %t884 = extractvalue { i64, ptr } %t882, 0
  %t885 = extractvalue { i64, ptr } %t882, 1
  %t886 = mul i64 %t884, 1
  %t887 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t886)
  call void @llvm.memcpy.p0.p0.i64(ptr %t887, ptr %t885, i64 %t886, i1 false)
  %t888 = insertvalue { i64, ptr } undef, i64 %t884, 0
  %t889 = insertvalue { i64, ptr } %t888, ptr %t887, 1
  %t891 = load ptr, ptr %lp6
  %t892 = getelementptr %"compiler/bindgen:Translation", ptr %t891, i32 0, i32 1
  store { i64, ptr } %t889, ptr %t892, !tbaa !27
  call void @__olang_scope_close(ptr %s56)
  br label %bb189
bb189:
  %t893 = load ptr, ptr %lp6
  %t894 = load %"compiler/bindgen:Translation", ptr %t893
  store %"compiler/bindgen:Translation" %t894, ptr %l350
  %t896 = call %"compiler/bindgen:Translation" @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3aTranslation(ptr %v6, ptr %l350)
  store %"compiler/bindgen:Translation" %t896, ptr %l352
  br label %bb190
bb190:
  %t897 = load %"compiler/bindgen:Translation", ptr %l352
  store %"compiler/bindgen:Translation" %t897, ptr %l350
  %t898 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t900 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t898)
  store i32 %t900, ptr %l354
  %t901 = icmp ne i32 %t900, 0
  br i1 %t901, label %bb192, label %ok.902, !prof !99
ok.902:
  br label %bb191
bb191:
  br label %bb196
bb192:
  %t903 = load i32, ptr %l354, !tbaa !23
  %t904 = ashr i32 %t903, 16
  %t906 = icmp eq i32 %t904, 1
  store i1 %t906, ptr %l356, !tbaa !21
  %t907 = load i32, ptr %l354, !tbaa !23
  %t908 = ashr i32 %t907, 16
  %t910 = icmp eq i32 %t908, 1
  br i1 %t910, label %bb193, label %bb194
bb193:
  call void @__olang_errpay_pop()
  br label %bb194
bb194:
  br label %bb195
bb195:
  br label %bb196
bb196:
  call void @__olang_scope_close(ptr %s0)
  %t912 = load %"compiler/bindgen:Translation", ptr %l350
  store %"compiler/bindgen:Translation" %t912, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:Translation", ptr %rv
  ret %"compiler/bindgen:Translation" %rr
}

define dso_local i64 @compiler_2fbindgen_2ebodyKind(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l13 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca i1
  %l46 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i64, ptr %l6, !tbaa !24
  %t5 = icmp sgt i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t7, i64 0)
  store { i64, ptr } %t9, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t10 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t16, i64 0)
  store { i64, ptr } %t19, ptr %l16
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb9
bb8:
  %t20 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t20, ptr %l17, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 0
  %t24 = load i8, ptr %t23, !tbaa !32
  %t26 = icmp eq i8 %t24, 34
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 2, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb13
bb13:
  %t32 = load i64, ptr %l2, !tbaa !24
  store i64 %t32, ptr %l22, !tbaa !24
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l24
  br label %bb14
bb14:
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = icmp slt i64 %t36, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb15, label %bb16
bb15:
  br label %bb43
bb16:
  br label %bb17
bb17:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t43 = load i64, ptr %l2, !tbaa !24
  %t46 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t42, i64 %t43)
  store { i64, ptr } %t46, ptr %l29
  br label %bb18
bb18:
  %t47 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t47, ptr %l3, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = icmp sgt i64 %t50, 0
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t54, ptr %l34, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 0
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t58)
  store i1 %t60, ptr %l36
  br label %bb21
bb20:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb25
bb21:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb23:
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t62, ptr %l38, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 0
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp eq i8 %t66, 46
  store i1 %t68, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t70 = load i1, ptr %l37, !tbaa !21
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb25
bb25:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t74 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %s4, { i64, ptr } %t72)
  store { i64, ptr } %t74, ptr %l42
  br label %bb28
bb27:
  br label %bb41
bb28:
  %t75 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t75, ptr %l4, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s4, ptr %s4, { i64, ptr } %t76, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t78, ptr %l44
  br label %bb29
bb29:
  %t79 = load i1, ptr %l44, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb30, label %bb31
bb30:
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t85 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s4, ptr %s4, { i64, ptr } %t82, { i64, ptr } %t84)
  store i1 %t85, ptr %l49
  br label %bb32
bb31:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb37
bb32:
  %t86 = load i1, ptr %l49, !tbaa !21
  br i1 %t86, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb36
bb34:
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t90 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s4, ptr %s4, { i64, ptr } %t87, { i64, ptr } %t89)
  store i1 %t90, ptr %l53
  br label %bb35
bb35:
  %t91 = load i1, ptr %l53, !tbaa !21
  store i1 %t91, ptr %l50, !tbaa !21
  br label %bb36
bb36:
  %t92 = load i1, ptr %l50, !tbaa !21
  store i1 %t92, ptr %l46, !tbaa !21
  br label %bb37
bb37:
  %t93 = load i1, ptr %l46, !tbaa !21
  br i1 %t93, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i64 1, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l2, !tbaa !24
  br label %bb13
bb43:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fbindgen_2ecLex(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i64
  %l6 = alloca i8
  %l7 = alloca i8
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l39 = alloca i1
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l65 = alloca i64
  %l71 = alloca i1
  %l72 = alloca i1
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca { i64, ptr }
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l101 = alloca i1
  %l102 = alloca { i64, ptr }
  %l106 = alloca i1
  %l107 = alloca { i64, ptr }
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l121 = alloca i1
  %l122 = alloca { i64, ptr }
  %l131 = alloca i1
  %l132 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l150 = alloca i64
  %l156 = alloca i1
  %l157 = alloca i1
  %l160 = alloca i1
  %l166 = alloca i1
  %l167 = alloca { i64, ptr }
  %l171 = alloca i1
  %l177 = alloca { i64, ptr }
  %l182 = alloca i1
  %l185 = alloca i1
  %l186 = alloca { i64, ptr }
  %l191 = alloca i1
  %l192 = alloca { i64, ptr }
  %l197 = alloca i1
  %l198 = alloca { i64, ptr }
  %l203 = alloca i1
  %l204 = alloca { i64, ptr }
  %l212 = alloca i1
  %l213 = alloca i1
  %l215 = alloca i1
  %l216 = alloca i1
  %l219 = alloca i1
  %l225 = alloca [15 x { i64, ptr }]
  %l243 = alloca i1
  %l244 = alloca { i64, ptr }
  %l245 = alloca i64
  %l249 = alloca i64
  %l250 = alloca i64
  %l256 = alloca i1
  %l263 = alloca ptr
  %l264 = alloca { i64, ptr }
  %l265 = alloca i64
  %l266 = alloca i64
  %l267 = alloca i64
  %s7 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t11 = icmp slt i64 %t5, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb176
bb4:
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l19, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l3, !tbaa !22
  %t23 = load i8, ptr %l3, !tbaa !22
  %t25 = icmp eq i8 %t23, 32
  br i1 %t25, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb8
bb7:
  %t27 = load i8, ptr %l3, !tbaa !22
  %t29 = icmp eq i8 %t27, 9
  store i1 %t29, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l24, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb11
bb10:
  %t32 = load i8, ptr %l3, !tbaa !22
  %t34 = icmp eq i8 %t32, 10
  store i1 %t34, ptr %l27, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l27, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  %t37 = load i8, ptr %l3, !tbaa !22
  %t39 = icmp eq i8 %t37, 13
  store i1 %t39, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t41 = load i1, ptr %l30, !tbaa !21
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb175
bb16:
  br label %bb17
bb17:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l4, !tbaa !24
  %t50 = load i8, ptr %l3, !tbaa !22
  %t52 = icmp eq i8 %t50, 34
  br i1 %t52, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb20
bb19:
  %t54 = load i8, ptr %l3, !tbaa !22
  %t56 = icmp eq i8 %t54, 39
  store i1 %t56, ptr %l39, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l39, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  %t59 = load i8, ptr %l3, !tbaa !22
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t59)
  store i1 %t61, ptr %l71
  br label %bb38
bb23:
  %t62 = load i64, ptr %l4, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  br i1 %t68, label %bb24, label %bb25
bb24:
  %t70 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t70, ptr %l47, !tbaa !27
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i8, ptr %t74, i64 %t71
  %t76 = load i8, ptr %t75, !tbaa !32
  %t77 = load i8, ptr %l3, !tbaa !22
  %t80 = icmp ne i8 %t76, %t77
  store i1 %t80, ptr %l46, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb26
bb26:
  %t82 = load i1, ptr %l46, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb27, label %bb28
bb27:
  br label %bb34
bb28:
  br label %bb29
bb29:
  %t85 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t85, ptr %l53, !tbaa !27
  %t86 = load i64, ptr %l4, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 %t86
  %t91 = load i8, ptr %t90, !tbaa !32
  %t93 = icmp eq i8 %t91, 92
  br i1 %t93, label %bb30, label %bb31
bb30:
  %t95 = load i64, ptr %l4, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l4, !tbaa !24
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb33
bb33:
  br label %bb23
bb34:
  %t103 = load i64, ptr %l4, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t109 = icmp slt i64 %t103, %t106
  br i1 %t109, label %bb35, label %bb36
bb35:
  %t111 = load i64, ptr %l4, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l65, !tbaa !24
  br label %bb37
bb36:
  %t115 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l65, !tbaa !24
  br label %bb37
bb37:
  %t119 = load i64, ptr %l65, !tbaa !24
  store i64 %t119, ptr %l4, !tbaa !24
  br label %bb167
bb38:
  %t120 = load i1, ptr %l71, !tbaa !21
  br i1 %t120, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb41
bb40:
  %t121 = load i8, ptr %l3, !tbaa !22
  %t123 = icmp eq i8 %t121, 95
  store i1 %t123, ptr %l72, !tbaa !21
  br label %bb41
bb41:
  %t125 = load i1, ptr %l72, !tbaa !21
  br i1 %t125, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  br label %bb44
bb43:
  %t126 = load i8, ptr %l3, !tbaa !22
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t126)
  store i1 %t128, ptr %l156
  br label %bb95
bb44:
  %t129 = load i64, ptr %l4, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t135 = icmp slt i64 %t129, %t132
  br i1 %t135, label %bb45, label %bb46
bb45:
  %t137 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t137, ptr %l80, !tbaa !27
  %t138 = load i64, ptr %l4, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr i8, ptr %t141, i64 %t138
  %t143 = load i8, ptr %t142, !tbaa !32
  %t145 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t143)
  store i1 %t145, ptr %l83
  br label %bb47
bb46:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb55
bb47:
  %t146 = load i1, ptr %l83, !tbaa !21
  br i1 %t146, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb51
bb49:
  %t147 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t147, ptr %l85, !tbaa !27
  %t148 = load i64, ptr %l4, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i8, ptr %t151, i64 %t148
  %t153 = load i8, ptr %t152, !tbaa !32
  %t155 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t153)
  store i1 %t155, ptr %l88
  br label %bb50
bb50:
  %t156 = load i1, ptr %l88, !tbaa !21
  store i1 %t156, ptr %l84, !tbaa !21
  br label %bb51
bb51:
  %t157 = load i1, ptr %l84, !tbaa !21
  br i1 %t157, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb54
bb53:
  %t158 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t158, ptr %l90, !tbaa !27
  %t159 = load i64, ptr %l4, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i8, ptr %t162, i64 %t159
  %t164 = load i8, ptr %t163, !tbaa !32
  %t166 = icmp eq i8 %t164, 95
  store i1 %t166, ptr %l89, !tbaa !21
  br label %bb54
bb54:
  %t168 = load i1, ptr %l89, !tbaa !21
  store i1 %t168, ptr %l79, !tbaa !21
  br label %bb55
bb55:
  %t169 = load i1, ptr %l79, !tbaa !21
  %t170 = xor i1 %t169, true
  br i1 %t170, label %bb56, label %bb57
bb56:
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t172 = load i64, ptr %l4, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l4, !tbaa !24
  br label %bb59
bb59:
  br label %bb44
bb60:
  %t176 = load i64, ptr %l4, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t182 = icmp slt i64 %t176, %t179
  br i1 %t182, label %bb61, label %bb62
bb61:
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l102, !tbaa !27
  %t185 = load i64, ptr %l4, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i8, ptr %t188, i64 %t185
  %t190 = load i8, ptr %t189, !tbaa !32
  %t192 = icmp eq i8 %t190, 34
  br i1 %t192, label %bb63, label %bb64
bb62:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb66
bb63:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb65
bb64:
  %t194 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t194, ptr %l107, !tbaa !27
  %t195 = load i64, ptr %l4, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr i8, ptr %t198, i64 %t195
  %t200 = load i8, ptr %t199, !tbaa !32
  %t202 = icmp eq i8 %t200, 39
  store i1 %t202, ptr %l106, !tbaa !21
  br label %bb65
bb65:
  %t204 = load i1, ptr %l106, !tbaa !21
  store i1 %t204, ptr %l101, !tbaa !21
  br label %bb66
bb66:
  %t205 = load i1, ptr %l101, !tbaa !21
  br i1 %t205, label %bb67, label %bb68
bb67:
  %t206 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t206, ptr %l112, !tbaa !27
  %t207 = load i64, ptr %l2, !tbaa !24
  store i64 %t207, ptr %l113, !tbaa !24
  %t208 = load i64, ptr %l4, !tbaa !24
  store i64 %t208, ptr %l114, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l115, !tbaa !24
  %t211 = load i64, ptr %l113, !tbaa !24
  %t212 = icmp sge i64 %t211, 0
  br i1 %t212, label %bb69, label %bb70
bb68:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb76
bb69:
  %t214 = load i64, ptr %l113, !tbaa !24
  %t215 = load i64, ptr %l114, !tbaa !24
  %t216 = icmp sle i64 %t214, %t215
  br i1 %t216, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_4691cb288a833ba5_dfaa9dffbec0c2d9)
  unreachable
bb71:
  %t218 = load i64, ptr %l114, !tbaa !24
  %t219 = load i64, ptr %l115, !tbaa !24
  %t220 = icmp sle i64 %t218, %t219
  br i1 %t220, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_4691cb288a833ba5_dfaa9dffbec0c2d9)
  unreachable
bb73:
  %t222 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = load i64, ptr %l113, !tbaa !24
  %t225 = load i64, ptr %l114, !tbaa !24
  %t226 = getelementptr i8, ptr %t223, i64 %t224
  %t227 = sub i64 %t225, %t224
  %t228 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t226, 1
  %t233 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s7, ptr %v0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x { i64, ptr }] }>, ptr @.d38, i32 0, i32 1) }, { i64, ptr } %t229)
  store i1 %t233, ptr %l121
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_4691cb288a833ba5_dfaa9dffbec0c2d9)
  unreachable
bb75:
  %t234 = load i1, ptr %l121, !tbaa !21
  store i1 %t234, ptr %l111, !tbaa !21
  br label %bb76
bb76:
  %t235 = load i1, ptr %l111, !tbaa !21
  br i1 %t235, label %bb77, label %bb78
bb77:
  %t236 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t236, ptr %l122, !tbaa !27
  %t237 = load i64, ptr %l4, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr i8, ptr %t240, i64 %t237
  %t242 = load i8, ptr %t241, !tbaa !32
  store i8 %t242, ptr %l6, !tbaa !22
  %t244 = load i64, ptr %l4, !tbaa !24
  %t246 = add i64 %t244, 1
  store i64 %t246, ptr %l4, !tbaa !24
  br label %bb79
bb78:
  br label %bb94
bb79:
  %t248 = load i64, ptr %l4, !tbaa !24
  %t249 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t254 = icmp slt i64 %t248, %t251
  br i1 %t254, label %bb80, label %bb81
bb80:
  %t256 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t256, ptr %l132, !tbaa !27
  %t257 = load i64, ptr %l4, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr i8, ptr %t260, i64 %t257
  %t262 = load i8, ptr %t261, !tbaa !32
  %t263 = load i8, ptr %l6, !tbaa !22
  %t266 = icmp ne i8 %t262, %t263
  store i1 %t266, ptr %l131, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb82
bb82:
  %t268 = load i1, ptr %l131, !tbaa !21
  %t269 = xor i1 %t268, true
  br i1 %t269, label %bb83, label %bb84
bb83:
  br label %bb90
bb84:
  br label %bb85
bb85:
  %t271 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t271, ptr %l138, !tbaa !27
  %t272 = load i64, ptr %l4, !tbaa !24
  %t274 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr i8, ptr %t275, i64 %t272
  %t277 = load i8, ptr %t276, !tbaa !32
  %t279 = icmp eq i8 %t277, 92
  br i1 %t279, label %bb86, label %bb87
bb86:
  %t281 = load i64, ptr %l4, !tbaa !24
  %t283 = add i64 %t281, 1
  store i64 %t283, ptr %l4, !tbaa !24
  br label %bb88
bb87:
  br label %bb88
bb88:
  %t285 = load i64, ptr %l4, !tbaa !24
  %t287 = add i64 %t285, 1
  store i64 %t287, ptr %l4, !tbaa !24
  br label %bb89
bb89:
  br label %bb79
bb90:
  %t289 = load i64, ptr %l4, !tbaa !24
  %t290 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t295 = icmp slt i64 %t289, %t292
  br i1 %t295, label %bb91, label %bb92
bb91:
  %t297 = load i64, ptr %l4, !tbaa !24
  %t299 = add i64 %t297, 1
  store i64 %t299, ptr %l150, !tbaa !24
  br label %bb93
bb92:
  %t301 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t301, 0
  store i64 %t303, ptr %l150, !tbaa !24
  br label %bb93
bb93:
  %t305 = load i64, ptr %l150, !tbaa !24
  store i64 %t305, ptr %l4, !tbaa !24
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s7)
  br label %bb166
bb95:
  %t306 = load i1, ptr %l156, !tbaa !21
  br i1 %t306, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l157, !tbaa !21
  br label %bb105
bb97:
  %t307 = load i8, ptr %l3, !tbaa !22
  %t309 = icmp eq i8 %t307, 46
  br i1 %t309, label %bb98, label %bb99
bb98:
  %t311 = load i64, ptr %l2, !tbaa !24
  %t313 = add i64 %t311, 1
  %t314 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t319 = icmp slt i64 %t313, %t316
  store i1 %t319, ptr %l160, !tbaa !21
  br label %bb100
bb99:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb100
bb100:
  %t321 = load i1, ptr %l160, !tbaa !21
  br i1 %t321, label %bb101, label %bb102
bb101:
  %t322 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t322, ptr %l167, !tbaa !27
  %t323 = load i64, ptr %l2, !tbaa !24
  %t325 = add i64 %t323, 1
  %t327 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr i8, ptr %t328, i64 %t325
  %t330 = load i8, ptr %t329, !tbaa !32
  %t332 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t330)
  store i1 %t332, ptr %l171
  br label %bb103
bb102:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb104
bb103:
  %t333 = load i1, ptr %l171, !tbaa !21
  store i1 %t333, ptr %l166, !tbaa !21
  br label %bb104
bb104:
  %t334 = load i1, ptr %l166, !tbaa !21
  store i1 %t334, ptr %l157, !tbaa !21
  br label %bb105
bb105:
  %t335 = load i1, ptr %l157, !tbaa !21
  br i1 %t335, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s18
  %t336 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %t336, !tbaa !37
  %t337 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %t337, !tbaa !37
  %t338 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 2
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %t338, !tbaa !37
  %t339 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t339, !tbaa !37
  %t340 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %t340, !tbaa !37
  %t341 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 5
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %t341, !tbaa !37
  %t342 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 6
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %t342, !tbaa !37
  %t343 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 7
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %t343, !tbaa !37
  %t344 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 8
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %t344, !tbaa !37
  %t345 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 9
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %t345, !tbaa !37
  %t346 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 10
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %t346, !tbaa !37
  %t347 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 11
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %t347, !tbaa !37
  %t348 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 12
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %t348, !tbaa !37
  %t349 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 13
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %t349, !tbaa !37
  %t350 = getelementptr [15 x { i64, ptr }], ptr %l225, i64 0, i64 14
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %t350, !tbaa !37
  %t351 = call ptr @__olang_scope_alloc_a(ptr %s18, i64 240, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t351, ptr %l225, i64 240, i1 false)
  store ptr %t351, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t353 = load ptr, ptr %l8
  store i64 15, ptr %l10, !tbaa !24
  br label %bb146
bb108:
  %t356 = load i64, ptr %l4, !tbaa !24
  %t357 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t362 = icmp slt i64 %t356, %t359
  %t364 = xor i1 %t362, true
  br i1 %t364, label %bb109, label %bb110
bb109:
  br label %bb145
bb110:
  br label %bb111
bb111:
  %t366 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t366, ptr %l177, !tbaa !27
  %t367 = load i64, ptr %l4, !tbaa !24
  %t369 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = getelementptr i8, ptr %t370, i64 %t367
  %t372 = load i8, ptr %t371, !tbaa !32
  store i8 %t372, ptr %l7, !tbaa !22
  %t374 = load i8, ptr %l7, !tbaa !22
  %t376 = icmp eq i8 %t374, 43
  br i1 %t376, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb114
bb113:
  %t378 = load i8, ptr %l7, !tbaa !22
  %t380 = icmp eq i8 %t378, 45
  store i1 %t380, ptr %l182, !tbaa !21
  br label %bb114
bb114:
  %t382 = load i1, ptr %l182, !tbaa !21
  br i1 %t382, label %bb115, label %bb116
bb115:
  %t383 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t383, ptr %l186, !tbaa !27
  %t384 = load i64, ptr %l4, !tbaa !24
  %t386 = sub i64 %t384, 1
  %t388 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !27
  %t390 = getelementptr i8, ptr %t389, i64 %t386
  %t391 = load i8, ptr %t390, !tbaa !32
  %t393 = icmp eq i8 %t391, 101
  br i1 %t393, label %bb117, label %bb118
bb116:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb126
bb117:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb119
bb118:
  %t395 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t395, ptr %l192, !tbaa !27
  %t396 = load i64, ptr %l4, !tbaa !24
  %t398 = sub i64 %t396, 1
  %t400 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr i8, ptr %t401, i64 %t398
  %t403 = load i8, ptr %t402, !tbaa !32
  %t405 = icmp eq i8 %t403, 69
  store i1 %t405, ptr %l191, !tbaa !21
  br label %bb119
bb119:
  %t407 = load i1, ptr %l191, !tbaa !21
  br i1 %t407, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l197, !tbaa !21
  br label %bb122
bb121:
  %t408 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t408, ptr %l198, !tbaa !27
  %t409 = load i64, ptr %l4, !tbaa !24
  %t411 = sub i64 %t409, 1
  %t413 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = getelementptr i8, ptr %t414, i64 %t411
  %t416 = load i8, ptr %t415, !tbaa !32
  %t418 = icmp eq i8 %t416, 112
  store i1 %t418, ptr %l197, !tbaa !21
  br label %bb122
bb122:
  %t420 = load i1, ptr %l197, !tbaa !21
  br i1 %t420, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l203, !tbaa !21
  br label %bb125
bb124:
  %t421 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t421, ptr %l204, !tbaa !27
  %t422 = load i64, ptr %l4, !tbaa !24
  %t424 = sub i64 %t422, 1
  %t426 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !27
  %t428 = getelementptr i8, ptr %t427, i64 %t424
  %t429 = load i8, ptr %t428, !tbaa !32
  %t431 = icmp eq i8 %t429, 80
  store i1 %t431, ptr %l203, !tbaa !21
  br label %bb125
bb125:
  %t433 = load i1, ptr %l203, !tbaa !21
  store i1 %t433, ptr %l185, !tbaa !21
  br label %bb126
bb126:
  %t434 = load i1, ptr %l185, !tbaa !21
  br i1 %t434, label %bb127, label %bb128
bb127:
  %t435 = load i64, ptr %l4, !tbaa !24
  %t437 = add i64 %t435, 1
  store i64 %t437, ptr %l4, !tbaa !24
  br label %bb144
bb128:
  br label %bb129
bb129:
  %t439 = load i8, ptr %l7, !tbaa !22
  %t441 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t439)
  store i1 %t441, ptr %l212
  br label %bb130
bb130:
  %t442 = load i1, ptr %l212, !tbaa !21
  br i1 %t442, label %bb131, label %bb132
bb131:
  store i1 true, ptr %l213, !tbaa !21
  br label %bb134
bb132:
  %t443 = load i8, ptr %l7, !tbaa !22
  %t445 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t443)
  store i1 %t445, ptr %l215
  br label %bb133
bb133:
  %t446 = load i1, ptr %l215, !tbaa !21
  store i1 %t446, ptr %l213, !tbaa !21
  br label %bb134
bb134:
  %t447 = load i1, ptr %l213, !tbaa !21
  br i1 %t447, label %bb135, label %bb136
bb135:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb137
bb136:
  %t448 = load i8, ptr %l7, !tbaa !22
  %t450 = icmp eq i8 %t448, 95
  store i1 %t450, ptr %l216, !tbaa !21
  br label %bb137
bb137:
  %t452 = load i1, ptr %l216, !tbaa !21
  br i1 %t452, label %bb138, label %bb139
bb138:
  store i1 true, ptr %l219, !tbaa !21
  br label %bb140
bb139:
  %t453 = load i8, ptr %l7, !tbaa !22
  %t455 = icmp eq i8 %t453, 46
  store i1 %t455, ptr %l219, !tbaa !21
  br label %bb140
bb140:
  %t457 = load i1, ptr %l219, !tbaa !21
  %t458 = xor i1 %t457, true
  br i1 %t458, label %bb141, label %bb142
bb141:
  br label %bb145
bb142:
  br label %bb143
bb143:
  %t460 = load i64, ptr %l4, !tbaa !24
  %t462 = add i64 %t460, 1
  store i64 %t462, ptr %l4, !tbaa !24
  br label %bb144
bb144:
  br label %bb108
bb145:
  br label %bb165
bb146:
  %t464 = load i64, ptr %l9, !tbaa !24
  %t465 = load i64, ptr %l10, !tbaa !24
  %t468 = icmp slt i64 %t464, %t465
  %t470 = xor i1 %t468, true
  br i1 %t470, label %bb147, label %bb148
bb147:
  br label %bb164
bb148:
  br label %bb149
bb149:
  %t472 = load ptr, ptr %l8
  %t473 = load i64, ptr %l9, !tbaa !24
  %t476 = getelementptr [15 x { i64, ptr }], ptr %t472, i64 0, i64 %t473
  %t477 = load { i64, ptr }, ptr %t476, !tbaa !37
  store { i64, ptr } %t477, ptr %l11, !tbaa !27
  %t479 = load i64, ptr %l2, !tbaa !24
  %t480 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t480, 0
  %t485 = add i64 %t479, %t482
  %t486 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t491 = icmp sle i64 %t485, %t488
  br i1 %t491, label %bb150, label %bb151
bb150:
  %t493 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t493, ptr %l244, !tbaa !27
  %t494 = load i64, ptr %l2, !tbaa !24
  store i64 %t494, ptr %l245, !tbaa !24
  %t495 = load i64, ptr %l2, !tbaa !24
  %t496 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t498 = extractvalue { i64, ptr } %t496, 0
  %t501 = add i64 %t495, %t498
  store i64 %t501, ptr %l249, !tbaa !24
  %t502 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 0
  store i64 %t503, ptr %l250, !tbaa !24
  %t504 = load i64, ptr %l245, !tbaa !24
  %t505 = icmp sge i64 %t504, 0
  br i1 %t505, label %bb152, label %bb153
bb151:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb159
bb152:
  %t507 = load i64, ptr %l245, !tbaa !24
  %t508 = load i64, ptr %l249, !tbaa !24
  %t509 = icmp sle i64 %t507, %t508
  br i1 %t509, label %bb154, label %bb155
bb153:
  call void @__olang_check_failed(ptr @olang_loc_8de001e7a64c0b48_1a9d06562d43232c)
  unreachable
bb154:
  %t511 = load i64, ptr %l249, !tbaa !24
  %t512 = load i64, ptr %l250, !tbaa !24
  %t513 = icmp sle i64 %t511, %t512
  br i1 %t513, label %bb156, label %bb157
bb155:
  call void @__olang_check_failed(ptr @olang_loc_8de001e7a64c0b48_1a9d06562d43232c)
  unreachable
bb156:
  %t515 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !27
  %t517 = load i64, ptr %l245, !tbaa !24
  %t518 = load i64, ptr %l249, !tbaa !24
  %t519 = getelementptr i8, ptr %t516, i64 %t517
  %t520 = sub i64 %t518, %t517
  %t521 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t519, 1
  %t523 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t524 = load ptr, ptr @__olang_prog_scope
  %t527 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t524, { i64, ptr } %t522, { i64, ptr } %t523)
  store i1 %t527, ptr %l256
  br label %bb158
bb157:
  call void @__olang_check_failed(ptr @olang_loc_8de001e7a64c0b48_1a9d06562d43232c)
  unreachable
bb158:
  %t528 = load i1, ptr %l256, !tbaa !21
  store i1 %t528, ptr %l243, !tbaa !21
  br label %bb159
bb159:
  %t529 = load i1, ptr %l243, !tbaa !21
  br i1 %t529, label %bb160, label %bb161
bb160:
  %t530 = load i64, ptr %l2, !tbaa !24
  %t531 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t531, 0
  %t536 = add i64 %t530, %t533
  store i64 %t536, ptr %l4, !tbaa !24
  br label %bb164
bb161:
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t538 = load i64, ptr %l9, !tbaa !24
  %t540 = add i64 %t538, 1
  store i64 %t540, ptr %l9, !tbaa !24
  br label %bb146
bb164:
  call void @__olang_scope_close(ptr %s18)
  br label %bb165
bb165:
  br label %bb166
bb166:
  br label %bb167
bb167:
  %t542 = load ptr, ptr %l1, !tbaa !29
  store ptr %t542, ptr %l263, !tbaa !29
  %t543 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t543, ptr %l264, !tbaa !27
  %t544 = load i64, ptr %l2, !tbaa !24
  store i64 %t544, ptr %l265, !tbaa !24
  %t545 = load i64, ptr %l4, !tbaa !24
  store i64 %t545, ptr %l266, !tbaa !24
  %t546 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t546, 0
  store i64 %t547, ptr %l267, !tbaa !24
  %t548 = load i64, ptr %l265, !tbaa !24
  %t549 = icmp sge i64 %t548, 0
  br i1 %t549, label %bb168, label %bb169
bb168:
  %t551 = load i64, ptr %l265, !tbaa !24
  %t552 = load i64, ptr %l266, !tbaa !24
  %t553 = icmp sle i64 %t551, %t552
  br i1 %t553, label %bb170, label %bb171
bb169:
  call void @__olang_check_failed(ptr @olang_loc_9f24fc1b10bf4163_f387df93e06eee97)
  unreachable
bb170:
  %t555 = load i64, ptr %l266, !tbaa !24
  %t556 = load i64, ptr %l267, !tbaa !24
  %t557 = icmp sle i64 %t555, %t556
  br i1 %t557, label %bb172, label %bb173
bb171:
  call void @__olang_check_failed(ptr @olang_loc_9f24fc1b10bf4163_f387df93e06eee97)
  unreachable
bb172:
  %t559 = getelementptr { i64, ptr }, ptr %l264, i32 0, i32 1
  %t560 = load ptr, ptr %t559, !tbaa !27
  %t561 = load i64, ptr %l265, !tbaa !24
  %t562 = load i64, ptr %l266, !tbaa !24
  %t563 = getelementptr i8, ptr %t560, i64 %t561
  %t564 = sub i64 %t562, %t561
  %t565 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t566 = insertvalue { i64, ptr } %t565, ptr %t563, 1
  %t567 = load ptr, ptr %l263, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %t567, { i64, ptr } %t566)
  br label %bb174
bb173:
  call void @__olang_check_failed(ptr @olang_loc_9f24fc1b10bf4163_f387df93e06eee97)
  unreachable
bb174:
  %t569 = load i64, ptr %l4, !tbaa !24
  store i64 %t569, ptr %l2, !tbaa !24
  br label %bb175
bb175:
  br label %bb2
bb176:
  %t571 = load ptr, ptr %l1, !tbaa !29
  store ptr %t571, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3actp_2eat(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:ctp", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t8 = add i64 %t4, %a1
  store i64 %t8, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/bindgen:ctp", ptr %t11, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp slt i64 %t10, %t16
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/bindgen:ctp", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l14, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %t28, i64 %t25
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !37
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = extractvalue { i64, ptr } %t30, 0
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t32, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l12, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t38, ptr %l12, !tbaa !27
  br label %bb3
bb3:
  %t40 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l20, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = mul i64 %t42, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l21, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l20, !tbaa !24
  %t52 = mul i64 %t51, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %t50, i64 %t52, i1 false)
  %t53 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t53, ptr %l12, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBinary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/bindgen:cx"
  %l8 = alloca %"compiler/bindgen:cx"
  %lp9 = alloca ptr
  %lp10 = alloca ptr
  %l11 = alloca %"compiler/bindgen:cx"
  %l12 = alloca %"compiler/bindgen:cx"
  %l15 = alloca %"compiler/bindgen:cx"
  %l16 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca i64
  %l24 = alloca i1
  %l28 = alloca ptr
  %l31 = alloca %"compiler/bindgen:cx"
  %l36 = alloca %"compiler/bindgen:cx"
  %l37 = alloca i32
  %l40 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l46 = alloca %"compiler/bindgen:cx"
  %l47 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l53 = alloca %"compiler/bindgen:cx"
  %l58 = alloca %"compiler/bindgen:cx"
  %l61 = alloca i1
  %l66 = alloca %"compiler/bindgen:cx"
  %l69 = alloca %"compiler/bindgen:cx"
  %l76 = alloca %"compiler/bindgen:cx"
  %l79 = alloca %"compiler/bindgen:cx"
  %l82 = alloca %"compiler/bindgen:cx"
  %l85 = alloca %"compiler/bindgen:cx"
  %l90 = alloca %"compiler/bindgen:cx"
  %l93 = alloca i1
  %l97 = alloca i1
  %l102 = alloca %"compiler/bindgen:cx"
  %l111 = alloca %"compiler/bindgen:cx"
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/bindgen:cx" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecUnary(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2)
  %t6 = extractvalue { i32, %"compiler/bindgen:cx" } %t5, 1
  %t7 = extractvalue { i32, %"compiler/bindgen:cx" } %t5, 0
  store i32 %t7, ptr %l16
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store %"compiler/bindgen:cx" %t6, ptr %l15
  br label %bb1
bb1:
  %t10 = load %"compiler/bindgen:cx", ptr %l15
  store %"compiler/bindgen:cx" %t10, ptr %l12
  br label %bb3
bb2:
  %t11 = load i32, ptr %l16, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  %t21 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t19, 0
  store { i32, %"compiler/bindgen:cx" } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t22, ptr %lp3
  %t23 = load %"compiler/bindgen:cx", ptr %l12
  %t24 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t23, ptr %t24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s1, ptr %t25)
  store { i64, ptr } %t27, ptr %l19
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = call i64 @compiler_2fbindgen_2ecPrec(ptr %s1, { i64, ptr } %t29)
  store i64 %t31, ptr %l21
  br label %bb6
bb6:
  %t32 = load i64, ptr %l21, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp eq i64 %t33, 0
  br i1 %t35, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %a2
  store i1 %t41, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb58
bb11:
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l28, !tbaa !29
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = getelementptr %"compiler/bindgen:cparse", ptr %t45, i32 0, i32 2
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = add i64 %t47, 1
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = getelementptr %"compiler/bindgen:cparse", ptr %t51, i32 0, i32 2
  store i64 %t49, ptr %t52, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t55, 1
  %t61 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBinary(ptr %v0, ptr %v1, ptr %v2, ptr %t53, ptr %t54, i64 %t57)
  %t62 = extractvalue { i32, %"compiler/bindgen:cx" } %t61, 1
  %t63 = extractvalue { i32, %"compiler/bindgen:cx" } %t61, 0
  store i32 %t63, ptr %l37
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb14, label %ok.65, !prof !99
ok.65:
  store %"compiler/bindgen:cx" %t62, ptr %l36
  br label %bb13
bb13:
  %t66 = load %"compiler/bindgen:cx", ptr %l36
  store %"compiler/bindgen:cx" %t66, ptr %l31
  br label %bb15
bb14:
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = lshr i32 %t67, 16
  %t69 = and i32 %t67, 65535
  %t70 = icmp eq i32 %t68, 1
  %t71 = select i1 %t70, i32 1, i32 0
  %t72 = icmp eq i32 %t67, 0
  %t73 = shl i32 %t71, 16
  %t74 = or i32 %t73, %t69
  %t75 = select i1 %t72, i32 0, i32 %t74
  call void @__olang_scope_close(ptr %s1)
  %t77 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t75, 0
  store { i32, %"compiler/bindgen:cx" } %t77, ptr %rv
  br label %ret
bb15:
  %t78 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t78, ptr %lp6
  %t79 = load %"compiler/bindgen:cx", ptr %l31
  %t80 = load ptr, ptr %lp6
  store %"compiler/bindgen:cx" %t79, ptr %t80
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t81, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t83, ptr %l40
  br label %bb16
bb16:
  %t84 = load i1, ptr %l40, !tbaa !21
  br i1 %t84, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb20
bb18:
  %t85 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t85, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t87, ptr %l43
  br label %bb19
bb19:
  %t88 = load i1, ptr %l43, !tbaa !21
  store i1 %t88, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t89 = load i1, ptr %l41, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %lp3
  %t92 = load %"compiler/bindgen:cx", ptr %t91
  %t95 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v2, ptr %v2, ptr %t90, %"compiler/bindgen:cx" %t92)
  store %"compiler/bindgen:cx" %t95, ptr %l46
  br label %bb23
bb22:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = icmp eq i64 %t96, 6
  br i1 %t98, label %bb30, label %bb31
bb23:
  %t100 = getelementptr %"compiler/bindgen:cx", ptr %l46, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l47, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t104 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s3, { i64, ptr } %t102, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t104, ptr %l49
  br label %bb24
bb24:
  %t105 = load i1, ptr %l49, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l50, !tbaa !27
  br label %bb27
bb26:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l50, !tbaa !27
  br label %bb27
bb27:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %lp6
  %t108 = load %"compiler/bindgen:cx", ptr %t107
  %t111 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v2, ptr %v2, ptr %t106, %"compiler/bindgen:cx" %t108)
  store %"compiler/bindgen:cx" %t111, ptr %l53
  br label %bb28
bb28:
  %t112 = getelementptr %"compiler/bindgen:cx", ptr %l53, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t116 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = add i64 %t115, %t118
  %t120 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = add i64 %t119, %t122
  %t125 = extractvalue { i64, ptr } %t113, 1
  %t126 = extractvalue { i64, ptr } %t113, 0
  %t127 = add i64 %t123, %t126
  %t128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t114, i64 %t115)
  %t132 = getelementptr i8, ptr %t131, i64 %t115
  call void @olang_textcopy(ptr %t132, ptr %t117, i64 %t118)
  %t133 = getelementptr i8, ptr %t132, i64 %t118
  call void @olang_textcopy(ptr %t133, ptr %t121, i64 %t122)
  %t134 = getelementptr i8, ptr %t133, i64 %t122
  call void @olang_textcopy(ptr %t134, ptr %t125, i64 %t126)
  %t135 = getelementptr i8, ptr %t134, i64 %t126
  call void @olang_textcopy(ptr %t135, ptr %t128, i64 %t129)
  %t136 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t131, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = extractvalue { i64, ptr } %t137, 1
  %t141 = mul i64 %t139, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t141)
  call void @llvm.memcpy.p0.p0.i64(ptr %t142, ptr %t140, i64 %t141, i1 false)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  %t145 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t148 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t144, i64 %t145, i64 -1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t148, ptr %l58
  br label %bb29
bb29:
  %t149 = load %"compiler/bindgen:cx", ptr %l58
  %t150 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t149, ptr %t150
  call void @__olang_scope_close(ptr %s3)
  br label %bb56
bb30:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb32
bb31:
  %t151 = load i64, ptr %l5, !tbaa !24
  %t153 = icmp eq i64 %t151, 7
  store i1 %t153, ptr %l61, !tbaa !21
  br label %bb32
bb32:
  %t155 = load i1, ptr %l61, !tbaa !21
  br i1 %t155, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %lp3
  %t158 = load %"compiler/bindgen:cx", ptr %t157
  %t161 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %s6, ptr %t156, %"compiler/bindgen:cx" %t158)
  store %"compiler/bindgen:cx" %t161, ptr %l66
  br label %bb35
bb34:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %lp3
  %t164 = load %"compiler/bindgen:cx", ptr %t163
  %t167 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %v2, ptr %t162, %"compiler/bindgen:cx" %t164)
  store %"compiler/bindgen:cx" %t167, ptr %l79
  br label %bb38
bb35:
  %t168 = load %"compiler/bindgen:cx", ptr %l66
  store %"compiler/bindgen:cx" %t168, ptr %l7
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %lp6
  %t171 = load %"compiler/bindgen:cx", ptr %t170
  %t174 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %s6, ptr %t169, %"compiler/bindgen:cx" %t171)
  store %"compiler/bindgen:cx" %t174, ptr %l69
  br label %bb36
bb36:
  %t175 = load %"compiler/bindgen:cx", ptr %l69
  store %"compiler/bindgen:cx" %t175, ptr %l8
  %t176 = getelementptr %"compiler/bindgen:cx", ptr %l7, i32 0, i32 0
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t179 = getelementptr %"compiler/bindgen:cx", ptr %l8, i32 0, i32 0
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  %t181 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t184 = extractvalue { i64, ptr } %t177, 1
  %t185 = extractvalue { i64, ptr } %t177, 0
  %t186 = add i64 %t182, %t185
  %t187 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t191 = extractvalue { i64, ptr } %t178, 1
  %t192 = extractvalue { i64, ptr } %t178, 0
  %t193 = add i64 %t189, %t192
  %t194 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t198 = extractvalue { i64, ptr } %t180, 1
  %t199 = extractvalue { i64, ptr } %t180, 0
  %t200 = add i64 %t196, %t199
  %t201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t203 = add i64 %t200, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t181, i64 %t182)
  %t205 = getelementptr i8, ptr %t204, i64 %t182
  call void @olang_textcopy(ptr %t205, ptr %t184, i64 %t185)
  %t206 = getelementptr i8, ptr %t205, i64 %t185
  call void @olang_textcopy(ptr %t206, ptr %t187, i64 %t188)
  %t207 = getelementptr i8, ptr %t206, i64 %t188
  call void @olang_textcopy(ptr %t207, ptr %t191, i64 %t192)
  %t208 = getelementptr i8, ptr %t207, i64 %t192
  call void @olang_textcopy(ptr %t208, ptr %t194, i64 %t195)
  %t209 = getelementptr i8, ptr %t208, i64 %t195
  call void @olang_textcopy(ptr %t209, ptr %t198, i64 %t199)
  %t210 = getelementptr i8, ptr %t209, i64 %t199
  call void @olang_textcopy(ptr %t210, ptr %t201, i64 %t202)
  %t211 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t204, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } %t212, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  %t220 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t223 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t219, i64 %t220, i64 -1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t223, ptr %l76
  br label %bb37
bb37:
  %t224 = load %"compiler/bindgen:cx", ptr %l76
  %t225 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t224, ptr %t225
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb38:
  %t226 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t226, ptr %lp9
  %t227 = load %"compiler/bindgen:cx", ptr %l79
  %t228 = load ptr, ptr %lp9
  store %"compiler/bindgen:cx" %t227, ptr %t228
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %lp6
  %t231 = load %"compiler/bindgen:cx", ptr %t230
  %t234 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %v2, ptr %t229, %"compiler/bindgen:cx" %t231)
  store %"compiler/bindgen:cx" %t234, ptr %l82
  br label %bb39
bb39:
  %t235 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t235, ptr %lp10
  %t236 = load %"compiler/bindgen:cx", ptr %l82
  %t237 = load ptr, ptr %lp10
  store %"compiler/bindgen:cx" %t236, ptr %t237
  %t238 = load i64, ptr %l5, !tbaa !24
  %t240 = icmp eq i64 %t238, 8
  br i1 %t240, label %bb40, label %bb41
bb40:
  %t242 = load ptr, ptr %lp9
  %t243 = load %"compiler/bindgen:cx", ptr %t242
  store %"compiler/bindgen:cx" %t243, ptr %l85
  br label %bb43
bb41:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %lp9
  %t247 = load %"compiler/bindgen:cx", ptr %t246
  %t248 = load ptr, ptr %lp10
  %t249 = load %"compiler/bindgen:cx", ptr %t248
  %t253 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecLead(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t245, %"compiler/bindgen:cx" %t247, %"compiler/bindgen:cx" %t249)
  store %"compiler/bindgen:cx" %t253, ptr %l90
  br label %bb42
bb42:
  %t254 = load %"compiler/bindgen:cx", ptr %l90
  store %"compiler/bindgen:cx" %t254, ptr %l85
  br label %bb43
bb43:
  %t255 = load %"compiler/bindgen:cx", ptr %l85
  store %"compiler/bindgen:cx" %t255, ptr %l11
  %t256 = load i64, ptr %l5, !tbaa !24
  %t258 = icmp eq i64 %t256, 8
  br i1 %t258, label %bb44, label %bb45
bb44:
  %t260 = load ptr, ptr %lp9
  %t261 = getelementptr %"compiler/bindgen:cx", ptr %t260, i32 0, i32 1
  %t262 = load i64, ptr %t261, !tbaa !24
  %t263 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t266 = icmp eq i64 %t262, %t263
  store i1 %t266, ptr %l93, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb46
bb46:
  %t268 = load i1, ptr %l93, !tbaa !21
  br i1 %t268, label %bb47, label %bb48
bb47:
  %t269 = load ptr, ptr %lp10
  %t270 = getelementptr %"compiler/bindgen:cx", ptr %t269, i32 0, i32 1
  %t271 = load i64, ptr %t270, !tbaa !24
  %t272 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t275 = icmp ne i64 %t271, %t272
  store i1 %t275, ptr %l97, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb49
bb49:
  %t277 = load i1, ptr %l97, !tbaa !21
  br i1 %t277, label %bb50, label %bb51
bb50:
  %t278 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t280 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v2, ptr %v2, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d67, i32 0, i32 1) }, i64 %t278)
  store %"compiler/bindgen:cx" %t280, ptr %l102
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t281 = load %"compiler/bindgen:cx", ptr %l102
  store %"compiler/bindgen:cx" %t281, ptr %l11
  br label %bb53
bb53:
  %t282 = load ptr, ptr %lp9
  %t283 = getelementptr %"compiler/bindgen:cx", ptr %t282, i32 0, i32 0
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t286 = load ptr, ptr %lp10
  %t287 = getelementptr %"compiler/bindgen:cx", ptr %t286, i32 0, i32 0
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  %t289 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t290 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t292 = extractvalue { i64, ptr } %t284, 1
  %t293 = extractvalue { i64, ptr } %t284, 0
  %t294 = add i64 %t290, %t293
  %t295 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t297 = add i64 %t294, %t296
  %t299 = extractvalue { i64, ptr } %t285, 1
  %t300 = extractvalue { i64, ptr } %t285, 0
  %t301 = add i64 %t297, %t300
  %t302 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t303 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t304 = add i64 %t301, %t303
  %t306 = extractvalue { i64, ptr } %t288, 1
  %t307 = extractvalue { i64, ptr } %t288, 0
  %t308 = add i64 %t304, %t307
  %t309 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t311 = add i64 %t308, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t289, i64 %t290)
  %t313 = getelementptr i8, ptr %t312, i64 %t290
  call void @olang_textcopy(ptr %t313, ptr %t292, i64 %t293)
  %t314 = getelementptr i8, ptr %t313, i64 %t293
  call void @olang_textcopy(ptr %t314, ptr %t295, i64 %t296)
  %t315 = getelementptr i8, ptr %t314, i64 %t296
  call void @olang_textcopy(ptr %t315, ptr %t299, i64 %t300)
  %t316 = getelementptr i8, ptr %t315, i64 %t300
  call void @olang_textcopy(ptr %t316, ptr %t302, i64 %t303)
  %t317 = getelementptr i8, ptr %t316, i64 %t303
  call void @olang_textcopy(ptr %t317, ptr %t306, i64 %t307)
  %t318 = getelementptr i8, ptr %t317, i64 %t307
  call void @olang_textcopy(ptr %t318, ptr %t309, i64 %t310)
  %t319 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t312, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  %t328 = getelementptr %"compiler/bindgen:cx", ptr %l11, i32 0, i32 1
  %t329 = load i64, ptr %t328, !tbaa !24
  %t330 = getelementptr %"compiler/bindgen:cx", ptr %l11, i32 0, i32 2
  %t331 = load i64, ptr %t330, !tbaa !24
  %t332 = getelementptr %"compiler/bindgen:cx", ptr %l11, i32 0, i32 3
  %t333 = load { i64, ptr }, ptr %t332, !tbaa !27
  %t338 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t327, i64 %t329, i64 %t331, { i64, ptr } %t333)
  store %"compiler/bindgen:cx" %t338, ptr %l111
  br label %bb54
bb54:
  %t339 = load %"compiler/bindgen:cx", ptr %l111
  %t340 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t339, ptr %t340
  br label %bb55
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s1)
  br label %bb57
bb57:
  br label %bb4
bb58:
  %t341 = load ptr, ptr %lp3
  %t342 = load %"compiler/bindgen:cx", ptr %t341
  %t344 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t342, 1
  store { i32, %"compiler/bindgen:cx" } %t344, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/bindgen:cx" }, ptr %rv
  ret { i32, %"compiler/bindgen:cx" } %rr
}

define dso_local { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %l8 = alloca %"compiler/bindgen:cx"
  %l11 = alloca %"compiler/bindgen:cx"
  %l12 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca %"compiler/bindgen:cx"
  %l26 = alloca %"compiler/bindgen:cx"
  %l27 = alloca i32
  %l30 = alloca { i64, ptr }
  %l32 = alloca i1
  %l35 = alloca i32
  %l37 = alloca ptr
  %l40 = alloca %"compiler/bindgen:cx"
  %l43 = alloca %"compiler/bindgen:cx"
  %l44 = alloca i32
  %l49 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca %"compiler/bindgen:cx"
  %l62 = alloca %"compiler/bindgen:cx"
  %l65 = alloca %"compiler/bindgen:cx"
  %l68 = alloca %"compiler/bindgen:cx"
  %l72 = alloca %"compiler/bindgen:cx"
  %l73 = alloca { i64, ptr }
  %l76 = alloca %"compiler/bindgen:cx"
  %l84 = alloca %"compiler/bindgen:cx"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/bindgen:cx" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBinary(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2, i64 1)
  %t6 = extractvalue { i32, %"compiler/bindgen:cx" } %t5, 1
  %t7 = extractvalue { i32, %"compiler/bindgen:cx" } %t5, 0
  store i32 %t7, ptr %l12
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store %"compiler/bindgen:cx" %t6, ptr %l11
  br label %bb1
bb1:
  %t10 = load %"compiler/bindgen:cx", ptr %l11
  store %"compiler/bindgen:cx" %t10, ptr %l8
  br label %bb3
bb2:
  %t11 = load i32, ptr %l12, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  call void @__olang_scope_close(ptr %s0)
  %t21 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t19, 0
  store { i32, %"compiler/bindgen:cx" } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t22, ptr %lp2
  %t23 = load %"compiler/bindgen:cx", ptr %l8
  %t24 = load ptr, ptr %lp2
  store %"compiler/bindgen:cx" %t23, ptr %t24
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s0, ptr %t25)
  store { i64, ptr } %t27, ptr %l15
  br label %bb4
bb4:
  %t28 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t36, ptr %l17
  br label %bb5
bb5:
  %t37 = load i1, ptr %l17, !tbaa !21
  %t38 = xor i1 %t37, true
  br i1 %t38, label %bb6, label %bb7
bb6:
  %t40 = load ptr, ptr %lp2
  %t41 = load %"compiler/bindgen:cx", ptr %t40
  call void @__olang_scope_close(ptr %s0)
  %t43 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t41, 1
  store { i32, %"compiler/bindgen:cx" } %t43, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l20, !tbaa !29
  %t45 = load ptr, ptr %l20, !tbaa !29
  %t46 = getelementptr %"compiler/bindgen:cparse", ptr %t45, i32 0, i32 2
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = add i64 %t47, 1
  %t51 = load ptr, ptr %l20, !tbaa !29
  %t52 = getelementptr %"compiler/bindgen:cparse", ptr %t51, i32 0, i32 2
  store i64 %t49, ptr %t52, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t57 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t53, ptr %t54)
  %t58 = extractvalue { i32, %"compiler/bindgen:cx" } %t57, 1
  %t59 = extractvalue { i32, %"compiler/bindgen:cx" } %t57, 0
  store i32 %t59, ptr %l27
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb10, label %ok.61, !prof !99
ok.61:
  store %"compiler/bindgen:cx" %t58, ptr %l26
  br label %bb9
bb9:
  %t62 = load %"compiler/bindgen:cx", ptr %l26
  store %"compiler/bindgen:cx" %t62, ptr %l23
  br label %bb11
bb10:
  %t63 = load i32, ptr %l27, !tbaa !23
  %t64 = lshr i32 %t63, 16
  %t65 = and i32 %t63, 65535
  %t66 = icmp eq i32 %t64, 1
  %t67 = select i1 %t66, i32 1, i32 0
  %t68 = icmp eq i32 %t63, 0
  %t69 = shl i32 %t67, 16
  %t70 = or i32 %t69, %t65
  %t71 = select i1 %t68, i32 0, i32 %t70
  call void @__olang_scope_close(ptr %s0)
  %t73 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t71, 0
  store { i32, %"compiler/bindgen:cx" } %t73, ptr %rv
  br label %ret
bb11:
  %t74 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t74, ptr %lp3
  %t75 = load %"compiler/bindgen:cx", ptr %l23
  %t76 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t75, ptr %t76
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s0, ptr %t77)
  store { i64, ptr } %t79, ptr %l30
  br label %bb12
bb12:
  %t80 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t86, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t88, ptr %l32
  br label %bb13
bb13:
  %t89 = load i1, ptr %l32, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s2, ptr %t92, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i32 %t94, ptr %l35
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb17, label %ok.96, !prof !99
ok.96:
  br label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb18
bb17:
  %t97 = load i32, ptr %l35, !tbaa !23
  %t98 = lshr i32 %t97, 16
  %t99 = and i32 %t97, 65535
  %t100 = icmp eq i32 %t98, 1
  %t101 = select i1 %t100, i32 1, i32 0
  %t102 = icmp eq i32 %t97, 0
  %t103 = shl i32 %t101, 16
  %t104 = or i32 %t103, %t99
  %t105 = select i1 %t102, i32 0, i32 %t104
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t107 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t105, 0
  store { i32, %"compiler/bindgen:cx" } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l37, !tbaa !29
  %t109 = load ptr, ptr %l37, !tbaa !29
  %t110 = getelementptr %"compiler/bindgen:cparse", ptr %t109, i32 0, i32 2
  %t111 = load i64, ptr %t110, !tbaa !24
  %t113 = add i64 %t111, 1
  %t115 = load ptr, ptr %l37, !tbaa !29
  %t116 = getelementptr %"compiler/bindgen:cparse", ptr %t115, i32 0, i32 2
  store i64 %t113, ptr %t116, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t121 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t117, ptr %t118)
  %t122 = extractvalue { i32, %"compiler/bindgen:cx" } %t121, 1
  %t123 = extractvalue { i32, %"compiler/bindgen:cx" } %t121, 0
  store i32 %t123, ptr %l44
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb21, label %ok.125, !prof !99
ok.125:
  store %"compiler/bindgen:cx" %t122, ptr %l43
  br label %bb20
bb20:
  %t126 = load %"compiler/bindgen:cx", ptr %l43
  store %"compiler/bindgen:cx" %t126, ptr %l40
  br label %bb22
bb21:
  %t127 = load i32, ptr %l44, !tbaa !23
  %t128 = lshr i32 %t127, 16
  %t129 = and i32 %t127, 65535
  %t130 = icmp eq i32 %t128, 1
  %t131 = select i1 %t130, i32 1, i32 0
  %t132 = icmp eq i32 %t127, 0
  %t133 = shl i32 %t131, 16
  %t134 = or i32 %t133, %t129
  %t135 = select i1 %t132, i32 0, i32 %t134
  call void @__olang_scope_close(ptr %s0)
  %t137 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t135, 0
  store { i32, %"compiler/bindgen:cx" } %t137, ptr %rv
  br label %ret
bb22:
  %t138 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t138, ptr %lp4
  %t139 = load %"compiler/bindgen:cx", ptr %l40
  %t140 = load ptr, ptr %lp4
  store %"compiler/bindgen:cx" %t139, ptr %t140
  %t141 = load ptr, ptr %lp3
  %t142 = getelementptr %"compiler/bindgen:cx", ptr %t141, i32 0, i32 1
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t147 = icmp eq i64 %t143, %t144
  br i1 %t147, label %bb23, label %bb24
bb23:
  %t149 = load ptr, ptr %lp4
  %t150 = getelementptr %"compiler/bindgen:cx", ptr %t149, i32 0, i32 1
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t155 = icmp eq i64 %t151, %t152
  store i1 %t155, ptr %l49, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t157 = load i1, ptr %l49, !tbaa !21
  br i1 %t157, label %bb26, label %bb27
bb26:
  %t158 = load ptr, ptr %lp3
  %t159 = getelementptr %"compiler/bindgen:cx", ptr %t158, i32 0, i32 0
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  store { i64, ptr } %t160, ptr %l53, !tbaa !27
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %lp2
  %t163 = load %"compiler/bindgen:cx", ptr %t162
  %t166 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v2, ptr %v2, ptr %t161, %"compiler/bindgen:cx" %t163)
  store %"compiler/bindgen:cx" %t166, ptr %l56
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t167 = getelementptr %"compiler/bindgen:cx", ptr %l56, i32 0, i32 0
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t169 = load ptr, ptr %lp4
  %t170 = getelementptr %"compiler/bindgen:cx", ptr %t169, i32 0, i32 0
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t174 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = add i64 %t173, %t176
  %t178 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t180 = add i64 %t177, %t179
  %t182 = extractvalue { i64, ptr } %t168, 1
  %t183 = extractvalue { i64, ptr } %t168, 0
  %t184 = add i64 %t180, %t183
  %t185 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t187 = add i64 %t184, %t186
  %t189 = extractvalue { i64, ptr } %t171, 1
  %t190 = extractvalue { i64, ptr } %t171, 0
  %t191 = add i64 %t187, %t190
  %t192 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t194 = add i64 %t191, %t193
  %t195 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t172, i64 %t173)
  %t196 = getelementptr i8, ptr %t195, i64 %t173
  call void @olang_textcopy(ptr %t196, ptr %t175, i64 %t176)
  %t197 = getelementptr i8, ptr %t196, i64 %t176
  call void @olang_textcopy(ptr %t197, ptr %t178, i64 %t179)
  %t198 = getelementptr i8, ptr %t197, i64 %t179
  call void @olang_textcopy(ptr %t198, ptr %t182, i64 %t183)
  %t199 = getelementptr i8, ptr %t198, i64 %t183
  call void @olang_textcopy(ptr %t199, ptr %t185, i64 %t186)
  %t200 = getelementptr i8, ptr %t199, i64 %t186
  call void @olang_textcopy(ptr %t200, ptr %t189, i64 %t190)
  %t201 = getelementptr i8, ptr %t200, i64 %t190
  call void @olang_textcopy(ptr %t201, ptr %t192, i64 %t193)
  %t202 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t195, 1
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = extractvalue { i64, ptr } %t203, 1
  %t207 = mul i64 %t205, 1
  %t208 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t207)
  call void @llvm.memcpy.p0.p0.i64(ptr %t208, ptr %t206, i64 %t207, i1 false)
  %t209 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t211 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t214 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t210, i64 %t211, i64 -1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t214, ptr %l62
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t215 = load %"compiler/bindgen:cx", ptr %l62
  %t216 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t215, 1
  store { i32, %"compiler/bindgen:cx" } %t216, ptr %rv
  br label %ret
bb30:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %lp3
  %t219 = load %"compiler/bindgen:cx", ptr %t218
  %t222 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %v2, ptr %t217, %"compiler/bindgen:cx" %t219)
  store %"compiler/bindgen:cx" %t222, ptr %l65
  br label %bb31
bb31:
  %t223 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t223, ptr %lp5
  %t224 = load %"compiler/bindgen:cx", ptr %l65
  %t225 = load ptr, ptr %lp5
  store %"compiler/bindgen:cx" %t224, ptr %t225
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load ptr, ptr %lp4
  %t228 = load %"compiler/bindgen:cx", ptr %t227
  %t231 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %v2, ptr %t226, %"compiler/bindgen:cx" %t228)
  store %"compiler/bindgen:cx" %t231, ptr %l68
  br label %bb32
bb32:
  %t232 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t232, ptr %lp6
  %t233 = load %"compiler/bindgen:cx", ptr %l68
  %t234 = load ptr, ptr %lp6
  store %"compiler/bindgen:cx" %t233, ptr %t234
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %lp5
  %t237 = load %"compiler/bindgen:cx", ptr %t236
  %t238 = load ptr, ptr %lp6
  %t239 = load %"compiler/bindgen:cx", ptr %t238
  %t243 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecLead(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t235, %"compiler/bindgen:cx" %t237, %"compiler/bindgen:cx" %t239)
  store %"compiler/bindgen:cx" %t243, ptr %l72
  br label %bb33
bb33:
  %t244 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t244, ptr %lp7
  %t245 = load %"compiler/bindgen:cx", ptr %l72
  %t246 = load ptr, ptr %lp7
  store %"compiler/bindgen:cx" %t245, ptr %t246
  %t247 = load ptr, ptr %lp5
  %t248 = getelementptr %"compiler/bindgen:cx", ptr %t247, i32 0, i32 0
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  store { i64, ptr } %t249, ptr %l73, !tbaa !27
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %lp2
  %t252 = load %"compiler/bindgen:cx", ptr %t251
  %t255 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v2, ptr %v2, ptr %t250, %"compiler/bindgen:cx" %t252)
  store %"compiler/bindgen:cx" %t255, ptr %l76
  br label %bb34
bb34:
  %t256 = getelementptr %"compiler/bindgen:cx", ptr %l76, i32 0, i32 0
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  %t258 = load ptr, ptr %lp6
  %t259 = getelementptr %"compiler/bindgen:cx", ptr %t258, i32 0, i32 0
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  %t261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t263 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t263, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t257, 1
  %t272 = extractvalue { i64, ptr } %t257, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t278 = extractvalue { i64, ptr } %t260, 1
  %t279 = extractvalue { i64, ptr } %t260, 0
  %t280 = add i64 %t276, %t279
  %t281 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t283 = add i64 %t280, %t282
  %t284 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t283)
  call void @olang_textcopy(ptr %t284, ptr %t261, i64 %t262)
  %t285 = getelementptr i8, ptr %t284, i64 %t262
  call void @olang_textcopy(ptr %t285, ptr %t264, i64 %t265)
  %t286 = getelementptr i8, ptr %t285, i64 %t265
  call void @olang_textcopy(ptr %t286, ptr %t267, i64 %t268)
  %t287 = getelementptr i8, ptr %t286, i64 %t268
  call void @olang_textcopy(ptr %t287, ptr %t271, i64 %t272)
  %t288 = getelementptr i8, ptr %t287, i64 %t272
  call void @olang_textcopy(ptr %t288, ptr %t274, i64 %t275)
  %t289 = getelementptr i8, ptr %t288, i64 %t275
  call void @olang_textcopy(ptr %t289, ptr %t278, i64 %t279)
  %t290 = getelementptr i8, ptr %t289, i64 %t279
  call void @olang_textcopy(ptr %t290, ptr %t281, i64 %t282)
  %t291 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t284, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = extractvalue { i64, ptr } %t292, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  %t300 = load ptr, ptr %lp7
  %t301 = getelementptr %"compiler/bindgen:cx", ptr %t300, i32 0, i32 1
  %t302 = load i64, ptr %t301, !tbaa !24
  %t303 = load ptr, ptr %lp7
  %t304 = getelementptr %"compiler/bindgen:cx", ptr %t303, i32 0, i32 2
  %t305 = load i64, ptr %t304, !tbaa !24
  %t306 = load ptr, ptr %lp7
  %t307 = getelementptr %"compiler/bindgen:cx", ptr %t306, i32 0, i32 3
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  %t313 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t299, i64 %t302, i64 %t305, { i64, ptr } %t308)
  store %"compiler/bindgen:cx" %t313, ptr %l84
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t314 = load %"compiler/bindgen:cx", ptr %l84
  %t315 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t314, 1
  store { i32, %"compiler/bindgen:cx" } %t315, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/bindgen:cx" }, ptr %rv
  ret { i32, %"compiler/bindgen:cx" } %rr
}

define dso_local { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNumber(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l30 = alloca i32
  %l36 = alloca i1
  %l41 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l57 = alloca i1
  %l62 = alloca i1
  %l67 = alloca i32
  %l69 = alloca i64
  %l70 = alloca i64
  %l76 = alloca %"std/prelude/text:StringBuilder"
  %l78 = alloca i1
  %l80 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i32
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca i64
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca i1
  %l107 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l125 = alloca { i64, ptr }
  %l128 = alloca %"compiler/bindgen:cx"
  %l130 = alloca i1
  %l132 = alloca i1
  %l133 = alloca i1
  %l135 = alloca i1
  %l136 = alloca i1
  %l138 = alloca i1
  %l144 = alloca %"compiler/bindgen:cx"
  %l145 = alloca i64
  %l146 = alloca { i64, ptr }
  %l149 = alloca i64
  %l150 = alloca i64
  %l154 = alloca { i64, ptr }
  %l155 = alloca i64
  %l156 = alloca i32
  %l157 = alloca i64
  %l158 = alloca i32
  %l163 = alloca i32
  %l169 = alloca %"compiler/bindgen:cx"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/bindgen:cx" }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v1, ptr %s0, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t7, ptr %l13
  br label %bb2
bb2:
  %t8 = load i1, ptr %l13, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  %t9 = load i1, ptr %l3, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t16 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } %t15)
  store i1 %t16, ptr %l19
  br label %bb5
bb4:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb10
bb5:
  %t17 = load i1, ptr %l19, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb7:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t21 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t18, { i64, ptr } %t20)
  store i1 %t21, ptr %l23
  br label %bb8
bb8:
  %t22 = load i1, ptr %l23, !tbaa !21
  store i1 %t22, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l20, !tbaa !21
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t24 = load i1, ptr %l16, !tbaa !21
  store i1 %t24, ptr %l4, !tbaa !21
  %t25 = load i1, ptr %l3, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t30 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t27, { i64, ptr } %t29)
  store i1 %t30, ptr %l28
  br label %bb13
bb12:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb14
bb13:
  %t31 = load i1, ptr %l28, !tbaa !21
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb14
bb14:
  %t32 = load i1, ptr %l25, !tbaa !21
  br i1 %t32, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s1
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s1, ptr %t33, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i32 %t35, ptr %l30
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb18, label %ok.37, !prof !99
ok.37:
  br label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb19
bb18:
  %t38 = load i32, ptr %l30, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 1, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t48 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t46, 0
  store { i32, %"compiler/bindgen:cx" } %t48, ptr %rv
  br label %ret
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l5, !tbaa !24
  br label %bb21
bb21:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = sub i64 %t57, 1
  %t61 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 117
  br i1 %t66, label %bb24, label %bb25
bb23:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb33
bb24:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb26
bb25:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = sub i64 %t68, 1
  %t72 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 %t70
  %t75 = load i8, ptr %t74, !tbaa !32
  %t77 = icmp eq i8 %t75, 108
  store i1 %t77, ptr %l41, !tbaa !21
  br label %bb26
bb26:
  %t79 = load i1, ptr %l41, !tbaa !21
  br i1 %t79, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb32
bb28:
  %t80 = load i1, ptr %l4, !tbaa !21
  br i1 %t80, label %bb29, label %bb30
bb29:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t84 = sub i64 %t82, 1
  %t86 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i8, ptr %t87, i64 %t84
  %t89 = load i8, ptr %t88, !tbaa !32
  %t91 = icmp eq i8 %t89, 102
  store i1 %t91, ptr %l48, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb31
bb31:
  %t93 = load i1, ptr %l48, !tbaa !21
  store i1 %t93, ptr %l46, !tbaa !21
  br label %bb32
bb32:
  %t94 = load i1, ptr %l46, !tbaa !21
  store i1 %t94, ptr %l36, !tbaa !21
  br label %bb33
bb33:
  %t95 = load i1, ptr %l36, !tbaa !21
  %t96 = xor i1 %t95, true
  br i1 %t96, label %bb34, label %bb35
bb34:
  br label %bb38
bb35:
  br label %bb36
bb36:
  %t98 = load i64, ptr %l5, !tbaa !24
  %t100 = sub i64 %t98, 1
  store i64 %t100, ptr %l5, !tbaa !24
  br label %bb37
bb37:
  br label %bb21
bb38:
  %t102 = load i1, ptr %l4, !tbaa !21
  br i1 %t102, label %bb39, label %bb40
bb39:
  %t104 = load i64, ptr %l5, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t110 = icmp slt i64 %t104, %t107
  store i1 %t110, ptr %l57, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb41
bb41:
  %t112 = load i1, ptr %l57, !tbaa !21
  br i1 %t112, label %bb42, label %bb43
bb42:
  %t113 = load i64, ptr %l5, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i8, ptr %t116, i64 %t113
  %t118 = load i8, ptr %t117, !tbaa !32
  %t120 = icmp eq i8 %t118, 108
  store i1 %t120, ptr %l62, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb44
bb44:
  %t122 = load i1, ptr %l62, !tbaa !21
  br i1 %t122, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s3
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s3, ptr %t123, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i32 %t125, ptr %l67
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb48, label %ok.127, !prof !99
ok.127:
  br label %bb47
bb46:
  br label %bb50
bb47:
  br label %bb49
bb48:
  %t128 = load i32, ptr %l67, !tbaa !23
  %t129 = lshr i32 %t128, 16
  %t130 = and i32 %t128, 65535
  %t131 = icmp eq i32 %t129, 1
  %t132 = select i1 %t131, i32 1, i32 0
  %t133 = icmp eq i32 %t128, 0
  %t134 = shl i32 %t132, 16
  %t135 = or i32 %t134, %t130
  %t136 = select i1 %t133, i32 0, i32 %t135
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t138 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t136, 0
  store { i32, %"compiler/bindgen:cx" } %t138, ptr %rv
  br label %ret
bb49:
  call void @__olang_scope_close(ptr %s3)
  br label %bb50
bb50:
  %t139 = load i64, ptr %l5, !tbaa !24
  store i64 %t139, ptr %l69, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 0
  store i64 %t141, ptr %l70, !tbaa !24
  %t142 = icmp sge i64 0, 0
  br i1 %t142, label %bb51, label %bb52
bb51:
  %t144 = load i64, ptr %l69, !tbaa !24
  %t145 = icmp sle i64 0, %t144
  br i1 %t145, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_2281448cce404233_754aa41ddbc9325f)
  unreachable
bb53:
  %t147 = load i64, ptr %l69, !tbaa !24
  %t148 = load i64, ptr %l70, !tbaa !24
  %t149 = icmp sle i64 %t147, %t148
  br i1 %t149, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_2281448cce404233_754aa41ddbc9325f)
  unreachable
bb55:
  %t151 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l69, !tbaa !24
  %t154 = getelementptr i8, ptr %t152, i64 0
  %t155 = sub i64 %t153, 0
  %t156 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  store { i64, ptr } %t157, ptr %l6, !tbaa !27
  %t159 = load i1, ptr %l4, !tbaa !21
  br i1 %t159, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_2281448cce404233_754aa41ddbc9325f)
  unreachable
bb57:
  store %olang.scope zeroinitializer, ptr %s4
  %t161 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s4)
  store %"std/prelude/text:StringBuilder" %t161, ptr %l76
  br label %bb59
bb58:
  br label %bb100
bb59:
  %t162 = load %"std/prelude/text:StringBuilder", ptr %l76
  store %"std/prelude/text:StringBuilder" %t162, ptr %l7
  %t163 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t165 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t163, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t165, ptr %l78
  br label %bb60
bb60:
  %t166 = load i1, ptr %l78, !tbaa !21
  br i1 %t166, label %bb61, label %bb62
bb61:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s4, ptr %l7, i8 48)
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  %t168 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t171 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %s0, { i64, ptr } %t168, i8 101)
  %t172 = extractvalue { i32, i64 } %t171, 1
  %t173 = extractvalue { i32, i64 } %t171, 0
  store i32 %t173, ptr %l84
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb66, label %ok.175, !prof !99
ok.175:
  store i64 %t172, ptr %l83
  br label %bb65
bb65:
  %t176 = load i64, ptr %l83, !tbaa !24
  store i64 %t176, ptr %l80, !tbaa !24
  br label %bb68
bb66:
  br label %bb67
bb67:
  %t177 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  store i64 %t179, ptr %l80, !tbaa !24
  br label %bb68
bb68:
  %t181 = load i64, ptr %l80, !tbaa !24
  store i64 %t181, ptr %l8, !tbaa !24
  store ptr %l7, ptr %l87, !tbaa !29
  %t182 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t182, ptr %l88, !tbaa !27
  %t183 = load i64, ptr %l8, !tbaa !24
  store i64 %t183, ptr %l89, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  store i64 %t185, ptr %l90, !tbaa !24
  %t186 = icmp sge i64 0, 0
  br i1 %t186, label %bb69, label %bb70
bb69:
  %t188 = load i64, ptr %l89, !tbaa !24
  %t189 = icmp sle i64 0, %t188
  br i1 %t189, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_231822a9f2b4ccd6_f89b0d7c0520fae2)
  unreachable
bb71:
  %t191 = load i64, ptr %l89, !tbaa !24
  %t192 = load i64, ptr %l90, !tbaa !24
  %t193 = icmp sle i64 %t191, %t192
  br i1 %t193, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_231822a9f2b4ccd6_f89b0d7c0520fae2)
  unreachable
bb73:
  %t195 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = load i64, ptr %l89, !tbaa !24
  %t198 = getelementptr i8, ptr %t196, i64 0
  %t199 = sub i64 %t197, 0
  %t200 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  %t202 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %s0, ptr %t202, { i64, ptr } %t201)
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_231822a9f2b4ccd6_f89b0d7c0520fae2)
  unreachable
bb75:
  %t204 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t204, ptr %l95, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  store i64 %t205, ptr %l96, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  store i64 %t207, ptr %l97, !tbaa !24
  %t208 = icmp sge i64 0, 0
  br i1 %t208, label %bb76, label %bb77
bb76:
  %t210 = load i64, ptr %l96, !tbaa !24
  %t211 = icmp sle i64 0, %t210
  br i1 %t211, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_3945c858895394b5_b3e6527511891161)
  unreachable
bb78:
  %t213 = load i64, ptr %l96, !tbaa !24
  %t214 = load i64, ptr %l97, !tbaa !24
  %t215 = icmp sle i64 %t213, %t214
  br i1 %t215, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_3945c858895394b5_b3e6527511891161)
  unreachable
bb80:
  %t217 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = load i64, ptr %l96, !tbaa !24
  %t220 = getelementptr i8, ptr %t218, i64 0
  %t221 = sub i64 %t219, 0
  %t222 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t220, 1
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t227 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s4, { i64, ptr } %t223, { i64, ptr } %t226)
  store i1 %t227, ptr %l104
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_3945c858895394b5_b3e6527511891161)
  unreachable
bb82:
  %t228 = load i1, ptr %l104, !tbaa !21
  %t229 = xor i1 %t228, true
  br i1 %t229, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %s6, ptr %l7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb85
bb84:
  %t232 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t232, ptr %l107, !tbaa !27
  %t233 = load i64, ptr %l8, !tbaa !24
  %t235 = sub i64 %t233, 1
  %t237 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr i8, ptr %t238, i64 %t235
  %t240 = load i8, ptr %t239, !tbaa !32
  %t242 = icmp eq i8 %t240, 46
  br i1 %t242, label %bb86, label %bb87
bb85:
  call void @__olang_scope_close(ptr %s6)
  br label %bb90
bb86:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s4, ptr %l7, i8 48)
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  store ptr %l7, ptr %l113, !tbaa !29
  %t245 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t245, ptr %l114, !tbaa !27
  %t246 = load i64, ptr %l8, !tbaa !24
  store i64 %t246, ptr %l115, !tbaa !24
  %t247 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t247, 0
  store i64 %t250, ptr %l118, !tbaa !24
  %t251 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  store i64 %t252, ptr %l119, !tbaa !24
  %t253 = load i64, ptr %l115, !tbaa !24
  %t254 = icmp sge i64 %t253, 0
  br i1 %t254, label %bb91, label %bb92
bb91:
  %t256 = load i64, ptr %l115, !tbaa !24
  %t257 = load i64, ptr %l118, !tbaa !24
  %t258 = icmp sle i64 %t256, %t257
  br i1 %t258, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_5833c224f66d4858_52a9715d8b07374)
  unreachable
bb93:
  %t260 = load i64, ptr %l118, !tbaa !24
  %t261 = load i64, ptr %l119, !tbaa !24
  %t262 = icmp sle i64 %t260, %t261
  br i1 %t262, label %bb95, label %bb96
bb94:
  call void @__olang_check_failed(ptr @olang_loc_5833c224f66d4858_52a9715d8b07374)
  unreachable
bb95:
  %t264 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = load i64, ptr %l115, !tbaa !24
  %t267 = load i64, ptr %l118, !tbaa !24
  %t268 = getelementptr i8, ptr %t265, i64 %t266
  %t269 = sub i64 %t267, %t266
  %t270 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t268, 1
  %t272 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %s0, ptr %t272, { i64, ptr } %t271)
  br label %bb97
bb96:
  call void @__olang_check_failed(ptr @olang_loc_5833c224f66d4858_52a9715d8b07374)
  unreachable
bb97:
  %t275 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s4, ptr %v2, ptr %l7)
  store { i64, ptr } %t275, ptr %l125
  br label %bb98
bb98:
  %t276 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 0
  %t278 = extractvalue { i64, ptr } %t276, 1
  %t279 = mul i64 %t277, 1
  %t280 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t279)
  call void @llvm.memcpy.p0.p0.i64(ptr %t280, ptr %t278, i64 %t279, i1 false)
  %t281 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  %t283 = load i64, ptr @G_2ecompiler_2fbindgen_2eKFloat, !tbaa !24
  %t286 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v2, ptr %v2, { i64, ptr } %t282, i64 %t283)
  store %"compiler/bindgen:cx" %t286, ptr %l128
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t287 = load %"compiler/bindgen:cx", ptr %l128
  %t288 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t287, 1
  store { i32, %"compiler/bindgen:cx" } %t288, ptr %rv
  br label %ret
bb100:
  %t289 = load i1, ptr %l3, !tbaa !21
  br i1 %t289, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb104
bb102:
  %t291 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t293 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t291, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t293, ptr %l132
  br label %bb103
bb103:
  %t294 = load i1, ptr %l132, !tbaa !21
  store i1 %t294, ptr %l130, !tbaa !21
  br label %bb104
bb104:
  %t295 = load i1, ptr %l130, !tbaa !21
  br i1 %t295, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l133, !tbaa !21
  br label %bb108
bb106:
  %t296 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t298 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t296, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t298, ptr %l135
  br label %bb107
bb107:
  %t299 = load i1, ptr %l135, !tbaa !21
  store i1 %t299, ptr %l133, !tbaa !21
  br label %bb108
bb108:
  %t300 = load i1, ptr %l133, !tbaa !21
  br i1 %t300, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb112
bb110:
  %t301 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t303 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t301, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) })
  store i1 %t303, ptr %l138
  br label %bb111
bb111:
  %t304 = load i1, ptr %l138, !tbaa !21
  %t305 = xor i1 %t304, true
  store i1 %t305, ptr %l136, !tbaa !21
  br label %bb112
bb112:
  %t307 = load i1, ptr %l136, !tbaa !21
  br i1 %t307, label %bb113, label %bb114
bb113:
  %t308 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t308, 1
  %t311 = extractvalue { i64, ptr } %t308, 0
  %t312 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t310, i64 %t311)
  %t313 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t317 = extractvalue { i64, ptr } %t314, 1
  %t318 = mul i64 %t316, 1
  %t319 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t318)
  call void @llvm.memcpy.p0.p0.i64(ptr %t319, ptr %t317, i64 %t318, i1 false)
  %t320 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  %t322 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t325 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v2, ptr %v2, { i64, ptr } %t321, i64 %t322)
  store %"compiler/bindgen:cx" %t325, ptr %l144
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s0)
  %t326 = load %"compiler/bindgen:cx", ptr %l144
  %t327 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t326, 1
  store { i32, %"compiler/bindgen:cx" } %t327, ptr %rv
  br label %ret
bb116:
  %t328 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t328, ptr %l146, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t329, 0
  store i64 %t332, ptr %l149, !tbaa !24
  %t333 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t333, 0
  store i64 %t334, ptr %l150, !tbaa !24
  %t335 = icmp sge i64 1, 0
  br i1 %t335, label %bb117, label %bb118
bb117:
  %t337 = load i64, ptr %l149, !tbaa !24
  %t338 = icmp sle i64 1, %t337
  br i1 %t338, label %bb119, label %bb120
bb118:
  call void @__olang_check_failed(ptr @olang_loc_8ffdd2b799db8b57_8707d2f5a85c3a7b)
  unreachable
bb119:
  %t340 = load i64, ptr %l149, !tbaa !24
  %t341 = load i64, ptr %l150, !tbaa !24
  %t342 = icmp sle i64 %t340, %t341
  br i1 %t342, label %bb121, label %bb122
bb120:
  call void @__olang_check_failed(ptr @olang_loc_8ffdd2b799db8b57_8707d2f5a85c3a7b)
  unreachable
bb121:
  %t344 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = load i64, ptr %l149, !tbaa !24
  %t347 = getelementptr i8, ptr %t345, i64 1
  %t348 = sub i64 %t346, 1
  %t349 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t347, 1
  store { i64, ptr } %t350, ptr %l154, !tbaa !27
  %t351 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 8)
  %t352 = extractvalue { i32, i64 } %t351, 1
  %t353 = extractvalue { i32, i64 } %t351, 0
  store i32 %t353, ptr %l156
  %t354 = icmp ne i32 %t353, 0
  br i1 %t354, label %bb124, label %ok.355, !prof !99
ok.355:
  store i64 %t352, ptr %l155
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_8ffdd2b799db8b57_8707d2f5a85c3a7b)
  unreachable
bb123:
  %t356 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t357 = load i64, ptr %l155, !tbaa !24
  %t358 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t356, i64 %t357)
  %t359 = extractvalue { i32, i64 } %t358, 1
  %t360 = extractvalue { i32, i64 } %t358, 0
  store i32 %t360, ptr %l158
  %t361 = icmp ne i32 %t360, 0
  br i1 %t361, label %bb127, label %ok.362, !prof !99
ok.362:
  store i64 %t359, ptr %l157
  br label %bb126
bb124:
  br label %bb125
bb125:
  store %olang.scope zeroinitializer, ptr %s11
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t365 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t366 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t368 = extractvalue { i64, ptr } %t364, 1
  %t369 = extractvalue { i64, ptr } %t364, 0
  %t370 = add i64 %t366, %t369
  %t371 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t372 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t373 = add i64 %t370, %t372
  %t374 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t373)
  call void @olang_textcopy(ptr %t374, ptr %t365, i64 %t366)
  %t375 = getelementptr i8, ptr %t374, i64 %t366
  call void @olang_textcopy(ptr %t375, ptr %t368, i64 %t369)
  %t376 = getelementptr i8, ptr %t375, i64 %t369
  call void @olang_textcopy(ptr %t376, ptr %t371, i64 %t372)
  %t377 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t374, 1
  %t380 = extractvalue { i64, ptr } %t378, 0
  %t381 = extractvalue { i64, ptr } %t378, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  %t388 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s11, ptr %t363, { i64, ptr } %t385)
  store i32 %t388, ptr %l163
  %t389 = icmp ne i32 %t388, 0
  br i1 %t389, label %bb129, label %ok.390, !prof !99
ok.390:
  br label %bb128
bb126:
  %t391 = load i64, ptr %l157, !tbaa !24
  store i64 %t391, ptr %l145, !tbaa !24
  br label %bb131
bb127:
  br label %bb125
bb128:
  br label %bb130
bb129:
  %t392 = load i32, ptr %l163, !tbaa !23
  %t393 = lshr i32 %t392, 16
  %t394 = and i32 %t392, 65535
  %t395 = icmp eq i32 %t393, 1
  %t396 = select i1 %t395, i32 1, i32 0
  %t397 = icmp eq i32 %t392, 0
  %t398 = shl i32 %t396, 16
  %t399 = or i32 %t398, %t394
  %t400 = select i1 %t397, i32 0, i32 %t399
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t402 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t400, 0
  store { i32, %"compiler/bindgen:cx" } %t402, ptr %rv
  br label %ret
bb130:
  call void @__olang_scope_close(ptr %s11)
  store i64 0, ptr %l145, !tbaa !24
  br label %bb131
bb131:
  %t403 = load i64, ptr %l145, !tbaa !24
  %t406 = call i64 @__olang_fmt_i64(ptr null, i64 %t403)
  %t407 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t406)
  %t408 = call i64 @__olang_fmt_i64(ptr %t407, i64 %t403)
  %t409 = insertvalue { i64, ptr } undef, i64 %t406, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t407, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = extractvalue { i64, ptr } %t410, 1
  %t414 = mul i64 %t412, 1
  %t415 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t414)
  call void @llvm.memcpy.p0.p0.i64(ptr %t415, ptr %t413, i64 %t414, i1 false)
  %t416 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t415, 1
  %t418 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t421 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v2, ptr %v2, { i64, ptr } %t417, i64 %t418)
  store %"compiler/bindgen:cx" %t421, ptr %l169
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s0)
  %t422 = load %"compiler/bindgen:cx", ptr %l169
  %t423 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t422, 1
  store { i32, %"compiler/bindgen:cx" } %t423, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/bindgen:cx" }, ptr %rv
  ret { i32, %"compiler/bindgen:cx" } %rr
}

define dso_local { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecUnary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %lp7 = alloca ptr
  %l8 = alloca %"compiler/bindgen:cx"
  %l10 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca %"compiler/bindgen:cx"
  %l26 = alloca %"compiler/bindgen:cx"
  %l27 = alloca i32
  %l29 = alloca %"compiler/bindgen:cx"
  %l31 = alloca i1
  %l40 = alloca %"compiler/bindgen:cx"
  %l42 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca %"compiler/bindgen:cx"
  %l49 = alloca %"compiler/bindgen:cx"
  %l50 = alloca i32
  %l54 = alloca %"compiler/bindgen:cx"
  %l59 = alloca %"compiler/bindgen:cx"
  %l61 = alloca i1
  %l64 = alloca ptr
  %l67 = alloca %"std/prelude/text:StringBuilder"
  %l74 = alloca i1
  %l76 = alloca { i64, ptr }
  %l78 = alloca i1
  %l81 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l89 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i1
  %l97 = alloca i1
  %l99 = alloca { i64, ptr }
  %l101 = alloca i1
  %l102 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca %"compiler/bindgen:cx"
  %l109 = alloca %"compiler/bindgen:cx"
  %l110 = alloca i32
  %l112 = alloca %"compiler/bindgen:cx"
  %l119 = alloca %"compiler/bindgen:cx"
  %l122 = alloca %"compiler/bindgen:cx"
  %l125 = alloca %"compiler/bindgen:cx"
  %l126 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/bindgen:cx" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s0, ptr %t1)
  store { i64, ptr } %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store i1 %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load i1, ptr %l12, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb4:
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t11, ptr %l15
  br label %bb5
bb5:
  %t12 = load i1, ptr %l15, !tbaa !21
  store i1 %t12, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t13 = load i1, ptr %l13, !tbaa !21
  br i1 %t13, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t16, ptr %l18
  br label %bb9
bb9:
  %t17 = load i1, ptr %l18, !tbaa !21
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t18 = load i1, ptr %l16, !tbaa !21
  br i1 %t18, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l19, !tbaa !29
  %t20 = load ptr, ptr %l19, !tbaa !29
  %t21 = getelementptr %"compiler/bindgen:cparse", ptr %t20, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = load ptr, ptr %l19, !tbaa !29
  %t27 = getelementptr %"compiler/bindgen:cparse", ptr %t26, i32 0, i32 2
  store i64 %t24, ptr %t27, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l22, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecUnary(ptr %v0, ptr %v1, ptr %v0, ptr %t29, ptr %t30)
  %t34 = extractvalue { i32, %"compiler/bindgen:cx" } %t33, 1
  %t35 = extractvalue { i32, %"compiler/bindgen:cx" } %t33, 0
  store i32 %t35, ptr %l27
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb14, label %ok.37, !prof !99
ok.37:
  store %"compiler/bindgen:cx" %t34, ptr %l26
  br label %bb13
bb12:
  br label %bb22
bb13:
  %t38 = load %"compiler/bindgen:cx", ptr %l26
  store %"compiler/bindgen:cx" %t38, ptr %l23
  br label %bb15
bb14:
  %t39 = load i32, ptr %l27, !tbaa !23
  %t40 = lshr i32 %t39, 16
  %t41 = and i32 %t39, 65535
  %t42 = icmp eq i32 %t40, 1
  %t43 = select i1 %t42, i32 1, i32 0
  %t44 = icmp eq i32 %t39, 0
  %t45 = shl i32 %t43, 16
  %t46 = or i32 %t45, %t41
  %t47 = select i1 %t44, i32 0, i32 %t46
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t49 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t47, 0
  store { i32, %"compiler/bindgen:cx" } %t49, ptr %rv
  br label %ret
bb15:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load %"compiler/bindgen:cx", ptr %l23
  %t52 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v0, ptr %v2, ptr %t50, %"compiler/bindgen:cx" %t51)
  store %"compiler/bindgen:cx" %t52, ptr %l29
  br label %bb16
bb16:
  %t53 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t53, ptr %lp3
  %t54 = load %"compiler/bindgen:cx", ptr %l29
  %t55 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t54, ptr %t55
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s1, { i64, ptr } %t56, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t58, ptr %l31
  br label %bb17
bb17:
  %t59 = load i1, ptr %l31, !tbaa !21
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %lp3
  %t61 = load %"compiler/bindgen:cx", ptr %t60
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t63 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t61, 1
  store { i32, %"compiler/bindgen:cx" } %t63, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = load ptr, ptr %lp3
  %t66 = getelementptr %"compiler/bindgen:cx", ptr %t65, i32 0, i32 0
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t71 = extractvalue { i64, ptr } %t64, 1
  %t72 = extractvalue { i64, ptr } %t64, 0
  %t73 = add i64 %t69, %t72
  %t75 = extractvalue { i64, ptr } %t67, 1
  %t76 = extractvalue { i64, ptr } %t67, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t81 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t68, i64 %t69)
  %t82 = getelementptr i8, ptr %t81, i64 %t69
  call void @olang_textcopy(ptr %t82, ptr %t71, i64 %t72)
  %t83 = getelementptr i8, ptr %t82, i64 %t72
  call void @olang_textcopy(ptr %t83, ptr %t75, i64 %t76)
  %t84 = getelementptr i8, ptr %t83, i64 %t76
  call void @olang_textcopy(ptr %t84, ptr %t78, i64 %t79)
  %t85 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t81, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t94 = load ptr, ptr %lp3
  %t95 = getelementptr %"compiler/bindgen:cx", ptr %t94, i32 0, i32 1
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = load ptr, ptr %lp3
  %t98 = getelementptr %"compiler/bindgen:cx", ptr %t97, i32 0, i32 2
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = load ptr, ptr %lp3
  %t101 = getelementptr %"compiler/bindgen:cx", ptr %t100, i32 0, i32 3
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t107 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t93, i64 %t96, i64 %t99, { i64, ptr } %t102)
  store %"compiler/bindgen:cx" %t107, ptr %l40
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t108 = load %"compiler/bindgen:cx", ptr %l40
  %t109 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t108, 1
  store { i32, %"compiler/bindgen:cx" } %t109, ptr %rv
  br label %ret
bb22:
  %t110 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t112 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t110, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store i1 %t112, ptr %l42
  br label %bb23
bb23:
  %t113 = load i1, ptr %l42, !tbaa !21
  br i1 %t113, label %bb24, label %bb25
bb24:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l43, !tbaa !29
  %t115 = load ptr, ptr %l43, !tbaa !29
  %t116 = getelementptr %"compiler/bindgen:cparse", ptr %t115, i32 0, i32 2
  %t117 = load i64, ptr %t116, !tbaa !24
  %t119 = add i64 %t117, 1
  %t121 = load ptr, ptr %l43, !tbaa !29
  %t122 = getelementptr %"compiler/bindgen:cparse", ptr %t121, i32 0, i32 2
  store i64 %t119, ptr %t122, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t127 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecUnary(ptr %v0, ptr %v1, ptr %v0, ptr %t123, ptr %t124)
  %t128 = extractvalue { i32, %"compiler/bindgen:cx" } %t127, 1
  %t129 = extractvalue { i32, %"compiler/bindgen:cx" } %t127, 0
  store i32 %t129, ptr %l50
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb27, label %ok.131, !prof !99
ok.131:
  store %"compiler/bindgen:cx" %t128, ptr %l49
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t132 = load %"compiler/bindgen:cx", ptr %l49
  store %"compiler/bindgen:cx" %t132, ptr %l46
  br label %bb28
bb27:
  %t133 = load i32, ptr %l50, !tbaa !23
  %t134 = lshr i32 %t133, 16
  %t135 = and i32 %t133, 65535
  %t136 = icmp eq i32 %t134, 1
  %t137 = select i1 %t136, i32 1, i32 0
  %t138 = icmp eq i32 %t133, 0
  %t139 = shl i32 %t137, 16
  %t140 = or i32 %t139, %t135
  %t141 = select i1 %t138, i32 0, i32 %t140
  call void @__olang_scope_close(ptr %s0)
  %t143 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t141, 0
  store { i32, %"compiler/bindgen:cx" } %t143, ptr %rv
  br label %ret
bb28:
  %t144 = load %"compiler/bindgen:cx", ptr %l46
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t149 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v0, ptr %v0, ptr %t145, %"compiler/bindgen:cx" %t144)
  store %"compiler/bindgen:cx" %t149, ptr %l54
  br label %bb29
bb29:
  %t150 = getelementptr %"compiler/bindgen:cx", ptr %l54, i32 0, i32 0
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  %t152 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t155 = extractvalue { i64, ptr } %t151, 1
  %t156 = extractvalue { i64, ptr } %t151, 0
  %t157 = add i64 %t153, %t156
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t160 = add i64 %t157, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t152, i64 %t153)
  %t162 = getelementptr i8, ptr %t161, i64 %t153
  call void @olang_textcopy(ptr %t162, ptr %t155, i64 %t156)
  %t163 = getelementptr i8, ptr %t162, i64 %t156
  call void @olang_textcopy(ptr %t163, ptr %t158, i64 %t159)
  %t164 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t161, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = extractvalue { i64, ptr } %t165, 1
  %t169 = mul i64 %t167, 1
  %t170 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t169)
  call void @llvm.memcpy.p0.p0.i64(ptr %t170, ptr %t168, i64 %t169, i1 false)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  %t173 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t176 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t172, i64 %t173, i64 -1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d106, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t176, ptr %l59
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t177 = load %"compiler/bindgen:cx", ptr %l59
  %t178 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t177, 1
  store { i32, %"compiler/bindgen:cx" } %t178, ptr %rv
  br label %ret
bb31:
  %t179 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t181 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t179, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) })
  store i1 %t181, ptr %l61
  br label %bb32
bb32:
  %t182 = load i1, ptr %l61, !tbaa !21
  br i1 %t182, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/bindgen:cparse", ptr %t183, i32 0, i32 2
  %t186 = load i64, ptr %t185, !tbaa !24
  store i64 %t186, ptr %l5, !tbaa !24
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l64, !tbaa !29
  %t189 = load ptr, ptr %l64, !tbaa !29
  %t190 = getelementptr %"compiler/bindgen:cparse", ptr %t189, i32 0, i32 2
  %t191 = load i64, ptr %t190, !tbaa !24
  %t193 = add i64 %t191, 1
  %t195 = load ptr, ptr %l64, !tbaa !29
  %t196 = getelementptr %"compiler/bindgen:cparse", ptr %t195, i32 0, i32 2
  store i64 %t193, ptr %t196, !tbaa !24
  %t197 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s6)
  store %"std/prelude/text:StringBuilder" %t197, ptr %l67
  br label %bb35
bb34:
  br label %bb66
bb35:
  %t198 = load %"std/prelude/text:StringBuilder", ptr %l67
  store %"std/prelude/text:StringBuilder" %t198, ptr %l6
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr %"compiler/bindgen:cparse", ptr %t199, i32 0, i32 2
  %t202 = load i64, ptr %t201, !tbaa !24
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr %"compiler/bindgen:cparse", ptr %t203, i32 0, i32 0
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t211 = icmp slt i64 %t202, %t208
  br i1 %t211, label %bb37, label %bb38
bb37:
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s7, ptr %t213)
  store { i64, ptr } %t215, ptr %l76
  br label %bb39
bb38:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb41
bb39:
  %t216 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  %t218 = extractvalue { i64, ptr } %t216, 1
  %t219 = mul i64 %t217, 1
  %t220 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t219)
  call void @llvm.memcpy.p0.p0.i64(ptr %t220, ptr %t218, i64 %t219, i1 false)
  %t221 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  %t224 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t222, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) })
  store i1 %t224, ptr %l78
  br label %bb40
bb40:
  %t225 = load i1, ptr %l78, !tbaa !21
  %t226 = xor i1 %t225, true
  store i1 %t226, ptr %l74, !tbaa !21
  br label %bb41
bb41:
  %t228 = load i1, ptr %l74, !tbaa !21
  %t229 = xor i1 %t228, true
  br i1 %t229, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb43:
  br label %bb44
bb44:
  store ptr %l6, ptr %l81, !tbaa !29
  %t231 = load ptr, ptr %l1, !tbaa !29
  %t233 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s7, ptr %t231)
  store { i64, ptr } %t233, ptr %l83
  br label %bb45
bb45:
  %t234 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 0
  %t236 = extractvalue { i64, ptr } %t234, 1
  %t237 = mul i64 %t235, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t238, ptr %t236, i64 %t237, i1 false)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t241 = load ptr, ptr %l81, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s7, ptr %t241, { i64, ptr } %t240)
  br label %bb46
bb46:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s7, ptr %l6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) })
  br label %bb47
bb47:
  %t244 = load ptr, ptr %l1, !tbaa !29
  store ptr %t244, ptr %l86, !tbaa !29
  %t245 = load ptr, ptr %l86, !tbaa !29
  %t246 = getelementptr %"compiler/bindgen:cparse", ptr %t245, i32 0, i32 2
  %t247 = load i64, ptr %t246, !tbaa !24
  %t249 = add i64 %t247, 1
  %t251 = load ptr, ptr %l86, !tbaa !29
  %t252 = getelementptr %"compiler/bindgen:cparse", ptr %t251, i32 0, i32 2
  store i64 %t249, ptr %t252, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb48:
  br label %bb36
bb49:
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l89, !tbaa !29
  %t255 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s6, ptr %v2, ptr %l6)
  store { i64, ptr } %t255, ptr %l91
  br label %bb50
bb50:
  %t256 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 0
  %t258 = extractvalue { i64, ptr } %t256, 1
  %t259 = mul i64 %t257, 1
  %t260 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t259)
  call void @llvm.memcpy.p0.p0.i64(ptr %t260, ptr %t258, i64 %t259, i1 false)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  %t263 = load ptr, ptr %l89, !tbaa !29
  %t265 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecastType(ptr %v0, ptr %v2, ptr %v2, ptr %t263, { i64, ptr } %t262)
  store { i64, ptr } %t265, ptr %l93
  br label %bb51
bb51:
  %t266 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t266, ptr %lp7
  %t267 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t268 = load ptr, ptr %lp7
  store { i64, ptr } %t267, ptr %t268, !tbaa !27
  %t269 = load ptr, ptr %lp7
  %t270 = load { i64, ptr }, ptr %t269, !tbaa !27
  %t272 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s6, { i64, ptr } %t270, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store i1 %t272, ptr %l95
  br label %bb52
bb52:
  %t273 = load i1, ptr %l95, !tbaa !21
  %t274 = xor i1 %t273, true
  br i1 %t274, label %bb53, label %bb54
bb53:
  %t276 = load ptr, ptr %l1, !tbaa !29
  %t278 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s6, ptr %t276)
  store { i64, ptr } %t278, ptr %l99
  br label %bb55
bb54:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb57
bb55:
  %t279 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 0
  %t281 = extractvalue { i64, ptr } %t279, 1
  %t282 = mul i64 %t280, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t282)
  call void @llvm.memcpy.p0.p0.i64(ptr %t283, ptr %t281, i64 %t282, i1 false)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  %t287 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t285, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d111, i32 0, i32 1) })
  store i1 %t287, ptr %l101
  br label %bb56
bb56:
  %t288 = load i1, ptr %l101, !tbaa !21
  store i1 %t288, ptr %l97, !tbaa !21
  br label %bb57
bb57:
  %t289 = load i1, ptr %l97, !tbaa !21
  br i1 %t289, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s8
  %t290 = load ptr, ptr %l1, !tbaa !29
  store ptr %t290, ptr %l102, !tbaa !29
  %t291 = load ptr, ptr %l102, !tbaa !29
  %t292 = getelementptr %"compiler/bindgen:cparse", ptr %t291, i32 0, i32 2
  %t293 = load i64, ptr %t292, !tbaa !24
  %t295 = add i64 %t293, 1
  %t297 = load ptr, ptr %l102, !tbaa !29
  %t298 = getelementptr %"compiler/bindgen:cparse", ptr %t297, i32 0, i32 2
  store i64 %t295, ptr %t298, !tbaa !24
  %t299 = load ptr, ptr %l0, !tbaa !29
  store ptr %t299, ptr %l105, !tbaa !29
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load ptr, ptr %l1, !tbaa !29
  %t304 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecUnary(ptr %v0, ptr %v1, ptr %v0, ptr %t300, ptr %t301)
  %t305 = extractvalue { i32, %"compiler/bindgen:cx" } %t304, 1
  %t306 = extractvalue { i32, %"compiler/bindgen:cx" } %t304, 0
  store i32 %t306, ptr %l110
  %t307 = icmp ne i32 %t306, 0
  br i1 %t307, label %bb61, label %ok.308, !prof !99
ok.308:
  store %"compiler/bindgen:cx" %t305, ptr %l109
  br label %bb60
bb59:
  br label %bb65
bb60:
  %t309 = load %"compiler/bindgen:cx", ptr %l109
  store %"compiler/bindgen:cx" %t309, ptr %l106
  br label %bb62
bb61:
  %t310 = load i32, ptr %l110, !tbaa !23
  %t311 = lshr i32 %t310, 16
  %t312 = and i32 %t310, 65535
  %t313 = icmp eq i32 %t311, 1
  %t314 = select i1 %t313, i32 1, i32 0
  %t315 = icmp eq i32 %t310, 0
  %t316 = shl i32 %t314, 16
  %t317 = or i32 %t316, %t312
  %t318 = select i1 %t315, i32 0, i32 %t317
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t320 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t318, 0
  store { i32, %"compiler/bindgen:cx" } %t320, ptr %rv
  br label %ret
bb62:
  %t321 = load ptr, ptr %l105, !tbaa !29
  %t322 = load %"compiler/bindgen:cx", ptr %l106
  %t323 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v0, ptr %s8, ptr %t321, %"compiler/bindgen:cx" %t322)
  store %"compiler/bindgen:cx" %t323, ptr %l112
  br label %bb63
bb63:
  %t324 = load %"compiler/bindgen:cx", ptr %l112
  store %"compiler/bindgen:cx" %t324, ptr %l8
  %t325 = load ptr, ptr %lp7
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  %t327 = getelementptr %"compiler/bindgen:cx", ptr %l8, i32 0, i32 0
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t326, 1
  %t331 = extractvalue { i64, ptr } %t326, 0
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t336 = extractvalue { i64, ptr } %t328, 1
  %t337 = extractvalue { i64, ptr } %t328, 0
  %t338 = add i64 %t334, %t337
  %t339 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t341 = add i64 %t338, %t340
  %t342 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t341)
  call void @olang_textcopy(ptr %t342, ptr %t330, i64 %t331)
  %t343 = getelementptr i8, ptr %t342, i64 %t331
  call void @olang_textcopy(ptr %t343, ptr %t332, i64 %t333)
  %t344 = getelementptr i8, ptr %t343, i64 %t333
  call void @olang_textcopy(ptr %t344, ptr %t336, i64 %t337)
  %t345 = getelementptr i8, ptr %t344, i64 %t337
  call void @olang_textcopy(ptr %t345, ptr %t339, i64 %t340)
  %t346 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t342, 1
  %t349 = extractvalue { i64, ptr } %t347, 0
  %t350 = extractvalue { i64, ptr } %t347, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t355 = load i64, ptr @G_2ecompiler_2fbindgen_2eKType, !tbaa !24
  %t356 = load ptr, ptr %lp7
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  %t361 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t354, i64 %t355, i64 -1, { i64, ptr } %t357)
  store %"compiler/bindgen:cx" %t361, ptr %l119
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t362 = load %"compiler/bindgen:cx", ptr %l119
  %t363 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t362, 1
  store { i32, %"compiler/bindgen:cx" } %t363, ptr %rv
  br label %ret
bb65:
  %t364 = load ptr, ptr %l1, !tbaa !29
  %t365 = load i64, ptr %l5, !tbaa !24
  %t368 = getelementptr %"compiler/bindgen:cparse", ptr %t364, i32 0, i32 2
  store i64 %t365, ptr %t368, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb66:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t373 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecPrimary(ptr %v0, ptr %v1, ptr %v2, ptr %t369, ptr %t370)
  %t374 = extractvalue { i32, %"compiler/bindgen:cx" } %t373, 1
  %t375 = extractvalue { i32, %"compiler/bindgen:cx" } %t373, 0
  store i32 %t375, ptr %l126
  %t376 = icmp ne i32 %t375, 0
  br i1 %t376, label %bb68, label %ok.377, !prof !99
ok.377:
  store %"compiler/bindgen:cx" %t374, ptr %l125
  br label %bb67
bb67:
  %t378 = load %"compiler/bindgen:cx", ptr %l125
  store %"compiler/bindgen:cx" %t378, ptr %l122
  br label %bb69
bb68:
  %t379 = load i32, ptr %l126, !tbaa !23
  %t380 = lshr i32 %t379, 16
  %t381 = and i32 %t379, 65535
  %t382 = icmp eq i32 %t380, 1
  %t383 = select i1 %t382, i32 1, i32 0
  %t384 = icmp eq i32 %t379, 0
  %t385 = shl i32 %t383, 16
  %t386 = or i32 %t385, %t381
  %t387 = select i1 %t384, i32 0, i32 %t386
  call void @__olang_scope_close(ptr %s0)
  %t389 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t387, 0
  store { i32, %"compiler/bindgen:cx" } %t389, ptr %rv
  br label %ret
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t390 = load %"compiler/bindgen:cx", ptr %l122
  %t391 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t390, 1
  store { i32, %"compiler/bindgen:cx" } %t391, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/bindgen:cx" }, ptr %rv
  ret { i32, %"compiler/bindgen:cx" } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l6 = alloca i1
  %l8 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @compiler_2fbindgen_2eusable(ptr %v1, { i64, ptr } %t1)
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:gen", ptr %t9, i32 0, i32 10
  %t15 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %t11, { i64, ptr } %t7)
  store i1 %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load i1, ptr %l13, !tbaa !21
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp sge i64 %t18, -2147483648
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = icmp sle i64 %t22, 2147483647
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d115, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb14
bb14:
  %t27 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/bindgen:gen", ptr %t28, i32 0, i32 9
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = extractvalue { i64, ptr } %t31, 1
  %t36 = extractvalue { i64, ptr } %t31, 0
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t41 = extractvalue { i64, ptr } %t27, 1
  %t42 = extractvalue { i64, ptr } %t27, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t48 = call i64 @__olang_fmt_i64(ptr null, i64 %t33)
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t35, i64 %t36)
  %t51 = getelementptr i8, ptr %t50, i64 %t36
  call void @olang_textcopy(ptr %t51, ptr %t37, i64 %t38)
  %t52 = getelementptr i8, ptr %t51, i64 %t38
  call void @olang_textcopy(ptr %t52, ptr %t41, i64 %t42)
  %t53 = getelementptr i8, ptr %t52, i64 %t42
  call void @olang_textcopy(ptr %t53, ptr %t44, i64 %t45)
  %t54 = getelementptr i8, ptr %t53, i64 %t45
  %t55 = call i64 @__olang_fmt_i64(ptr %t54, i64 %t33)
  %t56 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t50, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t30, { i64, ptr } %t64)
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/bindgen:gen", ptr %t67, i32 0, i32 10
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = extractvalue { i64, ptr } %t70, 0
  %t74 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t72, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = extractvalue { i64, ptr } %t76, 1
  %t80 = mul i64 %t78, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t80)
  call void @llvm.memcpy.p0.p0.i64(ptr %t81, ptr %t79, i64 %t80, i1 false)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t69, { i64, ptr } %t83, i64 0)
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/bindgen:gen", ptr %t86, i32 0, i32 21
  %t89 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t91, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = extractvalue { i64, ptr } %t95, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t88, { i64, ptr } %t102, i64 0)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edump(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %lp13 = alloca ptr
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca { i64, ptr }
  %l53 = alloca %"std/os:Output"
  %l55 = alloca { i64, ptr }
  %l56 = alloca %"std/os:Output"
  %l57 = alloca i32
  %l59 = alloca i1
  %l65 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l69 = alloca i32
  %l71 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i32
  %l76 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t5 = extractvalue { i64, ptr } %a1, 1
  %t6 = extractvalue { i64, ptr } %a1, 0
  %t7 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t6)
  call void @olang_textcopy(ptr %t7, ptr %t5, i64 %t6)
  %t8 = insertvalue { i64, ptr } undef, i64 %t6, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t7, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = extractvalue { i64, ptr } %t9, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t16)
  br label %bb2
bb2:
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  %t43 = extractvalue { i64, ptr } %t39, 1
  %t44 = extractvalue { i64, ptr } %t39, 0
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t43, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t54)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l6, !tbaa !24
  br label %bb3
bb9:
  store %olang.scope zeroinitializer, ptr %s6
  %t62 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t63 = insertvalue [8 x { i64, ptr }] %t62, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t64 = insertvalue [8 x { i64, ptr }] %t63, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d120, i32 0, i32 1) }, 2
  %t65 = insertvalue [8 x { i64, ptr }] %t64, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d121, i32 0, i32 1) }, 3
  %t66 = insertvalue [8 x { i64, ptr }] %t65, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d122, i32 0, i32 1) }, 4
  %t67 = insertvalue [8 x { i64, ptr }] %t66, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d123, i32 0, i32 1) }, 5
  %t68 = insertvalue [8 x { i64, ptr }] %t67, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d124, i32 0, i32 1) }, 6
  %t70 = insertvalue [8 x { i64, ptr }] %t68, { i64, ptr } %a3, 7
  %t72 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 128, i64 8)
  store [8 x { i64, ptr }] %t70, ptr %t72
  store ptr %t72, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t74 = load ptr, ptr %l9
  store i64 8, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t85 = load ptr, ptr %l9
  %t86 = load i64, ptr %l10, !tbaa !24
  %t89 = getelementptr [8 x { i64, ptr }], ptr %t85, i64 0, i64 %t86
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !37
  %t94 = extractvalue { i64, ptr } %t90, 1
  %t95 = extractvalue { i64, ptr } %t90, 0
  %t96 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t94, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t101 = extractvalue { i64, ptr } %t98, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t105)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t108 = load i64, ptr %l10, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l10, !tbaa !24
  br label %bb10
bb16:
  call void @__olang_scope_close(ptr %s6)
  %t113 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t113, ptr %l55
  br label %bb17
bb17:
  %t114 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t115 = call { i32, %"std/os:Output" } @compiler_2fbindgen_2eclangSays(ptr %s0, ptr %v4, { i64, ptr } %t114)
  %t116 = extractvalue { i32, %"std/os:Output" } %t115, 1
  %t117 = extractvalue { i32, %"std/os:Output" } %t115, 0
  store i32 %t117, ptr %l57
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb19, label %ok.119, !prof !99
ok.119:
  store %"std/os:Output" %t116, ptr %l56
  br label %bb18
bb18:
  %t120 = load %"std/os:Output", ptr %l56
  store %"std/os:Output" %t120, ptr %l53
  br label %bb21
bb19:
  %t121 = load i32, ptr %l57, !tbaa !23
  %t122 = ashr i32 %t121, 16
  %t124 = icmp eq i32 %t122, 1
  store i1 %t124, ptr %l59, !tbaa !21
  br label %bb20
bb20:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/bindgen:gen", ptr %t125, i32 0, i32 25
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d125, i32 0, i32 1) }, ptr %t127, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t129 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t129, ptr %rv
  br label %ret
bb21:
  %t130 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store ptr %t130, ptr %lp13
  %t131 = load %"std/os:Output", ptr %l53
  %t132 = load ptr, ptr %lp13
  store %"std/os:Output" %t131, ptr %t132
  %t133 = load ptr, ptr %lp13
  %t134 = getelementptr %"std/os:Output", ptr %t133, i32 0, i32 1
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t139 = icmp eq i64 %t137, 0
  br i1 %t139, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s11
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l65, !tbaa !29
  %t142 = load ptr, ptr %lp13
  %t143 = getelementptr %"std/os:Output", ptr %t142, i32 0, i32 2
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t146 = call { i64, ptr } @compiler_2fbindgen_2efirstError(ptr %v4, ptr %s11, { i64, ptr } %t144)
  store { i64, ptr } %t146, ptr %l67
  br label %bb24
bb23:
  br label %bb28
bb24:
  %t147 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = mul i64 %t148, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t150)
  call void @llvm.memcpy.p0.p0.i64(ptr %t151, ptr %t149, i64 %t150, i1 false)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  %t154 = load ptr, ptr %l65, !tbaa !29
  %t156 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s11, ptr %t154, { i64, ptr } %t153)
  store i32 %t156, ptr %l69
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb26, label %ok.158, !prof !99
ok.158:
  br label %bb25
bb25:
  br label %bb27
bb26:
  %t159 = load i32, ptr %l69, !tbaa !23
  %t160 = lshr i32 %t159, 16
  %t161 = and i32 %t159, 65535
  %t162 = icmp eq i32 %t160, 1
  %t163 = select i1 %t162, i32 1, i32 0
  %t164 = icmp eq i32 %t159, 0
  %t165 = shl i32 %t163, 16
  %t166 = or i32 %t165, %t161
  %t167 = select i1 %t164, i32 0, i32 %t166
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t169 = insertvalue { i32, ptr } zeroinitializer, i32 %t167, 0
  store { i32, ptr } %t169, ptr %rv
  br label %ret
bb27:
  call void @__olang_scope_close(ptr %s11)
  br label %bb28
bb28:
  %t170 = load ptr, ptr %lp13
  %t171 = getelementptr %"std/os:Output", ptr %t170, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  %t174 = call { i32, ptr } @std_2fjson_2eParse(ptr %v4, ptr %v4, { i64, ptr } %t172)
  %t175 = extractvalue { i32, ptr } %t174, 1
  %t176 = extractvalue { i32, ptr } %t174, 0
  store i32 %t176, ptr %l74
  %t177 = icmp ne i32 %t176, 0
  br i1 %t177, label %bb30, label %ok.178, !prof !99
ok.178:
  store ptr %t175, ptr %l73
  br label %bb29
bb29:
  %t179 = load ptr, ptr %l73, !tbaa !29
  store ptr %t179, ptr %l71, !tbaa !29
  br label %bb34
bb30:
  %t180 = load i32, ptr %l74, !tbaa !23
  %t181 = ashr i32 %t180, 16
  %t183 = icmp eq i32 %t181, 1
  store i1 %t183, ptr %l76, !tbaa !21
  %t184 = load i32, ptr %l74, !tbaa !23
  %t185 = ashr i32 %t184, 16
  %t187 = icmp eq i32 %t185, 1
  br i1 %t187, label %bb31, label %bb32
bb31:
  call void @__olang_errpay_pop()
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/bindgen:gen", ptr %t189, i32 0, i32 25
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d126, i32 0, i32 1) }, ptr %t191, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t193 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t193, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t194 = load ptr, ptr %l71, !tbaa !29
  %t195 = insertvalue { i32, ptr } zeroinitializer, ptr %t194, 1
  store { i32, ptr } %t195, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l9 = alloca %"compiler/bindgen:cMacro"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l33 = alloca i32
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l50 = alloca i32
  %l52 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i32
  %l60 = alloca i1
  %l64 = alloca %"compiler/bindgen:cMacro"
  %l66 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i1
  %l81 = alloca %"compiler/bindgen:cMacro"
  %l93 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l94 = alloca i32
  %l97 = alloca i64
  %l99 = alloca i64
  %l104 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca i32
  %l122 = alloca i1
  %l123 = alloca { i64, ptr }
  %l127 = alloca i1
  %l140 = alloca i32
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l151 = alloca { i64, ptr }
  %l155 = alloca i1
  %l159 = alloca i1
  %l165 = alloca i1
  %l166 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l172 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l188 = alloca i32
  %l191 = alloca i64
  %l193 = alloca i1
  %l195 = alloca i64
  %l197 = alloca ptr
  %l198 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l200 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l202 = alloca i64
  %l210 = alloca i32
  %l212 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l220 = alloca { i64, ptr }
  %l223 = alloca i64
  %l227 = alloca i64
  %l228 = alloca i32
  %l236 = alloca ptr
  %l239 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l241 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l243 = alloca { i64, ptr }
  %l247 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l248 = alloca i32
  %l251 = alloca i64
  %l253 = alloca i64
  %l258 = alloca { i64, ptr }
  %l272 = alloca ptr
  %l274 = alloca { i64, ptr }
  %l278 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l279 = alloca i32
  %l282 = alloca i64
  %l284 = alloca i64
  %l289 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l299 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  %t549 = alloca { { i64, ptr }, ptr }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 64
  br i1 %t3, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s1, ptr %t5, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d127, i32 0, i32 1) })
  store i32 %t7, ptr %l33
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb4, label %ok.9, !prof !99
ok.9:
  br label %bb3
bb2:
  br label %bb6
bb3:
  br label %bb5
bb4:
  %t10 = load i32, ptr %l33, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t20 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t18, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t20, ptr %rv
  br label %ret
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l35
  br label %bb7
bb7:
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t22, ptr %lp4
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  %t24 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %t24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp slt i64 %t25, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb179
bb10:
  br label %bb11
bb11:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr %l41, !tbaa !27
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %t39, i64 %t36
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !37
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t43, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) })
  store i1 %t45, ptr %l45
  br label %bb12
bb12:
  %t46 = load i1, ptr %l45, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb16
bb14:
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t47, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d129, i32 0, i32 1) })
  store i1 %t49, ptr %l48
  br label %bb15
bb15:
  %t50 = load i1, ptr %l48, !tbaa !21
  store i1 %t50, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l46, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s3, ptr %t52, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d130, i32 0, i32 1) })
  store i32 %t54, ptr %l50
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb20, label %ok.56, !prof !99
ok.56:
  br label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb21
bb20:
  %t57 = load i32, ptr %l50, !tbaa !23
  %t58 = lshr i32 %t57, 16
  %t59 = and i32 %t57, 65535
  %t60 = icmp eq i32 %t58, 1
  %t61 = select i1 %t60, i32 1, i32 0
  %t62 = icmp eq i32 %t57, 0
  %t63 = shl i32 %t61, 16
  %t64 = or i32 %t63, %t59
  %t65 = select i1 %t62, i32 0, i32 %t64
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t67 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t65, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t67, ptr %rv
  br label %ret
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/bindgen:gen", ptr %t68, i32 0, i32 13
  %t71 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t74 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t70, { i64, ptr } %t71)
  %t75 = extractvalue { i32, i64 } %t74, 1
  %t76 = extractvalue { i32, i64 } %t74, 0
  store i32 %t76, ptr %l57
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb24, label %ok.78, !prof !99
ok.78:
  store i64 %t75, ptr %l56
  br label %bb23
bb23:
  %t79 = load i64, ptr %l56, !tbaa !24
  store i64 %t79, ptr %l52, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  store i64 -1, ptr %l52, !tbaa !24
  br label %bb26
bb26:
  %t80 = load i64, ptr %l52, !tbaa !24
  store i64 %t80, ptr %l7, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = icmp slt i64 %t81, 0
  br i1 %t83, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb31
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/bindgen:gen", ptr %t85, i32 0, i32 12
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v0, ptr %t87, i64 %t88)
  store %"compiler/bindgen:cMacro" %t91, ptr %l64
  br label %bb29
bb29:
  %t92 = getelementptr %"compiler/bindgen:cMacro", ptr %l64, i32 0, i32 0
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t93, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d131, i32 0, i32 1) })
  store i1 %t95, ptr %l66
  br label %bb30
bb30:
  %t96 = load i1, ptr %l66, !tbaa !21
  store i1 %t96, ptr %l60, !tbaa !21
  br label %bb31
bb31:
  %t97 = load i1, ptr %l60, !tbaa !21
  br i1 %t97, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb35
bb33:
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t104 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v2, ptr %v1, ptr %t100, { i64, ptr } %t98)
  store i1 %t104, ptr %l71
  br label %bb34
bb34:
  %t105 = load i1, ptr %l71, !tbaa !21
  store i1 %t105, ptr %l67, !tbaa !21
  br label %bb35
bb35:
  %t106 = load i1, ptr %l67, !tbaa !21
  br i1 %t106, label %bb36, label %bb37
bb36:
  %t107 = load ptr, ptr %lp4
  %t108 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = extractvalue { i64, ptr } %t108, 0
  %t112 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t110, i64 %t111)
  %t113 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } %t114, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t107, { i64, ptr } %t121)
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb178
bb39:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/bindgen:gen", ptr %t128, i32 0, i32 12
  %t131 = load i64, ptr %l7, !tbaa !24
  %t134 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v0, ptr %t130, i64 %t131)
  store %"compiler/bindgen:cMacro" %t134, ptr %l81
  br label %bb40
bb40:
  %t135 = load %"compiler/bindgen:cMacro", ptr %l81
  store %"compiler/bindgen:cMacro" %t135, ptr %l9
  %t136 = getelementptr %"compiler/bindgen:cMacro", ptr %l9, i32 0, i32 1
  %t137 = load i1, ptr %t136, !tbaa !21
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load ptr, ptr %l2, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = extractvalue { i64, ptr } %t142, 0
  %t146 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t144, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } %t148, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t141, { i64, ptr } %t155)
  br label %bb43
bb42:
  br label %bb60
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/bindgen:cMacro", ptr %l9, i32 0, i32 3
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t162 = load i64, ptr %l3, !tbaa !24
  %t164 = add i64 %t162, 1
  %t169 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %v0, ptr %v2, ptr %s8, ptr %t158, { i64, ptr } %t160, ptr %t161, i64 %t164)
  %t170 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t169, 1
  %t171 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t169, 0
  store i32 %t171, ptr %l94
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb45, label %ok.173, !prof !99
ok.173:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l93
  br label %bb44
bb44:
  %t174 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93
  %t175 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t174, ptr %t175
  store ptr %t175, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb46
bb45:
  %t177 = load i32, ptr %l94, !tbaa !23
  %t178 = lshr i32 %t177, 16
  %t179 = and i32 %t177, 65535
  %t180 = icmp eq i32 %t178, 1
  %t181 = select i1 %t180, i32 1, i32 0
  %t182 = icmp eq i32 %t177, 0
  %t183 = shl i32 %t181, 16
  %t184 = or i32 %t183, %t179
  %t185 = select i1 %t182, i32 0, i32 %t184
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t187 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t185, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t187, ptr %rv
  br label %ret
bb46:
  %t188 = load i64, ptr %l11, !tbaa !24
  store i64 %t188, ptr %l97, !tbaa !24
  %t189 = load ptr, ptr %l10, !tbaa !29
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s8, ptr %t189)
  store i64 %t191, ptr %l99
  br label %bb47
bb47:
  %t192 = load i64, ptr %l97, !tbaa !24
  %t193 = load i64, ptr %l99, !tbaa !24
  %t194 = icmp slt i64 %t192, %t193
  %t196 = xor i1 %t194, true
  br i1 %t196, label %bb48, label %bb49
bb48:
  br label %bb54
bb49:
  br label %bb50
bb50:
  %t198 = load ptr, ptr %l10, !tbaa !29
  %t199 = load i64, ptr %l11, !tbaa !24
  %t202 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s8, ptr %s8, ptr %t198, i64 %t199)
  store { i64, ptr } %t202, ptr %l104
  br label %bb51
bb51:
  %t203 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t204 = load ptr, ptr %lp4
  %t207 = extractvalue { i64, ptr } %t203, 1
  %t208 = extractvalue { i64, ptr } %t203, 0
  %t209 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t207, i64 %t208)
  %t210 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = extractvalue { i64, ptr } %t211, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t204, { i64, ptr } %t218)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t221 = load i64, ptr %l11, !tbaa !24
  %t223 = add i64 %t221, 1
  store i64 %t223, ptr %l11, !tbaa !24
  br label %bb46
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  %t225 = load ptr, ptr %l2, !tbaa !29
  %t227 = call { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Hdc04e7543082eec80486670259c0789b(ptr %v2, ptr %s6, ptr %t225)
  %t228 = extractvalue { i32, { i64, ptr } } %t227, 1
  %t229 = extractvalue { i32, { i64, ptr } } %t227, 0
  store i32 %t229, ptr %l114
  %t230 = icmp ne i32 %t229, 0
  br i1 %t230, label %bb57, label %ok.231, !prof !99
ok.231:
  store { i64, ptr } %t228, ptr %l113
  br label %bb56
bb56:
  %t232 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t232, ptr %l111, !tbaa !27
  br label %bb59
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t233 = load i64, ptr %l5, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  br label %bb178
bb60:
  %t237 = load i64, ptr %l5, !tbaa !24
  %t239 = add i64 %t237, 1
  %t240 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t245 = icmp sge i64 %t239, %t242
  br i1 %t245, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb64
bb62:
  %t247 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t247, ptr %l123, !tbaa !27
  %t248 = load i64, ptr %l5, !tbaa !24
  %t250 = add i64 %t248, 1
  %t252 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr { i64, ptr }, ptr %t253, i64 %t250
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !37
  %t257 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t255, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d132, i32 0, i32 1) })
  store i1 %t257, ptr %l127
  br label %bb63
bb63:
  %t258 = load i1, ptr %l127, !tbaa !21
  %t259 = xor i1 %t258, true
  store i1 %t259, ptr %l122, !tbaa !21
  br label %bb64
bb64:
  %t261 = load i1, ptr %l122, !tbaa !21
  br i1 %t261, label %bb65, label %bb66
bb65:
  %t262 = load ptr, ptr %lp4
  %t263 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t263, 1
  %t266 = extractvalue { i64, ptr } %t263, 0
  %t267 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t266)
  call void @olang_textcopy(ptr %t267, ptr %t265, i64 %t266)
  %t268 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t272 = extractvalue { i64, ptr } %t269, 1
  %t273 = mul i64 %t271, 1
  %t274 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t273)
  call void @llvm.memcpy.p0.p0.i64(ptr %t274, ptr %t272, i64 %t273, i1 false)
  %t275 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t262, { i64, ptr } %t276)
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t279 = load i64, ptr %l5, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb178
bb68:
  %t283 = getelementptr %"compiler/bindgen:cMacro", ptr %l9, i32 0, i32 5
  %t284 = load i1, ptr %t283, !tbaa !21
  br i1 %t284, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s15
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t288 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t289 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t291 = extractvalue { i64, ptr } %t287, 1
  %t292 = extractvalue { i64, ptr } %t287, 0
  %t293 = add i64 %t289, %t292
  %t294 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t296 = add i64 %t293, %t295
  %t297 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t296)
  call void @olang_textcopy(ptr %t297, ptr %t288, i64 %t289)
  %t298 = getelementptr i8, ptr %t297, i64 %t289
  call void @olang_textcopy(ptr %t298, ptr %t291, i64 %t292)
  %t299 = getelementptr i8, ptr %t298, i64 %t292
  call void @olang_textcopy(ptr %t299, ptr %t294, i64 %t295)
  %t300 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t297, 1
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t304 = extractvalue { i64, ptr } %t301, 1
  %t305 = mul i64 %t303, 1
  %t306 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t305)
  call void @llvm.memcpy.p0.p0.i64(ptr %t306, ptr %t304, i64 %t305, i1 false)
  %t307 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  %t311 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s15, ptr %t286, { i64, ptr } %t308)
  store i32 %t311, ptr %l140
  %t312 = icmp ne i32 %t311, 0
  br i1 %t312, label %bb72, label %ok.313, !prof !99
ok.313:
  br label %bb71
bb70:
  br label %bb74
bb71:
  br label %bb73
bb72:
  %t314 = load i32, ptr %l140, !tbaa !23
  %t315 = lshr i32 %t314, 16
  %t316 = and i32 %t314, 65535
  %t317 = icmp eq i32 %t315, 1
  %t318 = select i1 %t317, i32 1, i32 0
  %t319 = icmp eq i32 %t314, 0
  %t320 = shl i32 %t318, 16
  %t321 = or i32 %t320, %t316
  %t322 = select i1 %t319, i32 0, i32 %t321
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t324 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t322, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t324, ptr %rv
  br label %ret
bb73:
  call void @__olang_scope_close(ptr %s15)
  br label %bb74
bb74:
  %t325 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t325, ptr %l142
  br label %bb75
bb75:
  %t326 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t326, ptr %l13
  %t327 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t327, ptr %l143
  br label %bb76
bb76:
  %t328 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l143
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t328, ptr %l14
  store i64 0, ptr %l15, !tbaa !24
  %t329 = load i64, ptr %l5, !tbaa !24
  %t331 = add i64 %t329, 2
  store i64 %t331, ptr %l16, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s17
  %t333 = load i64, ptr %l16, !tbaa !24
  %t334 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t334, 0
  %t339 = icmp slt i64 %t333, %t336
  %t341 = xor i1 %t339, true
  br i1 %t341, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s17)
  br label %bb104
bb79:
  br label %bb80
bb80:
  %t343 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t343, ptr %l151, !tbaa !27
  %t344 = load i64, ptr %l16, !tbaa !24
  %t346 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %t347, i64 %t344
  %t349 = load { i64, ptr }, ptr %t348, !tbaa !37
  store { i64, ptr } %t349, ptr %l17, !tbaa !27
  %t351 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t353 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s17, { i64, ptr } %t351, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) })
  store i1 %t353, ptr %l155
  br label %bb81
bb81:
  %t354 = load i1, ptr %l155, !tbaa !21
  br i1 %t354, label %bb82, label %bb83
bb82:
  %t355 = load i64, ptr %l15, !tbaa !24
  %t357 = add i64 %t355, 1
  store i64 %t357, ptr %l15, !tbaa !24
  br label %bb84
bb83:
  br label %bb84
bb84:
  %t359 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t361 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s17, { i64, ptr } %t359, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) })
  store i1 %t361, ptr %l159
  br label %bb85
bb85:
  %t362 = load i1, ptr %l159, !tbaa !21
  br i1 %t362, label %bb86, label %bb87
bb86:
  %t363 = load i64, ptr %l15, !tbaa !24
  %t365 = icmp eq i64 %t363, 0
  br i1 %t365, label %bb88, label %bb89
bb87:
  br label %bb91
bb88:
  call void @__olang_scope_close(ptr %s17)
  br label %bb104
bb89:
  br label %bb90
bb90:
  %t367 = load i64, ptr %l15, !tbaa !24
  %t369 = sub i64 %t367, 1
  store i64 %t369, ptr %l15, !tbaa !24
  br label %bb91
bb91:
  %t371 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t373 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s17, { i64, ptr } %t371, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) })
  store i1 %t373, ptr %l165
  br label %bb92
bb92:
  %t374 = load i1, ptr %l165, !tbaa !21
  br i1 %t374, label %bb93, label %bb94
bb93:
  %t375 = load i64, ptr %l15, !tbaa !24
  %t377 = icmp eq i64 %t375, 0
  store i1 %t377, ptr %l166, !tbaa !21
  br label %bb95
bb94:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb95
bb95:
  %t379 = load i1, ptr %l166, !tbaa !21
  br i1 %t379, label %bb96, label %bb97
bb96:
  store ptr %l13, ptr %l169, !tbaa !29
  %t380 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t380, ptr %l170
  %t382 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s2, ptr %l170)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t382, ptr %l172
  br label %bb98
bb97:
  %t383 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t385 = extractvalue { i64, ptr } %t383, 1
  %t386 = extractvalue { i64, ptr } %t383, 0
  %t387 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t386)
  call void @olang_textcopy(ptr %t387, ptr %t385, i64 %t386)
  %t388 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t387, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = extractvalue { i64, ptr } %t389, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l14, { i64, ptr } %t396)
  br label %bb101
bb98:
  %t399 = load ptr, ptr %l169, !tbaa !29
  %t400 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l172
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H40771be639b3022d183b79789a9eab56(ptr %s2, ptr %s2, ptr %t399, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t400)
  br label %bb99
bb99:
  %t401 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t401, ptr %l173
  br label %bb100
bb100:
  %t402 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t402, ptr %l14
  br label %bb102
bb101:
  br label %bb102
bb102:
  %t403 = load i64, ptr %l16, !tbaa !24
  %t405 = add i64 %t403, 1
  store i64 %t405, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb103
bb103:
  br label %bb77
bb104:
  %t407 = load i64, ptr %l16, !tbaa !24
  %t408 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t413 = icmp sge i64 %t407, %t410
  br i1 %t413, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s24
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t417 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t420 = extractvalue { i64, ptr } %t416, 1
  %t421 = extractvalue { i64, ptr } %t416, 0
  %t422 = add i64 %t418, %t421
  %t423 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t424 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t425 = add i64 %t422, %t424
  %t426 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t425)
  call void @olang_textcopy(ptr %t426, ptr %t417, i64 %t418)
  %t427 = getelementptr i8, ptr %t426, i64 %t418
  call void @olang_textcopy(ptr %t427, ptr %t420, i64 %t421)
  %t428 = getelementptr i8, ptr %t427, i64 %t421
  call void @olang_textcopy(ptr %t428, ptr %t423, i64 %t424)
  %t429 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t426, 1
  %t432 = extractvalue { i64, ptr } %t430, 0
  %t433 = extractvalue { i64, ptr } %t430, 1
  %t434 = mul i64 %t432, 1
  %t435 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t434)
  call void @llvm.memcpy.p0.p0.i64(ptr %t435, ptr %t433, i64 %t434, i1 false)
  %t436 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  %t440 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s24, ptr %t415, { i64, ptr } %t437)
  store i32 %t440, ptr %l188
  %t441 = icmp ne i32 %t440, 0
  br i1 %t441, label %bb108, label %ok.442, !prof !99
ok.442:
  br label %bb107
bb106:
  br label %bb110
bb107:
  br label %bb109
bb108:
  %t443 = load i32, ptr %l188, !tbaa !23
  %t444 = lshr i32 %t443, 16
  %t445 = and i32 %t443, 65535
  %t446 = icmp eq i32 %t444, 1
  %t447 = select i1 %t446, i32 1, i32 0
  %t448 = icmp eq i32 %t443, 0
  %t449 = shl i32 %t447, 16
  %t450 = or i32 %t449, %t445
  %t451 = select i1 %t448, i32 0, i32 %t450
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t453 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t451, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t453, ptr %rv
  br label %ret
bb109:
  call void @__olang_scope_close(ptr %s24)
  br label %bb110
bb110:
  %t455 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l14)
  store i64 %t455, ptr %l191
  br label %bb111
bb111:
  %t456 = load i64, ptr %l191, !tbaa !24
  %t457 = icmp sgt i64 %t456, 0
  br i1 %t457, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb115
bb113:
  %t460 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Hbb0b9cf8ae0bb786ffc6cf28ae45ef64(ptr %s2, ptr %l13)
  store i64 %t460, ptr %l195
  br label %bb114
bb114:
  %t461 = load i64, ptr %l195, !tbaa !24
  %t462 = icmp sgt i64 %t461, 0
  store i1 %t462, ptr %l193, !tbaa !21
  br label %bb115
bb115:
  %t464 = load i1, ptr %l193, !tbaa !21
  br i1 %t464, label %bb116, label %bb117
bb116:
  store ptr %l13, ptr %l197, !tbaa !29
  %t465 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t465, ptr %l198
  %t467 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s2, ptr %l198)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t467, ptr %l200
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t468 = load ptr, ptr %l197, !tbaa !29
  %t469 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l200
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H40771be639b3022d183b79789a9eab56(ptr %s2, ptr %s2, ptr %t468, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t469)
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t471 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Hbb0b9cf8ae0bb786ffc6cf28ae45ef64(ptr %s2, ptr %l13)
  store i64 %t471, ptr %l202
  br label %bb121
bb121:
  %t472 = getelementptr %"compiler/bindgen:cMacro", ptr %l9, i32 0, i32 2
  %t473 = load { i64, ptr }, ptr %t472, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t473, 0
  %t476 = load i64, ptr %l202, !tbaa !24
  %t478 = icmp ne i64 %t476, %t475
  br i1 %t478, label %bb122, label %bb123
bb122:
  store %olang.scope zeroinitializer, ptr %s27
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t482 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t483 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t485 = extractvalue { i64, ptr } %t481, 1
  %t486 = extractvalue { i64, ptr } %t481, 0
  %t487 = add i64 %t483, %t486
  %t488 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t489 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t490 = add i64 %t487, %t489
  %t491 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t490)
  call void @olang_textcopy(ptr %t491, ptr %t482, i64 %t483)
  %t492 = getelementptr i8, ptr %t491, i64 %t483
  call void @olang_textcopy(ptr %t492, ptr %t485, i64 %t486)
  %t493 = getelementptr i8, ptr %t492, i64 %t486
  call void @olang_textcopy(ptr %t493, ptr %t488, i64 %t489)
  %t494 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t491, 1
  %t497 = extractvalue { i64, ptr } %t495, 0
  %t498 = extractvalue { i64, ptr } %t495, 1
  %t499 = mul i64 %t497, 1
  %t500 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t499)
  call void @llvm.memcpy.p0.p0.i64(ptr %t500, ptr %t498, i64 %t499, i1 false)
  %t501 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t500, 1
  %t505 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s27, ptr %t480, { i64, ptr } %t502)
  store i32 %t505, ptr %l210
  %t506 = icmp ne i32 %t505, 0
  br i1 %t506, label %bb125, label %ok.507, !prof !99
ok.507:
  br label %bb124
bb123:
  br label %bb127
bb124:
  br label %bb126
bb125:
  %t508 = load i32, ptr %l210, !tbaa !23
  %t509 = lshr i32 %t508, 16
  %t510 = and i32 %t508, 65535
  %t511 = icmp eq i32 %t509, 1
  %t512 = select i1 %t511, i32 1, i32 0
  %t513 = icmp eq i32 %t508, 0
  %t514 = shl i32 %t512, 16
  %t515 = or i32 %t514, %t510
  %t516 = select i1 %t513, i32 0, i32 %t515
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t518 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t516, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t518, ptr %rv
  br label %ret
bb126:
  call void @__olang_scope_close(ptr %s27)
  br label %bb127
bb127:
  %t519 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t519, ptr %l212
  br label %bb128
bb128:
  %t520 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l212
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t520, ptr %l18
  %t521 = getelementptr %"compiler/bindgen:cMacro", ptr %l9, i32 0, i32 3
  %t522 = load { i64, ptr }, ptr %t521, !tbaa !27
  store { i64, ptr } %t522, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t524 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t526 = extractvalue { i64, ptr } %t524, 0
  store i64 %t526, ptr %l21, !tbaa !24
  br label %bb129
bb129:
  store %olang.scope zeroinitializer, ptr %s30
  %t528 = load i64, ptr %l20, !tbaa !24
  %t529 = load i64, ptr %l21, !tbaa !24
  %t532 = icmp slt i64 %t528, %t529
  %t534 = xor i1 %t532, true
  br i1 %t534, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s30)
  br label %bb159
bb131:
  br label %bb132
bb132:
  %t536 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t536, ptr %l220, !tbaa !27
  %t537 = load i64, ptr %l20, !tbaa !24
  %t539 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t540 = load ptr, ptr %t539, !tbaa !27
  %t541 = getelementptr { i64, ptr }, ptr %t540, i64 %t537
  %t542 = load { i64, ptr }, ptr %t541, !tbaa !37
  store { i64, ptr } %t542, ptr %l22, !tbaa !27
  %t544 = getelementptr %"compiler/bindgen:cMacro", ptr %l9, i32 0, i32 2
  %t545 = load { i64, ptr }, ptr %t544, !tbaa !27
  %t546 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t547 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t548 = ptrtoint ptr %t547 to i64
  %t550 = getelementptr { { i64, ptr }, ptr }, ptr %t549, i32 0, i32 0
  store { i64, ptr } %t546, ptr %t550, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t552 = getelementptr { { i64, ptr }, ptr }, ptr %t549, i32 0, i32 1
  store ptr %v0, ptr %t552, !tbaa !28
  %t553 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_142, 0
  %t554 = insertvalue { ptr, ptr } %t553, ptr %t549, 1
  %t557 = extractvalue { ptr, ptr } %t554, 0
  %t558 = extractvalue { ptr, ptr } %t554, 1
  %t559 = call { i32, i64 } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eFindIndex_3cstd_2f_H0cdaf28864c9da4990596b1986b376a0(ptr %v0, ptr %s30, { i64, ptr } %t545, ptr %t557, ptr %t558)
  %t560 = extractvalue { i32, i64 } %t559, 1
  %t561 = extractvalue { i32, i64 } %t559, 0
  store i32 %t561, ptr %l228
  %t562 = icmp ne i32 %t561, 0
  br i1 %t562, label %bb134, label %ok.563, !prof !99
ok.563:
  store i64 %t560, ptr %l227
  br label %bb133
bb133:
  %t564 = load i64, ptr %l227, !tbaa !24
  store i64 %t564, ptr %l223, !tbaa !24
  br label %bb136
bb134:
  br label %bb135
bb135:
  store i64 -1, ptr %l223, !tbaa !24
  br label %bb136
bb136:
  %t565 = load i64, ptr %l223, !tbaa !24
  store i64 %t565, ptr %l23, !tbaa !24
  %t566 = load i64, ptr %l23, !tbaa !24
  %t568 = icmp slt i64 %t566, 0
  br i1 %t568, label %bb137, label %bb138
bb137:
  %t570 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t570, 1
  %t573 = extractvalue { i64, ptr } %t570, 0
  %t574 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t573)
  call void @olang_textcopy(ptr %t574, ptr %t572, i64 %t573)
  %t575 = insertvalue { i64, ptr } undef, i64 %t573, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t574, 1
  %t578 = extractvalue { i64, ptr } %t576, 0
  %t579 = extractvalue { i64, ptr } %t576, 1
  %t580 = mul i64 %t578, 1
  %t581 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t580)
  call void @llvm.memcpy.p0.p0.i64(ptr %t581, ptr %t579, i64 %t580, i1 false)
  %t582 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t583 = insertvalue { i64, ptr } %t582, ptr %t581, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l18, { i64, ptr } %t583)
  br label %bb139
bb138:
  br label %bb140
bb139:
  call void @__olang_scope_close(ptr %s30)
  br label %bb158
bb140:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l18, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) })
  br label %bb141
bb141:
  store %olang.scope zeroinitializer, ptr %s33
  %t587 = load ptr, ptr %l0, !tbaa !29
  store ptr %t587, ptr %l236, !tbaa !29
  %t588 = load i64, ptr %l23, !tbaa !24
  %t591 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H21d8db2bdfeb46fab755f8173a35f95e(ptr %s2, ptr %s2, ptr %l13, i64 %t588)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t591, ptr %l239
  br label %bb142
bb142:
  %t593 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s2, ptr %l239)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t593, ptr %l241
  br label %bb143
bb143:
  %t594 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l241
  %t595 = call ptr @__olang_scope_alloc_a(ptr %s33, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t594, ptr %t595
  %t597 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s2, ptr %s33, ptr %t595)
  store { i64, ptr } %t597, ptr %l243
  br label %bb144
bb144:
  %t598 = load ptr, ptr %l2, !tbaa !29
  %t599 = load i64, ptr %l3, !tbaa !24
  %t601 = add i64 %t599, 1
  %t602 = load ptr, ptr %l236, !tbaa !29
  %t603 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t606 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %s33, ptr %v2, ptr %s33, ptr %t602, { i64, ptr } %t603, ptr %t598, i64 %t601)
  %t607 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t606, 1
  %t608 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t606, 0
  store i32 %t608, ptr %l248
  %t609 = icmp ne i32 %t608, 0
  br i1 %t609, label %bb146, label %ok.610, !prof !99
ok.610:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t607, ptr %l247
  br label %bb145
bb145:
  %t611 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l247
  %t612 = call ptr @__olang_scope_alloc_a(ptr %s33, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t611, ptr %t612
  store ptr %t612, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb147
bb146:
  %t614 = load i32, ptr %l248, !tbaa !23
  %t615 = lshr i32 %t614, 16
  %t616 = and i32 %t614, 65535
  %t617 = icmp eq i32 %t615, 1
  %t618 = select i1 %t617, i32 1, i32 0
  %t619 = icmp eq i32 %t614, 0
  %t620 = shl i32 %t618, 16
  %t621 = or i32 %t620, %t616
  %t622 = select i1 %t619, i32 0, i32 %t621
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t624 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t622, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t624, ptr %rv
  br label %ret
bb147:
  %t625 = load i64, ptr %l25, !tbaa !24
  store i64 %t625, ptr %l251, !tbaa !24
  %t626 = load ptr, ptr %l24, !tbaa !29
  %t628 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s33, ptr %t626)
  store i64 %t628, ptr %l253
  br label %bb148
bb148:
  %t629 = load i64, ptr %l251, !tbaa !24
  %t630 = load i64, ptr %l253, !tbaa !24
  %t631 = icmp slt i64 %t629, %t630
  %t633 = xor i1 %t631, true
  br i1 %t633, label %bb149, label %bb150
bb149:
  br label %bb155
bb150:
  br label %bb151
bb151:
  %t635 = load ptr, ptr %l24, !tbaa !29
  %t636 = load i64, ptr %l25, !tbaa !24
  %t639 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s33, ptr %s33, ptr %t635, i64 %t636)
  store { i64, ptr } %t639, ptr %l258
  br label %bb152
bb152:
  %t640 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t643 = extractvalue { i64, ptr } %t640, 1
  %t644 = extractvalue { i64, ptr } %t640, 0
  %t645 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t644)
  call void @olang_textcopy(ptr %t645, ptr %t643, i64 %t644)
  %t646 = insertvalue { i64, ptr } undef, i64 %t644, 0
  %t647 = insertvalue { i64, ptr } %t646, ptr %t645, 1
  %t649 = extractvalue { i64, ptr } %t647, 0
  %t650 = extractvalue { i64, ptr } %t647, 1
  %t651 = mul i64 %t649, 1
  %t652 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t651)
  call void @llvm.memcpy.p0.p0.i64(ptr %t652, ptr %t650, i64 %t651, i1 false)
  %t653 = insertvalue { i64, ptr } undef, i64 %t649, 0
  %t654 = insertvalue { i64, ptr } %t653, ptr %t652, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l18, { i64, ptr } %t654)
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t657 = load i64, ptr %l25, !tbaa !24
  %t659 = add i64 %t657, 1
  store i64 %t659, ptr %l25, !tbaa !24
  br label %bb147
bb155:
  call void @__olang_scope_close(ptr %s33)
  br label %bb156
bb156:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l18, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) })
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s30)
  br label %bb158
bb158:
  %t662 = load i64, ptr %l20, !tbaa !24
  %t664 = add i64 %t662, 1
  store i64 %t664, ptr %l20, !tbaa !24
  br label %bb129
bb159:
  %t666 = load ptr, ptr %l2, !tbaa !29
  %t667 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t669 = extractvalue { i64, ptr } %t667, 1
  %t670 = extractvalue { i64, ptr } %t667, 0
  %t671 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t670)
  call void @olang_textcopy(ptr %t671, ptr %t669, i64 %t670)
  %t672 = insertvalue { i64, ptr } undef, i64 %t670, 0
  %t673 = insertvalue { i64, ptr } %t672, ptr %t671, 1
  %t675 = extractvalue { i64, ptr } %t673, 0
  %t676 = extractvalue { i64, ptr } %t673, 1
  %t677 = mul i64 %t675, 1
  %t678 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t677)
  call void @llvm.memcpy.p0.p0.i64(ptr %t678, ptr %t676, i64 %t677, i1 false)
  %t679 = insertvalue { i64, ptr } undef, i64 %t675, 0
  %t680 = insertvalue { i64, ptr } %t679, ptr %t678, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t666, { i64, ptr } %t680)
  br label %bb160
bb160:
  store %olang.scope zeroinitializer, ptr %s39
  %t683 = load ptr, ptr %l0, !tbaa !29
  store ptr %t683, ptr %l272, !tbaa !29
  %t685 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s2, ptr %s2, ptr %l18)
  store { i64, ptr } %t685, ptr %l274
  br label %bb161
bb161:
  %t686 = load ptr, ptr %l2, !tbaa !29
  %t687 = load i64, ptr %l3, !tbaa !24
  %t689 = add i64 %t687, 1
  %t690 = load ptr, ptr %l272, !tbaa !29
  %t691 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t694 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %s2, ptr %v2, ptr %s39, ptr %t690, { i64, ptr } %t691, ptr %t686, i64 %t689)
  %t695 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t694, 1
  %t696 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t694, 0
  store i32 %t696, ptr %l279
  %t697 = icmp ne i32 %t696, 0
  br i1 %t697, label %bb163, label %ok.698, !prof !99
ok.698:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t695, ptr %l278
  br label %bb162
bb162:
  %t699 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l278
  %t700 = call ptr @__olang_scope_alloc_a(ptr %s39, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t699, ptr %t700
  store ptr %t700, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb164
bb163:
  %t702 = load i32, ptr %l279, !tbaa !23
  %t703 = lshr i32 %t702, 16
  %t704 = and i32 %t702, 65535
  %t705 = icmp eq i32 %t703, 1
  %t706 = select i1 %t705, i32 1, i32 0
  %t707 = icmp eq i32 %t702, 0
  %t708 = shl i32 %t706, 16
  %t709 = or i32 %t708, %t704
  %t710 = select i1 %t707, i32 0, i32 %t709
  call void @__olang_scope_close(ptr %s39)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t712 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t710, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t712, ptr %rv
  br label %ret
bb164:
  %t713 = load i64, ptr %l28, !tbaa !24
  store i64 %t713, ptr %l282, !tbaa !24
  %t714 = load ptr, ptr %l27, !tbaa !29
  %t716 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s39, ptr %t714)
  store i64 %t716, ptr %l284
  br label %bb165
bb165:
  %t717 = load i64, ptr %l282, !tbaa !24
  %t718 = load i64, ptr %l284, !tbaa !24
  %t719 = icmp slt i64 %t717, %t718
  %t721 = xor i1 %t719, true
  br i1 %t721, label %bb166, label %bb167
bb166:
  br label %bb172
bb167:
  br label %bb168
bb168:
  %t723 = load ptr, ptr %l27, !tbaa !29
  %t724 = load i64, ptr %l28, !tbaa !24
  %t727 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s39, ptr %s39, ptr %t723, i64 %t724)
  store { i64, ptr } %t727, ptr %l289
  br label %bb169
bb169:
  %t728 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t729 = load ptr, ptr %lp4
  %t732 = extractvalue { i64, ptr } %t728, 1
  %t733 = extractvalue { i64, ptr } %t728, 0
  %t734 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t733)
  call void @olang_textcopy(ptr %t734, ptr %t732, i64 %t733)
  %t735 = insertvalue { i64, ptr } undef, i64 %t733, 0
  %t736 = insertvalue { i64, ptr } %t735, ptr %t734, 1
  %t738 = extractvalue { i64, ptr } %t736, 0
  %t739 = extractvalue { i64, ptr } %t736, 1
  %t740 = mul i64 %t738, 1
  %t741 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t740)
  call void @llvm.memcpy.p0.p0.i64(ptr %t741, ptr %t739, i64 %t740, i1 false)
  %t742 = insertvalue { i64, ptr } undef, i64 %t738, 0
  %t743 = insertvalue { i64, ptr } %t742, ptr %t741, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t729, { i64, ptr } %t743)
  br label %bb170
bb170:
  br label %bb171
bb171:
  %t746 = load i64, ptr %l28, !tbaa !24
  %t748 = add i64 %t746, 1
  store i64 %t748, ptr %l28, !tbaa !24
  br label %bb164
bb172:
  call void @__olang_scope_close(ptr %s39)
  br label %bb173
bb173:
  %t750 = load ptr, ptr %l2, !tbaa !29
  %t752 = call { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Hdc04e7543082eec80486670259c0789b(ptr %v2, ptr %s2, ptr %t750)
  %t753 = extractvalue { i32, { i64, ptr } } %t752, 1
  %t754 = extractvalue { i32, { i64, ptr } } %t752, 0
  store i32 %t754, ptr %l299
  %t755 = icmp ne i32 %t754, 0
  br i1 %t755, label %bb175, label %ok.756, !prof !99
ok.756:
  store { i64, ptr } %t753, ptr %l298
  br label %bb174
bb174:
  %t757 = load { i64, ptr }, ptr %l298, !tbaa !27
  store { i64, ptr } %t757, ptr %l296, !tbaa !27
  br label %bb177
bb175:
  br label %bb176
bb176:
  br label %bb177
bb177:
  %t758 = load i64, ptr %l16, !tbaa !24
  %t760 = add i64 %t758, 1
  store i64 %t760, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb178
bb178:
  br label %bb8
bb179:
  %t762 = load ptr, ptr %lp4
  %t763 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t762
  call void @__olang_scope_close(ptr %s0)
  %t765 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t763, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t765, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/bindgen:ctype"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/bindgen:ctype"
  %l6 = alloca i64
  %l10 = alloca %"compiler/bindgen:ctype"
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i32
  %l37 = alloca { i64, ptr }
  %l43 = alloca %"compiler/bindgen:ctype"
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l55 = alloca i64
  %l58 = alloca i1
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l72 = alloca i32
  %l75 = alloca i32
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 16
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/bindgen:ctype" %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l10
  store %"compiler/bindgen:ctype" %t8, ptr %l2
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 0
  %t10 = load i32, ptr %t9, !range !{i32 0, i32 7}
  store i32 %t10, ptr %l3
  %t12 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb9
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d145, i32 0, i32 1) })
  store i1 %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d146, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l16, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l21, !tbaa !24
  %t35 = load i64, ptr %l21, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l22, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l21, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t46, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t47 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t48 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t47, 1
  store { i32, { i64, ptr } } %t48, ptr %rv
  br label %ret
bb9:
  %t49 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t51 = trunc i64 2 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t59 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t54, { i64, ptr } %t56)
  store i64 %t59, ptr %l27
  br label %bb13
bb13:
  %t60 = load i64, ptr %l27, !tbaa !24
  store i64 %t60, ptr %l4, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t61, i64 %t62)
  store i1 %t65, ptr %l30
  br label %bb14
bb14:
  %t66 = load i1, ptr %l30, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s4, ptr %t69, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d147, i32 0, i32 1) })
  store i32 %t71, ptr %l33
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb18, label %ok.73, !prof !99
ok.73:
  br label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb19
bb18:
  %t74 = load i32, ptr %l33, !tbaa !23
  %t75 = lshr i32 %t74, 16
  %t76 = and i32 %t74, 65535
  %t77 = icmp eq i32 %t75, 1
  %t78 = select i1 %t77, i32 1, i32 0
  %t79 = icmp eq i32 %t74, 0
  %t80 = shl i32 %t78, 16
  %t81 = or i32 %t80, %t76
  %t82 = select i1 %t79, i32 0, i32 %t81
  call void @__olang_scope_close(ptr %s4)
  %t84 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t82, 0
  store { i32, { i64, ptr } } %t84, ptr %rv
  br label %ret
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l4, !tbaa !24
  %t89 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %v1, ptr %t85, i64 %t86)
  store { i64, ptr } %t89, ptr %l37
  br label %bb21
bb21:
  %t90 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
bb22:
  %t92 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t94 = trunc i64 3 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb40
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/bindgen:gen", ptr %t97, i32 0, i32 16
  %t100 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  %t104 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t99, i64 %t101)
  store %"compiler/bindgen:ctype" %t104, ptr %l43
  br label %bb26
bb26:
  %t105 = load %"compiler/bindgen:ctype", ptr %l43
  store %"compiler/bindgen:ctype" %t105, ptr %l5
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t108 = load i64, ptr %t107, !tbaa !24
  %t111 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisByte(ptr %v0, ptr %t106, i64 %t108)
  store i1 %t111, ptr %l46
  br label %bb27
bb27:
  %t112 = load i1, ptr %l46, !tbaa !21
  br i1 %t112, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d148, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t113, ptr %l48, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l49, !tbaa !24
  %t116 = load i64, ptr %l49, !tbaa !24
  %t117 = mul i64 %t116, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t117)
  %t119 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  store { i64, ptr } %t120, ptr %l50, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l49, !tbaa !24
  %t126 = mul i64 %t125, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t122, ptr %t124, i64 %t126, i1 false)
  %t127 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t127, ptr %l48, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t129 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t128, 1
  store { i32, { i64, ptr } } %t129, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t130 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t131 = load i32, ptr %t130, !range !{i32 0, i32 7}
  %t133 = trunc i64 2 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb31, label %bb32
bb31:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t141 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t136, { i64, ptr } %t138)
  store i64 %t141, ptr %l55
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t142 = load i64, ptr %l55, !tbaa !24
  store i64 %t142, ptr %l6, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i64, ptr %l6, !tbaa !24
  %t147 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t143, i64 %t144)
  store i1 %t147, ptr %l58
  br label %bb34
bb34:
  %t148 = load i1, ptr %l58, !tbaa !21
  %t149 = xor i1 %t148, true
  br i1 %t149, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l6, !tbaa !24
  %t155 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s8, ptr %t151, i64 %t152)
  store { i64, ptr } %t155, ptr %l62
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t156 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t157, i64 %t158)
  %t163 = getelementptr i8, ptr %t162, i64 %t158
  call void @olang_textcopy(ptr %t163, ptr %t159, i64 %t160)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t162, 1
  call void @__olang_scope_close(ptr %s8)
  %t167 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t165, 1
  store { i32, { i64, ptr } } %t167, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d150, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t168 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t168, ptr %l65, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 0
  store i64 %t170, ptr %l66, !tbaa !24
  %t171 = load i64, ptr %l66, !tbaa !24
  %t172 = mul i64 %t171, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t172)
  %t174 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  store { i64, ptr } %t175, ptr %l67, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = load i64, ptr %l66, !tbaa !24
  %t181 = mul i64 %t180, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t177, ptr %t179, i64 %t181, i1 false)
  %t182 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t182, ptr %l65, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t184 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t183, 1
  store { i32, { i64, ptr } } %t184, ptr %rv
  br label %ret
bb40:
  %t185 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t187 = trunc i64 6 to i32
  %t188 = icmp eq i32 %t185, %t187
  br i1 %t188, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb47
bb43:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  %t195 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t190, { i64, ptr } %t192)
  store i32 %t195, ptr %l72
  %t196 = icmp ne i32 %t195, 0
  br i1 %t196, label %bb45, label %ok.197, !prof !99
ok.197:
  br label %bb44
bb44:
  br label %bb46
bb45:
  %t198 = load i32, ptr %l72, !tbaa !23
  %t199 = lshr i32 %t198, 16
  %t200 = and i32 %t198, 65535
  %t201 = icmp eq i32 %t199, 1
  %t202 = select i1 %t201, i32 1, i32 0
  %t203 = icmp eq i32 %t198, 0
  %t204 = shl i32 %t202, 16
  %t205 = or i32 %t204, %t200
  %t206 = select i1 %t203, i32 0, i32 %t205
  %t208 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t206, 0
  store { i32, { i64, ptr } } %t208, ptr %rv
  br label %ret
bb46:
  br label %bb55
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb54
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s11, ptr %t209, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store i32 %t211, ptr %l75
  %t212 = icmp ne i32 %t211, 0
  br i1 %t212, label %bb52, label %ok.213, !prof !99
ok.213:
  br label %bb51
bb51:
  br label %bb53
bb52:
  %t214 = load i32, ptr %l75, !tbaa !23
  %t215 = lshr i32 %t214, 16
  %t216 = and i32 %t214, 65535
  %t217 = icmp eq i32 %t215, 1
  %t218 = select i1 %t217, i32 1, i32 0
  %t219 = icmp eq i32 %t214, 0
  %t220 = shl i32 %t218, 16
  %t221 = or i32 %t220, %t216
  %t222 = select i1 %t219, i32 0, i32 %t221
  call void @__olang_scope_close(ptr %s11)
  %t224 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t222, 0
  store { i32, { i64, ptr } } %t224, ptr %rv
  br label %ret
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_582986fcdf40d11c_2a39a940a03de888)
  unreachable
bb55:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d152, i32 0, i32 1) }, ptr %l77, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t225, ptr %l78, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 0
  store i64 %t227, ptr %l79, !tbaa !24
  %t228 = load i64, ptr %l79, !tbaa !24
  %t229 = mul i64 %t228, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t229)
  %t231 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  store { i64, ptr } %t232, ptr %l80, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = load i64, ptr %l79, !tbaa !24
  %t238 = mul i64 %t237, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t234, ptr %t236, i64 %t238, i1 false)
  %t239 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t239, ptr %l78, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t241 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t240, 1
  store { i32, { i64, ptr } } %t241, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efunction(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l5 = alloca %"compiler/bindgen:ctype"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca i1
  %l25 = alloca i64
  %l29 = alloca %"compiler/bindgen:ctype"
  %l34 = alloca i32
  %l40 = alloca i32
  %l42 = alloca %"std/prelude/text:StringBuilder"
  %l48 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l53 = alloca i64
  %l56 = alloca i64
  %l77 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l102 = alloca i32
  %l109 = alloca i1
  %l110 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l118 = alloca %"compiler/bindgen:ctype"
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i32
  %l135 = alloca %"compiler/bindgen:ctype"
  %l138 = alloca i1
  %l141 = alloca i1
  %l154 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:cFunc", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v1, ptr %s0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l18
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/bindgen:cFunc", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t12 = load { i64, ptr }, ptr @G_2ecompiler_2fbindgen_2eNoReturnAttr, !tbaa !27
  %t13 = load ptr, ptr @__olang_prog_scope
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %t13, { i64, ptr } %t11, { i64, ptr } %t12)
  store i1 %t16, ptr %l22
  br label %bb2
bb2:
  %t17 = load i1, ptr %l22, !tbaa !21
  store i1 %t17, ptr %l3, !tbaa !21
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s0, ptr %t18, { i64, ptr } %t19, i64 0)
  store i64 %t22, ptr %l25
  br label %bb3
bb3:
  %t23 = load i64, ptr %l25, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/bindgen:gen", ptr %t24, i32 0, i32 16
  %t30 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t26, i64 %t23)
  store %"compiler/bindgen:ctype" %t30, ptr %l29
  br label %bb4
bb4:
  %t31 = load %"compiler/bindgen:ctype", ptr %l29
  store %"compiler/bindgen:ctype" %t31, ptr %l5
  %t32 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t33 = load i32, ptr %t32, !range !{i32 0, i32 7}
  %t35 = trunc i64 6 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb5, label %bb6
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t43 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t38, { i64, ptr } %t40)
  store i32 %t43, ptr %l34
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb8, label %ok.45, !prof !99
ok.45:
  br label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb9
bb8:
  %t46 = load i32, ptr %l34, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  call void @__olang_scope_close(ptr %s0)
  %t56 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t54, 0
  store { i32, { i64, ptr } } %t56, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t57 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t58 = load i32, ptr %t57, !range !{i32 0, i32 7}
  %t60 = trunc i64 5 to i32
  %t61 = icmp eq i32 %t58, %t60
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s2, ptr %t65, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d153, i32 0, i32 1) })
  store i32 %t67, ptr %l40
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb14, label %ok.69, !prof !99
ok.69:
  br label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb15
bb14:
  %t70 = load i32, ptr %l40, !tbaa !23
  %t71 = lshr i32 %t70, 16
  %t72 = and i32 %t70, 65535
  %t73 = icmp eq i32 %t71, 1
  %t74 = select i1 %t73, i32 1, i32 0
  %t75 = icmp eq i32 %t70, 0
  %t76 = shl i32 %t74, 16
  %t77 = or i32 %t76, %t72
  %t78 = select i1 %t75, i32 0, i32 %t77
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t80 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t78, 0
  store { i32, { i64, ptr } } %t80, ptr %rv
  br label %ret
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t81 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t81, ptr %l42
  br label %bb17
bb17:
  %t82 = load %"std/prelude/text:StringBuilder", ptr %l42
  store %"std/prelude/text:StringBuilder" %t82, ptr %l6
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/bindgen:cFunc", ptr %t83, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t87 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t90 = extractvalue { i64, ptr } %t86, 1
  %t91 = extractvalue { i64, ptr } %t86, 0
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t87, i64 %t88)
  %t97 = getelementptr i8, ptr %t96, i64 %t88
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = getelementptr i8, ptr %t97, i64 %t91
  call void @olang_textcopy(ptr %t98, ptr %t93, i64 %t94)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t96, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t107)
  br label %bb18
bb18:
  %t110 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t110, ptr %l48
  br label %bb19
bb19:
  %t111 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l48
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t111, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t112 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 4
  %t113 = load i64, ptr %t112, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb20, label %bb21
bb20:
  %t121 = load i64, ptr %l10, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb25
bb22:
  %t125 = load i64, ptr %l9, !tbaa !24
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l10, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l56, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb24
bb24:
  %t141 = load i64, ptr %l56, !tbaa !24
  store i64 %t141, ptr %l53, !tbaa !24
  br label %bb25
bb25:
  %t142 = load i64, ptr %l53, !tbaa !24
  store i64 %t142, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t143 = load i64, ptr %l12, !tbaa !24
  %t144 = load i64, ptr %l11, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb28:
  br label %bb29
bb29:
  %t151 = load i64, ptr %l8, !tbaa !24
  %t152 = load i64, ptr %l12, !tbaa !24
  %t153 = load i64, ptr %l10, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l13, !tbaa !24
  %t161 = load i64, ptr %l13, !tbaa !24
  %t163 = icmp sgt i64 %t161, 0
  br i1 %t163, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d156, i32 0, i32 1) })
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l77, !tbaa !29
  %t167 = load i64, ptr %l13, !tbaa !24
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/bindgen:cFunc", ptr %t168, i32 0, i32 2
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t176 = icmp slt i64 %t167, %t173
  br i1 %t176, label %bb34, label %bb35
bb34:
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr %"compiler/bindgen:cFunc", ptr %t178, i32 0, i32 2
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l85, !tbaa !27
  %t182 = load i64, ptr %l13, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %t185, i64 %t182
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !37
  store { i64, ptr } %t187, ptr %l83, !tbaa !27
  br label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d157, i32 0, i32 1) }, ptr %l83, !tbaa !27
  br label %bb36
bb36:
  %t189 = load i64, ptr %l13, !tbaa !24
  %t190 = load ptr, ptr %l77, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t194 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v1, ptr %s0, ptr %s5, ptr %t190, { i64, ptr } %t191, i64 %t189, ptr %l7)
  store { i64, ptr } %t194, ptr %l90
  br label %bb37
bb37:
  %t195 = load { i64, ptr }, ptr %l90, !tbaa !27
  store ptr %l6, ptr %l91, !tbaa !29
  store { i64, ptr } %t195, ptr %l92, !tbaa !27
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l94, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/bindgen:gen", ptr %t198, i32 0, i32 17
  %t201 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 5
  %t202 = load i64, ptr %t201, !tbaa !24
  %t203 = load i64, ptr %l13, !tbaa !24
  %t206 = add i64 %t202, %t203
  %t209 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t200, i64 %t206)
  store i64 %t209, ptr %l100
  br label %bb38
bb38:
  %t210 = load ptr, ptr %l94, !tbaa !29
  %t211 = load i64, ptr %l100, !tbaa !24
  %t212 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamType(ptr %v0, ptr %s5, ptr %t210, i64 %t211)
  %t213 = extractvalue { i32, { i64, ptr } } %t212, 1
  %t214 = extractvalue { i32, { i64, ptr } } %t212, 0
  store i32 %t214, ptr %l102
  %t215 = icmp ne i32 %t214, 0
  br i1 %t215, label %bb40, label %ok.216, !prof !99
ok.216:
  store { i64, ptr } %t213, ptr %l101
  br label %bb39
bb39:
  %t217 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t217, ptr %l93, !tbaa !27
  br label %bb41
bb40:
  %t218 = load i32, ptr %l102, !tbaa !23
  %t219 = lshr i32 %t218, 16
  %t220 = and i32 %t218, 65535
  %t221 = icmp eq i32 %t219, 1
  %t222 = select i1 %t221, i32 1, i32 0
  %t223 = icmp eq i32 %t218, 0
  %t224 = shl i32 %t222, 16
  %t225 = or i32 %t224, %t220
  %t226 = select i1 %t223, i32 0, i32 %t225
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t228 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t226, 0
  store { i32, { i64, ptr } } %t228, ptr %rv
  br label %ret
bb41:
  %t229 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t234 = add i64 %t231, %t233
  %t235 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = add i64 %t234, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t230, i64 %t231)
  %t240 = getelementptr i8, ptr %t239, i64 %t231
  call void @olang_textcopy(ptr %t240, ptr %t232, i64 %t233)
  %t241 = getelementptr i8, ptr %t240, i64 %t233
  call void @olang_textcopy(ptr %t241, ptr %t236, i64 %t237)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t239, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t251 = load ptr, ptr %l91, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t251, { i64, ptr } %t250)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  %t253 = load i64, ptr %l12, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l12, !tbaa !24
  br label %bb26
bb44:
  %t257 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 1
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  %t260 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t258, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t260, ptr %l109
  br label %bb45
bb45:
  %t261 = load i1, ptr %l109, !tbaa !21
  br i1 %t261, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  store ptr %l6, ptr %l110, !tbaa !29
  %t262 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 4
  %t263 = load i64, ptr %t262, !tbaa !24
  %t265 = icmp sgt i64 %t263, 0
  br i1 %t265, label %bb48, label %bb49
bb47:
  br label %bb52
bb48:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d160, i32 0, i32 1) }, ptr %l113, !tbaa !27
  br label %bb50
bb49:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d161, i32 0, i32 1) }, ptr %l113, !tbaa !27
  br label %bb50
bb50:
  %t267 = load ptr, ptr %l110, !tbaa !29
  %t268 = load { i64, ptr }, ptr %l113, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t267, { i64, ptr } %t268)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb52:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) })
  br label %bb53
bb53:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/bindgen:gen", ptr %t270, i32 0, i32 16
  %t273 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 2
  %t274 = load i64, ptr %t273, !tbaa !24
  %t277 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t272, i64 %t274)
  store %"compiler/bindgen:ctype" %t277, ptr %l118
  br label %bb54
bb54:
  %t278 = getelementptr %"compiler/bindgen:ctype", ptr %l118, i32 0, i32 0
  %t279 = load i32, ptr %t278, !range !{i32 0, i32 7}
  %t281 = trunc i64 0 to i32
  %t282 = icmp eq i32 %t279, %t281
  %t284 = xor i1 %t282, true
  br i1 %t284, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 2
  %t288 = load i64, ptr %t287, !tbaa !24
  %t291 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %s10, ptr %t286, i64 %t288, i1 false)
  %t292 = extractvalue { i32, { i64, ptr } } %t291, 1
  %t293 = extractvalue { i32, { i64, ptr } } %t291, 0
  store i32 %t293, ptr %l126
  %t294 = icmp ne i32 %t293, 0
  br i1 %t294, label %bb58, label %ok.295, !prof !99
ok.295:
  store { i64, ptr } %t292, ptr %l125
  br label %bb57
bb56:
  %t296 = load i1, ptr %l3, !tbaa !21
  br i1 %t296, label %bb70, label %bb71
bb57:
  %t298 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t298, ptr %l122, !tbaa !27
  br label %bb59
bb58:
  %t299 = load i32, ptr %l126, !tbaa !23
  %t300 = lshr i32 %t299, 16
  %t301 = and i32 %t299, 65535
  %t302 = icmp eq i32 %t300, 1
  %t303 = select i1 %t302, i32 1, i32 0
  %t304 = icmp eq i32 %t299, 0
  %t305 = shl i32 %t303, 16
  %t306 = or i32 %t305, %t301
  %t307 = select i1 %t304, i32 0, i32 %t306
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t309 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t307, 0
  store { i32, { i64, ptr } } %t309, ptr %rv
  br label %ret
bb59:
  %t310 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t310, ptr %l15, !tbaa !27
  %t311 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t312 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t315 = extractvalue { i64, ptr } %t311, 1
  %t316 = extractvalue { i64, ptr } %t311, 0
  %t317 = add i64 %t313, %t316
  %t318 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t317)
  call void @olang_textcopy(ptr %t318, ptr %t312, i64 %t313)
  %t319 = getelementptr i8, ptr %t318, i64 %t313
  call void @olang_textcopy(ptr %t319, ptr %t315, i64 %t316)
  %t320 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t318, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = extractvalue { i64, ptr } %t321, 1
  %t325 = mul i64 %t323, 1
  %t326 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t325)
  call void @llvm.memcpy.p0.p0.i64(ptr %t326, ptr %t324, i64 %t325, i1 false)
  %t327 = insertvalue { i64, ptr } undef, i64 %t323, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t326, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %l6, { i64, ptr } %t328)
  br label %bb60
bb60:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/bindgen:gen", ptr %t331, i32 0, i32 16
  %t334 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 2
  %t335 = load i64, ptr %t334, !tbaa !24
  %t338 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s10, ptr %t333, i64 %t335)
  store %"compiler/bindgen:ctype" %t338, ptr %l135
  br label %bb61
bb61:
  %t339 = getelementptr %"compiler/bindgen:ctype", ptr %l135, i32 0, i32 0
  %t340 = load i32, ptr %t339, !range !{i32 0, i32 7}
  %t342 = trunc i64 1 to i32
  %t343 = icmp eq i32 %t340, %t342
  br i1 %t343, label %bb62, label %bb63
bb62:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load %"compiler/bindgen:ctype", ptr %l5
  %t349 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enumbersOnly(ptr %v0, ptr %v0, ptr %t345, %"compiler/bindgen:ctype" %t346)
  store i1 %t349, ptr %l141
  br label %bb64
bb63:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb65
bb64:
  %t350 = load i1, ptr %l141, !tbaa !21
  store i1 %t350, ptr %l138, !tbaa !21
  br label %bb65
bb65:
  %t351 = load i1, ptr %l138, !tbaa !21
  br i1 %t351, label %bb66, label %bb67
bb66:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/bindgen:gen", ptr %t352, i32 0, i32 15
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr %"compiler/bindgen:cFunc", ptr %t355, i32 0, i32 0
  %t358 = load { i64, ptr }, ptr %t357, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t358, 1
  %t361 = extractvalue { i64, ptr } %t358, 0
  %t362 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t361)
  call void @olang_textcopy(ptr %t362, ptr %t360, i64 %t361)
  %t363 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t367 = extractvalue { i64, ptr } %t364, 1
  %t368 = mul i64 %t366, 1
  %t369 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t368)
  call void @llvm.memcpy.p0.p0.i64(ptr %t369, ptr %t367, i64 %t368, i1 false)
  %t370 = insertvalue { i64, ptr } undef, i64 %t366, 0
  %t371 = insertvalue { i64, ptr } %t370, ptr %t369, 1
  %t372 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t372, 1
  %t375 = extractvalue { i64, ptr } %t372, 0
  %t376 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t375)
  call void @olang_textcopy(ptr %t376, ptr %t374, i64 %t375)
  %t377 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t376, 1
  %t380 = extractvalue { i64, ptr } %t378, 0
  %t381 = extractvalue { i64, ptr } %t378, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t354, { i64, ptr } %t371, { i64, ptr } %t385)
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s10)
  br label %bb74
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l6, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d164, i32 0, i32 1) })
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s16)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t391 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l6)
  store { i64, ptr } %t391, ptr %l154
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t392 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t393 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t392, 1
  store { i32, { i64, ptr } } %t393, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eintMacros(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/bindgen:cMacro"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l13 = alloca i64
  %l19 = alloca %"compiler/bindgen:cMacro"
  %l21 = alloca i1
  %l22 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca i32
  %l47 = alloca i1
  %l49 = alloca i64
  %l51 = alloca i1
  %l53 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/bindgen:gen", ptr %t5, i32 0, i32 12
  store ptr %t7, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l11, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l13
  br label %bb3
bb3:
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l13, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb5:
  br label %bb6
bb6:
  %t19 = load i64, ptr %l3, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v0, ptr %t21, i64 %t22)
  store %"compiler/bindgen:cMacro" %t25, ptr %l19
  br label %bb7
bb7:
  %t26 = load %"compiler/bindgen:cMacro", ptr %l19
  store %"compiler/bindgen:cMacro" %t26, ptr %l5
  %t27 = getelementptr %"compiler/bindgen:cMacro", ptr %l5, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t28, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d165, i32 0, i32 1) })
  store i1 %t30, ptr %l21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l21, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t32 = getelementptr %"compiler/bindgen:cMacro", ptr %l5, i32 0, i32 1
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb14
bb13:
  %t36 = getelementptr %"compiler/bindgen:cMacro", ptr %l5, i32 0, i32 4
  %t37 = load i1, ptr %t36, !tbaa !21
  %t39 = xor i1 %t37, true
  store i1 %t39, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t41 = load i1, ptr %l24, !tbaa !21
  br i1 %t41, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb18
bb16:
  %t42 = getelementptr %"compiler/bindgen:cMacro", ptr %l5, i32 0, i32 0
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t43)
  store i1 %t45, ptr %l29
  br label %bb17
bb17:
  %t46 = load i1, ptr %l29, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb21
bb20:
  %t50 = getelementptr %"compiler/bindgen:cMacro", ptr %l5, i32 0, i32 3
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t55 = icmp eq i64 %t53, 0
  store i1 %t55, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb23:
  br label %bb24
bb24:
  %t58 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l35
  br label %bb25
bb25:
  %t59 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l6
  %t60 = getelementptr %"compiler/bindgen:cMacro", ptr %l5, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 1
  %t64 = extractvalue { i64, ptr } %t61, 0
  %t65 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t63, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l6, { i64, ptr } %t74)
  br label %bb26
bb26:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/bindgen:cMacro", ptr %l5, i32 0, i32 3
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  %t83 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %v0, ptr %s2, ptr %s2, ptr %t77, { i64, ptr } %t79, ptr %l6, i64 0)
  %t84 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t83, 1
  %t85 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t83, 0
  store i32 %t85, ptr %l45
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb28, label %ok.87, !prof !99
ok.87:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l44
  br label %bb27
bb27:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l40
  br label %bb30
bb28:
  %t89 = load i32, ptr %l45, !tbaa !23
  %t90 = ashr i32 %t89, 16
  %t92 = icmp eq i32 %t90, 1
  store i1 %t92, ptr %l47, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb30:
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l7
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l7)
  store i64 %t95, ptr %l49
  br label %bb31
bb31:
  %t96 = load i64, ptr %l49, !tbaa !24
  %t97 = icmp eq i64 %t96, 0
  br i1 %t97, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb35
bb33:
  %t100 = call i64 @compiler_2fbindgen_2ebodyKind(ptr %s2, ptr %l7)
  store i64 %t100, ptr %l53
  br label %bb34
bb34:
  %t101 = load i64, ptr %l53, !tbaa !24
  %t102 = icmp ne i64 %t101, 0
  store i1 %t102, ptr %l51, !tbaa !21
  br label %bb35
bb35:
  %t104 = load i1, ptr %l51, !tbaa !21
  br i1 %t104, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb37:
  br label %bb38
bb38:
  %t105 = load ptr, ptr %lp1
  %t106 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t105, i64 %t106)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t109 = load i64, ptr %l3, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l3, !tbaa !24
  br label %bb2
bb41:
  %t113 = load ptr, ptr %lp1
  %t114 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t113
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisByte(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca %"compiler/bindgen:ctype"
  %l9 = alloca i1
  %l13 = alloca %"compiler/bindgen:ctype"
  %l16 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 16
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t3, i64 %t4)
  store %"compiler/bindgen:ctype" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/bindgen:ctype", ptr %l6, i32 0, i32 0
  %t9 = load i32, ptr %t8, !range !{i32 0, i32 7}
  %t11 = trunc i64 1 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/bindgen:gen", ptr %t14, i32 0, i32 16
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/bindgen:ctype" %t20, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb4:
  %t21 = getelementptr %"compiler/bindgen:ctype", ptr %l13, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t26 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0, ptr %v0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x { i64, ptr }] }>, ptr @.d166, i32 0, i32 1) }, { i64, ptr } %t22)
  store i1 %t26, ptr %l16
  br label %bb5
bb5:
  %t27 = load i1, ptr %l16, !tbaa !21
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l9, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisChar(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca %"compiler/bindgen:ctype"
  %l8 = alloca i1
  %l12 = alloca %"compiler/bindgen:ctype"
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 16
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t3, i64 %t4)
  store %"compiler/bindgen:ctype" %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t9 = load i32, ptr %t8, !range !{i32 0, i32 7}
  %t11 = trunc i64 1 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/bindgen:gen", ptr %t14, i32 0, i32 16
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/bindgen:ctype" %t20, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t21 = getelementptr %"compiler/bindgen:ctype", ptr %l12, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d167, i32 0, i32 1) })
  store i1 %t24, ptr %l14
  br label %bb5
bb5:
  %t25 = load i1, ptr %l14, !tbaa !21
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i1, ptr %l8, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emacroFn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"compiler/bindgen:cparse"
  %l5 = alloca %"compiler/bindgen:cx"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i32
  %l36 = alloca i64
  %l39 = alloca i32
  %l42 = alloca { i64, ptr }
  %l45 = alloca %"compiler/bindgen:cparse"
  %l46 = alloca %"compiler/bindgen:cx"
  %l49 = alloca %"compiler/bindgen:cx"
  %l50 = alloca i32
  %l52 = alloca i64
  %l54 = alloca i64
  %l56 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l61 = alloca i32
  %l63 = alloca %"std/prelude/text:StringBuilder"
  %l80 = alloca i64
  %l83 = alloca i64
  %l101 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l118 = alloca i64
  %l121 = alloca i64
  %l139 = alloca ptr
  %l142 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l174 = alloca i64
  %l175 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l21
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/bindgen:cMacro", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = extractvalue { i64, ptr } %t6, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t19)
  br label %bb2
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/bindgen:cMacro", ptr %t23, i32 0, i32 3
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t30 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t22, { i64, ptr } %t26, ptr %l2, i64 0)
  %t31 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t30, 1
  %t32 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t30, 0
  store i32 %t32, ptr %l33
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb4, label %ok.34, !prof !99
ok.34:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l32
  br label %bb3
bb3:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l27
  br label %bb5
bb4:
  %t36 = load i32, ptr %l33, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  call void @__olang_scope_close(ptr %s0)
  %t46 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t44, 0
  store { i32, { i64, ptr } } %t46, ptr %rv
  br label %ret
bb5:
  %t47 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l3
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t49, ptr %l36
  br label %bb6
bb6:
  %t50 = load i64, ptr %l36, !tbaa !24
  %t51 = icmp eq i64 %t50, 0
  br i1 %t51, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s2, ptr %t53, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d168, i32 0, i32 1) })
  store i32 %t55, ptr %l39
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb10, label %ok.57, !prof !99
ok.57:
  br label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb11
bb10:
  %t58 = load i32, ptr %l39, !tbaa !23
  %t59 = lshr i32 %t58, 16
  %t60 = and i32 %t58, 65535
  %t61 = icmp eq i32 %t59, 1
  %t62 = select i1 %t61, i32 1, i32 0
  %t63 = icmp eq i32 %t58, 0
  %t64 = shl i32 %t62, 16
  %t65 = or i32 %t64, %t60
  %t66 = select i1 %t63, i32 0, i32 %t65
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t68 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t66, 0
  store { i32, { i64, ptr } } %t68, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t70 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t70, ptr %l42
  br label %bb13
bb13:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/bindgen:cMacro", ptr %t71, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t77 = call %"compiler/bindgen:cparse" @compiler_2fbindgen_3acparse_2ector(ptr %s0, ptr %v1, ptr %s0, { i64, ptr } %t75, { i64, ptr } %t74)
  store %"compiler/bindgen:cparse" %t77, ptr %l45
  br label %bb14
bb14:
  %t78 = load %"compiler/bindgen:cparse", ptr %l45
  store %"compiler/bindgen:cparse" %t78, ptr %l4
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t82 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %s0, ptr %s0, ptr %t79, ptr %l4)
  %t83 = extractvalue { i32, %"compiler/bindgen:cx" } %t82, 1
  %t84 = extractvalue { i32, %"compiler/bindgen:cx" } %t82, 0
  store i32 %t84, ptr %l50
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb16, label %ok.86, !prof !99
ok.86:
  store %"compiler/bindgen:cx" %t83, ptr %l49
  br label %bb15
bb15:
  %t87 = load %"compiler/bindgen:cx", ptr %l49
  store %"compiler/bindgen:cx" %t87, ptr %l46
  br label %bb17
bb16:
  %t88 = load i32, ptr %l50, !tbaa !23
  %t89 = lshr i32 %t88, 16
  %t90 = and i32 %t88, 65535
  %t91 = icmp eq i32 %t89, 1
  %t92 = select i1 %t91, i32 1, i32 0
  %t93 = icmp eq i32 %t88, 0
  %t94 = shl i32 %t92, 16
  %t95 = or i32 %t94, %t90
  %t96 = select i1 %t93, i32 0, i32 %t95
  call void @__olang_scope_close(ptr %s0)
  %t98 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t96, 0
  store { i32, { i64, ptr } } %t98, ptr %rv
  br label %ret
bb17:
  %t99 = load %"compiler/bindgen:cx", ptr %l46
  store %"compiler/bindgen:cx" %t99, ptr %l5
  %t100 = getelementptr %"compiler/bindgen:cparse", ptr %l4, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  store i64 %t101, ptr %l52, !tbaa !24
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t103, ptr %l54
  br label %bb18
bb18:
  %t104 = load i64, ptr %l52, !tbaa !24
  %t105 = load i64, ptr %l54, !tbaa !24
  %t106 = icmp ne i64 %t104, %t105
  br i1 %t106, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l56, !tbaa !29
  %t110 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %s0, ptr %s3, ptr %l4)
  store { i64, ptr } %t110, ptr %l58
  br label %bb21
bb20:
  br label %bb25
bb21:
  %t111 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t113 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t111, i64 %t112)
  %t121 = getelementptr i8, ptr %t120, i64 %t112
  call void @olang_textcopy(ptr %t121, ptr %t114, i64 %t115)
  %t122 = getelementptr i8, ptr %t121, i64 %t115
  call void @olang_textcopy(ptr %t122, ptr %t117, i64 %t118)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t120, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  %t132 = load ptr, ptr %l56, !tbaa !29
  %t134 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s3, ptr %t132, { i64, ptr } %t131)
  store i32 %t134, ptr %l61
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb23, label %ok.136, !prof !99
ok.136:
  br label %bb22
bb22:
  br label %bb24
bb23:
  %t137 = load i32, ptr %l61, !tbaa !23
  %t138 = lshr i32 %t137, 16
  %t139 = and i32 %t137, 65535
  %t140 = icmp eq i32 %t138, 1
  %t141 = select i1 %t140, i32 1, i32 0
  %t142 = icmp eq i32 %t137, 0
  %t143 = shl i32 %t141, 16
  %t144 = or i32 %t143, %t139
  %t145 = select i1 %t142, i32 0, i32 %t144
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t147 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t145, 0
  store { i32, { i64, ptr } } %t147, ptr %rv
  br label %ret
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t148 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t148, ptr %l63
  br label %bb26
bb26:
  %t149 = load %"std/prelude/text:StringBuilder", ptr %l63
  store %"std/prelude/text:StringBuilder" %t149, ptr %l6
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/bindgen:cMacro", ptr %t150, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t154 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t157 = extractvalue { i64, ptr } %t153, 1
  %t158 = extractvalue { i64, ptr } %t153, 0
  %t159 = add i64 %t155, %t158
  %t160 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t159)
  call void @olang_textcopy(ptr %t160, ptr %t154, i64 %t155)
  %t161 = getelementptr i8, ptr %t160, i64 %t155
  call void @olang_textcopy(ptr %t161, ptr %t157, i64 %t158)
  %t162 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t160, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t170)
  br label %bb27
bb27:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr %"compiler/bindgen:cMacro", ptr %t173, i32 0, i32 2
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t180 = icmp sgt i64 %t178, 0
  br i1 %t180, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) })
  br label %bb30
bb29:
  br label %bb48
bb30:
  store i64 0, ptr %l7, !tbaa !24
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/bindgen:cMacro", ptr %t183, i32 0, i32 2
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  store i64 %t188, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t190 = load i64, ptr %l8, !tbaa !24
  %t191 = load i64, ptr %l7, !tbaa !24
  %t194 = icmp sgt i64 %t190, %t191
  br i1 %t194, label %bb31, label %bb32
bb31:
  %t196 = load i64, ptr %l9, !tbaa !24
  %t198 = icmp sgt i64 %t196, 0
  br i1 %t198, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb36
bb33:
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load i64, ptr %l7, !tbaa !24
  %t204 = sub i64 %t200, %t201
  %t205 = load i64, ptr %l9, !tbaa !24
  %t208 = add i64 %t204, %t205
  %t210 = sub i64 %t208, 1
  %t211 = load i64, ptr %l9, !tbaa !24
  %t214 = sdiv i64 %t210, %t211
  store i64 %t214, ptr %l83, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb35
bb35:
  %t216 = load i64, ptr %l83, !tbaa !24
  store i64 %t216, ptr %l80, !tbaa !24
  br label %bb36
bb36:
  %t217 = load i64, ptr %l80, !tbaa !24
  store i64 %t217, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t218 = load i64, ptr %l11, !tbaa !24
  %t219 = load i64, ptr %l10, !tbaa !24
  %t222 = icmp slt i64 %t218, %t219
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb39:
  br label %bb40
bb40:
  %t226 = load i64, ptr %l7, !tbaa !24
  %t227 = load i64, ptr %l11, !tbaa !24
  %t228 = load i64, ptr %l9, !tbaa !24
  %t231 = mul i64 %t227, %t228
  %t234 = add i64 %t226, %t231
  store i64 %t234, ptr %l12, !tbaa !24
  store ptr %l6, ptr %l101, !tbaa !29
  %t236 = load i64, ptr %l12, !tbaa !24
  %t238 = icmp sgt i64 %t236, 0
  br i1 %t238, label %bb41, label %bb42
bb41:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d173, i32 0, i32 1) }, ptr %l104, !tbaa !27
  br label %bb43
bb42:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) }, ptr %l104, !tbaa !27
  br label %bb43
bb43:
  %t240 = load i64, ptr %l12, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 1
  %t243 = extractvalue { i64, ptr } %t241, 0
  %t244 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t245 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t246 = add i64 %t243, %t245
  %t248 = call i64 @__olang_fmt_i64(ptr null, i64 %t240)
  %t249 = add i64 %t246, %t248
  %t250 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t249)
  call void @olang_textcopy(ptr %t250, ptr %t242, i64 %t243)
  %t251 = getelementptr i8, ptr %t250, i64 %t243
  call void @olang_textcopy(ptr %t251, ptr %t244, i64 %t245)
  %t252 = getelementptr i8, ptr %t251, i64 %t245
  %t253 = call i64 @__olang_fmt_i64(ptr %t252, i64 %t240)
  %t254 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t250, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = extractvalue { i64, ptr } %t255, 1
  %t259 = mul i64 %t257, 1
  %t260 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t259)
  call void @llvm.memcpy.p0.p0.i64(ptr %t260, ptr %t258, i64 %t259, i1 false)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  %t263 = load ptr, ptr %l101, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t263, { i64, ptr } %t262)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s8)
  br label %bb45
bb45:
  %t265 = load i64, ptr %l11, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l11, !tbaa !24
  br label %bb37
bb46:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) })
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb48:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) })
  br label %bb49
bb49:
  store i64 0, ptr %l13, !tbaa !24
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr %"compiler/bindgen:cMacro", ptr %t271, i32 0, i32 2
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t274, 0
  store i64 %t276, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t278 = load i64, ptr %l14, !tbaa !24
  %t279 = load i64, ptr %l13, !tbaa !24
  %t282 = icmp sgt i64 %t278, %t279
  br i1 %t282, label %bb50, label %bb51
bb50:
  %t284 = load i64, ptr %l15, !tbaa !24
  %t286 = icmp sgt i64 %t284, 0
  br i1 %t286, label %bb52, label %bb53
bb51:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb55
bb52:
  %t288 = load i64, ptr %l14, !tbaa !24
  %t289 = load i64, ptr %l13, !tbaa !24
  %t292 = sub i64 %t288, %t289
  %t293 = load i64, ptr %l15, !tbaa !24
  %t296 = add i64 %t292, %t293
  %t298 = sub i64 %t296, 1
  %t299 = load i64, ptr %l15, !tbaa !24
  %t302 = sdiv i64 %t298, %t299
  store i64 %t302, ptr %l121, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb54
bb54:
  %t304 = load i64, ptr %l121, !tbaa !24
  store i64 %t304, ptr %l118, !tbaa !24
  br label %bb55
bb55:
  %t305 = load i64, ptr %l118, !tbaa !24
  store i64 %t305, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s12
  %t306 = load i64, ptr %l17, !tbaa !24
  %t307 = load i64, ptr %l16, !tbaa !24
  %t310 = icmp slt i64 %t306, %t307
  %t312 = xor i1 %t310, true
  br i1 %t312, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s12)
  br label %bb65
bb58:
  br label %bb59
bb59:
  %t314 = load i64, ptr %l13, !tbaa !24
  %t315 = load i64, ptr %l17, !tbaa !24
  %t316 = load i64, ptr %l15, !tbaa !24
  %t319 = mul i64 %t315, %t316
  %t322 = add i64 %t314, %t319
  store i64 %t322, ptr %l18, !tbaa !24
  store ptr %l6, ptr %l139, !tbaa !29
  %t324 = load i64, ptr %l18, !tbaa !24
  %t326 = icmp sgt i64 %t324, 0
  br i1 %t326, label %bb60, label %bb61
bb60:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d178, i32 0, i32 1) }, ptr %l142, !tbaa !27
  br label %bb62
bb61:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) }, ptr %l142, !tbaa !27
  br label %bb62
bb62:
  %t328 = load i64, ptr %l18, !tbaa !24
  %t329 = load i64, ptr %l18, !tbaa !24
  %t330 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 1
  %t332 = extractvalue { i64, ptr } %t330, 0
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t334 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t335 = add i64 %t332, %t334
  %t337 = call i64 @__olang_fmt_i64(ptr null, i64 %t328)
  %t338 = add i64 %t335, %t337
  %t339 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t341 = add i64 %t338, %t340
  %t343 = call i64 @__olang_fmt_i64(ptr null, i64 %t329)
  %t344 = add i64 %t341, %t343
  %t345 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t344)
  call void @olang_textcopy(ptr %t345, ptr %t331, i64 %t332)
  %t346 = getelementptr i8, ptr %t345, i64 %t332
  call void @olang_textcopy(ptr %t346, ptr %t333, i64 %t334)
  %t347 = getelementptr i8, ptr %t346, i64 %t334
  %t348 = call i64 @__olang_fmt_i64(ptr %t347, i64 %t328)
  %t349 = getelementptr i8, ptr %t347, i64 %t337
  call void @olang_textcopy(ptr %t349, ptr %t339, i64 %t340)
  %t350 = getelementptr i8, ptr %t349, i64 %t340
  %t351 = call i64 @__olang_fmt_i64(ptr %t350, i64 %t329)
  %t352 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t345, 1
  %t355 = extractvalue { i64, ptr } %t353, 0
  %t356 = extractvalue { i64, ptr } %t353, 1
  %t357 = mul i64 %t355, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t358, ptr %t356, i64 %t357, i1 false)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  %t361 = load ptr, ptr %l139, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t361, { i64, ptr } %t360)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  %t363 = load i64, ptr %l17, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l17, !tbaa !24
  br label %bb56
bb65:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d182, i32 0, i32 1) })
  br label %bb66
bb66:
  %t368 = getelementptr %"compiler/bindgen:cx", ptr %l5, i32 0, i32 1
  %t369 = load i64, ptr %t368, !tbaa !24
  store i64 %t369, ptr %l19, !tbaa !24
  %t371 = load i64, ptr %l19, !tbaa !24
  %t372 = load i64, ptr @G_2ecompiler_2fbindgen_2eKVar, !tbaa !24
  %t375 = icmp eq i64 %t371, %t372
  br i1 %t375, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  %t377 = getelementptr %"compiler/bindgen:cx", ptr %l5, i32 0, i32 2
  %t378 = load i64, ptr %t377, !tbaa !24
  %t379 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t380 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t382 = call i64 @__olang_fmt_i64(ptr null, i64 %t378)
  %t383 = add i64 %t380, %t382
  %t384 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t383)
  call void @olang_textcopy(ptr %t384, ptr %t379, i64 %t380)
  %t385 = getelementptr i8, ptr %t384, i64 %t380
  %t386 = call i64 @__olang_fmt_i64(ptr %t385, i64 %t378)
  %t387 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t384, 1
  store { i64, ptr } %t388, ptr %l151, !tbaa !27
  br label %bb87
bb70:
  %t390 = load i64, ptr %l19, !tbaa !24
  %t391 = load i64, ptr @G_2ecompiler_2fbindgen_2eKType, !tbaa !24
  %t394 = icmp eq i64 %t390, %t391
  br i1 %t394, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t396 = getelementptr %"compiler/bindgen:cx", ptr %l5, i32 0, i32 3
  %t397 = load { i64, ptr }, ptr %t396, !tbaa !27
  %t399 = extractvalue { i64, ptr } %t397, 1
  %t400 = extractvalue { i64, ptr } %t397, 0
  %t401 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t400)
  call void @olang_textcopy(ptr %t401, ptr %t399, i64 %t400)
  %t402 = insertvalue { i64, ptr } undef, i64 %t400, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t401, 1
  store { i64, ptr } %t403, ptr %l151, !tbaa !27
  br label %bb87
bb74:
  %t405 = load i64, ptr %l19, !tbaa !24
  %t406 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t409 = icmp eq i64 %t405, %t406
  br i1 %t409, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d184, i32 0, i32 1) }, ptr %l165, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t411, ptr %l151, !tbaa !27
  br label %bb87
bb78:
  %t413 = load i64, ptr %l19, !tbaa !24
  %t414 = load i64, ptr @G_2ecompiler_2fbindgen_2eKFloat, !tbaa !24
  %t417 = icmp eq i64 %t413, %t414
  br i1 %t417, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d185, i32 0, i32 1) }, ptr %l170, !tbaa !27
  %t419 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t419, ptr %l151, !tbaa !27
  br label %bb87
bb82:
  br i1 true, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d186, i32 0, i32 1) }, ptr %l172, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t421, ptr %l151, !tbaa !27
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_7ea854ff7e2640a8_63f49c54b749b4b4)
  unreachable
bb87:
  %t423 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t423, 0
  store i64 %t424, ptr %l174, !tbaa !24
  %t425 = load i64, ptr %l174, !tbaa !24
  %t426 = mul i64 %t425, 1
  %t427 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t426)
  %t428 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t429 = insertvalue { i64, ptr } %t428, ptr %t427, 1
  store { i64, ptr } %t429, ptr %l175, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = load i64, ptr %l174, !tbaa !24
  %t435 = mul i64 %t434, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t431, ptr %t433, i64 %t435, i1 false)
  %t436 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t438 = getelementptr %"compiler/bindgen:cx", ptr %l5, i32 0, i32 0
  %t439 = load { i64, ptr }, ptr %t438, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t436, 1
  %t442 = extractvalue { i64, ptr } %t436, 0
  %t443 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t445 = add i64 %t442, %t444
  %t447 = extractvalue { i64, ptr } %t439, 1
  %t448 = extractvalue { i64, ptr } %t439, 0
  %t449 = add i64 %t445, %t448
  %t450 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t452 = add i64 %t449, %t451
  %t453 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t452)
  call void @olang_textcopy(ptr %t453, ptr %t441, i64 %t442)
  %t454 = getelementptr i8, ptr %t453, i64 %t442
  call void @olang_textcopy(ptr %t454, ptr %t443, i64 %t444)
  %t455 = getelementptr i8, ptr %t454, i64 %t444
  call void @olang_textcopy(ptr %t455, ptr %t447, i64 %t448)
  %t456 = getelementptr i8, ptr %t455, i64 %t448
  call void @olang_textcopy(ptr %t456, ptr %t450, i64 %t451)
  %t457 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t453, 1
  %t460 = extractvalue { i64, ptr } %t458, 0
  %t461 = extractvalue { i64, ptr } %t458, 1
  %t462 = mul i64 %t460, 1
  %t463 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t462)
  call void @llvm.memcpy.p0.p0.i64(ptr %t463, ptr %t461, i64 %t462, i1 false)
  %t464 = insertvalue { i64, ptr } undef, i64 %t460, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t463, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t465)
  br label %bb88
bb88:
  %t469 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l6)
  store { i64, ptr } %t469, ptr %l182
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s0)
  %t470 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t471 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t470, 1
  store { i32, { i64, ptr } } %t471, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecord(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l15 = alloca %"compiler/bindgen:record"
  %l17 = alloca %"compiler/bindgen:record"
  %l22 = alloca i1
  %l24 = alloca i1
  %l28 = alloca %"compiler/bindgen:record"
  %l30 = alloca %"compiler/bindgen:record"
  %l32 = alloca i1
  %l40 = alloca ptr
  %l44 = alloca i1
  %l45 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l67 = alloca i64
  %l70 = alloca i1
  %l73 = alloca { i64, ptr }
  %l75 = alloca i64
  %l80 = alloca i1
  %l81 = alloca i1
  %l83 = alloca i1
  %l86 = alloca { i64, ptr }
  %l88 = alloca i64
  %l97 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t5 = alloca %"compiler/bindgen:record", align 8
  %t8 = alloca %"compiler/bindgen:record", align 8
  %t31 = alloca %"compiler/bindgen:record", align 8
  %t34 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t5, i64 176, i1 false)
  br label %bb1
bb1:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t8, ptr %v0, ptr %l15)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t8, i64 176, i1 false)
  br label %bb2
bb2:
  %t10 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 0
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %a2, 1
  %t16 = extractvalue { i64, ptr } %a2, 0
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t15, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d189, i32 0, i32 1) })
  store i1 %t23, ptr %l22
  br label %bb3
bb3:
  %t24 = load i1, ptr %l22, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/bindgen:gen", ptr %t27, i32 0, i32 5
  %t30 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t31, ptr %v0, ptr %v0, ptr %t29, i64 %t30)
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %t31, i64 176, i1 false)
  br label %bb6
bb5:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb6:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t34, ptr %v0, ptr %l28)
  call void @llvm.memmove.p0.p0.i64(ptr %l30, ptr %t34, i64 176, i1 false)
  br label %bb7
bb7:
  %t36 = getelementptr %"compiler/bindgen:record", ptr %l30, i32 0, i32 11
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t37, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d190, i32 0, i32 1) })
  store i1 %t39, ptr %l32
  br label %bb8
bb8:
  %t40 = load i1, ptr %l32, !tbaa !21
  store i1 %t40, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t41 = load i1, ptr %l24, !tbaa !21
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l6, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/bindgen:gen", ptr %t59, i32 0, i32 5
  %t65 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t61, i64 %t42)
  store ptr %t65, ptr %l40
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t71 = getelementptr %"compiler/bindgen:record", ptr %t66, i32 0, i32 11
  store { i64, ptr } %t68, ptr %t71, !tbaa !27
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d191, i32 0, i32 1) })
  store i1 %t74, ptr %l44
  br label %bb14
bb14:
  %t75 = load i1, ptr %l44, !tbaa !21
  br i1 %t75, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t78 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s4, { i64, ptr } %t76, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d192, i32 0, i32 1) })
  %t79 = extractvalue { i32, i64 } %t78, 1
  %t80 = extractvalue { i32, i64 } %t78, 0
  store i32 %t80, ptr %l48
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb18, label %ok.82, !prof !99
ok.82:
  store i64 %t79, ptr %l47
  br label %bb17
bb16:
  br label %bb33
bb17:
  %t83 = load i64, ptr %l47, !tbaa !24
  store i64 %t83, ptr %l45, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  store i64 -1, ptr %l45, !tbaa !24
  br label %bb20
bb20:
  %t84 = load i64, ptr %l45, !tbaa !24
  store i64 %t84, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = icmp sge i64 %t85, 0
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t89, ptr %l52, !tbaa !27
  %t90 = load i64, ptr %l8, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l54, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t93, 0
  store i64 %t96, ptr %l57, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l58, !tbaa !24
  %t99 = load i64, ptr %l54, !tbaa !24
  %t100 = icmp sge i64 %t99, 0
  br i1 %t100, label %bb23, label %bb24
bb22:
  %t102 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = extractvalue { i64, ptr } %t102, 0
  %t106 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t104, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l51, !tbaa !27
  br label %bb29
bb23:
  %t110 = load i64, ptr %l54, !tbaa !24
  %t111 = load i64, ptr %l57, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7e828aa3d49398bd_dbb08dcf54087001)
  unreachable
bb25:
  %t114 = load i64, ptr %l57, !tbaa !24
  %t115 = load i64, ptr %l58, !tbaa !24
  %t116 = icmp sle i64 %t114, %t115
  br i1 %t116, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7e828aa3d49398bd_dbb08dcf54087001)
  unreachable
bb27:
  %t118 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = load i64, ptr %l54, !tbaa !24
  %t121 = load i64, ptr %l57, !tbaa !24
  %t122 = getelementptr i8, ptr %t119, i64 %t120
  %t123 = sub i64 %t121, %t120
  %t124 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t122, 1
  %t127 = extractvalue { i64, ptr } %t125, 1
  %t128 = extractvalue { i64, ptr } %t125, 0
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t127, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l51, !tbaa !27
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_7e828aa3d49398bd_dbb08dcf54087001)
  unreachable
bb29:
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l67, !tbaa !24
  %t138 = load i64, ptr %l67, !tbaa !24
  %t139 = icmp eq i64 %t134, %t138
  br i1 %t139, label %bb30, label %bb31
bb30:
  %t141 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = load i64, ptr %l67, !tbaa !24
  %t146 = mul i64 %t145, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t142, ptr %t144, i64 %t146, i1 false)
  br label %bb32
bb31:
  %t147 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t147, ptr %l4, !tbaa !27
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  %t148 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t150 = call i1 @compiler_2fbindgen_2eusable(ptr %s0, { i64, ptr } %t148)
  store i1 %t150, ptr %l70
  br label %bb34
bb34:
  %t151 = load i1, ptr %l70, !tbaa !21
  %t152 = xor i1 %t151, true
  br i1 %t152, label %bb35, label %bb36
bb35:
  %t154 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t155 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t158 = extractvalue { i64, ptr } %t154, 1
  %t159 = extractvalue { i64, ptr } %t154, 0
  %t160 = add i64 %t156, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t155, i64 %t156)
  %t162 = getelementptr i8, ptr %t161, i64 %t156
  call void @olang_textcopy(ptr %t162, ptr %t158, i64 %t159)
  %t163 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t161, 1
  store { i64, ptr } %t164, ptr %l73, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 0
  %t167 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  store i64 %t168, ptr %l75, !tbaa !24
  %t170 = load i64, ptr %l75, !tbaa !24
  %t171 = icmp eq i64 %t166, %t170
  br i1 %t171, label %bb37, label %bb38
bb36:
  br label %bb40
bb37:
  %t173 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = load i64, ptr %l75, !tbaa !24
  %t178 = mul i64 %t177, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t174, ptr %t176, i64 %t178, i1 false)
  br label %bb39
bb38:
  %t179 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t179, ptr %l4, !tbaa !27
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/bindgen:gen", ptr %t180, i32 0, i32 21
  %t183 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t186 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %s0, ptr %t182, { i64, ptr } %t183)
  store i1 %t186, ptr %l80
  br label %bb42
bb42:
  %t187 = load i1, ptr %l80, !tbaa !21
  br i1 %t187, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb46
bb44:
  %t188 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t190 = call i1 @compiler_2fbindgen_2epreludeName(ptr %s0, { i64, ptr } %t188)
  store i1 %t190, ptr %l83
  br label %bb45
bb45:
  %t191 = load i1, ptr %l83, !tbaa !21
  store i1 %t191, ptr %l81, !tbaa !21
  br label %bb46
bb46:
  %t192 = load i1, ptr %l81, !tbaa !21
  %t193 = xor i1 %t192, true
  br i1 %t193, label %bb47, label %bb48
bb47:
  br label %bb54
bb48:
  br label %bb49
bb49:
  %t195 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 1
  %t198 = extractvalue { i64, ptr } %t195, 0
  %t199 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t202 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t201)
  call void @olang_textcopy(ptr %t202, ptr %t197, i64 %t198)
  %t203 = getelementptr i8, ptr %t202, i64 %t198
  call void @olang_textcopy(ptr %t203, ptr %t199, i64 %t200)
  %t204 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t202, 1
  store { i64, ptr } %t205, ptr %l86, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  %t208 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  store i64 %t209, ptr %l88, !tbaa !24
  %t211 = load i64, ptr %l88, !tbaa !24
  %t212 = icmp eq i64 %t207, %t211
  br i1 %t212, label %bb50, label %bb51
bb50:
  %t214 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = load i64, ptr %l88, !tbaa !24
  %t219 = mul i64 %t218, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t215, ptr %t217, i64 %t219, i1 false)
  br label %bb52
bb51:
  %t220 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t220, ptr %l4, !tbaa !27
  br label %bb52
bb52:
  br label %bb53
bb53:
  br label %bb41
bb54:
  %t221 = load i64, ptr %l1, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t223, 1
  %t226 = extractvalue { i64, ptr } %t223, 0
  %t227 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t226)
  call void @olang_textcopy(ptr %t227, ptr %t225, i64 %t226)
  %t228 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = extractvalue { i64, ptr } %t229, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  store { i64, ptr } %t236, ptr %l10, !tbaa !27
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/bindgen:gen", ptr %t238, i32 0, i32 5
  %t244 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t240, i64 %t221)
  store ptr %t244, ptr %l97
  br label %bb55
bb55:
  %t245 = load ptr, ptr %l97, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t250 = getelementptr %"compiler/bindgen:record", ptr %t245, i32 0, i32 7
  store { i64, ptr } %t247, ptr %t250, !tbaa !27
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/bindgen:gen", ptr %t251, i32 0, i32 21
  %t254 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t254, 1
  %t257 = extractvalue { i64, ptr } %t254, 0
  %t258 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t257)
  call void @olang_textcopy(ptr %t258, ptr %t256, i64 %t257)
  %t259 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } %t260, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t253, { i64, ptr } %t267, i64 0)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enamedConst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca i1
  %l12 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @compiler_2fbindgen_2eusable(ptr %v1, { i64, ptr } %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:gen", ptr %t9, i32 0, i32 10
  %t15 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %t11, { i64, ptr } %t7)
  store i1 %t15, ptr %l12
  br label %bb4
bb4:
  %t16 = load i1, ptr %l12, !tbaa !21
  store i1 %t16, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l7, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/bindgen:gen", ptr %t18, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v2, ptr %t20, { i64, ptr } %a2)
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/bindgen:gen", ptr %t24, i32 0, i32 10
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = extractvalue { i64, ptr } %t27, 0
  %t31 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t29, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t26, { i64, ptr } %t40, i64 0)
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/bindgen:gen", ptr %t43, i32 0, i32 21
  %t46 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 1
  %t49 = extractvalue { i64, ptr } %t46, 0
  %t50 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t48, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = extractvalue { i64, ptr } %t52, 1
  %t56 = mul i64 %t54, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t56)
  call void @llvm.memcpy.p0.p0.i64(ptr %t57, ptr %t55, i64 %t56, i1 false)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t45, { i64, ptr } %t59, i64 0)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, i1 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca ptr
  %l13 = alloca %"compiler/bindgen:ctype"
  %l16 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 16
  store ptr %t3, ptr %l7, !tbaa !29
  %t14 = call %"compiler/bindgen:ctype" @compiler_2fbindgen_3actype_2ector(ptr %v1, ptr %v0, i32 %a1, { i64, ptr } %a2, i64 %a3, i1 %a4, i64 %a5)
  store %"compiler/bindgen:ctype" %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = load %"compiler/bindgen:ctype", ptr %l13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ePush_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t15, %"compiler/bindgen:ctype" %t16)
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/bindgen:gen", ptr %t17, i32 0, i32 16
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eLen_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l16
  br label %bb3
bb3:
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = sub i64 %t22, 1
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enumType(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i64
  %l35 = alloca i1
  %l38 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l45 = alloca i1
  %l48 = alloca i64
  %l50 = alloca i1
  %l53 = alloca i64
  %l55 = alloca i1
  %l57 = alloca i64
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i32
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca i32
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d195, i32 0, i32 1) })
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t5, i32 0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d196, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t8, ptr %l9
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i64, ptr %l9, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
bb5:
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d197, i32 0, i32 1) })
  store i1 %t12, ptr %l11
  br label %bb6
bb6:
  %t13 = load i1, ptr %l11, !tbaa !21
  br i1 %t13, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb8:
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d198, i32 0, i32 1) })
  store i1 %t16, ptr %l14
  br label %bb9
bb9:
  %t17 = load i1, ptr %l14, !tbaa !21
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb11, label %bb12
bb11:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t19, i32 1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d199, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t22, ptr %l17
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i64, ptr %l17, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
bb14:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d200, i32 0, i32 1) })
  store i1 %t26, ptr %l19
  br label %bb15
bb15:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb16, label %bb17
bb16:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i32 1, ptr %l21
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp eq i64 %t29, 1
  br i1 %t31, label %bb18, label %bb19
bb17:
  br label %bb25
bb18:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d201, i32 0, i32 1) }, ptr %l24, !tbaa !27
  br label %bb23
bb19:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = icmp eq i64 %t33, 2
  br i1 %t35, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d202, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d203, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb22
bb22:
  %t37 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  br label %bb23
bb23:
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = load i32, ptr %l21, !range !{i32 0, i32 7}
  %t40 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t41 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t38, i32 %t39, { i64, ptr } %t40, i64 -1, i1 false, i64 0)
  store i64 %t41, ptr %l28
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb25:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t43, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d204, i32 0, i32 1) })
  store i1 %t45, ptr %l30
  br label %bb26
bb26:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb27, label %bb28
bb27:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t50 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t47, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d205, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t50, ptr %l33
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load i64, ptr %l33, !tbaa !24
  store i64 %t51, ptr %rv
  br label %ret
bb30:
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d206, i32 0, i32 1) })
  store i1 %t54, ptr %l35
  br label %bb31
bb31:
  %t55 = load i1, ptr %l35, !tbaa !21
  br i1 %t55, label %bb32, label %bb33
bb32:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb34, label %bb35
bb33:
  br label %bb39
bb34:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t60, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d207, i32 0, i32 1) })
  store i64 %t62, ptr %l40
  br label %bb36
bb35:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t63, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d208, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t66, ptr %l43
  br label %bb37
bb36:
  %t67 = load i64, ptr %l40, !tbaa !24
  store i64 %t67, ptr %l38, !tbaa !24
  br label %bb38
bb37:
  %t68 = load i64, ptr %l43, !tbaa !24
  store i64 %t68, ptr %l38, !tbaa !24
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i64, ptr %l38, !tbaa !24
  store i64 %t69, ptr %rv
  br label %ret
bb39:
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t70, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d209, i32 0, i32 1) })
  store i1 %t72, ptr %l45
  br label %bb40
bb40:
  %t73 = load i1, ptr %l45, !tbaa !21
  br i1 %t73, label %bb41, label %bb42
bb41:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t74, i32 1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d210, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t77, ptr %l48
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t78 = load i64, ptr %l48, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
bb44:
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t81 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t79, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d211, i32 0, i32 1) })
  store i1 %t81, ptr %l50
  br label %bb45
bb45:
  %t82 = load i1, ptr %l50, !tbaa !21
  br i1 %t82, label %bb46, label %bb47
bb46:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t86 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t83, i32 1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d212, i32 0, i32 1) }, i64 -1, i1 false, i64 0)
  store i64 %t86, ptr %l53
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i64, ptr %l53, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
bb49:
  %t88 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t88, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d213, i32 0, i32 1) })
  store i1 %t90, ptr %l55
  br label %bb50
bb50:
  %t91 = load i1, ptr %l55, !tbaa !21
  br i1 %t91, label %bb51, label %bb52
bb51:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v0, ptr %t92, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d214, i32 0, i32 1) })
  store i64 %t94, ptr %l57
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t95 = load i64, ptr %l57, !tbaa !24
  store i64 %t95, ptr %rv
  br label %ret
bb54:
  %t96 = load i64, ptr %l2, !tbaa !24
  %t98 = icmp eq i64 %t96, 2
  store i1 %t98, ptr %l4, !tbaa !21
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t100, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d215, i32 0, i32 1) })
  store i1 %t102, ptr %l61
  br label %bb55
bb55:
  %t103 = load i1, ptr %l61, !tbaa !21
  br i1 %t103, label %bb56, label %bb57
bb56:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l62, !tbaa !29
  store i32 1, ptr %l63
  %t105 = load i1, ptr %l4, !tbaa !21
  br i1 %t105, label %bb58, label %bb59
bb57:
  br label %bb62
bb58:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d216, i32 0, i32 1) }, ptr %l65, !tbaa !27
  br label %bb60
bb59:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d217, i32 0, i32 1) }, ptr %l65, !tbaa !27
  br label %bb60
bb60:
  %t107 = load ptr, ptr %l62, !tbaa !29
  %t108 = load i32, ptr %l63, !range !{i32 0, i32 7}
  %t109 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t110 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t107, i32 %t108, { i64, ptr } %t109, i64 -1, i1 false, i64 0)
  store i64 %t110, ptr %l66
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i64, ptr %l66, !tbaa !24
  store i64 %t111, ptr %rv
  br label %ret
bb62:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t114 = icmp sgt i64 %t112, 0
  br i1 %t114, label %bb63, label %bb64
bb63:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l69, !tbaa !29
  store i32 1, ptr %l70
  %t117 = load i1, ptr %l4, !tbaa !21
  br i1 %t117, label %bb65, label %bb66
bb64:
  br label %bb69
bb65:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d218, i32 0, i32 1) }, ptr %l72, !tbaa !27
  br label %bb67
bb66:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d219, i32 0, i32 1) }, ptr %l72, !tbaa !27
  br label %bb67
bb67:
  %t119 = load ptr, ptr %l69, !tbaa !29
  %t120 = load i32, ptr %l70, !range !{i32 0, i32 7}
  %t121 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t122 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t119, i32 %t120, { i64, ptr } %t121, i64 -1, i1 false, i64 0)
  store i64 %t122, ptr %l73
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t123 = load i64, ptr %l73, !tbaa !24
  store i64 %t123, ptr %rv
  br label %ret
bb69:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l74, !tbaa !29
  store i32 1, ptr %l75
  %t125 = load i1, ptr %l4, !tbaa !21
  br i1 %t125, label %bb70, label %bb71
bb70:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d220, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb72
bb71:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d221, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb72
bb72:
  %t127 = load ptr, ptr %l74, !tbaa !29
  %t128 = load i32, ptr %l75, !range !{i32 0, i32 7}
  %t129 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t130 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enode(ptr %v0, ptr %v0, ptr %t127, i32 %t128, { i64, ptr } %t129, i64 -1, i1 false, i64 0)
  store i64 %t130, ptr %l78
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  %t131 = load i64, ptr %l78, !tbaa !24
  store i64 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enumbersOnly(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:ctype" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/bindgen:ctype"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i1
  %l15 = alloca i64
  %l18 = alloca i64
  %l37 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca %"compiler/bindgen:ctype"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/bindgen:ctype" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/bindgen:ctype", ptr %l1, i32 0, i32 1
  %t2 = load { i64, ptr }, ptr %t1, !tbaa !27
  %t4 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d222, i32 0, i32 1) })
  store i1 %t4, ptr %l9
  br label %bb1
bb1:
  %t5 = load i1, ptr %l9, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l2, !tbaa !24
  %t7 = getelementptr %"compiler/bindgen:ctype", ptr %l1, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb10
bb7:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l18, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l18, !tbaa !24
  store i64 %t36, ptr %l15, !tbaa !24
  br label %bb10
bb10:
  %t37 = load i64, ptr %l15, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/bindgen:gen", ptr %t56, i32 0, i32 16
  store ptr %t58, ptr %l37, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/bindgen:gen", ptr %t59, i32 0, i32 17
  %t62 = getelementptr %"compiler/bindgen:ctype", ptr %l1, i32 0, i32 5
  %t63 = load i64, ptr %t62, !tbaa !24
  %t67 = add i64 %t63, %t54
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t61, i64 %t67)
  store i64 %t70, ptr %l43
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load i64, ptr %l43, !tbaa !24
  %t73 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s3, ptr %t71, i64 %t72)
  store %"compiler/bindgen:ctype" %t73, ptr %l44
  br label %bb16
bb16:
  %t74 = getelementptr %"compiler/bindgen:ctype", ptr %l44, i32 0, i32 0
  %t75 = load i32, ptr %t74, !range !{i32 0, i32 7}
  %t77 = trunc i64 1 to i32
  %t78 = icmp eq i32 %t75, %t77
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l6, !tbaa !24
  br label %bb11
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eotherConsts(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/bindgen:cMacro"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/bindgen:cparse"
  %l11 = alloca %"compiler/bindgen:cx"
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca %"compiler/bindgen:cMacro"
  %l24 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l45 = alloca i1
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i32
  %l61 = alloca i1
  %l67 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca i1
  %l86 = alloca { i64, ptr }
  %l90 = alloca %"compiler/bindgen:cparse"
  %l91 = alloca %"compiler/bindgen:cx"
  %l94 = alloca %"compiler/bindgen:cx"
  %l95 = alloca i32
  %l97 = alloca i1
  %l102 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i1
  %l111 = alloca i64
  %l113 = alloca i1
  %l115 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l118 = alloca i1
  %l119 = alloca i1
  %l121 = alloca i64
  %l123 = alloca i1
  %l125 = alloca { i64, ptr }
  %l126 = alloca i1
  %l127 = alloca i1
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l132 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 12
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l15, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l17
  br label %bb2
bb2:
  %t9 = load i64, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb100
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/bindgen:cMacro" %t19, ptr %l22
  br label %bb6
bb6:
  %t20 = load %"compiler/bindgen:cMacro", ptr %l22
  store %"compiler/bindgen:cMacro" %t20, ptr %l3
  %t21 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t22, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store i1 %t24, ptr %l24
  br label %bb7
bb7:
  %t25 = load i1, ptr %l24, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb10
bb9:
  %t26 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 1
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t29 = load i1, ptr %l25, !tbaa !21
  br i1 %t29, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t30 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 4
  %t31 = load i1, ptr %t30, !tbaa !21
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb15:
  %t36 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t37)
  store i1 %t39, ptr %l32
  br label %bb16
bb16:
  %t40 = load i1, ptr %l32, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t43 = load i1, ptr %l30, !tbaa !21
  br i1 %t43, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb21
bb19:
  %t44 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/bindgen:gen", ptr %t47, i32 0, i32 10
  %t53 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t49, { i64, ptr } %t45)
  store i1 %t53, ptr %l39
  br label %bb20
bb20:
  %t54 = load i1, ptr %l39, !tbaa !21
  store i1 %t54, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb25
bb23:
  %t56 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/bindgen:gen", ptr %t59, i32 0, i32 21
  %t65 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t61, { i64, ptr } %t57)
  store i1 %t65, ptr %l45
  br label %bb24
bb24:
  %t66 = load i1, ptr %l45, !tbaa !21
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb25
bb25:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb99
bb27:
  br label %bb28
bb28:
  %t68 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t73 = icmp eq i64 %t71, 0
  br i1 %t73, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb99
bb30:
  br label %bb31
bb31:
  %t75 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l49
  br label %bb32
bb32:
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l6
  %t77 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = extractvalue { i64, ptr } %t78, 0
  %t82 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t80, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } %t84, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l6, { i64, ptr } %t91)
  br label %bb33
bb33:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 3
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t100 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %v0, ptr %s2, ptr %s2, ptr %t94, { i64, ptr } %t96, ptr %l6, i64 0)
  %t101 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t100, 1
  %t102 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t100, 0
  store i32 %t102, ptr %l59
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb35, label %ok.104, !prof !99
ok.104:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %l58
  br label %bb34
bb34:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l54
  br label %bb38
bb35:
  %t106 = load i32, ptr %l59, !tbaa !23
  %t107 = ashr i32 %t106, 16
  %t109 = icmp eq i32 %t107, 1
  store i1 %t109, ptr %l61, !tbaa !21
  br label %bb36
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/bindgen:gen", ptr %t113, i32 0, i32 25
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %v0, ptr %t110, { i64, ptr } %t112, { i64, ptr } %t116)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s2)
  br label %bb99
bb38:
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l7
  %t122 = call i64 @compiler_2fbindgen_2ebodyKind(ptr %s2, ptr %l7)
  store i64 %t122, ptr %l67
  br label %bb39
bb39:
  %t123 = load i64, ptr %l67, !tbaa !24
  store i64 %t123, ptr %l8, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t126 = icmp eq i64 %t124, 2
  br i1 %t126, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t129 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s2, ptr %s2, ptr %l7)
  store { i64, ptr } %t129, ptr %l71
  br label %bb42
bb41:
  br label %bb50
bb42:
  %t130 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t131 = call { i64, ptr } @compiler_2fbindgen_2etextLiteral(ptr %s2, ptr %s7, { i64, ptr } %t130)
  store { i64, ptr } %t131, ptr %l72
  br label %bb43
bb43:
  %t132 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t132, ptr %l9, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t133, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d224, i32 0, i32 1) })
  store i1 %t135, ptr %l74
  br label %bb44
bb44:
  %t136 = load i1, ptr %l74, !tbaa !21
  br i1 %t136, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %s8, ptr %t137, { i64, ptr } %t139, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d225, i32 0, i32 1) })
  br label %bb47
bb46:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t145 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t146, 1
  %t150 = extractvalue { i64, ptr } %t146, 0
  %t151 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t153 = add i64 %t150, %t152
  %t155 = extractvalue { i64, ptr } %t147, 1
  %t156 = extractvalue { i64, ptr } %t147, 0
  %t157 = add i64 %t153, %t156
  %t158 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t157)
  call void @olang_textcopy(ptr %t158, ptr %t149, i64 %t150)
  %t159 = getelementptr i8, ptr %t158, i64 %t150
  call void @olang_textcopy(ptr %t159, ptr %t151, i64 %t152)
  %t160 = getelementptr i8, ptr %t159, i64 %t152
  call void @olang_textcopy(ptr %t160, ptr %t155, i64 %t156)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t158, 1
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t165 = extractvalue { i64, ptr } %t162, 1
  %t166 = mul i64 %t164, 1
  %t167 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t166)
  call void @llvm.memcpy.p0.p0.i64(ptr %t167, ptr %t165, i64 %t166, i1 false)
  %t168 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enamedConst(ptr %v0, ptr %v0, ptr %v0, ptr %t142, { i64, ptr } %t144, { i64, ptr } %t169)
  br label %bb48
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s2)
  br label %bb99
bb50:
  %t173 = load i64, ptr %l8, !tbaa !24
  %t175 = icmp eq i64 %t173, 1
  br i1 %t175, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s11
  %t178 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s2, ptr %s2, ptr %l7)
  store { i64, ptr } %t178, ptr %l86
  br label %bb53
bb52:
  br label %bb97
bb53:
  %t179 = icmp sge i64 0, 0
  br i1 %t179, label %bb54, label %bb55
bb54:
  %t181 = icmp sle i64 0, 576460752303423487
  br i1 %t181, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_588cbeac7c6acbe1_e04f9e86f435a7f5)
  unreachable
bb56:
  %t183 = mul i64 0, 16
  %t184 = insertvalue { i64, ptr } undef, i64 0, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t186 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t188 = call %"compiler/bindgen:cparse" @compiler_2fbindgen_3acparse_2ector(ptr %s2, ptr %s11, ptr %s11, { i64, ptr } %t186, { i64, ptr } %t185)
  store %"compiler/bindgen:cparse" %t188, ptr %l90
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_588cbeac7c6acbe1_e04f9e86f435a7f5)
  unreachable
bb58:
  %t189 = load %"compiler/bindgen:cparse", ptr %l90
  store %"compiler/bindgen:cparse" %t189, ptr %l10
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t193 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %s11, ptr %s11, ptr %t190, ptr %l10)
  %t194 = extractvalue { i32, %"compiler/bindgen:cx" } %t193, 1
  %t195 = extractvalue { i32, %"compiler/bindgen:cx" } %t193, 0
  store i32 %t195, ptr %l95
  %t196 = icmp ne i32 %t195, 0
  br i1 %t196, label %bb60, label %ok.197, !prof !99
ok.197:
  store %"compiler/bindgen:cx" %t194, ptr %l94
  br label %bb59
bb59:
  %t198 = load %"compiler/bindgen:cx", ptr %l94
  store %"compiler/bindgen:cx" %t198, ptr %l91
  br label %bb63
bb60:
  %t199 = load i32, ptr %l95, !tbaa !23
  %t200 = ashr i32 %t199, 16
  %t202 = icmp eq i32 %t200, 1
  store i1 %t202, ptr %l97, !tbaa !21
  br label %bb61
bb61:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/bindgen:gen", ptr %t206, i32 0, i32 25
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %v0, ptr %t203, { i64, ptr } %t205, { i64, ptr } %t209)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s2)
  br label %bb99
bb63:
  %t213 = load %"compiler/bindgen:cx", ptr %l91
  store %"compiler/bindgen:cx" %t213, ptr %l11
  %t214 = getelementptr %"compiler/bindgen:cparse", ptr %l10, i32 0, i32 2
  %t215 = load i64, ptr %t214, !tbaa !24
  store i64 %t215, ptr %l102, !tbaa !24
  %t217 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l7)
  store i64 %t217, ptr %l104
  br label %bb64
bb64:
  %t218 = load i64, ptr %l102, !tbaa !24
  %t219 = load i64, ptr %l104, !tbaa !24
  %t220 = icmp eq i64 %t218, %t219
  br i1 %t220, label %bb65, label %bb66
bb65:
  %t222 = getelementptr %"compiler/bindgen:cx", ptr %l11, i32 0, i32 1
  %t223 = load i64, ptr %t222, !tbaa !24
  %t224 = load i64, ptr @G_2ecompiler_2fbindgen_2eKFloat, !tbaa !24
  %t227 = icmp eq i64 %t223, %t224
  store i1 %t227, ptr %l106, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb67
bb67:
  %t229 = load i1, ptr %l106, !tbaa !21
  br i1 %t229, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s13
  %t231 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l7)
  store i64 %t231, ptr %l111
  br label %bb70
bb69:
  br label %bb96
bb70:
  %t232 = load i64, ptr %l111, !tbaa !24
  %t233 = icmp eq i64 %t232, 1
  br i1 %t233, label %bb71, label %bb72
bb71:
  %t236 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l7, i64 0)
  store { i64, ptr } %t236, ptr %l115
  br label %bb73
bb72:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb76
bb73:
  %t237 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t238 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %s2, ptr %s13, { i64, ptr } %t237)
  store { i64, ptr } %t238, ptr %l116
  br label %bb74
bb74:
  %t239 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  %t241 = extractvalue { i64, ptr } %t239, 1
  %t242 = mul i64 %t240, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  %t247 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s13, ptr %s13, { i64, ptr } %t245, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) })
  store i1 %t247, ptr %l118
  br label %bb75
bb75:
  %t248 = load i1, ptr %l118, !tbaa !21
  store i1 %t248, ptr %l113, !tbaa !21
  br label %bb76
bb76:
  %t249 = load i1, ptr %l113, !tbaa !21
  br i1 %t249, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb91
bb78:
  %t251 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l7)
  store i64 %t251, ptr %l121
  br label %bb79
bb79:
  %t252 = load i64, ptr %l121, !tbaa !24
  %t253 = icmp eq i64 %t252, 3
  br i1 %t253, label %bb80, label %bb81
bb80:
  %t256 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l7, i64 0)
  store { i64, ptr } %t256, ptr %l125
  br label %bb82
bb81:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb84
bb82:
  %t257 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t258 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s13, { i64, ptr } %t257, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d228, i32 0, i32 1) })
  store i1 %t258, ptr %l126
  br label %bb83
bb83:
  %t259 = load i1, ptr %l126, !tbaa !21
  store i1 %t259, ptr %l123, !tbaa !21
  br label %bb84
bb84:
  %t260 = load i1, ptr %l123, !tbaa !21
  br i1 %t260, label %bb85, label %bb86
bb85:
  %t262 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l7, i64 1)
  store { i64, ptr } %t262, ptr %l129
  br label %bb87
bb86:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb90
bb87:
  %t263 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t264 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %s2, ptr %s13, { i64, ptr } %t263)
  store { i64, ptr } %t264, ptr %l130
  br label %bb88
bb88:
  %t265 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  %t267 = extractvalue { i64, ptr } %t265, 1
  %t268 = mul i64 %t266, 1
  %t269 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t268)
  call void @llvm.memcpy.p0.p0.i64(ptr %t269, ptr %t267, i64 %t268, i1 false)
  %t270 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  %t273 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s13, ptr %s13, { i64, ptr } %t271, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d229, i32 0, i32 1) })
  store i1 %t273, ptr %l132
  br label %bb89
bb89:
  %t274 = load i1, ptr %l132, !tbaa !21
  store i1 %t274, ptr %l127, !tbaa !21
  br label %bb90
bb90:
  %t275 = load i1, ptr %l127, !tbaa !21
  store i1 %t275, ptr %l119, !tbaa !21
  br label %bb91
bb91:
  %t276 = load i1, ptr %l119, !tbaa !21
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l133, !tbaa !29
  %t278 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t279 = load { i64, ptr }, ptr %t278, !tbaa !27
  store { i64, ptr } %t279, ptr %l134, !tbaa !27
  %t280 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !27
  store { i64, ptr } %t281, ptr %l135, !tbaa !27
  br i1 %t276, label %bb92, label %bb93
bb92:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d230, i32 0, i32 1) }, ptr %l137, !tbaa !27
  br label %bb94
bb93:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d231, i32 0, i32 1) }, ptr %l137, !tbaa !27
  br label %bb94
bb94:
  %t284 = getelementptr %"compiler/bindgen:cx", ptr %l11, i32 0, i32 0
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  %t286 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t292 = add i64 %t288, %t291
  %t294 = extractvalue { i64, ptr } %t285, 1
  %t295 = extractvalue { i64, ptr } %t285, 0
  %t296 = add i64 %t292, %t295
  %t297 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t296)
  call void @olang_textcopy(ptr %t297, ptr %t287, i64 %t288)
  %t298 = getelementptr i8, ptr %t297, i64 %t288
  call void @olang_textcopy(ptr %t298, ptr %t290, i64 %t291)
  %t299 = getelementptr i8, ptr %t298, i64 %t291
  call void @olang_textcopy(ptr %t299, ptr %t294, i64 %t295)
  %t300 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t297, 1
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t304 = extractvalue { i64, ptr } %t301, 1
  %t305 = mul i64 %t303, 1
  %t306 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t305)
  call void @llvm.memcpy.p0.p0.i64(ptr %t306, ptr %t304, i64 %t305, i1 false)
  %t307 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  %t309 = load ptr, ptr %l133, !tbaa !29
  %t310 = load { i64, ptr }, ptr %l134, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enamedConst(ptr %v0, ptr %v0, ptr %v0, ptr %t309, { i64, ptr } %t310, { i64, ptr } %t308)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s2)
  br label %bb99
bb96:
  call void @__olang_scope_close(ptr %s11)
  br label %bb97
bb97:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %s2, ptr %t312, { i64, ptr } %t314, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d232, i32 0, i32 1) })
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s2)
  br label %bb99
bb99:
  %t317 = load i64, ptr %l2, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l2, !tbaa !24
  br label %bb1
bb100:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i1
  %l54 = alloca i1
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l13, !tbaa !27
  %t10 = load i64, ptr %l4, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp eq i8 %t15, 95
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l12, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = add i64 %t22, 1
  store i64 %t24, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t26, ptr %l20, !tbaa !27
  %t27 = load i64, ptr %l4, !tbaa !24
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t28, 0
  store i64 %t31, ptr %l24, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l25, !tbaa !24
  %t34 = load i64, ptr %l21, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = load i64, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_76a2c5c4ca94453d_57e44e0801590749)
  unreachable
bb12:
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_76a2c5c4ca94453d_57e44e0801590749)
  unreachable
bb14:
  %t45 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l21, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = getelementptr i8, ptr %t46, i64 %t47
  %t50 = sub i64 %t48, %t47
  %t51 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  %t54 = extractvalue { i64, ptr } %t52, 1
  %t55 = extractvalue { i64, ptr } %t52, 0
  %t56 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t54, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t59, ptr %lp5
  %t61 = load ptr, ptr %lp5
  store { i64, ptr } %t58, ptr %t61, !tbaa !27
  %t62 = load ptr, ptr %lp5
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t65 = call i1 @compiler_2fbindgen_2eusable(ptr %v3, { i64, ptr } %t63)
  store i1 %t65, ptr %l32
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_76a2c5c4ca94453d_57e44e0801590749)
  unreachable
bb16:
  %t66 = load i1, ptr %l32, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb20
bb18:
  %t69 = load ptr, ptr %lp5
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l35, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l36, !tbaa !24
  %t73 = load i64, ptr %l36, !tbaa !24
  %t74 = mul i64 %t73, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l37, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l36, !tbaa !24
  %t83 = mul i64 %t82, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t79, ptr %t81, i64 %t83, i1 false)
  %t84 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t87 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 21
  %t91 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %s0, ptr %t87, { i64, ptr } %t84)
  store i1 %t91, ptr %l41
  br label %bb19
bb19:
  %t92 = load i1, ptr %l41, !tbaa !21
  store i1 %t92, ptr %l34, !tbaa !21
  br label %bb20
bb20:
  %t93 = load i1, ptr %l34, !tbaa !21
  br i1 %t93, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb24
bb22:
  %t94 = load ptr, ptr %lp5
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l43, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l44, !tbaa !24
  %t98 = load i64, ptr %l44, !tbaa !24
  %t99 = mul i64 %t98, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l45, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l44, !tbaa !24
  %t108 = mul i64 %t107, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t104, ptr %t106, i64 %t108, i1 false)
  %t109 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t114 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v2, ptr %s0, ptr %t110, { i64, ptr } %t109)
  store i1 %t114, ptr %l48
  br label %bb23
bb23:
  %t115 = load i1, ptr %l48, !tbaa !21
  store i1 %t115, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t116 = load i1, ptr %l42, !tbaa !21
  br i1 %t116, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb28
bb26:
  %t117 = load ptr, ptr %lp5
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t118, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d233, i32 0, i32 1) })
  store i1 %t120, ptr %l51
  br label %bb27
bb27:
  %t121 = load i1, ptr %l51, !tbaa !21
  store i1 %t121, ptr %l49, !tbaa !21
  br label %bb28
bb28:
  %t122 = load i1, ptr %l49, !tbaa !21
  br i1 %t122, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb32
bb30:
  %t123 = load ptr, ptr %lp5
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t124, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d234, i32 0, i32 1) })
  store i1 %t126, ptr %l54
  br label %bb31
bb31:
  %t127 = load i1, ptr %l54, !tbaa !21
  store i1 %t127, ptr %l52, !tbaa !21
  br label %bb32
bb32:
  %t128 = load i1, ptr %l52, !tbaa !21
  br i1 %t128, label %bb33, label %bb34
bb33:
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t133 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t134 = add i64 %t131, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t130, i64 %t131)
  %t136 = getelementptr i8, ptr %t135, i64 %t131
  %t137 = call i64 @__olang_fmt_i64(ptr %t136, i64 %a2)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t135, 1
  store { i64, ptr } %t139, ptr %l56, !tbaa !27
  %t140 = load ptr, ptr %lp5
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l58, !tbaa !24
  %t146 = load i64, ptr %l58, !tbaa !24
  %t147 = icmp eq i64 %t142, %t146
  br i1 %t147, label %bb35, label %bb36
bb34:
  br label %bb38
bb35:
  %t149 = load ptr, ptr %lp5
  %t150 = getelementptr { i64, ptr }, ptr %t149, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = mul i64 %t154, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t151, ptr %t153, i64 %t155, i1 false)
  br label %bb37
bb36:
  %t156 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t157 = load ptr, ptr %lp5
  store { i64, ptr } %t156, ptr %t157, !tbaa !27
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t158 = load ptr, ptr %l3, !tbaa !29
  %t159 = load ptr, ptr %lp5
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 1
  %t163 = extractvalue { i64, ptr } %t160, 0
  %t164 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t163)
  call void @olang_textcopy(ptr %t164, ptr %t162, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = extractvalue { i64, ptr } %t166, 1
  %t170 = mul i64 %t168, 1
  %t171 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t170)
  call void @llvm.memcpy.p0.p0.i64(ptr %t171, ptr %t169, i64 %t170, i1 false)
  %t172 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v2, ptr %v2, ptr %t158, { i64, ptr } %t173, i64 0)
  br label %bb39
bb39:
  %t176 = load ptr, ptr %lp5
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t177, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca %"compiler/bindgen:record"
  %l20 = alloca %"compiler/bindgen:record"
  %l32 = alloca ptr
  %l38 = alloca %"compiler/bindgen:record"
  %l40 = alloca %"compiler/bindgen:record"
  %l42 = alloca i1
  %l46 = alloca %"compiler/bindgen:record"
  %l48 = alloca %"compiler/bindgen:record"
  %l51 = alloca i1
  %l55 = alloca %"compiler/bindgen:record"
  %l57 = alloca %"compiler/bindgen:record"
  %l60 = alloca i1
  %l64 = alloca %"compiler/bindgen:record"
  %l66 = alloca %"compiler/bindgen:record"
  %l73 = alloca %"compiler/bindgen:record"
  %l75 = alloca %"compiler/bindgen:record"
  %l77 = alloca i64
  %l79 = alloca i64
  %l85 = alloca { i64, ptr }
  %l89 = alloca %"compiler/bindgen:record"
  %l91 = alloca %"compiler/bindgen:record"
  %l94 = alloca { i64, ptr }
  %l95 = alloca i1
  %l98 = alloca i64
  %l102 = alloca %"compiler/bindgen:ctype"
  %l108 = alloca %"compiler/bindgen:ctype"
  %l110 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca i32
  %l116 = alloca i1
  %l121 = alloca i64
  %l125 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  %t5 = alloca %"compiler/bindgen:record", align 8
  %t8 = alloca %"compiler/bindgen:record", align 8
  %t42 = alloca %"compiler/bindgen:record", align 8
  %t45 = alloca %"compiler/bindgen:record", align 8
  %t54 = alloca %"compiler/bindgen:record", align 8
  %t57 = alloca %"compiler/bindgen:record", align 8
  %t69 = alloca %"compiler/bindgen:record", align 8
  %t72 = alloca %"compiler/bindgen:record", align 8
  %t84 = alloca %"compiler/bindgen:record", align 8
  %t87 = alloca %"compiler/bindgen:record", align 8
  %t101 = alloca %"compiler/bindgen:record", align 8
  %t104 = alloca %"compiler/bindgen:record", align 8
  %t130 = alloca %"compiler/bindgen:record", align 8
  %t133 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t5, ptr %v0, ptr %s0, ptr %t3, i64 %t4)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t5, i64 176, i1 false)
  br label %bb1
bb1:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t8, ptr %s0, ptr %l18)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t8, i64 176, i1 false)
  br label %bb2
bb2:
  %t10 = getelementptr %"compiler/bindgen:record", ptr %l20, i32 0, i32 9
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp eq i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp sge i64 %t18, 1
  br i1 %t20, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/bindgen:gen", ptr %t25, i32 0, i32 5
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t27, i64 %t23)
  store ptr %t31, ptr %l32
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l32, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = getelementptr %"compiler/bindgen:record", ptr %t32, i32 0, i32 9
  store i64 %t34, ptr %t37, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/bindgen:gen", ptr %t38, i32 0, i32 5
  %t41 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t42, ptr %v0, ptr %s0, ptr %t40, i64 %t41)
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t42, i64 176, i1 false)
  br label %bb10
bb10:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t45, ptr %s0, ptr %l38)
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %t45, i64 176, i1 false)
  br label %bb11
bb11:
  %t47 = getelementptr %"compiler/bindgen:record", ptr %l40, i32 0, i32 2
  %t48 = load i1, ptr %t47, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/bindgen:gen", ptr %t50, i32 0, i32 5
  %t53 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t54, ptr %v0, ptr %s0, ptr %t52, i64 %t53)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t54, i64 176, i1 false)
  br label %bb14
bb13:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb16
bb14:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t57, ptr %s0, ptr %l46)
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t57, i64 176, i1 false)
  br label %bb15
bb15:
  %t59 = getelementptr %"compiler/bindgen:record", ptr %l48, i32 0, i32 3
  %t60 = load i1, ptr %t59, !tbaa !21
  %t62 = xor i1 %t60, true
  store i1 %t62, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l42, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/bindgen:gen", ptr %t65, i32 0, i32 5
  %t68 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t69, ptr %v0, ptr %s0, ptr %t67, i64 %t68)
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %t69, i64 176, i1 false)
  br label %bb19
bb18:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb21
bb19:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t72, ptr %s0, ptr %l55)
  call void @llvm.memmove.p0.p0.i64(ptr %l57, ptr %t72, i64 176, i1 false)
  br label %bb20
bb20:
  %t74 = getelementptr %"compiler/bindgen:record", ptr %l57, i32 0, i32 1
  %t75 = load i1, ptr %t74, !tbaa !21
  %t77 = xor i1 %t75, true
  store i1 %t77, ptr %l51, !tbaa !21
  br label %bb21
bb21:
  %t79 = load i1, ptr %l51, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/bindgen:gen", ptr %t80, i32 0, i32 5
  %t83 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t84, ptr %v0, ptr %s0, ptr %t82, i64 %t83)
  call void @llvm.memmove.p0.p0.i64(ptr %l64, ptr %t84, i64 176, i1 false)
  br label %bb24
bb23:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb26
bb24:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t87, ptr %s0, ptr %l64)
  call void @llvm.memmove.p0.p0.i64(ptr %l66, ptr %t87, i64 176, i1 false)
  br label %bb25
bb25:
  %t89 = getelementptr %"compiler/bindgen:record", ptr %l66, i32 0, i32 10
  %t90 = load i1, ptr %t89, !tbaa !21
  %t92 = xor i1 %t90, true
  store i1 %t92, ptr %l60, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l60, !tbaa !21
  store i1 %t94, ptr %l6, !tbaa !21
  %t95 = load i1, ptr %l6, !tbaa !21
  br i1 %t95, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/bindgen:gen", ptr %t97, i32 0, i32 5
  %t100 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t101, ptr %v0, ptr %v0, ptr %t99, i64 %t100)
  call void @llvm.memmove.p0.p0.i64(ptr %l73, ptr %t101, i64 176, i1 false)
  br label %bb29
bb28:
  br label %bb56
bb29:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t104, ptr %v0, ptr %l73)
  call void @llvm.memmove.p0.p0.i64(ptr %l75, ptr %t104, i64 176, i1 false)
  br label %bb30
bb30:
  %t106 = getelementptr %"compiler/bindgen:record", ptr %l75, i32 0, i32 5
  store ptr %t106, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = load i64, ptr %l8, !tbaa !24
  store i64 %t108, ptr %l77, !tbaa !24
  %t109 = load ptr, ptr %l7, !tbaa !29
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s4, ptr %t109)
  store i64 %t111, ptr %l79
  br label %bb32
bb32:
  %t112 = load i64, ptr %l77, !tbaa !24
  %t113 = load i64, ptr %l79, !tbaa !24
  %t114 = icmp slt i64 %t112, %t113
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb34:
  br label %bb35
bb35:
  %t118 = load i64, ptr %l8, !tbaa !24
  store i64 %t118, ptr %l9, !tbaa !24
  %t120 = load ptr, ptr %l7, !tbaa !29
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s4, ptr %s4, ptr %t120, i64 %t121)
  store { i64, ptr } %t124, ptr %l85
  br label %bb36
bb36:
  %t125 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t125, ptr %l10, !tbaa !27
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/bindgen:gen", ptr %t126, i32 0, i32 5
  %t129 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t130, ptr %v0, ptr %v0, ptr %t128, i64 %t129)
  call void @llvm.memmove.p0.p0.i64(ptr %l89, ptr %t130, i64 176, i1 false)
  br label %bb37
bb37:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t133, ptr %v0, ptr %l89)
  call void @llvm.memmove.p0.p0.i64(ptr %l91, ptr %t133, i64 176, i1 false)
  br label %bb38
bb38:
  %t135 = getelementptr %"compiler/bindgen:record", ptr %l91, i32 0, i32 4
  %t136 = load i64, ptr %l9, !tbaa !24
  %t139 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s5, ptr %t135, i64 %t136)
  store { i64, ptr } %t139, ptr %l94
  br label %bb39
bb39:
  %t140 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %s5, { i64, ptr } %t140, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d236, i32 0, i32 1) })
  store i1 %t141, ptr %l95
  br label %bb40
bb40:
  %t142 = load i1, ptr %l95, !tbaa !21
  br i1 %t142, label %bb41, label %bb42
bb41:
  store i1 false, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb42:
  br label %bb43
bb43:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t147 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s4, ptr %t143, { i64, ptr } %t144, i64 0)
  store i64 %t147, ptr %l98
  br label %bb44
bb44:
  %t148 = load i64, ptr %l98, !tbaa !24
  store i64 %t148, ptr %l11, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/bindgen:gen", ptr %t149, i32 0, i32 16
  %t152 = load i64, ptr %l11, !tbaa !24
  %t155 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s5, ptr %t151, i64 %t152)
  store %"compiler/bindgen:ctype" %t155, ptr %l102
  br label %bb45
bb45:
  %t156 = getelementptr %"compiler/bindgen:ctype", ptr %l102, i32 0, i32 0
  %t157 = load i32, ptr %t156, !range !{i32 0, i32 7}
  %t159 = trunc i64 4 to i32
  %t160 = icmp eq i32 %t157, %t159
  br i1 %t160, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s7
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/bindgen:gen", ptr %t162, i32 0, i32 16
  %t165 = load i64, ptr %l11, !tbaa !24
  %t168 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s7, ptr %t164, i64 %t165)
  store %"compiler/bindgen:ctype" %t168, ptr %l108
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t169 = getelementptr %"compiler/bindgen:ctype", ptr %l108, i32 0, i32 2
  %t170 = load i64, ptr %t169, !tbaa !24
  store i64 %t170, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb49:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i64, ptr %l11, !tbaa !24
  %t176 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %s5, ptr %t172, i64 %t173)
  %t177 = extractvalue { i32, { i64, ptr } } %t176, 1
  %t178 = extractvalue { i32, { i64, ptr } } %t176, 0
  store i32 %t178, ptr %l114
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb51, label %ok.180, !prof !99
ok.180:
  store { i64, ptr } %t177, ptr %l113
  br label %bb50
bb50:
  %t181 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t181, ptr %l110, !tbaa !27
  br label %bb53
bb51:
  %t182 = load i32, ptr %l114, !tbaa !23
  %t183 = ashr i32 %t182, 16
  %t185 = icmp eq i32 %t183, 1
  store i1 %t185, ptr %l116, !tbaa !21
  br label %bb52
bb52:
  store i1 false, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb53:
  call void @__olang_scope_close(ptr %s5)
  br label %bb54
bb54:
  %t186 = load i64, ptr %l8, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l8, !tbaa !24
  br label %bb31
bb55:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb56:
  %t190 = load i64, ptr %l1, !tbaa !24
  store i64 %t190, ptr %l12, !tbaa !24
  %t192 = load i1, ptr %l6, !tbaa !21
  br i1 %t192, label %bb57, label %bb58
bb57:
  store i64 1, ptr %l121, !tbaa !24
  br label %bb59
bb58:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb59
bb59:
  %t194 = load i64, ptr %l121, !tbaa !24
  store i64 %t194, ptr %l13, !tbaa !24
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/bindgen:gen", ptr %t195, i32 0, i32 5
  %t198 = load i64, ptr %l12, !tbaa !24
  %t201 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t197, i64 %t198)
  store ptr %t201, ptr %l125
  br label %bb60
bb60:
  %t202 = load ptr, ptr %l125, !tbaa !29
  %t204 = load i64, ptr %l13, !tbaa !24
  %t207 = getelementptr %"compiler/bindgen:record", ptr %t202, i32 0, i32 9
  store i64 %t204, ptr %t207, !tbaa !24
  %t208 = load i1, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t208, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epointerParam(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/bindgen:ctype"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca %"compiler/bindgen:ctype"
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca %"compiler/bindgen:ctype"
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l39 = alloca i64
  %l41 = alloca i1
  %l44 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l56 = alloca %"compiler/bindgen:ctype"
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l68 = alloca i64
  %l71 = alloca i1
  %l75 = alloca { i64, ptr }
  %l79 = alloca i1
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l91 = alloca i1
  %l93 = alloca i32
  %l95 = alloca %"std/prelude/text:StringBuilder"
  %l101 = alloca i64
  %l104 = alloca i64
  %l125 = alloca ptr
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l134 = alloca i64
  %l135 = alloca { i64, ptr }
  %l136 = alloca i32
  %l146 = alloca %"compiler/bindgen:ctype"
  %l150 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i32
  %l160 = alloca { i64, ptr }
  %l165 = alloca i32
  %l168 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 16
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/bindgen:ctype" %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l19
  store %"compiler/bindgen:ctype" %t8, ptr %l3
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 0
  %t10 = load i32, ptr %t9, !range !{i32 0, i32 7}
  store i32 %t10, ptr %l4
  %t12 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb12
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d237, i32 0, i32 1) })
  store i1 %t20, ptr %l24
  br label %bb5
bb5:
  %t21 = load i1, ptr %l24, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d238, i32 0, i32 1) }, ptr %l25, !tbaa !27
  br label %bb8
bb7:
  %t22 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l25, !tbaa !27
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  %t39 = load i1, ptr %l2, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t42 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = extractvalue { i64, ptr } %t41, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t42, i64 %t43)
  %t52 = getelementptr i8, ptr %t51, i64 %t43
  call void @olang_textcopy(ptr %t52, ptr %t45, i64 %t46)
  %t53 = getelementptr i8, ptr %t52, i64 %t46
  call void @olang_textcopy(ptr %t53, ptr %t48, i64 %t49)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t51, 1
  store { i64, ptr } %t55, ptr %l30, !tbaa !27
  br label %bb11
bb10:
  %t57 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t58 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t61 = extractvalue { i64, ptr } %t57, 1
  %t62 = extractvalue { i64, ptr } %t57, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t58, i64 %t59)
  %t68 = getelementptr i8, ptr %t67, i64 %t59
  call void @olang_textcopy(ptr %t68, ptr %t61, i64 %t62)
  %t69 = getelementptr i8, ptr %t68, i64 %t62
  call void @olang_textcopy(ptr %t69, ptr %t64, i64 %t65)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t67, 1
  store { i64, ptr } %t71, ptr %l30, !tbaa !27
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  %t73 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t74 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t73, 1
  store { i32, { i64, ptr } } %t74, ptr %rv
  br label %ret
bb12:
  %t75 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t77 = trunc i64 2 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb25
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t85 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t80, { i64, ptr } %t82)
  store i64 %t85, ptr %l39
  br label %bb16
bb16:
  %t86 = load i64, ptr %l39, !tbaa !24
  store i64 %t86, ptr %l6, !tbaa !24
  %t87 = load i1, ptr %l2, !tbaa !21
  br i1 %t87, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb20
bb18:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t93, ptr %l44
  br label %bb19
bb19:
  %t94 = load i1, ptr %l44, !tbaa !21
  %t95 = xor i1 %t94, true
  store i1 %t95, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t97 = load i1, ptr %l41, !tbaa !21
  br i1 %t97, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d243, i32 0, i32 1) }, ptr %l46, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d244, i32 0, i32 1) }, ptr %l46, !tbaa !27
  br label %bb23
bb23:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s5, ptr %t98, i64 %t99)
  store { i64, ptr } %t102, ptr %l49
  br label %bb24
bb24:
  %t103 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = add i64 %t105, %t108
  %t110 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t112 = add i64 %t109, %t111
  %t113 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t104, i64 %t105)
  %t114 = getelementptr i8, ptr %t113, i64 %t105
  call void @olang_textcopy(ptr %t114, ptr %t107, i64 %t108)
  %t115 = getelementptr i8, ptr %t114, i64 %t108
  call void @olang_textcopy(ptr %t115, ptr %t110, i64 %t111)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t113, 1
  call void @__olang_scope_close(ptr %s5)
  %t119 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t117, 1
  store { i32, { i64, ptr } } %t119, ptr %rv
  br label %ret
bb25:
  %t120 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t122 = trunc i64 3 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb50
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/bindgen:gen", ptr %t125, i32 0, i32 16
  %t128 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t129 = load i64, ptr %t128, !tbaa !24
  %t132 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t127, i64 %t129)
  store %"compiler/bindgen:ctype" %t132, ptr %l56
  br label %bb29
bb29:
  %t133 = load %"compiler/bindgen:ctype", ptr %l56
  store %"compiler/bindgen:ctype" %t133, ptr %l7
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t136 = load i64, ptr %t135, !tbaa !24
  %t139 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisChar(ptr %v0, ptr %t134, i64 %t136)
  store i1 %t139, ptr %l59
  br label %bb30
bb30:
  %t140 = load i1, ptr %l59, !tbaa !21
  br i1 %t140, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d246, i32 0, i32 1) }, ptr %l60, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t141, ptr %l61, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l62, !tbaa !24
  %t144 = load i64, ptr %l62, !tbaa !24
  %t145 = mul i64 %t144, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l63, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l62, !tbaa !24
  %t154 = mul i64 %t153, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %t152, i64 %t154, i1 false)
  %t155 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t155, ptr %l61, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t157 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t156, 1
  store { i32, { i64, ptr } } %t157, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t158 = getelementptr %"compiler/bindgen:ctype", ptr %l7, i32 0, i32 0
  %t159 = load i32, ptr %t158, !range !{i32 0, i32 7}
  %t161 = trunc i64 2 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb34, label %bb35
bb34:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/bindgen:ctype", ptr %l7, i32 0, i32 1
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  %t169 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t164, { i64, ptr } %t166)
  store i64 %t169, ptr %l68
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t170 = load i64, ptr %l68, !tbaa !24
  store i64 %t170, ptr %l8, !tbaa !24
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i64, ptr %l8, !tbaa !24
  %t175 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t171, i64 %t172)
  store i1 %t175, ptr %l71
  br label %bb37
bb37:
  %t176 = load i1, ptr %l71, !tbaa !21
  %t177 = xor i1 %t176, true
  br i1 %t177, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l8, !tbaa !24
  %t183 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s10, ptr %t179, i64 %t180)
  store { i64, ptr } %t183, ptr %l75
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t184 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t186 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t184, i64 %t185)
  %t194 = getelementptr i8, ptr %t193, i64 %t185
  call void @olang_textcopy(ptr %t194, ptr %t187, i64 %t188)
  %t195 = getelementptr i8, ptr %t194, i64 %t188
  call void @olang_textcopy(ptr %t195, ptr %t190, i64 %t191)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t193, 1
  call void @__olang_scope_close(ptr %s10)
  %t199 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t197, 1
  store { i32, { i64, ptr } } %t199, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t200 = getelementptr %"compiler/bindgen:ctype", ptr %l7, i32 0, i32 0
  %t201 = load i32, ptr %t200, !range !{i32 0, i32 7}
  %t203 = trunc i64 0 to i32
  %t204 = icmp eq i32 %t201, %t203
  br i1 %t204, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb45
bb44:
  %t206 = getelementptr %"compiler/bindgen:ctype", ptr %l7, i32 0, i32 0
  %t207 = load i32, ptr %t206, !range !{i32 0, i32 7}
  %t209 = trunc i64 2 to i32
  %t210 = icmp eq i32 %t207, %t209
  store i1 %t210, ptr %l79, !tbaa !21
  br label %bb45
bb45:
  %t212 = load i1, ptr %l79, !tbaa !21
  br i1 %t212, label %bb46, label %bb47
bb46:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d249, i32 0, i32 1) }, ptr %l82, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t213, ptr %l83, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 0
  store i64 %t215, ptr %l84, !tbaa !24
  %t216 = load i64, ptr %l84, !tbaa !24
  %t217 = mul i64 %t216, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t217)
  %t219 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  store { i64, ptr } %t220, ptr %l85, !tbaa !27
  %t221 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = load i64, ptr %l84, !tbaa !24
  %t226 = mul i64 %t225, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t222, ptr %t224, i64 %t226, i1 false)
  %t227 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t227, ptr %l83, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t229 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t228, 1
  store { i32, { i64, ptr } } %t229, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t230 = load i1, ptr %l2, !tbaa !21
  %t232 = call { i64, ptr } @compiler_2fbindgen_2evoidRef(ptr %v1, i1 %t230)
  store { i64, ptr } %t232, ptr %l87
  br label %bb49
bb49:
  %t233 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t234 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t233, 1
  store { i32, { i64, ptr } } %t234, ptr %rv
  br label %ret
bb50:
  %t235 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t237 = trunc i64 5 to i32
  %t238 = icmp eq i32 %t235, %t237
  br i1 %t238, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb94
bb53:
  store %olang.scope zeroinitializer, ptr %s13
  %t240 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  %t243 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s13, { i64, ptr } %t241, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d250, i32 0, i32 1) })
  store i1 %t243, ptr %l91
  br label %bb54
bb54:
  %t244 = load i1, ptr %l91, !tbaa !21
  br i1 %t244, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s14
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s14, ptr %t245, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d251, i32 0, i32 1) })
  store i32 %t247, ptr %l93
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb58, label %ok.249, !prof !99
ok.249:
  br label %bb57
bb56:
  br label %bb60
bb57:
  br label %bb59
bb58:
  %t250 = load i32, ptr %l93, !tbaa !23
  %t251 = lshr i32 %t250, 16
  %t252 = and i32 %t250, 65535
  %t253 = icmp eq i32 %t251, 1
  %t254 = select i1 %t253, i32 1, i32 0
  %t255 = icmp eq i32 %t250, 0
  %t256 = shl i32 %t254, 16
  %t257 = or i32 %t256, %t252
  %t258 = select i1 %t255, i32 0, i32 %t257
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  %t260 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t258, 0
  store { i32, { i64, ptr } } %t260, ptr %rv
  br label %ret
bb59:
  call void @__olang_scope_close(ptr %s14)
  br label %bb60
bb60:
  %t261 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s13)
  store %"std/prelude/text:StringBuilder" %t261, ptr %l95
  br label %bb61
bb61:
  %t262 = load %"std/prelude/text:StringBuilder", ptr %l95
  store %"std/prelude/text:StringBuilder" %t262, ptr %l9
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l9, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d252, i32 0, i32 1) })
  br label %bb62
bb62:
  store i64 0, ptr %l10, !tbaa !24
  %t264 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 4
  %t265 = load i64, ptr %t264, !tbaa !24
  store i64 %t265, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t267 = load i64, ptr %l11, !tbaa !24
  %t268 = load i64, ptr %l10, !tbaa !24
  %t271 = icmp sgt i64 %t267, %t268
  br i1 %t271, label %bb63, label %bb64
bb63:
  %t273 = load i64, ptr %l12, !tbaa !24
  %t275 = icmp sgt i64 %t273, 0
  br i1 %t275, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb68
bb65:
  %t277 = load i64, ptr %l11, !tbaa !24
  %t278 = load i64, ptr %l10, !tbaa !24
  %t281 = sub i64 %t277, %t278
  %t282 = load i64, ptr %l12, !tbaa !24
  %t285 = add i64 %t281, %t282
  %t287 = sub i64 %t285, 1
  %t288 = load i64, ptr %l12, !tbaa !24
  %t291 = sdiv i64 %t287, %t288
  store i64 %t291, ptr %l104, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb67
bb67:
  %t293 = load i64, ptr %l104, !tbaa !24
  store i64 %t293, ptr %l101, !tbaa !24
  br label %bb68
bb68:
  %t294 = load i64, ptr %l101, !tbaa !24
  store i64 %t294, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s16
  %t295 = load i64, ptr %l14, !tbaa !24
  %t296 = load i64, ptr %l13, !tbaa !24
  %t299 = icmp slt i64 %t295, %t296
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s16)
  br label %bb83
bb71:
  br label %bb72
bb72:
  %t303 = load i64, ptr %l10, !tbaa !24
  %t304 = load i64, ptr %l14, !tbaa !24
  %t305 = load i64, ptr %l12, !tbaa !24
  %t308 = mul i64 %t304, %t305
  %t311 = add i64 %t303, %t308
  store i64 %t311, ptr %l15, !tbaa !24
  %t313 = load i64, ptr %l15, !tbaa !24
  %t315 = icmp sgt i64 %t313, 0
  br i1 %t315, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s17
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s17, ptr %l9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d253, i32 0, i32 1) })
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s17)
  br label %bb76
bb76:
  store ptr %l9, ptr %l125, !tbaa !29
  %t318 = load i64, ptr %l15, !tbaa !24
  store i64 %t318, ptr %l126, !tbaa !24
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l128, !tbaa !29
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/bindgen:gen", ptr %t320, i32 0, i32 17
  %t323 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 5
  %t324 = load i64, ptr %t323, !tbaa !24
  %t325 = load i64, ptr %l15, !tbaa !24
  %t328 = add i64 %t324, %t325
  %t331 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t322, i64 %t328)
  store i64 %t331, ptr %l134
  br label %bb77
bb77:
  %t332 = load ptr, ptr %l128, !tbaa !29
  %t333 = load i64, ptr %l134, !tbaa !24
  %t334 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %s16, ptr %t332, i64 %t333, i1 true)
  %t335 = extractvalue { i32, { i64, ptr } } %t334, 1
  %t336 = extractvalue { i32, { i64, ptr } } %t334, 0
  store i32 %t336, ptr %l136
  %t337 = icmp ne i32 %t336, 0
  br i1 %t337, label %bb79, label %ok.338, !prof !99
ok.338:
  store { i64, ptr } %t335, ptr %l135
  br label %bb78
bb78:
  %t339 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t339, ptr %l127, !tbaa !27
  br label %bb80
bb79:
  %t340 = load i32, ptr %l136, !tbaa !23
  %t341 = lshr i32 %t340, 16
  %t342 = and i32 %t340, 65535
  %t343 = icmp eq i32 %t341, 1
  %t344 = select i1 %t343, i32 1, i32 0
  %t345 = icmp eq i32 %t340, 0
  %t346 = shl i32 %t344, 16
  %t347 = or i32 %t346, %t342
  %t348 = select i1 %t345, i32 0, i32 %t347
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s13)
  %t350 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t348, 0
  store { i32, { i64, ptr } } %t350, ptr %rv
  br label %ret
bb80:
  %t351 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t352 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t353 = load i64, ptr %l126, !tbaa !24
  %t354 = call i64 @__olang_fmt_i64(ptr null, i64 %t353)
  %t355 = add i64 %t352, %t354
  %t356 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t357 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t358 = add i64 %t355, %t357
  %t359 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 1
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t362 = add i64 %t358, %t361
  %t363 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t362)
  call void @olang_textcopy(ptr %t363, ptr %t351, i64 %t352)
  %t364 = getelementptr i8, ptr %t363, i64 %t352
  %t365 = call i64 @__olang_fmt_i64(ptr %t364, i64 %t353)
  %t366 = getelementptr i8, ptr %t364, i64 %t354
  call void @olang_textcopy(ptr %t366, ptr %t356, i64 %t357)
  %t367 = getelementptr i8, ptr %t366, i64 %t357
  call void @olang_textcopy(ptr %t367, ptr %t360, i64 %t361)
  %t368 = insertvalue { i64, ptr } undef, i64 %t362, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t363, 1
  %t371 = extractvalue { i64, ptr } %t369, 0
  %t372 = extractvalue { i64, ptr } %t369, 1
  %t373 = mul i64 %t371, 1
  %t374 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t374, ptr %t372, i64 %t373, i1 false)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  %t377 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s16, ptr %t377, { i64, ptr } %t376)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s16)
  br label %bb82
bb82:
  %t379 = load i64, ptr %l14, !tbaa !24
  %t381 = add i64 %t379, 1
  store i64 %t381, ptr %l14, !tbaa !24
  br label %bb69
bb83:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d256, i32 0, i32 1) })
  br label %bb84
bb84:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/bindgen:gen", ptr %t384, i32 0, i32 16
  %t387 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t388 = load i64, ptr %t387, !tbaa !24
  %t391 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s13, ptr %t386, i64 %t388)
  store %"compiler/bindgen:ctype" %t391, ptr %l146
  br label %bb85
bb85:
  %t392 = getelementptr %"compiler/bindgen:ctype", ptr %l146, i32 0, i32 0
  %t393 = load i32, ptr %t392, !range !{i32 0, i32 7}
  %t395 = trunc i64 0 to i32
  %t396 = icmp eq i32 %t393, %t395
  %t398 = xor i1 %t396, true
  br i1 %t398, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s20
  store ptr %l9, ptr %l150, !tbaa !29
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t402 = load i64, ptr %t401, !tbaa !24
  %t405 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %s20, ptr %t400, i64 %t402, i1 true)
  %t406 = extractvalue { i32, { i64, ptr } } %t405, 1
  %t407 = extractvalue { i32, { i64, ptr } } %t405, 0
  store i32 %t407, ptr %l155
  %t408 = icmp ne i32 %t407, 0
  br i1 %t408, label %bb89, label %ok.409, !prof !99
ok.409:
  store { i64, ptr } %t406, ptr %l154
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t410 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t410, ptr %l151, !tbaa !27
  br label %bb90
bb89:
  %t411 = load i32, ptr %l155, !tbaa !23
  %t412 = lshr i32 %t411, 16
  %t413 = and i32 %t411, 65535
  %t414 = icmp eq i32 %t412, 1
  %t415 = select i1 %t414, i32 1, i32 0
  %t416 = icmp eq i32 %t411, 0
  %t417 = shl i32 %t415, 16
  %t418 = or i32 %t417, %t413
  %t419 = select i1 %t416, i32 0, i32 %t418
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s13)
  %t421 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t419, 0
  store { i32, { i64, ptr } } %t421, ptr %rv
  br label %ret
bb90:
  %t422 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t423 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t424 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 1
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t427 = add i64 %t423, %t426
  %t428 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t427)
  call void @olang_textcopy(ptr %t428, ptr %t422, i64 %t423)
  %t429 = getelementptr i8, ptr %t428, i64 %t423
  call void @olang_textcopy(ptr %t429, ptr %t425, i64 %t426)
  %t430 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t428, 1
  %t433 = extractvalue { i64, ptr } %t431, 0
  %t434 = extractvalue { i64, ptr } %t431, 1
  %t435 = mul i64 %t433, 1
  %t436 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t435)
  call void @llvm.memcpy.p0.p0.i64(ptr %t436, ptr %t434, i64 %t435, i1 false)
  %t437 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t436, 1
  %t439 = load ptr, ptr %l150, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s20, ptr %t439, { i64, ptr } %t438)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s20)
  br label %bb92
bb92:
  %t442 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s13, ptr %v1, ptr %l9)
  store { i64, ptr } %t442, ptr %l160
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s13)
  %t443 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t444 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t443, 1
  store { i32, { i64, ptr } } %t444, ptr %rv
  br label %ret
bb94:
  %t445 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t447 = trunc i64 6 to i32
  %t448 = icmp eq i32 %t445, %t447
  br i1 %t448, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb101
bb97:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t452 = load { i64, ptr }, ptr %t451, !tbaa !27
  %t455 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t450, { i64, ptr } %t452)
  store i32 %t455, ptr %l165
  %t456 = icmp ne i32 %t455, 0
  br i1 %t456, label %bb99, label %ok.457, !prof !99
ok.457:
  br label %bb98
bb98:
  br label %bb100
bb99:
  %t458 = load i32, ptr %l165, !tbaa !23
  %t459 = lshr i32 %t458, 16
  %t460 = and i32 %t458, 65535
  %t461 = icmp eq i32 %t459, 1
  %t462 = select i1 %t461, i32 1, i32 0
  %t463 = icmp eq i32 %t458, 0
  %t464 = shl i32 %t462, 16
  %t465 = or i32 %t464, %t460
  %t466 = select i1 %t463, i32 0, i32 %t465
  %t468 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t466, 0
  store { i32, { i64, ptr } } %t468, ptr %rv
  br label %ret
bb100:
  br label %bb106
bb101:
  br i1 true, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_55ef846781ac27aa_5519550b25564c26)
  unreachable
bb106:
  %t469 = load i1, ptr %l2, !tbaa !21
  %t471 = call { i64, ptr } @compiler_2fbindgen_2evoidRef(ptr %v1, i1 %t469)
  store { i64, ptr } %t471, ptr %l168
  br label %bb107
bb107:
  %t472 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t473 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t472, 1
  store { i32, { i64, ptr } } %t473, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l80 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca i1
  %l96 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l121 = alloca i64
  %l123 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca i32
  %l131 = alloca i1
  %l133 = alloca i1
  %l134 = alloca i1
  %l136 = alloca i1
  %l150 = alloca ptr
  %l156 = alloca %"compiler/bindgen:record"
  %l158 = alloca %"compiler/bindgen:record"
  %l160 = alloca i1
  %l168 = alloca ptr
  %l174 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l177 = alloca { i64, ptr }
  %l180 = alloca i1
  %l182 = alloca i1
  %l184 = alloca { i64, ptr }
  %l192 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l198 = alloca i1
  %l201 = alloca { i64, ptr }
  %l203 = alloca i1
  %l205 = alloca i64
  %l206 = alloca { i64, ptr }
  %l207 = alloca i64
  %l208 = alloca i32
  %l209 = alloca i64
  %l210 = alloca i32
  %l213 = alloca { i64, ptr }
  %l222 = alloca i1
  %l231 = alloca i1
  %l232 = alloca i1
  %l235 = alloca i1
  %l236 = alloca i1
  %l238 = alloca i1
  %l240 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l242 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l245 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l259 = alloca i1
  %l260 = alloca ptr
  %l262 = alloca { i64, ptr }
  %l264 = alloca ptr
  %l266 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l273 = alloca i1
  %l274 = alloca i1
  %l276 = alloca i1
  %l279 = alloca i1
  %l287 = alloca { i64, ptr }
  %l289 = alloca i1
  %l290 = alloca i1
  %l293 = alloca i1
  %l294 = alloca { i64, ptr }
  %l299 = alloca ptr
  %l302 = alloca { i64, ptr }
  %l304 = alloca { i64, ptr }
  %l305 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l309 = alloca { i64, ptr }
  %l312 = alloca %"compiler/bindgen:cFunc"
  %l314 = alloca i1
  %l315 = alloca i1
  %l318 = alloca i1
  %l319 = alloca i1
  %l321 = alloca i1
  %l322 = alloca i1
  %l324 = alloca { i64, ptr }
  %l326 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %t280 = alloca %"compiler/bindgen:record", align 8
  %t283 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %v1, ptr %s1, ptr %a1)
  store { i64, ptr } %t3, ptr %l46
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 8
  %t8 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb182
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l54, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 %t25
  %t30 = load ptr, ptr %t29, !tbaa !39
  store ptr %t30, ptr %l6, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = call ptr @compiler_2fbindgen_2emember(ptr %s1, ptr %s1, ptr %s1, ptr %t32, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d258, i32 0, i32 1) })
  store ptr %t34, ptr %l58
  br label %bb6
bb6:
  %t35 = load ptr, ptr %l58, !tbaa !29
  store ptr %t35, ptr %l7, !tbaa !29
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %s1, ptr %v2, ptr %t42, ptr %t43, { i64, ptr } %t44)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/bindgen:gen", ptr %t48, i32 0, i32 26
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l8, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s4
  %t53 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t54 = insertvalue [3 x { i64, ptr }] %t53, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t55 = insertvalue [3 x { i64, ptr }] %t54, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d261, i32 0, i32 1) }, 2
  %t57 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 48, i64 8)
  store [3 x { i64, ptr }] %t55, ptr %t57
  store ptr %t57, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t59 = load ptr, ptr %l9
  store i64 3, ptr %l11, !tbaa !24
  br label %bb11
bb11:
  %t62 = load i64, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l11, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t70 = load ptr, ptr %l9
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = getelementptr [3 x { i64, ptr }], ptr %t70, i64 0, i64 %t71
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !37
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = load ptr, ptr @__olang_prog_scope
  %t82 = call ptr @compiler_2fbindgen_2emember(ptr %s1, ptr %t79, ptr %s1, ptr %t77, { i64, ptr } %t75)
  store ptr %t82, ptr %l80
  br label %bb15
bb15:
  %t83 = load ptr, ptr %l80, !tbaa !29
  store ptr %t83, ptr %l13, !tbaa !29
  %t84 = load ptr, ptr %l13, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb16, label %bb17
bb16:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l13, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %s1, ptr %v2, ptr %t90, ptr %t91, { i64, ptr } %t92)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t96 = load i64, ptr %l10, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l10, !tbaa !24
  br label %bb11
bb21:
  call void @__olang_scope_close(ptr %s4)
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t102 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s2, ptr %s2, ptr %t100, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d262, i32 0, i32 1) })
  store { i64, ptr } %t102, ptr %l90
  br label %bb22
bb22:
  %t103 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t103, ptr %l14, !tbaa !27
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s2, ptr %s2, ptr %t104, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d263, i32 0, i32 1) })
  store { i64, ptr } %t106, ptr %l92
  br label %bb23
bb23:
  %t107 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t107, ptr %l15, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t110 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t108, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d264, i32 0, i32 1) })
  store i1 %t110, ptr %l94
  br label %bb24
bb24:
  %t111 = load i1, ptr %l94, !tbaa !21
  br i1 %t111, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t114 = call { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %s1, ptr %s8, ptr %t112)
  store { i64, ptr } %t114, ptr %l96
  br label %bb27
bb26:
  br label %bb65
bb27:
  %t115 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t115, ptr %l16, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/bindgen:gen", ptr %t116, i32 0, i32 4
  %t119 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = extractvalue { i64, ptr } %t119, 0
  %t123 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t121, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  %t133 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = extractvalue { i64, ptr } %t133, 0
  %t137 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t135, i64 %t136)
  %t138 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = extractvalue { i64, ptr } %t139, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t118, { i64, ptr } %t132, { i64, ptr } %t146)
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s11
  %t150 = load ptr, ptr %l6, !tbaa !29
  %t152 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s1, ptr %s11, ptr %t150)
  store { i64, ptr } %t152, ptr %l106
  br label %bb29
bb29:
  %t153 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = mul i64 %t154, 8
  %t157 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  store i64 %t163, ptr %l19, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s12
  %t165 = load i64, ptr %l18, !tbaa !24
  %t166 = load i64, ptr %l19, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb32:
  br label %bb33
bb33:
  %t173 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t173, ptr %l114, !tbaa !27
  %t174 = load i64, ptr %l18, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr ptr, ptr %t177, i64 %t174
  %t179 = load ptr, ptr %t178, !tbaa !39
  %t183 = call ptr @compiler_2fbindgen_2emember(ptr %s11, ptr %s11, ptr %s11, ptr %t179, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d265, i32 0, i32 1) })
  store ptr %t183, ptr %l118
  br label %bb34
bb34:
  %t184 = load ptr, ptr %l118, !tbaa !29
  store ptr %t184, ptr %l21, !tbaa !29
  %t185 = load ptr, ptr %l21, !tbaa !29
  %t187 = icmp eq ptr %t185, null
  br i1 %t187, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s12)
  br label %bb63
bb36:
  br label %bb37
bb37:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/bindgen:gen", ptr %t189, i32 0, i32 7
  store ptr %t191, ptr %l123, !tbaa !29
  %t192 = load ptr, ptr %l21, !tbaa !29
  %t194 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s11, ptr %s12, ptr %s12, ptr %t192, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d266, i32 0, i32 1) })
  store { i64, ptr } %t194, ptr %l125
  br label %bb38
bb38:
  %t195 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  %t197 = extractvalue { i64, ptr } %t195, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  %t202 = load ptr, ptr %l123, !tbaa !29
  %t204 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %s12, ptr %t202, { i64, ptr } %t201)
  %t205 = extractvalue { i32, i64 } %t204, 1
  %t206 = extractvalue { i32, i64 } %t204, 0
  store i32 %t206, ptr %l128
  %t207 = icmp ne i32 %t206, 0
  br i1 %t207, label %bb40, label %ok.208, !prof !99
ok.208:
  store i64 %t205, ptr %l127
  br label %bb39
bb39:
  %t209 = load i64, ptr %l127, !tbaa !24
  store i64 %t209, ptr %l121, !tbaa !24
  br label %bb42
bb40:
  br label %bb41
bb41:
  store i64 -1, ptr %l121, !tbaa !24
  br label %bb42
bb42:
  %t210 = load i64, ptr %l121, !tbaa !24
  store i64 %t210, ptr %l22, !tbaa !24
  %t211 = load i64, ptr %l22, !tbaa !24
  %t213 = icmp sge i64 %t211, 0
  br i1 %t213, label %bb43, label %bb44
bb43:
  %t215 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t217 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s8, ptr %s12, { i64, ptr } %t215, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d267, i32 0, i32 1) })
  store i1 %t217, ptr %l133
  br label %bb45
bb44:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb50
bb45:
  %t218 = load i1, ptr %l133, !tbaa !21
  br i1 %t218, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb49
bb47:
  %t219 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t221 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s8, ptr %s12, { i64, ptr } %t219, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d268, i32 0, i32 1) })
  store i1 %t221, ptr %l136
  br label %bb48
bb48:
  %t222 = load i1, ptr %l136, !tbaa !21
  store i1 %t222, ptr %l134, !tbaa !21
  br label %bb49
bb49:
  %t223 = load i1, ptr %l134, !tbaa !21
  store i1 %t223, ptr %l131, !tbaa !21
  br label %bb50
bb50:
  %t224 = load i1, ptr %l131, !tbaa !21
  br i1 %t224, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s14
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/bindgen:gen", ptr %t225, i32 0, i32 6
  %t228 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 1
  %t231 = extractvalue { i64, ptr } %t228, 0
  %t232 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t231)
  call void @olang_textcopy(ptr %t232, ptr %t230, i64 %t231)
  %t233 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  %t236 = extractvalue { i64, ptr } %t234, 0
  %t237 = extractvalue { i64, ptr } %t234, 1
  %t238 = mul i64 %t236, 1
  %t239 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t238)
  call void @llvm.memcpy.p0.p0.i64(ptr %t239, ptr %t237, i64 %t238, i1 false)
  %t240 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  %t242 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t227, { i64, ptr } %t241, i64 %t242)
  br label %bb53
bb52:
  br label %bb62
bb53:
  %t246 = load i64, ptr %l22, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t248, 1
  %t251 = extractvalue { i64, ptr } %t248, 0
  %t252 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t251)
  call void @olang_textcopy(ptr %t252, ptr %t250, i64 %t251)
  %t253 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t252, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = extractvalue { i64, ptr } %t254, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  store { i64, ptr } %t261, ptr %l24, !tbaa !27
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/bindgen:gen", ptr %t263, i32 0, i32 5
  %t269 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t265, i64 %t246)
  store ptr %t269, ptr %l150
  br label %bb54
bb54:
  %t270 = load ptr, ptr %l150, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t275 = getelementptr %"compiler/bindgen:record", ptr %t270, i32 0, i32 0
  store { i64, ptr } %t272, ptr %t275, !tbaa !27
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/bindgen:gen", ptr %t276, i32 0, i32 5
  %t279 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t280, ptr %v0, ptr %v0, ptr %t278, i64 %t279)
  call void @llvm.memmove.p0.p0.i64(ptr %l156, ptr %t280, i64 176, i1 false)
  br label %bb55
bb55:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t283, ptr %v0, ptr %l156)
  call void @llvm.memmove.p0.p0.i64(ptr %l158, ptr %t283, i64 176, i1 false)
  br label %bb56
bb56:
  %t285 = getelementptr %"compiler/bindgen:record", ptr %l158, i32 0, i32 11
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  %t288 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s14, { i64, ptr } %t286, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d269, i32 0, i32 1) })
  store i1 %t288, ptr %l160
  br label %bb57
bb57:
  %t289 = load i1, ptr %l160, !tbaa !21
  br i1 %t289, label %bb58, label %bb59
bb58:
  %t290 = load i64, ptr %l22, !tbaa !24
  %t292 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t292, 1
  %t295 = extractvalue { i64, ptr } %t292, 0
  %t296 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t295)
  call void @olang_textcopy(ptr %t296, ptr %t294, i64 %t295)
  %t297 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t296, 1
  %t300 = extractvalue { i64, ptr } %t298, 0
  %t301 = extractvalue { i64, ptr } %t298, 1
  %t302 = mul i64 %t300, 1
  %t303 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t302)
  call void @llvm.memcpy.p0.p0.i64(ptr %t303, ptr %t301, i64 %t302, i1 false)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  store { i64, ptr } %t305, ptr %l27, !tbaa !27
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/bindgen:gen", ptr %t307, i32 0, i32 5
  %t313 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t309, i64 %t290)
  store ptr %t313, ptr %l168
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t314 = load ptr, ptr %l168, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t319 = getelementptr %"compiler/bindgen:record", ptr %t314, i32 0, i32 11
  store { i64, ptr } %t316, ptr %t319, !tbaa !27
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s14)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s12)
  br label %bb63
bb63:
  %t320 = load i64, ptr %l18, !tbaa !24
  %t322 = add i64 %t320, 1
  store i64 %t322, ptr %l18, !tbaa !24
  br label %bb30
bb64:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s2)
  br label %bb181
bb65:
  %t324 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t326 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t324, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d270, i32 0, i32 1) })
  store i1 %t326, ptr %l174
  br label %bb66
bb66:
  %t327 = load i1, ptr %l174, !tbaa !21
  br i1 %t327, label %bb67, label %bb68
bb67:
  %t328 = load ptr, ptr %l0, !tbaa !29
  store ptr %t328, ptr %l175, !tbaa !29
  %t329 = load ptr, ptr %l6, !tbaa !29
  store ptr %t329, ptr %l176, !tbaa !29
  %t330 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t330, ptr %l177, !tbaa !27
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i64, ptr %l8, !tbaa !24
  %t335 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewanted(ptr %v0, ptr %t331, i64 %t332)
  store i1 %t335, ptr %l180
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t336 = load ptr, ptr %l175, !tbaa !29
  %t337 = load ptr, ptr %l176, !tbaa !29
  %t338 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t339 = load i1, ptr %l180, !tbaa !21
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordDecl(ptr %v0, ptr %s1, ptr %s2, ptr %t336, ptr %t337, { i64, ptr } %t338, i1 %t339)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s2)
  br label %bb181
bb71:
  %t340 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t342 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t340, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d271, i32 0, i32 1) })
  store i1 %t342, ptr %l182
  br label %bb72
bb72:
  %t343 = load i1, ptr %l182, !tbaa !21
  br i1 %t343, label %bb73, label %bb74
bb73:
  store i64 0, ptr %l29, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s22
  %t344 = load ptr, ptr %l6, !tbaa !29
  %t346 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s1, ptr %s22, ptr %t344)
  store { i64, ptr } %t346, ptr %l184
  br label %bb75
bb74:
  br label %bb105
bb75:
  %t347 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t347, 0
  %t349 = extractvalue { i64, ptr } %t347, 1
  %t350 = mul i64 %t348, 8
  %t351 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t350)
  call void @llvm.memcpy.p0.p0.i64(ptr %t351, ptr %t349, i64 %t350, i1 false)
  %t352 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t351, 1
  store { i64, ptr } %t353, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t355 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t355, 0
  store i64 %t357, ptr %l32, !tbaa !24
  br label %bb76
bb76:
  store %olang.scope zeroinitializer, ptr %s23
  %t359 = load i64, ptr %l31, !tbaa !24
  %t360 = load i64, ptr %l32, !tbaa !24
  %t363 = icmp slt i64 %t359, %t360
  %t365 = xor i1 %t363, true
  br i1 %t365, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s23)
  br label %bb104
bb78:
  br label %bb79
bb79:
  %t367 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t367, ptr %l192, !tbaa !27
  %t368 = load i64, ptr %l31, !tbaa !24
  %t370 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr ptr, ptr %t371, i64 %t368
  %t373 = load ptr, ptr %t372, !tbaa !39
  store ptr %t373, ptr %l33, !tbaa !29
  %t375 = load ptr, ptr %l33, !tbaa !29
  %t377 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s22, ptr %s23, ptr %s23, ptr %t375, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d272, i32 0, i32 1) })
  store { i64, ptr } %t377, ptr %l196
  br label %bb80
bb80:
  %t378 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t379 = extractvalue { i64, ptr } %t378, 0
  %t380 = extractvalue { i64, ptr } %t378, 1
  %t381 = mul i64 %t379, 1
  %t382 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t381)
  call void @llvm.memcpy.p0.p0.i64(ptr %t382, ptr %t380, i64 %t381, i1 false)
  %t383 = insertvalue { i64, ptr } undef, i64 %t379, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  %t386 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s23, ptr %s23, { i64, ptr } %t384, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d273, i32 0, i32 1) })
  store i1 %t386, ptr %l198
  br label %bb81
bb81:
  %t387 = load i1, ptr %l198, !tbaa !21
  %t388 = xor i1 %t387, true
  br i1 %t388, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s23)
  br label %bb103
bb83:
  br label %bb84
bb84:
  %t390 = load ptr, ptr %l33, !tbaa !29
  %t392 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s22, ptr %s23, ptr %t390)
  store { i64, ptr } %t392, ptr %l201
  br label %bb85
bb85:
  %t393 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t393, ptr %l34, !tbaa !27
  %t394 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t396 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s23, ptr %s23, { i64, ptr } %t394, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d274, i32 0, i32 1) })
  store i1 %t396, ptr %l203
  br label %bb86
bb86:
  %t397 = load i1, ptr %l203, !tbaa !21
  %t398 = xor i1 %t397, true
  br i1 %t398, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s25
  %t400 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t400, ptr %l206, !tbaa !27
  %t401 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s25, i64 10)
  %t402 = extractvalue { i32, i64 } %t401, 1
  %t403 = extractvalue { i32, i64 } %t401, 0
  store i32 %t403, ptr %l208
  %t404 = icmp ne i32 %t403, 0
  br i1 %t404, label %bb90, label %ok.405, !prof !99
ok.405:
  store i64 %t402, ptr %l207
  br label %bb89
bb88:
  br label %bb95
bb89:
  %t406 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t407 = load i64, ptr %l207, !tbaa !24
  %t408 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s23, { i64, ptr } %t406, i64 %t407)
  %t409 = extractvalue { i32, i64 } %t408, 1
  %t410 = extractvalue { i32, i64 } %t408, 0
  store i32 %t410, ptr %l210
  %t411 = icmp ne i32 %t410, 0
  br i1 %t411, label %bb93, label %ok.412, !prof !99
ok.412:
  store i64 %t409, ptr %l209
  br label %bb92
bb90:
  br label %bb91
bb91:
  %t413 = load i64, ptr %l29, !tbaa !24
  store i64 %t413, ptr %l205, !tbaa !24
  br label %bb94
bb92:
  %t415 = load i64, ptr %l209, !tbaa !24
  store i64 %t415, ptr %l205, !tbaa !24
  br label %bb94
bb93:
  br label %bb91
bb94:
  %t416 = load i64, ptr %l205, !tbaa !24
  store i64 %t416, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s25)
  br label %bb95
bb95:
  %t417 = load ptr, ptr %l33, !tbaa !29
  %t419 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s22, ptr %s23, ptr %s23, ptr %t417, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d275, i32 0, i32 1) })
  store { i64, ptr } %t419, ptr %l213
  br label %bb96
bb96:
  %t420 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t420, ptr %l35, !tbaa !27
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/bindgen:gen", ptr %t421, i32 0, i32 11
  %t424 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t424, 1
  %t427 = extractvalue { i64, ptr } %t424, 0
  %t428 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t427)
  call void @olang_textcopy(ptr %t428, ptr %t426, i64 %t427)
  %t429 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  %t432 = extractvalue { i64, ptr } %t430, 0
  %t433 = extractvalue { i64, ptr } %t430, 1
  %t434 = mul i64 %t432, 1
  %t435 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t434)
  call void @llvm.memcpy.p0.p0.i64(ptr %t435, ptr %t433, i64 %t434, i1 false)
  %t436 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  %t438 = load i64, ptr %l29, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t423, { i64, ptr } %t437, i64 %t438)
  br label %bb97
bb97:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load i64, ptr %l8, !tbaa !24
  %t446 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewanted(ptr %v0, ptr %t442, i64 %t443)
  store i1 %t446, ptr %l222
  br label %bb98
bb98:
  %t447 = load i1, ptr %l222, !tbaa !21
  br i1 %t447, label %bb99, label %bb100
bb99:
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t450 = load i64, ptr %l29, !tbaa !24
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %v0, ptr %s23, ptr %t448, { i64, ptr } %t449, i64 %t450)
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb102
bb102:
  %t454 = load i64, ptr %l29, !tbaa !24
  %t456 = add i64 %t454, 1
  store i64 %t456, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb103
bb103:
  %t458 = load i64, ptr %l31, !tbaa !24
  %t460 = add i64 %t458, 1
  store i64 %t460, ptr %l31, !tbaa !24
  br label %bb76
bb104:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s2)
  br label %bb181
bb105:
  %t462 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t464 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t462, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d276, i32 0, i32 1) })
  store i1 %t464, ptr %l231
  br label %bb106
bb106:
  %t465 = load i1, ptr %l231, !tbaa !21
  br i1 %t465, label %bb107, label %bb108
bb107:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load i64, ptr %l8, !tbaa !24
  %t470 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewanted(ptr %v0, ptr %t466, i64 %t467)
  store i1 %t470, ptr %l235
  br label %bb109
bb108:
  store i1 false, ptr %l232, !tbaa !21
  br label %bb110
bb109:
  %t471 = load i1, ptr %l235, !tbaa !21
  store i1 %t471, ptr %l232, !tbaa !21
  br label %bb110
bb110:
  %t472 = load i1, ptr %l232, !tbaa !21
  br i1 %t472, label %bb111, label %bb112
bb111:
  %t473 = load ptr, ptr %l6, !tbaa !29
  %t475 = call i1 @compiler_2fbindgen_2eflag(ptr %s1, ptr %s2, ptr %t473, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d277, i32 0, i32 1) })
  store i1 %t475, ptr %l238
  br label %bb113
bb112:
  store i1 false, ptr %l236, !tbaa !21
  br label %bb114
bb113:
  %t476 = load i1, ptr %l238, !tbaa !21
  %t477 = xor i1 %t476, true
  store i1 %t477, ptr %l236, !tbaa !21
  br label %bb114
bb114:
  %t479 = load i1, ptr %l236, !tbaa !21
  br i1 %t479, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s29
  %t480 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t480, ptr %l240
  br label %bb117
bb116:
  br label %bb162
bb117:
  %t481 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l240
  %t482 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t481, ptr %t482
  store ptr %t482, ptr %l36, !tbaa !29
  %t484 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t484, ptr %l242
  br label %bb118
bb118:
  %t485 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l242
  %t486 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t485, ptr %t486
  store ptr %t486, ptr %l37, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s30
  %t488 = load ptr, ptr %l6, !tbaa !29
  %t490 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s1, ptr %s30, ptr %t488)
  store { i64, ptr } %t490, ptr %l245
  br label %bb119
bb119:
  %t491 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 0
  %t493 = extractvalue { i64, ptr } %t491, 1
  %t494 = mul i64 %t492, 8
  %t495 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t494)
  call void @llvm.memcpy.p0.p0.i64(ptr %t495, ptr %t493, i64 %t494, i1 false)
  %t496 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t495, 1
  store { i64, ptr } %t497, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t499 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t501 = extractvalue { i64, ptr } %t499, 0
  store i64 %t501, ptr %l40, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s31
  %t503 = load i64, ptr %l39, !tbaa !24
  %t504 = load i64, ptr %l40, !tbaa !24
  %t507 = icmp slt i64 %t503, %t504
  %t509 = xor i1 %t507, true
  br i1 %t509, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s31)
  br label %bb134
bb122:
  br label %bb123
bb123:
  %t511 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t511, ptr %l253, !tbaa !27
  %t512 = load i64, ptr %l39, !tbaa !24
  %t514 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t515 = load ptr, ptr %t514, !tbaa !27
  %t516 = getelementptr ptr, ptr %t515, i64 %t512
  %t517 = load ptr, ptr %t516, !tbaa !39
  store ptr %t517, ptr %l41, !tbaa !29
  %t519 = load ptr, ptr %l41, !tbaa !29
  %t521 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s30, ptr %s31, ptr %s31, ptr %t519, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d278, i32 0, i32 1) })
  store { i64, ptr } %t521, ptr %l257
  br label %bb124
bb124:
  %t522 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t522, 0
  %t524 = extractvalue { i64, ptr } %t522, 1
  %t525 = mul i64 %t523, 1
  %t526 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t525)
  call void @llvm.memcpy.p0.p0.i64(ptr %t526, ptr %t524, i64 %t525, i1 false)
  %t527 = insertvalue { i64, ptr } undef, i64 %t523, 0
  %t528 = insertvalue { i64, ptr } %t527, ptr %t526, 1
  %t530 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %s31, { i64, ptr } %t528, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d279, i32 0, i32 1) })
  store i1 %t530, ptr %l259
  br label %bb125
bb125:
  %t531 = load i1, ptr %l259, !tbaa !21
  br i1 %t531, label %bb126, label %bb127
bb126:
  %t532 = load ptr, ptr %l36, !tbaa !29
  store ptr %t532, ptr %l260, !tbaa !29
  %t533 = load ptr, ptr %l41, !tbaa !29
  %t535 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s30, ptr %v0, ptr %v0, ptr %t533, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d280, i32 0, i32 1) })
  store { i64, ptr } %t535, ptr %l262
  br label %bb128
bb127:
  br label %bb132
bb128:
  %t536 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t537 = extractvalue { i64, ptr } %t536, 0
  %t538 = extractvalue { i64, ptr } %t536, 1
  %t539 = mul i64 %t537, 1
  %t540 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t539)
  call void @llvm.memcpy.p0.p0.i64(ptr %t540, ptr %t538, i64 %t539, i1 false)
  %t541 = insertvalue { i64, ptr } undef, i64 %t537, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t540, 1
  %t543 = load ptr, ptr %l260, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t543, { i64, ptr } %t542)
  br label %bb129
bb129:
  %t545 = load ptr, ptr %l37, !tbaa !29
  store ptr %t545, ptr %l264, !tbaa !29
  %t546 = load ptr, ptr %l41, !tbaa !29
  %t548 = call { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %s30, ptr %v0, ptr %t546)
  store { i64, ptr } %t548, ptr %l266
  br label %bb130
bb130:
  %t549 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t550 = extractvalue { i64, ptr } %t549, 0
  %t551 = extractvalue { i64, ptr } %t549, 1
  %t552 = mul i64 %t550, 1
  %t553 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t552)
  call void @llvm.memcpy.p0.p0.i64(ptr %t553, ptr %t551, i64 %t552, i1 false)
  %t554 = insertvalue { i64, ptr } undef, i64 %t550, 0
  %t555 = insertvalue { i64, ptr } %t554, ptr %t553, 1
  %t556 = load ptr, ptr %l264, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t556, { i64, ptr } %t555)
  br label %bb131
bb131:
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s31)
  br label %bb133
bb133:
  %t558 = load i64, ptr %l39, !tbaa !24
  %t560 = add i64 %t558, 1
  store i64 %t560, ptr %l39, !tbaa !24
  br label %bb120
bb134:
  call void @__olang_scope_close(ptr %s30)
  %t562 = load ptr, ptr %l6, !tbaa !29
  %t564 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s29, ptr %s29, ptr %t562, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d281, i32 0, i32 1) })
  store { i64, ptr } %t564, ptr %l271
  br label %bb135
bb135:
  %t565 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 0
  %t567 = extractvalue { i64, ptr } %t565, 1
  %t568 = mul i64 %t566, 1
  %t569 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t568)
  call void @llvm.memcpy.p0.p0.i64(ptr %t569, ptr %t567, i64 %t568, i1 false)
  %t570 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t569, 1
  %t573 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s29, ptr %s29, { i64, ptr } %t571, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d282, i32 0, i32 1) })
  store i1 %t573, ptr %l273
  br label %bb136
bb136:
  %t574 = load i1, ptr %l273, !tbaa !21
  br i1 %t574, label %bb137, label %bb138
bb137:
  store i1 true, ptr %l274, !tbaa !21
  br label %bb140
bb138:
  %t575 = load ptr, ptr %l6, !tbaa !29
  %t577 = call i1 @compiler_2fbindgen_2eflag(ptr %s1, ptr %s29, ptr %t575, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d283, i32 0, i32 1) })
  store i1 %t577, ptr %l276
  br label %bb139
bb139:
  %t578 = load i1, ptr %l276, !tbaa !21
  store i1 %t578, ptr %l274, !tbaa !21
  br label %bb140
bb140:
  %t579 = load i1, ptr %l274, !tbaa !21
  store i1 %t579, ptr %l42, !tbaa !21
  %t580 = load i64, ptr %l8, !tbaa !24
  %t582 = icmp eq i64 %t580, 1
  br i1 %t582, label %bb141, label %bb142
bb141:
  %t584 = load i1, ptr %l42, !tbaa !21
  store i1 %t584, ptr %l279, !tbaa !21
  br label %bb143
bb142:
  store i1 false, ptr %l279, !tbaa !21
  br label %bb143
bb143:
  %t586 = load i1, ptr %l279, !tbaa !21
  br i1 %t586, label %bb144, label %bb145
bb144:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t589 = getelementptr %"compiler/bindgen:gen", ptr %t587, i32 0, i32 24
  %t590 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t592 = extractvalue { i64, ptr } %t590, 1
  %t593 = extractvalue { i64, ptr } %t590, 0
  %t594 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t593)
  call void @olang_textcopy(ptr %t594, ptr %t592, i64 %t593)
  %t595 = insertvalue { i64, ptr } undef, i64 %t593, 0
  %t596 = insertvalue { i64, ptr } %t595, ptr %t594, 1
  %t598 = extractvalue { i64, ptr } %t596, 0
  %t599 = extractvalue { i64, ptr } %t596, 1
  %t600 = mul i64 %t598, 1
  %t601 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t600)
  call void @llvm.memcpy.p0.p0.i64(ptr %t601, ptr %t599, i64 %t600, i1 false)
  %t602 = insertvalue { i64, ptr } undef, i64 %t598, 0
  %t603 = insertvalue { i64, ptr } %t602, ptr %t601, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t589, { i64, ptr } %t603, i64 0)
  br label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb147
bb147:
  %t606 = load ptr, ptr %l6, !tbaa !29
  %t608 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s29, ptr %s29, ptr %t606, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d284, i32 0, i32 1) })
  store { i64, ptr } %t608, ptr %l287
  br label %bb148
bb148:
  %t609 = load { i64, ptr }, ptr %l287, !tbaa !27
  store { i64, ptr } %t609, ptr %l43, !tbaa !27
  %t610 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t612 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s29, ptr %s29, { i64, ptr } %t610, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d285, i32 0, i32 1) })
  store i1 %t612, ptr %l289
  br label %bb149
bb149:
  %t613 = load i1, ptr %l289, !tbaa !21
  br i1 %t613, label %bb150, label %bb151
bb150:
  store i1 true, ptr %l290, !tbaa !21
  br label %bb153
bb151:
  %t614 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t615 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t618 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s29, ptr %s2, { i64, ptr } %t614, { i64, ptr } %t615)
  store i1 %t618, ptr %l293
  br label %bb152
bb152:
  %t619 = load i1, ptr %l293, !tbaa !21
  store i1 %t619, ptr %l290, !tbaa !21
  br label %bb153
bb153:
  %t620 = load i1, ptr %l290, !tbaa !21
  br i1 %t620, label %bb154, label %bb155
bb154:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d286, i32 0, i32 1) }, ptr %l294, !tbaa !27
  br label %bb156
bb155:
  %t621 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t621, ptr %l294, !tbaa !27
  br label %bb156
bb156:
  %t623 = load { i64, ptr }, ptr %l294, !tbaa !27
  %t624 = extractvalue { i64, ptr } %t623, 1
  %t625 = extractvalue { i64, ptr } %t623, 0
  %t626 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t625)
  call void @olang_textcopy(ptr %t626, ptr %t624, i64 %t625)
  %t627 = insertvalue { i64, ptr } undef, i64 %t625, 0
  %t628 = insertvalue { i64, ptr } %t627, ptr %t626, 1
  %t630 = extractvalue { i64, ptr } %t628, 0
  %t631 = extractvalue { i64, ptr } %t628, 1
  %t632 = mul i64 %t630, 1
  %t633 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t632)
  call void @llvm.memcpy.p0.p0.i64(ptr %t633, ptr %t631, i64 %t632, i1 false)
  %t634 = insertvalue { i64, ptr } undef, i64 %t630, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t633, 1
  store { i64, ptr } %t635, ptr %l44, !tbaa !27
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t639 = getelementptr %"compiler/bindgen:gen", ptr %t637, i32 0, i32 8
  store ptr %t639, ptr %l299, !tbaa !29
  %t640 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t642 = extractvalue { i64, ptr } %t640, 1
  %t643 = extractvalue { i64, ptr } %t640, 0
  %t644 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t643)
  call void @olang_textcopy(ptr %t644, ptr %t642, i64 %t643)
  %t645 = insertvalue { i64, ptr } undef, i64 %t643, 0
  %t646 = insertvalue { i64, ptr } %t645, ptr %t644, 1
  %t648 = extractvalue { i64, ptr } %t646, 0
  %t649 = extractvalue { i64, ptr } %t646, 1
  %t650 = mul i64 %t648, 1
  %t651 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t650)
  call void @llvm.memcpy.p0.p0.i64(ptr %t651, ptr %t649, i64 %t650, i1 false)
  %t652 = insertvalue { i64, ptr } undef, i64 %t648, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t651, 1
  store { i64, ptr } %t653, ptr %l302, !tbaa !27
  %t654 = load ptr, ptr %l6, !tbaa !29
  %t656 = call { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %s1, ptr %v0, ptr %t654)
  store { i64, ptr } %t656, ptr %l304
  br label %bb157
bb157:
  %t657 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t658 = extractvalue { i64, ptr } %t657, 0
  %t659 = extractvalue { i64, ptr } %t657, 1
  %t660 = mul i64 %t658, 1
  %t661 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t660)
  call void @llvm.memcpy.p0.p0.i64(ptr %t661, ptr %t659, i64 %t660, i1 false)
  %t662 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t663 = insertvalue { i64, ptr } %t662, ptr %t661, 1
  store { i64, ptr } %t663, ptr %l305, !tbaa !27
  %t664 = load ptr, ptr %l36, !tbaa !29
  %t666 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %t664)
  store { i64, ptr } %t666, ptr %l307
  br label %bb158
bb158:
  %t667 = load ptr, ptr %l37, !tbaa !29
  %t669 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %t667)
  store { i64, ptr } %t669, ptr %l309
  br label %bb159
bb159:
  %t670 = load i1, ptr %l42, !tbaa !21
  %t671 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t672 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t673 = load { i64, ptr }, ptr %l305, !tbaa !27
  %t674 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t675 = load { i64, ptr }, ptr %l309, !tbaa !27
  %t678 = call %"compiler/bindgen:cFunc" @compiler_2fbindgen_3acFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t672, { i64, ptr } %t673, { i64, ptr } %t674, { i64, ptr } %t675, i1 %t670, { i64, ptr } %t671)
  store %"compiler/bindgen:cFunc" %t678, ptr %l312
  br label %bb160
bb160:
  %t679 = load ptr, ptr %l299, !tbaa !29
  %t680 = load %"compiler/bindgen:cFunc", ptr %l312
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ePush_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t679, %"compiler/bindgen:cFunc" %t680)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s2)
  br label %bb181
bb162:
  %t681 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t683 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t681, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d287, i32 0, i32 1) })
  store i1 %t683, ptr %l314
  br label %bb163
bb163:
  %t684 = load i1, ptr %l314, !tbaa !21
  br i1 %t684, label %bb164, label %bb165
bb164:
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load i64, ptr %l8, !tbaa !24
  %t689 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewanted(ptr %v0, ptr %t685, i64 %t686)
  store i1 %t689, ptr %l318
  br label %bb166
bb165:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb167
bb166:
  %t690 = load i1, ptr %l318, !tbaa !21
  store i1 %t690, ptr %l315, !tbaa !21
  br label %bb167
bb167:
  %t691 = load i1, ptr %l315, !tbaa !21
  br i1 %t691, label %bb168, label %bb169
bb168:
  %t692 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t694 = call i1 @compiler_2fbindgen_2eusable(ptr %s2, { i64, ptr } %t692)
  store i1 %t694, ptr %l321
  br label %bb170
bb169:
  store i1 false, ptr %l319, !tbaa !21
  br label %bb171
bb170:
  %t695 = load i1, ptr %l321, !tbaa !21
  store i1 %t695, ptr %l319, !tbaa !21
  br label %bb171
bb171:
  %t696 = load i1, ptr %l319, !tbaa !21
  br i1 %t696, label %bb172, label %bb173
bb172:
  %t697 = load ptr, ptr %l6, !tbaa !29
  %t699 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s2, ptr %s2, ptr %t697, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d288, i32 0, i32 1) })
  store { i64, ptr } %t699, ptr %l324
  br label %bb174
bb173:
  store i1 false, ptr %l322, !tbaa !21
  br label %bb176
bb174:
  %t700 = load { i64, ptr }, ptr %l324, !tbaa !27
  %t701 = extractvalue { i64, ptr } %t700, 0
  %t702 = extractvalue { i64, ptr } %t700, 1
  %t703 = mul i64 %t701, 1
  %t704 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t703)
  call void @llvm.memcpy.p0.p0.i64(ptr %t704, ptr %t702, i64 %t703, i1 false)
  %t705 = insertvalue { i64, ptr } undef, i64 %t701, 0
  %t706 = insertvalue { i64, ptr } %t705, ptr %t704, 1
  %t708 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t706, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d289, i32 0, i32 1) })
  store i1 %t708, ptr %l326
  br label %bb175
bb175:
  %t709 = load i1, ptr %l326, !tbaa !21
  %t710 = xor i1 %t709, true
  store i1 %t710, ptr %l322, !tbaa !21
  br label %bb176
bb176:
  %t712 = load i1, ptr %l322, !tbaa !21
  br i1 %t712, label %bb177, label %bb178
bb177:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t715 = getelementptr %"compiler/bindgen:gen", ptr %t713, i32 0, i32 18
  %t716 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t718 = extractvalue { i64, ptr } %t716, 1
  %t719 = extractvalue { i64, ptr } %t716, 0
  %t720 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t721 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t722 = add i64 %t719, %t721
  %t723 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t722)
  call void @olang_textcopy(ptr %t723, ptr %t718, i64 %t719)
  %t724 = getelementptr i8, ptr %t723, i64 %t719
  call void @olang_textcopy(ptr %t724, ptr %t720, i64 %t721)
  %t725 = insertvalue { i64, ptr } undef, i64 %t722, 0
  %t726 = insertvalue { i64, ptr } %t725, ptr %t723, 1
  %t728 = extractvalue { i64, ptr } %t726, 0
  %t729 = extractvalue { i64, ptr } %t726, 1
  %t730 = mul i64 %t728, 1
  %t731 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t730)
  call void @llvm.memcpy.p0.p0.i64(ptr %t731, ptr %t729, i64 %t730, i1 false)
  %t732 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t731, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t715, { i64, ptr } %t733)
  br label %bb179
bb178:
  br label %bb180
bb179:
  br label %bb180
bb180:
  call void @__olang_scope_close(ptr %s2)
  br label %bb181
bb181:
  %t736 = load i64, ptr %l4, !tbaa !24
  %t738 = add i64 %t736, 1
  store i64 %t738, ptr %l4, !tbaa !24
  br label %bb2
bb182:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l13 = alloca ptr
  %l17 = alloca %"compiler/bindgen:record"
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l29 = alloca i64
  %rv = alloca i64
  %t37 = alloca %"compiler/bindgen:record", align 8
  %t40 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 6
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/bindgen:gen", ptr %t20, i32 0, i32 5
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @compiler_2fbindgen_3arecord_2ector(ptr %t37, ptr %v0, ptr %v0, { i64, ptr } %t36)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t37, i64 176, i1 false)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l13, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %l17, i64 176, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ePush_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t39, ptr %t40)
  br label %bb9
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/bindgen:gen", ptr %t41, i32 0, i32 6
  store ptr %t43, ptr %l19, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l22, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/bindgen:gen", ptr %t58, i32 0, i32 5
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l25
  br label %bb10
bb10:
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = sub i64 %t63, 1
  %t65 = load ptr, ptr %l19, !tbaa !29
  %t66 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t65, { i64, ptr } %t66, i64 %t64)
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/bindgen:gen", ptr %t68, i32 0, i32 5
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t70)
  store i64 %t72, ptr %l29
  br label %bb12
bb12:
  %t73 = load i64, ptr %l29, !tbaa !24
  %t74 = sub i64 %t73, 1
  store i64 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2esizes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/bindgen:cFunc"
  %l9 = alloca i64
  %l10 = alloca %"compiler/bindgen:ctype"
  %l12 = alloca i1
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %l60 = alloca i64
  %l65 = alloca %"compiler/bindgen:cFunc"
  %l67 = alloca { i64, ptr }
  %l70 = alloca i64
  %l74 = alloca %"compiler/bindgen:ctype"
  %l79 = alloca ptr
  %l83 = alloca %"compiler/bindgen:ctype"
  %l85 = alloca %"compiler/bindgen:ctype"
  %l88 = alloca i1
  %l92 = alloca %"compiler/bindgen:ctype"
  %l95 = alloca ptr
  %l99 = alloca %"compiler/bindgen:ctype"
  %l101 = alloca i64
  %l105 = alloca ptr
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l141 = alloca ptr
  %l145 = alloca i1
  %l150 = alloca i1
  %l154 = alloca ptr
  %l157 = alloca i1
  %l158 = alloca i1
  %l161 = alloca i1
  %l167 = alloca i64
  %l169 = alloca %"std/prelude/text:StringBuilder"
  %l175 = alloca i64
  %l177 = alloca i64
  %l183 = alloca i64
  %l184 = alloca ptr
  %l185 = alloca i64
  %l186 = alloca i64
  %l189 = alloca { i64, ptr }
  %l190 = alloca i64
  %l193 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l203 = alloca i32
  %l205 = alloca i1
  %l209 = alloca i32
  %l211 = alloca ptr
  %l216 = alloca ptr
  %l217 = alloca i32
  %l220 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l236 = alloca i1
  %l238 = alloca i1
  %l240 = alloca i1
  %l242 = alloca i64
  %l244 = alloca i64
  %l245 = alloca i64
  %l249 = alloca { i64, ptr }
  %l250 = alloca i64
  %l251 = alloca i32
  %l252 = alloca i64
  %l253 = alloca i32
  %l256 = alloca i1
  %l257 = alloca i64
  %l259 = alloca i64
  %l261 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l263 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l275 = alloca { i64, ptr }
  %l276 = alloca ptr
  %l277 = alloca i64
  %l278 = alloca { i64, ptr }
  %l279 = alloca i64
  %l280 = alloca i32
  %l281 = alloca i64
  %l282 = alloca i32
  %l286 = alloca i64
  %l290 = alloca i64
  %l292 = alloca i64
  %l296 = alloca ptr
  %l301 = alloca i64
  %l303 = alloca i64
  %l307 = alloca ptr
  %l314 = alloca i64
  %l318 = alloca i64
  %l321 = alloca i64
  %l343 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l6, !tbaa !24
  store i64 %t5, ptr %l58, !tbaa !24
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l60
  br label %bb2
bb2:
  %t9 = load i64, ptr %l58, !tbaa !24
  %t10 = load i64, ptr %l60, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = call %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/bindgen:cFunc" %t19, ptr %l65
  br label %bb6
bb6:
  %t20 = load %"compiler/bindgen:cFunc", ptr %l65
  store %"compiler/bindgen:cFunc" %t20, ptr %l7
  %t21 = getelementptr %"compiler/bindgen:cFunc", ptr %l7, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = call { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v0, ptr %s2, { i64, ptr } %t22)
  store { i64, ptr } %t24, ptr %l67
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s2, ptr %t26, { i64, ptr } %t25, i64 0)
  store i64 %t30, ptr %l70
  br label %bb8
bb8:
  %t31 = load i64, ptr %l70, !tbaa !24
  store i64 %t31, ptr %l9, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/bindgen:gen", ptr %t32, i32 0, i32 16
  %t35 = load i64, ptr %l9, !tbaa !24
  %t38 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s2, ptr %t34, i64 %t35)
  store %"compiler/bindgen:ctype" %t38, ptr %l74
  br label %bb9
bb9:
  %t39 = getelementptr %"compiler/bindgen:ctype", ptr %l74, i32 0, i32 0
  %t40 = load i32, ptr %t39, !range !{i32 0, i32 7}
  %t42 = trunc i64 5 to i32
  %t43 = icmp eq i32 %t40, %t42
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb11:
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/bindgen:gen", ptr %t47, i32 0, i32 16
  store ptr %t49, ptr %l79, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/bindgen:gen", ptr %t50, i32 0, i32 16
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s2, ptr %t52, i64 %t53)
  store %"compiler/bindgen:ctype" %t56, ptr %l83
  br label %bb13
bb13:
  %t57 = getelementptr %"compiler/bindgen:ctype", ptr %l83, i32 0, i32 2
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load ptr, ptr %l79, !tbaa !29
  %t61 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t59, i64 %t58)
  store %"compiler/bindgen:ctype" %t61, ptr %l85
  br label %bb14
bb14:
  %t62 = load %"compiler/bindgen:ctype", ptr %l85
  store %"compiler/bindgen:ctype" %t62, ptr %l10
  %t63 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 0
  %t64 = load i32, ptr %t63, !range !{i32 0, i32 7}
  %t66 = trunc i64 3 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/bindgen:gen", ptr %t69, i32 0, i32 16
  %t72 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 2
  %t73 = load i64, ptr %t72, !tbaa !24
  %t76 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s2, ptr %t71, i64 %t73)
  store %"compiler/bindgen:ctype" %t76, ptr %l92
  br label %bb17
bb16:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb18
bb17:
  %t77 = getelementptr %"compiler/bindgen:ctype", ptr %l92, i32 0, i32 0
  %t78 = load i32, ptr %t77, !range !{i32 0, i32 7}
  %t80 = trunc i64 2 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l88, !tbaa !21
  br label %bb18
bb18:
  %t83 = load i1, ptr %l88, !tbaa !21
  br i1 %t83, label %bb19, label %bb20
bb19:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l95, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/bindgen:gen", ptr %t85, i32 0, i32 16
  %t88 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 2
  %t89 = load i64, ptr %t88, !tbaa !24
  %t92 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t87, i64 %t89)
  store %"compiler/bindgen:ctype" %t92, ptr %l99
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t93 = getelementptr %"compiler/bindgen:ctype", ptr %l99, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  %t95 = load ptr, ptr %l95, !tbaa !29
  %t97 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v0, ptr %t95, { i64, ptr } %t94)
  store i64 %t97, ptr %l101
  br label %bb22
bb22:
  %t98 = load i64, ptr %l101, !tbaa !24
  store i1 true, ptr %l12, !tbaa !21
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/bindgen:gen", ptr %t99, i32 0, i32 5
  %t105 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t101, i64 %t98)
  store ptr %t105, ptr %l105
  br label %bb23
bb23:
  %t106 = load ptr, ptr %l105, !tbaa !29
  %t108 = load i1, ptr %l12, !tbaa !21
  %t111 = getelementptr %"compiler/bindgen:record", ptr %t106, i32 0, i32 10
  store i1 %t108, ptr %t111, !tbaa !21
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t112 = load i64, ptr %l6, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l6, !tbaa !24
  br label %bb1
bb26:
  %t116 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %l110
  br label %bb27
bb27:
  %t117 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %l14
  store i64 0, ptr %l15, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/bindgen:gen", ptr %t118, i32 0, i32 5
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t120)
  store i64 %t122, ptr %l113
  br label %bb28
bb28:
  %t123 = load i64, ptr %l113, !tbaa !24
  store i64 %t123, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t124 = load i64, ptr %l16, !tbaa !24
  %t125 = load i64, ptr %l15, !tbaa !24
  %t128 = icmp sgt i64 %t124, %t125
  br i1 %t128, label %bb29, label %bb30
bb29:
  %t130 = load i64, ptr %l17, !tbaa !24
  %t132 = icmp sgt i64 %t130, 0
  br i1 %t132, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb34
bb31:
  %t134 = load i64, ptr %l16, !tbaa !24
  %t135 = load i64, ptr %l15, !tbaa !24
  %t138 = sub i64 %t134, %t135
  %t139 = load i64, ptr %l17, !tbaa !24
  %t142 = add i64 %t138, %t139
  %t144 = sub i64 %t142, 1
  %t145 = load i64, ptr %l17, !tbaa !24
  %t148 = sdiv i64 %t144, %t145
  store i64 %t148, ptr %l120, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb33
bb33:
  %t150 = load i64, ptr %l120, !tbaa !24
  store i64 %t150, ptr %l117, !tbaa !24
  br label %bb34
bb34:
  %t151 = load i64, ptr %l117, !tbaa !24
  store i64 %t151, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t152 = load i64, ptr %l19, !tbaa !24
  %t153 = load i64, ptr %l18, !tbaa !24
  %t156 = icmp slt i64 %t152, %t153
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb61
bb37:
  br label %bb38
bb38:
  %t160 = load i64, ptr %l15, !tbaa !24
  %t161 = load i64, ptr %l19, !tbaa !24
  %t162 = load i64, ptr %l17, !tbaa !24
  %t165 = mul i64 %t161, %t162
  %t168 = add i64 %t160, %t165
  store i64 %t168, ptr %l20, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/bindgen:gen", ptr %t170, i32 0, i32 5
  %t173 = load i64, ptr %l20, !tbaa !24
  %t176 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t172, i64 %t173)
  store ptr %t176, ptr %l141
  br label %bb39
bb39:
  %t177 = load ptr, ptr %l141, !tbaa !29
  store ptr %t177, ptr %l21, !tbaa !29
  %t178 = load ptr, ptr %l21, !tbaa !29
  %t180 = getelementptr %"compiler/bindgen:record", ptr %t178, i32 0, i32 2
  %t181 = load i1, ptr %t180, !tbaa !21
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb42
bb41:
  %t185 = load ptr, ptr %l21, !tbaa !29
  %t187 = getelementptr %"compiler/bindgen:record", ptr %t185, i32 0, i32 10
  %t188 = load i1, ptr %t187, !tbaa !21
  store i1 %t188, ptr %l145, !tbaa !21
  br label %bb42
bb42:
  %t190 = load i1, ptr %l145, !tbaa !21
  br i1 %t190, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb44:
  br label %bb45
bb45:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i64, ptr %l20, !tbaa !24
  %t195 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t191, i64 %t192)
  store i1 %t195, ptr %l150
  br label %bb46
bb46:
  %t196 = load i1, ptr %l150, !tbaa !21
  br i1 %t196, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb48:
  br label %bb49
bb49:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/bindgen:gen", ptr %t197, i32 0, i32 5
  %t200 = load i64, ptr %l20, !tbaa !24
  %t203 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t199, i64 %t200)
  store ptr %t203, ptr %l154
  br label %bb50
bb50:
  %t204 = load ptr, ptr %l154, !tbaa !29
  store ptr %t204, ptr %l22, !tbaa !29
  %t205 = load ptr, ptr %l22, !tbaa !29
  %t207 = getelementptr %"compiler/bindgen:record", ptr %t205, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t210 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t208, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d291, i32 0, i32 1) })
  store i1 %t210, ptr %l157
  br label %bb51
bb51:
  %t211 = load i1, ptr %l157, !tbaa !21
  br i1 %t211, label %bb52, label %bb53
bb52:
  %t212 = load ptr, ptr %l22, !tbaa !29
  %t214 = getelementptr %"compiler/bindgen:record", ptr %t212, i32 0, i32 11
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  %t217 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t215, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d292, i32 0, i32 1) })
  store i1 %t217, ptr %l161
  br label %bb54
bb53:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb55
bb54:
  %t218 = load i1, ptr %l161, !tbaa !21
  store i1 %t218, ptr %l158, !tbaa !21
  br label %bb55
bb55:
  %t219 = load i1, ptr %l158, !tbaa !21
  br i1 %t219, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t220 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l14, i64 %t220)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb60:
  %t223 = load i64, ptr %l19, !tbaa !24
  %t225 = add i64 %t223, 1
  store i64 %t225, ptr %l19, !tbaa !24
  br label %bb35
bb61:
  %t228 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l14)
  store i64 %t228, ptr %l167
  br label %bb62
bb62:
  %t229 = load i64, ptr %l167, !tbaa !24
  %t230 = icmp eq i64 %t229, 0
  br i1 %t230, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t232 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t232, ptr %l169
  br label %bb66
bb66:
  %t233 = load %"std/prelude/text:StringBuilder", ptr %l169
  store %"std/prelude/text:StringBuilder" %t233, ptr %l23
  %t236 = extractvalue { i64, ptr } %a4, 1
  %t237 = extractvalue { i64, ptr } %a4, 0
  %t238 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t240 = add i64 %t237, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t236, i64 %t237)
  %t242 = getelementptr i8, ptr %t241, i64 %t237
  call void @olang_textcopy(ptr %t242, ptr %t238, i64 %t239)
  %t243 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t241, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = extractvalue { i64, ptr } %t244, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l23, { i64, ptr } %t251)
  br label %bb67
bb67:
  store ptr %l14, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s15
  %t255 = load i64, ptr %l25, !tbaa !24
  store i64 %t255, ptr %l175, !tbaa !24
  %t256 = load ptr, ptr %l24, !tbaa !29
  %t258 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t256)
  store i64 %t258, ptr %l177
  br label %bb69
bb69:
  %t259 = load i64, ptr %l175, !tbaa !24
  %t260 = load i64, ptr %l177, !tbaa !24
  %t261 = icmp slt i64 %t259, %t260
  %t263 = xor i1 %t261, true
  br i1 %t263, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s15)
  br label %bb78
bb71:
  br label %bb72
bb72:
  %t265 = load i64, ptr %l25, !tbaa !24
  store i64 %t265, ptr %l26, !tbaa !24
  %t267 = load ptr, ptr %l24, !tbaa !29
  %t268 = load i64, ptr %l25, !tbaa !24
  %t271 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t267, i64 %t268)
  store i64 %t271, ptr %l183
  br label %bb73
bb73:
  %t272 = load i64, ptr %l183, !tbaa !24
  store i64 %t272, ptr %l27, !tbaa !24
  store ptr %l23, ptr %l184, !tbaa !29
  %t273 = load i64, ptr %l26, !tbaa !24
  store i64 %t273, ptr %l185, !tbaa !24
  %t274 = load i64, ptr %l26, !tbaa !24
  store i64 %t274, ptr %l186, !tbaa !24
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load i64, ptr %l27, !tbaa !24
  %t279 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2espell(ptr %v0, ptr %s15, ptr %t275, i64 %t276)
  store { i64, ptr } %t279, ptr %l189
  br label %bb74
bb74:
  %t280 = load i64, ptr %l26, !tbaa !24
  store i64 %t280, ptr %l190, !tbaa !24
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load i64, ptr %l27, !tbaa !24
  %t285 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2espell(ptr %v0, ptr %s15, ptr %t281, i64 %t282)
  store { i64, ptr } %t285, ptr %l193
  br label %bb75
bb75:
  %t286 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t287 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t288 = load i64, ptr %l185, !tbaa !24
  %t289 = call i64 @__olang_fmt_i64(ptr null, i64 %t288)
  %t290 = add i64 %t287, %t289
  %t291 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t293 = add i64 %t290, %t292
  %t294 = load i64, ptr %l186, !tbaa !24
  %t295 = call i64 @__olang_fmt_i64(ptr null, i64 %t294)
  %t296 = add i64 %t293, %t295
  %t297 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t298 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t299 = add i64 %t296, %t298
  %t300 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t300, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = add i64 %t299, %t302
  %t304 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t306 = add i64 %t303, %t305
  %t307 = load i64, ptr %l190, !tbaa !24
  %t308 = call i64 @__olang_fmt_i64(ptr null, i64 %t307)
  %t309 = add i64 %t306, %t308
  %t310 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t312 = add i64 %t309, %t311
  %t313 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t316 = add i64 %t312, %t315
  %t317 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t318 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t319 = add i64 %t316, %t318
  %t320 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t319)
  call void @olang_textcopy(ptr %t320, ptr %t286, i64 %t287)
  %t321 = getelementptr i8, ptr %t320, i64 %t287
  %t322 = call i64 @__olang_fmt_i64(ptr %t321, i64 %t288)
  %t323 = getelementptr i8, ptr %t321, i64 %t289
  call void @olang_textcopy(ptr %t323, ptr %t291, i64 %t292)
  %t324 = getelementptr i8, ptr %t323, i64 %t292
  %t325 = call i64 @__olang_fmt_i64(ptr %t324, i64 %t294)
  %t326 = getelementptr i8, ptr %t324, i64 %t295
  call void @olang_textcopy(ptr %t326, ptr %t297, i64 %t298)
  %t327 = getelementptr i8, ptr %t326, i64 %t298
  call void @olang_textcopy(ptr %t327, ptr %t301, i64 %t302)
  %t328 = getelementptr i8, ptr %t327, i64 %t302
  call void @olang_textcopy(ptr %t328, ptr %t304, i64 %t305)
  %t329 = getelementptr i8, ptr %t328, i64 %t305
  %t330 = call i64 @__olang_fmt_i64(ptr %t329, i64 %t307)
  %t331 = getelementptr i8, ptr %t329, i64 %t308
  call void @olang_textcopy(ptr %t331, ptr %t310, i64 %t311)
  %t332 = getelementptr i8, ptr %t331, i64 %t311
  call void @olang_textcopy(ptr %t332, ptr %t314, i64 %t315)
  %t333 = getelementptr i8, ptr %t332, i64 %t315
  call void @olang_textcopy(ptr %t333, ptr %t317, i64 %t318)
  %t334 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t320, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } %t335, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  %t343 = load ptr, ptr %l184, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %t343, { i64, ptr } %t342)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s15)
  br label %bb77
bb77:
  %t345 = load i64, ptr %l25, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l25, !tbaa !24
  br label %bb68
bb78:
  %t349 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t349, ptr %l198, !tbaa !27
  %t351 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l23)
  store { i64, ptr } %t351, ptr %l200
  br label %bb79
bb79:
  %t352 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t352, 0
  %t355 = extractvalue { i64, ptr } %t352, 1
  %t356 = mul i64 %t354, 1
  %t357 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t356)
  call void @llvm.memcpy.p0.p0.i64(ptr %t357, ptr %t355, i64 %t356, i1 false)
  %t358 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  %t360 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t362 = call i32 @std_2fos_2eWriteFile(ptr %v3, ptr %s0, { i64, ptr } %t360, { i64, ptr } %t359)
  store i32 %t362, ptr %l203
  %t363 = icmp ne i32 %t362, 0
  br i1 %t363, label %bb81, label %ok.364, !prof !99
ok.364:
  br label %bb80
bb80:
  br label %bb88
bb81:
  %t365 = load i32, ptr %l203, !tbaa !23
  %t366 = ashr i32 %t365, 16
  %t368 = icmp eq i32 %t366, 1
  store i1 %t368, ptr %l205, !tbaa !21
  %t369 = load i32, ptr %l203, !tbaa !23
  %t370 = ashr i32 %t369, 16
  %t372 = icmp eq i32 %t370, 1
  br i1 %t372, label %bb82, label %bb83
bb82:
  call void @__olang_errpay_pop()
  br label %bb83
bb83:
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s18
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %s18, ptr %t374, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d300, i32 0, i32 1) })
  store i32 %t376, ptr %l209
  %t377 = icmp ne i32 %t376, 0
  br i1 %t377, label %bb86, label %ok.378, !prof !99
ok.378:
  br label %bb85
bb85:
  br label %bb87
bb86:
  %t379 = load i32, ptr %l209, !tbaa !23
  %t380 = lshr i32 %t379, 16
  %t381 = and i32 %t379, 65535
  %t382 = icmp eq i32 %t380, 1
  %t383 = select i1 %t382, i32 1, i32 0
  %t384 = icmp eq i32 %t379, 0
  %t385 = shl i32 %t383, 16
  %t386 = or i32 %t385, %t381
  %t387 = select i1 %t384, i32 0, i32 %t386
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t387, ptr %rv
  br label %ret
bb87:
  call void @__olang_scope_close(ptr %s18)
  br label %bb88
bb88:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t397 = call { i32, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edump(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %t389, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %t392)
  %t398 = extractvalue { i32, ptr } %t397, 1
  %t399 = extractvalue { i32, ptr } %t397, 0
  store i32 %t399, ptr %l217
  %t400 = icmp ne i32 %t399, 0
  br i1 %t400, label %bb90, label %ok.401, !prof !99
ok.401:
  store ptr %t398, ptr %l216
  br label %bb89
bb89:
  %t402 = load ptr, ptr %l216, !tbaa !29
  store ptr %t402, ptr %l211, !tbaa !29
  br label %bb91
bb90:
  %t403 = load i32, ptr %l217, !tbaa !23
  %t404 = lshr i32 %t403, 16
  %t405 = and i32 %t403, 65535
  %t406 = icmp eq i32 %t404, 1
  %t407 = select i1 %t406, i32 1, i32 0
  %t408 = icmp eq i32 %t403, 0
  %t409 = shl i32 %t407, 16
  %t410 = or i32 %t409, %t405
  %t411 = select i1 %t408, i32 0, i32 %t410
  call void @__olang_scope_close(ptr %s0)
  store i32 %t411, ptr %rv
  br label %ret
bb91:
  %t413 = load ptr, ptr %l211, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s19
  %t416 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s0, ptr %s19, ptr %t413)
  store { i64, ptr } %t416, ptr %l220
  br label %bb92
bb92:
  %t417 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t418 = extractvalue { i64, ptr } %t417, 0
  %t419 = extractvalue { i64, ptr } %t417, 1
  %t420 = mul i64 %t418, 8
  %t421 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t420)
  call void @llvm.memcpy.p0.p0.i64(ptr %t421, ptr %t419, i64 %t420, i1 false)
  %t422 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t423 = insertvalue { i64, ptr } %t422, ptr %t421, 1
  store { i64, ptr } %t423, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t425 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t425, 0
  store i64 %t427, ptr %l31, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s20
  %t429 = load i64, ptr %l30, !tbaa !24
  %t430 = load i64, ptr %l31, !tbaa !24
  %t433 = icmp slt i64 %t429, %t430
  %t435 = xor i1 %t433, true
  br i1 %t435, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s20)
  br label %bb153
bb95:
  br label %bb96
bb96:
  %t437 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t437, ptr %l228, !tbaa !27
  %t438 = load i64, ptr %l30, !tbaa !24
  %t440 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !27
  %t442 = getelementptr ptr, ptr %t441, i64 %t438
  %t443 = load ptr, ptr %t442, !tbaa !39
  store ptr %t443, ptr %l32, !tbaa !29
  %t445 = load ptr, ptr %l32, !tbaa !29
  %t447 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s19, ptr %s20, ptr %s20, ptr %t445, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d301, i32 0, i32 1) })
  store { i64, ptr } %t447, ptr %l232
  br label %bb97
bb97:
  %t448 = load { i64, ptr }, ptr %l232, !tbaa !27
  store { i64, ptr } %t448, ptr %l33, !tbaa !27
  %t449 = load ptr, ptr %l32, !tbaa !29
  %t451 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s19, ptr %s20, ptr %s20, ptr %t449, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d302, i32 0, i32 1) })
  store { i64, ptr } %t451, ptr %l234
  br label %bb98
bb98:
  %t452 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 0
  %t454 = extractvalue { i64, ptr } %t452, 1
  %t455 = mul i64 %t453, 1
  %t456 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t455)
  call void @llvm.memcpy.p0.p0.i64(ptr %t456, ptr %t454, i64 %t455, i1 false)
  %t457 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  %t460 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s20, ptr %s20, { i64, ptr } %t458, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d303, i32 0, i32 1) })
  store i1 %t460, ptr %l236
  br label %bb99
bb99:
  %t461 = load i1, ptr %l236, !tbaa !21
  %t462 = xor i1 %t461, true
  br i1 %t462, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l238, !tbaa !21
  br label %bb103
bb101:
  %t464 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t466 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s20, ptr %s20, { i64, ptr } %t464, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d304, i32 0, i32 1) })
  store i1 %t466, ptr %l240
  br label %bb102
bb102:
  %t467 = load i1, ptr %l240, !tbaa !21
  %t468 = xor i1 %t467, true
  store i1 %t468, ptr %l238, !tbaa !21
  br label %bb103
bb103:
  %t470 = load i1, ptr %l238, !tbaa !21
  br i1 %t470, label %bb104, label %bb105
bb104:
  call void @__olang_scope_close(ptr %s20)
  br label %bb152
bb105:
  br label %bb106
bb106:
  %t471 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t471, 0
  store i64 %t473, ptr %l244, !tbaa !24
  %t474 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t474, 0
  store i64 %t475, ptr %l245, !tbaa !24
  %t476 = icmp sge i64 9, 0
  br i1 %t476, label %bb107, label %bb108
bb107:
  %t478 = load i64, ptr %l244, !tbaa !24
  %t479 = icmp sle i64 9, %t478
  br i1 %t479, label %bb109, label %bb110
bb108:
  call void @__olang_check_failed(ptr @olang_loc_f6b0d4dcea5d2bc9_16e8d1d827605cbd)
  unreachable
bb109:
  %t481 = load i64, ptr %l244, !tbaa !24
  %t482 = load i64, ptr %l245, !tbaa !24
  %t483 = icmp sle i64 %t481, %t482
  br i1 %t483, label %bb111, label %bb112
bb110:
  call void @__olang_check_failed(ptr @olang_loc_f6b0d4dcea5d2bc9_16e8d1d827605cbd)
  unreachable
bb111:
  %t485 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = load i64, ptr %l244, !tbaa !24
  %t488 = getelementptr i8, ptr %t486, i64 9
  %t489 = sub i64 %t487, 9
  %t490 = insertvalue { i64, ptr } undef, i64 %t489, 0
  %t491 = insertvalue { i64, ptr } %t490, ptr %t488, 1
  store { i64, ptr } %t491, ptr %l249, !tbaa !27
  %t492 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s20, i64 10)
  %t493 = extractvalue { i32, i64 } %t492, 1
  %t494 = extractvalue { i32, i64 } %t492, 0
  store i32 %t494, ptr %l251
  %t495 = icmp ne i32 %t494, 0
  br i1 %t495, label %bb114, label %ok.496, !prof !99
ok.496:
  store i64 %t493, ptr %l250
  br label %bb113
bb112:
  call void @__olang_check_failed(ptr @olang_loc_f6b0d4dcea5d2bc9_16e8d1d827605cbd)
  unreachable
bb113:
  %t497 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t498 = load i64, ptr %l250, !tbaa !24
  %t499 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s20, { i64, ptr } %t497, i64 %t498)
  %t500 = extractvalue { i32, i64 } %t499, 1
  %t501 = extractvalue { i32, i64 } %t499, 0
  store i32 %t501, ptr %l253
  %t502 = icmp ne i32 %t501, 0
  br i1 %t502, label %bb117, label %ok.503, !prof !99
ok.503:
  store i64 %t500, ptr %l252
  br label %bb116
bb114:
  br label %bb115
bb115:
  store i64 -1, ptr %l242, !tbaa !24
  br label %bb118
bb116:
  %t504 = load i64, ptr %l252, !tbaa !24
  store i64 %t504, ptr %l242, !tbaa !24
  br label %bb118
bb117:
  br label %bb115
bb118:
  %t505 = load i64, ptr %l242, !tbaa !24
  store i64 %t505, ptr %l34, !tbaa !24
  %t506 = load i64, ptr %l34, !tbaa !24
  %t508 = icmp slt i64 %t506, 0
  br i1 %t508, label %bb119, label %bb120
bb119:
  store i1 true, ptr %l256, !tbaa !21
  br label %bb122
bb120:
  %t510 = load i64, ptr %l34, !tbaa !24
  store i64 %t510, ptr %l257, !tbaa !24
  %t512 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l14)
  store i64 %t512, ptr %l259
  br label %bb121
bb121:
  %t513 = load i64, ptr %l257, !tbaa !24
  %t514 = load i64, ptr %l259, !tbaa !24
  %t515 = icmp sge i64 %t513, %t514
  store i1 %t515, ptr %l256, !tbaa !21
  br label %bb122
bb122:
  %t517 = load i1, ptr %l256, !tbaa !21
  br i1 %t517, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s20)
  br label %bb152
bb124:
  br label %bb125
bb125:
  %t518 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s20, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t518, ptr %l261
  br label %bb126
bb126:
  %t519 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l261
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t519, ptr %l35
  store %olang.scope zeroinitializer, ptr %s23
  %t520 = load ptr, ptr %l32, !tbaa !29
  %t522 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s19, ptr %s23, ptr %t520)
  store { i64, ptr } %t522, ptr %l263
  br label %bb127
bb127:
  %t523 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t524 = extractvalue { i64, ptr } %t523, 0
  %t525 = extractvalue { i64, ptr } %t523, 1
  %t526 = mul i64 %t524, 8
  %t527 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t526)
  call void @llvm.memcpy.p0.p0.i64(ptr %t527, ptr %t525, i64 %t526, i1 false)
  %t528 = insertvalue { i64, ptr } undef, i64 %t524, 0
  %t529 = insertvalue { i64, ptr } %t528, ptr %t527, 1
  store { i64, ptr } %t529, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t531 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t531, 0
  store i64 %t533, ptr %l38, !tbaa !24
  br label %bb128
bb128:
  store %olang.scope zeroinitializer, ptr %s24
  %t535 = load i64, ptr %l37, !tbaa !24
  %t536 = load i64, ptr %l38, !tbaa !24
  %t539 = icmp slt i64 %t535, %t536
  %t541 = xor i1 %t539, true
  br i1 %t541, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s24)
  br label %bb141
bb130:
  br label %bb131
bb131:
  %t543 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t543, ptr %l271, !tbaa !27
  %t544 = load i64, ptr %l37, !tbaa !24
  %t546 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !27
  %t548 = getelementptr ptr, ptr %t547, i64 %t544
  %t549 = load ptr, ptr %t548, !tbaa !39
  %t553 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s23, ptr %s24, ptr %t549)
  store { i64, ptr } %t553, ptr %l275
  br label %bb132
bb132:
  %t554 = load { i64, ptr }, ptr %l275, !tbaa !27
  store ptr %l35, ptr %l276, !tbaa !29
  store { i64, ptr } %t554, ptr %l278, !tbaa !27
  %t556 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s24, i64 10)
  %t557 = extractvalue { i32, i64 } %t556, 1
  %t558 = extractvalue { i32, i64 } %t556, 0
  store i32 %t558, ptr %l280
  %t559 = icmp ne i32 %t558, 0
  br i1 %t559, label %bb134, label %ok.560, !prof !99
ok.560:
  store i64 %t557, ptr %l279
  br label %bb133
bb133:
  %t561 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t562 = load i64, ptr %l279, !tbaa !24
  %t563 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s24, { i64, ptr } %t561, i64 %t562)
  %t564 = extractvalue { i32, i64 } %t563, 1
  %t565 = extractvalue { i32, i64 } %t563, 0
  store i32 %t565, ptr %l282
  %t566 = icmp ne i32 %t565, 0
  br i1 %t566, label %bb137, label %ok.567, !prof !99
ok.567:
  store i64 %t564, ptr %l281
  br label %bb136
bb134:
  br label %bb135
bb135:
  store i64 -1, ptr %l277, !tbaa !24
  br label %bb138
bb136:
  %t568 = load i64, ptr %l281, !tbaa !24
  store i64 %t568, ptr %l277, !tbaa !24
  br label %bb138
bb137:
  br label %bb135
bb138:
  %t569 = load ptr, ptr %l276, !tbaa !29
  %t570 = load i64, ptr %l277, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s20, ptr %t569, i64 %t570)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s24)
  br label %bb140
bb140:
  %t571 = load i64, ptr %l37, !tbaa !24
  %t573 = add i64 %t571, 1
  store i64 %t573, ptr %l37, !tbaa !24
  br label %bb128
bb141:
  call void @__olang_scope_close(ptr %s23)
  %t576 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s20, ptr %l35)
  store i64 %t576, ptr %l286
  br label %bb142
bb142:
  %t577 = load i64, ptr %l286, !tbaa !24
  %t578 = icmp eq i64 %t577, 2
  br i1 %t578, label %bb143, label %bb144
bb143:
  %t580 = load i64, ptr %l34, !tbaa !24
  %t583 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l14, i64 %t580)
  store i64 %t583, ptr %l290
  br label %bb145
bb144:
  br label %bb151
bb145:
  %t584 = load i64, ptr %l290, !tbaa !24
  store i64 %t584, ptr %l41, !tbaa !24
  %t586 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s20, ptr %l35, i64 0)
  store i64 %t586, ptr %l292
  br label %bb146
bb146:
  %t587 = load i64, ptr %l292, !tbaa !24
  store i64 %t587, ptr %l42, !tbaa !24
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t590 = getelementptr %"compiler/bindgen:gen", ptr %t588, i32 0, i32 5
  %t591 = load i64, ptr %l41, !tbaa !24
  %t594 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t590, i64 %t591)
  store ptr %t594, ptr %l296
  br label %bb147
bb147:
  %t595 = load ptr, ptr %l296, !tbaa !29
  %t597 = load i64, ptr %l42, !tbaa !24
  %t600 = getelementptr %"compiler/bindgen:record", ptr %t595, i32 0, i32 13
  store i64 %t597, ptr %t600, !tbaa !24
  %t601 = load i64, ptr %l34, !tbaa !24
  %t604 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l14, i64 %t601)
  store i64 %t604, ptr %l301
  br label %bb148
bb148:
  %t605 = load i64, ptr %l301, !tbaa !24
  store i64 %t605, ptr %l44, !tbaa !24
  %t607 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s20, ptr %l35, i64 1)
  store i64 %t607, ptr %l303
  br label %bb149
bb149:
  %t608 = load i64, ptr %l303, !tbaa !24
  store i64 %t608, ptr %l45, !tbaa !24
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t611 = getelementptr %"compiler/bindgen:gen", ptr %t609, i32 0, i32 5
  %t612 = load i64, ptr %l44, !tbaa !24
  %t615 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t611, i64 %t612)
  store ptr %t615, ptr %l307
  br label %bb150
bb150:
  %t616 = load ptr, ptr %l307, !tbaa !29
  %t618 = load i64, ptr %l45, !tbaa !24
  %t621 = getelementptr %"compiler/bindgen:record", ptr %t616, i32 0, i32 14
  store i64 %t618, ptr %t621, !tbaa !24
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s20)
  br label %bb152
bb152:
  %t622 = load i64, ptr %l30, !tbaa !24
  %t624 = add i64 %t622, 1
  store i64 %t624, ptr %l30, !tbaa !24
  br label %bb93
bb153:
  call void @__olang_scope_close(ptr %s19)
  store i64 0, ptr %l47, !tbaa !24
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t628 = getelementptr %"compiler/bindgen:gen", ptr %t626, i32 0, i32 5
  %t630 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t628)
  store i64 %t630, ptr %l314
  br label %bb154
bb154:
  %t631 = load i64, ptr %l314, !tbaa !24
  store i64 %t631, ptr %l48, !tbaa !24
  store i64 1, ptr %l49, !tbaa !24
  %t632 = load i64, ptr %l48, !tbaa !24
  %t633 = load i64, ptr %l47, !tbaa !24
  %t636 = icmp sgt i64 %t632, %t633
  br i1 %t636, label %bb155, label %bb156
bb155:
  %t638 = load i64, ptr %l49, !tbaa !24
  %t640 = icmp sgt i64 %t638, 0
  br i1 %t640, label %bb157, label %bb158
bb156:
  store i64 0, ptr %l318, !tbaa !24
  br label %bb160
bb157:
  %t642 = load i64, ptr %l48, !tbaa !24
  %t643 = load i64, ptr %l47, !tbaa !24
  %t646 = sub i64 %t642, %t643
  %t647 = load i64, ptr %l49, !tbaa !24
  %t650 = add i64 %t646, %t647
  %t652 = sub i64 %t650, 1
  %t653 = load i64, ptr %l49, !tbaa !24
  %t656 = sdiv i64 %t652, %t653
  store i64 %t656, ptr %l321, !tbaa !24
  br label %bb159
bb158:
  store i64 0, ptr %l321, !tbaa !24
  br label %bb159
bb159:
  %t658 = load i64, ptr %l321, !tbaa !24
  store i64 %t658, ptr %l318, !tbaa !24
  br label %bb160
bb160:
  %t659 = load i64, ptr %l318, !tbaa !24
  store i64 %t659, ptr %l50, !tbaa !24
  store i64 0, ptr %l51, !tbaa !24
  br label %bb161
bb161:
  %t660 = load i64, ptr %l51, !tbaa !24
  %t661 = load i64, ptr %l50, !tbaa !24
  %t664 = icmp slt i64 %t660, %t661
  %t666 = xor i1 %t664, true
  br i1 %t666, label %bb162, label %bb163
bb162:
  br label %bb167
bb163:
  br label %bb164
bb164:
  %t668 = load i64, ptr %l47, !tbaa !24
  %t669 = load i64, ptr %l51, !tbaa !24
  %t670 = load i64, ptr %l49, !tbaa !24
  %t673 = mul i64 %t669, %t670
  %t676 = add i64 %t668, %t673
  store i64 -1, ptr %l54, !tbaa !24
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t682 = getelementptr %"compiler/bindgen:gen", ptr %t680, i32 0, i32 5
  %t686 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t682, i64 %t676)
  store ptr %t686, ptr %l343
  br label %bb165
bb165:
  %t687 = load ptr, ptr %l343, !tbaa !29
  %t689 = load i64, ptr %l54, !tbaa !24
  %t692 = getelementptr %"compiler/bindgen:record", ptr %t687, i32 0, i32 9
  store i64 %t689, ptr %t692, !tbaa !24
  br label %bb166
bb166:
  %t693 = load i64, ptr %l51, !tbaa !24
  %t695 = add i64 %t693, 1
  store i64 %t695, ptr %l51, !tbaa !24
  br label %bb161
bb167:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 18
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store { i64, ptr } %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 1
  %t25 = extractvalue { i64, ptr } %t22, 0
  %t26 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t24, i64 %t25)
  %t30 = getelementptr i8, ptr %t29, i64 %t25
  call void @olang_textcopy(ptr %t30, ptr %t26, i64 %t27)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t29, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t20, { i64, ptr } %t39)
  store i1 %t42, ptr %l20
  br label %bb7
bb7:
  %t43 = load i1, ptr %l20, !tbaa !21
  br i1 %t43, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t44 = load i64, ptr %l4, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l4, !tbaa !24
  br label %bb1
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/bindgen:gen", ptr %t48, i32 0, i32 18
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = extractvalue { i64, ptr } %t51, 0
  %t56 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t60 = extractvalue { i64, ptr } %a2, 1
  %t61 = extractvalue { i64, ptr } %a2, 0
  %t62 = add i64 %t58, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t54, i64 %t55)
  %t64 = getelementptr i8, ptr %t63, i64 %t55
  call void @olang_textcopy(ptr %t64, ptr %t56, i64 %t57)
  %t65 = getelementptr i8, ptr %t64, i64 %t57
  call void @olang_textcopy(ptr %t65, ptr %t60, i64 %t61)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t50, { i64, ptr } %t74)
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2espell(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 5
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:record", ptr %t9, i32 0, i32 11
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d307, i32 0, i32 1) })
  store i1 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/bindgen:record", ptr %t18, i32 0, i32 11
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t23, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"compiler/bindgen:record", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 1
  %t35 = extractvalue { i64, ptr } %t32, 0
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t34, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %lp6 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %v0, ptr %v1, ptr %v1, ptr %t1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d308, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t4, ptr %lp1
  %t5 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t6 = load ptr, ptr %lp1
  store { i64, ptr } %t5, ptr %t6, !tbaa !27
  %t7 = load ptr, ptr %lp1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d309, i32 0, i32 1) })
  store i1 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i1, ptr %l10, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %lp1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t15, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %v0, ptr %s2, ptr %t17)
  store { i64, ptr } %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = mul i64 %t21, 8
  %t24 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l22, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr ptr, ptr %t44, i64 %t41
  %t46 = load ptr, ptr %t45, !tbaa !39
  %t50 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s2, ptr %v1, ptr %t46)
  store { i64, ptr } %t50, ptr %l26
  br label %bb11
bb11:
  %t51 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t51, ptr %lp6
  %t52 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t53 = load ptr, ptr %lp6
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load ptr, ptr %lp6
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t55, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d310, i32 0, i32 1) })
  store i1 %t57, ptr %l28
  br label %bb12
bb12:
  %t58 = load i1, ptr %l28, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = load ptr, ptr %lp6
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t62, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l3, !tbaa !24
  br label %bb7
bb17:
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d311, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t68, ptr %l34, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l35, !tbaa !24
  %t71 = load i64, ptr %l35, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l36, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l35, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t82, ptr %l34, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2efirstError(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:LineIter"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t1)
  store %"std/prelude/text:LineIter" %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l5
  store %"std/prelude/text:LineIter" %t4, ptr %l1
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l1)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l9
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l8
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l9, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb6:
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d312, i32 0, i32 1) })
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l15
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb8, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l14
  br label %bb7
bb7:
  %t24 = load i64, ptr %l14, !tbaa !24
  store i64 %t24, ptr %l12, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb10
bb10:
  %t25 = load i64, ptr %l12, !tbaa !24
  store i64 %t25, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t30, ptr %l18, !tbaa !27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t31, 7
  store i64 %t33, ptr %l20, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t34, 0
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load i64, ptr %l20, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb13, label %bb14
bb12:
  br label %bb19
bb13:
  %t43 = load i64, ptr %l20, !tbaa !24
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b4f4b1f3947eb18f_4b11d328df759133)
  unreachable
bb15:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_b4f4b1f3947eb18f_4b11d328df759133)
  unreachable
bb17:
  %t51 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l20, !tbaa !24
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = getelementptr i8, ptr %t52, i64 %t53
  %t56 = sub i64 %t54, %t53
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = extractvalue { i64, ptr } %t58, 1
  %t61 = extractvalue { i64, ptr } %t58, 0
  %t62 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t60, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t64, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_b4f4b1f3947eb18f_4b11d328df759133)
  unreachable
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %bb2
bb21:
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t68 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s0, { i64, ptr } %t66)
  store { i64, ptr } %t68, ptr %l31
  br label %bb22
bb22:
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t70, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbindgen_2eflag(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %v1, ptr %v0, ptr %a0, { i64, ptr } %a1)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t13 = load ptr, ptr %l10, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l10, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 8}
  %t19 = icmp eq i64 %t17, 1
  store i1 %t19, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l11, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { i1 }, ptr %t23, i32 0, i32 0
  %t25 = load i1, ptr %t24
  store i1 %t25, ptr %l3, !tbaa !21
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t27 = load i1, ptr %l3, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_c89c4e9e31b29b9e_9d77991e4d65189a)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2einner(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %v0, ptr %v0, ptr %a0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d313, i32 0, i32 1) })
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb15
bb4:
  %t15 = load ptr, ptr %l8, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 8}
  %t18 = icmp eq i64 %t16, 6
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { { i64, ptr } }, ptr %t22, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l15, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l16, !tbaa !24
  %t30 = load i64, ptr %l16, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l16, !tbaa !24
  %t40 = mul i64 %t39, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t41, ptr %l15, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t42, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_6ea08524187c2be0_2ef7bb2e3d9cc7b4)
  unreachable
bb14:
  br label %bb15
bb15:
  %t43 = icmp sge i64 0, 0
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = icmp sle i64 0, 1152921504606846975
  br i1 %t45, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_feb39f4cfa8fb0e2_4824786a1f7bac1e)
  unreachable
bb18:
  %t47 = mul i64 0, 8
  %t48 = insertvalue { i64, ptr } undef, i64 0, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t49, ptr %rv
  br label %ret
bb19:
  call void @__olang_check_failed(ptr @olang_loc_feb39f4cfa8fb0e2_4824786a1f7bac1e)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca i1
  %l48 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb23
bb5:
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l16
  br label %bb6
bb6:
  %t19 = load i64, ptr %l16, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb12
bb9:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l23, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb11
bb11:
  %t46 = load i64, ptr %l23, !tbaa !24
  store i64 %t46, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t47 = load i64, ptr %l20, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  br label %bb22
bb15:
  br label %bb16
bb16:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l8, !tbaa !24
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"std/json:Object", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l42, !tbaa !27
  %t70 = load i64, ptr %l8, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %t73, i64 %t70
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !37
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t75, { i64, ptr } %a1)
  store i1 %t79, ptr %l46
  br label %bb17
bb17:
  %t80 = load i1, ptr %l46, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr %"std/json:Object", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l48, !tbaa !27
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr ptr, ptr %t88, i64 %t85
  %t90 = load ptr, ptr %t89, !tbaa !39
  store ptr %t90, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb13
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_76a363c24681a0e6_dedc35590a663c5a)
  unreachable
bb28:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr @G_2ecompiler_2fbindgen_2eNoReturnAttr, !tbaa !27
  %t3 = load ptr, ptr @__olang_prog_scope
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %t3, { i64, ptr } %t1, { i64, ptr } %t2)
  store i1 %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load i1, ptr %l3, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = load { i64, ptr }, ptr @G_2ecompiler_2fbindgen_2eNoReturnAttr, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t17 = sub i64 %t11, %t14
  store i64 %t17, ptr %l9, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l10, !tbaa !24
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  br label %bb10
bb4:
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sle i64 0, %t22
  br i1 %t23, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_98d0b4f031acf4f7_7a1fbeedfef40c4b)
  unreachable
bb6:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_98d0b4f031acf4f7_7a1fbeedfef40c4b)
  unreachable
bb8:
  %t29 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l9, !tbaa !24
  %t32 = getelementptr i8, ptr %t30, i64 0
  %t33 = sub i64 %t31, 0
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = extractvalue { i64, ptr } %t35, 0
  %t39 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t37, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_98d0b4f031acf4f7_7a1fbeedfef40c4b)
  unreachable
bb10:
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 1
  %t46 = extractvalue { i64, ptr } %t43, 0
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t45, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbindgen_2epreludeName(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue { i64, ptr } undef, i64 19, 0
  %t5 = insertvalue { i64, ptr } %t4, ptr @G_2ecompiler_2fbindgen_2epreludeNames, 1
  %t7 = load ptr, ptr @__olang_prog_scope
  %t10 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t7, ptr %v0, { i64, ptr } %t5, { i64, ptr } %a0)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2eresultText(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l46 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca i1
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d314, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d315, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t7, ptr %l8, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l9, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l1, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t27 = sub i64 %t25, 1
  store i64 %t27, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp sge i64 %t29, 0
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb6, label %bb7
bb6:
  br label %bb19
bb7:
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t35, ptr %l17, !tbaa !27
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 %t36
  %t41 = load i8, ptr %t40, !tbaa !32
  %t43 = icmp eq i8 %t41, 41
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l1, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t49, ptr %l23, !tbaa !27
  %t50 = load i64, ptr %l2, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i8, ptr %t53, i64 %t50
  %t55 = load i8, ptr %t54, !tbaa !32
  %t57 = icmp eq i8 %t55, 40
  br i1 %t57, label %bb12, label %bb13
bb12:
  %t59 = load i64, ptr %l1, !tbaa !24
  %t61 = sub i64 %t59, 1
  store i64 %t61, ptr %l1, !tbaa !24
  %t63 = load i64, ptr %l1, !tbaa !24
  %t65 = icmp eq i64 %t63, 0
  br i1 %t65, label %bb14, label %bb15
bb13:
  br label %bb17
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = sub i64 %t67, 1
  store i64 %t69, ptr %l2, !tbaa !24
  br label %bb18
bb18:
  br label %bb5
bb19:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t73 = icmp sle i64 %t71, 0
  br i1 %t73, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d316, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t75, ptr %l36, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l37, !tbaa !24
  %t78 = load i64, ptr %l37, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l37, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t89, ptr %l36, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l39, !tbaa !27
  %t92 = load i64, ptr %l2, !tbaa !24
  store i64 %t92, ptr %l40, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l41, !tbaa !24
  %t95 = icmp sge i64 0, 0
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t97 = load i64, ptr %l40, !tbaa !24
  %t98 = icmp sle i64 0, %t97
  br i1 %t98, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_63a5955120245215_3bb90f7c84aecf01)
  unreachable
bb25:
  %t100 = load i64, ptr %l40, !tbaa !24
  %t101 = load i64, ptr %l41, !tbaa !24
  %t102 = icmp sle i64 %t100, %t101
  br i1 %t102, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_63a5955120245215_3bb90f7c84aecf01)
  unreachable
bb27:
  %t104 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = load i64, ptr %l40, !tbaa !24
  %t107 = getelementptr i8, ptr %t105, i64 0
  %t108 = sub i64 %t106, 0
  %t109 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t107, 1
  %t112 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %t110)
  store { i64, ptr } %t112, ptr %l46
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_63a5955120245215_3bb90f7c84aecf01)
  unreachable
bb29:
  %t113 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t113, ptr %l3, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d317, i32 0, i32 1) }, ptr %l49, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t118 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t114, { i64, ptr } %t117)
  store i1 %t118, ptr %l50
  br label %bb30
bb30:
  %t119 = load i1, ptr %l50, !tbaa !21
  br i1 %t119, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb34
bb32:
  %t120 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t122 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t120, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d318, i32 0, i32 1) })
  store i1 %t122, ptr %l53
  br label %bb33
bb33:
  %t123 = load i1, ptr %l53, !tbaa !21
  store i1 %t123, ptr %l51, !tbaa !21
  br label %bb34
bb34:
  %t124 = load i1, ptr %l51, !tbaa !21
  br i1 %t124, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d319, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t125, ptr %l55, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l56, !tbaa !24
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l57, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l56, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t139, ptr %l55, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t140 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t140, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t141 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = extractvalue { i64, ptr } %t141, 0
  %t145 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t143, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t147, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2etextLiteral(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i8
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l55 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l95 = alloca i8
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l101 = alloca i8
  %l106 = alloca i64
  %l107 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l115 = alloca { i64, ptr }
  %l116 = alloca i64
  %l117 = alloca i32
  %l118 = alloca i64
  %l119 = alloca i32
  %l123 = alloca i1
  %l132 = alloca i1
  %l137 = alloca i1
  %l138 = alloca { i64, ptr }
  %l142 = alloca i1
  %l143 = alloca { i64, ptr }
  %l150 = alloca i64
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i64
  %l158 = alloca { i64, ptr }
  %l159 = alloca i64
  %l160 = alloca i32
  %l161 = alloca i64
  %l162 = alloca i32
  %l164 = alloca i64
  %l186 = alloca i1
  %l189 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l191 = alloca i64
  %l192 = alloca { i64, ptr }
  %l195 = alloca i1
  %l204 = alloca i1
  %l211 = alloca ptr
  %l213 = alloca i8
  %l214 = alloca i64
  %l215 = alloca i32
  %l216 = alloca { i64, ptr }
  %l218 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d320, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t7, ptr %l16, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l17, !tbaa !24
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l18, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t23, ptr %l19
  br label %bb4
bb4:
  %t24 = load %"std/prelude/text:StringBuilder", ptr %l19
  store %"std/prelude/text:StringBuilder" %t24, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t26, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb7, label %bb8
bb7:
  br label %bb163
bb8:
  br label %bb9
bb9:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l28, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %t44, i64 %t41
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !37
  store { i64, ptr } %t46, ptr %l5, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = icmp slt i64 %t50, 2
  br i1 %t52, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb12
bb11:
  %t54 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 0
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = icmp ne i8 %t58, 34
  store i1 %t60, ptr %l34, !tbaa !21
  br label %bb12
bb12:
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d321, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t63, ptr %l39, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load i64, ptr %l40, !tbaa !24
  %t67 = mul i64 %t66, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l41, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l40, !tbaa !24
  %t76 = mul i64 %t75, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t72, ptr %t74, i64 %t76, i1 false)
  %t77 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t77, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t78 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t78, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  store i64 1, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = sub i64 %t82, 1
  %t87 = icmp slt i64 %t79, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb17, label %bb18
bb17:
  br label %bb161
bb18:
  br label %bb19
bb19:
  %t91 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t91, ptr %l48, !tbaa !27
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i8, ptr %t95, i64 %t92
  %t97 = load i8, ptr %t96, !tbaa !32
  store i8 %t97, ptr %l7, !tbaa !22
  %t99 = load i8, ptr %l7, !tbaa !22
  %t101 = icmp ne i8 %t99, 92
  br i1 %t101, label %bb20, label %bb21
bb20:
  %t103 = load i8, ptr %l7, !tbaa !22
  %t105 = icmp eq i8 %t103, 34
  br i1 %t105, label %bb22, label %bb23
bb21:
  br label %bb30
bb22:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb24
bb23:
  %t107 = load i8, ptr %l7, !tbaa !22
  %t109 = icmp eq i8 %t107, 92
  store i1 %t109, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t111 = load i1, ptr %l55, !tbaa !21
  br i1 %t111, label %bb25, label %bb26
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t113 = load i8, ptr %l7, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t113)
  br label %bb29
bb29:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l6, !tbaa !24
  br label %bb160
bb30:
  %t120 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l6, !tbaa !24
  %t124 = load i64, ptr %l6, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t129 = sub i64 %t127, 1
  %t132 = icmp sge i64 %t124, %t129
  br i1 %t132, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d322, i32 0, i32 1) }, ptr %l70, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t134, ptr %l71, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l72, !tbaa !24
  %t137 = load i64, ptr %l72, !tbaa !24
  %t138 = mul i64 %t137, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l73, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l72, !tbaa !24
  %t147 = mul i64 %t146, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t143, ptr %t145, i64 %t147, i1 false)
  %t148 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t148, ptr %l71, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t149 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t149, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t150 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t150, ptr %l74, !tbaa !27
  %t151 = load i64, ptr %l6, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i8, ptr %t154, i64 %t151
  %t156 = load i8, ptr %t155, !tbaa !32
  store i8 %t156, ptr %l8, !tbaa !22
  store i64 -1, ptr %l9, !tbaa !24
  %t158 = load i8, ptr %l8, !tbaa !22
  %t160 = icmp eq i8 %t158, 120
  br i1 %t160, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t162 = load i64, ptr %l6, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l10, !tbaa !24
  br label %bb36
bb35:
  %t166 = load i8, ptr %l8, !tbaa !22
  %t168 = icmp uge i8 %t166, 48
  br i1 %t168, label %bb66, label %bb67
bb36:
  %t170 = load i64, ptr %l10, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t175 = sub i64 %t173, 1
  %t178 = icmp slt i64 %t170, %t175
  br i1 %t178, label %bb37, label %bb38
bb37:
  %t180 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t180, ptr %l87, !tbaa !27
  %t181 = load i64, ptr %l10, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i8, ptr %t184, i64 %t181
  %t186 = load i8, ptr %t185, !tbaa !32
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t186)
  store i1 %t188, ptr %l90
  br label %bb39
bb38:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb48
bb39:
  %t189 = load i1, ptr %l90, !tbaa !21
  br i1 %t189, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb47
bb41:
  %t190 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t190, ptr %l92, !tbaa !27
  %t191 = load i64, ptr %l10, !tbaa !24
  %t193 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr i8, ptr %t194, i64 %t191
  %t196 = load i8, ptr %t195, !tbaa !32
  %t198 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t196)
  store i8 %t198, ptr %l95
  br label %bb42
bb42:
  %t199 = load i8, ptr %l95, !tbaa !22
  %t200 = icmp uge i8 %t199, 97
  br i1 %t200, label %bb43, label %bb44
bb43:
  %t202 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t202, ptr %l98, !tbaa !27
  %t203 = load i64, ptr %l10, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i8, ptr %t206, i64 %t203
  %t208 = load i8, ptr %t207, !tbaa !32
  %t210 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t208)
  store i8 %t210, ptr %l101
  br label %bb45
bb44:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb46
bb45:
  %t211 = load i8, ptr %l101, !tbaa !22
  %t212 = icmp ule i8 %t211, 102
  store i1 %t212, ptr %l97, !tbaa !21
  br label %bb46
bb46:
  %t214 = load i1, ptr %l97, !tbaa !21
  store i1 %t214, ptr %l91, !tbaa !21
  br label %bb47
bb47:
  %t215 = load i1, ptr %l91, !tbaa !21
  store i1 %t215, ptr %l86, !tbaa !21
  br label %bb48
bb48:
  %t216 = load i1, ptr %l86, !tbaa !21
  %t217 = xor i1 %t216, true
  br i1 %t217, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t219 = load i64, ptr %l10, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l10, !tbaa !24
  br label %bb52
bb52:
  br label %bb36
bb53:
  %t223 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t223, ptr %l107, !tbaa !27
  %t224 = load i64, ptr %l6, !tbaa !24
  %t226 = add i64 %t224, 1
  store i64 %t226, ptr %l109, !tbaa !24
  %t227 = load i64, ptr %l10, !tbaa !24
  store i64 %t227, ptr %l110, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  store i64 %t229, ptr %l111, !tbaa !24
  %t230 = load i64, ptr %l109, !tbaa !24
  %t231 = icmp sge i64 %t230, 0
  br i1 %t231, label %bb54, label %bb55
bb54:
  %t233 = load i64, ptr %l109, !tbaa !24
  %t234 = load i64, ptr %l110, !tbaa !24
  %t235 = icmp sle i64 %t233, %t234
  br i1 %t235, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_d82489adf04aec69_8da73aeba875ea7d)
  unreachable
bb56:
  %t237 = load i64, ptr %l110, !tbaa !24
  %t238 = load i64, ptr %l111, !tbaa !24
  %t239 = icmp sle i64 %t237, %t238
  br i1 %t239, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_d82489adf04aec69_8da73aeba875ea7d)
  unreachable
bb58:
  %t241 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = load i64, ptr %l109, !tbaa !24
  %t244 = load i64, ptr %l110, !tbaa !24
  %t245 = getelementptr i8, ptr %t242, i64 %t243
  %t246 = sub i64 %t244, %t243
  %t247 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t245, 1
  store { i64, ptr } %t248, ptr %l115, !tbaa !27
  %t249 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s9, i64 16)
  %t250 = extractvalue { i32, i64 } %t249, 1
  %t251 = extractvalue { i32, i64 } %t249, 0
  store i32 %t251, ptr %l117
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb61, label %ok.253, !prof !99
ok.253:
  store i64 %t250, ptr %l116
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_d82489adf04aec69_8da73aeba875ea7d)
  unreachable
bb60:
  %t254 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t255 = load i64, ptr %l116, !tbaa !24
  %t256 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t254, i64 %t255)
  %t257 = extractvalue { i32, i64 } %t256, 1
  %t258 = extractvalue { i32, i64 } %t256, 0
  store i32 %t258, ptr %l119
  %t259 = icmp ne i32 %t258, 0
  br i1 %t259, label %bb64, label %ok.260, !prof !99
ok.260:
  store i64 %t257, ptr %l118
  br label %bb63
bb61:
  br label %bb62
bb62:
  store i64 -1, ptr %l106, !tbaa !24
  br label %bb65
bb63:
  %t261 = load i64, ptr %l118, !tbaa !24
  store i64 %t261, ptr %l106, !tbaa !24
  br label %bb65
bb64:
  br label %bb62
bb65:
  %t262 = load i64, ptr %l106, !tbaa !24
  store i64 %t262, ptr %l9, !tbaa !24
  %t263 = load i64, ptr %l10, !tbaa !24
  store i64 %t263, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb132
bb66:
  %t265 = load i8, ptr %l8, !tbaa !22
  %t267 = icmp ule i8 %t265, 55
  store i1 %t267, ptr %l123, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb68
bb68:
  %t269 = load i1, ptr %l123, !tbaa !21
  br i1 %t269, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s12
  %t270 = load i64, ptr %l6, !tbaa !24
  store i64 %t270, ptr %l11, !tbaa !24
  br label %bb71
bb70:
  %t272 = load i8, ptr %l8, !tbaa !22
  %t274 = icmp eq i8 %t272, 110
  br i1 %t274, label %bb98, label %bb99
bb71:
  %t276 = load i64, ptr %l11, !tbaa !24
  %t277 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t281 = sub i64 %t279, 1
  %t284 = icmp slt i64 %t276, %t281
  br i1 %t284, label %bb72, label %bb73
bb72:
  %t286 = load i64, ptr %l11, !tbaa !24
  %t287 = load i64, ptr %l6, !tbaa !24
  %t289 = add i64 %t287, 3
  %t292 = icmp slt i64 %t286, %t289
  store i1 %t292, ptr %l132, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb74
bb74:
  %t294 = load i1, ptr %l132, !tbaa !21
  br i1 %t294, label %bb75, label %bb76
bb75:
  %t295 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t295, ptr %l138, !tbaa !27
  %t296 = load i64, ptr %l11, !tbaa !24
  %t298 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr i8, ptr %t299, i64 %t296
  %t301 = load i8, ptr %t300, !tbaa !32
  %t303 = icmp uge i8 %t301, 48
  store i1 %t303, ptr %l137, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb77
bb77:
  %t305 = load i1, ptr %l137, !tbaa !21
  br i1 %t305, label %bb78, label %bb79
bb78:
  %t306 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t306, ptr %l143, !tbaa !27
  %t307 = load i64, ptr %l11, !tbaa !24
  %t309 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr i8, ptr %t310, i64 %t307
  %t312 = load i8, ptr %t311, !tbaa !32
  %t314 = icmp ule i8 %t312, 55
  store i1 %t314, ptr %l142, !tbaa !21
  br label %bb80
bb79:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb80
bb80:
  %t316 = load i1, ptr %l142, !tbaa !21
  %t317 = xor i1 %t316, true
  br i1 %t317, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  br label %bb83
bb83:
  %t319 = load i64, ptr %l11, !tbaa !24
  %t321 = add i64 %t319, 1
  store i64 %t321, ptr %l11, !tbaa !24
  br label %bb84
bb84:
  br label %bb71
bb85:
  %t323 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t323, ptr %l151, !tbaa !27
  %t324 = load i64, ptr %l6, !tbaa !24
  store i64 %t324, ptr %l152, !tbaa !24
  %t325 = load i64, ptr %l11, !tbaa !24
  store i64 %t325, ptr %l153, !tbaa !24
  %t326 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 0
  store i64 %t327, ptr %l154, !tbaa !24
  %t328 = load i64, ptr %l152, !tbaa !24
  %t329 = icmp sge i64 %t328, 0
  br i1 %t329, label %bb86, label %bb87
bb86:
  %t331 = load i64, ptr %l152, !tbaa !24
  %t332 = load i64, ptr %l153, !tbaa !24
  %t333 = icmp sle i64 %t331, %t332
  br i1 %t333, label %bb88, label %bb89
bb87:
  call void @__olang_check_failed(ptr @olang_loc_e159f608b90be7c_888d447c7b7c1020)
  unreachable
bb88:
  %t335 = load i64, ptr %l153, !tbaa !24
  %t336 = load i64, ptr %l154, !tbaa !24
  %t337 = icmp sle i64 %t335, %t336
  br i1 %t337, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_e159f608b90be7c_888d447c7b7c1020)
  unreachable
bb90:
  %t339 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = load i64, ptr %l152, !tbaa !24
  %t342 = load i64, ptr %l153, !tbaa !24
  %t343 = getelementptr i8, ptr %t340, i64 %t341
  %t344 = sub i64 %t342, %t341
  %t345 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t343, 1
  store { i64, ptr } %t346, ptr %l158, !tbaa !27
  %t347 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s12, i64 8)
  %t348 = extractvalue { i32, i64 } %t347, 1
  %t349 = extractvalue { i32, i64 } %t347, 0
  store i32 %t349, ptr %l160
  %t350 = icmp ne i32 %t349, 0
  br i1 %t350, label %bb93, label %ok.351, !prof !99
ok.351:
  store i64 %t348, ptr %l159
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_e159f608b90be7c_888d447c7b7c1020)
  unreachable
bb92:
  %t352 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t353 = load i64, ptr %l159, !tbaa !24
  %t354 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t352, i64 %t353)
  %t355 = extractvalue { i32, i64 } %t354, 1
  %t356 = extractvalue { i32, i64 } %t354, 0
  store i32 %t356, ptr %l162
  %t357 = icmp ne i32 %t356, 0
  br i1 %t357, label %bb96, label %ok.358, !prof !99
ok.358:
  store i64 %t355, ptr %l161
  br label %bb95
bb93:
  br label %bb94
bb94:
  store i64 -1, ptr %l150, !tbaa !24
  br label %bb97
bb95:
  %t359 = load i64, ptr %l161, !tbaa !24
  store i64 %t359, ptr %l150, !tbaa !24
  br label %bb97
bb96:
  br label %bb94
bb97:
  %t360 = load i64, ptr %l150, !tbaa !24
  store i64 %t360, ptr %l9, !tbaa !24
  %t361 = load i64, ptr %l11, !tbaa !24
  store i64 %t361, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb131
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  store i64 10, ptr %l164, !tbaa !24
  br label %bb130
bb101:
  %t363 = load i8, ptr %l8, !tbaa !22
  %t365 = icmp eq i8 %t363, 116
  br i1 %t365, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  store i64 9, ptr %l164, !tbaa !24
  br label %bb130
bb105:
  %t367 = load i8, ptr %l8, !tbaa !22
  %t369 = icmp eq i8 %t367, 114
  br i1 %t369, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb109
bb108:
  store i64 13, ptr %l164, !tbaa !24
  br label %bb130
bb109:
  %t371 = load i8, ptr %l8, !tbaa !22
  %t373 = icmp eq i8 %t371, 97
  br i1 %t373, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  store i64 7, ptr %l164, !tbaa !24
  br label %bb130
bb113:
  %t375 = load i8, ptr %l8, !tbaa !22
  %t377 = icmp eq i8 %t375, 98
  br i1 %t377, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  store i64 8, ptr %l164, !tbaa !24
  br label %bb130
bb117:
  %t379 = load i8, ptr %l8, !tbaa !22
  %t381 = icmp eq i8 %t379, 102
  br i1 %t381, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  store i64 12, ptr %l164, !tbaa !24
  br label %bb130
bb121:
  %t383 = load i8, ptr %l8, !tbaa !22
  %t385 = icmp eq i8 %t383, 118
  br i1 %t385, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb125
bb124:
  store i64 11, ptr %l164, !tbaa !24
  br label %bb130
bb125:
  br i1 true, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  %t387 = load i8, ptr %l8, !tbaa !22
  %t390 = zext i8 %t387 to i64
  store i64 %t390, ptr %l164, !tbaa !24
  br label %bb130
bb129:
  call void @__olang_check_failed(ptr @olang_loc_2265f42fe0f29d10_7d9e15ddc2058014)
  unreachable
bb130:
  %t392 = load i64, ptr %l164, !tbaa !24
  store i64 %t392, ptr %l9, !tbaa !24
  %t393 = load i64, ptr %l6, !tbaa !24
  %t395 = add i64 %t393, 1
  store i64 %t395, ptr %l6, !tbaa !24
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t397 = load i64, ptr %l9, !tbaa !24
  %t399 = icmp slt i64 %t397, 0
  br i1 %t399, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb135
bb134:
  %t401 = load i64, ptr %l9, !tbaa !24
  %t403 = icmp sgt i64 %t401, 255
  store i1 %t403, ptr %l186, !tbaa !21
  br label %bb135
bb135:
  %t405 = load i1, ptr %l186, !tbaa !21
  br i1 %t405, label %bb136, label %bb137
bb136:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d323, i32 0, i32 1) }, ptr %l189, !tbaa !27
  %t406 = load { i64, ptr }, ptr %l189, !tbaa !27
  store { i64, ptr } %t406, ptr %l190, !tbaa !27
  %t407 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t408 = extractvalue { i64, ptr } %t407, 0
  store i64 %t408, ptr %l191, !tbaa !24
  %t409 = load i64, ptr %l191, !tbaa !24
  %t410 = mul i64 %t409, 1
  %t411 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t410)
  %t412 = insertvalue { i64, ptr } undef, i64 %t409, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t411, 1
  store { i64, ptr } %t413, ptr %l192, !tbaa !27
  %t414 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t415 = load ptr, ptr %t414, !tbaa !27
  %t416 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !27
  %t418 = load i64, ptr %l191, !tbaa !24
  %t419 = mul i64 %t418, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t415, ptr %t417, i64 %t419, i1 false)
  %t420 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t420, ptr %l190, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t421 = load { i64, ptr }, ptr %l190, !tbaa !27
  store { i64, ptr } %t421, ptr %rv
  br label %ret
bb137:
  br label %bb138
bb138:
  %t422 = load i64, ptr %l9, !tbaa !24
  %t424 = icmp eq i64 %t422, 34
  br i1 %t424, label %bb139, label %bb140
bb139:
  store i1 true, ptr %l195, !tbaa !21
  br label %bb141
bb140:
  %t426 = load i64, ptr %l9, !tbaa !24
  %t428 = icmp eq i64 %t426, 92
  store i1 %t428, ptr %l195, !tbaa !21
  br label %bb141
bb141:
  %t430 = load i1, ptr %l195, !tbaa !21
  br i1 %t430, label %bb142, label %bb143
bb142:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb144
bb143:
  %t432 = load i64, ptr %l9, !tbaa !24
  %t434 = icmp sge i64 %t432, 32
  br i1 %t434, label %bb146, label %bb147
bb144:
  %t436 = load i64, ptr %l9, !tbaa !24
  %t438 = trunc i64 %t436 to i8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t438)
  br label %bb145
bb145:
  br label %bb159
bb146:
  %t441 = load i64, ptr %l9, !tbaa !24
  %t443 = icmp slt i64 %t441, 127
  store i1 %t443, ptr %l204, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb148
bb148:
  %t445 = load i1, ptr %l204, !tbaa !21
  br i1 %t445, label %bb149, label %bb150
bb149:
  %t446 = load i64, ptr %l9, !tbaa !24
  %t448 = trunc i64 %t446 to i8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t448)
  br label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d324, i32 0, i32 1) })
  br label %bb152
bb151:
  br label %bb158
bb152:
  store ptr %l1, ptr %l211, !tbaa !29
  %t452 = load i64, ptr %l9, !tbaa !24
  %t454 = trunc i64 %t452 to i8
  store i8 %t454, ptr %l213, !tbaa !22
  %t455 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s27, i64 16)
  %t456 = extractvalue { i32, i64 } %t455, 1
  %t457 = extractvalue { i32, i64 } %t455, 0
  store i32 %t457, ptr %l215
  %t458 = icmp ne i32 %t457, 0
  br i1 %t458, label %bb154, label %ok.459, !prof !99
ok.459:
  store i64 %t456, ptr %l214
  br label %bb153
bb153:
  %t460 = load i8, ptr %l213, !tbaa !22
  %t461 = load i64, ptr %l214, !tbaa !24
  %t462 = call { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %s27, i8 %t460, i64 %t461)
  store { i64, ptr } %t462, ptr %l216
  br label %bb155
bb154:
  call void @__olang_check_failed(ptr @olang_loc_6de4e6ae025697a1_ab8e19fa95fbb0c5)
  unreachable
bb155:
  %t463 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t463, 0
  %t465 = extractvalue { i64, ptr } %t463, 1
  %t466 = mul i64 %t464, 1
  %t467 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t466)
  call void @llvm.memcpy.p0.p0.i64(ptr %t467, ptr %t465, i64 %t466, i1 false)
  %t468 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t469 = insertvalue { i64, ptr } %t468, ptr %t467, 1
  %t471 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s27, ptr %s27, { i64, ptr } %t469, i64 2, i8 48)
  store { i64, ptr } %t471, ptr %l218
  br label %bb156
bb156:
  %t472 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t472, 0
  %t474 = extractvalue { i64, ptr } %t472, 1
  %t475 = mul i64 %t473, 1
  %t476 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t475)
  call void @llvm.memcpy.p0.p0.i64(ptr %t476, ptr %t474, i64 %t475, i1 false)
  %t477 = insertvalue { i64, ptr } undef, i64 %t473, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t476, 1
  %t479 = load ptr, ptr %l211, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %t479, { i64, ptr } %t478)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s27)
  br label %bb158
bb158:
  br label %bb159
bb159:
  br label %bb160
bb160:
  br label %bb16
bb161:
  br label %bb162
bb162:
  %t481 = load i64, ptr %l3, !tbaa !24
  %t483 = add i64 %t481, 1
  store i64 %t483, ptr %l3, !tbaa !24
  br label %bb6
bb163:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb164
bb164:
  %t487 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t487, ptr %l224
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s0)
  %t488 = load { i64, ptr }, ptr %l224, !tbaa !27
  store { i64, ptr } %t488, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l6 = alloca i1
  %l7 = alloca i1
  %l9 = alloca i1
  %l11 = alloca { i64, ptr }
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca i1
  %l34 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l52 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d325, i32 0, i32 1) })
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d326, i32 0, i32 1) })
  store i1 %t7, ptr %l9
  br label %bb4
bb4:
  %t8 = load i1, ptr %l9, !tbaa !21
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l11, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 0
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp eq i8 %t15, 95
  br i1 %t17, label %bb9, label %bb10
bb9:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp slt i64 %t21, 2
  br i1 %t23, label %bb11, label %bb12
bb10:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb18
bb11:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb13
bb12:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 1
  %t29 = load i8, ptr %t28, !tbaa !32
  %t31 = icmp eq i8 %t29, 95
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb17
bb15:
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t34, ptr %l23, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 1
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t38)
  store i1 %t40, ptr %l25
  br label %bb16
bb16:
  %t41 = load i1, ptr %l25, !tbaa !21
  store i1 %t41, ptr %l22, !tbaa !21
  br label %bb17
bb17:
  %t42 = load i1, ptr %l22, !tbaa !21
  store i1 %t42, ptr %l14, !tbaa !21
  br label %bb18
bb18:
  %t43 = load i1, ptr %l14, !tbaa !21
  br i1 %t43, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t45, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l3, !tbaa !24
  br label %bb22
bb22:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb23, label %bb24
bb23:
  br label %bb38
bb24:
  br label %bb25
bb25:
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i8, ptr %t63, i64 %t60
  %t65 = load i8, ptr %t64, !tbaa !32
  store i8 %t65, ptr %l4, !tbaa !22
  %t67 = load i8, ptr %l4, !tbaa !22
  %t69 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t67)
  store i1 %t69, ptr %l38
  br label %bb26
bb26:
  %t70 = load i1, ptr %l38, !tbaa !21
  br i1 %t70, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb30
bb28:
  %t71 = load i8, ptr %l4, !tbaa !22
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t71)
  store i1 %t73, ptr %l41
  br label %bb29
bb29:
  %t74 = load i1, ptr %l41, !tbaa !21
  store i1 %t74, ptr %l39, !tbaa !21
  br label %bb30
bb30:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb33
bb32:
  %t76 = load i8, ptr %l4, !tbaa !22
  %t78 = icmp eq i8 %t76, 95
  store i1 %t78, ptr %l42, !tbaa !21
  br label %bb33
bb33:
  %t80 = load i1, ptr %l42, !tbaa !21
  %t81 = xor i1 %t80, true
  br i1 %t81, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t84 = load i64, ptr %l2, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l2, !tbaa !24
  br label %bb22
bb38:
  %t88 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t94 = call i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %t88, i64 0, i64 %t91)
  store i32 %t94, ptr %l52
  br label %bb39
bb39:
  %t95 = load i32, ptr %l52, !range !{i32 0, i32 98}
  %t97 = trunc i64 1 to i32
  %t98 = icmp eq i32 %t95, %t97
  call void @__olang_scope_close(ptr %s0)
  store i1 %t98, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/bindgen:Translation" @compiler_2fbindgen_3aTranslation_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/bindgen:Translation"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d327, i32 0, i32 1) }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d328, i32 0, i32 1) }, ptr %l1, !tbaa !27
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d329, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = insertvalue %"compiler/bindgen:Translation" undef, { i64, ptr } %t3, 0
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = insertvalue %"compiler/bindgen:Translation" %t4, { i64, ptr } %t5, 1
  %t8 = insertvalue %"compiler/bindgen:Translation" %t6, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, 2
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = insertvalue %"compiler/bindgen:Translation" %t8, { i64, ptr } %t9, 3
  %t12 = insertvalue %"compiler/bindgen:Translation" %t10, i1 false, 4
  store %"compiler/bindgen:Translation" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:Translation", ptr %rv
  ret %"compiler/bindgen:Translation" %rr
}

define dso_local %"compiler/bindgen:cFunc" @compiler_2fbindgen_3acFunc_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/bindgen:cFunc"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/bindgen:cFunc" undef, { i64, ptr } %a0, 0
  %t16 = insertvalue %"compiler/bindgen:cFunc" %t14, { i64, ptr } %a1, 1
  %t18 = insertvalue %"compiler/bindgen:cFunc" %t16, { i64, ptr } %a2, 2
  %t20 = insertvalue %"compiler/bindgen:cFunc" %t18, { i64, ptr } %a3, 3
  %t22 = insertvalue %"compiler/bindgen:cFunc" %t20, i1 %a4, 4
  %t24 = insertvalue %"compiler/bindgen:cFunc" %t22, { i64, ptr } %a5, 5
  store %"compiler/bindgen:cFunc" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cFunc", ptr %rv
  ret %"compiler/bindgen:cFunc" %rr
}

define dso_local %"compiler/bindgen:cMacro" @compiler_2fbindgen_3acMacro_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, i1 %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/bindgen:cMacro"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/bindgen:cMacro" undef, { i64, ptr } %a0, 0
  %t14 = insertvalue %"compiler/bindgen:cMacro" %t12, i1 %a1, 1
  %t16 = insertvalue %"compiler/bindgen:cMacro" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/bindgen:cMacro" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/bindgen:cMacro" %t18, i1 %a4, 4
  %t22 = insertvalue %"compiler/bindgen:cMacro" %t20, i1 false, 5
  store %"compiler/bindgen:cMacro" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cMacro", ptr %rv
  ret %"compiler/bindgen:cMacro" %rr
}

define dso_local %"compiler/bindgen:ctp" @compiler_2fbindgen_3actp_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %rv = alloca %"compiler/bindgen:ctp"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"compiler/bindgen:ctp" undef, { i64, ptr } %a0, 0
  %t6 = insertvalue %"compiler/bindgen:ctp" %t4, i64 0, 1
  store %"compiler/bindgen:ctp" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:ctp", ptr %rv
  ret %"compiler/bindgen:ctp" %rr
}

define dso_local %"compiler/bindgen:ctype" @compiler_2fbindgen_3actype_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1, i64 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/bindgen:ctype"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/bindgen:ctype" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/bindgen:ctype" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/bindgen:ctype" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/bindgen:ctype" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/bindgen:ctype" %t18, i64 %a4, 4
  %t22 = insertvalue %"compiler/bindgen:ctype" %t20, i64 0, 5
  store %"compiler/bindgen:ctype" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:ctype", ptr %rv
  ret %"compiler/bindgen:ctype" %rr
}

define dso_local %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/bindgen:cx"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/bindgen:cx" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/bindgen:cx" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/bindgen:cx" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/bindgen:cx" %t14, { i64, ptr } %a3, 3
  store %"compiler/bindgen:cx" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cx", ptr %rv
  ret %"compiler/bindgen:cx" %rr
}

define dso_local void @compiler_2fbindgen_3arecord_2ector(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"compiler/bindgen:record"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i1 false, ptr %l2, !tbaa !21
  store i1 false, ptr %l3, !tbaa !21
  store i1 false, ptr %l4, !tbaa !21
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l5
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l18
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d330, i32 0, i32 1) }, ptr %l8, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d331, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t7 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 1
  %t10 = load i1, ptr %l2, !tbaa !21
  store i1 %t10, ptr %t9, !tbaa !21
  %t11 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 2
  %t12 = load i1, ptr %l3, !tbaa !21
  store i1 %t12, ptr %t11, !tbaa !21
  %t13 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 3
  %t14 = load i1, ptr %l4, !tbaa !21
  store i1 %t14, ptr %t13, !tbaa !21
  %t15 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 4
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t15
  %t17 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t17
  %t19 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 6
  store i1 false, ptr %t19, !tbaa !21
  %t21 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 7
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t22, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 8
  store i1 false, ptr %t23, !tbaa !21
  %t25 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 9
  store i64 -1, ptr %t25, !tbaa !24
  %t27 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 10
  store i1 false, ptr %t27, !tbaa !21
  %t29 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 11
  %t30 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t30, ptr %t29, !tbaa !27
  %t31 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 12
  store i1 false, ptr %t31, !tbaa !21
  %t33 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 13
  store i64 -1, ptr %t33, !tbaa !24
  %t35 = getelementptr %"compiler/bindgen:record", ptr %l19, i32 0, i32 14
  store i64 -1, ptr %t35, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l19, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"a C import needs clang, and there is none on the PATH" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang-cimport" }>, align 8
declare void @__olang_errpay_pop()
@.d4 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"a temporary directory cannot be made" }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"probe.c" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d7 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the probe cannot be written" }>, align 8
define linkonce_odr %"compiler/bindgen:Translation" @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3aTranslation(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/bindgen:Translation"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/bindgen:Translation"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/bindgen:Translation", ptr %a0
  store %"compiler/bindgen:Translation" %t2, ptr %l1
  %t3 = getelementptr %"compiler/bindgen:Translation", ptr %l1, i32 0, i32 2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/bindgen:Translation", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/bindgen:Translation", ptr %l1
  store %"compiler/bindgen:Translation" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:Translation", ptr %rv
  ret %"compiler/bindgen:Translation" %rr
}

@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-E" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-dD" }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-w" }>, align 8
@.d15 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"clang could not be run" }>, align 8
@.d16 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"file not found" }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d19 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"enum __olang_m" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d20 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" : long long { __olang_v" }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" = (" }>, align 8
@.d22 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c") };\0A" }>, align 8
@.d23 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the probe cannot be written" }>, align 8
@.d24 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d25 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d26 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d27 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"__olang_m" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"# olang's translation of " }>, align 8
@.d30 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c" (X17), made by the compiler: C's declarations as olang declares them\0A" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"/* olang C import: " }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" */\0A" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d35 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0x" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d38 = private constant <{ i64, [4 x { i64, ptr }] }> <{ i64 0, [4 x { i64, ptr }] [{ i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d332, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d333, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d335, i32 0, i32 1) }] }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"<<=" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c">>=" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d42 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"<<" }>, align 8
@.d43 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">>" }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"<=" }>, align 8
@.d45 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">=" }>, align 8
@.d46 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"==" }>, align 8
@.d47 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!=" }>, align 8
@.d48 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&&" }>, align 8
@.d49 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"||" }>, align 8
@.d50 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"##" }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"->" }>, align 8
@.d52 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"++" }>, align 8
@.d53 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"--" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&&" }>, align 8
@.d56 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"||" }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&&" }>, align 8
@.d58 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d59 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" or " }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d66 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d67 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d73 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a ? with no :" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d75 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d76 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" else " }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d80 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d81 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" else " }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d83 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0x" }>, align 8
@.d84 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"p" }>, align 8
@.d87 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"a hexadecimal float" }>, align 8
@.d88 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a long double" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d91 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".0" }>, align 8
@.d92 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0b" }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d94 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d95 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d96 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"', which is no number read here" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d98 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"+" }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"~" }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"+" }>, align 8
@.d101 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d102 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d103 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d104 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(not " }>, align 8
@.d105 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d106 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d109 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d110 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d111 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d112 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d114 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d115 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d116 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d117 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d118 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d120 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"-fsyntax-only" }>, align 8
@.d121 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-w" }>, align 8
@.d122 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"-ferror-limit=0" }>, align 8
@.d123 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-Xclang" }>, align 8
@.d124 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"-ast-dump=json" }>, align 8
@.d125 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"clang could not be run" }>, align 8
@.d126 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"clang's tree could not be read" }>, align 8
@.d127 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"its expansion is too deep" }>, align 8
@.d128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d129 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"##" }>, align 8
@.d130 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"it uses # or ##, which make text rather than an expression" }>, align 8
@.d131 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d132 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d133 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"it uses " }>, align 8
@.d134 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c", which takes a variable number of arguments" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d136 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d138 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"its use of " }>, align 8
@.d139 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" is not closed" }>, align 8
@.d140 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"it gives " }>, align 8
@.d141 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" another number of arguments" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_142(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %vc0, { i64, ptr } %a0, { i64, ptr } %cv0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d143 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d145 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d146 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d147 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a struct held in place that is not plain data (X11)" }>, align 8
@.d148 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"CStr?&" }>, align 8
@.d149 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d150 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"CVoid?&" }>, align 8
@.d151 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a field of this type, which has no olang form" }>, align 8
@.d152 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d153 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"its type is no function's" }>, align 8
@.d154 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d155 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d156 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d157 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d158 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d159 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d160 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", ..." }>, align 8
@.d161 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d162 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d163 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d164 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" noreturn" }>, align 8
@.d165 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d166 = private constant <{ i64, [3 x { i64, ptr }] }> <{ i64 0, [3 x { i64, ptr }] [{ i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d336, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d337, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d338, i32 0, i32 1) }] }>, align 8
@.d167 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d168 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"its body is empty" }>, align 8
@.d169 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"its body is no expression read here, at '" }>, align 8
@.d170 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d171 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d172 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d173 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d174 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d175 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"T" }>, align 8
@.d176 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d177 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d178 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d179 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d180 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d181 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" T" }>, align 8
@.d182 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d183 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"T" }>, align 8
@.d184 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d185 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d186 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d187 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" { return " }>, align 8
@.d188 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/bindgen:record"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 176, i1 false)
  %t2 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 4
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

@.d189 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d190 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d191 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d192 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d193 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c_" }>, align 8
@.d194 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"_t" }>, align 8
@.d195 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d196 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d197 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_Bool" }>, align 8
@.d198 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bool" }>, align 8
@.d199 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d200 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d201 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d202 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d203 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d204 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d205 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d206 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d207 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"long double" }>, align 8
@.d208 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d209 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_Float16" }>, align 8
@.d210 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d211 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"__bf16" }>, align 8
@.d212 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d213 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__int128" }>, align 8
@.d214 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__int128" }>, align 8
@.d215 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"short" }>, align 8
@.d216 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d217 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d218 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d219 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d220 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d221 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d222 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d223 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d224 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d225 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"its text is no olang text literal" }>, align 8
@.d226 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" String = " }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d227 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"f" }>, align 8
@.d228 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d229 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"f" }>, align 8
@.d230 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" F32 = " }>, align 8
@.d231 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" F64 = " }>, align 8
@.d232 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"its body is no constant" }>, align 8
@.d233 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"CVoid" }>, align 8
@.d234 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"CStr" }>, align 8
@.d235 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d236 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d237 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d238 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d239 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d240 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d241 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"mut Array<" }>, align 8
@.d242 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">&" }>, align 8
@.d243 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d244 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d245 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d246 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mut Array<CStr?&>&" }>, align 8
@.d247 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"mut Array<" }>, align 8
@.d248 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"?&>&" }>, align 8
@.d249 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mut Array<CVoid?&>&" }>, align 8
@.d250 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d251 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a callback taking a variable number of arguments" }>, align 8
@.d252 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fn?&(" }>, align 8
@.d253 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d254 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d255 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d256 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d257 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d258 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"loc" }>, align 8
@.d259 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"range" }>, align 8
@.d260 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"type" }>, align 8
@.d261 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"inner" }>, align 8
@.d262 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d263 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d264 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"TypedefDecl" }>, align 8
@.d265 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"ownedTagDecl" }>, align 8
@.d266 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"id" }>, align 8
@.d267 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct " }>, align 8
@.d268 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"union " }>, align 8
@.d269 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d270 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"RecordDecl" }>, align 8
@.d271 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d272 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d273 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"EnumConstantDecl" }>, align 8
@.d274 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d275 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d276 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"FunctionDecl" }>, align 8
@.d277 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"isImplicit" }>, align 8
@.d278 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d279 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"ParmVarDecl" }>, align 8
@.d280 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d281 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"storageClass" }>, align 8
@.d282 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"static" }>, align 8
@.d283 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"inline" }>, align 8
@.d284 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"mangledName" }>, align 8
@.d285 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d286 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d287 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"VarDecl" }>, align 8
@.d288 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"storageClass" }>, align 8
@.d289 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"static" }>, align 8
@.d290 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c": a variable - an extern variable has no olang form (X1)" }>, align 8
@.d291 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d292 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d293 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d294 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"enum __olang_l" }>, align 8
@.d295 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" : long long { __olang_z" }>, align 8
@.d296 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" = sizeof(" }>, align 8
@.d297 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"), __olang_a" }>, align 8
@.d298 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = _Alignof(" }>, align 8
@.d299 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c") };\0A" }>, align 8
@.d300 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the probe cannot be written" }>, align 8
@.d301 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d302 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d303 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d304 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"__olang_l" }>, align 8
@.d305 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d306 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c": a macro - " }>, align 8
@.d307 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d308 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"value" }>, align 8
@.d309 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d310 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d311 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d312 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"error: " }>, align 8
@.d313 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"inner" }>, align 8
@.d314 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d315 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d316 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d317 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d318 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d319 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d320 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d321 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d322 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d323 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d324 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cx" }>, align 8
@.d325 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d326 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d327 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d328 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d329 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d330 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d331 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d332 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d333 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"u" }>, align 8
@.d334 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"U" }>, align 8
@.d335 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"u8" }>, align 8
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d336 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d337 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d338 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2fbindgen_3agen_2ector(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @compiler_2fbindgen_2eclangSays(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ereadMacros(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbindgen_2etext(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_489a2a8be26135c1_2fe8a601822a7f65 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
@olang_loc_4691cb288a833ba5_dfaa9dffbec0c2d9 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8de001e7a64c0b48_1a9d06562d43232c = external constant [0 x i8]
@olang_loc_9f24fc1b10bf4163_f387df93e06eee97 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fbindgen_2ecPrec(ptr %v0, { i64, ptr } %a0)
declare %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/bindgen:cx" %a1)
declare %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/bindgen:cx" %a1)
declare %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecLead(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/bindgen:cx" %a1, %"compiler/bindgen:cx" %a2)
declare %"compiler/bindgen:cx" @compiler_2fbindgen_2elit(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_2281448cce404233_754aa41ddbc9325f = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_231822a9f2b4ccd6_f89b0d7c0520fae2 = external constant [0 x i8]
@olang_loc_3945c858895394b5_b3e6527511891161 = external constant [0 x i8]
@olang_loc_5833c224f66d4858_52a9715d8b07374 = external constant [0 x i8]
@olang_loc_8ffdd2b799db8b57_8707d2f5a85c3a7b = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecastType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecPrimary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i32, ptr } @std_2fjson_2eParse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Hdc04e7543082eec80486670259c0789b(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H40771be639b3022d183b79789a9eab56(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Hbb0b9cf8ae0bb786ffc6cf28ae45ef64(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eFindIndex_3cstd_2f_H0cdaf28864c9da4990596b1986b376a0(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H21d8db2bdfeb46fab755f8173a35f95e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_582986fcdf40d11c_2a39a940a03de888 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamType(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/bindgen:cparse" @compiler_2fbindgen_3acparse_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7ea854ff7e2640a8_63f49c54b749b4b4 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7e828aa3d49398bd_dbb08dcf54087001 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ePush_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:ctype" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eLen_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ebad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_588cbeac7c6acbe1_e04f9e86f435a7f5 = external constant [0 x i8]
@olang_loc_76a2c5c4ca94453d_57e44e0801590749 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbindgen_2evoidRef(ptr %v0, i1 %a0)
@olang_loc_55ef846781ac27aa_5519550b25564c26 = external constant [0 x i8]
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewanted(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ePush_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:cFunc" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ePush_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %a0)
declare %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_f6b0d4dcea5d2bc9_16e8d1d827605cbd = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_b4f4b1f3947eb18f_4b11d328df759133 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_c89c4e9e31b29b9e_9d77991e4d65189a = external constant [0 x i8]
@olang_loc_6ea08524187c2be0_2ef7bb2e3d9cc7b4 = external constant [0 x i8]
@olang_loc_feb39f4cfa8fb0e2_4824786a1f7bac1e = external constant [0 x i8]
declare i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %a0)
@olang_loc_76a363c24681a0e6_dedc35590a663c5a = external constant [0 x i8]
@olang_loc_98d0b4f031acf4f7_7a1fbeedfef40c4b = external constant [0 x i8]
@olang_loc_63a5955120245215_3bb90f7c84aecf01 = external constant [0 x i8]
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
@olang_loc_d82489adf04aec69_8da73aeba875ea7d = external constant [0 x i8]
@olang_loc_e159f608b90be7c_888d447c7b7c1020 = external constant [0 x i8]
@olang_loc_2265f42fe0f29d10_7d9e15ddc2058014 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %v0, i8 %a0, i64 %a1)
@olang_loc_6de4e6ae025697a1_ab8e19fa95fbb0c5 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
