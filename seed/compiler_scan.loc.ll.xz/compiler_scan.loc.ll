; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_29c361661bd12d1c_bc00961d9e0a1b58 = weak_odr constant [46 x i8] c"compiler/scan.olang:409: unreachable reached\0A\00"
@olang_loc_39af88013a73b478_a5c9d135875fcb24 = weak_odr constant [45 x i8] c"compiler/scan.olang:83: unreachable reached\0A\00"
@olang_loc_3aab5bd1ecbcb485_f7a3519a1de9c361 = weak_odr constant [45 x i8] c"compiler/scan.olang:60: unreachable reached\0A\00"
@olang_loc_5edef46376bb22ab_dbf9e31b0e24ed2f = weak_odr constant [52 x i8] c"compiler/scan.olang:171: array length out of range\0A\00"
@olang_loc_5fa49199d15530eb_36bb6c13fc6f006f = weak_odr constant [46 x i8] c"compiler/scan.olang:120: unreachable reached\0A\00"
@olang_loc_639a87f47d38eeab_7a46798b70a2d59f = weak_odr constant [46 x i8] c"compiler/scan.olang:286: unreachable reached\0A\00"
@olang_loc_987371ebee6d680a_1a9f2e533741df1e = weak_odr constant [46 x i8] c"compiler/scan.olang:129: unreachable reached\0A\00"
@olang_loc_bcb8545b4a157296_c09080caec3ed55a = weak_odr constant [52 x i8] c"compiler/scan.olang:170: array length out of range\0A\00"
@olang_loc_e0eb014d323e7d9_3ee0f0ba74559745 = weak_odr constant [52 x i8] c"compiler/scan.olang:835: slice bounds out of range\0A\00"
@olang_loc_ee9cb139bec139e6_8761f47a368b1bd2 = weak_odr constant [52 x i8] c"compiler/scan.olang:926: slice bounds out of range\0A\00"
