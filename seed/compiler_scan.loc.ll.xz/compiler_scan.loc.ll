; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_39af88013a73b478_a5c9d135875fcb24 = weak_odr constant [45 x i8] c"compiler/scan.olang:70: unreachable reached\0A\00"
@olang_loc_3aab5bd1ecbcb485_f7a3519a1de9c361 = weak_odr constant [45 x i8] c"compiler/scan.olang:50: unreachable reached\0A\00"
@olang_loc_8ff622b408ac7e7d_74a5d541f5b7fd49 = weak_odr constant [52 x i8] c"compiler/scan.olang:127: array length out of range\0A\00"
@olang_loc_d419e7c03b25d150_6d8c7625642ff0fc = weak_odr constant [52 x i8] c"compiler/scan.olang:126: array length out of range\0A\00"
@olang_loc_ee9cb139bec139e6_8761f47a368b1bd2 = weak_odr constant [52 x i8] c"compiler/scan.olang:629: slice bounds out of range\0A\00"
