; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_29c361661bd12d1c_bc00961d9e0a1b58 = weak_odr constant [46 x i8] c"compiler/scan.olang:372: unreachable reached\0A\00"
@olang_loc_39af88013a73b478_a5c9d135875fcb24 = weak_odr constant [45 x i8] c"compiler/scan.olang:80: unreachable reached\0A\00"
@olang_loc_3aab5bd1ecbcb485_f7a3519a1de9c361 = weak_odr constant [45 x i8] c"compiler/scan.olang:58: unreachable reached\0A\00"
@olang_loc_639a87f47d38eeab_7a46798b70a2d59f = weak_odr constant [46 x i8] c"compiler/scan.olang:271: unreachable reached\0A\00"
@olang_loc_8ff622b408ac7e7d_74a5d541f5b7fd49 = weak_odr constant [52 x i8] c"compiler/scan.olang:145: array length out of range\0A\00"
@olang_loc_d419e7c03b25d150_6d8c7625642ff0fc = weak_odr constant [52 x i8] c"compiler/scan.olang:144: array length out of range\0A\00"
@olang_loc_e0eb014d323e7d9_3ee0f0ba74559745 = weak_odr constant [52 x i8] c"compiler/scan.olang:740: slice bounds out of range\0A\00"
@olang_loc_ee9cb139bec139e6_8761f47a368b1bd2 = weak_odr constant [52 x i8] c"compiler/scan.olang:831: slice bounds out of range\0A\00"
