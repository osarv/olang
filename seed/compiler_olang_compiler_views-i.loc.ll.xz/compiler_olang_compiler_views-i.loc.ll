; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1c49285dffae43d4_e9b24c81495e44c0 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_214db67b0a81646e_deb96a6acabbb492 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:233: slice bounds out of range\0A\00"
@olang_loc_4f23ac148f9fc339_7d19292cfeb39665 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_7004ca72b26de486_2b99a3783348146a = weak_odr constant [54 x i8] c"std/prelude/vec.olang:233: slice bounds out of range\0A\00"
@olang_loc_7dd8ee16e33507e_16d497be4d0d3542 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:233: slice bounds out of range\0A\00"
@olang_loc_88886ff9bb7f1865_a9e5875df2ebf031 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_8ba2e54614619f7e_8bba8e21eb12a9ca = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_beecda37f40e3eda_431d079bb9d91d2e = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_bf3db0efe6223f53_b1d02810edb7e2f = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_bf8f2f6f787bf031_acfd09ccf5b00cd = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_dbf82a53e00efe8f_78a6f35151e85c7b = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
