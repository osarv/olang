; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1c49285dffae43d4_e9b24c81495e44c0 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_214db67b0a81646e_deb96a6acabbb492 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:231: slice bounds out of range\0A\00"
@olang_loc_2f5bb11b26a0009e_82876332934bc1e2 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_4ebb262c53b85fbb_7f831ff33c0e68f = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_6d99fd504a114ae5_e1e0f7dacee18aa9 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_7004ca72b26de486_2b99a3783348146a = weak_odr constant [54 x i8] c"std/prelude/vec.olang:231: slice bounds out of range\0A\00"
@olang_loc_7dd8ee16e33507e_16d497be4d0d3542 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:231: slice bounds out of range\0A\00"
@olang_loc_cc10b6e7b8dc6512_28dfdedf24007eae = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_dff6b8be09b6baf1_622ab6838d45c8e5 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_ed7864de8b76e86f_de4638c348c1e6c3 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_f78a9fec54718aa9_47b445c464e6082d = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
