; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_268877b82f8b9bc2_3ddf2b27bbff9896 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_4e4b8e2f79159516_80d81af6d746203a = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_61f557e66e731d60_5b4adbce41547004 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_9464eca05caf9266_71dfe42a8da0467a = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_9ae8d06863075d5e_87316c8ceed7b032 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_f15419eb22c8e4ec_5ffc19f61e6731b0 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_f8e3021aa35e7a6c_8ea5e9624caf8da0 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
