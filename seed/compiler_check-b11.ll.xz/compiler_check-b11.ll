; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32, i32 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/check:fieldSet" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:unsetCand" = type { i64, i64, i64, i1, i64, %"compiler/source:Span", i32, i1 }
%"compiler/generic:varRow" = type { i64, i32, i32, i32, i32 }
%"compiler/check:factsCopy" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:factsMark" = type { i64, i64, i64 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:ownerAt" = type { i32, i1 }
%"compiler/check:payloadItem" = type { i32, ptr }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:roArg" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.b139c4f75a6545712256427180a82a06" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" }
%"compiler/check:roDeepArg" = type { i64, ptr, i64, i64 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/generic:AnySlot"
  %l25 = alloca i32
  %l30 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca %"compiler/diagmsg:Msg"
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca i32
  %l77 = alloca i32
  %l81 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca i64
  %l108 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l125 = alloca i1
  %l126 = alloca { i64, ptr }
  %l128 = alloca i1
  %l129 = alloca ptr
  %l132 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l148 = alloca %"compiler/source:Span"
  %l149 = alloca { i64, ptr }
  %l151 = alloca i32
  %l154 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l175 = alloca i64
  %l178 = alloca i1
  %l181 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca %"compiler/source:Span"
  %l186 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l192 = alloca %"compiler/diagmsg:Msg"
  %l193 = alloca i64
  %l198 = alloca ptr
  %l201 = alloca ptr
  %l202 = alloca %"compiler/source:Span"
  %l203 = alloca %"compiler/source:Span"
  %l204 = alloca i64
  %l206 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l215 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l219 = alloca %"compiler/msgs:Nearest"
  %l228 = alloca { i64, ptr }
  %l231 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l239 = alloca %"compiler/source:Span"
  %l242 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l251 = alloca %"compiler/diagmsg:Msg"
  %l252 = alloca i64
  %l257 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  %t306 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1)
  store i32 %t4, ptr %l25
  br label %bb1
bb1:
  %t5 = load i32, ptr %l25, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l7, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l30
  br label %bb2
bb2:
  %t16 = load i1, ptr %l30, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l31, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t18)
  store %"compiler/source:Span" %t20, ptr %l33
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l34, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t22)
  store %"compiler/source:Span" %t24, ptr %l36
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l34, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l36
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t25, %"compiler/source:Span" %t26)
  store { i64, ptr } %t27, ptr %l37
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l7, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l40
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t33, ptr %l41, !tbaa !27
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l42, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t35)
  store %"compiler/source:Span" %t37, ptr %l44
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l42, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l44
  %t40 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t38, %"compiler/source:Span" %t39)
  store { i64, ptr } %t40, ptr %l45
  br label %bb10
bb10:
  %t41 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t42 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s1, { i64, ptr } %t41)
  store { i64, ptr } %t42, ptr %l46
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  store i64 %t44, ptr %l47, !tbaa !24
  %t45 = load i64, ptr %l47, !tbaa !24
  %t46 = mul i64 %t45, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l47, !tbaa !24
  %t55 = mul i64 %t54, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %t53, i64 %t55, i1 false)
  %t56 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  %t58 = extractvalue { i64, ptr } %t56, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l49, !tbaa !27
  %t63 = call ptr @__olang_scope_hold(ptr %v0)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l50, !tbaa !24
  %t65 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t65, label %bb12, label %bb13
bb12:
  %t67 = call ptr @__olang_region_make(ptr %v0)
  %t68 = ptrtoint ptr %t67 to i64
  store i64 %t68, ptr %l50, !tbaa !24
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l52, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l53, !tbaa !29
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t71)
  store %"compiler/source:Span" %t73, ptr %l55
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l53, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l55
  %t76 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t74, %"compiler/source:Span" %t75)
  store { i64, ptr } %t76, ptr %l56
  br label %bb15
bb15:
  %t77 = load i64, ptr %l50
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = load i64, ptr %l50
  %t80 = inttoptr i64 %t79 to ptr
  %t81 = load ptr, ptr %l52, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eendedWhy(ptr %v0, ptr %t78, ptr %t80, ptr %t81, { i64, ptr } %t82)
  store { i64, ptr } %t83, ptr %l57
  br label %bb16
bb16:
  %t84 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t85 = load i64, ptr %l50
  %t86 = inttoptr i64 %t85 to ptr
  %t87 = extractvalue { i64, ptr } %t84, 0
  %t88 = extractvalue { i64, ptr } %t84, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_held_alloc(ptr %t86, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t97 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s1, ptr %s1, ptr %v0, ptr %v0, { i64, ptr } %t93, { i64, ptr } %t94, { i64, ptr } %t95, { i64, ptr } %t92)
  store %"compiler/diagmsg:Msg" %t97, ptr %l59
  br label %bb17
bb17:
  %t98 = load ptr, ptr %l31, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l33
  %t100 = load %"compiler/diagmsg:Msg", ptr %l59
  %t101 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t98, %"compiler/source:Span" %t99, %"compiler/diagmsg:Msg" %t100)
  store i64 %t101, ptr %l60
  br label %bb18
bb18:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l61, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t103, ptr %l62
  %t104 = load ptr, ptr %l3, !tbaa !29
  store ptr %t104, ptr %l63, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l7, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l68
  br label %bb19
bb19:
  %t115 = load ptr, ptr %l61, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l62
  %t117 = load ptr, ptr %l63, !tbaa !29
  %t118 = load i32, ptr %l68, !tbaa !23
  %t119 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v0, ptr %t115, %"compiler/source:Span" %t116, ptr %t117, i32 %t118)
  store ptr %t119, ptr %l69
  br label %bb20
bb20:
  %t120 = load ptr, ptr %l69, !tbaa !29
  store ptr %t120, ptr %l3, !tbaa !29
  %t121 = load ptr, ptr %l3, !tbaa !29
  %t124 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t121)
  store i32 %t124, ptr %l72
  br label %bb21
bb21:
  %t125 = load i32, ptr %l72, !tbaa !23
  store i32 %t125, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb22
bb22:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l7, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l77
  br label %bb23
bb23:
  %t136 = load i32, ptr %l77, !tbaa !23
  store i32 %t136, ptr %l8, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t141 = load i32, ptr %l8, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l81
  br label %bb24
bb24:
  %t145 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t145, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  store i64 %t148, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l11, !tbaa !24
  %t151 = load i64, ptr %l10, !tbaa !24
  %t154 = icmp sgt i64 %t150, %t151
  br i1 %t154, label %bb25, label %bb26
bb25:
  %t156 = load i64, ptr %l12, !tbaa !24
  %t158 = icmp sgt i64 %t156, 0
  br i1 %t158, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb30
bb27:
  %t160 = load i64, ptr %l11, !tbaa !24
  %t161 = load i64, ptr %l10, !tbaa !24
  %t164 = sub i64 %t160, %t161
  %t165 = load i64, ptr %l12, !tbaa !24
  %t168 = add i64 %t164, %t165
  %t170 = sub i64 %t168, 1
  %t171 = load i64, ptr %l12, !tbaa !24
  %t174 = sdiv i64 %t170, %t171
  store i64 %t174, ptr %l90, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb29
bb29:
  %t176 = load i64, ptr %l90, !tbaa !24
  store i64 %t176, ptr %l87, !tbaa !24
  br label %bb30
bb30:
  %t177 = load i64, ptr %l87, !tbaa !24
  store i64 %t177, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  %t178 = load i64, ptr %l14, !tbaa !24
  %t179 = load i64, ptr %l13, !tbaa !24
  %t182 = icmp slt i64 %t178, %t179
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb32, label %bb33
bb32:
  br label %bb60
bb33:
  br label %bb34
bb34:
  %t186 = load i64, ptr %l10, !tbaa !24
  %t187 = load i64, ptr %l14, !tbaa !24
  %t188 = load i64, ptr %l12, !tbaa !24
  %t191 = mul i64 %t187, %t188
  %t194 = add i64 %t186, %t191
  store i64 %t194, ptr %l15, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t196, ptr %l108, !tbaa !27
  %t197 = load i64, ptr %l15, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr %"compiler/generic:AnySlot", ptr %t200, i64 %t197
  %t202 = getelementptr %"compiler/generic:AnySlot", ptr %t201, i32 0, i32 0
  %t203 = load i32, ptr %t202, !tbaa !23
  %t204 = load i32, ptr %l4, !tbaa !23
  %t207 = icmp ne i32 %t203, %t204
  br i1 %t207, label %bb35, label %bb36
bb35:
  br label %bb59
bb36:
  br label %bb37
bb37:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l8, !tbaa !23
  %t211 = load i64, ptr %l15, !tbaa !24
  %t212 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %t209, i32 %t210, i64 %t211, %"compiler/source:Span" %t212)
  br label %bb38
bb38:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t218, ptr %l118, !tbaa !27
  %t219 = load i64, ptr %l15, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr %"compiler/generic:AnySlot", ptr %t222, i64 %t219
  %t224 = load %"compiler/generic:AnySlot", ptr %t223
  %t227 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v0, ptr %t217, %"compiler/generic:AnySlot" %t224)
  store ptr %t227, ptr %l121
  br label %bb39
bb39:
  %t228 = load ptr, ptr %l121, !tbaa !29
  store ptr %t228, ptr %l16, !tbaa !29
  %t229 = load ptr, ptr %l16, !tbaa !29
  %t231 = icmp eq ptr %t229, null
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb40, label %bb41
bb40:
  %t235 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t235, ptr %l126, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 1
  %t238 = call ptr @__olang_scope_of(ptr %t237, ptr null)
  %t239 = call ptr @__olang_scope_hold(ptr %t238)
  %t240 = ptrtoint ptr %t239 to i64
  %t242 = inttoptr i64 %t240 to ptr
  %t243 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t244 = call i1 @compiler_2fcheck_2ehasNamed(ptr %t242, { i64, ptr } %t243)
  store i1 %t244, ptr %l128
  br label %bb42
bb41:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb43
bb42:
  %t245 = load i1, ptr %l128, !tbaa !21
  store i1 %t245, ptr %l125, !tbaa !21
  br label %bb43
bb43:
  %t246 = load i1, ptr %l125, !tbaa !21
  br i1 %t246, label %bb44, label %bb45
bb44:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l129, !tbaa !29
  %t248 = load ptr, ptr %l16, !tbaa !29
  %t250 = getelementptr %"compiler/ast:Func", ptr %t248, i32 0, i32 3
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t253 = getelementptr %"compiler/ast:Sig", ptr %t251, i32 0, i32 0
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  store { i64, ptr } %t254, ptr %l132, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t255, ptr %l133, !tbaa !27
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i32, ptr %l4, !tbaa !23
  %t260 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t256, i32 %t257)
  store { i64, ptr } %t260, ptr %l136
  br label %bb46
bb45:
  br label %bb53
bb46:
  %t261 = load ptr, ptr %l129, !tbaa !29
  %t262 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t263 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t264 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t265 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v0, ptr %v3, ptr %v0, ptr %v0, ptr %t261, { i64, ptr } %t262, { i64, ptr } %t263, { i64, ptr } %t264)
  store { i64, ptr } %t265, ptr %l137
  br label %bb47
bb47:
  %t266 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t266, ptr %l6, !tbaa !27
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 177
  %t270 = load i1, ptr %t269, !tbaa !21
  br i1 %t270, label %bb48, label %bb49
bb48:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t272, i32 0, i32 177
  store i1 false, ptr %t274, !tbaa !21
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v0, ptr %t275, { i64, ptr } %t276)
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  %t283 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t279, %"compiler/source:Span" %t280)
  store ptr %t283, ptr %l145
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t284 = load ptr, ptr %l145, !tbaa !29
  store ptr %t284, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l146, !tbaa !29
  %t286 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t286, ptr %l147
  %t287 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t287, ptr %l148
  %t288 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t288, ptr %l149, !tbaa !27
  %t289 = load i64, ptr %l15, !tbaa !24
  %t291 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr %"compiler/generic:AnySlot", ptr %t292, i64 %t289
  %t294 = getelementptr %"compiler/generic:AnySlot", ptr %t293, i32 0, i32 5
  %t295 = load i32, ptr %t294, !tbaa !23
  store i32 %t295, ptr %l151, !tbaa !23
  %t296 = load i32, ptr %l8, !tbaa !23
  %t297 = load i64, ptr %l15, !tbaa !24
  %t298 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t298, ptr %l154, !tbaa !27
  %t299 = load i64, ptr %l15, !tbaa !24
  %t301 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr %"compiler/generic:AnySlot", ptr %t302, i64 %t299
  %t304 = getelementptr %"compiler/generic:AnySlot", ptr %t303, i32 0, i32 5
  %t305 = load i32, ptr %t304, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t306
  %t307 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 0
  store i64 3, ptr %t307
  %t309 = insertvalue { i32, i64, i32 } undef, i32 %t296, 0
  %t311 = insertvalue { i32, i64, i32 } %t309, i64 %t297, 1
  %t313 = insertvalue { i32, i64, i32 } %t311, i32 %t305, 2
  %t314 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 1
  store { i32, i64, i32 } %t313, ptr %t314
  %t315 = load { i64, [3 x i64] }, ptr %t306
  %t317 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store { i64, [3 x i64] } %t315, ptr %t317
  store ptr %t317, ptr %l158, !tbaa !29
  %t318 = load ptr, ptr %l3, !tbaa !29
  store ptr %t318, ptr %l160, !tbaa !29
  %t320 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t320, ptr %l161, !tbaa !27
  %t321 = icmp sge i64 0, 0
  br i1 %t321, label %bb54, label %bb55
bb54:
  %t323 = icmp sle i64 0, 1152921504606846975
  br i1 %t323, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_e1138a3bee8dfd28_1d9c93b07a3bbf3c)
  unreachable
bb56:
  %t325 = mul i64 0, 8
  %t326 = insertvalue { i64, ptr } undef, i64 0, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t328 = load ptr, ptr %l160, !tbaa !29
  %t329 = call ptr @__olang_scope_of(ptr %t328, ptr null)
  %t330 = call ptr @__olang_scope_hold(ptr %t329)
  %t331 = ptrtoint ptr %t330 to i64
  %t332 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 1
  %t334 = call ptr @__olang_scope_of(ptr %t333, ptr null)
  %t335 = call ptr @__olang_scope_hold(ptr %t334)
  %t336 = ptrtoint ptr %t335 to i64
  %t338 = inttoptr i64 %t331 to ptr
  %t340 = inttoptr i64 %t336 to ptr
  %t341 = load ptr, ptr %l146, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l147
  %t343 = load %"compiler/source:Span", ptr %l148
  %t344 = load i32, ptr %l151, !tbaa !23
  %t345 = load ptr, ptr %l158, !tbaa !29
  %t346 = load ptr, ptr %l160, !tbaa !29
  %t347 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t349 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v4, ptr %t338, ptr %t340, ptr %v0, ptr %v4, ptr %t341, %"compiler/source:Span" %t342, %"compiler/source:Span" %t343, i32 %t344, ptr %t345, i64 -1, ptr %t346, { i64, ptr } %t347, { i64, ptr } %t327)
  store ptr %t349, ptr %l167
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_e1138a3bee8dfd28_1d9c93b07a3bbf3c)
  unreachable
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t350 = load ptr, ptr %l167, !tbaa !29
  store ptr %t350, ptr %rv
  br label %ret
bb59:
  %t351 = load i64, ptr %l14, !tbaa !24
  %t354 = add i64 %t351, 1
  store i64 %t354, ptr %l14, !tbaa !24
  br label %bb31
bb60:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/check:Checker", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t360 = load i32, ptr %l8, !tbaa !23
  %t361 = load i32, ptr %l4, !tbaa !23
  %t365 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyDefault(ptr %v0, ptr %t359, i32 %t360, i32 %t361)
  store i64 %t365, ptr %l175
  br label %bb61
bb61:
  %t366 = load i64, ptr %l175, !tbaa !24
  store i64 %t366, ptr %l17, !tbaa !24
  %t367 = load i64, ptr %l17, !tbaa !24
  %t369 = icmp sge i64 %t367, 0
  br i1 %t369, label %bb62, label %bb63
bb62:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i64, ptr %l17, !tbaa !24
  %t375 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultCopiesRecv(ptr %v0, ptr %t371, i64 %t372)
  store i1 %t375, ptr %l181
  br label %bb64
bb63:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb65
bb64:
  %t376 = load i1, ptr %l181, !tbaa !21
  store i1 %t376, ptr %l178, !tbaa !21
  br label %bb65
bb65:
  %t377 = load i1, ptr %l178, !tbaa !21
  br i1 %t377, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s8
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l182, !tbaa !29
  %t379 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t379, ptr %l183
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load i32, ptr %l4, !tbaa !23
  %t384 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t380, i32 %t381)
  store { i64, ptr } %t384, ptr %l186
  br label %bb68
bb67:
  br label %bb74
bb68:
  %t385 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t385, ptr %l187, !tbaa !27
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load i32, ptr %l7, !tbaa !23
  %t390 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t386, i32 %t387)
  store { i64, ptr } %t390, ptr %l190
  br label %bb69
bb69:
  %t391 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t392 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t394 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNoCopy(ptr %s8, ptr %s8, ptr %v0, { i64, ptr } %t392, { i64, ptr } %t391)
  store %"compiler/diagmsg:Msg" %t394, ptr %l192
  br label %bb70
bb70:
  %t395 = load ptr, ptr %l182, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l183
  %t397 = load %"compiler/diagmsg:Msg", ptr %l192
  %t398 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t395, %"compiler/source:Span" %t396, %"compiler/diagmsg:Msg" %t397)
  store i64 %t398, ptr %l193
  br label %bb71
bb71:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t399, { i64, ptr } %t400)
  br label %bb72
bb72:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t404 = load %"compiler/source:Span", ptr %l1
  %t407 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t403, %"compiler/source:Span" %t404)
  store ptr %t407, ptr %l198
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t408 = load ptr, ptr %l198, !tbaa !29
  store ptr %t408, ptr %rv
  br label %ret
bb74:
  %t409 = load i64, ptr %l17, !tbaa !24
  %t411 = icmp sge i64 %t409, 0
  br i1 %t411, label %bb75, label %bb76
bb75:
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l201, !tbaa !29
  %t414 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t414, ptr %l202
  %t415 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t415, ptr %l203
  %t416 = load i64, ptr %l17, !tbaa !24
  store i64 %t416, ptr %l204, !tbaa !24
  %t417 = load ptr, ptr %l3, !tbaa !29
  store ptr %t417, ptr %l206, !tbaa !29
  %t419 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t419, ptr %l207, !tbaa !27
  %t420 = icmp sge i64 0, 0
  br i1 %t420, label %bb77, label %bb78
bb76:
  br label %bb86
bb77:
  %t422 = icmp sle i64 0, 1152921504606846975
  br i1 %t422, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_ecdebd42147a0915_28ece6113815da89)
  unreachable
bb79:
  %t424 = mul i64 0, 8
  %t425 = insertvalue { i64, ptr } undef, i64 0, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t426, ptr %l210, !tbaa !27
  %t427 = icmp sge i64 0, 0
  br i1 %t427, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @olang_loc_ecdebd42147a0915_28ece6113815da89)
  unreachable
bb81:
  %t429 = icmp sle i64 0, 2305843009213693951
  br i1 %t429, label %bb83, label %bb84
bb82:
  call void @__olang_check_failed(ptr @olang_loc_b35cdd4155941ff6_f61ebbb89c67ebca)
  unreachable
bb83:
  %t431 = mul i64 0, 4
  %t432 = insertvalue { i64, ptr } undef, i64 0, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t434 = load ptr, ptr %l206, !tbaa !29
  %t435 = call ptr @__olang_scope_of(ptr %t434, ptr null)
  %t436 = call ptr @__olang_scope_hold(ptr %t435)
  %t437 = ptrtoint ptr %t436 to i64
  %t439 = inttoptr i64 %t437 to ptr
  %t440 = load ptr, ptr %l201, !tbaa !29
  %t441 = load %"compiler/source:Span", ptr %l202
  %t442 = load %"compiler/source:Span", ptr %l203
  %t443 = load i64, ptr %l204, !tbaa !24
  %t444 = load ptr, ptr %l206, !tbaa !29
  %t445 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t446 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t448 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %t439, ptr %v3, ptr %v0, ptr %v4, ptr %v4, ptr %t440, %"compiler/source:Span" %t441, %"compiler/source:Span" %t442, i64 %t443, ptr %t444, { i64, ptr } %t445, { i64, ptr } %t446, { i64, ptr } %t433)
  store ptr %t448, ptr %l215
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_b35cdd4155941ff6_f61ebbb89c67ebca)
  unreachable
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t449 = load ptr, ptr %l215, !tbaa !29
  store ptr %t449, ptr %rv
  br label %ret
bb86:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load i32, ptr %l4, !tbaa !23
  %t454 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t450, i32 %t451)
  store { i64, ptr } %t454, ptr %l218
  br label %bb87
bb87:
  %t455 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t456 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t455)
  store %"compiler/msgs:Nearest" %t456, ptr %l219
  br label %bb88
bb88:
  %t457 = load %"compiler/msgs:Nearest", ptr %l219
  %t458 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t457, ptr %t458
  store ptr %t458, ptr %l18, !tbaa !29
  %t460 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t460, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t462 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t462, 0
  store i64 %t464, ptr %l21, !tbaa !24
  br label %bb89
bb89:
  %t466 = load i64, ptr %l20, !tbaa !24
  %t467 = load i64, ptr %l21, !tbaa !24
  %t470 = icmp slt i64 %t466, %t467
  %t472 = xor i1 %t470, true
  br i1 %t472, label %bb90, label %bb91
bb90:
  br label %bb96
bb91:
  br label %bb92
bb92:
  %t474 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t474, ptr %l228, !tbaa !27
  %t475 = load i64, ptr %l20, !tbaa !24
  %t477 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !27
  %t479 = getelementptr %"compiler/generic:AnySlot", ptr %t478, i64 %t475
  %t480 = load %"compiler/generic:AnySlot", ptr %t479
  store %"compiler/generic:AnySlot" %t480, ptr %l22
  %t482 = load ptr, ptr %l18, !tbaa !29
  store ptr %t482, ptr %l231, !tbaa !29
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/generic:AnySlot", ptr %l22, i32 0, i32 0
  %t485 = load i32, ptr %t484, !tbaa !23
  %t488 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t483, i32 %t485)
  store { i64, ptr } %t488, ptr %l234
  br label %bb93
bb93:
  %t489 = load ptr, ptr %l231, !tbaa !29
  %t490 = load { i64, ptr }, ptr %l234, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t489, { i64, ptr } %t490)
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t491 = load i64, ptr %l20, !tbaa !24
  %t494 = add i64 %t491, 1
  store i64 %t494, ptr %l20, !tbaa !24
  br label %bb89
bb96:
  %t496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t496, ptr %l238, !tbaa !29
  %t497 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t497, ptr %l239
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t499 = load i32, ptr %l7, !tbaa !23
  %t502 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t498, i32 %t499)
  store { i64, ptr } %t502, ptr %l242
  br label %bb97
bb97:
  %t503 = load { i64, ptr }, ptr %l242, !tbaa !27
  store { i64, ptr } %t503, ptr %l243, !tbaa !27
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = load i32, ptr %l4, !tbaa !23
  %t508 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t504, i32 %t505)
  store { i64, ptr } %t508, ptr %l246
  br label %bb98
bb98:
  %t509 = load { i64, ptr }, ptr %l246, !tbaa !27
  store { i64, ptr } %t509, ptr %l247, !tbaa !27
  %t510 = load ptr, ptr %l18, !tbaa !29
  %t512 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s0, ptr %s0, ptr %t510)
  store { i64, ptr } %t512, ptr %l249
  br label %bb99
bb99:
  %t513 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t514 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t515 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t517 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNoMethod(ptr %s0, ptr %s0, ptr %s0, ptr %v0, { i64, ptr } %t514, { i64, ptr } %t515, { i64, ptr } %t513)
  store %"compiler/diagmsg:Msg" %t517, ptr %l251
  br label %bb100
bb100:
  %t518 = load ptr, ptr %l238, !tbaa !29
  %t519 = load %"compiler/source:Span", ptr %l239
  %t520 = load %"compiler/diagmsg:Msg", ptr %l251
  %t521 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t518, %"compiler/source:Span" %t519, %"compiler/diagmsg:Msg" %t520)
  store i64 %t521, ptr %l252
  br label %bb101
bb101:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t522, { i64, ptr } %t523)
  br label %bb102
bb102:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load %"compiler/source:Span", ptr %l1
  %t530 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t526, %"compiler/source:Span" %t527)
  store ptr %t530, ptr %l257
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s0)
  %t531 = load ptr, ptr %l257, !tbaa !29
  store ptr %t531, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyTable(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"compiler/generic:AnySlot"
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/generic:AnySlot"
  %l30 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l49 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i32
  %l71 = alloca i64
  %l74 = alloca i64
  %l92 = alloca { i64, ptr }
  %l99 = alloca i64
  %l107 = alloca i32
  %l109 = alloca ptr
  %l111 = alloca i64
  %l112 = alloca i64
  %l117 = alloca i32
  %l124 = alloca i32
  %l128 = alloca i1
  %l132 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l148 = alloca %"compiler/diagmsg:Msg"
  %l149 = alloca i64
  %l152 = alloca ptr
  %l153 = alloca i64
  %l154 = alloca i64
  %l157 = alloca { i64, ptr }
  %l159 = alloca %"compiler/diagmsg:Msg"
  %l171 = alloca ptr
  %l173 = alloca ptr
  %l181 = alloca i64
  %l184 = alloca i64
  %l202 = alloca { i64, ptr }
  %l207 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l219 = alloca i64
  %l222 = alloca ptr
  %l223 = alloca i32
  %l229 = alloca i32
  %l230 = alloca i32
  %l232 = alloca ptr
  %l240 = alloca i64
  %l244 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i64
  %t423 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  %t10 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableOf(ptr %v0, ptr %t4, i32 %t5, i32 %t6)
  store i64 %t10, ptr %l35
  br label %bb1
bb1:
  %t11 = load i64, ptr %l35, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 169
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l41
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t23 = load i1, ptr %l41, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i64 -1, ptr %l42, !tbaa !24
  br label %bb7
bb6:
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l42, !tbaa !24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i64, ptr %l42, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l45, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  store i32 %t31, ptr %l46, !tbaa !23
  %t32 = load i32, ptr %l2, !tbaa !23
  store i32 %t32, ptr %l47, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t33)
  store ptr %t35, ptr %l49
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l49, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 2
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = load %"compiler/source:Span", ptr %l3
  %t41 = load ptr, ptr %l45, !tbaa !29
  %t42 = load i32, ptr %l46, !tbaa !23
  %t43 = load i32, ptr %l47, !tbaa !23
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eNewAnyTable(ptr %v0, ptr %t41, i32 %t42, i32 %t43, i64 %t39, %"compiler/source:Span" %t40)
  store i64 %t46, ptr %l53
  br label %bb10
bb10:
  %t47 = load i64, ptr %l53, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t51, i32 %t52)
  store { i64, ptr } %t55, ptr %l57
  br label %bb11
bb11:
  %t56 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l59, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %l1, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l64
  br label %bb12
bb12:
  %t71 = load ptr, ptr %l59, !tbaa !29
  %t72 = load i32, ptr %l64, !tbaa !23
  %t73 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t73, ptr %l65
  br label %bb13
bb13:
  %t74 = load i32, ptr %l65, !tbaa !23
  store i32 %t74, ptr %l7, !tbaa !23
  store i64 0, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = icmp sgt i64 %t79, %t80
  br i1 %t83, label %bb14, label %bb15
bb14:
  %t85 = load i64, ptr %l10, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb19
bb16:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = sub i64 %t89, %t90
  %t94 = load i64, ptr %l10, !tbaa !24
  %t97 = add i64 %t93, %t94
  %t99 = sub i64 %t97, 1
  %t100 = load i64, ptr %l10, !tbaa !24
  %t103 = sdiv i64 %t99, %t100
  store i64 %t103, ptr %l74, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb18
bb18:
  %t105 = load i64, ptr %l74, !tbaa !24
  store i64 %t105, ptr %l71, !tbaa !24
  br label %bb19
bb19:
  %t106 = load i64, ptr %l71, !tbaa !24
  store i64 %t106, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb20
bb20:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb21, label %bb22
bb21:
  br label %bb59
bb22:
  br label %bb23
bb23:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l10, !tbaa !24
  %t120 = mul i64 %t116, %t117
  %t123 = add i64 %t115, %t120
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t125, ptr %l92, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/generic:AnySlot", ptr %t129, i64 %t123
  %t131 = load %"compiler/generic:AnySlot", ptr %t130
  store %"compiler/generic:AnySlot" %t131, ptr %l14
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load i32, ptr %l1, !tbaa !23
  %t138 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t139 = load i32, ptr %t138, !tbaa !23
  %t143 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t136, i32 %t137, i32 %t139)
  store i64 %t143, ptr %l99
  br label %bb24
bb24:
  %t144 = load i64, ptr %l99, !tbaa !24
  store i64 %t144, ptr %l15, !tbaa !24
  %t145 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t145, ptr %l16, !tbaa !23
  %t147 = load i64, ptr %l15, !tbaa !24
  %t149 = icmp sge i64 %t147, 0
  br i1 %t149, label %bb25, label %bb26
bb25:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i32, ptr %l1, !tbaa !23
  %t160 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t154, i64 %t155, i32 %t156)
  store i32 %t160, ptr %l107
  br label %bb27
bb26:
  %t161 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 3
  %t162 = load i64, ptr %t161, !tbaa !24
  %t164 = icmp sge i64 %t162, 0
  br i1 %t164, label %bb34, label %bb35
bb27:
  %t166 = load i32, ptr %l107, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  store ptr %t170, ptr %l109, !tbaa !29
  %t171 = load i64, ptr %l15, !tbaa !24
  %t173 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t171)
  store i64 %t173, ptr %l111
  br label %bb28
bb28:
  %t174 = load ptr, ptr %l109, !tbaa !29
  %t175 = load i64, ptr %l111, !tbaa !24
  %t176 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t174, i64 %t175)
  store i64 %t176, ptr %l112
  br label %bb29
bb29:
  %t177 = load i64, ptr %l112, !tbaa !24
  %t178 = icmp sgt i64 %t177, 0
  br i1 %t178, label %bb30, label %bb31
bb30:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l15, !tbaa !24
  %t182 = load i32, ptr %l1, !tbaa !23
  %t186 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %t180, i64 %t181, i32 %t182)
  store i32 %t186, ptr %l117
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t187 = load i32, ptr %l117, !tbaa !23
  store i32 %t187, ptr %l16, !tbaa !23
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 3
  %t193 = load i64, ptr %t192, !tbaa !24
  %t194 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %t191, i64 %t193, i32 %t194)
  store i32 %t198, ptr %l124
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t199 = load i32, ptr %l124, !tbaa !23
  store i32 %t199, ptr %l16, !tbaa !23
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t200 = load i32, ptr %l16, !tbaa !23
  %t201 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t204 = icmp ne i32 %t200, %t201
  br i1 %t204, label %bb39, label %bb40
bb39:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i32, ptr %l16, !tbaa !23
  %t208 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 5
  %t209 = load i32, ptr %t208, !tbaa !23
  %t213 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %t206, i32 %t207, i32 %t209)
  store i1 %t213, ptr %l132
  br label %bb41
bb40:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb42
bb41:
  %t214 = load i1, ptr %l132, !tbaa !21
  %t215 = xor i1 %t214, true
  store i1 %t215, ptr %l128, !tbaa !21
  br label %bb42
bb42:
  %t217 = load i1, ptr %l128, !tbaa !21
  br i1 %t217, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l134, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t219, ptr %l135
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l1, !tbaa !23
  %t224 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t220, i32 %t221)
  store { i64, ptr } %t224, ptr %l138
  br label %bb45
bb44:
  br label %bb57
bb45:
  %t225 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t225, ptr %l139, !tbaa !27
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t228 = load i32, ptr %t227, !tbaa !23
  %t231 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t226, i32 %t228)
  store { i64, ptr } %t231, ptr %l142
  br label %bb46
bb46:
  %t232 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t232, ptr %l143, !tbaa !27
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l2, !tbaa !23
  %t237 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t233, i32 %t234)
  store { i64, ptr } %t237, ptr %l146
  br label %bb47
bb47:
  %t238 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t242 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %s8, ptr %s8, ptr %s8, ptr %v0, { i64, ptr } %t239, { i64, ptr } %t240, { i64, ptr } %t238)
  store %"compiler/diagmsg:Msg" %t242, ptr %l148
  br label %bb48
bb48:
  %t243 = load ptr, ptr %l134, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l135
  %t245 = load %"compiler/diagmsg:Msg", ptr %l148
  %t246 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t243, %"compiler/source:Span" %t244, %"compiler/diagmsg:Msg" %t245)
  store i64 %t246, ptr %l149
  br label %bb49
bb49:
  %t247 = load i64, ptr %l149, !tbaa !24
  store i64 %t247, ptr %l17, !tbaa !24
  %t248 = load i64, ptr %l15, !tbaa !24
  %t250 = icmp sge i64 %t248, 0
  br i1 %t250, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l152, !tbaa !29
  %t253 = load i64, ptr %l17, !tbaa !24
  store i64 %t253, ptr %l153, !tbaa !24
  %t254 = load i64, ptr %l15, !tbaa !24
  store i64 %t254, ptr %l154, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t257 = load i32, ptr %t256, !tbaa !23
  %t260 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t255, i32 %t257)
  store { i64, ptr } %t260, ptr %l157
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t261 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t263 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteAnyMethod(ptr %s9, ptr %v0, { i64, ptr } %t261)
  store %"compiler/diagmsg:Msg" %t263, ptr %l159
  br label %bb53
bb53:
  %t264 = load ptr, ptr %l152, !tbaa !29
  %t265 = load i64, ptr %l153, !tbaa !24
  %t266 = load i64, ptr %l154, !tbaa !24
  %t267 = load %"compiler/diagmsg:Msg", ptr %l159
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v0, ptr %t264, i64 %t265, i64 %t266, %"compiler/diagmsg:Msg" %t267)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 169
  %t271 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t270, i64 %t271, i1 true)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t275 = load i64, ptr %l12, !tbaa !24
  %t278 = add i64 %t275, 1
  store i64 %t278, ptr %l12, !tbaa !24
  br label %bb20
bb59:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t285 = getelementptr %"compiler/generic:Program", ptr %t283, i32 0, i32 70
  %t286 = load i64, ptr %l5, !tbaa !24
  %t289 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H0986089bcad3c266fbd2f46fa03b07d1(ptr %v0, ptr %v0, ptr %t285, i64 %t286)
  store ptr %t289, ptr %l171
  br label %bb60
bb60:
  %t290 = load ptr, ptr %l171, !tbaa !29
  store ptr %t290, ptr %l18, !tbaa !29
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t291)
  store ptr %t293, ptr %l173
  br label %bb61
bb61:
  %t294 = load ptr, ptr %l173, !tbaa !29
  %t296 = getelementptr %"compiler/check:frame", ptr %t294, i32 0, i32 1
  %t297 = load i64, ptr %t296, !tbaa !24
  store i64 %t297, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t299 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t299, 0
  store i64 %t301, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t303 = load i64, ptr %l21, !tbaa !24
  %t304 = load i64, ptr %l20, !tbaa !24
  %t307 = icmp sgt i64 %t303, %t304
  br i1 %t307, label %bb62, label %bb63
bb62:
  %t309 = load i64, ptr %l22, !tbaa !24
  %t311 = icmp sgt i64 %t309, 0
  br i1 %t311, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l181, !tbaa !24
  br label %bb67
bb64:
  %t313 = load i64, ptr %l21, !tbaa !24
  %t314 = load i64, ptr %l20, !tbaa !24
  %t317 = sub i64 %t313, %t314
  %t318 = load i64, ptr %l22, !tbaa !24
  %t321 = add i64 %t317, %t318
  %t323 = sub i64 %t321, 1
  %t324 = load i64, ptr %l22, !tbaa !24
  %t327 = sdiv i64 %t323, %t324
  store i64 %t327, ptr %l184, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l184, !tbaa !24
  br label %bb66
bb66:
  %t329 = load i64, ptr %l184, !tbaa !24
  store i64 %t329, ptr %l181, !tbaa !24
  br label %bb67
bb67:
  %t330 = load i64, ptr %l181, !tbaa !24
  store i64 %t330, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb68
bb68:
  %t331 = load i64, ptr %l24, !tbaa !24
  %t332 = load i64, ptr %l23, !tbaa !24
  %t335 = icmp slt i64 %t331, %t332
  %t337 = xor i1 %t335, true
  br i1 %t337, label %bb69, label %bb70
bb69:
  br label %bb80
bb70:
  br label %bb71
bb71:
  %t339 = load i64, ptr %l20, !tbaa !24
  %t340 = load i64, ptr %l24, !tbaa !24
  %t341 = load i64, ptr %l22, !tbaa !24
  %t344 = mul i64 %t340, %t341
  %t347 = add i64 %t339, %t344
  store i64 %t347, ptr %l25, !tbaa !24
  %t349 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t349, ptr %l202, !tbaa !27
  %t350 = load i64, ptr %l25, !tbaa !24
  %t352 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = getelementptr %"compiler/generic:AnySlot", ptr %t353, i64 %t350
  %t355 = load %"compiler/generic:AnySlot", ptr %t354
  store %"compiler/generic:AnySlot" %t355, ptr %l26
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/check:Checker", ptr %t357, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = getelementptr %"compiler/generic:Program", ptr %t360, i32 0, i32 2
  store ptr %t362, ptr %l207, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t368 = getelementptr %"compiler/generic:Program", ptr %t366, i32 0, i32 2
  %t369 = getelementptr %"compiler/generic:AnySlot", ptr %l26, i32 0, i32 5
  %t370 = load i32, ptr %t369, !tbaa !23
  %t373 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t368, i32 %t370)
  store i32 %t373, ptr %l212
  br label %bb72
bb72:
  %t374 = load ptr, ptr %l207, !tbaa !29
  %t375 = load i32, ptr %l212, !tbaa !23
  %t376 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t374, i32 %t375)
  store { i64, ptr } %t376, ptr %l213
  br label %bb73
bb73:
  %t377 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/check:Checker", ptr %t378, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = getelementptr %"compiler/generic:Program", ptr %t381, i32 0, i32 2
  store { i64, ptr } %t377, ptr %l217, !tbaa !27
  %t385 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr i32, ptr %t386, i64 0
  %t388 = load i32, ptr %t387, !tbaa !33
  %t391 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t383, i32 %t388)
  store i64 %t391, ptr %l219
  br label %bb74
bb74:
  %t392 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t393 = load i64, ptr %l219, !tbaa !24
  %t395 = and i64 %t393, %t392
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l222, !tbaa !29
  %t398 = getelementptr %"compiler/generic:AnySlot", ptr %l26, i32 0, i32 5
  %t399 = load i32, ptr %t398, !tbaa !23
  store i32 %t399, ptr %l223, !tbaa !23
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = getelementptr %"compiler/generic:Program", ptr %t403, i32 0, i32 2
  %t406 = load i32, ptr %l7, !tbaa !23
  %t411 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t405, i32 %t406, i64 %t395)
  store i32 %t411, ptr %l229
  br label %bb75
bb75:
  %t412 = load ptr, ptr %l222, !tbaa !29
  %t413 = load i32, ptr %l223, !tbaa !23
  %t414 = load i32, ptr %l229, !tbaa !23
  %t415 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %t412, i32 %t413, i32 %t414)
  store i32 %t415, ptr %l230
  br label %bb76
bb76:
  %t416 = load i32, ptr %l230, !tbaa !23
  %t417 = load ptr, ptr %l18, !tbaa !29
  %t419 = getelementptr %"compiler/generic:AnyTable", ptr %t417, i32 0, i32 5
  store ptr %t419, ptr %l232, !tbaa !29
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load i64, ptr %l5, !tbaa !24
  %t422 = load i64, ptr %l25, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t423
  %t424 = getelementptr { i64, [2 x i64] }, ptr %t423, i32 0, i32 0
  store i64 9, ptr %t424
  %t426 = insertvalue { i64, i64 } undef, i64 %t421, 0
  %t428 = insertvalue { i64, i64 } %t426, i64 %t422, 1
  %t429 = getelementptr { i64, [2 x i64] }, ptr %t423, i32 0, i32 1
  store { i64, i64 } %t428, ptr %t429
  %t430 = load { i64, [2 x i64] }, ptr %t423
  %t432 = load i64, ptr %l19, !tbaa !24
  %t433 = load %"compiler/source:Span", ptr %l3
  %t439 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t420, { i64, [2 x i64] } %t430, i32 %t416, i64 %t432, %"compiler/source:Span" %t433)
  store i64 %t439, ptr %l240
  br label %bb77
bb77:
  %t440 = load ptr, ptr %l232, !tbaa !29
  %t441 = load i64, ptr %l240, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t440, i64 %t441)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t442 = load i64, ptr %l24, !tbaa !24
  %t445 = add i64 %t442, 1
  store i64 %t445, ptr %l24, !tbaa !24
  br label %bb68
bb80:
  %t447 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t447, ptr %l244
  br label %bb81
bb81:
  %t448 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l244
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t448, ptr %l30
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t450 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %s0, ptr %t449, i32 %t450, ptr %l30, i64 0)
  br label %bb82
bb82:
  %t454 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t454, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l21 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l21, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Alt", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t30, ptr %t31, ptr %t35)
  br label %bb8
bb8:
  %t40 = load ptr, ptr %l6, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Alt", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t57 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t57, ptr %l37, !tbaa !27
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Bind", ptr %t63, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t65, ptr %t66, ptr %t70)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %l8, !tbaa !24
  br label %bb9
bb15:
  br label %bb16
bb16:
  %t80 = load i64, ptr %l4, !tbaa !24
  %t83 = add i64 %t80, 1
  store i64 %t83, ptr %l4, !tbaa !24
  br label %bb4
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Arm", ptr %t87, i32 0, i32 2
  %t90 = load ptr, ptr %t89, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t85, ptr %t86, ptr %t90)
  br label %bb18
bb18:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Arm", ptr %t96, i32 0, i32 3
  %t99 = load ptr, ptr %t98, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t94, ptr %t95, ptr %t99)
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Arm", ptr %t105, i32 0, i32 4
  %t108 = load ptr, ptr %t107, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t103, ptr %t104, ptr %t108)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l66 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l153 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l164 = alloca i1
  %l177 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l192 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca i1
  %l219 = alloca { i64, ptr }
  %l229 = alloca ptr
  %l230 = alloca i1
  %l250 = alloca ptr
  %l251 = alloca i1
  %l270 = alloca ptr
  %l271 = alloca i1
  %l284 = alloca { i64, ptr }
  %l298 = alloca ptr
  %l299 = alloca i1
  %l312 = alloca { i64, ptr }
  %l330 = alloca { i64, ptr }
  %l344 = alloca ptr
  %l345 = alloca i1
  %l362 = alloca { i64, ptr }
  %l377 = alloca { i64, ptr }
  %l390 = alloca ptr
  %l391 = alloca i1
  %l396 = alloca ptr
  %l397 = alloca i1
  %l406 = alloca ptr
  %l407 = alloca i1
  %l425 = alloca { i64, ptr }
  %l436 = alloca ptr
  %l437 = alloca i1
  %l452 = alloca ptr
  %l453 = alloca i1
  %l466 = alloca { i64, ptr }
  %l475 = alloca ptr
  %l476 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t6 = load ptr, ptr %l69, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l69, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l70, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l70, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t20, ptr %t21, ptr %t22)
  br label %bb9
bb9:
  br label %bb239
bb10:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t28 = load ptr, ptr %l79, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l79, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 3
  store i1 %t34, ptr %l80, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l80, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t42, ptr %t43, ptr %t44)
  br label %bb16
bb16:
  br label %bb239
bb17:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t50 = load ptr, ptr %l89, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb18, label %bb19
bb18:
  %t53 = load ptr, ptr %l89, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 18}
  %t56 = icmp eq i64 %t54, 4
  store i1 %t56, ptr %l90, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l90, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t64, ptr %t65, ptr %t66)
  br label %bb23
bb23:
  br label %bb239
bb24:
  %t71 = load ptr, ptr %l2, !tbaa !29
  store ptr %t71, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t72 = load ptr, ptr %l99, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t75 = load ptr, ptr %l99, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 18}
  %t78 = icmp eq i64 %t76, 5
  store i1 %t78, ptr %l100, !tbaa !21
  br label %bb26
bb26:
  %t79 = load i1, ptr %l100, !tbaa !21
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t86, ptr %t87, ptr %t91)
  br label %bb30
bb30:
  br label %bb239
bb31:
  %t96 = load ptr, ptr %l2, !tbaa !29
  store ptr %t96, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t97 = load ptr, ptr %l110, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb32, label %bb33
bb32:
  %t100 = load ptr, ptr %l110, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 18}
  %t103 = icmp eq i64 %t101, 6
  store i1 %t103, ptr %l111, !tbaa !21
  br label %bb33
bb33:
  %t104 = load i1, ptr %l111, !tbaa !21
  br i1 %t104, label %bb34, label %bb35
bb34:
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  br label %bb69
bb36:
  %t111 = load ptr, ptr %l7, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Call", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  store ptr %t114, ptr %l8, !tbaa !29
  %t116 = load ptr, ptr %l8, !tbaa !29
  store ptr %t116, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t117 = load ptr, ptr %l118, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb37, label %bb38
bb37:
  %t120 = load ptr, ptr %l118, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 5}
  %t123 = icmp eq i64 %t121, 0
  store i1 %t123, ptr %l119, !tbaa !21
  br label %bb38
bb38:
  %t124 = load i1, ptr %l119, !tbaa !21
  br i1 %t124, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %l8, !tbaa !29
  %t127 = getelementptr { i64, [3 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { i32 }, ptr %t127, i32 0, i32 0
  %t129 = load i32, ptr %t128
  store i32 %t129, ptr %l9, !tbaa !23
  br label %bb41
bb40:
  br label %bb46
bb41:
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr %"compiler/check:b5aWalk", ptr %t131, i32 0, i32 6
  %t134 = load i1, ptr %t133, !tbaa !21
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb42, label %bb43
bb42:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t140 = load i32, ptr %l9, !tbaa !23
  %t142 = sext i32 %t140 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t138, ptr %t139, i64 %t142)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb61
bb46:
  %t146 = load ptr, ptr %l8, !tbaa !29
  store ptr %t146, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t147 = load ptr, ptr %l131, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb47, label %bb48
bb47:
  %t150 = load ptr, ptr %l131, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 5}
  %t153 = icmp eq i64 %t151, 2
  store i1 %t153, ptr %l132, !tbaa !21
  br label %bb48
bb48:
  %t154 = load i1, ptr %l132, !tbaa !21
  br i1 %t154, label %bb49, label %bb50
bb49:
  %t155 = load ptr, ptr %l8, !tbaa !29
  %t157 = getelementptr { i64, [3 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { ptr }, ptr %t157, i32 0, i32 0
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l10, !tbaa !29
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/check:b5aWalk", ptr %t161, i32 0, i32 6
  %t164 = load i1, ptr %t163, !tbaa !21
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb52, label %bb53
bb52:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/check:b5aWalk", ptr %t168, i32 0, i32 7
  store i1 true, ptr %t170, !tbaa !21
  br label %bb54
bb53:
  br label %bb54
bb54:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t173 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t171, ptr %t172, ptr %t173)
  br label %bb55
bb55:
  br label %bb61
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_94214b31169ec8c4_68c852e51d74cc68)
  unreachable
bb61:
  %t178 = load ptr, ptr %l7, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Call", ptr %t178, i32 0, i32 1
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  store i64 %t185, ptr %l13, !tbaa !24
  br label %bb62
bb62:
  %t187 = load i64, ptr %l12, !tbaa !24
  %t188 = load i64, ptr %l13, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb63, label %bb64
bb63:
  br label %bb68
bb64:
  br label %bb65
bb65:
  %t195 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t195, ptr %l153, !tbaa !27
  %t196 = load i64, ptr %l12, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr ptr, ptr %t199, i64 %t196
  %t201 = load ptr, ptr %t200, !tbaa !39
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t203, ptr %t204, ptr %t201)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t210 = load i64, ptr %l12, !tbaa !24
  %t213 = add i64 %t210, 1
  store i64 %t213, ptr %l12, !tbaa !24
  br label %bb62
bb68:
  br label %bb239
bb69:
  %t215 = load ptr, ptr %l2, !tbaa !29
  store ptr %t215, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t216 = load ptr, ptr %l163, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb70, label %bb71
bb70:
  %t219 = load ptr, ptr %l163, !tbaa !29
  %t220 = load i64, ptr %t219, !range !{i64 0, i64 18}
  %t222 = icmp eq i64 %t220, 7
  store i1 %t222, ptr %l164, !tbaa !21
  br label %bb71
bb71:
  %t223 = load i1, ptr %l164, !tbaa !21
  br i1 %t223, label %bb72, label %bb73
bb72:
  %t224 = load ptr, ptr %l2, !tbaa !29
  %t226 = getelementptr { i64, [5 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t226, i32 0, i32 2
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l15, !tbaa !29
  br label %bb74
bb73:
  br label %bb83
bb74:
  %t230 = load ptr, ptr %l15, !tbaa !29
  %t232 = getelementptr %"compiler/typed:Make", ptr %t230, i32 0, i32 2
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t235, 0
  store i64 %t237, ptr %l18, !tbaa !24
  br label %bb75
bb75:
  %t239 = load i64, ptr %l17, !tbaa !24
  %t240 = load i64, ptr %l18, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb76, label %bb77
bb76:
  br label %bb81
bb77:
  br label %bb78
bb78:
  %t247 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t247, ptr %l177, !tbaa !27
  %t248 = load i64, ptr %l17, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr ptr, ptr %t251, i64 %t248
  %t253 = load ptr, ptr %t252, !tbaa !39
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t255, ptr %t256, ptr %t253)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t262 = load i64, ptr %l17, !tbaa !24
  %t265 = add i64 %t262, 1
  store i64 %t265, ptr %l17, !tbaa !24
  br label %bb75
bb81:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t269 = load ptr, ptr %l15, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Make", ptr %t269, i32 0, i32 3
  %t272 = load ptr, ptr %t271, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t267, ptr %t268, ptr %t272)
  br label %bb82
bb82:
  br label %bb239
bb83:
  %t276 = load ptr, ptr %l2, !tbaa !29
  store ptr %t276, ptr %l191, !tbaa !29
  store i1 false, ptr %l192, !tbaa !21
  %t277 = load ptr, ptr %l191, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb84, label %bb85
bb84:
  %t280 = load ptr, ptr %l191, !tbaa !29
  %t281 = load i64, ptr %t280, !range !{i64 0, i64 18}
  %t283 = icmp eq i64 %t281, 8
  store i1 %t283, ptr %l192, !tbaa !21
  br label %bb85
bb85:
  %t284 = load i1, ptr %l192, !tbaa !21
  br i1 %t284, label %bb86, label %bb87
bb86:
  %t285 = load ptr, ptr %l2, !tbaa !29
  %t287 = getelementptr { i64, [5 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t287, i32 0, i32 2
  %t289 = load ptr, ptr %t288
  store ptr %t289, ptr %l20, !tbaa !29
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t293 = load ptr, ptr %l20, !tbaa !29
  %t295 = getelementptr %"compiler/typed:Collect", ptr %t293, i32 0, i32 0
  %t296 = load ptr, ptr %t295, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t291, ptr %t292, ptr %t296)
  br label %bb89
bb89:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load ptr, ptr %l1, !tbaa !29
  %t302 = load ptr, ptr %l20, !tbaa !29
  %t304 = getelementptr %"compiler/typed:Collect", ptr %t302, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t300, ptr %t301, ptr %t305)
  br label %bb90
bb90:
  br label %bb239
bb91:
  %t310 = load ptr, ptr %l2, !tbaa !29
  store ptr %t310, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t311 = load ptr, ptr %l206, !tbaa !29
  %t312 = icmp ne ptr %t311, null
  br i1 %t312, label %bb92, label %bb93
bb92:
  %t314 = load ptr, ptr %l206, !tbaa !29
  %t315 = load i64, ptr %t314, !range !{i64 0, i64 18}
  %t317 = icmp eq i64 %t315, 9
  store i1 %t317, ptr %l207, !tbaa !21
  br label %bb93
bb93:
  %t318 = load i1, ptr %l207, !tbaa !21
  br i1 %t318, label %bb94, label %bb95
bb94:
  %t319 = load ptr, ptr %l2, !tbaa !29
  %t321 = getelementptr { i64, [5 x i64] }, ptr %t319, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t321, i32 0, i32 4
  %t323 = load { i64, ptr }, ptr %t322
  store { i64, ptr } %t323, ptr %l21, !tbaa !27
  br label %bb96
bb95:
  br label %bb104
bb96:
  %t325 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t325, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t327 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t327, 0
  store i64 %t329, ptr %l24, !tbaa !24
  br label %bb97
bb97:
  %t331 = load i64, ptr %l23, !tbaa !24
  %t332 = load i64, ptr %l24, !tbaa !24
  %t335 = icmp slt i64 %t331, %t332
  %t337 = xor i1 %t335, true
  br i1 %t337, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t339 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t339, ptr %l219, !tbaa !27
  %t340 = load i64, ptr %l23, !tbaa !24
  %t342 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr ptr, ptr %t343, i64 %t340
  %t345 = load ptr, ptr %t344, !tbaa !39
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t347, ptr %t348, ptr %t345)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t354 = load i64, ptr %l23, !tbaa !24
  %t357 = add i64 %t354, 1
  store i64 %t357, ptr %l23, !tbaa !24
  br label %bb97
bb103:
  br label %bb239
bb104:
  %t359 = load ptr, ptr %l2, !tbaa !29
  store ptr %t359, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t360 = load ptr, ptr %l229, !tbaa !29
  %t361 = icmp ne ptr %t360, null
  br i1 %t361, label %bb105, label %bb106
bb105:
  %t363 = load ptr, ptr %l229, !tbaa !29
  %t364 = load i64, ptr %t363, !range !{i64 0, i64 18}
  %t366 = icmp eq i64 %t364, 10
  store i1 %t366, ptr %l230, !tbaa !21
  br label %bb106
bb106:
  %t367 = load i1, ptr %l230, !tbaa !21
  br i1 %t367, label %bb107, label %bb108
bb107:
  %t368 = load ptr, ptr %l2, !tbaa !29
  %t370 = getelementptr { i64, [5 x i64] }, ptr %t368, i32 0, i32 1
  %t371 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t370, i32 0, i32 2
  %t372 = load ptr, ptr %t371
  store ptr %t372, ptr %l26, !tbaa !29
  br label %bb109
bb108:
  br label %bb113
bb109:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load ptr, ptr %l1, !tbaa !29
  %t376 = load ptr, ptr %l26, !tbaa !29
  %t378 = getelementptr %"compiler/typed:Slice", ptr %t376, i32 0, i32 0
  %t379 = load ptr, ptr %t378, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t374, ptr %t375, ptr %t379)
  br label %bb110
bb110:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load ptr, ptr %l1, !tbaa !29
  %t386 = load ptr, ptr %l26, !tbaa !29
  %t388 = getelementptr %"compiler/typed:Slice", ptr %t386, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t384, ptr %t385, ptr %t389)
  br label %bb111
bb111:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load ptr, ptr %l1, !tbaa !29
  %t396 = load ptr, ptr %l26, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Slice", ptr %t396, i32 0, i32 2
  %t399 = load ptr, ptr %t398, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t394, ptr %t395, ptr %t399)
  br label %bb112
bb112:
  br label %bb239
bb113:
  %t404 = load ptr, ptr %l2, !tbaa !29
  store ptr %t404, ptr %l250, !tbaa !29
  store i1 false, ptr %l251, !tbaa !21
  %t405 = load ptr, ptr %l250, !tbaa !29
  %t406 = icmp ne ptr %t405, null
  br i1 %t406, label %bb114, label %bb115
bb114:
  %t408 = load ptr, ptr %l250, !tbaa !29
  %t409 = load i64, ptr %t408, !range !{i64 0, i64 18}
  %t411 = icmp eq i64 %t409, 11
  store i1 %t411, ptr %l251, !tbaa !21
  br label %bb115
bb115:
  %t412 = load i1, ptr %l251, !tbaa !21
  br i1 %t412, label %bb116, label %bb117
bb116:
  %t413 = load ptr, ptr %l2, !tbaa !29
  %t415 = getelementptr { i64, [5 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t415, i32 0, i32 2
  %t417 = load ptr, ptr %t416
  store ptr %t417, ptr %l27, !tbaa !29
  br label %bb118
bb117:
  br label %bb122
bb118:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load ptr, ptr %l1, !tbaa !29
  %t421 = load ptr, ptr %l27, !tbaa !29
  %t423 = getelementptr %"compiler/typed:Cond", ptr %t421, i32 0, i32 0
  %t424 = load ptr, ptr %t423, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t419, ptr %t420, ptr %t424)
  br label %bb119
bb119:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load ptr, ptr %l1, !tbaa !29
  %t431 = load ptr, ptr %l27, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Cond", ptr %t431, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t429, ptr %t430, ptr %t434)
  br label %bb120
bb120:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t440 = load ptr, ptr %l27, !tbaa !29
  %t442 = getelementptr %"compiler/typed:Cond", ptr %t440, i32 0, i32 2
  %t443 = load ptr, ptr %t442, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t438, ptr %t439, ptr %t443)
  br label %bb121
bb121:
  br label %bb239
bb122:
  %t448 = load ptr, ptr %l2, !tbaa !29
  store ptr %t448, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t449 = load ptr, ptr %l270, !tbaa !29
  %t450 = icmp ne ptr %t449, null
  br i1 %t450, label %bb123, label %bb124
bb123:
  %t452 = load ptr, ptr %l270, !tbaa !29
  %t453 = load i64, ptr %t452, !range !{i64 0, i64 18}
  %t455 = icmp eq i64 %t453, 12
  store i1 %t455, ptr %l271, !tbaa !21
  br label %bb124
bb124:
  %t456 = load i1, ptr %l271, !tbaa !21
  br i1 %t456, label %bb125, label %bb126
bb125:
  %t457 = load ptr, ptr %l2, !tbaa !29
  %t459 = getelementptr { i64, [5 x i64] }, ptr %t457, i32 0, i32 1
  %t460 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t459, i32 0, i32 2
  %t461 = load ptr, ptr %t460
  store ptr %t461, ptr %l28, !tbaa !29
  br label %bb127
bb126:
  br label %bb136
bb127:
  %t463 = load ptr, ptr %l28, !tbaa !29
  %t465 = getelementptr %"compiler/typed:Seq", ptr %t463, i32 0, i32 0
  %t466 = load { i64, ptr }, ptr %t465, !tbaa !27
  store { i64, ptr } %t466, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t468 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t468, 0
  store i64 %t470, ptr %l31, !tbaa !24
  br label %bb128
bb128:
  %t472 = load i64, ptr %l30, !tbaa !24
  %t473 = load i64, ptr %l31, !tbaa !24
  %t476 = icmp slt i64 %t472, %t473
  %t478 = xor i1 %t476, true
  br i1 %t478, label %bb129, label %bb130
bb129:
  br label %bb134
bb130:
  br label %bb131
bb131:
  %t480 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t480, ptr %l284, !tbaa !27
  %t481 = load i64, ptr %l30, !tbaa !24
  %t483 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t484 = load ptr, ptr %t483, !tbaa !27
  %t485 = getelementptr ptr, ptr %t484, i64 %t481
  %t486 = load ptr, ptr %t485, !tbaa !39
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t488, ptr %t489, ptr %t486)
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t495 = load i64, ptr %l30, !tbaa !24
  %t498 = add i64 %t495, 1
  store i64 %t498, ptr %l30, !tbaa !24
  br label %bb128
bb134:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load ptr, ptr %l1, !tbaa !29
  %t502 = load ptr, ptr %l28, !tbaa !29
  %t504 = getelementptr %"compiler/typed:Seq", ptr %t502, i32 0, i32 1
  %t505 = load ptr, ptr %t504, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t500, ptr %t501, ptr %t505)
  br label %bb135
bb135:
  br label %bb239
bb136:
  %t509 = load ptr, ptr %l2, !tbaa !29
  store ptr %t509, ptr %l298, !tbaa !29
  store i1 false, ptr %l299, !tbaa !21
  %t510 = load ptr, ptr %l298, !tbaa !29
  %t511 = icmp ne ptr %t510, null
  br i1 %t511, label %bb137, label %bb138
bb137:
  %t513 = load ptr, ptr %l298, !tbaa !29
  %t514 = load i64, ptr %t513, !range !{i64 0, i64 18}
  %t516 = icmp eq i64 %t514, 13
  store i1 %t516, ptr %l299, !tbaa !21
  br label %bb138
bb138:
  %t517 = load i1, ptr %l299, !tbaa !21
  br i1 %t517, label %bb139, label %bb140
bb139:
  %t518 = load ptr, ptr %l2, !tbaa !29
  %t520 = getelementptr { i64, [5 x i64] }, ptr %t518, i32 0, i32 1
  %t521 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t520, i32 0, i32 2
  %t522 = load ptr, ptr %t521
  store ptr %t522, ptr %l33, !tbaa !29
  br label %bb141
bb140:
  br label %bb157
bb141:
  %t524 = load ptr, ptr %l33, !tbaa !29
  %t526 = getelementptr %"compiler/typed:Match", ptr %t524, i32 0, i32 0
  %t527 = load { i64, ptr }, ptr %t526, !tbaa !27
  store { i64, ptr } %t527, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t529 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t531 = extractvalue { i64, ptr } %t529, 0
  store i64 %t531, ptr %l36, !tbaa !24
  br label %bb142
bb142:
  %t533 = load i64, ptr %l35, !tbaa !24
  %t534 = load i64, ptr %l36, !tbaa !24
  %t537 = icmp slt i64 %t533, %t534
  %t539 = xor i1 %t537, true
  br i1 %t539, label %bb143, label %bb144
bb143:
  br label %bb148
bb144:
  br label %bb145
bb145:
  %t541 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t541, ptr %l312, !tbaa !27
  %t542 = load i64, ptr %l35, !tbaa !24
  %t544 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t545 = load ptr, ptr %t544, !tbaa !27
  %t546 = getelementptr ptr, ptr %t545, i64 %t542
  %t547 = load ptr, ptr %t546, !tbaa !39
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t550 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t549, ptr %t550, ptr %t547)
  br label %bb146
bb146:
  br label %bb147
bb147:
  %t556 = load i64, ptr %l35, !tbaa !24
  %t559 = add i64 %t556, 1
  store i64 %t559, ptr %l35, !tbaa !24
  br label %bb142
bb148:
  %t561 = load ptr, ptr %l33, !tbaa !29
  %t563 = getelementptr %"compiler/typed:Match", ptr %t561, i32 0, i32 1
  %t564 = load { i64, ptr }, ptr %t563, !tbaa !27
  store { i64, ptr } %t564, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t566 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t568 = extractvalue { i64, ptr } %t566, 0
  store i64 %t568, ptr %l40, !tbaa !24
  br label %bb149
bb149:
  %t570 = load i64, ptr %l39, !tbaa !24
  %t571 = load i64, ptr %l40, !tbaa !24
  %t574 = icmp slt i64 %t570, %t571
  %t576 = xor i1 %t574, true
  br i1 %t576, label %bb150, label %bb151
bb150:
  br label %bb155
bb151:
  br label %bb152
bb152:
  %t578 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t578, ptr %l330, !tbaa !27
  %t579 = load i64, ptr %l39, !tbaa !24
  %t581 = getelementptr { i64, ptr }, ptr %l330, i32 0, i32 1
  %t582 = load ptr, ptr %t581, !tbaa !27
  %t583 = getelementptr ptr, ptr %t582, i64 %t579
  %t584 = load ptr, ptr %t583, !tbaa !39
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %t586, ptr %t587, ptr %t584)
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t593 = load i64, ptr %l39, !tbaa !24
  %t596 = add i64 %t593, 1
  store i64 %t596, ptr %l39, !tbaa !24
  br label %bb149
bb155:
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load ptr, ptr %l1, !tbaa !29
  %t600 = load ptr, ptr %l33, !tbaa !29
  %t602 = getelementptr %"compiler/typed:Match", ptr %t600, i32 0, i32 2
  %t603 = load ptr, ptr %t602, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %t598, ptr %t599, ptr %t603)
  br label %bb156
bb156:
  br label %bb239
bb157:
  %t607 = load ptr, ptr %l2, !tbaa !29
  store ptr %t607, ptr %l344, !tbaa !29
  store i1 false, ptr %l345, !tbaa !21
  %t608 = load ptr, ptr %l344, !tbaa !29
  %t609 = icmp ne ptr %t608, null
  br i1 %t609, label %bb158, label %bb159
bb158:
  %t611 = load ptr, ptr %l344, !tbaa !29
  %t612 = load i64, ptr %t611, !range !{i64 0, i64 18}
  %t614 = icmp eq i64 %t612, 14
  store i1 %t614, ptr %l345, !tbaa !21
  br label %bb159
bb159:
  %t615 = load i1, ptr %l345, !tbaa !21
  br i1 %t615, label %bb160, label %bb161
bb160:
  %t616 = load ptr, ptr %l2, !tbaa !29
  %t618 = getelementptr { i64, [5 x i64] }, ptr %t616, i32 0, i32 1
  %t619 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t618, i32 0, i32 2
  %t620 = load ptr, ptr %t619
  store ptr %t620, ptr %l42, !tbaa !29
  br label %bb162
bb161:
  br label %bb178
bb162:
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t623 = load ptr, ptr %l1, !tbaa !29
  %t624 = load ptr, ptr %l42, !tbaa !29
  %t626 = getelementptr %"compiler/typed:Try", ptr %t624, i32 0, i32 0
  %t627 = load ptr, ptr %t626, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t622, ptr %t623, ptr %t627)
  br label %bb163
bb163:
  %t631 = load ptr, ptr %l42, !tbaa !29
  %t633 = getelementptr %"compiler/typed:Try", ptr %t631, i32 0, i32 1
  %t634 = load { i64, ptr }, ptr %t633, !tbaa !27
  store { i64, ptr } %t634, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t636 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t636, 0
  store i64 %t638, ptr %l45, !tbaa !24
  br label %bb164
bb164:
  %t640 = load i64, ptr %l44, !tbaa !24
  %t641 = load i64, ptr %l45, !tbaa !24
  %t644 = icmp slt i64 %t640, %t641
  %t646 = xor i1 %t644, true
  br i1 %t646, label %bb165, label %bb166
bb165:
  br label %bb177
bb166:
  br label %bb167
bb167:
  %t648 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t648, ptr %l362, !tbaa !27
  %t649 = load i64, ptr %l44, !tbaa !24
  %t651 = getelementptr { i64, ptr }, ptr %l362, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !27
  %t653 = getelementptr ptr, ptr %t652, i64 %t649
  %t654 = load ptr, ptr %t653, !tbaa !39
  store ptr %t654, ptr %l46, !tbaa !29
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = load ptr, ptr %l1, !tbaa !29
  %t658 = load ptr, ptr %l46, !tbaa !29
  %t660 = getelementptr %"compiler/typed:Clause", ptr %t658, i32 0, i32 3
  %t661 = load ptr, ptr %t660, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t656, ptr %t657, ptr %t661)
  br label %bb168
bb168:
  %t665 = load ptr, ptr %l46, !tbaa !29
  %t667 = getelementptr %"compiler/typed:Clause", ptr %t665, i32 0, i32 4
  %t668 = load { i64, ptr }, ptr %t667, !tbaa !27
  store { i64, ptr } %t668, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  %t670 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t672 = extractvalue { i64, ptr } %t670, 0
  store i64 %t672, ptr %l49, !tbaa !24
  br label %bb169
bb169:
  %t674 = load i64, ptr %l48, !tbaa !24
  %t675 = load i64, ptr %l49, !tbaa !24
  %t678 = icmp slt i64 %t674, %t675
  %t680 = xor i1 %t678, true
  br i1 %t680, label %bb170, label %bb171
bb170:
  br label %bb175
bb171:
  br label %bb172
bb172:
  %t682 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t682, ptr %l377, !tbaa !27
  %t683 = load i64, ptr %l48, !tbaa !24
  %t685 = getelementptr { i64, ptr }, ptr %l377, i32 0, i32 1
  %t686 = load ptr, ptr %t685, !tbaa !27
  %t687 = getelementptr ptr, ptr %t686, i64 %t683
  %t688 = load ptr, ptr %t687, !tbaa !39
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t690, ptr %t691, ptr %t688)
  br label %bb173
bb173:
  br label %bb174
bb174:
  %t697 = load i64, ptr %l48, !tbaa !24
  %t700 = add i64 %t697, 1
  store i64 %t700, ptr %l48, !tbaa !24
  br label %bb169
bb175:
  br label %bb176
bb176:
  %t702 = load i64, ptr %l44, !tbaa !24
  %t705 = add i64 %t702, 1
  store i64 %t705, ptr %l44, !tbaa !24
  br label %bb164
bb177:
  br label %bb239
bb178:
  %t707 = load ptr, ptr %l2, !tbaa !29
  store ptr %t707, ptr %l390, !tbaa !29
  store i1 false, ptr %l391, !tbaa !21
  %t708 = load ptr, ptr %l390, !tbaa !29
  %t709 = icmp ne ptr %t708, null
  br i1 %t709, label %bb179, label %bb180
bb179:
  %t711 = load ptr, ptr %l390, !tbaa !29
  %t712 = load i64, ptr %t711, !range !{i64 0, i64 18}
  %t714 = icmp eq i64 %t712, 15
  store i1 %t714, ptr %l391, !tbaa !21
  br label %bb180
bb180:
  %t715 = load i1, ptr %l391, !tbaa !21
  br i1 %t715, label %bb181, label %bb182
bb181:
  %t716 = load ptr, ptr %l2, !tbaa !29
  %t718 = getelementptr { i64, [5 x i64] }, ptr %t716, i32 0, i32 1
  %t719 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t718, i32 0, i32 2
  %t720 = load ptr, ptr %t719
  store ptr %t720, ptr %l51, !tbaa !29
  br label %bb183
bb182:
  br label %bb214
bb183:
  %t722 = load ptr, ptr %l51, !tbaa !29
  store ptr %t722, ptr %l396, !tbaa !29
  store i1 false, ptr %l397, !tbaa !21
  %t723 = load ptr, ptr %l396, !tbaa !29
  %t724 = icmp ne ptr %t723, null
  br i1 %t724, label %bb184, label %bb185
bb184:
  %t726 = load ptr, ptr %l396, !tbaa !29
  %t727 = load i64, ptr %t726, !range !{i64 0, i64 3}
  %t729 = icmp eq i64 %t727, 0
  store i1 %t729, ptr %l397, !tbaa !21
  br label %bb185
bb185:
  %t730 = load i1, ptr %l397, !tbaa !21
  br i1 %t730, label %bb186, label %bb187
bb186:
  %t731 = load ptr, ptr %l51, !tbaa !29
  %t733 = getelementptr { i64, [4 x i64] }, ptr %t731, i32 0, i32 1
  %t734 = getelementptr { i32 }, ptr %t733, i32 0, i32 0
  %t735 = load i32, ptr %t734
  store i32 %t735, ptr %l52, !tbaa !23
  br label %bb188
bb187:
  br label %bb190
bb188:
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t738 = load ptr, ptr %l1, !tbaa !29
  %t739 = load i32, ptr %l52, !tbaa !23
  %t741 = sext i32 %t739 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t737, ptr %t738, i64 %t741)
  br label %bb189
bb189:
  br label %bb213
bb190:
  %t745 = load ptr, ptr %l51, !tbaa !29
  store ptr %t745, ptr %l406, !tbaa !29
  store i1 false, ptr %l407, !tbaa !21
  %t746 = load ptr, ptr %l406, !tbaa !29
  %t747 = icmp ne ptr %t746, null
  br i1 %t747, label %bb191, label %bb192
bb191:
  %t749 = load ptr, ptr %l406, !tbaa !29
  %t750 = load i64, ptr %t749, !range !{i64 0, i64 3}
  %t752 = icmp eq i64 %t750, 1
  store i1 %t752, ptr %l407, !tbaa !21
  br label %bb192
bb192:
  %t753 = load i1, ptr %l407, !tbaa !21
  br i1 %t753, label %bb193, label %bb194
bb193:
  %t754 = load ptr, ptr %l51, !tbaa !29
  %t756 = getelementptr { i64, [4 x i64] }, ptr %t754, i32 0, i32 1
  %t757 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t756, i32 0, i32 0
  %t758 = load i32, ptr %t757
  store i32 %t758, ptr %l53, !tbaa !23
  %t760 = load ptr, ptr %l51, !tbaa !29
  %t762 = getelementptr { i64, [4 x i64] }, ptr %t760, i32 0, i32 1
  %t763 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t762, i32 0, i32 1
  %t764 = load { i64, ptr }, ptr %t763
  store { i64, ptr } %t764, ptr %l54, !tbaa !27
  br label %bb195
bb194:
  br label %bb204
bb195:
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load ptr, ptr %l1, !tbaa !29
  %t768 = load i32, ptr %l53, !tbaa !23
  %t770 = sext i32 %t768 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t766, ptr %t767, i64 %t770)
  br label %bb196
bb196:
  %t774 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t774, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t776 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t778 = extractvalue { i64, ptr } %t776, 0
  store i64 %t778, ptr %l57, !tbaa !24
  br label %bb197
bb197:
  %t780 = load i64, ptr %l56, !tbaa !24
  %t781 = load i64, ptr %l57, !tbaa !24
  %t784 = icmp slt i64 %t780, %t781
  %t786 = xor i1 %t784, true
  br i1 %t786, label %bb198, label %bb199
bb198:
  br label %bb203
bb199:
  br label %bb200
bb200:
  %t788 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t788, ptr %l425, !tbaa !27
  %t789 = load i64, ptr %l56, !tbaa !24
  %t791 = getelementptr { i64, ptr }, ptr %l425, i32 0, i32 1
  %t792 = load ptr, ptr %t791, !tbaa !27
  %t793 = getelementptr ptr, ptr %t792, i64 %t789
  %t794 = load ptr, ptr %t793, !tbaa !39
  %t796 = load ptr, ptr %l0, !tbaa !29
  %t797 = load ptr, ptr %l1, !tbaa !29
  %t800 = getelementptr %"compiler/typed:Capture", ptr %t794, i32 0, i32 1
  %t801 = load ptr, ptr %t800, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t796, ptr %t797, ptr %t801)
  br label %bb201
bb201:
  br label %bb202
bb202:
  %t806 = load i64, ptr %l56, !tbaa !24
  %t809 = add i64 %t806, 1
  store i64 %t809, ptr %l56, !tbaa !24
  br label %bb197
bb203:
  br label %bb213
bb204:
  %t811 = load ptr, ptr %l51, !tbaa !29
  store ptr %t811, ptr %l436, !tbaa !29
  store i1 false, ptr %l437, !tbaa !21
  %t812 = load ptr, ptr %l436, !tbaa !29
  %t813 = icmp ne ptr %t812, null
  br i1 %t813, label %bb205, label %bb206
bb205:
  %t815 = load ptr, ptr %l436, !tbaa !29
  %t816 = load i64, ptr %t815, !range !{i64 0, i64 3}
  %t818 = icmp eq i64 %t816, 2
  store i1 %t818, ptr %l437, !tbaa !21
  br label %bb206
bb206:
  %t819 = load i1, ptr %l437, !tbaa !21
  br i1 %t819, label %bb207, label %bb208
bb207:
  %t820 = load ptr, ptr %l51, !tbaa !29
  %t822 = getelementptr { i64, [4 x i64] }, ptr %t820, i32 0, i32 1
  %t823 = getelementptr { i32, ptr, i32 }, ptr %t822, i32 0, i32 0
  %t824 = load i32, ptr %t823
  store i32 %t824, ptr %l59, !tbaa !23
  %t826 = load ptr, ptr %l51, !tbaa !29
  %t828 = getelementptr { i64, [4 x i64] }, ptr %t826, i32 0, i32 1
  %t829 = getelementptr { i32, ptr, i32 }, ptr %t828, i32 0, i32 1
  %t830 = load ptr, ptr %t829
  store ptr %t830, ptr %l60, !tbaa !29
  br label %bb209
bb208:
  br label %bb212
bb209:
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t833 = load ptr, ptr %l1, !tbaa !29
  %t834 = load i32, ptr %l59, !tbaa !23
  %t836 = sext i32 %t834 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t832, ptr %t833, i64 %t836)
  br label %bb210
bb210:
  %t840 = load ptr, ptr %l0, !tbaa !29
  %t841 = load ptr, ptr %l1, !tbaa !29
  %t842 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t840, ptr %t841, ptr %t842)
  br label %bb211
bb211:
  br label %bb213
bb212:
  call void @__olang_check_failed(ptr @olang_loc_d48ba9fb56fa57b5_9836703f13f4bc39)
  unreachable
bb213:
  br label %bb239
bb214:
  %t847 = load ptr, ptr %l2, !tbaa !29
  store ptr %t847, ptr %l452, !tbaa !29
  store i1 false, ptr %l453, !tbaa !21
  %t848 = load ptr, ptr %l452, !tbaa !29
  %t849 = icmp ne ptr %t848, null
  br i1 %t849, label %bb215, label %bb216
bb215:
  %t851 = load ptr, ptr %l452, !tbaa !29
  %t852 = load i64, ptr %t851, !range !{i64 0, i64 18}
  %t854 = icmp eq i64 %t852, 16
  store i1 %t854, ptr %l453, !tbaa !21
  br label %bb216
bb216:
  %t855 = load i1, ptr %l453, !tbaa !21
  br i1 %t855, label %bb217, label %bb218
bb217:
  %t856 = load ptr, ptr %l2, !tbaa !29
  %t858 = getelementptr { i64, [5 x i64] }, ptr %t856, i32 0, i32 1
  %t859 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t858, i32 0, i32 2
  %t860 = load ptr, ptr %t859
  store ptr %t860, ptr %l61, !tbaa !29
  br label %bb219
bb218:
  br label %bb227
bb219:
  %t862 = load ptr, ptr %l61, !tbaa !29
  %t864 = getelementptr %"compiler/typed:Text", ptr %t862, i32 0, i32 0
  %t865 = load { i64, ptr }, ptr %t864, !tbaa !27
  store { i64, ptr } %t865, ptr %l62, !tbaa !27
  store i64 0, ptr %l63, !tbaa !24
  %t867 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t869 = extractvalue { i64, ptr } %t867, 0
  store i64 %t869, ptr %l64, !tbaa !24
  br label %bb220
bb220:
  %t871 = load i64, ptr %l63, !tbaa !24
  %t872 = load i64, ptr %l64, !tbaa !24
  %t875 = icmp slt i64 %t871, %t872
  %t877 = xor i1 %t875, true
  br i1 %t877, label %bb221, label %bb222
bb221:
  br label %bb226
bb222:
  br label %bb223
bb223:
  %t879 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t879, ptr %l466, !tbaa !27
  %t880 = load i64, ptr %l63, !tbaa !24
  %t882 = getelementptr { i64, ptr }, ptr %l466, i32 0, i32 1
  %t883 = load ptr, ptr %t882, !tbaa !27
  %t884 = getelementptr ptr, ptr %t883, i64 %t880
  %t885 = load ptr, ptr %t884, !tbaa !39
  %t887 = load ptr, ptr %l0, !tbaa !29
  %t888 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPiece(ptr %v0, ptr %v1, ptr %v2, ptr %t887, ptr %t888, ptr %t885)
  br label %bb224
bb224:
  br label %bb225
bb225:
  %t893 = load i64, ptr %l63, !tbaa !24
  %t896 = add i64 %t893, 1
  store i64 %t896, ptr %l63, !tbaa !24
  br label %bb220
bb226:
  br label %bb239
bb227:
  %t898 = load ptr, ptr %l2, !tbaa !29
  store ptr %t898, ptr %l475, !tbaa !29
  store i1 false, ptr %l476, !tbaa !21
  %t899 = load ptr, ptr %l475, !tbaa !29
  %t900 = icmp ne ptr %t899, null
  br i1 %t900, label %bb228, label %bb229
bb228:
  %t902 = load ptr, ptr %l475, !tbaa !29
  %t903 = load i64, ptr %t902, !range !{i64 0, i64 18}
  %t905 = icmp eq i64 %t903, 17
  store i1 %t905, ptr %l476, !tbaa !21
  br label %bb229
bb229:
  %t906 = load i1, ptr %l476, !tbaa !21
  br i1 %t906, label %bb230, label %bb231
bb230:
  %t907 = load ptr, ptr %l2, !tbaa !29
  %t909 = getelementptr { i64, [5 x i64] }, ptr %t907, i32 0, i32 1
  %t910 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t909, i32 0, i32 2
  %t911 = load ptr, ptr %t910
  store ptr %t911, ptr %l66, !tbaa !29
  br label %bb232
bb231:
  br label %bb234
bb232:
  %t913 = load ptr, ptr %l0, !tbaa !29
  %t914 = load ptr, ptr %l1, !tbaa !29
  %t915 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t913, ptr %t914, ptr %t915)
  br label %bb233
bb233:
  br label %bb239
bb234:
  br i1 true, label %bb235, label %bb236
bb235:
  br label %bb237
bb236:
  br label %bb238
bb237:
  br label %bb239
bb238:
  call void @__olang_check_failed(ptr @olang_loc_964ce48e3719b9fe_ecf9d1875d849bc2)
  unreachable
bb239:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:b5aWalk", ptr %t3, i32 0, i32 2
  %t9 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t5, i64 %t1)
  store i1 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i1, ptr %l8, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/check:b5aWalk", ptr %t13, i32 0, i32 2
  %t16 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t15, i64 %t16)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPiece(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l20 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 2}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t16, ptr %t17, ptr %t18)
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/check:b5aWalk", ptr %t23, i32 0, i32 6
  %t26 = load i1, ptr %t25, !tbaa !21
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l17, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l18, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t32)
  store i32 %t34, ptr %l20
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i32, ptr %l20, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t35, ptr %t36, i32 %t37, i64 0)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_fd984862ae15b7b5_96e74f0ca55af519)
  unreachable
bb17:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v1, ptr %a0, i1 %a1, %"compiler/source:Span" %a2, ptr %a3) #0 {
entry:
  %l9 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a1, label %bb1, label %bb2
bb1:
  %t7 = load %"compiler/diagmsg:Msg", ptr %a3
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a2, %"compiler/diagmsg:Msg" %t7)
  store i64 %t11, ptr %l9
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebufferField(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t24 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  store ptr %t27, ptr %l14, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t28)
  store i32 %t30, ptr %l16
  br label %bb6
bb6:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t32 = load ptr, ptr %l14, !tbaa !29
  %t33 = load i32, ptr %l16, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFieldHolds(ptr %v0, ptr %t32, i32 %t33, i32 %t31)
  store i1 %t35, ptr %l18
  br label %bb7
bb7:
  %t36 = load i1, ptr %l18, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %rv
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_656971ecbb067a73_942081a116b7a267)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyField(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i32, ptr }
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca i64
  %l38 = alloca { i64, ptr }
  %l44 = alloca { i32, ptr }
  %l52 = alloca ptr
  %l53 = alloca i1
  %l55 = alloca %"compiler/source:Span"
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l60 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca i1
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/diagmsg:Msg"
  %l69 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca i1
  %l88 = alloca %"compiler/source:Span"
  %l93 = alloca %"compiler/diagmsg:Msg"
  %l95 = alloca i32
  %l100 = alloca i64
  %l103 = alloca i1
  %l107 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l113 = alloca %"compiler/source:Span"
  %l117 = alloca ptr
  %l118 = alloca i32
  %l122 = alloca ptr
  %l123 = alloca i1
  %l126 = alloca %"compiler/source:Span"
  %l130 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l134 = alloca %"compiler/diagmsg:Msg"
  %l138 = alloca { i64, ptr }
  %l139 = alloca %"compiler/diagmsg:Msg"
  %l141 = alloca i32
  %l152 = alloca i1
  %l155 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca i1
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca i64
  %l165 = alloca { i64, ptr }
  %l167 = alloca %"compiler/diagmsg:Msg"
  %l169 = alloca i32
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t10 = alloca { i64, [4 x i64] }, align 8
  %t28 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/check:fieldSet", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l21, !tbaa !24
  %t9 = load %"compiler/source:Span", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t10
  %t11 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 0
  store i64 0, ptr %t11
  %t13 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t9, 0
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  store { %"compiler/source:Span" } %t13, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %t10
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t15, ptr %t17
  store ptr %t17, ptr %l24, !tbaa !29
  %t18 = load i64, ptr %l21, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l21, !tbaa !24
  %t22 = icmp sle i64 %t21, 1152921504606846975
  br i1 %t22, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_7e33472f03e5a723_adcfc8d4e22973ef)
  unreachable
bb3:
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t25)
  %t27 = load ptr, ptr %l24, !tbaa !29
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, %t24
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr ptr, ptr %t26, i64 %t32
  store ptr %t27, ptr %t34
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t26, 1
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t38, ptr %lp6
  %t40 = load ptr, ptr %lp6
  store { i64, ptr } %t37, ptr %t40, !tbaa !27
  %t41 = load i64, ptr %l5, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_7e33472f03e5a723_adcfc8d4e22973ef)
  unreachable
bb5:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = mul i64 %t45, 1
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  store i1 false, ptr %l9, !tbaa !21
  store { i64, ptr } %a2, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l12, !tbaa !24
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d27f09f1ed434aae_8d18f82803f9a31a)
  unreachable
bb7:
  %t57 = load i64, ptr %l11, !tbaa !24
  %t58 = load i64, ptr %l12, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb8, label %bb9
bb8:
  br label %bb70
bb9:
  br label %bb10
bb10:
  %t65 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t65, ptr %l38, !tbaa !27
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr ptr, ptr %t69, i64 %t66
  %t71 = load ptr, ptr %t70, !tbaa !39
  store ptr %t71, ptr %l13, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l13, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t79 = call { i32, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eitemOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t73, ptr %t74, ptr %t75)
  store { i32, ptr } %t79, ptr %l44
  br label %bb11
bb11:
  %t80 = load { i32, ptr }, ptr %l44
  store { i32, ptr } %t80, ptr %l14
  %t81 = getelementptr { i32, ptr }, ptr %l14, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l15, !tbaa !23
  %t84 = getelementptr { i32, ptr }, ptr %l14, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l16, !tbaa !29
  %t87 = load i32, ptr %l15, !tbaa !23
  %t89 = icmp eq i32 %t87, 0
  br i1 %t89, label %bb12, label %bb13
bb12:
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/check:fieldSet", ptr %t91, i32 0, i32 1
  %t94 = load i32, ptr %t93, !tbaa !23
  %t96 = icmp sge i32 %t94, 0
  br i1 %t96, label %bb14, label %bb15
bb13:
  br label %bb33
bb14:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l52, !tbaa !29
  %t99 = load i1, ptr %l4, !tbaa !21
  store i1 %t99, ptr %l53, !tbaa !21
  %t100 = load ptr, ptr %l13, !tbaa !29
  %t102 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t100)
  store %"compiler/source:Span" %t102, ptr %l55
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t105 = getelementptr %"compiler/check:fieldSet", ptr %t103, i32 0, i32 2
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStructPatPositional(ptr %v2, ptr %v0, { i64, ptr } %t106)
  store %"compiler/diagmsg:Msg" %t108, ptr %l58
  br label %bb17
bb17:
  %t109 = load ptr, ptr %l52, !tbaa !29
  %t110 = load i1, ptr %l53, !tbaa !21
  %t111 = load %"compiler/source:Span", ptr %l55
  %t113 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t109, i1 %t110, %"compiler/source:Span" %t111, ptr %l58)
  store i32 %t113, ptr %l60
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb19, label %ok.115, !prof !99
ok.115:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t116 = load i32, ptr %l60, !tbaa !23
  %t117 = lshr i32 %t116, 16
  %t118 = and i32 %t116, 65535
  %t119 = icmp eq i32 %t117, 1
  %t120 = select i1 %t119, i32 1, i32 0
  %t121 = icmp eq i32 %t116, 0
  %t122 = shl i32 %t120, 16
  %t123 = or i32 %t122, %t118
  %t124 = select i1 %t121, i32 0, i32 %t123
  call void @__olang_scope_close(ptr %s0)
  %t126 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t124, 0
  store { i32, { i64, ptr } } %t126, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t127 = load i1, ptr %l9, !tbaa !21
  br i1 %t127, label %bb22, label %bb23
bb22:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l63, !tbaa !29
  %t130 = load i1, ptr %l4, !tbaa !21
  store i1 %t130, ptr %l64, !tbaa !21
  %t131 = load ptr, ptr %l13, !tbaa !29
  %t133 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t131)
  store %"compiler/source:Span" %t133, ptr %l66
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t134 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatPositionAfterName(ptr %v0)
  store %"compiler/diagmsg:Msg" %t134, ptr %l67
  br label %bb25
bb25:
  %t135 = load ptr, ptr %l63, !tbaa !29
  %t136 = load i1, ptr %l64, !tbaa !21
  %t137 = load %"compiler/source:Span", ptr %l66
  %t139 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t135, i1 %t136, %"compiler/source:Span" %t137, ptr %l67)
  store i32 %t139, ptr %l69
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb27, label %ok.141, !prof !99
ok.141:
  br label %bb26
bb26:
  br label %bb28
bb27:
  %t142 = load i32, ptr %l69, !tbaa !23
  %t143 = lshr i32 %t142, 16
  %t144 = and i32 %t142, 65535
  %t145 = icmp eq i32 %t143, 1
  %t146 = select i1 %t145, i32 1, i32 0
  %t147 = icmp eq i32 %t142, 0
  %t148 = shl i32 %t146, 16
  %t149 = or i32 %t148, %t144
  %t150 = select i1 %t147, i32 0, i32 %t149
  call void @__olang_scope_close(ptr %s0)
  %t152 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t150, 0
  store { i32, { i64, ptr } } %t152, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t153 = load i64, ptr %l8, !tbaa !24
  %t154 = load i64, ptr %l5, !tbaa !24
  %t157 = icmp slt i64 %t153, %t154
  br i1 %t157, label %bb30, label %bb31
bb30:
  %t159 = load i64, ptr %l8, !tbaa !24
  %t160 = load ptr, ptr %l13, !tbaa !29
  %t162 = load ptr, ptr %lp6
  %t164 = getelementptr { i64, ptr }, ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr ptr, ptr %t165, i64 %t159
  store ptr %t160, ptr %t166, !tbaa !39
  %t167 = load i64, ptr %l8, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i1, ptr %t170, i64 %t167
  store i1 true, ptr %t171, !tbaa !31
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t175 = add i64 %t172, 1
  store i64 %t175, ptr %l8, !tbaa !24
  br label %bb69
bb33:
  store i1 true, ptr %l9, !tbaa !21
  %t177 = load ptr, ptr %l3, !tbaa !29
  %t179 = getelementptr %"compiler/check:fieldSet", ptr %t177, i32 0, i32 3
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t184 = icmp sgt i64 %t182, 0
  br i1 %t184, label %bb34, label %bb35
bb34:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l84, !tbaa !29
  %t187 = load i1, ptr %l4, !tbaa !21
  store i1 %t187, ptr %l85, !tbaa !21
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l13, !tbaa !29
  %t192 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %t188, ptr %t189)
  store %"compiler/source:Span" %t192, ptr %l88
  br label %bb36
bb35:
  br label %bb41
bb36:
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t195 = getelementptr %"compiler/check:fieldSet", ptr %t193, i32 0, i32 2
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  %t197 = load ptr, ptr %l3, !tbaa !29
  %t199 = getelementptr %"compiler/check:fieldSet", ptr %t197, i32 0, i32 3
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  %t203 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWholeCaseNamed(ptr %v2, ptr %v2, ptr %v0, { i64, ptr } %t196, { i64, ptr } %t200)
  store %"compiler/diagmsg:Msg" %t203, ptr %l93
  br label %bb37
bb37:
  %t204 = load ptr, ptr %l84, !tbaa !29
  %t205 = load i1, ptr %l85, !tbaa !21
  %t206 = load %"compiler/source:Span", ptr %l88
  %t208 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t204, i1 %t205, %"compiler/source:Span" %t206, ptr %l93)
  store i32 %t208, ptr %l95
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb39, label %ok.210, !prof !99
ok.210:
  br label %bb38
bb38:
  br label %bb40
bb39:
  %t211 = load i32, ptr %l95, !tbaa !23
  %t212 = lshr i32 %t211, 16
  %t213 = and i32 %t211, 65535
  %t214 = icmp eq i32 %t212, 1
  %t215 = select i1 %t214, i32 1, i32 0
  %t216 = icmp eq i32 %t211, 0
  %t217 = shl i32 %t215, 16
  %t218 = or i32 %t217, %t213
  %t219 = select i1 %t216, i32 0, i32 %t218
  call void @__olang_scope_close(ptr %s0)
  %t221 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t219, 0
  store { i32, { i64, ptr } } %t221, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t222 = load ptr, ptr %l3, !tbaa !29
  %t224 = getelementptr %"compiler/check:fieldSet", ptr %t222, i32 0, i32 0
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  %t226 = load i32, ptr %l15, !tbaa !23
  %t229 = call i64 @compiler_2fcheck_2enameIndex(ptr %v2, { i64, ptr } %t225, i32 %t226)
  store i64 %t229, ptr %l100
  br label %bb42
bb42:
  %t230 = load i64, ptr %l100, !tbaa !24
  store i64 %t230, ptr %l17, !tbaa !24
  %t231 = load i64, ptr %l17, !tbaa !24
  %t233 = icmp slt i64 %t231, 0
  br i1 %t233, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb46
bb44:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l3, !tbaa !29
  %t237 = load i32, ptr %l15, !tbaa !23
  %t241 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldReadable(ptr %v0, ptr %v2, ptr %t235, ptr %t236, i32 %t237)
  store i1 %t241, ptr %l107
  br label %bb45
bb45:
  %t242 = load i1, ptr %l107, !tbaa !21
  %t243 = xor i1 %t242, true
  store i1 %t243, ptr %l103, !tbaa !21
  br label %bb46
bb46:
  %t245 = load i1, ptr %l103, !tbaa !21
  br i1 %t245, label %bb47, label %bb48
bb47:
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l109, !tbaa !29
  %t247 = load i1, ptr %l4, !tbaa !21
  store i1 %t247, ptr %l110, !tbaa !21
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l13, !tbaa !29
  %t252 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %t248, ptr %t249)
  store %"compiler/source:Span" %t252, ptr %l113
  br label %bb49
bb48:
  br label %bb54
bb49:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load ptr, ptr %l3, !tbaa !29
  %t255 = load i32, ptr %l15, !tbaa !23
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoItemField(ptr %v0, ptr %v2, ptr %v0, ptr %t253, ptr %t254, i32 %t255)
  store ptr %t259, ptr %l117
  br label %bb50
bb50:
  %t260 = load ptr, ptr %l109, !tbaa !29
  %t261 = load i1, ptr %l110, !tbaa !21
  %t262 = load %"compiler/source:Span", ptr %l113
  %t263 = load ptr, ptr %l117, !tbaa !29
  %t264 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t260, i1 %t261, %"compiler/source:Span" %t262, ptr %t263)
  store i32 %t264, ptr %l118
  %t265 = icmp ne i32 %t264, 0
  br i1 %t265, label %bb52, label %ok.266, !prof !99
ok.266:
  br label %bb51
bb51:
  br label %bb53
bb52:
  %t267 = load i32, ptr %l118, !tbaa !23
  %t268 = lshr i32 %t267, 16
  %t269 = and i32 %t267, 65535
  %t270 = icmp eq i32 %t268, 1
  %t271 = select i1 %t270, i32 1, i32 0
  %t272 = icmp eq i32 %t267, 0
  %t273 = shl i32 %t271, 16
  %t274 = or i32 %t273, %t269
  %t275 = select i1 %t272, i32 0, i32 %t274
  call void @__olang_scope_close(ptr %s0)
  %t277 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t275, 0
  store { i32, { i64, ptr } } %t277, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t278 = load i64, ptr %l17, !tbaa !24
  %t280 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr i1, ptr %t281, i64 %t278
  %t283 = load i1, ptr %t282, !tbaa !31
  br i1 %t283, label %bb55, label %bb56
bb55:
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l122, !tbaa !29
  %t286 = load i1, ptr %l4, !tbaa !21
  store i1 %t286, ptr %l123, !tbaa !21
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load ptr, ptr %l13, !tbaa !29
  %t291 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %t287, ptr %t288)
  store %"compiler/source:Span" %t291, ptr %l126
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t292 = load i64, ptr %l17, !tbaa !24
  %t293 = load i64, ptr %l8, !tbaa !24
  %t296 = icmp slt i64 %t292, %t293
  br i1 %t296, label %bb58, label %bb59
bb58:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load i32, ptr %l15, !tbaa !23
  %t302 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t298, i32 %t299)
  store { i64, ptr } %t302, ptr %l133
  br label %bb60
bb59:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l15, !tbaa !23
  %t307 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t303, i32 %t304)
  store { i64, ptr } %t307, ptr %l138
  br label %bb62
bb60:
  %t308 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t309 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldBothWays(ptr %v0, ptr %v0, { i64, ptr } %t308)
  store %"compiler/diagmsg:Msg" %t309, ptr %l134
  br label %bb61
bb61:
  %t310 = load %"compiler/diagmsg:Msg", ptr %l134
  %t311 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/diagmsg:Msg" %t310, ptr %t311
  store ptr %t311, ptr %l130, !tbaa !29
  br label %bb64
bb62:
  %t313 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t314 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldTwice(ptr %v0, ptr %v0, { i64, ptr } %t313)
  store %"compiler/diagmsg:Msg" %t314, ptr %l139
  br label %bb63
bb63:
  %t315 = load %"compiler/diagmsg:Msg", ptr %l139
  %t316 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/diagmsg:Msg" %t315, ptr %t316
  store ptr %t316, ptr %l130, !tbaa !29
  br label %bb64
bb64:
  %t318 = load ptr, ptr %l122, !tbaa !29
  %t319 = load i1, ptr %l123, !tbaa !21
  %t320 = load %"compiler/source:Span", ptr %l126
  %t321 = load ptr, ptr %l130, !tbaa !29
  %t322 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t318, i1 %t319, %"compiler/source:Span" %t320, ptr %t321)
  store i32 %t322, ptr %l141
  %t323 = icmp ne i32 %t322, 0
  br i1 %t323, label %bb66, label %ok.324, !prof !99
ok.324:
  br label %bb65
bb65:
  br label %bb67
bb66:
  %t325 = load i32, ptr %l141, !tbaa !23
  %t326 = lshr i32 %t325, 16
  %t327 = and i32 %t325, 65535
  %t328 = icmp eq i32 %t326, 1
  %t329 = select i1 %t328, i32 1, i32 0
  %t330 = icmp eq i32 %t325, 0
  %t331 = shl i32 %t329, 16
  %t332 = or i32 %t331, %t327
  %t333 = select i1 %t330, i32 0, i32 %t332
  call void @__olang_scope_close(ptr %s0)
  %t335 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t333, 0
  store { i32, { i64, ptr } } %t335, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t336 = load i64, ptr %l17, !tbaa !24
  %t337 = load ptr, ptr %l16, !tbaa !29
  %t339 = load ptr, ptr %lp6
  %t341 = getelementptr { i64, ptr }, ptr %t339, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr ptr, ptr %t342, i64 %t336
  store ptr %t337, ptr %t343, !tbaa !39
  %t344 = load i64, ptr %l17, !tbaa !24
  %t346 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr i1, ptr %t347, i64 %t344
  store i1 true, ptr %t348, !tbaa !31
  br label %bb69
bb69:
  %t349 = load i64, ptr %l11, !tbaa !24
  %t352 = add i64 %t349, 1
  store i64 %t352, ptr %l11, !tbaa !24
  br label %bb7
bb70:
  %t354 = load i64, ptr %l8, !tbaa !24
  %t355 = load i64, ptr %l5, !tbaa !24
  %t358 = icmp sgt i64 %t354, %t355
  br i1 %t358, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l152, !tbaa !21
  br label %bb76
bb72:
  %t360 = load i1, ptr %l9, !tbaa !21
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb73, label %bb74
bb73:
  %t364 = load i64, ptr %l8, !tbaa !24
  %t365 = load i64, ptr %l5, !tbaa !24
  %t368 = icmp ne i64 %t364, %t365
  store i1 %t368, ptr %l155, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb75
bb75:
  %t370 = load i1, ptr %l155, !tbaa !21
  store i1 %t370, ptr %l152, !tbaa !21
  br label %bb76
bb76:
  %t371 = load i1, ptr %l152, !tbaa !21
  br i1 %t371, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s11
  %t372 = load ptr, ptr %l0, !tbaa !29
  store ptr %t372, ptr %l159, !tbaa !29
  %t373 = load i1, ptr %l4, !tbaa !21
  store i1 %t373, ptr %l160, !tbaa !21
  %t374 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t374, ptr %l161
  %t375 = load i64, ptr %l5, !tbaa !24
  store i64 %t375, ptr %l162, !tbaa !24
  %t376 = load i64, ptr %l5, !tbaa !24
  %t378 = icmp eq i64 %t376, 1
  br i1 %t378, label %bb79, label %bb80
bb78:
  br label %bb86
bb79:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l165, !tbaa !27
  br label %bb81
bb80:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l165, !tbaa !27
  br label %bb81
bb81:
  %t380 = load i64, ptr %l8, !tbaa !24
  %t381 = load i64, ptr %l162, !tbaa !24
  %t382 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t384 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s11, ptr %v0, i64 %t381, { i64, ptr } %t382, i64 %t380)
  store %"compiler/diagmsg:Msg" %t384, ptr %l167
  br label %bb82
bb82:
  %t385 = load ptr, ptr %l159, !tbaa !29
  %t386 = load i1, ptr %l160, !tbaa !21
  %t387 = load %"compiler/source:Span", ptr %l161
  %t389 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t385, i1 %t386, %"compiler/source:Span" %t387, ptr %l167)
  store i32 %t389, ptr %l169
  %t390 = icmp ne i32 %t389, 0
  br i1 %t390, label %bb84, label %ok.391, !prof !99
ok.391:
  br label %bb83
bb83:
  br label %bb85
bb84:
  %t392 = load i32, ptr %l169, !tbaa !23
  %t393 = lshr i32 %t392, 16
  %t394 = and i32 %t392, 65535
  %t395 = icmp eq i32 %t393, 1
  %t396 = select i1 %t395, i32 1, i32 0
  %t397 = icmp eq i32 %t392, 0
  %t398 = shl i32 %t396, 16
  %t399 = or i32 %t398, %t394
  %t400 = select i1 %t397, i32 0, i32 %t399
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t402 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t400, 0
  store { i32, { i64, ptr } } %t402, ptr %rv
  br label %ret
bb85:
  call void @__olang_scope_close(ptr %s11)
  br label %bb86
bb86:
  %t403 = load ptr, ptr %lp6
  %t404 = load { i64, ptr }, ptr %t403, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t406 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t404, 1
  store { i32, { i64, ptr } } %t406, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/generic:Desc"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %lp17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %lp24 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/generic:Desc"
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i1
  %l64 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i1
  %l83 = alloca i64
  %l90 = alloca ptr
  %l93 = alloca ptr
  %l96 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l103 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l112 = alloca i64
  %l116 = alloca { i64, ptr }
  %l119 = alloca %"compiler/diagmsg:Msg"
  %l120 = alloca i64
  %l124 = alloca ptr
  %l128 = alloca i1
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca i32
  %l134 = alloca ptr
  %l139 = alloca ptr
  %l144 = alloca i32
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l149 = alloca %"compiler/source:Span"
  %l150 = alloca i32
  %l151 = alloca ptr
  %l155 = alloca %"compiler/typed:Payload"
  %l163 = alloca i64
  %l166 = alloca i64
  %l184 = alloca { i64, ptr }
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca { i64, ptr }
  %l194 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca ptr
  %l198 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l205 = alloca ptr
  %l206 = alloca ptr
  %l216 = alloca ptr
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  %t232 = alloca { i64, [4 x i64] }, align 8
  %t288 = alloca { i64, [4 x i64] }, align 8
  %t369 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l27
  br label %bb1
bb1:
  %t6 = load i32, ptr %l27, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l29
  br label %bb2
bb2:
  %t10 = load %"compiler/source:Span", ptr %l29
  store %"compiler/source:Span" %t10, ptr %l5
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  store %"compiler/generic:Desc" %t15, ptr %l32
  br label %bb3
bb3:
  %t16 = load %"compiler/generic:Desc", ptr %l32
  store %"compiler/generic:Desc" %t16, ptr %l6
  %t17 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t22 = icmp eq i64 %t18, %t19
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l5
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 2
  %t28 = load i64, ptr %t27, !tbaa !24
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v2, ptr %v3, ptr %t24, %"compiler/source:Span" %t25, ptr %t26, i64 %t28)
  store ptr %t33, ptr %l40
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t34 = load ptr, ptr %l40, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t36 = load ptr, ptr %l41, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l41, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 28}
  %t42 = icmp eq i64 %t40, 0
  store i1 %t42, ptr %l42, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l42, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32 }, ptr %t46, i32 0, i32 0
  %t48 = load %"compiler/source:Span", ptr %t47
  store %"compiler/source:Span" %t48, ptr %l7
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32 }, ptr %t52, i32 0, i32 1
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l8, !tbaa !23
  br label %bb12
bb11:
  br label %bb19
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l8, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t56, i32 %t57)
  store { i64, ptr } %t60, ptr %l51
  br label %bb13
bb13:
  %t61 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t61, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t62, ptr %l52
  br label %bb14
bb14:
  %t63 = load i1, ptr %l52, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l7
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t64, %"compiler/source:Span" %t65, i32 %t66, i64 1)
  store ptr %t70, ptr %l56
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t71 = load ptr, ptr %l56, !tbaa !29
  store ptr %t71, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb81
bb19:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t73 = load ptr, ptr %l57, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb20, label %bb21
bb20:
  %t76 = load ptr, ptr %l57, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 28}
  %t79 = icmp eq i64 %t77, 12
  store i1 %t79, ptr %l58, !tbaa !21
  br label %bb21
bb21:
  %t80 = load i1, ptr %l58, !tbaa !21
  br i1 %t80, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb30
bb24:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t83 = load i32, ptr %l4, !tbaa !23
  %t87 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t81, ptr %t82, i32 %t83)
  store i64 %t87, ptr %l64
  br label %bb25
bb25:
  %t88 = load i64, ptr %l64, !tbaa !24
  store i64 %t88, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = icmp sge i64 %t89, 0
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l5
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t96 = load i64, ptr %l9, !tbaa !24
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v2, ptr %v3, ptr %t93, %"compiler/source:Span" %t94, ptr %t95, i64 %t96)
  store ptr %t101, ptr %l71
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t102 = load ptr, ptr %l71, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
bb29:
  br label %bb81
bb30:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t104 = load ptr, ptr %l72, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb31, label %bb32
bb31:
  %t107 = load ptr, ptr %l72, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 28}
  %t110 = icmp eq i64 %t108, 10
  store i1 %t110, ptr %l73, !tbaa !21
  br label %bb32
bb32:
  %t111 = load i1, ptr %l73, !tbaa !21
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l10, !tbaa !29
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t120, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l11, !tbaa !27
  br label %bb35
bb34:
  br label %bb76
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l10, !tbaa !29
  %t126 = load i32, ptr %l4, !tbaa !23
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t124, ptr %t125, i32 %t126)
  store i64 %t130, ptr %l83
  br label %bb36
bb36:
  %t131 = load i64, ptr %l83, !tbaa !24
  store i64 %t131, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l12, !tbaa !24
  %t134 = icmp sge i64 %t132, 0
  br i1 %t134, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l5
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load i64, ptr %l12, !tbaa !24
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v2, ptr %v3, ptr %t136, %"compiler/source:Span" %t137, ptr %t138, i64 %t139)
  store ptr %t144, ptr %l90
  br label %bb39
bb38:
  br label %bb75
bb39:
  %t145 = load ptr, ptr %l90, !tbaa !29
  store ptr %t145, ptr %l13, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  store ptr %t151, ptr %l93, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  store ptr %t157, ptr %l96, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load i32, ptr %l4, !tbaa !23
  %t163 = load i64, ptr %l12, !tbaa !24
  %t167 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t161, i32 %t162, i64 %t163)
  store i32 %t167, ptr %l101
  br label %bb40
bb40:
  %t168 = load ptr, ptr %l96, !tbaa !29
  %t169 = load i32, ptr %l101, !tbaa !23
  %t170 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t168, i32 %t169)
  store i32 %t170, ptr %l102
  br label %bb41
bb41:
  %t171 = load ptr, ptr %l93, !tbaa !29
  %t172 = load i32, ptr %l102, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t171, i32 %t172)
  store { i64, ptr } %t173, ptr %l103
  br label %bb42
bb42:
  %t174 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t174, ptr %l14, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp ne i64 %t177, %t180
  br i1 %t183, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l109, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t186, ptr %l110
  %t187 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l112, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t194 = icmp eq i64 %t192, 1
  br i1 %t194, label %bb45, label %bb46
bb44:
  br label %bb51
bb45:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l116, !tbaa !27
  br label %bb47
bb46:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l116, !tbaa !27
  br label %bb47
bb47:
  %t196 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = load i64, ptr %l112, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t202 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s8, ptr %v0, i64 %t199, { i64, ptr } %t200, i64 %t198)
  store %"compiler/diagmsg:Msg" %t202, ptr %l119
  br label %bb48
bb48:
  %t203 = load ptr, ptr %l109, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l110
  %t205 = load %"compiler/diagmsg:Msg", ptr %l119
  %t206 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t203, %"compiler/source:Span" %t204, %"compiler/diagmsg:Msg" %t205)
  store i64 %t206, ptr %l120
  br label %bb49
bb49:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l5
  %t209 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t207, %"compiler/source:Span" %t208, i32 %t209, i64 0)
  store ptr %t213, ptr %l124
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  %t214 = load ptr, ptr %l124, !tbaa !29
  store ptr %t214, ptr %rv
  br label %ret
bb51:
  %t215 = load ptr, ptr %l2, !tbaa !29
  store ptr %t215, ptr %l15, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l3, !tbaa !23
  %t221 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t217, i32 %t218)
  store i1 %t221, ptr %l128
  br label %bb52
bb52:
  %t222 = load i1, ptr %l128, !tbaa !21
  br i1 %t222, label %bb53, label %bb54
bb53:
  %t223 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t223, ptr %l129
  %t224 = load i32, ptr %l4, !tbaa !23
  store i32 %t224, ptr %l130, !tbaa !23
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l5
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v3, ptr %t225, %"compiler/source:Span" %t226, ptr %t227)
  store ptr %t231, ptr %l134
  br label %bb55
bb54:
  br label %bb56
bb55:
  store { i64, [4 x i64] } zeroinitializer, ptr %t232
  %t233 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 0
  store i64 2, ptr %t233
  %t234 = load %"compiler/source:Span", ptr %l129
  %t235 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t234, 0
  %t236 = load i32, ptr %l130, !tbaa !23
  %t237 = insertvalue { %"compiler/source:Span", i32, ptr } %t235, i32 %t236, 1
  %t238 = load ptr, ptr %l134, !tbaa !29
  %t239 = insertvalue { %"compiler/source:Span", i32, ptr } %t237, ptr %t238, 2
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t239, ptr %t240
  %t241 = load { i64, [4 x i64] }, ptr %t232
  %t243 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t241, ptr %t243
  store ptr %t243, ptr %l15, !tbaa !29
  br label %bb56
bb56:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = getelementptr %"compiler/generic:Program", ptr %t248, i32 0, i32 2
  store ptr %t250, ptr %l139, !tbaa !29
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/check:Checker", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = getelementptr %"compiler/generic:Program", ptr %t254, i32 0, i32 2
  %t257 = load i32, ptr %l4, !tbaa !23
  %t260 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t256, i32 %t257)
  store i32 %t260, ptr %l144
  br label %bb57
bb57:
  %t261 = load ptr, ptr %l139, !tbaa !29
  %t262 = load i32, ptr %l144, !tbaa !23
  %t263 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s7, ptr %t261, i32 %t262)
  store { i64, ptr } %t263, ptr %l145
  br label %bb58
bb58:
  %t264 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t264, ptr %l146, !tbaa !27
  %t265 = load i64, ptr %l12, !tbaa !24
  %t267 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr i32, ptr %t268, i64 %t265
  %t270 = load i32, ptr %t269, !tbaa !33
  %t272 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t272, ptr %l149
  store i32 %t270, ptr %l150, !tbaa !23
  %t274 = load ptr, ptr %l15, !tbaa !29
  store ptr %t274, ptr %l151, !tbaa !29
  %t275 = load i64, ptr %l12, !tbaa !24
  %t276 = load ptr, ptr %l151, !tbaa !29
  %t277 = call ptr @__olang_scope_of(ptr %t276, ptr null)
  %t278 = call ptr @__olang_scope_hold(ptr %t277)
  %t279 = ptrtoint ptr %t278 to i64
  %t281 = inttoptr i64 %t279 to ptr
  %t282 = load ptr, ptr %l151, !tbaa !29
  %t285 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %t281, ptr %v3, ptr %t282, i64 %t275, i32 0)
  store %"compiler/typed:Payload" %t285, ptr %l155
  br label %bb59
bb59:
  %t286 = load %"compiler/typed:Payload", ptr %l155
  %t287 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Payload" %t286, ptr %t287
  store { i64, [4 x i64] } zeroinitializer, ptr %t288
  %t289 = getelementptr { i64, [4 x i64] }, ptr %t288, i32 0, i32 0
  store i64 5, ptr %t289
  %t290 = load %"compiler/source:Span", ptr %l149
  %t291 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t290, 0
  %t292 = load i32, ptr %l150, !tbaa !23
  %t293 = insertvalue { %"compiler/source:Span", i32, ptr } %t291, i32 %t292, 1
  %t295 = insertvalue { %"compiler/source:Span", i32, ptr } %t293, ptr %t287, 2
  %t296 = getelementptr { i64, [4 x i64] }, ptr %t288, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t295, ptr %t296
  %t297 = load { i64, [4 x i64] }, ptr %t288
  %t298 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t298, ptr %lp17
  %t300 = load ptr, ptr %lp17
  store { i64, [4 x i64] } %t297, ptr %t300
  store i64 0, ptr %l18, !tbaa !24
  %t301 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t301, 0
  store i64 %t303, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t305 = load i64, ptr %l19, !tbaa !24
  %t306 = load i64, ptr %l18, !tbaa !24
  %t309 = icmp sgt i64 %t305, %t306
  br i1 %t309, label %bb60, label %bb61
bb60:
  %t311 = load i64, ptr %l20, !tbaa !24
  %t313 = icmp sgt i64 %t311, 0
  br i1 %t313, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb65
bb62:
  %t315 = load i64, ptr %l19, !tbaa !24
  %t316 = load i64, ptr %l18, !tbaa !24
  %t319 = sub i64 %t315, %t316
  %t320 = load i64, ptr %l20, !tbaa !24
  %t323 = add i64 %t319, %t320
  %t325 = sub i64 %t323, 1
  %t326 = load i64, ptr %l20, !tbaa !24
  %t329 = sdiv i64 %t325, %t326
  store i64 %t329, ptr %l166, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb64
bb64:
  %t331 = load i64, ptr %l166, !tbaa !24
  store i64 %t331, ptr %l163, !tbaa !24
  br label %bb65
bb65:
  %t332 = load i64, ptr %l163, !tbaa !24
  store i64 %t332, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb66
bb66:
  %t333 = load i64, ptr %l22, !tbaa !24
  %t334 = load i64, ptr %l21, !tbaa !24
  %t337 = icmp slt i64 %t333, %t334
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb67, label %bb68
bb67:
  br label %bb74
bb68:
  br label %bb69
bb69:
  %t341 = load i64, ptr %l18, !tbaa !24
  %t342 = load i64, ptr %l22, !tbaa !24
  %t343 = load i64, ptr %l20, !tbaa !24
  %t346 = mul i64 %t342, %t343
  %t349 = add i64 %t341, %t346
  store i64 %t349, ptr %l23, !tbaa !24
  %t351 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t351, ptr %l184, !tbaa !27
  %t352 = load i64, ptr %l23, !tbaa !24
  %t354 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr ptr, ptr %t355, i64 %t352
  %t357 = load ptr, ptr %t356, !tbaa !39
  %t359 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t357)
  store %"compiler/source:Span" %t359, ptr %l187
  br label %bb70
bb70:
  %t360 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t360, ptr %l188, !tbaa !27
  %t361 = load i64, ptr %l23, !tbaa !24
  %t363 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr i32, ptr %t364, i64 %t361
  %t366 = load i32, ptr %t365, !tbaa !33
  %t367 = load ptr, ptr %lp17
  %t368 = load i64, ptr %l23, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t369
  %t370 = getelementptr { i64, [4 x i64] }, ptr %t369, i32 0, i32 0
  store i64 3, ptr %t370
  %t371 = load %"compiler/source:Span", ptr %l187
  %t372 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t371, 0
  %t374 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t372, i32 %t366, 1
  %t376 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t374, ptr %t367, 2
  %t378 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t376, i64 %t368, 3
  %t379 = getelementptr { i64, [4 x i64] }, ptr %t369, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t378, ptr %t379
  %t380 = load { i64, [4 x i64] }, ptr %t369
  %t381 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t381, ptr %lp24
  %t383 = load ptr, ptr %lp24
  store { i64, [4 x i64] } %t380, ptr %t383
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l194, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t385, ptr %l195
  %t386 = load ptr, ptr %l13, !tbaa !29
  store ptr %t386, ptr %l196, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t388, ptr %l198, !tbaa !27
  %t389 = load i64, ptr %l23, !tbaa !24
  %t391 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !27
  %t393 = getelementptr ptr, ptr %t392, i64 %t389
  %t394 = load ptr, ptr %t393, !tbaa !39
  %t395 = load ptr, ptr %lp24
  %t396 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t396, ptr %l202, !tbaa !27
  %t397 = load i64, ptr %l23, !tbaa !24
  %t399 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !27
  %t401 = getelementptr i32, ptr %t400, i64 %t397
  %t402 = load i32, ptr %t401, !tbaa !33
  %t407 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t387, ptr %t394, ptr %t395, i32 %t402)
  store ptr %t407, ptr %l205
  br label %bb71
bb71:
  %t408 = load ptr, ptr %l194, !tbaa !29
  %t409 = load %"compiler/source:Span", ptr %l195
  %t410 = load ptr, ptr %l196, !tbaa !29
  %t411 = load ptr, ptr %l205, !tbaa !29
  %t412 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t408, %"compiler/source:Span" %t409, ptr %t410, ptr %t411)
  store ptr %t412, ptr %l206
  br label %bb72
bb72:
  %t413 = load ptr, ptr %l206, !tbaa !29
  store ptr %t413, ptr %l13, !tbaa !29
  br label %bb73
bb73:
  %t414 = load i64, ptr %l22, !tbaa !24
  %t417 = add i64 %t414, 1
  store i64 %t417, ptr %l22, !tbaa !24
  br label %bb66
bb74:
  %t419 = load ptr, ptr %l13, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  store ptr %t419, ptr %rv
  br label %ret
bb75:
  br label %bb81
bb76:
  br i1 true, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_82b73da87554a50f_4f07d83e7e807a5b)
  unreachable
bb81:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load %"compiler/source:Span", ptr %l5
  %t423 = load ptr, ptr %l2, !tbaa !29
  %t424 = load ptr, ptr %l1, !tbaa !29
  %t425 = load i32, ptr %l3, !tbaa !23
  %t431 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %t421, %"compiler/source:Span" %t422, ptr %t423, ptr %t424, i32 %t425)
  store ptr %t431, ptr %l216
  br label %bb82
bb82:
  %t432 = load ptr, ptr %l216, !tbaa !29
  store ptr %t432, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseZero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i1
  %l57 = alloca { i64, ptr }
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca i32
  %l65 = alloca %"compiler/typed:Make"
  %rv = alloca ptr
  %t107 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l16, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %a3)
  store i32 %t16, ptr %l21
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = load i32, ptr %l21, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 47
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l25
  br label %bb3
bb3:
  %t26 = load i64, ptr %l25, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  store i1 true, ptr %l6, !tbaa !21
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb5, label %bb6
bb5:
  br label %bb25
bb6:
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t41, ptr %l33, !tbaa !27
  %t42 = load i64, ptr %l8, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 %t42
  %t47 = load i32, ptr %t46, !tbaa !33
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t49, %"compiler/source:Span" %t50, i32 %t47)
  store ptr %t55, ptr %l39
  br label %bb8
bb8:
  %t56 = load ptr, ptr %l39, !tbaa !29
  store ptr %t56, ptr %l11, !tbaa !29
  %t57 = load ptr, ptr %l11, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t58 = load ptr, ptr %l40, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb9, label %bb10
bb9:
  %t61 = load ptr, ptr %l40, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 18}
  %t64 = icmp eq i64 %t62, 0
  store i1 %t64, ptr %l41, !tbaa !21
  br label %bb10
bb10:
  %t65 = load i1, ptr %l41, !tbaa !21
  br i1 %t65, label %bb11, label %bb12
bb11:
  %t66 = load ptr, ptr %l11, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t68, i32 0, i32 2
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l12, !tbaa !24
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t72 = load i64, ptr %l12, !tbaa !24
  %t74 = icmp ne i64 %t72, 0
  br i1 %t74, label %bb14, label %bb15
bb14:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ea1bc73a77e68519_ca6969815981751d)
  unreachable
bb22:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 47
  %t79 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t78, ptr %t79)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb4
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 47
  %t90 = load i64, ptr %l5, !tbaa !24
  %t93 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t89, i64 %t90)
  store { i64, ptr } %t93, ptr %l57
  br label %bb26
bb26:
  %t94 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t94, ptr %l13, !tbaa !27
  %t95 = load i1, ptr %l6, !tbaa !21
  br i1 %t95, label %bb27, label %bb28
bb27:
  store ptr null, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t98 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t98, ptr %l60
  store i32 %a2, ptr %l61, !tbaa !23
  %t100 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t104 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v1, ptr %v1, ptr %v1, i32 1, i64 0, { i64, ptr } %t100, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t104, ptr %l65
  br label %bb30
bb30:
  %t105 = load %"compiler/typed:Make", ptr %l65
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/typed:Make" %t105, ptr %t106
  store { i64, [5 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 0
  store i64 7, ptr %t108
  %t109 = load %"compiler/source:Span", ptr %l60
  %t110 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t109, 0
  %t111 = load i32, ptr %l61, !tbaa !23
  %t112 = insertvalue { %"compiler/source:Span", i32, ptr } %t110, i32 %t111, 1
  %t114 = insertvalue { %"compiler/source:Span", i32, ptr } %t112, ptr %t106, 2
  %t115 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t114, ptr %t115
  %t116 = load { i64, [5 x i64] }, ptr %t107
  %t118 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t116, ptr %t118
  store ptr %t118, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, ptr }
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca %"compiler/check:litv"
  %l59 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca %"compiler/check:litv"
  %l89 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca i32
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l13, !tbaa !27
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l6, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Chain", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = add i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Chain", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l22, !tbaa !27
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 116}
  store i32 %t34, ptr %l8
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb1, label %bb2
bb1:
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb3
bb3:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb4, label %bb5
bb4:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  %t47 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v1, ptr %v4, ptr %t45, %"compiler/source:Span" %t46, i32 %t47, ptr %t48, ptr %t49, i32 %t50)
  store ptr %t57, ptr %l36
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load ptr, ptr %l36, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb7:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l37, !tbaa !29
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t60)
  store %"compiler/source:Span" %t62, ptr %l39
  br label %bb8
bb8:
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l41
  br label %bb9
bb9:
  %t66 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t68 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t66)
  store { i64, ptr } %t68, ptr %l43
  br label %bb10
bb10:
  %t69 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l39
  %t73 = load %"compiler/source:Span", ptr %l41
  %t75 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t71, %"compiler/source:Span" %t72, %"compiler/source:Span" %t73, i64 %t70)
  store %"compiler/source:Span" %t75, ptr %l45
  br label %bb11
bb11:
  %t76 = load %"compiler/source:Span", ptr %l45
  store %"compiler/source:Span" %t76, ptr %l9
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb12, label %bb13
bb12:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l48, !tbaa !29
  %t82 = load ptr, ptr %l6, !tbaa !29
  store ptr %t82, ptr %l49, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t88 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  store %"compiler/check:litv" %t88, ptr %l53
  br label %bb14
bb13:
  br label %bb29
bb14:
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_854899d5724a103b_e7dfb19072d83fa7)
  unreachable
bb16:
  br label %bb17
bb17:
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t94 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t95 = load %"compiler/source:Span", ptr %l9
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = load %"compiler/check:litv", ptr %l53
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t96, ptr %t97, %"compiler/check:litv" %t98, ptr %t93, i32 %t94, %"compiler/source:Span" %t95, i1 false)
  store ptr %t102, ptr %l59
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l59, !tbaa !29
  store ptr %t103, ptr %l10, !tbaa !29
  %t104 = load ptr, ptr %l10, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb19, label %bb20
bb19:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t108, %"compiler/source:Span" %t109)
  store ptr %t112, ptr %l64
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load ptr, ptr %l64, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb22:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l65, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t115, ptr %l66
  %t116 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t116, ptr %l67
  %t117 = load i32, ptr %l8, !range !{i32 0, i32 116}
  store i32 %t117, ptr %l68
  %t118 = load ptr, ptr %l10, !tbaa !29
  store ptr %t118, ptr %l69, !tbaa !29
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  br i1 %t121, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_852b58c2eb82b3cc_e47a0c64d3951188)
  unreachable
bb24:
  br label %bb25
bb25:
  %t123 = load ptr, ptr %l5, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t124)
  store %"compiler/source:Span" %t126, ptr %l74
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t129 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t127)
  store %"compiler/source:Span" %t129, ptr %l76
  br label %bb27
bb27:
  %t130 = load ptr, ptr %l65, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l66
  %t132 = load %"compiler/source:Span", ptr %l67
  %t133 = load i32, ptr %l68, !range !{i32 0, i32 116}
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = load ptr, ptr %l72, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l74
  %t137 = load %"compiler/source:Span", ptr %l76
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v4, ptr %v3, ptr %v4, ptr %t130, %"compiler/source:Span" %t131, %"compiler/source:Span" %t132, i32 %t133, ptr %t134, ptr %t135, %"compiler/source:Span" %t136, %"compiler/source:Span" %t137)
  store ptr %t138, ptr %l77
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t139 = load ptr, ptr %l77, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb29:
  %t140 = load ptr, ptr %l5, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb30, label %bb31
bb30:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l80, !tbaa !29
  %t145 = load ptr, ptr %l7, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l7, !tbaa !29
  %t151 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t146, ptr %t147)
  store %"compiler/check:litv" %t151, ptr %l85
  br label %bb32
bb31:
  br label %bb41
bb32:
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t153 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t154 = load %"compiler/source:Span", ptr %l9
  %t155 = load ptr, ptr %l80, !tbaa !29
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load %"compiler/check:litv", ptr %l85
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t155, ptr %t156, %"compiler/check:litv" %t157, ptr %t152, i32 %t153, %"compiler/source:Span" %t154, i1 true)
  store ptr %t161, ptr %l89
  br label %bb33
bb33:
  %t162 = load ptr, ptr %l89, !tbaa !29
  store ptr %t162, ptr %l11, !tbaa !29
  %t163 = load ptr, ptr %l11, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  br i1 %t165, label %bb34, label %bb35
bb34:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t167, %"compiler/source:Span" %t168)
  store ptr %t171, ptr %l94
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t172 = load ptr, ptr %l94, !tbaa !29
  store ptr %t172, ptr %rv
  br label %ret
bb37:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l95, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t174, ptr %l96
  %t175 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t175, ptr %l97
  %t176 = load i32, ptr %l8, !range !{i32 0, i32 116}
  store i32 %t176, ptr %l98
  %t177 = load ptr, ptr %l4, !tbaa !29
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load ptr, ptr %l11, !tbaa !29
  store ptr %t178, ptr %l100, !tbaa !29
  %t179 = load ptr, ptr %l6, !tbaa !29
  %t181 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t179)
  store %"compiler/source:Span" %t181, ptr %l102
  br label %bb38
bb38:
  %t182 = load ptr, ptr %l7, !tbaa !29
  %t184 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t182)
  store %"compiler/source:Span" %t184, ptr %l104
  br label %bb39
bb39:
  %t185 = load ptr, ptr %l95, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l96
  %t187 = load %"compiler/source:Span", ptr %l97
  %t188 = load i32, ptr %l98, !range !{i32 0, i32 116}
  %t189 = load ptr, ptr %l99, !tbaa !29
  %t190 = load ptr, ptr %l100, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l102
  %t192 = load %"compiler/source:Span", ptr %l104
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v2, ptr %v4, ptr %v4, ptr %t185, %"compiler/source:Span" %t186, %"compiler/source:Span" %t187, i32 %t188, ptr %t189, ptr %t190, %"compiler/source:Span" %t191, %"compiler/source:Span" %t192)
  store ptr %t193, ptr %l105
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t194 = load ptr, ptr %l105, !tbaa !29
  store ptr %t194, ptr %rv
  br label %ret
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l106, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t196, ptr %l107
  %t197 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t197, ptr %l108
  %t198 = load i32, ptr %l8, !range !{i32 0, i32 116}
  store i32 %t198, ptr %l109
  %t199 = load ptr, ptr %l4, !tbaa !29
  store ptr %t199, ptr %l110, !tbaa !29
  %t200 = load ptr, ptr %l5, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t203 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t201)
  store %"compiler/source:Span" %t203, ptr %l113
  br label %bb42
bb42:
  %t204 = load ptr, ptr %l7, !tbaa !29
  %t206 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t204)
  store %"compiler/source:Span" %t206, ptr %l115
  br label %bb43
bb43:
  %t207 = load ptr, ptr %l106, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l107
  %t209 = load %"compiler/source:Span", ptr %l108
  %t210 = load i32, ptr %l109, !range !{i32 0, i32 116}
  %t211 = load ptr, ptr %l110, !tbaa !29
  %t212 = load ptr, ptr %l111, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l113
  %t214 = load %"compiler/source:Span", ptr %l115
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t207, %"compiler/source:Span" %t208, %"compiler/source:Span" %t209, i32 %t210, ptr %t211, ptr %t212, %"compiler/source:Span" %t213, %"compiler/source:Span" %t214)
  store ptr %t215, ptr %l116
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t216 = load ptr, ptr %l116, !tbaa !29
  store ptr %t216, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %lp12 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca i32
  %l51 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca %"compiler/typed:Cond"
  %l75 = alloca ptr
  %l77 = alloca i32
  %l81 = alloca i64
  %l84 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l90 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca ptr
  %l103 = alloca i64
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca i32
  %l116 = alloca { i64, ptr }
  %l119 = alloca %"compiler/typed:Seq"
  %l122 = alloca ptr
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %l128 = alloca i64
  %l132 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca i32
  %l137 = alloca ptr
  %l139 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca %"compiler/typed:Cond"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t106 = alloca { i64, [5 x i64] }, align 8
  %t171 = alloca { i64, [3 x i64] }, align 8
  %t222 = alloca { i64, [5 x i64] }, align 8
  %t278 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i64 %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = load i64, ptr %l5, !tbaa !24
  %t10 = add i64 %t8, 2
  %t14 = icmp sge i64 %t10, %t6
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l21, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t17, ptr %l22
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l23, !tbaa !29
  %t19 = load i64, ptr %l5, !tbaa !24
  store i64 %t19, ptr %l24, !tbaa !24
  %t20 = load ptr, ptr %l6, !tbaa !29
  store ptr %t20, ptr %l25, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l26, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i1, ptr %t27, i64 %t24
  %t29 = load i1, ptr %t28, !tbaa !31
  br i1 %t29, label %bb3, label %bb4
bb2:
  br label %bb8
bb3:
  store ptr null, ptr %l30, !tbaa !29
  br label %bb6
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 47
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = add i64 %t38, 1
  %t43 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t33, i64 %t40)
  store ptr %t43, ptr %l37
  br label %bb5
bb5:
  %t44 = load ptr, ptr %l37, !tbaa !29
  store ptr %t44, ptr %l30, !tbaa !29
  br label %bb6
bb6:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l22
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load i64, ptr %l24, !tbaa !24
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %v4, ptr %t46, %"compiler/source:Span" %t47, ptr %t48, i64 %t49, ptr %t50, ptr %t51)
  store ptr %t52, ptr %l39
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load ptr, ptr %l39, !tbaa !29
  store ptr %t53, ptr %rv
  br label %ret
bb8:
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t54, ptr %l40, !tbaa !27
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t55, 1
  %t59 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i1, ptr %t60, i64 %t57
  %t62 = load i1, ptr %t61, !tbaa !31
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t64, ptr %l44
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t65, ptr %l45, !tbaa !23
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = load ptr, ptr %l6, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %v0, ptr %t66, %"compiler/source:Span" %t67, ptr %t68, i64 %t69, ptr %t70, ptr null)
  store ptr %t76, ptr %l51
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = load i64, ptr %l5, !tbaa !24
  %t84 = add i64 %t82, 1
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %v4, ptr %t77, %"compiler/source:Span" %t78, ptr %t79, i64 %t80, { i64, ptr } %t81, i64 %t84, ptr null)
  store ptr %t91, ptr %l59
  br label %bb12
bb12:
  %t92 = load ptr, ptr %l59, !tbaa !29
  store ptr %t92, ptr %l60, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t93, %"compiler/source:Span" %t94, i32 %t95, i64 0)
  store ptr %t99, ptr %l64
  br label %bb13
bb13:
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = load ptr, ptr %l60, !tbaa !29
  %t102 = load ptr, ptr %l64, !tbaa !29
  %t103 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v4, ptr %v4, ptr %v4, ptr %t100, ptr %t101, ptr %t102)
  store %"compiler/typed:Cond" %t103, ptr %l65
  br label %bb14
bb14:
  %t104 = load %"compiler/typed:Cond", ptr %l65
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 24, i64 8)
  store %"compiler/typed:Cond" %t104, ptr %t105
  store { i64, [5 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 0
  store i64 11, ptr %t107
  %t108 = load %"compiler/source:Span", ptr %l44
  %t109 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t108, 0
  %t110 = load i32, ptr %l45, !tbaa !23
  %t111 = insertvalue { %"compiler/source:Span", i32, ptr } %t109, i32 %t110, 1
  %t113 = insertvalue { %"compiler/source:Span", i32, ptr } %t111, ptr %t105, 2
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t113, ptr %t114
  %t115 = load { i64, [5 x i64] }, ptr %t106
  %t117 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t115, ptr %t117
  call void @__olang_scope_close(ptr %s0)
  store ptr %t117, ptr %rv
  br label %ret
bb15:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 47
  %t122 = load i64, ptr %l3, !tbaa !24
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = add i64 %t126, 1
  %t131 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s0, ptr %t121, i64 %t128)
  store ptr %t131, ptr %l75
  br label %bb16
bb16:
  %t132 = load ptr, ptr %l75, !tbaa !29
  %t134 = call i32 @compiler_2fcheck_2etypeOf(ptr %s0, ptr %t132)
  store i32 %t134, ptr %l77
  br label %bb17
bb17:
  %t135 = load i32, ptr %l77, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  %t142 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t136, %"compiler/source:Span" %t137, i32 %t135)
  store i64 %t142, ptr %l81
  br label %bb18
bb18:
  %t143 = load i64, ptr %l81, !tbaa !24
  store i64 %t143, ptr %l9, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 48
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l84
  br label %bb19
bb19:
  %t149 = load i64, ptr %l84, !tbaa !24
  store i64 %t149, ptr %l10, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 48
  store ptr %t152, ptr %l86, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l87
  %t154 = load i64, ptr %l9, !tbaa !24
  %t156 = trunc i64 %t154 to i32
  store i32 %t156, ptr %l90, !tbaa !23
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 47
  %t161 = load i64, ptr %l3, !tbaa !24
  %t162 = load i64, ptr %l5, !tbaa !24
  %t165 = add i64 %t161, %t162
  %t167 = add i64 %t165, 1
  %t170 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t160, i64 %t167)
  store ptr %t170, ptr %l97
  br label %bb20
bb20:
  store { i64, [3 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 0
  store i64 0, ptr %t172
  %t173 = load %"compiler/source:Span", ptr %l87
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t173, 0
  %t175 = load i32, ptr %l90, !tbaa !23
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } %t174, i32 %t175, 1
  %t177 = load ptr, ptr %l97, !tbaa !29
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, ptr %t177, 2
  %t179 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t178, ptr %t179
  %t180 = load { i64, [3 x i64] }, ptr %t171
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t180, ptr %t182
  %t183 = load ptr, ptr %l86, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t183, ptr %t182)
  br label %bb21
bb21:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l100, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t186, ptr %l101
  %t187 = load ptr, ptr %l2, !tbaa !29
  store ptr %t187, ptr %l102, !tbaa !29
  %t188 = load i64, ptr %l5, !tbaa !24
  store i64 %t188, ptr %l103, !tbaa !24
  %t189 = load ptr, ptr %l6, !tbaa !29
  store ptr %t189, ptr %l104, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t192 = load i64, ptr %l9, !tbaa !24
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t190, %"compiler/source:Span" %t191, i64 %t192)
  store ptr %t196, ptr %l108
  br label %bb22
bb22:
  %t197 = load ptr, ptr %l108, !tbaa !29
  %t198 = load ptr, ptr %l100, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l101
  %t200 = load ptr, ptr %l102, !tbaa !29
  %t201 = load i64, ptr %l103, !tbaa !24
  %t202 = load ptr, ptr %l104, !tbaa !29
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %v4, ptr %t198, %"compiler/source:Span" %t199, ptr %t200, i64 %t201, ptr %t202, ptr %t197)
  store ptr %t204, ptr %l110
  br label %bb23
bb23:
  %t205 = load ptr, ptr %l110, !tbaa !29
  store ptr %t205, ptr %l11, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t206, ptr %l111
  %t207 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t207, ptr %l112, !tbaa !23
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 48
  %t211 = load i64, ptr %l10, !tbaa !24
  %t214 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t210, i64 %t211)
  store { i64, ptr } %t214, ptr %l116
  br label %bb24
bb24:
  %t215 = load ptr, ptr %l11, !tbaa !29
  %t217 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t219 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v4, ptr %v4, { i64, ptr } %t217, ptr %t215, i1 false)
  store %"compiler/typed:Seq" %t219, ptr %l119
  br label %bb25
bb25:
  %t220 = load %"compiler/typed:Seq", ptr %l119
  %t221 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"compiler/typed:Seq" %t220, ptr %t221
  store { i64, [5 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 0
  store i64 12, ptr %t223
  %t224 = load %"compiler/source:Span", ptr %l111
  %t225 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t224, 0
  %t226 = load i32, ptr %l112, !tbaa !23
  %t227 = insertvalue { %"compiler/source:Span", i32, ptr } %t225, i32 %t226, 1
  %t229 = insertvalue { %"compiler/source:Span", i32, ptr } %t227, ptr %t221, 2
  %t230 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t229, ptr %t230
  %t231 = load { i64, [5 x i64] }, ptr %t222
  %t232 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store ptr %t232, ptr %lp12
  %t234 = load ptr, ptr %lp12
  store { i64, [5 x i64] } %t231, ptr %t234
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l122, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t236, ptr %l123
  %t237 = load ptr, ptr %l2, !tbaa !29
  store ptr %t237, ptr %l124, !tbaa !29
  %t238 = load i64, ptr %l3, !tbaa !24
  store i64 %t238, ptr %l125, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t239, ptr %l126, !tbaa !27
  %t240 = load i64, ptr %l5, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l128, !tbaa !24
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l1
  %t245 = load i64, ptr %l9, !tbaa !24
  %t249 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t243, %"compiler/source:Span" %t244, i64 %t245)
  store ptr %t249, ptr %l132
  br label %bb26
bb26:
  %t250 = load ptr, ptr %l132, !tbaa !29
  %t251 = load ptr, ptr %l122, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l123
  %t253 = load ptr, ptr %l124, !tbaa !29
  %t254 = load i64, ptr %l125, !tbaa !24
  %t255 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t256 = load i64, ptr %l128, !tbaa !24
  %t258 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %v4, ptr %t251, %"compiler/source:Span" %t252, ptr %t253, i64 %t254, { i64, ptr } %t255, i64 %t256, ptr %t250)
  store ptr %t258, ptr %l134
  br label %bb27
bb27:
  %t259 = load ptr, ptr %l134, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t260, ptr %l135
  %t261 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t261, ptr %l136, !tbaa !23
  %t262 = load ptr, ptr %lp12
  store ptr %t262, ptr %l137, !tbaa !29
  store ptr %t259, ptr %l139, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  %t267 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t271 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t265, %"compiler/source:Span" %t266, i32 %t267, i64 0)
  store ptr %t271, ptr %l143
  br label %bb28
bb28:
  %t272 = load ptr, ptr %l137, !tbaa !29
  %t273 = load ptr, ptr %l139, !tbaa !29
  %t274 = load ptr, ptr %l143, !tbaa !29
  %t275 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %t272, ptr %t273, ptr %t274)
  store %"compiler/typed:Cond" %t275, ptr %l144
  br label %bb29
bb29:
  %t276 = load %"compiler/typed:Cond", ptr %l144
  %t277 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 24, i64 8)
  store %"compiler/typed:Cond" %t276, ptr %t277
  store { i64, [5 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 0
  store i64 11, ptr %t279
  %t280 = load %"compiler/source:Span", ptr %l135
  %t281 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t280, 0
  %t282 = load i32, ptr %l136, !tbaa !23
  %t283 = insertvalue { %"compiler/source:Span", i32, ptr } %t281, i32 %t282, 1
  %t285 = insertvalue { %"compiler/source:Span", i32, ptr } %t283, ptr %t277, 2
  %t286 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t285, ptr %t286
  %t287 = load { i64, [5 x i64] }, ptr %t278
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t287, ptr %t289
  call void @__olang_scope_close(ptr %s0)
  store ptr %t289, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnsFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %lp17 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca i32
  %l24 = alloca ptr
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i1
  %l51 = alloca i32
  %l54 = alloca i32
  %l57 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca %"compiler/typed:Local"
  %l64 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l88 = alloca i64
  %l91 = alloca i64
  %l95 = alloca i64
  %l98 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca %"compiler/source:Span"
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca { i64, ptr }
  %l121 = alloca i32
  %l122 = alloca %"compiler/source:Span"
  %l125 = alloca i32
  %l134 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l139 = alloca i1
  %l146 = alloca i1
  %l147 = alloca %"compiler/source:Span"
  %l148 = alloca { i64, ptr }
  %l150 = alloca i32
  %l151 = alloca i32
  %l154 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l159 = alloca ptr
  %l163 = alloca i32
  %l165 = alloca %"compiler/typed:Make"
  %l172 = alloca { i64, ptr }
  %l177 = alloca i64
  %l187 = alloca ptr
  %s0 = alloca %olang.scope
  %t239 = alloca { i64, [4 x i64] }, align 8
  %t252 = alloca { i64, [4 x i64] }, align 8
  %t330 = alloca { i64, [5 x i64] }, align 8
  %t358 = alloca { i64, [1 x i64] }, align 8
  %t376 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l22
  br label %bb1
bb1:
  %t9 = load i32, ptr %l22, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l24
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l24, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 5
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l27
  %t18 = call ptr @__olang_scope_hold(ptr %s0)
  %t19 = ptrtoint ptr %t18 to i64
  store i64 %t19, ptr %l28, !tbaa !24
  %t20 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2e0
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = call ptr @__olang_region_make_part(ptr %s0)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l28, !tbaa !24
  br label %bb4
bb4:
  %t24 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l30, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l31, !tbaa !24
  %t28 = load i64, ptr %l31, !tbaa !24
  %t29 = mul i64 %t28, 4
  %t30 = load i64, ptr %l28
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call ptr @__olang_held_alloc(ptr %t31, i64 %t29)
  %t33 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l32, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l31, !tbaa !24
  %t40 = mul i64 %t39, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t42, !tbaa !27
  %t43 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2e0
  br i1 %t43, label %bb5, label %bb6
bb5:
  %t45 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  %t49 = icmp eq i64 %t47, 0
  br i1 %t49, label %bb7, label %bb8
bb6:
  %t51 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l3
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t53, ptr %l37
  br label %bb9
bb7:
  %t54 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t54, !tbaa !27
  br label %bb8
bb8:
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27, i32 0, i32 0
  %t56 = load i64, ptr %l28
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = load { i64, ptr }, ptr %t55
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = call ptr @__olang_region_or(ptr %t59, ptr null)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr null
  call void @__olang_region_settle_in(ptr %t57, ptr %t62)
  br label %bb6
bb9:
  %t63 = load i64, ptr %l37, !tbaa !24
  %t64 = icmp slt i64 %t63, 2
  br i1 %t64, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb13
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l2, !tbaa !23
  %t70 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t66, i32 %t67)
  store i1 %t70, ptr %l42
  br label %bb12
bb12:
  %t71 = load i1, ptr %l42, !tbaa !21
  %t72 = xor i1 %t71, true
  store i1 %t72, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l39, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t82 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t78, i32 %t79)
  store i1 %t82, ptr %l48
  br label %bb16
bb16:
  %t83 = load i1, ptr %l48, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t86 = load i1, ptr %l44, !tbaa !21
  br i1 %t86, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb20
bb20:
  %t88 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 0)
  store i32 %t88, ptr %l51
  br label %bb21
bb21:
  %t89 = load i32, ptr %l51, !tbaa !23
  %t90 = sext i32 %t89 to i64
  store i64 %t90, ptr %l4, !tbaa !24
  %t93 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 1)
  store i32 %t93, ptr %l54
  br label %bb22
bb22:
  %t94 = load i32, ptr %l54, !tbaa !23
  %t95 = sext i32 %t94 to i64
  store i64 %t95, ptr %l5, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t97)
  store ptr %t99, ptr %l57
  br label %bb23
bb23:
  %t101 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 0)
  store i32 %t101, ptr %l59
  br label %bb24
bb24:
  %t102 = load ptr, ptr %l57, !tbaa !29
  %t103 = load i32, ptr %l59, !tbaa !23
  %t104 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t102, i32 %t103)
  store %"compiler/typed:Local" %t104, ptr %l60
  br label %bb25
bb25:
  %t105 = getelementptr %"compiler/typed:Local", ptr %l60, i32 0, i32 1
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l6
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  store ptr %t113, ptr %l64, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %l1, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t119, i32 %t120)
  store i32 %t123, ptr %l69
  br label %bb26
bb26:
  %t124 = load ptr, ptr %l64, !tbaa !29
  %t125 = load i32, ptr %l69, !tbaa !23
  %t126 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t124, i32 %t125)
  store { i64, ptr } %t126, ptr %l70
  br label %bb27
bb27:
  %t127 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t127, ptr %l7, !tbaa !27
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %s0, ptr %t131, i32 %t132)
  store { i64, ptr } %t135, ptr %l74
  br label %bb28
bb28:
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t136, ptr %l8, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 2
  store ptr %t142, ptr %l77, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l2, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l82
  br label %bb29
bb29:
  %t153 = load ptr, ptr %l77, !tbaa !29
  %t154 = load i32, ptr %l82, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t153, i32 %t154)
  store { i64, ptr } %t155, ptr %l83
  br label %bb30
bb30:
  %t156 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t156, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t165 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t159, i64 %t162)
  store i64 %t165, ptr %l88
  br label %bb31
bb31:
  %t166 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = load i64, ptr %l88, !tbaa !24
  %t171 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t169, i64 %t168)
  store i64 %t171, ptr %l91
  br label %bb32
bb32:
  %t172 = load i64, ptr %l91, !tbaa !24
  store i64 %t172, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t173 = load i64, ptr %l11, !tbaa !24
  %t174 = load i64, ptr %l10, !tbaa !24
  %t177 = icmp sgt i64 %t173, %t174
  br i1 %t177, label %bb33, label %bb34
bb33:
  %t179 = load i64, ptr %l12, !tbaa !24
  %t181 = icmp sgt i64 %t179, 0
  br i1 %t181, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb38
bb35:
  %t183 = load i64, ptr %l11, !tbaa !24
  %t184 = load i64, ptr %l10, !tbaa !24
  %t187 = sub i64 %t183, %t184
  %t188 = load i64, ptr %l12, !tbaa !24
  %t191 = add i64 %t187, %t188
  %t193 = sub i64 %t191, 1
  %t194 = load i64, ptr %l12, !tbaa !24
  %t197 = sdiv i64 %t193, %t194
  store i64 %t197, ptr %l98, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb37
bb37:
  %t199 = load i64, ptr %l98, !tbaa !24
  store i64 %t199, ptr %l95, !tbaa !24
  br label %bb38
bb38:
  %t200 = load i64, ptr %l95, !tbaa !24
  store i64 %t200, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb39
bb39:
  %t201 = load i64, ptr %l14, !tbaa !24
  %t202 = load i64, ptr %l13, !tbaa !24
  %t205 = icmp slt i64 %t201, %t202
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb40, label %bb41
bb40:
  br label %bb60
bb41:
  br label %bb42
bb42:
  %t209 = load i64, ptr %l10, !tbaa !24
  %t210 = load i64, ptr %l14, !tbaa !24
  %t211 = load i64, ptr %l12, !tbaa !24
  %t214 = mul i64 %t210, %t211
  %t217 = add i64 %t209, %t214
  store i64 %t217, ptr %l15, !tbaa !24
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l116, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t220, ptr %l117
  %t221 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t221, ptr %l118
  %t222 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t222, ptr %l119, !tbaa !27
  %t223 = load i64, ptr %l15, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i32, ptr %t226, i64 %t223
  %t228 = load i32, ptr %t227, !tbaa !33
  store i32 %t228, ptr %l121, !tbaa !23
  %t229 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t229, ptr %l122
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l5, !tbaa !24
  %t234 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t230, i64 %t231)
  store i32 %t234, ptr %l125
  br label %bb43
bb43:
  %t235 = load i64, ptr %l5, !tbaa !24
  %t237 = trunc i64 %t235 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t239
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 0
  store i64 0, ptr %t240
  %t241 = load %"compiler/source:Span", ptr %l122
  %t242 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t241, 0
  %t243 = load i32, ptr %l125, !tbaa !23
  %t244 = insertvalue { %"compiler/source:Span", i32, i32 } %t242, i32 %t243, 1
  %t246 = insertvalue { %"compiler/source:Span", i32, i32 } %t244, i32 %t237, 2
  %t247 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t246, ptr %t247
  %t248 = load { i64, [4 x i64] }, ptr %t239
  %t250 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t248, ptr %t250
  %t251 = load i64, ptr %l15, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t252
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 0
  store i64 3, ptr %t253
  %t254 = load %"compiler/source:Span", ptr %l118
  %t255 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t254, 0
  %t256 = load i32, ptr %l121, !tbaa !23
  %t257 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t255, i32 %t256, 1
  %t259 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t257, ptr %t250, 2
  %t261 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t259, i64 %t251, 3
  %t262 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t261, ptr %t262
  %t263 = load { i64, [4 x i64] }, ptr %t252
  %t265 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t263, ptr %t265
  %t266 = load ptr, ptr %l116, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l117
  %t269 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t266, %"compiler/source:Span" %t267, ptr %t265)
  store ptr %t269, ptr %l134
  br label %bb44
bb44:
  %t270 = load ptr, ptr %l134, !tbaa !29
  store ptr %t270, ptr %l16, !tbaa !29
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t272, ptr %l136, !tbaa !27
  %t273 = load i64, ptr %l15, !tbaa !24
  %t275 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr i32, ptr %t276, i64 %t273
  %t278 = load i32, ptr %t277, !tbaa !33
  %t281 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t271, i32 %t278)
  store i1 %t281, ptr %l139
  br label %bb45
bb45:
  %t282 = load i1, ptr %l139, !tbaa !21
  %t283 = xor i1 %t282, true
  br i1 %t283, label %bb46, label %bb47
bb46:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load ptr, ptr %l16, !tbaa !29
  %t288 = load %"compiler/source:Span", ptr %l6
  %t289 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t294 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t285, ptr %t286, %"compiler/source:Span" %t288, i64 %t289)
  store i1 %t294, ptr %l146
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb49
bb49:
  %t295 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t295, ptr %l147
  %t296 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t296, ptr %l148, !tbaa !27
  %t297 = load i64, ptr %l15, !tbaa !24
  %t299 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr i32, ptr %t300, i64 %t297
  %t302 = load i32, ptr %t301, !tbaa !33
  store i32 %t302, ptr %l150, !tbaa !23
  store i32 3, ptr %l151
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load ptr, ptr %l16, !tbaa !29
  %t307 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t303, ptr %t304)
  store { i64, ptr } %t307, ptr %l154
  br label %bb50
bb50:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load %"compiler/source:Span", ptr %l6
  %t310 = load i64, ptr %l4, !tbaa !24
  %t314 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t308, %"compiler/source:Span" %t309, i64 %t310)
  store ptr %t314, ptr %l158
  br label %bb51
bb51:
  %t315 = load ptr, ptr %l158, !tbaa !29
  store ptr %t315, ptr %l159, !tbaa !29
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load %"compiler/source:Span", ptr %l6
  %t321 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t316, i32 1, %"compiler/source:Span" %t317)
  store i32 %t321, ptr %l163
  br label %bb52
bb52:
  %t322 = load i32, ptr %l151, !range !{i32 0, i32 5}
  %t323 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t324 = load ptr, ptr %l159, !tbaa !29
  %t325 = load i32, ptr %l163, !tbaa !23
  %t327 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t322, i64 0, { i64, ptr } %t323, ptr %t324, i32 %t325, i32 1, i1 false)
  store %"compiler/typed:Make" %t327, ptr %l165
  br label %bb53
bb53:
  %t328 = load %"compiler/typed:Make", ptr %l165
  %t329 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t328, ptr %t329
  store { i64, [5 x i64] } zeroinitializer, ptr %t330
  %t331 = getelementptr { i64, [5 x i64] }, ptr %t330, i32 0, i32 0
  store i64 7, ptr %t331
  %t332 = load %"compiler/source:Span", ptr %l147
  %t333 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t332, 0
  %t334 = load i32, ptr %l150, !tbaa !23
  %t335 = insertvalue { %"compiler/source:Span", i32, ptr } %t333, i32 %t334, 1
  %t337 = insertvalue { %"compiler/source:Span", i32, ptr } %t335, ptr %t329, 2
  %t338 = getelementptr { i64, [5 x i64] }, ptr %t330, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t337, ptr %t338
  %t339 = load { i64, [5 x i64] }, ptr %t330
  %t340 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t340, ptr %lp17
  %t342 = load ptr, ptr %lp17
  store { i64, [5 x i64] } %t339, ptr %t342
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i64, ptr %l15, !tbaa !24
  %t346 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr i32, ptr %t347, i64 %t344
  %t349 = load i32, ptr %t348, !tbaa !33
  %t350 = load %"compiler/source:Span", ptr %l6
  %t351 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t351, ptr %l172, !tbaa !27
  %t352 = load i64, ptr %l15, !tbaa !24
  %t354 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr i32, ptr %t355, i64 %t352
  %t357 = load i32, ptr %t356, !tbaa !33
  store { i64, [1 x i64] } zeroinitializer, ptr %t358
  %t359 = getelementptr { i64, [1 x i64] }, ptr %t358, i32 0, i32 0
  store i64 4, ptr %t359
  %t360 = load { i64, [1 x i64] }, ptr %t358
  %t367 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t343, i32 %t349, %"compiler/source:Span" %t350, i32 %t357, i32 6, { i64, [1 x i64] } %t360)
  store i64 %t367, ptr %l177
  br label %bb54
bb54:
  %t368 = load i64, ptr %l177, !tbaa !24
  store i64 %t368, ptr %l18, !tbaa !24
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l6
  %t371 = load i64, ptr %l18, !tbaa !24
  %t373 = trunc i64 %t371 to i32
  %t375 = load ptr, ptr %lp17
  store { i64, [3 x i64] } zeroinitializer, ptr %t376
  %t377 = getelementptr { i64, [3 x i64] }, ptr %t376, i32 0, i32 0
  store i64 0, ptr %t377
  %t379 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t370, 0
  %t381 = insertvalue { %"compiler/source:Span", i32, ptr } %t379, i32 %t373, 1
  %t383 = insertvalue { %"compiler/source:Span", i32, ptr } %t381, ptr %t375, 2
  %t384 = getelementptr { i64, [3 x i64] }, ptr %t376, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t383, ptr %t384
  %t385 = load { i64, [3 x i64] }, ptr %t376
  %t387 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t385, ptr %t387
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t369, ptr %t387)
  br label %bb55
bb55:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t390)
  store ptr %t392, ptr %l187
  br label %bb56
bb56:
  %t393 = load ptr, ptr %l187, !tbaa !29
  %t395 = getelementptr %"compiler/typed:Body", ptr %t393, i32 0, i32 10
  %t396 = load i64, ptr %l18, !tbaa !24
  %t398 = trunc i64 %t396 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t395, i32 %t398)
  br label %bb57
bb57:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i64, ptr %l18, !tbaa !24
  %t404 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %t402, i64 %t403, %"compiler/source:Span" %t404, i1 true)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t408 = load i64, ptr %l14, !tbaa !24
  %t411 = add i64 %t408, 1
  store i64 %t411, ptr %l14, !tbaa !24
  br label %bb39
bb60:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/check:reflList"
  %l5 = alloca i1
  %l6 = alloca i32
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l46 = alloca i32
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca i1
  %lp51 = alloca ptr
  %l55 = alloca %"compiler/check:reflList"
  %l62 = alloca ptr
  %l68 = alloca i32
  %l72 = alloca i1
  %l75 = alloca i1
  %l76 = alloca i1
  %l81 = alloca i1
  %l82 = alloca ptr
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca %"compiler/diagmsg:Msg"
  %l88 = alloca i64
  %l91 = alloca ptr
  %l95 = alloca i32
  %l97 = alloca i32
  %l99 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l106 = alloca %"compiler/ast:ForIn"
  %l109 = alloca i64
  %l111 = alloca ptr
  %l160 = alloca ptr
  %l220 = alloca i32
  %l222 = alloca ptr
  %l227 = alloca i1
  %l229 = alloca ptr
  %l233 = alloca i64
  %l236 = alloca { i64, ptr }
  %l237 = alloca i64
  %l238 = alloca i32
  %l239 = alloca ptr
  %l242 = alloca %"compiler/source:Span"
  %l253 = alloca %"compiler/source:Span"
  %l255 = alloca %"compiler/diagmsg:Msg"
  %l256 = alloca i64
  %l258 = alloca ptr
  %l266 = alloca ptr
  %l267 = alloca %"compiler/source:Span"
  %l270 = alloca i32
  %l274 = alloca { i64, ptr }
  %l277 = alloca %"compiler/typed:Seq"
  %l288 = alloca ptr
  %l292 = alloca i1
  %l296 = alloca %"compiler/source:Span"
  %l297 = alloca i32
  %l298 = alloca ptr
  %l299 = alloca ptr
  %l303 = alloca i32
  %l306 = alloca %"compiler/typed:Collect"
  %l315 = alloca %"compiler/source:Span"
  %l316 = alloca i32
  %l320 = alloca { i64, ptr }
  %l322 = alloca %"compiler/typed:Seq"
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t499 = alloca { i64, [5 x i64] }, align 8
  %t562 = alloca { i64, [5 x i64] }, align 8
  %t603 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Compr", ptr %t2, i32 0, i32 4
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store %"compiler/check:reflList" %t8, ptr %l55
  br label %bb1
bb1:
  %t9 = load %"compiler/check:reflList", ptr %l55
  store %"compiler/check:reflList" %t9, ptr %l4
  %t10 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 0
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load %"compiler/check:reflList", ptr %l4
  %t17 = load i32, ptr %l3, !tbaa !23
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolledCompr(ptr %v0, ptr %v1, ptr %v2, ptr %t13, %"compiler/source:Span" %t14, ptr %t15, %"compiler/check:reflList" %t16, i32 %t17)
  store ptr %t23, ptr %l62
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t24 = load ptr, ptr %l62, !tbaa !29
  store ptr %t24, ptr %rv
  br label %ret
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 142
  %t28 = load i1, ptr %t27, !tbaa !21
  store i1 %t28, ptr %l5, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 142
  store i1 false, ptr %t32, !tbaa !21
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValueType(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l68
  br label %bb6
bb6:
  %t38 = load i32, ptr %l68, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  %t39 = load i32, ptr %l6, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp ne i32 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l6, !tbaa !23
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t45, i32 %t46)
  store i1 %t49, ptr %l75
  br label %bb9
bb8:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb14
bb9:
  %t50 = load i1, ptr %l75, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb13
bb11:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load i32, ptr %l6, !tbaa !23
  %t60 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l81
  br label %bb12
bb12:
  %t61 = load i1, ptr %l81, !tbaa !21
  store i1 %t61, ptr %l76, !tbaa !21
  br label %bb13
bb13:
  %t62 = load i1, ptr %l76, !tbaa !21
  store i1 %t62, ptr %l72, !tbaa !21
  br label %bb14
bb14:
  %t63 = load i1, ptr %l72, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l82, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t71 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprAt(ptr %v0, ptr %v1, ptr %t65, %"compiler/source:Span" %t66, ptr %t67)
  store %"compiler/source:Span" %t71, ptr %l86
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t72 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eComprehensionReferences(ptr %v0)
  store %"compiler/diagmsg:Msg" %t72, ptr %l87
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l82, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l86
  %t75 = load %"compiler/diagmsg:Msg", ptr %l87
  %t76 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t73, %"compiler/source:Span" %t74, %"compiler/diagmsg:Msg" %t75)
  store i64 %t76, ptr %l88
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t77, %"compiler/source:Span" %t78)
  store ptr %t81, ptr %l91
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i1, ptr %l5, !tbaa !21
  %t86 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 142
  store i1 %t83, ptr %t86, !tbaa !21
  %t87 = load ptr, ptr %l91, !tbaa !29
  store ptr %t87, ptr %rv
  br label %ret
bb21:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/ast:Compr", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %t90, !tbaa !23
  store i32 %t91, ptr %l95, !tbaa !23
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t94 = getelementptr %"compiler/ast:Compr", ptr %t92, i32 0, i32 3
  %t95 = load i32, ptr %t94, !tbaa !23
  store i32 %t95, ptr %l97, !tbaa !23
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Compr", ptr %t96, i32 0, i32 4
  %t99 = load ptr, ptr %t98, !tbaa !29
  store ptr %t99, ptr %l99, !tbaa !29
  %t100 = icmp sge i64 0, 0
  br i1 %t100, label %bb22, label %bb23
bb22:
  %t102 = icmp sle i64 0, 1152921504606846975
  br i1 %t102, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_db57390f6fdf03bc_f3fc0cbffafab9c0)
  unreachable
bb24:
  %t104 = mul i64 0, 8
  %t105 = insertvalue { i64, ptr } undef, i64 0, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t106, ptr %l102, !tbaa !27
  %t107 = icmp sge i64 0, 0
  br i1 %t107, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_db57390f6fdf03bc_f3fc0cbffafab9c0)
  unreachable
bb26:
  %t109 = icmp sle i64 0, 1152921504606846975
  br i1 %t109, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_db57390f6fdf03bc_f3fc0cbffafab9c0)
  unreachable
bb28:
  %t111 = mul i64 0, 8
  %t112 = insertvalue { i64, ptr } undef, i64 0, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t114 = load i32, ptr %l95, !tbaa !23
  %t115 = load i32, ptr %l97, !tbaa !23
  %t116 = load ptr, ptr %l99, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t119 = call %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v1, ptr %v2, ptr %v2, ptr %v2, i32 %t114, i32 %t115, ptr %t116, i1 false, { i64, ptr } %t117, { i64, ptr } %t113, i1 false)
  store %"compiler/ast:ForIn" %t119, ptr %l106
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_db57390f6fdf03bc_f3fc0cbffafab9c0)
  unreachable
bb30:
  %t120 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 64, i64 8)
  store ptr %t120, ptr %lp7
  %t121 = load %"compiler/ast:ForIn", ptr %l106
  %t122 = load ptr, ptr %lp7
  store %"compiler/ast:ForIn" %t121, ptr %t122
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 48
  %t127 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t125)
  store i64 %t127, ptr %l109
  br label %bb31
bb31:
  %t128 = load i64, ptr %l109, !tbaa !24
  store i64 %t128, ptr %l8, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t129)
  store ptr %t131, ptr %l111
  br label %bb32
bb32:
  %t132 = load ptr, ptr %l111, !tbaa !29
  %t134 = getelementptr %"compiler/check:frame", ptr %t132, i32 0, i32 17
  %t135 = load i64, ptr %t134, !tbaa !24
  store i64 %t135, ptr %l9, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 134
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l10, !tbaa !24
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 135
  %t145 = load i64, ptr %t144, !tbaa !24
  store i64 %t145, ptr %l11, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 136
  %t150 = load i64, ptr %t149, !tbaa !24
  store i64 %t150, ptr %l12, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 137
  %t155 = load i64, ptr %t154, !tbaa !24
  store i64 %t155, ptr %l13, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 138
  %t160 = load i64, ptr %t159, !tbaa !24
  store i64 %t160, ptr %l14, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 139
  %t165 = load i64, ptr %t164, !tbaa !24
  store i64 %t165, ptr %l15, !tbaa !24
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 140
  %t170 = load i64, ptr %t169, !tbaa !24
  store i64 %t170, ptr %l16, !tbaa !24
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/check:Checker", ptr %t172, i32 0, i32 141
  %t175 = load i64, ptr %t174, !tbaa !24
  store i64 %t175, ptr %l17, !tbaa !24
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 144
  %t180 = load i1, ptr %t179, !tbaa !21
  store i1 %t180, ptr %l18, !tbaa !21
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 145
  %t185 = load i32, ptr %t184, !tbaa !23
  store i32 %t185, ptr %l19, !tbaa !23
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 146
  %t190 = load i64, ptr %t189, !tbaa !24
  store i64 %t190, ptr %l20, !tbaa !24
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 134
  store i64 1, ptr %t196, !tbaa !24
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 139
  store i64 -1, ptr %t201, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/check:Checker", ptr %t202, i32 0, i32 140
  store i64 -1, ptr %t206, !tbaa !24
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 141
  store i64 -1, ptr %t211, !tbaa !24
  %t212 = load i32, ptr %l6, !tbaa !23
  %t213 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t216 = icmp eq i32 %t212, %t213
  %t218 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 144
  store i1 %t216, ptr %t224, !tbaa !21
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 145
  store i32 %t218, ptr %t229, !tbaa !23
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 146
  store i64 -1, ptr %t234, !tbaa !24
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l1
  %t237 = load ptr, ptr %lp7
  %t238 = load ptr, ptr %l2, !tbaa !29
  %t240 = load i32, ptr %l6, !tbaa !23
  %t246 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v2, ptr %v1, ptr %v2, ptr %t235, %"compiler/source:Span" %t236, ptr %t237, ptr %t238, i32 %t240)
  store ptr %t246, ptr %l160
  br label %bb33
bb33:
  %t247 = load ptr, ptr %l160, !tbaa !29
  store ptr %t247, ptr %l28, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/check:Checker", ptr %t248, i32 0, i32 134
  %t251 = load i64, ptr %t250, !tbaa !24
  %t253 = icmp eq i64 %t251, 1
  br i1 %t253, label %bb34, label %bb35
bb34:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %t255, %"compiler/source:Span" %t256)
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t259, i32 0, i32 134
  %t262 = load i64, ptr %t261, !tbaa !24
  store i64 %t262, ptr %l29, !tbaa !24
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 135
  %t267 = load i64, ptr %t266, !tbaa !24
  store i64 %t267, ptr %l30, !tbaa !24
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t269, i32 0, i32 136
  %t272 = load i64, ptr %t271, !tbaa !24
  store i64 %t272, ptr %l31, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 137
  %t277 = load i64, ptr %t276, !tbaa !24
  store i64 %t277, ptr %l32, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 138
  %t282 = load i64, ptr %t281, !tbaa !24
  store i64 %t282, ptr %l33, !tbaa !24
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t284, i32 0, i32 139
  %t287 = load i64, ptr %t286, !tbaa !24
  store i64 %t287, ptr %l34, !tbaa !24
  %t289 = load i32, ptr %l6, !tbaa !23
  %t290 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t293 = icmp eq i32 %t289, %t290
  br i1 %t293, label %bb38, label %bb39
bb38:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/check:Checker", ptr %t295, i32 0, i32 145
  %t298 = load i32, ptr %t297, !tbaa !23
  store i32 %t298, ptr %l6, !tbaa !23
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t300 = load i64, ptr %l10, !tbaa !24
  %t302 = load i64, ptr %l11, !tbaa !24
  %t304 = load i64, ptr %l12, !tbaa !24
  %t306 = load i64, ptr %l13, !tbaa !24
  %t308 = load i64, ptr %l14, !tbaa !24
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/check:Checker", ptr %t310, i32 0, i32 134
  store i64 %t300, ptr %t314, !tbaa !24
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 135
  store i64 %t302, ptr %t319, !tbaa !24
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/check:Checker", ptr %t320, i32 0, i32 136
  store i64 %t304, ptr %t324, !tbaa !24
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/check:Checker", ptr %t325, i32 0, i32 137
  store i64 %t306, ptr %t329, !tbaa !24
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t330, i32 0, i32 138
  store i64 %t308, ptr %t334, !tbaa !24
  %t335 = load i64, ptr %l15, !tbaa !24
  %t337 = load i64, ptr %l16, !tbaa !24
  %t339 = load i64, ptr %l17, !tbaa !24
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 139
  store i64 %t335, ptr %t345, !tbaa !24
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/check:Checker", ptr %t346, i32 0, i32 140
  store i64 %t337, ptr %t350, !tbaa !24
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 141
  store i64 %t339, ptr %t355, !tbaa !24
  %t356 = load i1, ptr %l18, !tbaa !21
  %t358 = load i32, ptr %l19, !tbaa !23
  %t360 = load i64, ptr %l20, !tbaa !24
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/check:Checker", ptr %t362, i32 0, i32 144
  store i1 %t356, ptr %t366, !tbaa !21
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/check:Checker", ptr %t367, i32 0, i32 145
  store i32 %t358, ptr %t371, !tbaa !23
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 146
  store i64 %t360, ptr %t376, !tbaa !24
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = getelementptr %"compiler/generic:Program", ptr %t380, i32 0, i32 2
  %t383 = load i32, ptr %l6, !tbaa !23
  %t386 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t382, i32 %t383, i32 0)
  store i32 %t386, ptr %l220
  br label %bb41
bb41:
  %t387 = load i32, ptr %l220, !tbaa !23
  store i32 %t387, ptr %l46, !tbaa !23
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t388)
  store ptr %t390, ptr %l222
  br label %bb42
bb42:
  %t391 = load ptr, ptr %l222, !tbaa !29
  %t393 = getelementptr %"compiler/check:frame", ptr %t391, i32 0, i32 17
  %t394 = load i64, ptr %t393, !tbaa !24
  %t395 = load i64, ptr %l9, !tbaa !24
  %t398 = icmp sgt i64 %t394, %t395
  br i1 %t398, label %bb43, label %bb44
bb43:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t400)
  store ptr %t402, ptr %l229
  br label %bb45
bb44:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb46
bb45:
  %t403 = load ptr, ptr %l229, !tbaa !29
  %t405 = getelementptr %"compiler/check:frame", ptr %t403, i32 0, i32 15
  %t406 = load i64, ptr %t405, !tbaa !24
  %t408 = icmp eq i64 %t406, 0
  store i1 %t408, ptr %l227, !tbaa !21
  br label %bb46
bb46:
  %t410 = load i1, ptr %l227, !tbaa !21
  br i1 %t410, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load %"compiler/source:Span", ptr %l1
  %t415 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t411, %"compiler/source:Span" %t412)
  store { i64, ptr } %t415, ptr %l236
  br label %bb49
bb48:
  br label %bb60
bb49:
  %t416 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t417 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s7, { i64, ptr } %t416, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) })
  %t418 = extractvalue { i32, i64 } %t417, 1
  %t419 = extractvalue { i32, i64 } %t417, 0
  store i32 %t419, ptr %l238
  %t420 = icmp ne i32 %t419, 0
  br i1 %t420, label %bb51, label %ok.421, !prof !99
ok.421:
  store i64 %t418, ptr %l237
  br label %bb50
bb50:
  %t422 = load i64, ptr %l237, !tbaa !24
  store i64 %t422, ptr %l233, !tbaa !24
  br label %bb53
bb51:
  br label %bb52
bb52:
  store i64 -1, ptr %l233, !tbaa !24
  br label %bb53
bb53:
  %t423 = load i64, ptr %l233, !tbaa !24
  store i64 %t423, ptr %l47, !tbaa !24
  %t424 = load ptr, ptr %l0, !tbaa !29
  store ptr %t424, ptr %l239, !tbaa !29
  %t425 = load i64, ptr %l47, !tbaa !24
  %t427 = icmp sge i64 %t425, 0
  br i1 %t427, label %bb54, label %bb55
bb54:
  %t429 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t430 = load i32, ptr %t429, !tbaa !23
  %t431 = load i64, ptr %l47, !tbaa !24
  %t433 = add i64 %t431, 1
  %t435 = trunc i64 %t433 to i32
  %t438 = add i32 %t430, %t435
  %t439 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t440 = load i32, ptr %t439, !tbaa !23
  %t441 = load i64, ptr %l47, !tbaa !24
  %t443 = add i64 %t441, 4
  %t445 = trunc i64 %t443 to i32
  %t448 = add i32 %t440, %t445
  %t451 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s7, i32 %t438, i32 %t448)
  store %"compiler/source:Span" %t451, ptr %l253
  br label %bb56
bb55:
  %t452 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t452, ptr %l242
  br label %bb57
bb56:
  %t454 = load %"compiler/source:Span", ptr %l253
  store %"compiler/source:Span" %t454, ptr %l242
  br label %bb57
bb57:
  %t455 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eComprNeedsTry(ptr %v0)
  store %"compiler/diagmsg:Msg" %t455, ptr %l255
  br label %bb58
bb58:
  %t456 = load ptr, ptr %l239, !tbaa !29
  %t457 = load %"compiler/source:Span", ptr %l242
  %t458 = load %"compiler/diagmsg:Msg", ptr %l255
  %t459 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t456, %"compiler/source:Span" %t457, %"compiler/diagmsg:Msg" %t458)
  store i64 %t459, ptr %l256
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb60:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t460)
  store ptr %t462, ptr %l258
  br label %bb61
bb61:
  %t463 = load ptr, ptr %l258, !tbaa !29
  %t464 = load i64, ptr %l9, !tbaa !24
  %t467 = getelementptr %"compiler/check:frame", ptr %t463, i32 0, i32 17
  store i64 %t464, ptr %t467, !tbaa !24
  %t468 = load i64, ptr %l29, !tbaa !24
  %t470 = icmp eq i64 %t468, 3
  br i1 %t470, label %bb62, label %bb63
bb62:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load %"compiler/source:Span", ptr %l1
  %t474 = load i64, ptr %l34, !tbaa !24
  %t478 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t472, %"compiler/source:Span" %t473, i64 %t474)
  store ptr %t478, ptr %l266
  br label %bb64
bb63:
  br label %bb68
bb64:
  %t479 = load ptr, ptr %l266, !tbaa !29
  store ptr %t479, ptr %l48, !tbaa !29
  %t480 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t480, ptr %l267
  %t481 = load ptr, ptr %l48, !tbaa !29
  %t484 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t481)
  store i32 %t484, ptr %l270
  br label %bb65
bb65:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/check:Checker", ptr %t485, i32 0, i32 48
  %t488 = load i64, ptr %l8, !tbaa !24
  %t491 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t487, i64 %t488)
  store { i64, ptr } %t491, ptr %l274
  br label %bb66
bb66:
  %t492 = load ptr, ptr %l48, !tbaa !29
  %t494 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t496 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t494, ptr %t492, i1 false)
  store %"compiler/typed:Seq" %t496, ptr %l277
  br label %bb67
bb67:
  %t497 = load %"compiler/typed:Seq", ptr %l277
  %t498 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t497, ptr %t498
  store { i64, [5 x i64] } zeroinitializer, ptr %t499
  %t500 = getelementptr { i64, [5 x i64] }, ptr %t499, i32 0, i32 0
  store i64 12, ptr %t500
  %t501 = load %"compiler/source:Span", ptr %l267
  %t502 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t501, 0
  %t503 = load i32, ptr %l270, !tbaa !23
  %t504 = insertvalue { %"compiler/source:Span", i32, ptr } %t502, i32 %t503, 1
  %t506 = insertvalue { %"compiler/source:Span", i32, ptr } %t504, ptr %t498, 2
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t499, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t506, ptr %t507
  %t508 = load { i64, [5 x i64] }, ptr %t499
  %t510 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t508, ptr %t510
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load i1, ptr %l5, !tbaa !21
  %t515 = getelementptr %"compiler/check:Checker", ptr %t511, i32 0, i32 142
  store i1 %t512, ptr %t515, !tbaa !21
  store ptr %t510, ptr %rv
  br label %ret
bb68:
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t518 = load i64, ptr %l30, !tbaa !24
  %t519 = load i64, ptr %l31, !tbaa !24
  %t520 = load i64, ptr %l32, !tbaa !24
  %t521 = load i64, ptr %l33, !tbaa !24
  %t527 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v2, ptr %t517, i64 %t518, i64 %t519, i64 %t520, i64 %t521)
  store ptr %t527, ptr %l288
  br label %bb69
bb69:
  %t528 = load ptr, ptr %l288, !tbaa !29
  store ptr %t528, ptr %l49, !tbaa !29
  %t529 = load ptr, ptr %l28, !tbaa !29
  %t531 = icmp eq ptr %t529, null
  %t533 = xor i1 %t531, true
  br i1 %t533, label %bb70, label %bb71
bb70:
  %t535 = load ptr, ptr %l2, !tbaa !29
  %t537 = getelementptr %"compiler/ast:Compr", ptr %t535, i32 0, i32 5
  %t538 = load ptr, ptr %t537, !tbaa !29
  %t540 = icmp eq ptr %t538, null
  store i1 %t540, ptr %l292, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l292, !tbaa !21
  br label %bb72
bb72:
  %t542 = load i1, ptr %l292, !tbaa !21
  store i1 %t542, ptr %l50, !tbaa !21
  %t543 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t543, ptr %l296
  %t544 = load i32, ptr %l46, !tbaa !23
  store i32 %t544, ptr %l297, !tbaa !23
  %t545 = load ptr, ptr %l28, !tbaa !29
  store ptr %t545, ptr %l298, !tbaa !29
  %t546 = load ptr, ptr %l49, !tbaa !29
  store ptr %t546, ptr %l299, !tbaa !29
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load %"compiler/source:Span", ptr %l1
  %t552 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t547, i32 3, %"compiler/source:Span" %t548)
  store i32 %t552, ptr %l303
  br label %bb73
bb73:
  %t553 = load i1, ptr %l50, !tbaa !21
  %t554 = load ptr, ptr %l298, !tbaa !29
  %t555 = load ptr, ptr %l299, !tbaa !29
  %t556 = load i32, ptr %l303, !tbaa !23
  %t559 = call %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t554, ptr %t555, i32 %t556, i32 0, i1 %t553, ptr null)
  store %"compiler/typed:Collect" %t559, ptr %l306
  br label %bb74
bb74:
  %t560 = load %"compiler/typed:Collect", ptr %l306
  %t561 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store %"compiler/typed:Collect" %t560, ptr %t561
  store { i64, [5 x i64] } zeroinitializer, ptr %t562
  %t563 = getelementptr { i64, [5 x i64] }, ptr %t562, i32 0, i32 0
  store i64 8, ptr %t563
  %t564 = load %"compiler/source:Span", ptr %l296
  %t565 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t564, 0
  %t566 = load i32, ptr %l297, !tbaa !23
  %t567 = insertvalue { %"compiler/source:Span", i32, ptr } %t565, i32 %t566, 1
  %t569 = insertvalue { %"compiler/source:Span", i32, ptr } %t567, ptr %t561, 2
  %t570 = getelementptr { i64, [5 x i64] }, ptr %t562, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t569, ptr %t570
  %t571 = load { i64, [5 x i64] }, ptr %t562
  %t572 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t572, ptr %lp51
  %t574 = load ptr, ptr %lp51
  store { i64, [5 x i64] } %t571, ptr %t574
  %t575 = load i64, ptr %l33, !tbaa !24
  %t576 = load i64, ptr %l8, !tbaa !24
  %t579 = icmp eq i64 %t575, %t576
  br i1 %t579, label %bb75, label %bb76
bb75:
  %t581 = load ptr, ptr %lp51
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t583 = load i1, ptr %l5, !tbaa !21
  %t586 = getelementptr %"compiler/check:Checker", ptr %t582, i32 0, i32 142
  store i1 %t583, ptr %t586, !tbaa !21
  store ptr %t581, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  %t588 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t588, ptr %l315
  %t589 = load i32, ptr %l46, !tbaa !23
  store i32 %t589, ptr %l316, !tbaa !23
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t592 = getelementptr %"compiler/check:Checker", ptr %t590, i32 0, i32 48
  %t593 = load i64, ptr %l8, !tbaa !24
  %t596 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t592, i64 %t593)
  store { i64, ptr } %t596, ptr %l320
  br label %bb78
bb78:
  %t597 = load ptr, ptr %lp51
  %t598 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t600 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t598, ptr %t597, i1 false)
  store %"compiler/typed:Seq" %t600, ptr %l322
  br label %bb79
bb79:
  %t601 = load %"compiler/typed:Seq", ptr %l322
  %t602 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t601, ptr %t602
  store { i64, [5 x i64] } zeroinitializer, ptr %t603
  %t604 = getelementptr { i64, [5 x i64] }, ptr %t603, i32 0, i32 0
  store i64 12, ptr %t604
  %t605 = load %"compiler/source:Span", ptr %l315
  %t606 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t605, 0
  %t607 = load i32, ptr %l316, !tbaa !23
  %t608 = insertvalue { %"compiler/source:Span", i32, ptr } %t606, i32 %t607, 1
  %t610 = insertvalue { %"compiler/source:Span", i32, ptr } %t608, ptr %t602, 2
  %t611 = getelementptr { i64, [5 x i64] }, ptr %t603, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t610, ptr %t611
  %t612 = load { i64, [5 x i64] }, ptr %t603
  %t614 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t612, ptr %t614
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t616 = load i1, ptr %l5, !tbaa !21
  %t619 = getelementptr %"compiler/check:Checker", ptr %t615, i32 0, i32 142
  store i1 %t616, ptr %t619, !tbaa !21
  store ptr %t614, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %lp6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i32
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l41 = alloca i64
  %l46 = alloca i64
  %l48 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l66 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l77 = alloca i32
  %l83 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %a2)
  store i32 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i32, ptr %l12, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i32 %t15, ptr %l14
  br label %bb3
bb3:
  %t16 = load i32, ptr %l14, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 0, i64 8)
  store ptr %t17, ptr %lp6
  %t19 = load ptr, ptr %lp6
  store [0 x i32] zeroinitializer, ptr %t19
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l20
  br label %bb4
bb4:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l4, !tbaa !23
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l26
  br label %bb7
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t41 = load i1, ptr %l26, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l21, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %t45, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d9, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i32 %t47, ptr %l29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = mul i64 2, 4
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 2, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l31, !tbaa !27
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 0
  store i32 %t53, ptr %t56, !tbaa !33
  %t58 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 1
  store i32 %t48, ptr %t60, !tbaa !33
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t71, ptr %l36
  br label %bb13
bb13:
  %t72 = load i1, ptr %l36, !tbaa !21
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l4, !tbaa !23
  %t82 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t78, i32 %t79)
  store i64 %t82, ptr %l41
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l3, !tbaa !23
  %t92 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t88, i32 %t89)
  store i64 %t92, ptr %l46
  br label %bb17
bb17:
  %t93 = load i64, ptr %l41, !tbaa !24
  %t94 = load i64, ptr %l46, !tbaa !24
  %t95 = icmp slt i64 %t93, %t94
  br i1 %t95, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  %t97 = load i32, ptr %l4, !tbaa !23
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = icmp ne i32 %t97, %t98
  store i1 %t101, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t103 = load i1, ptr %l48, !tbaa !21
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t104 = load i32, ptr %l5, !tbaa !23
  %t105 = mul i64 1, 4
  %t106 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 1, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l54, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 0
  store i32 %t104, ptr %t112, !tbaa !33
  %t113 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  br label %bb23
bb22:
  %t114 = load ptr, ptr %lp6
  %t116 = insertvalue { i64, ptr } undef, i64 0, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t114, 1
  store { i64, ptr } %t117, ptr %l52, !tbaa !27
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t119, ptr %rv
  br label %ret
bb24:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l4, !tbaa !23
  %t129 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t125, i32 %t126)
  store i1 %t129, ptr %l61
  br label %bb25
bb25:
  %t130 = load i1, ptr %l61, !tbaa !21
  br i1 %t130, label %bb26, label %bb27
bb26:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l4, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t136, i32 %t137)
  store i64 %t140, ptr %l66
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t141 = load i64, ptr %l66, !tbaa !24
  %t142 = icmp sle i64 %t141, 16
  br i1 %t142, label %bb29, label %bb30
bb29:
  %t144 = load i32, ptr %l5, !tbaa !23
  %t145 = mul i64 1, 4
  %t146 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 1, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l70, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 0
  store i32 %t144, ptr %t152, !tbaa !33
  %t153 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t153, ptr %l68, !tbaa !27
  br label %bb31
bb30:
  %t154 = load ptr, ptr %lp6
  %t156 = insertvalue { i64, ptr } undef, i64 0, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  store { i64, ptr } %t157, ptr %l68, !tbaa !27
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t159 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t159, ptr %rv
  br label %ret
bb32:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t164 = load i32, ptr %l3, !tbaa !23
  %t165 = load i32, ptr %l4, !tbaa !23
  %t169 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t163, i32 %t164, i32 %t165)
  store i32 %t169, ptr %l77
  br label %bb33
bb33:
  %t170 = load i32, ptr %l4, !tbaa !23
  %t171 = load i32, ptr %l77, !tbaa !23
  %t173 = icmp eq i32 %t171, %t170
  br i1 %t173, label %bb34, label %bb35
bb34:
  %t175 = load ptr, ptr %lp6
  %t177 = insertvalue { i64, ptr } undef, i64 0, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t178, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t180 = load i32, ptr %l5, !tbaa !23
  %t181 = mul i64 1, 4
  %t182 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t181)
  %t183 = insertvalue { i64, ptr } undef, i64 1, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l83, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr i32, ptr %t187, i64 0
  store i32 %t180, ptr %t188, !tbaa !33
  call void @__olang_scope_close(ptr %s0)
  %t189 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t189, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeadLet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l22 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l39 = alloca i64
  %l41 = alloca i1
  %l43 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i1
  %l58 = alloca i64
  %l61 = alloca i1
  %l66 = alloca %"compiler/check:unsetCand"
  %l67 = alloca i64
  %l69 = alloca ptr
  %l73 = alloca i1
  %l78 = alloca %"compiler/check:unsetCand"
  %l84 = alloca ptr
  %l85 = alloca i1
  %l95 = alloca ptr
  %l97 = alloca ptr
  %l102 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l105 = alloca i64
  %l107 = alloca ptr
  %l110 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l111 = alloca ptr
  %l112 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l126 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i1
  %l154 = alloca ptr
  %l158 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l159 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l163 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l164 = alloca i32
  %l165 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l169 = alloca i1
  %l172 = alloca i1
  %l173 = alloca i64
  %l175 = alloca ptr
  %l183 = alloca i64
  %l187 = alloca i64
  %l190 = alloca i64
  %l211 = alloca ptr
  %l212 = alloca ptr
  %l213 = alloca i1
  %l216 = alloca i1
  %l237 = alloca i1
  %l239 = alloca ptr
  %l240 = alloca i64
  %l241 = alloca i64
  %l242 = alloca %"compiler/source:Span"
  %l244 = alloca %"compiler/source:Span"
  %l246 = alloca ptr
  %l250 = alloca ptr
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 21
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l39
  br label %bb1
bb1:
  %t6 = load i64, ptr %l39, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l43
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l43, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l41, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l41, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t23 = load ptr, ptr %l48, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb9, label %bb10
bb9:
  %t26 = load ptr, ptr %l48, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 17}
  %t29 = icmp eq i64 %t27, 0
  store i1 %t29, ptr %l49, !tbaa !21
  br label %bb10
bb10:
  %t30 = load i1, ptr %l49, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [3 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l2, !tbaa !23
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb13
bb12:
  br label %bb38
bb13:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 129
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2eLen__H7de3be79b8c6c838ec83b81887d1384a(ptr %v0, ptr %t45)
  store i64 %t47, ptr %l58
  br label %bb14
bb14:
  %t48 = load i64, ptr %l58, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 129
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = sub i64 %t56, 1
  %t61 = call %"compiler/check:unsetCand" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2eAt_3ccompiler_2fcheck_3aunsetCand_3e(ptr %v0, ptr %t55, i64 %t58)
  store %"compiler/check:unsetCand" %t61, ptr %l66
  br label %bb17
bb16:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb19
bb17:
  %t62 = getelementptr %"compiler/check:unsetCand", ptr %l66, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l67, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t64)
  store ptr %t66, ptr %l69
  br label %bb18
bb18:
  %t67 = load ptr, ptr %l69, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 0
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load i64, ptr %l67, !tbaa !24
  %t73 = icmp eq i64 %t71, %t70
  store i1 %t73, ptr %l61, !tbaa !21
  br label %bb19
bb19:
  %t75 = load i1, ptr %l61, !tbaa !21
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 129
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = sub i64 %t79, 1
  %t84 = call %"compiler/check:unsetCand" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2eAt_3ccompiler_2fcheck_3aunsetCand_3e(ptr %v0, ptr %t78, i64 %t81)
  store %"compiler/check:unsetCand" %t84, ptr %l78
  br label %bb22
bb21:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb23
bb22:
  %t85 = getelementptr %"compiler/check:unsetCand", ptr %l78, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  %t87 = load i32, ptr %l2, !tbaa !23
  %t89 = sext i32 %t87 to i64
  %t92 = icmp eq i64 %t86, %t89
  store i1 %t92, ptr %l73, !tbaa !21
  br label %bb23
bb23:
  %t94 = load i1, ptr %l73, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l3, !tbaa !29
  store ptr %t97, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t98 = load ptr, ptr %l84, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb27, label %bb28
bb27:
  %t101 = load ptr, ptr %l84, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 18}
  %t104 = icmp eq i64 %t102, 6
  store i1 %t104, ptr %l85, !tbaa !21
  br label %bb28
bb28:
  %t105 = load i1, ptr %l85, !tbaa !21
  br i1 %t105, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 0
  %t110 = load %"compiler/source:Span", ptr %t109
  store %"compiler/source:Span" %t110, ptr %l5
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t114, i32 0, i32 1
  %t116 = load i32, ptr %t115
  store i32 %t116, ptr %l6, !tbaa !23
  %t118 = load ptr, ptr %l3, !tbaa !29
  %t120 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l7, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 49
  store ptr %t126, ptr %l95, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t127)
  store ptr %t129, ptr %l97
  br label %bb31
bb30:
  br label %bb37
bb31:
  %t130 = load ptr, ptr %l97, !tbaa !29
  %t132 = getelementptr %"compiler/check:frame", ptr %t130, i32 0, i32 0
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = load i32, ptr %l2, !tbaa !23
  %t136 = sext i32 %t134 to i64
  %t139 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t133, i64 %t136)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t139, ptr %l102
  br label %bb32
bb32:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 48
  %t144 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t142)
  store i64 %t144, ptr %l105
  br label %bb33
bb33:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t145)
  store ptr %t147, ptr %l107
  br label %bb34
bb34:
  %t148 = load ptr, ptr %l107, !tbaa !29
  %t150 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 7
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load i64, ptr %l105, !tbaa !24
  %t154 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t152, i64 %t151)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t154, ptr %l110
  br label %bb35
bb35:
  %t155 = load ptr, ptr %l95, !tbaa !29
  %t156 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l102
  %t157 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l110
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6df6a05cb53c1036d843c871c36d7669(ptr %v0, ptr %t155, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t156, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t157)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb37:
  br label %bb105
bb38:
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t159 = load ptr, ptr %l111, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb39, label %bb40
bb39:
  %t162 = load ptr, ptr %l111, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 17}
  %t165 = icmp eq i64 %t163, 1
  store i1 %t165, ptr %l112, !tbaa !21
  br label %bb40
bb40:
  %t166 = load i1, ptr %l112, !tbaa !21
  br i1 %t166, label %bb41, label %bb42
bb41:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [3 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t169, i32 0, i32 0
  %t171 = load %"compiler/source:Span", ptr %t170
  store %"compiler/source:Span" %t171, ptr %l8
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l9, !tbaa !29
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t181, i32 0, i32 2
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l10, !tbaa !29
  br label %bb43
bb42:
  br label %bb100
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t185 = load ptr, ptr %l9, !tbaa !29
  store ptr %t185, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t186 = load ptr, ptr %l121, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb44, label %bb45
bb44:
  %t189 = load ptr, ptr %l121, !tbaa !29
  %t190 = load i64, ptr %t189, !range !{i64 0, i64 8}
  %t192 = icmp eq i64 %t190, 0
  store i1 %t192, ptr %l122, !tbaa !21
  br label %bb45
bb45:
  %t193 = load i1, ptr %l122, !tbaa !21
  %t194 = xor i1 %t193, true
  br i1 %t194, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb50
bb47:
  %t196 = load ptr, ptr %l9, !tbaa !29
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l11
  %t202 = load ptr, ptr %l9, !tbaa !29
  %t204 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 1
  %t205 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t204, i32 0, i32 1
  %t206 = load i32, ptr %t205
  store i32 %t206, ptr %l12, !tbaa !23
  %t208 = load ptr, ptr %l9, !tbaa !29
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t210, i32 0, i32 2
  %t212 = load i32, ptr %t211
  store i32 %t212, ptr %l13, !tbaa !23
  %t214 = load ptr, ptr %l10, !tbaa !29
  store ptr %t214, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t215 = load ptr, ptr %l133, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb48, label %bb49
bb48:
  %t218 = load ptr, ptr %l133, !tbaa !29
  %t219 = load i64, ptr %t218, !range !{i64 0, i64 18}
  %t221 = icmp eq i64 %t219, 6
  store i1 %t221, ptr %l134, !tbaa !21
  br label %bb49
bb49:
  %t222 = load i1, ptr %l134, !tbaa !21
  %t223 = xor i1 %t222, true
  store i1 %t223, ptr %l126, !tbaa !21
  br label %bb50
bb50:
  %t225 = load i1, ptr %l126, !tbaa !21
  br i1 %t225, label %bb51, label %bb52
bb51:
  %t226 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  store ptr %t226, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t228 = load ptr, ptr %l9, !tbaa !29
  %t230 = getelementptr { i64, [4 x i64] }, ptr %t228, i32 0, i32 1
  %t231 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t230, i32 0, i32 0
  %t232 = load %"compiler/source:Span", ptr %t231
  store %"compiler/source:Span" %t232, ptr %l14
  %t234 = load ptr, ptr %l9, !tbaa !29
  %t236 = getelementptr { i64, [4 x i64] }, ptr %t234, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t236, i32 0, i32 1
  %t238 = load i32, ptr %t237
  store i32 %t238, ptr %l15, !tbaa !23
  %t240 = load ptr, ptr %l9, !tbaa !29
  %t242 = getelementptr { i64, [4 x i64] }, ptr %t240, i32 0, i32 1
  %t243 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t242, i32 0, i32 2
  %t244 = load i32, ptr %t243
  %t246 = load ptr, ptr %l10, !tbaa !29
  %t248 = getelementptr { i64, [5 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t248, i32 0, i32 0
  %t250 = load %"compiler/source:Span", ptr %t249
  store %"compiler/source:Span" %t250, ptr %l17
  %t252 = load ptr, ptr %l10, !tbaa !29
  %t254 = getelementptr { i64, [5 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t254, i32 0, i32 1
  %t256 = load i32, ptr %t255
  store i32 %t256, ptr %l18, !tbaa !23
  %t258 = load ptr, ptr %l10, !tbaa !29
  %t260 = getelementptr { i64, [5 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t260, i32 0, i32 2
  %t262 = load ptr, ptr %t261
  store ptr %t262, ptr %l19, !tbaa !29
  %t266 = sext i32 %t244 to i64
  store i64 %t266, ptr %l20, !tbaa !24
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t268)
  store ptr %t270, ptr %l154
  br label %bb54
bb54:
  %t271 = load ptr, ptr %l154, !tbaa !29
  %t273 = getelementptr %"compiler/check:frame", ptr %t271, i32 0, i32 0
  %t274 = load i64, ptr %t273, !tbaa !24
  %t275 = load i64, ptr %l20, !tbaa !24
  %t278 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t274, i64 %t275)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t278, ptr %l158
  br label %bb55
bb55:
  %t279 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l158
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t279, ptr %l21
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 49
  %t283 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t286 = call { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hdfbdd2f3b8a36ed711bc69ab15f6e663(ptr %v0, ptr %t282, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t283)
  %t287 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t286, 1
  %t288 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t286, 0
  store i32 %t288, ptr %l164
  %t289 = icmp ne i32 %t288, 0
  br i1 %t289, label %bb57, label %ok.290, !prof !99
ok.290:
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t287, ptr %l163
  br label %bb56
bb56:
  %t291 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l163
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t291, ptr %l159
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t292 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t292, ptr %l165
  br label %bb59
bb59:
  %t293 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l165
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t293, ptr %l159
  br label %bb60
bb60:
  %t294 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l159
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t294, ptr %l22
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/check:Checker", ptr %t295, i32 0, i32 49
  %t298 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t301 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc0ff66bb3944c98d4b07067782057742(ptr %v0, ptr %t297, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t298)
  store i1 %t301, ptr %l169
  br label %bb61
bb61:
  %t302 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l22, i32 0, i32 0
  %t303 = load i64, ptr %t302, !tbaa !24
  %t305 = icmp slt i64 %t303, 0
  br i1 %t305, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l172, !tbaa !21
  br label %bb65
bb63:
  %t307 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l22, i32 0, i32 1
  %t308 = load i64, ptr %t307, !tbaa !24
  store i64 %t308, ptr %l173, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t309)
  store ptr %t311, ptr %l175
  br label %bb64
bb64:
  %t312 = load ptr, ptr %l175, !tbaa !29
  %t314 = getelementptr %"compiler/check:frame", ptr %t312, i32 0, i32 7
  %t315 = load i64, ptr %t314, !tbaa !24
  %t316 = load i64, ptr %l173, !tbaa !24
  %t318 = icmp ne i64 %t316, %t315
  store i1 %t318, ptr %l172, !tbaa !21
  br label %bb65
bb65:
  %t320 = load i1, ptr %l172, !tbaa !21
  br i1 %t320, label %bb66, label %bb67
bb66:
  %t321 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  store ptr %t321, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t323 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l22, i32 0, i32 0
  %t324 = load i64, ptr %t323, !tbaa !24
  store i64 %t324, ptr %l23, !tbaa !24
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/check:Checker", ptr %t326, i32 0, i32 48
  %t330 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t328)
  store i64 %t330, ptr %l183
  br label %bb69
bb69:
  %t331 = load i64, ptr %l183, !tbaa !24
  store i64 %t331, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t332 = load i64, ptr %l24, !tbaa !24
  %t333 = load i64, ptr %l23, !tbaa !24
  %t336 = icmp sgt i64 %t332, %t333
  br i1 %t336, label %bb70, label %bb71
bb70:
  %t338 = load i64, ptr %l25, !tbaa !24
  %t340 = icmp sgt i64 %t338, 0
  br i1 %t340, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l187, !tbaa !24
  br label %bb75
bb72:
  %t342 = load i64, ptr %l24, !tbaa !24
  %t343 = load i64, ptr %l23, !tbaa !24
  %t346 = sub i64 %t342, %t343
  %t347 = load i64, ptr %l25, !tbaa !24
  %t350 = add i64 %t346, %t347
  %t352 = sub i64 %t350, 1
  %t353 = load i64, ptr %l25, !tbaa !24
  %t356 = sdiv i64 %t352, %t353
  store i64 %t356, ptr %l190, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l190, !tbaa !24
  br label %bb74
bb74:
  %t358 = load i64, ptr %l190, !tbaa !24
  store i64 %t358, ptr %l187, !tbaa !24
  br label %bb75
bb75:
  %t359 = load i64, ptr %l187, !tbaa !24
  store i64 %t359, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb76
bb76:
  %t360 = load i64, ptr %l27, !tbaa !24
  %t361 = load i64, ptr %l26, !tbaa !24
  %t364 = icmp slt i64 %t360, %t361
  %t366 = xor i1 %t364, true
  br i1 %t366, label %bb77, label %bb78
bb77:
  br label %bb99
bb78:
  br label %bb79
bb79:
  %t368 = load i64, ptr %l23, !tbaa !24
  %t369 = load i64, ptr %l27, !tbaa !24
  %t370 = load i64, ptr %l25, !tbaa !24
  %t373 = mul i64 %t369, %t370
  %t376 = add i64 %t368, %t373
  store i64 %t376, ptr %l28, !tbaa !24
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/check:Checker", ptr %t378, i32 0, i32 48
  %t381 = load i64, ptr %l28, !tbaa !24
  %t384 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t380, i64 %t381)
  store ptr %t384, ptr %l211
  br label %bb80
bb80:
  %t385 = load ptr, ptr %l211, !tbaa !29
  store ptr %t385, ptr %l29, !tbaa !29
  %t386 = load ptr, ptr %l29, !tbaa !29
  store ptr %t386, ptr %l212, !tbaa !29
  store i1 false, ptr %l213, !tbaa !21
  %t387 = load ptr, ptr %l212, !tbaa !29
  %t388 = icmp ne ptr %t387, null
  br i1 %t388, label %bb81, label %bb82
bb81:
  %t390 = load ptr, ptr %l212, !tbaa !29
  %t391 = load i64, ptr %t390, !range !{i64 0, i64 17}
  %t393 = icmp eq i64 %t391, 0
  store i1 %t393, ptr %l213, !tbaa !21
  br label %bb82
bb82:
  %t394 = load i1, ptr %l213, !tbaa !21
  br i1 %t394, label %bb83, label %bb84
bb83:
  %t395 = load ptr, ptr %l29, !tbaa !29
  %t397 = getelementptr { i64, [3 x i64] }, ptr %t395, i32 0, i32 1
  %t398 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t397, i32 0, i32 0
  %t399 = load %"compiler/source:Span", ptr %t398
  store %"compiler/source:Span" %t399, ptr %l30
  %t401 = load ptr, ptr %l29, !tbaa !29
  %t403 = getelementptr { i64, [3 x i64] }, ptr %t401, i32 0, i32 1
  %t404 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t403, i32 0, i32 1
  %t405 = load i32, ptr %t404
  %t407 = load ptr, ptr %l29, !tbaa !29
  %t409 = getelementptr { i64, [3 x i64] }, ptr %t407, i32 0, i32 1
  %t410 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t409, i32 0, i32 2
  %t411 = load ptr, ptr %t410
  store ptr %t411, ptr %l32, !tbaa !29
  %t415 = sext i32 %t405 to i64
  %t416 = load i64, ptr %l20, !tbaa !24
  %t419 = icmp eq i64 %t415, %t416
  store i1 %t419, ptr %l216, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l216, !tbaa !21
  br label %bb85
bb85:
  %t421 = load i1, ptr %l216, !tbaa !21
  br i1 %t421, label %bb86, label %bb87
bb86:
  %t422 = load ptr, ptr %l29, !tbaa !29
  %t424 = getelementptr { i64, [3 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t424, i32 0, i32 0
  %t426 = load %"compiler/source:Span", ptr %t425
  store %"compiler/source:Span" %t426, ptr %l33
  %t428 = load ptr, ptr %l29, !tbaa !29
  %t430 = getelementptr { i64, [3 x i64] }, ptr %t428, i32 0, i32 1
  %t431 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t430, i32 0, i32 1
  %t432 = load i32, ptr %t431
  store i32 %t432, ptr %l34, !tbaa !23
  %t434 = load ptr, ptr %l29, !tbaa !29
  %t436 = getelementptr { i64, [3 x i64] }, ptr %t434, i32 0, i32 1
  %t437 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t436, i32 0, i32 2
  %t438 = load ptr, ptr %t437
  store ptr %t438, ptr %l35, !tbaa !29
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load i64, ptr %l28, !tbaa !24
  %t442 = load i64, ptr %l20, !tbaa !24
  %t443 = load ptr, ptr %l10, !tbaa !29
  %t448 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsetLet(ptr %v0, ptr %v1, ptr %t440, i64 %t441, i64 %t442, ptr %t443)
  store i1 %t448, ptr %l237
  br label %bb88
bb87:
  br label %bb97
bb88:
  %t449 = load i1, ptr %l237, !tbaa !21
  br i1 %t449, label %bb89, label %bb90
bb89:
  %t450 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  store ptr %t450, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  %t452 = load ptr, ptr %l0, !tbaa !29
  store ptr %t452, ptr %l239, !tbaa !29
  %t453 = load i64, ptr %l28, !tbaa !24
  store i64 %t453, ptr %l240, !tbaa !24
  %t454 = load i64, ptr %l20, !tbaa !24
  store i64 %t454, ptr %l241, !tbaa !24
  %t455 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t455, ptr %l242
  %t456 = load ptr, ptr %l9, !tbaa !29
  %t458 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t456)
  store %"compiler/source:Span" %t458, ptr %l244
  br label %bb92
bb92:
  %t459 = load ptr, ptr %l10, !tbaa !29
  %t460 = load ptr, ptr %l239, !tbaa !29
  %t461 = load i64, ptr %l240, !tbaa !24
  %t462 = load i64, ptr %l241, !tbaa !24
  %t463 = load %"compiler/source:Span", ptr %l242
  %t464 = load %"compiler/source:Span", ptr %l244
  %t466 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esplitLet(ptr %v0, ptr %v1, ptr %v2, ptr %t460, i64 %t461, i64 %t462, %"compiler/source:Span" %t463, %"compiler/source:Span" %t464, ptr %t459)
  store ptr %t466, ptr %l246
  br label %bb93
bb93:
  %t467 = load ptr, ptr %l246, !tbaa !29
  store ptr %t467, ptr %l36, !tbaa !29
  %t468 = load ptr, ptr %l36, !tbaa !29
  %t470 = icmp eq ptr %t468, null
  %t472 = xor i1 %t470, true
  br i1 %t472, label %bb94, label %bb95
bb94:
  %t474 = load ptr, ptr %l36, !tbaa !29
  store ptr %t474, ptr %l250, !tbaa !29
  br label %bb96
bb95:
  %t476 = load ptr, ptr %l1, !tbaa !29
  store ptr %t476, ptr %l250, !tbaa !29
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s5)
  %t478 = load ptr, ptr %l250, !tbaa !29
  store ptr %t478, ptr %rv
  br label %ret
bb97:
  br label %bb98
bb98:
  %t479 = load i64, ptr %l27, !tbaa !24
  %t482 = add i64 %t479, 1
  store i64 %t482, ptr %l27, !tbaa !24
  br label %bb76
bb99:
  call void @__olang_scope_close(ptr %s5)
  br label %bb105
bb100:
  br i1 true, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_84d9a2b634770df4_5bbab0c17a6f4768)
  unreachable
bb105:
  %t484 = load ptr, ptr %l1, !tbaa !29
  store ptr %t484, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultCopiesRecv(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l8 = alloca i32
  %l11 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca i32
  %l30 = alloca i32
  %l36 = alloca ptr
  %l41 = alloca i32
  %l46 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l16
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l11, !tbaa !29
  %t27 = load i32, ptr %l16, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l17
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l23, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 0
  %t42 = load i32, ptr %t41, !tbaa !33
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t37, i32 %t42)
  store i32 %t45, ptr %l25
  br label %bb7
bb7:
  %t46 = load i32, ptr %l25, !tbaa !23
  store i32 %t46, ptr %l4, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l4, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l30
  br label %bb8
bb8:
  %t57 = load i32, ptr %l30, !range !{i32 0, i32 33}
  %t59 = trunc i64 25 to i32
  %t60 = icmp eq i32 %t57, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l36, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l41
  br label %bb12
bb12:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t84, i32 %t85)
  store i64 %t88, ptr %l46
  br label %bb13
bb13:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  %t95 = load i32, ptr %l4, !tbaa !23
  %t98 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t94, i32 %t95)
  store i64 %t98, ptr %l51
  br label %bb14
bb14:
  %t99 = load ptr, ptr %l36, !tbaa !29
  %t100 = load i32, ptr %l41, !tbaa !23
  %t101 = load i64, ptr %l46, !tbaa !24
  %t102 = load i64, ptr %l51, !tbaa !24
  %t103 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %t99, i32 %t100, i64 %t101, i64 %t102, i64 0)
  store i1 %t103, ptr %l52
  br label %bb15
bb15:
  %t104 = load i1, ptr %l52, !tbaa !21
  store i1 %t104, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultsFrom(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca i64
  %l45 = alloca i64
  %l46 = alloca %"compiler/generic:varRow"
  %rv = alloca i1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %a1)
  store i64 %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load i64, ptr %l12, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  store i64 %a3, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  %t59 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l41, !tbaa !29
  %t61 = load i64, ptr %l4, !tbaa !24
  store i64 %t61, ptr %l42, !tbaa !24
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t62, i64 %t55)
  store i64 %t66, ptr %l45
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l41, !tbaa !29
  %t68 = load i64, ptr %l42, !tbaa !24
  %t69 = load i64, ptr %l45, !tbaa !24
  %t70 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t67, i64 %t68, i64 %t69)
  store %"compiler/generic:varRow" %t70, ptr %l46
  br label %bb14
bb14:
  %t71 = getelementptr %"compiler/generic:varRow", ptr %l46, i32 0, i32 4
  %t72 = load i32, ptr %t71, !tbaa !23
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t76 = icmp eq i32 %t72, %t73
  br i1 %t76, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l9, !tbaa !24
  br label %bb9
bb19:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeferStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca %"compiler/check:factsCopy"
  %l25 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca %"compiler/check:factsMark"
  %l59 = alloca i64
  %l60 = alloca ptr
  %l62 = alloca i32
  %l66 = alloca { i64, i64, i64 }
  %l71 = alloca ptr
  %l75 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l82 = alloca ptr
  %l85 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l90 = alloca ptr
  %l93 = alloca i64
  %l98 = alloca ptr
  %l102 = alloca ptr
  %l110 = alloca ptr
  %s1 = alloca %olang.scope
  %t210 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l15, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 22
  store ptr %t6, ptr %l17, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t7)
  store ptr %t9, ptr %l19
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 7
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t14, i64 %t13)
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call %"compiler/check:factsCopy" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsCopied(ptr %v0, ptr %v0, ptr %t16)
  store %"compiler/check:factsCopy" %t18, ptr %l23
  br label %bb4
bb4:
  %t19 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 96, i64 8)
  store ptr %t19, ptr %lp4
  %t20 = load %"compiler/check:factsCopy", ptr %l23
  %t21 = load ptr, ptr %lp4
  store %"compiler/check:factsCopy" %t20, ptr %t21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t22)
  store ptr %t24, ptr %l25
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l25, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 57
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l27, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l29
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l29, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 56
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = load i64, ptr %l27, !tbaa !24
  %t40 = icmp slt i64 %t38, %t37
  br i1 %t40, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t42)
  store ptr %t44, ptr %l35
  br label %bb9
bb8:
  br label %bb20
bb9:
  %t45 = load ptr, ptr %l35, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 56
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l37, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t49)
  store ptr %t51, ptr %l39
  br label %bb10
bb10:
  %t52 = load ptr, ptr %l39, !tbaa !29
  %t54 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 57
  %t55 = load i64, ptr %t54, !tbaa !24
  store i64 %t55, ptr %l41, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t56)
  store ptr %t58, ptr %l43
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l43, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t59, i32 0, i32 56
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l46, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l47, !tbaa !24
  %t67 = load i64, ptr %l41, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load i64, ptr %l41, !tbaa !24
  %t71 = load i64, ptr %l46, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_45d73a08c1eee64c_a811f88d32b1fa78)
  unreachable
bb14:
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = load i64, ptr %l47, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_45d73a08c1eee64c_a811f88d32b1fa78)
  unreachable
bb16:
  %t78 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l41, !tbaa !24
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = getelementptr ptr, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l5, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l52, !tbaa !29
  %t88 = call %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %s1, i64 0, i64 0, i64 0)
  store %"compiler/check:factsMark" %t88, ptr %l53
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_45d73a08c1eee64c_a811f88d32b1fa78)
  unreachable
bb18:
  %t89 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t90 = load ptr, ptr %l52, !tbaa !29
  %t91 = load %"compiler/check:factsMark", ptr %l53
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ekillAssigned(ptr %v0, ptr %v0, ptr %t90, %"compiler/check:factsMark" %t91, { i64, ptr } %t89)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr @G_2ecompiler_2fcheck_2eWhyCalled, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ekillPaths(ptr %v0, ptr %t93, i64 %t94)
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 48
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t99)
  store i64 %t101, ptr %l59
  br label %bb22
bb22:
  %t102 = load i64, ptr %l59, !tbaa !24
  store i64 %t102, ptr %l6, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l60, !tbaa !29
  br i1 %a3, label %bb23, label %bb24
bb23:
  store i32 7, ptr %l62
  br label %bb25
bb24:
  store i32 6, ptr %l62
  br label %bb25
bb25:
  %t108 = load %"compiler/source:Span", ptr %l1
  %t109 = load ptr, ptr %l60, !tbaa !29
  %t110 = load i32, ptr %l62, !range !{i32 0, i32 10}
  %t112 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t109, i32 %t110, %"compiler/source:Span" %t108)
  store { i64, i64, i64 } %t112, ptr %l66
  br label %bb26
bb26:
  %t113 = load { i64, i64, i64 }, ptr %l66
  store { i64, i64, i64 } %t113, ptr %l7
  %t114 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t115 = load i64, ptr %t114, !tbaa !24
  store i64 %t115, ptr %l8, !tbaa !24
  %t117 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t118 = load i64, ptr %t117, !tbaa !24
  store i64 %t118, ptr %l9, !tbaa !24
  %t120 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t121 = load i64, ptr %t120, !tbaa !24
  store i64 %t121, ptr %l10, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t123)
  store ptr %t125, ptr %l71
  br label %bb27
bb27:
  %t126 = load ptr, ptr %l71, !tbaa !29
  %t128 = getelementptr %"compiler/check:frame", ptr %t126, i32 0, i32 34
  %t129 = load i64, ptr %t128, !tbaa !24
  store i64 %t129, ptr %l11, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t131)
  store ptr %t133, ptr %l75
  br label %bb28
bb28:
  %t134 = load ptr, ptr %l75, !tbaa !29
  %t136 = getelementptr %"compiler/check:frame", ptr %t134, i32 0, i32 37
  %t137 = load i64, ptr %t136, !tbaa !24
  store i64 %t137, ptr %l12, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t139)
  store ptr %t141, ptr %l79
  br label %bb29
bb29:
  %t142 = load ptr, ptr %l79, !tbaa !29
  store ptr %t142, ptr %l80, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t143)
  store ptr %t145, ptr %l82
  br label %bb30
bb30:
  %t146 = load ptr, ptr %l82, !tbaa !29
  %t148 = getelementptr %"compiler/check:frame", ptr %t146, i32 0, i32 10
  %t150 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t148)
  store i64 %t150, ptr %l85
  br label %bb31
bb31:
  %t151 = load i64, ptr %l85, !tbaa !24
  %t152 = load ptr, ptr %l80, !tbaa !29
  %t153 = getelementptr %"compiler/check:frame", ptr %t152, i32 0, i32 34
  store i64 %t151, ptr %t153, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t154)
  store ptr %t156, ptr %l87
  br label %bb32
bb32:
  %t157 = load ptr, ptr %l87, !tbaa !29
  store ptr %t157, ptr %l88, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t158)
  store ptr %t160, ptr %l90
  br label %bb33
bb33:
  %t161 = load ptr, ptr %l90, !tbaa !29
  %t163 = getelementptr %"compiler/check:frame", ptr %t161, i32 0, i32 38
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t163)
  store i64 %t165, ptr %l93
  br label %bb34
bb34:
  %t166 = load i64, ptr %l93, !tbaa !24
  %t167 = load ptr, ptr %l88, !tbaa !29
  %t168 = getelementptr %"compiler/check:frame", ptr %t167, i32 0, i32 37
  store i64 %t166, ptr %t168, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t169, ptr %a2)
  br label %bb35
bb35:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t174)
  store ptr %t176, ptr %l98
  br label %bb36
bb36:
  %t177 = load ptr, ptr %l98, !tbaa !29
  %t178 = load i64, ptr %l11, !tbaa !24
  %t181 = getelementptr %"compiler/check:frame", ptr %t177, i32 0, i32 34
  store i64 %t178, ptr %t181, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t182)
  store ptr %t184, ptr %l102
  br label %bb37
bb37:
  %t185 = load ptr, ptr %l102, !tbaa !29
  %t186 = load i64, ptr %l12, !tbaa !24
  %t189 = getelementptr %"compiler/check:frame", ptr %t185, i32 0, i32 37
  store i64 %t186, ptr %t189, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i64, ptr %l8, !tbaa !24
  %t192 = load i64, ptr %l9, !tbaa !24
  %t193 = load i64, ptr %l10, !tbaa !24
  %t194 = load i64, ptr %l6, !tbaa !24
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t190, i64 %t191, i64 %t192, i64 %t193, i64 %t194)
  store ptr %t200, ptr %l110
  br label %bb38
bb38:
  %t201 = load ptr, ptr %l110, !tbaa !29
  store ptr %t201, ptr %l13, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %lp4
  %t204 = load %"compiler/check:factsCopy", ptr %t203
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsRestored(ptr %v0, ptr %v0, ptr %t202, %"compiler/check:factsCopy" %t204)
  br label %bb39
bb39:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l1
  %t209 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t210
  %t211 = getelementptr { i64, [3 x i64] }, ptr %t210, i32 0, i32 0
  store i64 12, ptr %t211
  %t213 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t208, 0
  %t215 = insertvalue { %"compiler/source:Span", ptr } %t213, ptr %t209, 1
  %t216 = getelementptr { i64, [3 x i64] }, ptr %t210, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t215, ptr %t216
  %t217 = load { i64, [3 x i64] }, ptr %t210
  %t219 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t217, ptr %t219
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t207, ptr %t219)
  br label %bb40
bb40:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca { i64, ptr }
  %l25 = alloca i1
  %l35 = alloca { i64, ptr }
  %l42 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l63 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb20
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t34 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  store i1 %t34, ptr %l25
  br label %bb5
bb5:
  %t35 = load i1, ptr %l25, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/typed:Alt", ptr %t37, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 %t55
  %t60 = load ptr, ptr %t59, !tbaa !39
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Bind", ptr %t60, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t70 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t62, ptr %t66)
  store i1 %t70, ptr %l42
  br label %bb13
bb13:
  %t71 = load i1, ptr %l42, !tbaa !21
  br i1 %t71, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l7, !tbaa !24
  br label %bb9
bb18:
  br label %bb19
bb19:
  %t78 = load i64, ptr %l3, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l3, !tbaa !24
  br label %bb1
bb20:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Arm", ptr %t84, i32 0, i32 2
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t90 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t83, ptr %t87)
  store i1 %t90, ptr %l53
  br label %bb21
bb21:
  %t91 = load i1, ptr %l53, !tbaa !21
  br i1 %t91, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb25
bb23:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Arm", ptr %t93, i32 0, i32 3
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t99 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %t92, ptr %t96)
  store i1 %t99, ptr %l58
  br label %bb24
bb24:
  %t100 = load i1, ptr %l58, !tbaa !21
  store i1 %t100, ptr %l54, !tbaa !21
  br label %bb25
bb25:
  %t101 = load i1, ptr %l54, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb29
bb27:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Arm", ptr %t103, i32 0, i32 4
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t102, ptr %t106)
  store i1 %t109, ptr %l63
  br label %bb28
bb28:
  %t110 = load i1, ptr %l63, !tbaa !21
  store i1 %t110, ptr %l59, !tbaa !21
  br label %bb29
bb29:
  %t111 = load i1, ptr %l59, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l103 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l126 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l135 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i1
  %l159 = alloca { i64, ptr }
  %l165 = alloca i1
  %l171 = alloca ptr
  %l172 = alloca i1
  %l181 = alloca i1
  %l185 = alloca i1
  %l189 = alloca i1
  %l199 = alloca { i64, ptr }
  %l205 = alloca i1
  %l211 = alloca ptr
  %l212 = alloca i1
  %l223 = alloca i1
  %l225 = alloca i1
  %l234 = alloca { i64, ptr }
  %l240 = alloca i1
  %l246 = alloca ptr
  %l247 = alloca i1
  %l255 = alloca i1
  %l259 = alloca i1
  %l260 = alloca i1
  %l265 = alloca i1
  %l266 = alloca i1
  %l271 = alloca i1
  %l272 = alloca ptr
  %l273 = alloca i1
  %l282 = alloca i1
  %l283 = alloca i1
  %l287 = alloca i1
  %l288 = alloca i1
  %l293 = alloca i1
  %l294 = alloca ptr
  %l295 = alloca i1
  %l303 = alloca i1
  %l304 = alloca i1
  %l308 = alloca i1
  %l309 = alloca ptr
  %l310 = alloca i1
  %l318 = alloca i1
  %l328 = alloca { i64, ptr }
  %l333 = alloca i1
  %l342 = alloca i1
  %l343 = alloca ptr
  %l349 = alloca i1
  %l350 = alloca ptr
  %l351 = alloca i1
  %l358 = alloca i1
  %l362 = alloca i1
  %l372 = alloca { i64, ptr }
  %l378 = alloca i1
  %l388 = alloca { i64, ptr }
  %l394 = alloca i1
  %l403 = alloca ptr
  %l404 = alloca i1
  %l412 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t7 = load ptr, ptr %l46, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l46, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l47, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l47, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t16 = load ptr, ptr %l50, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l50, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l51, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l51, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t25 = load ptr, ptr %l54, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l54, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 15
  store i1 %t31, ptr %l55, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l55, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t35 = load ptr, ptr %l59, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb18, label %bb19
bb18:
  %t38 = load ptr, ptr %l59, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l60, !tbaa !21
  br label %bb19
bb19:
  %t42 = load i1, ptr %l60, !tbaa !21
  br i1 %t42, label %bb20, label %bb21
bb20:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l2, !tbaa !29
  br label %bb30
bb21:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t50 = load ptr, ptr %l65, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb22, label %bb23
bb22:
  %t53 = load ptr, ptr %l65, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 18}
  %t56 = icmp eq i64 %t54, 3
  store i1 %t56, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t57 = load i1, ptr %l66, !tbaa !21
  br i1 %t57, label %bb24, label %bb25
bb24:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l2, !tbaa !29
  br label %bb30
bb25:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t65 = load ptr, ptr %l71, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb26, label %bb27
bb26:
  %t68 = load ptr, ptr %l71, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 4
  store i1 %t71, ptr %l72, !tbaa !21
  br label %bb27
bb27:
  %t72 = load i1, ptr %l72, !tbaa !21
  br i1 %t72, label %bb28, label %bb29
bb28:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l2, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t79, ptr %t80, i1 false)
  store i1 %t83, ptr %l79
  br label %bb31
bb31:
  %t84 = load i1, ptr %l79, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb32:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t86 = load ptr, ptr %l80, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t89 = load ptr, ptr %l80, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 5
  store i1 %t92, ptr %l81, !tbaa !21
  br label %bb34
bb34:
  %t93 = load i1, ptr %l81, !tbaa !21
  br i1 %t93, label %bb35, label %bb36
bb35:
  br label %bb45
bb36:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t95 = load ptr, ptr %l84, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb37, label %bb38
bb37:
  %t98 = load ptr, ptr %l84, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 18}
  %t101 = icmp eq i64 %t99, 16
  store i1 %t101, ptr %l85, !tbaa !21
  br label %bb38
bb38:
  %t102 = load i1, ptr %l85, !tbaa !21
  br i1 %t102, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t104 = load ptr, ptr %l88, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb41, label %bb42
bb41:
  %t107 = load ptr, ptr %l88, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 18}
  %t110 = icmp eq i64 %t108, 8
  store i1 %t110, ptr %l89, !tbaa !21
  br label %bb42
bb42:
  %t111 = load i1, ptr %l89, !tbaa !21
  br i1 %t111, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i1 true, ptr %rv
  br label %ret
bb46:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t114 = load ptr, ptr %l93, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb47, label %bb48
bb47:
  %t117 = load ptr, ptr %l93, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 18}
  %t120 = icmp eq i64 %t118, 6
  store i1 %t120, ptr %l94, !tbaa !21
  br label %bb48
bb48:
  %t121 = load i1, ptr %l94, !tbaa !21
  br i1 %t121, label %bb49, label %bb50
bb49:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 1
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l3, !tbaa !23
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t130, i32 0, i32 2
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l4, !tbaa !29
  br label %bb51
bb50:
  br label %bb102
bb51:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l3, !tbaa !23
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l103
  br label %bb52
bb52:
  %t139 = load i1, ptr %l103, !tbaa !21
  br i1 %t139, label %bb53, label %bb54
bb53:
  store i1 true, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t141 = load ptr, ptr %l4, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Call", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  store ptr %t144, ptr %l5, !tbaa !29
  %t146 = load ptr, ptr %l5, !tbaa !29
  store ptr %t146, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t147 = load ptr, ptr %l107, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb56, label %bb57
bb56:
  %t150 = load ptr, ptr %l107, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 5}
  %t153 = icmp eq i64 %t151, 0
  store i1 %t153, ptr %l108, !tbaa !21
  br label %bb57
bb57:
  %t154 = load i1, ptr %l108, !tbaa !21
  br i1 %t154, label %bb58, label %bb59
bb58:
  %t155 = load ptr, ptr %l5, !tbaa !29
  %t157 = getelementptr { i64, [3 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { i32 }, ptr %t157, i32 0, i32 0
  %t159 = load i32, ptr %t158
  store i32 %t159, ptr %l6, !tbaa !23
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 132
  %t164 = load i32, ptr %l6, !tbaa !23
  %t166 = sext i32 %t164 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t163, i64 %t166)
  br label %bb61
bb61:
  br label %bb91
bb62:
  %t169 = load ptr, ptr %l5, !tbaa !29
  store ptr %t169, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t170 = load ptr, ptr %l117, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb63, label %bb64
bb63:
  %t173 = load ptr, ptr %l117, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 5}
  %t176 = icmp eq i64 %t174, 1
  store i1 %t176, ptr %l118, !tbaa !21
  br label %bb64
bb64:
  %t177 = load i1, ptr %l118, !tbaa !21
  br i1 %t177, label %bb65, label %bb66
bb65:
  %t178 = load ptr, ptr %l5, !tbaa !29
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { i64 }, ptr %t180, i32 0, i32 0
  %t182 = load i64, ptr %t181
  store i64 %t182, ptr %l7, !tbaa !24
  br label %bb67
bb66:
  br label %bb74
bb67:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t188 = load i64, ptr %l7, !tbaa !24
  %t191 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t187, i64 %t188)
  store ptr %t191, ptr %l126
  br label %bb68
bb68:
  %t192 = load ptr, ptr %l126, !tbaa !29
  store ptr %t192, ptr %l8, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr %"compiler/ast:Func", ptr %t194, i32 0, i32 2
  %t197 = load i32, ptr %t196, !tbaa !23
  %t200 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t193, i32 %t197)
  store { i64, ptr } %t200, ptr %l130
  br label %bb69
bb69:
  %t201 = load ptr, ptr %l8, !tbaa !29
  %t203 = getelementptr %"compiler/ast:Func", ptr %t201, i32 0, i32 3
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Sig", ptr %t204, i32 0, i32 0
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t212 = call i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %t210, i64 %t209)
  store i1 %t212, ptr %l135
  br label %bb70
bb70:
  %t213 = load i1, ptr %l135, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb71, label %bb72
bb71:
  store i1 true, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  br label %bb91
bb74:
  %t217 = load ptr, ptr %l5, !tbaa !29
  store ptr %t217, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t218 = load ptr, ptr %l138, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb75, label %bb76
bb75:
  %t221 = load ptr, ptr %l138, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 5}
  %t224 = icmp eq i64 %t222, 2
  store i1 %t224, ptr %l139, !tbaa !21
  br label %bb76
bb76:
  %t225 = load i1, ptr %l139, !tbaa !21
  br i1 %t225, label %bb77, label %bb78
bb77:
  br label %bb83
bb78:
  %t226 = load ptr, ptr %l5, !tbaa !29
  store ptr %t226, ptr %l142, !tbaa !29
  store i1 false, ptr %l143, !tbaa !21
  %t227 = load ptr, ptr %l142, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb79, label %bb80
bb79:
  %t230 = load ptr, ptr %l142, !tbaa !29
  %t231 = load i64, ptr %t230, !range !{i64 0, i64 5}
  %t233 = icmp eq i64 %t231, 3
  store i1 %t233, ptr %l143, !tbaa !21
  br label %bb80
bb80:
  %t234 = load i1, ptr %l143, !tbaa !21
  br i1 %t234, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store i1 true, ptr %rv
  br label %ret
bb84:
  %t236 = load ptr, ptr %l5, !tbaa !29
  store ptr %t236, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t237 = load ptr, ptr %l147, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb85, label %bb86
bb85:
  %t240 = load ptr, ptr %l147, !tbaa !29
  %t241 = load i64, ptr %t240, !range !{i64 0, i64 5}
  %t243 = icmp eq i64 %t241, 4
  store i1 %t243, ptr %l148, !tbaa !21
  br label %bb86
bb86:
  %t244 = load i1, ptr %l148, !tbaa !21
  br i1 %t244, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_d97e23b04dcff800_367dc3876d150fb4)
  unreachable
bb91:
  %t245 = load ptr, ptr %l4, !tbaa !29
  %t247 = getelementptr %"compiler/typed:Call", ptr %t245, i32 0, i32 1
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  store i64 %t252, ptr %l11, !tbaa !24
  br label %bb92
bb92:
  %t254 = load i64, ptr %l10, !tbaa !24
  %t255 = load i64, ptr %l11, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb93, label %bb94
bb93:
  br label %bb101
bb94:
  br label %bb95
bb95:
  %t262 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t262, ptr %l159, !tbaa !27
  %t263 = load i64, ptr %l10, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr ptr, ptr %t266, i64 %t263
  %t268 = load ptr, ptr %t267, !tbaa !39
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t275 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t270, ptr %t268)
  store i1 %t275, ptr %l165
  br label %bb96
bb96:
  %t276 = load i1, ptr %l165, !tbaa !21
  br i1 %t276, label %bb97, label %bb98
bb97:
  store i1 true, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t278 = load i64, ptr %l10, !tbaa !24
  %t281 = add i64 %t278, 1
  store i64 %t281, ptr %l10, !tbaa !24
  br label %bb92
bb101:
  store i1 false, ptr %rv
  br label %ret
bb102:
  %t284 = load ptr, ptr %l1, !tbaa !29
  store ptr %t284, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t285 = load ptr, ptr %l171, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb103, label %bb104
bb103:
  %t288 = load ptr, ptr %l171, !tbaa !29
  %t289 = load i64, ptr %t288, !range !{i64 0, i64 18}
  %t291 = icmp eq i64 %t289, 7
  store i1 %t291, ptr %l172, !tbaa !21
  br label %bb104
bb104:
  %t292 = load i1, ptr %l172, !tbaa !21
  br i1 %t292, label %bb105, label %bb106
bb105:
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t295 = getelementptr { i64, [5 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t295, i32 0, i32 2
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l13, !tbaa !29
  br label %bb107
bb106:
  br label %bb128
bb107:
  %t299 = load ptr, ptr %l13, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Make", ptr %t299, i32 0, i32 4
  %t302 = load i32, ptr %t301, !tbaa !23
  %t304 = sext i32 %t302 to i64
  %t306 = icmp sge i64 %t304, 0
  br i1 %t306, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb110
bb109:
  %t308 = load ptr, ptr %l13, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Make", ptr %t308, i32 0, i32 5
  %t311 = load i32, ptr %t310, !range !{i32 0, i32 4}
  %t313 = trunc i64 1 to i32
  %t314 = icmp eq i32 %t311, %t313
  store i1 %t314, ptr %l181, !tbaa !21
  br label %bb110
bb110:
  %t316 = load i1, ptr %l181, !tbaa !21
  br i1 %t316, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l185, !tbaa !21
  br label %bb114
bb112:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load ptr, ptr %l13, !tbaa !29
  %t320 = getelementptr %"compiler/typed:Make", ptr %t318, i32 0, i32 3
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t324 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t317, ptr %t321)
  store i1 %t324, ptr %l189
  br label %bb113
bb113:
  %t325 = load i1, ptr %l189, !tbaa !21
  store i1 %t325, ptr %l185, !tbaa !21
  br label %bb114
bb114:
  %t326 = load i1, ptr %l185, !tbaa !21
  br i1 %t326, label %bb115, label %bb116
bb115:
  store i1 true, ptr %rv
  br label %ret
bb116:
  br label %bb117
bb117:
  %t328 = load ptr, ptr %l13, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Make", ptr %t328, i32 0, i32 2
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  store { i64, ptr } %t331, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t333 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t333, 0
  store i64 %t335, ptr %l16, !tbaa !24
  br label %bb118
bb118:
  %t337 = load i64, ptr %l15, !tbaa !24
  %t338 = load i64, ptr %l16, !tbaa !24
  %t341 = icmp slt i64 %t337, %t338
  %t343 = xor i1 %t341, true
  br i1 %t343, label %bb119, label %bb120
bb119:
  br label %bb127
bb120:
  br label %bb121
bb121:
  %t345 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t345, ptr %l199, !tbaa !27
  %t346 = load i64, ptr %l15, !tbaa !24
  %t348 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr ptr, ptr %t349, i64 %t346
  %t351 = load ptr, ptr %t350, !tbaa !39
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t358 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t353, ptr %t351)
  store i1 %t358, ptr %l205
  br label %bb122
bb122:
  %t359 = load i1, ptr %l205, !tbaa !21
  br i1 %t359, label %bb123, label %bb124
bb123:
  store i1 true, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  %t361 = load i64, ptr %l15, !tbaa !24
  %t364 = add i64 %t361, 1
  store i64 %t364, ptr %l15, !tbaa !24
  br label %bb118
bb127:
  store i1 false, ptr %rv
  br label %ret
bb128:
  %t367 = load ptr, ptr %l1, !tbaa !29
  store ptr %t367, ptr %l211, !tbaa !29
  store i1 false, ptr %l212, !tbaa !21
  %t368 = load ptr, ptr %l211, !tbaa !29
  %t369 = icmp ne ptr %t368, null
  br i1 %t369, label %bb129, label %bb130
bb129:
  %t371 = load ptr, ptr %l211, !tbaa !29
  %t372 = load i64, ptr %t371, !range !{i64 0, i64 18}
  %t374 = icmp eq i64 %t372, 9
  store i1 %t374, ptr %l212, !tbaa !21
  br label %bb130
bb130:
  %t375 = load i1, ptr %l212, !tbaa !21
  br i1 %t375, label %bb131, label %bb132
bb131:
  %t376 = load ptr, ptr %l1, !tbaa !29
  %t378 = getelementptr { i64, [5 x i64] }, ptr %t376, i32 0, i32 1
  %t379 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t378, i32 0, i32 2
  %t380 = load i32, ptr %t379, !range !{i32 0, i32 54}
  store i32 %t380, ptr %l18
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t384 = getelementptr { i64, [5 x i64] }, ptr %t382, i32 0, i32 1
  %t385 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t384, i32 0, i32 3
  %t386 = load i32, ptr %t385, !range !{i32 0, i32 4}
  store i32 %t386, ptr %l19
  %t388 = load ptr, ptr %l1, !tbaa !29
  %t390 = getelementptr { i64, [5 x i64] }, ptr %t388, i32 0, i32 1
  %t391 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t390, i32 0, i32 4
  %t392 = load { i64, ptr }, ptr %t391
  store { i64, ptr } %t392, ptr %l20, !tbaa !27
  br label %bb133
bb132:
  br label %bb151
bb133:
  %t394 = load i32, ptr %l19, !range !{i32 0, i32 4}
  %t396 = trunc i64 1 to i32
  %t397 = icmp eq i32 %t394, %t396
  br i1 %t397, label %bb134, label %bb135
bb134:
  store i1 true, ptr %l223, !tbaa !21
  br label %bb137
bb135:
  %t399 = load i32, ptr %l18, !range !{i32 0, i32 54}
  %t401 = call i1 @compiler_2fcheck_2eeffectOp(i32 %t399)
  store i1 %t401, ptr %l225
  br label %bb136
bb136:
  %t402 = load i1, ptr %l225, !tbaa !21
  store i1 %t402, ptr %l223, !tbaa !21
  br label %bb137
bb137:
  %t403 = load i1, ptr %l223, !tbaa !21
  br i1 %t403, label %bb138, label %bb139
bb138:
  store i1 true, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  %t405 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t405, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t407 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t407, 0
  store i64 %t409, ptr %l23, !tbaa !24
  br label %bb141
bb141:
  %t411 = load i64, ptr %l22, !tbaa !24
  %t412 = load i64, ptr %l23, !tbaa !24
  %t415 = icmp slt i64 %t411, %t412
  %t417 = xor i1 %t415, true
  br i1 %t417, label %bb142, label %bb143
bb142:
  br label %bb150
bb143:
  br label %bb144
bb144:
  %t419 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t419, ptr %l234, !tbaa !27
  %t420 = load i64, ptr %l22, !tbaa !24
  %t422 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr ptr, ptr %t423, i64 %t420
  %t425 = load ptr, ptr %t424, !tbaa !39
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t432 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t427, ptr %t425)
  store i1 %t432, ptr %l240
  br label %bb145
bb145:
  %t433 = load i1, ptr %l240, !tbaa !21
  br i1 %t433, label %bb146, label %bb147
bb146:
  store i1 true, ptr %rv
  br label %ret
bb147:
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t435 = load i64, ptr %l22, !tbaa !24
  %t438 = add i64 %t435, 1
  store i64 %t438, ptr %l22, !tbaa !24
  br label %bb141
bb150:
  store i1 false, ptr %rv
  br label %ret
bb151:
  %t441 = load ptr, ptr %l1, !tbaa !29
  store ptr %t441, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t442 = load ptr, ptr %l246, !tbaa !29
  %t443 = icmp ne ptr %t442, null
  br i1 %t443, label %bb152, label %bb153
bb152:
  %t445 = load ptr, ptr %l246, !tbaa !29
  %t446 = load i64, ptr %t445, !range !{i64 0, i64 18}
  %t448 = icmp eq i64 %t446, 10
  store i1 %t448, ptr %l247, !tbaa !21
  br label %bb153
bb153:
  %t449 = load i1, ptr %l247, !tbaa !21
  br i1 %t449, label %bb154, label %bb155
bb154:
  %t450 = load ptr, ptr %l1, !tbaa !29
  %t452 = getelementptr { i64, [5 x i64] }, ptr %t450, i32 0, i32 1
  %t453 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t452, i32 0, i32 2
  %t454 = load ptr, ptr %t453
  store ptr %t454, ptr %l25, !tbaa !29
  br label %bb156
bb155:
  br label %bb169
bb156:
  %t456 = load ptr, ptr %l25, !tbaa !29
  %t458 = getelementptr %"compiler/typed:Slice", ptr %t456, i32 0, i32 3
  %t459 = load i32, ptr %t458, !range !{i32 0, i32 4}
  %t461 = trunc i64 1 to i32
  %t462 = icmp eq i32 %t459, %t461
  br i1 %t462, label %bb157, label %bb158
bb157:
  store i1 true, ptr %l255, !tbaa !21
  br label %bb160
bb158:
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t465 = load ptr, ptr %l25, !tbaa !29
  %t467 = getelementptr %"compiler/typed:Slice", ptr %t465, i32 0, i32 0
  %t468 = load ptr, ptr %t467, !tbaa !29
  %t471 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t464, ptr %t468, i1 false)
  store i1 %t471, ptr %l259
  br label %bb159
bb159:
  %t472 = load i1, ptr %l259, !tbaa !21
  store i1 %t472, ptr %l255, !tbaa !21
  br label %bb160
bb160:
  %t473 = load i1, ptr %l255, !tbaa !21
  br i1 %t473, label %bb161, label %bb162
bb161:
  store i1 true, ptr %l260, !tbaa !21
  br label %bb164
bb162:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load ptr, ptr %l25, !tbaa !29
  %t477 = getelementptr %"compiler/typed:Slice", ptr %t475, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !29
  %t482 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t474, ptr %t478)
  store i1 %t482, ptr %l265
  br label %bb163
bb163:
  %t483 = load i1, ptr %l265, !tbaa !21
  store i1 %t483, ptr %l260, !tbaa !21
  br label %bb164
bb164:
  %t484 = load i1, ptr %l260, !tbaa !21
  br i1 %t484, label %bb165, label %bb166
bb165:
  store i1 true, ptr %l266, !tbaa !21
  br label %bb168
bb166:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load ptr, ptr %l25, !tbaa !29
  %t488 = getelementptr %"compiler/typed:Slice", ptr %t486, i32 0, i32 2
  %t489 = load ptr, ptr %t488, !tbaa !29
  %t493 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t485, ptr %t489)
  store i1 %t493, ptr %l271
  br label %bb167
bb167:
  %t494 = load i1, ptr %l271, !tbaa !21
  store i1 %t494, ptr %l266, !tbaa !21
  br label %bb168
bb168:
  %t495 = load i1, ptr %l266, !tbaa !21
  store i1 %t495, ptr %rv
  br label %ret
bb169:
  %t496 = load ptr, ptr %l1, !tbaa !29
  store ptr %t496, ptr %l272, !tbaa !29
  store i1 false, ptr %l273, !tbaa !21
  %t497 = load ptr, ptr %l272, !tbaa !29
  %t498 = icmp ne ptr %t497, null
  br i1 %t498, label %bb170, label %bb171
bb170:
  %t500 = load ptr, ptr %l272, !tbaa !29
  %t501 = load i64, ptr %t500, !range !{i64 0, i64 18}
  %t503 = icmp eq i64 %t501, 11
  store i1 %t503, ptr %l273, !tbaa !21
  br label %bb171
bb171:
  %t504 = load i1, ptr %l273, !tbaa !21
  br i1 %t504, label %bb172, label %bb173
bb172:
  %t505 = load ptr, ptr %l1, !tbaa !29
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t507, i32 0, i32 2
  %t509 = load ptr, ptr %t508
  store ptr %t509, ptr %l26, !tbaa !29
  br label %bb174
bb173:
  br label %bb184
bb174:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load ptr, ptr %l26, !tbaa !29
  %t514 = getelementptr %"compiler/typed:Cond", ptr %t512, i32 0, i32 0
  %t515 = load ptr, ptr %t514, !tbaa !29
  %t519 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t511, ptr %t515)
  store i1 %t519, ptr %l282
  br label %bb175
bb175:
  %t520 = load i1, ptr %l282, !tbaa !21
  br i1 %t520, label %bb176, label %bb177
bb176:
  store i1 true, ptr %l283, !tbaa !21
  br label %bb179
bb177:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load ptr, ptr %l26, !tbaa !29
  %t524 = getelementptr %"compiler/typed:Cond", ptr %t522, i32 0, i32 1
  %t525 = load ptr, ptr %t524, !tbaa !29
  %t528 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t521, ptr %t525)
  store i1 %t528, ptr %l287
  br label %bb178
bb178:
  %t529 = load i1, ptr %l287, !tbaa !21
  store i1 %t529, ptr %l283, !tbaa !21
  br label %bb179
bb179:
  %t530 = load i1, ptr %l283, !tbaa !21
  br i1 %t530, label %bb180, label %bb181
bb180:
  store i1 true, ptr %l288, !tbaa !21
  br label %bb183
bb181:
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t532 = load ptr, ptr %l26, !tbaa !29
  %t534 = getelementptr %"compiler/typed:Cond", ptr %t532, i32 0, i32 2
  %t535 = load ptr, ptr %t534, !tbaa !29
  %t539 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t531, ptr %t535)
  store i1 %t539, ptr %l293
  br label %bb182
bb182:
  %t540 = load i1, ptr %l293, !tbaa !21
  store i1 %t540, ptr %l288, !tbaa !21
  br label %bb183
bb183:
  %t541 = load i1, ptr %l288, !tbaa !21
  store i1 %t541, ptr %rv
  br label %ret
bb184:
  %t542 = load ptr, ptr %l1, !tbaa !29
  store ptr %t542, ptr %l294, !tbaa !29
  store i1 false, ptr %l295, !tbaa !21
  %t543 = load ptr, ptr %l294, !tbaa !29
  %t544 = icmp ne ptr %t543, null
  br i1 %t544, label %bb185, label %bb186
bb185:
  %t546 = load ptr, ptr %l294, !tbaa !29
  %t547 = load i64, ptr %t546, !range !{i64 0, i64 18}
  %t549 = icmp eq i64 %t547, 12
  store i1 %t549, ptr %l295, !tbaa !21
  br label %bb186
bb186:
  %t550 = load i1, ptr %l295, !tbaa !21
  br i1 %t550, label %bb187, label %bb188
bb187:
  %t551 = load ptr, ptr %l1, !tbaa !29
  %t553 = getelementptr { i64, [5 x i64] }, ptr %t551, i32 0, i32 1
  %t554 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t553, i32 0, i32 2
  %t555 = load ptr, ptr %t554
  store ptr %t555, ptr %l27, !tbaa !29
  br label %bb189
bb188:
  br label %bb195
bb189:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load ptr, ptr %l27, !tbaa !29
  %t560 = getelementptr %"compiler/typed:Seq", ptr %t558, i32 0, i32 0
  %t561 = load { i64, ptr }, ptr %t560, !tbaa !27
  %t564 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %t557, { i64, ptr } %t561)
  store i1 %t564, ptr %l303
  br label %bb190
bb190:
  %t565 = load i1, ptr %l303, !tbaa !21
  br i1 %t565, label %bb191, label %bb192
bb191:
  store i1 true, ptr %l304, !tbaa !21
  br label %bb194
bb192:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load ptr, ptr %l27, !tbaa !29
  %t569 = getelementptr %"compiler/typed:Seq", ptr %t567, i32 0, i32 1
  %t570 = load ptr, ptr %t569, !tbaa !29
  %t573 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t566, ptr %t570)
  store i1 %t573, ptr %l308
  br label %bb193
bb193:
  %t574 = load i1, ptr %l308, !tbaa !21
  store i1 %t574, ptr %l304, !tbaa !21
  br label %bb194
bb194:
  %t575 = load i1, ptr %l304, !tbaa !21
  store i1 %t575, ptr %rv
  br label %ret
bb195:
  %t576 = load ptr, ptr %l1, !tbaa !29
  store ptr %t576, ptr %l309, !tbaa !29
  store i1 false, ptr %l310, !tbaa !21
  %t577 = load ptr, ptr %l309, !tbaa !29
  %t578 = icmp ne ptr %t577, null
  br i1 %t578, label %bb196, label %bb197
bb196:
  %t580 = load ptr, ptr %l309, !tbaa !29
  %t581 = load i64, ptr %t580, !range !{i64 0, i64 18}
  %t583 = icmp eq i64 %t581, 13
  store i1 %t583, ptr %l310, !tbaa !21
  br label %bb197
bb197:
  %t584 = load i1, ptr %l310, !tbaa !21
  br i1 %t584, label %bb198, label %bb199
bb198:
  %t585 = load ptr, ptr %l1, !tbaa !29
  %t587 = getelementptr { i64, [5 x i64] }, ptr %t585, i32 0, i32 1
  %t588 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t587, i32 0, i32 2
  %t589 = load ptr, ptr %t588
  store ptr %t589, ptr %l28, !tbaa !29
  br label %bb200
bb199:
  br label %bb222
bb200:
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t592 = load ptr, ptr %l28, !tbaa !29
  %t594 = getelementptr %"compiler/typed:Match", ptr %t592, i32 0, i32 0
  %t595 = load { i64, ptr }, ptr %t594, !tbaa !27
  %t598 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %t591, { i64, ptr } %t595)
  store i1 %t598, ptr %l318
  br label %bb201
bb201:
  %t599 = load i1, ptr %l318, !tbaa !21
  br i1 %t599, label %bb202, label %bb203
bb202:
  store i1 true, ptr %rv
  br label %ret
bb203:
  br label %bb204
bb204:
  %t601 = load ptr, ptr %l28, !tbaa !29
  %t603 = getelementptr %"compiler/typed:Match", ptr %t601, i32 0, i32 1
  %t604 = load { i64, ptr }, ptr %t603, !tbaa !27
  store { i64, ptr } %t604, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t606 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t606, 0
  store i64 %t608, ptr %l31, !tbaa !24
  br label %bb205
bb205:
  %t610 = load i64, ptr %l30, !tbaa !24
  %t611 = load i64, ptr %l31, !tbaa !24
  %t614 = icmp slt i64 %t610, %t611
  %t616 = xor i1 %t614, true
  br i1 %t616, label %bb206, label %bb207
bb206:
  br label %bb214
bb207:
  br label %bb208
bb208:
  %t618 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t618, ptr %l328, !tbaa !27
  %t619 = load i64, ptr %l30, !tbaa !24
  %t621 = getelementptr { i64, ptr }, ptr %l328, i32 0, i32 1
  %t622 = load ptr, ptr %t621, !tbaa !27
  %t623 = getelementptr ptr, ptr %t622, i64 %t619
  %t624 = load ptr, ptr %t623, !tbaa !39
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t630 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %t626, ptr %t624)
  store i1 %t630, ptr %l333
  br label %bb209
bb209:
  %t631 = load i1, ptr %l333, !tbaa !21
  br i1 %t631, label %bb210, label %bb211
bb210:
  store i1 true, ptr %rv
  br label %ret
bb211:
  br label %bb212
bb212:
  br label %bb213
bb213:
  %t633 = load i64, ptr %l30, !tbaa !24
  %t636 = add i64 %t633, 1
  store i64 %t636, ptr %l30, !tbaa !24
  br label %bb205
bb214:
  %t638 = load ptr, ptr %l28, !tbaa !29
  %t640 = getelementptr %"compiler/typed:Match", ptr %t638, i32 0, i32 2
  %t641 = load ptr, ptr %t640, !tbaa !29
  %t643 = icmp eq ptr %t641, null
  %t645 = xor i1 %t643, true
  br i1 %t645, label %bb215, label %bb216
bb215:
  %t647 = load ptr, ptr %l0, !tbaa !29
  store ptr %t647, ptr %l343, !tbaa !29
  %t648 = load ptr, ptr %l28, !tbaa !29
  %t650 = getelementptr %"compiler/typed:Match", ptr %t648, i32 0, i32 2
  %t651 = load ptr, ptr %t650, !tbaa !29
  %t653 = icmp eq ptr %t651, null
  br i1 %t653, label %bb217, label %bb218
bb216:
  store i1 false, ptr %l342, !tbaa !21
  br label %bb221
bb217:
  call void @__olang_check_failed(ptr @olang_loc_ad4dc9fe288360e2_6bae22496d237a26)
  unreachable
bb218:
  br label %bb219
bb219:
  %t655 = load ptr, ptr %l28, !tbaa !29
  %t657 = getelementptr %"compiler/typed:Match", ptr %t655, i32 0, i32 2
  %t658 = load ptr, ptr %t657, !tbaa !29
  %t659 = load ptr, ptr %l343, !tbaa !29
  %t661 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %t659, ptr %t658)
  store i1 %t661, ptr %l349
  br label %bb220
bb220:
  %t662 = load i1, ptr %l349, !tbaa !21
  store i1 %t662, ptr %l342, !tbaa !21
  br label %bb221
bb221:
  %t663 = load i1, ptr %l342, !tbaa !21
  store i1 %t663, ptr %rv
  br label %ret
bb222:
  %t664 = load ptr, ptr %l1, !tbaa !29
  store ptr %t664, ptr %l350, !tbaa !29
  store i1 false, ptr %l351, !tbaa !21
  %t665 = load ptr, ptr %l350, !tbaa !29
  %t666 = icmp ne ptr %t665, null
  br i1 %t666, label %bb223, label %bb224
bb223:
  %t668 = load ptr, ptr %l350, !tbaa !29
  %t669 = load i64, ptr %t668, !range !{i64 0, i64 18}
  %t671 = icmp eq i64 %t669, 14
  store i1 %t671, ptr %l351, !tbaa !21
  br label %bb224
bb224:
  %t672 = load i1, ptr %l351, !tbaa !21
  br i1 %t672, label %bb225, label %bb226
bb225:
  %t673 = load ptr, ptr %l1, !tbaa !29
  %t675 = getelementptr { i64, [5 x i64] }, ptr %t673, i32 0, i32 1
  %t676 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t675, i32 0, i32 2
  %t677 = load ptr, ptr %t676
  store ptr %t677, ptr %l33, !tbaa !29
  br label %bb227
bb226:
  br label %bb255
bb227:
  %t679 = load ptr, ptr %l33, !tbaa !29
  %t681 = getelementptr %"compiler/typed:Try", ptr %t679, i32 0, i32 2
  %t682 = load i1, ptr %t681, !tbaa !21
  br i1 %t682, label %bb228, label %bb229
bb228:
  store i1 true, ptr %l358, !tbaa !21
  br label %bb231
bb229:
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t685 = load ptr, ptr %l33, !tbaa !29
  %t687 = getelementptr %"compiler/typed:Try", ptr %t685, i32 0, i32 0
  %t688 = load ptr, ptr %t687, !tbaa !29
  %t691 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t684, ptr %t688)
  store i1 %t691, ptr %l362
  br label %bb230
bb230:
  %t692 = load i1, ptr %l362, !tbaa !21
  store i1 %t692, ptr %l358, !tbaa !21
  br label %bb231
bb231:
  %t693 = load i1, ptr %l358, !tbaa !21
  br i1 %t693, label %bb232, label %bb233
bb232:
  store i1 true, ptr %rv
  br label %ret
bb233:
  br label %bb234
bb234:
  %t695 = load ptr, ptr %l33, !tbaa !29
  %t697 = getelementptr %"compiler/typed:Try", ptr %t695, i32 0, i32 1
  %t698 = load { i64, ptr }, ptr %t697, !tbaa !27
  store { i64, ptr } %t698, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t700 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t702 = extractvalue { i64, ptr } %t700, 0
  store i64 %t702, ptr %l36, !tbaa !24
  br label %bb235
bb235:
  %t704 = load i64, ptr %l35, !tbaa !24
  %t705 = load i64, ptr %l36, !tbaa !24
  %t708 = icmp slt i64 %t704, %t705
  %t710 = xor i1 %t708, true
  br i1 %t710, label %bb236, label %bb237
bb236:
  br label %bb254
bb237:
  br label %bb238
bb238:
  %t712 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t712, ptr %l372, !tbaa !27
  %t713 = load i64, ptr %l35, !tbaa !24
  %t715 = getelementptr { i64, ptr }, ptr %l372, i32 0, i32 1
  %t716 = load ptr, ptr %t715, !tbaa !27
  %t717 = getelementptr ptr, ptr %t716, i64 %t713
  %t718 = load ptr, ptr %t717, !tbaa !39
  store ptr %t718, ptr %l37, !tbaa !29
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t721 = load ptr, ptr %l37, !tbaa !29
  %t723 = getelementptr %"compiler/typed:Clause", ptr %t721, i32 0, i32 3
  %t724 = load ptr, ptr %t723, !tbaa !29
  %t727 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %t720, ptr %t724)
  store i1 %t727, ptr %l378
  br label %bb239
bb239:
  %t728 = load i1, ptr %l378, !tbaa !21
  br i1 %t728, label %bb240, label %bb241
bb240:
  store i1 true, ptr %rv
  br label %ret
bb241:
  br label %bb242
bb242:
  %t730 = load ptr, ptr %l37, !tbaa !29
  %t732 = getelementptr %"compiler/typed:Clause", ptr %t730, i32 0, i32 4
  %t733 = load { i64, ptr }, ptr %t732, !tbaa !27
  store { i64, ptr } %t733, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t735 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t737 = extractvalue { i64, ptr } %t735, 0
  store i64 %t737, ptr %l40, !tbaa !24
  br label %bb243
bb243:
  %t739 = load i64, ptr %l39, !tbaa !24
  %t740 = load i64, ptr %l40, !tbaa !24
  %t743 = icmp slt i64 %t739, %t740
  %t745 = xor i1 %t743, true
  br i1 %t745, label %bb244, label %bb245
bb244:
  br label %bb252
bb245:
  br label %bb246
bb246:
  %t747 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t747, ptr %l388, !tbaa !27
  %t748 = load i64, ptr %l39, !tbaa !24
  %t750 = getelementptr { i64, ptr }, ptr %l388, i32 0, i32 1
  %t751 = load ptr, ptr %t750, !tbaa !27
  %t752 = getelementptr ptr, ptr %t751, i64 %t748
  %t753 = load ptr, ptr %t752, !tbaa !39
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t760 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t755, ptr %t753)
  store i1 %t760, ptr %l394
  br label %bb247
bb247:
  %t761 = load i1, ptr %l394, !tbaa !21
  br i1 %t761, label %bb248, label %bb249
bb248:
  store i1 true, ptr %rv
  br label %ret
bb249:
  br label %bb250
bb250:
  br label %bb251
bb251:
  %t763 = load i64, ptr %l39, !tbaa !24
  %t766 = add i64 %t763, 1
  store i64 %t766, ptr %l39, !tbaa !24
  br label %bb243
bb252:
  br label %bb253
bb253:
  %t768 = load i64, ptr %l35, !tbaa !24
  %t771 = add i64 %t768, 1
  store i64 %t771, ptr %l35, !tbaa !24
  br label %bb235
bb254:
  store i1 false, ptr %rv
  br label %ret
bb255:
  %t774 = load ptr, ptr %l1, !tbaa !29
  store ptr %t774, ptr %l403, !tbaa !29
  store i1 false, ptr %l404, !tbaa !21
  %t775 = load ptr, ptr %l403, !tbaa !29
  %t776 = icmp ne ptr %t775, null
  br i1 %t776, label %bb256, label %bb257
bb256:
  %t778 = load ptr, ptr %l403, !tbaa !29
  %t779 = load i64, ptr %t778, !range !{i64 0, i64 18}
  %t781 = icmp eq i64 %t779, 17
  store i1 %t781, ptr %l404, !tbaa !21
  br label %bb257
bb257:
  %t782 = load i1, ptr %l404, !tbaa !21
  br i1 %t782, label %bb258, label %bb259
bb258:
  %t783 = load ptr, ptr %l1, !tbaa !29
  %t785 = getelementptr { i64, [5 x i64] }, ptr %t783, i32 0, i32 1
  %t786 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t785, i32 0, i32 2
  %t787 = load ptr, ptr %t786
  store ptr %t787, ptr %l42, !tbaa !29
  br label %bb260
bb259:
  br label %bb262
bb260:
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = load ptr, ptr %l42, !tbaa !29
  %t794 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t789, ptr %t790)
  store i1 %t794, ptr %l412
  br label %bb261
bb261:
  %t795 = load i1, ptr %l412, !tbaa !21
  store i1 %t795, ptr %rv
  br label %ret
bb262:
  call void @__olang_check_failed(ptr @olang_loc_29ea0c7d0dcef6fa_322b22c08f06752e)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i32
  %l14 = alloca i1
  %l20 = alloca i32
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca i1
  %l36 = alloca ptr
  %l40 = alloca i64
  %l63 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t54 = alloca { i64, [4 x i64] }, align 8
  %t89 = alloca { i64, [3 x i64] }, align 8
  %t113 = alloca { i64, [4 x i64] }, align 8
  %t125 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l9
  br label %bb1
bb1:
  %t5 = load i32, ptr %l9, !tbaa !23
  store i32 %t5, ptr %l2, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l14
  br label %bb2
bb2:
  %t16 = load i1, ptr %l14, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t19, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t26, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i32 %t28, ptr %l20
  br label %bb6
bb6:
  %t29 = load i32, ptr %l20, !tbaa !23
  store i32 %t29, ptr %l3, !tbaa !23
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t30)
  store %"compiler/source:Span" %t32, ptr %l22
  br label %bb7
bb7:
  %t33 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t33, ptr %l4
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t35 = load ptr, ptr %l23, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load ptr, ptr %l23, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t42 = load i1, ptr %l24, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l4
  %t51 = load %"compiler/source:Span", ptr %l4
  %t52 = load i32, ptr %l3, !tbaa !23
  %t53 = load ptr, ptr %l5, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 0
  store i64 3, ptr %t55
  %t57 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t51, 0
  %t59 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t57, i32 %t52, 1
  %t61 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t59, ptr %t53, 2
  %t62 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t61, i64 0, 3
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t62, ptr %t63
  %t64 = load { i64, [4 x i64] }, ptr %t54
  %t66 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t64, ptr %t66
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t49, %"compiler/source:Span" %t50, ptr %t66)
  store ptr %t70, ptr %l36
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t71 = load ptr, ptr %l36, !tbaa !29
  store ptr %t71, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_57182574fbaa5aef_a841f6796e4dcc63)
  unreachable
bb19:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l4
  %t74 = load i32, ptr %l2, !tbaa !23
  %t78 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t72, %"compiler/source:Span" %t73, i32 %t74)
  store i64 %t78, ptr %l40
  br label %bb20
bb20:
  %t79 = load i64, ptr %l40, !tbaa !24
  store i64 %t79, ptr %l6, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 48
  %t83 = load %"compiler/source:Span", ptr %l4
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = trunc i64 %t84 to i32
  %t88 = load ptr, ptr %l1, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 0
  store i64 0, ptr %t90
  %t92 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t83, 0
  %t94 = insertvalue { %"compiler/source:Span", i32, ptr } %t92, i32 %t86, 1
  %t96 = insertvalue { %"compiler/source:Span", i32, ptr } %t94, ptr %t88, 2
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t96, ptr %t97
  %t98 = load { i64, [3 x i64] }, ptr %t89
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t98, ptr %t100
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t82, ptr %t100)
  br label %bb21
bb21:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l4
  %t105 = load %"compiler/source:Span", ptr %l4
  %t106 = load i32, ptr %l3, !tbaa !23
  %t107 = load %"compiler/source:Span", ptr %l4
  %t108 = load i32, ptr %l2, !tbaa !23
  %t109 = load i64, ptr %l6, !tbaa !24
  %t111 = trunc i64 %t109 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t113
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 0
  store i64 0, ptr %t114
  %t116 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t107, 0
  %t118 = insertvalue { %"compiler/source:Span", i32, i32 } %t116, i32 %t108, 1
  %t120 = insertvalue { %"compiler/source:Span", i32, i32 } %t118, i32 %t111, 2
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t120, ptr %t121
  %t122 = load { i64, [4 x i64] }, ptr %t113
  %t124 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t122, ptr %t124
  store { i64, [4 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 0
  store i64 3, ptr %t126
  %t128 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t105, 0
  %t130 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t128, i32 %t106, 1
  %t132 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t130, ptr %t124, 2
  %t133 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t132, i64 0, 3
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t133, ptr %t134
  %t135 = load { i64, [4 x i64] }, ptr %t125
  %t137 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t135, ptr %t137
  %t141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t103, %"compiler/source:Span" %t104, ptr %t137)
  store ptr %t141, ptr %l63
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t142 = load ptr, ptr %l63, !tbaa !29
  store ptr %t142, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrPath(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l17 = alloca i1
  %l24 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l42 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i64
  %l55 = alloca i1
  %l58 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i1
  %l62 = alloca i1
  %l64 = alloca ptr
  %l68 = alloca i1
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t19 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t9 = icmp ne i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i32, ptr %l2, !tbaa !23
  store i32 %t11, ptr %l12, !tbaa !23
  %t12 = icmp sge i64 1, 0
  br i1 %t12, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t14 = icmp sle i64 1, 2305843009213693951
  br i1 %t14, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_414cc8b7f33d3de6_fda2437ae6b3c3f2)
  unreachable
bb6:
  %t16 = mul i64 1, 4
  %t17 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t16)
  %t18 = load i32, ptr %l12, !tbaa !23
  store i64 0, ptr %t19
  br label %fill.20
fill.20:
  %t23 = load i64, ptr %t19
  %t24 = icmp slt i64 %t23, 1
  br i1 %t24, label %fillb.21, label %filld.22
fillb.21:
  %t25 = getelementptr i32, ptr %t17, i64 %t23
  store i32 %t18, ptr %t25
  %t26 = add i64 %t23, 1
  store i64 %t26, ptr %t19
  br label %fill.20
filld.22:
  %t27 = insertvalue { i64, ptr } undef, i64 1, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t17, 1
  store { i64, ptr } %t28, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_414cc8b7f33d3de6_fda2437ae6b3c3f2)
  unreachable
bb8:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = call i1 @compiler_2fcheck_2eisMember(ptr %v1, ptr %t30)
  store i1 %t32, ptr %l17
  br label %bb9
bb9:
  %t33 = load i1, ptr %l17, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = icmp sge i64 0, 0
  br i1 %t36, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  %t38 = icmp sle i64 0, 2305843009213693951
  br i1 %t38, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9722fccfe35ee7b_558e4c381c37f7e7)
  unreachable
bb14:
  %t40 = mul i64 0, 4
  %t41 = insertvalue { i64, ptr } undef, i64 0, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t42, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_9722fccfe35ee7b_558e4c381c37f7e7)
  unreachable
bb16:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t48 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowPath(ptr %v0, ptr %v1, ptr %v2, ptr %t44, ptr %t45)
  store { i64, ptr } %t48, ptr %l24
  br label %bb17
bb17:
  %t49 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t49, ptr %l3, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t54 = icmp slt i64 %t52, 2
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t58)
  store %"compiler/source:Span" %t60, ptr %l30
  br label %bb21
bb21:
  %t61 = load %"compiler/source:Span", ptr %l30
  store %"compiler/source:Span" %t61, ptr %l4
  %t62 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t63 = load i32, ptr %t62, !tbaa !23
  %t65 = sext i32 %t63 to i64
  %t67 = mul i64 %t65, 4294967296
  %t68 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t69 = load i32, ptr %t68, !tbaa !23
  %t71 = sext i32 %t69 to i64
  %t74 = add i64 %t67, %t71
  store i64 %t74, ptr %l5, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t76)
  store ptr %t78, ptr %l38
  br label %bb22
bb22:
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t81 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 63
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t81, i64 %t82)
  store i1 %t85, ptr %l42
  br label %bb23
bb23:
  %t86 = load i1, ptr %l42, !tbaa !21
  %t87 = xor i1 %t86, true
  br i1 %t87, label %bb24, label %bb25
bb24:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2equietPlace(ptr %v0, ptr %v1, ptr %v0, ptr %t89, ptr %t90)
  store ptr %t93, ptr %l46
  br label %bb26
bb25:
  br label %bb34
bb26:
  %t94 = load ptr, ptr %l46, !tbaa !29
  store ptr %t94, ptr %l6, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t95)
  store ptr %t97, ptr %l48
  br label %bb27
bb27:
  %t98 = load ptr, ptr %l48, !tbaa !29
  %t100 = getelementptr %"compiler/check:frame", ptr %t98, i32 0, i32 63
  store ptr %t100, ptr %l50, !tbaa !29
  %t101 = load i64, ptr %l5, !tbaa !24
  store i64 %t101, ptr %l51, !tbaa !24
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb28, label %bb29
bb28:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  store ptr %t113, ptr %l58, !tbaa !29
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t114)
  store i32 %t116, ptr %l60
  br label %bb30
bb29:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb32
bb30:
  %t117 = load ptr, ptr %l58, !tbaa !29
  %t118 = load i32, ptr %l60, !tbaa !23
  %t119 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t117, i32 %t118)
  store i1 %t119, ptr %l61
  br label %bb31
bb31:
  %t120 = load i1, ptr %l61, !tbaa !21
  store i1 %t120, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t121 = load ptr, ptr %l50, !tbaa !29
  %t122 = load i64, ptr %l51, !tbaa !24
  %t123 = load i1, ptr %l55, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t121, i64 %t122, i1 %t123)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t124)
  store ptr %t126, ptr %l64
  br label %bb35
bb35:
  %t127 = load ptr, ptr %l64, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 63
  %t130 = load i64, ptr %l5, !tbaa !24
  %t133 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t129, i64 %t130)
  %t134 = extractvalue { i32, i1 } %t133, 1
  %t135 = extractvalue { i32, i1 } %t133, 0
  store i32 %t135, ptr %l69
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb37, label %ok.137, !prof !99
ok.137:
  store i1 %t134, ptr %l68
  br label %bb36
bb36:
  %t138 = load i1, ptr %l68, !tbaa !21
  store i1 %t138, ptr %l62, !tbaa !21
  br label %bb39
bb37:
  br label %bb38
bb38:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb39
bb39:
  %t139 = load i1, ptr %l62, !tbaa !21
  br i1 %t139, label %bb40, label %bb41
bb40:
  %t140 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t140, ptr %l70, !tbaa !27
  br label %bb46
bb41:
  %t142 = icmp sge i64 0, 0
  br i1 %t142, label %bb42, label %bb43
bb42:
  %t144 = icmp sle i64 0, 2305843009213693951
  br i1 %t144, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_9c172245b700a898_5abd6adb0e722504)
  unreachable
bb44:
  %t146 = mul i64 0, 4
  %t147 = insertvalue { i64, ptr } undef, i64 0, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t148, ptr %l70, !tbaa !27
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_9c172245b700a898_5abd6adb0e722504)
  unreachable
bb46:
  %t150 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t150, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l47 = alloca i32
  %l49 = alloca i64
  %l51 = alloca i64
  %l56 = alloca i32
  %l61 = alloca i32
  %l67 = alloca i64
  %l70 = alloca i64
  %l91 = alloca { i64, ptr }
  %l94 = alloca i32
  %l106 = alloca { i64, ptr }
  %l109 = alloca i64
  %l112 = alloca i64
  %l118 = alloca i64
  %l123 = alloca ptr
  %l124 = alloca %"compiler/source:Span"
  %l125 = alloca i32
  %l126 = alloca i32
  %l127 = alloca ptr
  %l131 = alloca ptr
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca i32
  %l137 = alloca i32
  %l138 = alloca ptr
  %l144 = alloca ptr
  %l146 = alloca ptr
  %l152 = alloca i64
  %l158 = alloca i64
  %l161 = alloca i64
  %l180 = alloca i64
  %l184 = alloca ptr
  %l185 = alloca %"compiler/source:Span"
  %l186 = alloca i32
  %l187 = alloca i32
  %l188 = alloca ptr
  %l189 = alloca ptr
  %l190 = alloca %"compiler/source:Span"
  %l193 = alloca i32
  %l199 = alloca ptr
  %l201 = alloca ptr
  %l204 = alloca ptr
  %l214 = alloca ptr
  %l223 = alloca ptr
  %l230 = alloca ptr
  %l234 = alloca ptr
  %l244 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l32, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l35, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t13)
  store i32 %t16, ptr %l38
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l35, !tbaa !29
  %t18 = load i32, ptr %l38, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l39
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l32, !tbaa !29
  %t21 = load i32, ptr %l39, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t22, ptr %l40
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCode(ptr %v0, ptr %v1, ptr %v3, ptr %t24, ptr %t25)
  store ptr %t28, ptr %l43
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l43, !tbaa !29
  store ptr %t29, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t35, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i32 %t37, ptr %l47
  br label %bb5
bb5:
  %t38 = load i32, ptr %l47, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  store ptr null, ptr %l7, !tbaa !29
  store ptr %a3, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t41 = load i64, ptr %l9, !tbaa !24
  store i64 %t41, ptr %l49, !tbaa !24
  %t42 = load ptr, ptr %l8, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t42)
  store i64 %t44, ptr %l51
  br label %bb7
bb7:
  %t45 = load i64, ptr %l49, !tbaa !24
  %t46 = load i64, ptr %l51, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  br label %bb73
bb9:
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l8, !tbaa !29
  %t52 = load i64, ptr %l9, !tbaa !24
  %t55 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t51, i64 %t52)
  store i32 %t55, ptr %l56
  br label %bb11
bb11:
  %t56 = load i32, ptr %l56, !tbaa !23
  store i32 %t56, ptr %l10, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l10, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l61
  br label %bb12
bb12:
  %t67 = load i32, ptr %l61, !tbaa !23
  store i32 %t67, ptr %l11, !tbaa !23
  store i64 -1, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t72 = load i64, ptr %l14, !tbaa !24
  %t73 = load i64, ptr %l13, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb13, label %bb14
bb13:
  %t78 = load i64, ptr %l15, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb18
bb15:
  %t82 = load i64, ptr %l14, !tbaa !24
  %t83 = load i64, ptr %l13, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l15, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l15, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l70, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb17
bb17:
  %t98 = load i64, ptr %l70, !tbaa !24
  store i64 %t98, ptr %l67, !tbaa !24
  br label %bb18
bb18:
  %t99 = load i64, ptr %l67, !tbaa !24
  store i64 %t99, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb19
bb19:
  %t100 = load i64, ptr %l17, !tbaa !24
  %t101 = load i64, ptr %l16, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb20, label %bb21
bb20:
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t108 = load i64, ptr %l13, !tbaa !24
  %t109 = load i64, ptr %l17, !tbaa !24
  %t110 = load i64, ptr %l15, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l18, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t124, ptr %l91, !tbaa !27
  %t125 = load i64, ptr %l18, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i32, ptr %t128, i64 %t125
  %t130 = load i32, ptr %t129, !tbaa !33
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t123, i32 %t130)
  store i32 %t133, ptr %l94
  br label %bb23
bb23:
  %t134 = load i32, ptr %l11, !tbaa !23
  %t135 = load i32, ptr %l94, !tbaa !23
  %t137 = icmp eq i32 %t135, %t134
  br i1 %t137, label %bb24, label %bb25
bb24:
  %t139 = load i64, ptr %l18, !tbaa !24
  store i64 %t139, ptr %l12, !tbaa !24
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t141 = load i64, ptr %l17, !tbaa !24
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %l17, !tbaa !24
  br label %bb19
bb28:
  %t146 = load i64, ptr %l12, !tbaa !24
  %t148 = icmp slt i64 %t146, 0
  br i1 %t148, label %bb29, label %bb30
bb29:
  br label %bb72
bb30:
  br label %bb31
bb31:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  %t156 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t156, ptr %l106, !tbaa !27
  %t157 = load i64, ptr %l12, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  %t165 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t155, i32 %t162)
  store i64 %t165, ptr %l109
  br label %bb32
bb32:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l11, !tbaa !23
  %t170 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %t166, i32 %t167)
  store i64 %t170, ptr %l112
  br label %bb33
bb33:
  %t171 = load i64, ptr %l109, !tbaa !65
  %t172 = load i64, ptr %l112, !tbaa !65
  %t173 = and i64 %t171, %t172
  store i64 %t173, ptr %l19, !tbaa !65
  store ptr null, ptr %l20, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = load i32, ptr %l10, !tbaa !23
  %t184 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t180, i32 %t181)
  store i64 %t184, ptr %l118
  br label %bb34
bb34:
  %t185 = load i64, ptr %l19, !tbaa !65
  %t186 = load i64, ptr %l118, !tbaa !65
  %t188 = and i64 %t186, %t185
  %t189 = load i64, ptr %l19, !tbaa !65
  %t192 = icmp eq i64 %t188, %t189
  br i1 %t192, label %bb35, label %bb36
bb35:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l123, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t195, ptr %l124
  %t196 = load i32, ptr %l6, !tbaa !23
  store i32 %t196, ptr %l125, !tbaa !23
  store i32 9, ptr %l126
  %t197 = load ptr, ptr %l5, !tbaa !29
  store ptr %t197, ptr %l127, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l1
  %t200 = load i32, ptr %l6, !tbaa !23
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t198, %"compiler/source:Span" %t199, i32 %t200, i64 16)
  store ptr %t204, ptr %l131
  br label %bb37
bb36:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 2
  %t211 = load i32, ptr %l10, !tbaa !23
  %t214 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t210, i32 %t211)
  store i64 %t214, ptr %l152
  br label %bb41
bb37:
  %t215 = load ptr, ptr %l131, !tbaa !29
  %t216 = load ptr, ptr %l123, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l124
  %t218 = load i32, ptr %l125, !tbaa !23
  %t219 = load i32, ptr %l126, !range !{i32 0, i32 54}
  %t220 = load ptr, ptr %l127, !tbaa !29
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v0, ptr %t216, %"compiler/source:Span" %t217, i32 %t218, i32 %t219, ptr %t220, ptr %t215)
  store ptr %t222, ptr %l133
  br label %bb38
bb38:
  %t223 = load ptr, ptr %l133, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l134, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t225, ptr %l135
  %t226 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t226, ptr %l136, !tbaa !23
  store i32 13, ptr %l137
  store ptr %t223, ptr %l138, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l1
  %t230 = load i32, ptr %l6, !tbaa !23
  %t231 = load i64, ptr %l12, !tbaa !24
  %t233 = add i64 %t231, 1
  %t238 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t228, %"compiler/source:Span" %t229, i32 %t230, i64 %t233)
  store ptr %t238, ptr %l144
  br label %bb39
bb39:
  %t239 = load ptr, ptr %l144, !tbaa !29
  %t240 = load ptr, ptr %l134, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l135
  %t242 = load i32, ptr %l136, !tbaa !23
  %t243 = load i32, ptr %l137, !range !{i32 0, i32 54}
  %t244 = load ptr, ptr %l138, !tbaa !29
  %t246 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t240, %"compiler/source:Span" %t241, i32 %t242, i32 %t243, ptr %t244, ptr %t239)
  store ptr %t246, ptr %l146
  br label %bb40
bb40:
  %t247 = load ptr, ptr %l146, !tbaa !29
  store ptr %t247, ptr %l20, !tbaa !29
  br label %bb64
bb41:
  %t249 = load i64, ptr %l19, !tbaa !65
  %t250 = load i64, ptr %l152, !tbaa !65
  %t252 = and i64 %t250, %t249
  store i64 %t252, ptr %l22, !tbaa !65
  store i64 0, ptr %l23, !tbaa !24
  store i64 64, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t254 = load i64, ptr %l24, !tbaa !24
  %t255 = load i64, ptr %l23, !tbaa !24
  %t258 = icmp sgt i64 %t254, %t255
  br i1 %t258, label %bb42, label %bb43
bb42:
  %t260 = load i64, ptr %l25, !tbaa !24
  %t262 = icmp sgt i64 %t260, 0
  br i1 %t262, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l158, !tbaa !24
  br label %bb47
bb44:
  %t264 = load i64, ptr %l24, !tbaa !24
  %t265 = load i64, ptr %l23, !tbaa !24
  %t268 = sub i64 %t264, %t265
  %t269 = load i64, ptr %l25, !tbaa !24
  %t272 = add i64 %t268, %t269
  %t274 = sub i64 %t272, 1
  %t275 = load i64, ptr %l25, !tbaa !24
  %t278 = sdiv i64 %t274, %t275
  store i64 %t278, ptr %l161, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb46
bb46:
  %t280 = load i64, ptr %l161, !tbaa !24
  store i64 %t280, ptr %l158, !tbaa !24
  br label %bb47
bb47:
  %t281 = load i64, ptr %l158, !tbaa !24
  store i64 %t281, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb48
bb48:
  %t282 = load i64, ptr %l27, !tbaa !24
  %t283 = load i64, ptr %l26, !tbaa !24
  %t286 = icmp slt i64 %t282, %t283
  %t288 = xor i1 %t286, true
  br i1 %t288, label %bb49, label %bb50
bb49:
  br label %bb63
bb50:
  br label %bb51
bb51:
  %t290 = load i64, ptr %l23, !tbaa !24
  %t291 = load i64, ptr %l27, !tbaa !24
  %t292 = load i64, ptr %l25, !tbaa !24
  %t295 = mul i64 %t291, %t292
  %t298 = add i64 %t290, %t295
  store i64 %t298, ptr %l28, !tbaa !24
  %t300 = load i64, ptr %l22, !tbaa !65
  %t301 = load i64, ptr %l28, !tbaa !24
  store i64 %t301, ptr %l180, !tbaa !24
  %t302 = load i64, ptr %l180, !tbaa !24
  %t303 = load i64, ptr %l180, !tbaa !24
  %t304 = shl i64 1, %t303
  %t307 = and i64 %t300, %t304
  %t309 = icmp eq i64 %t307, 0
  br i1 %t309, label %bb52, label %bb53
bb52:
  br label %bb62
bb53:
  br label %bb54
bb54:
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l184, !tbaa !29
  %t312 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t312, ptr %l185
  %t313 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t313, ptr %l186, !tbaa !23
  store i32 13, ptr %l187
  %t314 = load ptr, ptr %l5, !tbaa !29
  store ptr %t314, ptr %l188, !tbaa !29
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l189, !tbaa !29
  %t316 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t316, ptr %l190
  %t317 = load ptr, ptr %l5, !tbaa !29
  %t320 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t317)
  store i32 %t320, ptr %l193
  br label %bb55
bb55:
  %t321 = load i64, ptr %l12, !tbaa !24
  %t323 = add i64 %t321, 1
  %t325 = shl i64 %t323, 16
  %t326 = load i64, ptr %l28, !tbaa !24
  %t329 = or i64 %t325, %t326
  %t330 = load ptr, ptr %l189, !tbaa !29
  %t331 = load %"compiler/source:Span", ptr %l190
  %t332 = load i32, ptr %l193, !tbaa !23
  %t334 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t330, %"compiler/source:Span" %t331, i32 %t332, i64 %t329)
  store ptr %t334, ptr %l199
  br label %bb56
bb56:
  %t335 = load ptr, ptr %l199, !tbaa !29
  %t336 = load ptr, ptr %l184, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l185
  %t338 = load i32, ptr %l186, !tbaa !23
  %t339 = load i32, ptr %l187, !range !{i32 0, i32 54}
  %t340 = load ptr, ptr %l188, !tbaa !29
  %t342 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v0, ptr %t336, %"compiler/source:Span" %t337, i32 %t338, i32 %t339, ptr %t340, ptr %t335)
  store ptr %t342, ptr %l201
  br label %bb57
bb57:
  %t343 = load ptr, ptr %l201, !tbaa !29
  store ptr %t343, ptr %l29, !tbaa !29
  %t344 = load ptr, ptr %l20, !tbaa !29
  %t346 = icmp eq ptr %t344, null
  br i1 %t346, label %bb58, label %bb59
bb58:
  %t348 = load ptr, ptr %l29, !tbaa !29
  store ptr %t348, ptr %l204, !tbaa !29
  br label %bb61
bb59:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load %"compiler/source:Span", ptr %l1
  %t353 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t354 = load ptr, ptr %l20, !tbaa !29
  %t355 = load ptr, ptr %l29, !tbaa !29
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t351, %"compiler/source:Span" %t352, i32 %t353, i32 11, ptr %t354, ptr %t355)
  store ptr %t363, ptr %l214
  br label %bb60
bb60:
  %t364 = load ptr, ptr %l214, !tbaa !29
  store ptr %t364, ptr %l204, !tbaa !29
  br label %bb61
bb61:
  %t366 = load ptr, ptr %l204, !tbaa !29
  store ptr %t366, ptr %l20, !tbaa !29
  br label %bb62
bb62:
  %t367 = load i64, ptr %l27, !tbaa !24
  %t370 = add i64 %t367, 1
  store i64 %t370, ptr %l27, !tbaa !24
  br label %bb48
bb63:
  br label %bb64
bb64:
  %t372 = load ptr, ptr %l20, !tbaa !29
  %t374 = icmp eq ptr %t372, null
  br i1 %t374, label %bb65, label %bb66
bb65:
  br label %bb72
bb66:
  br label %bb67
bb67:
  %t376 = load ptr, ptr %l7, !tbaa !29
  %t378 = icmp eq ptr %t376, null
  br i1 %t378, label %bb68, label %bb69
bb68:
  %t380 = load ptr, ptr %l20, !tbaa !29
  store ptr %t380, ptr %l223, !tbaa !29
  br label %bb71
bb69:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  %t385 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t386 = load ptr, ptr %l7, !tbaa !29
  store ptr %t386, ptr %l230, !tbaa !29
  %t387 = load ptr, ptr %l20, !tbaa !29
  %t389 = load ptr, ptr %l230, !tbaa !29
  %t390 = call ptr @__olang_scope_of(ptr %t389, ptr null)
  %t391 = call ptr @__olang_scope_hold(ptr %t390)
  %t392 = ptrtoint ptr %t391 to i64
  %t394 = inttoptr i64 %t392 to ptr
  %t399 = load ptr, ptr %l230, !tbaa !29
  %t401 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t394, ptr %v0, ptr %v3, ptr %t383, %"compiler/source:Span" %t384, i32 %t385, i32 11, ptr %t399, ptr %t387)
  store ptr %t401, ptr %l234
  br label %bb70
bb70:
  %t402 = load ptr, ptr %l234, !tbaa !29
  store ptr %t402, ptr %l223, !tbaa !29
  br label %bb71
bb71:
  %t404 = load ptr, ptr %l223, !tbaa !29
  store ptr %t404, ptr %l7, !tbaa !29
  br label %bb72
bb72:
  %t405 = load i64, ptr %l9, !tbaa !24
  %t408 = add i64 %t405, 1
  store i64 %t408, ptr %l9, !tbaa !24
  br label %bb6
bb73:
  %t410 = load ptr, ptr %l7, !tbaa !29
  %t412 = icmp eq ptr %t410, null
  br i1 %t412, label %bb74, label %bb75
bb74:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load %"compiler/source:Span", ptr %l1
  %t416 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t420 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t414, %"compiler/source:Span" %t415, i32 %t416, i64 0)
  store ptr %t420, ptr %l244
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_scope_close(ptr %s0)
  %t421 = load ptr, ptr %l244, !tbaa !29
  store ptr %t421, ptr %rv
  br label %ret
bb77:
  %t422 = load ptr, ptr %l7, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t422, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l30 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca i64
  %l42 = alloca i64
  %l46 = alloca i64
  %l51 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca %"compiler/source:Span"
  %l60 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca i64
  %l67 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/diagmsg:Msg"
  %l76 = alloca i64
  %l83 = alloca i1
  %l87 = alloca i1
  %l92 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l97 = alloca %"compiler/source:Span"
  %l101 = alloca %"compiler/diagmsg:Msg"
  %l102 = alloca i64
  %l110 = alloca i64
  %l112 = alloca i64
  %l117 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i32
  %l136 = alloca i64
  %l139 = alloca i64
  %l158 = alloca { i64, ptr }
  %l162 = alloca i32
  %l169 = alloca { i64, ptr }
  %l172 = alloca i64
  %l181 = alloca { i64, ptr }
  %l182 = alloca i64
  %l184 = alloca ptr
  %l186 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l192 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t230 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sge i64 0, 0
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t7 = icmp sle i64 0, 2305843009213693951
  br i1 %t7, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb5:
  %t9 = mul i64 0, 4
  %t10 = insertvalue { i64, ptr } undef, i64 0, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t11, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb7:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l30
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l30, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Func", ptr %t21, i32 0, i32 2
  %t26 = load i32, ptr %t25, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t22, i32 %t26)
  store { i64, ptr } %t29, ptr %l34
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %s0, ptr %t34, i64 %t35)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l38
  br label %bb10
bb10:
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l6
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t41, ptr %l40
  br label %bb11
bb11:
  %t42 = load i64, ptr %l40, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t43)
  store i64 %t45, ptr %l42
  br label %bb12
bb12:
  %t46 = load i64, ptr %l42, !tbaa !24
  store i64 %t46, ptr %l8, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarIndex(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l46
  br label %bb13
bb13:
  %t55 = load i64, ptr %l46, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = icmp sgt i64 %t58, %t59
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t66 = icmp slt i64 %t64, 0
  store i1 %t66, ptr %l51, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb16
bb16:
  %t68 = load i1, ptr %l51, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l54, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t70, ptr %l55, !tbaa !27
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 %t71
  %t76 = load ptr, ptr %t75, !tbaa !39
  %t78 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t76)
  store %"compiler/source:Span" %t78, ptr %l58
  br label %bb19
bb18:
  br label %bb26
bb19:
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrSetArgUnwanted(ptr %v0, ptr %v0, { i64, ptr } %t79)
  store %"compiler/diagmsg:Msg" %t81, ptr %l60
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l54, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l58
  %t84 = load %"compiler/diagmsg:Msg", ptr %l60
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t82, %"compiler/source:Span" %t83, %"compiler/diagmsg:Msg" %t84)
  store i64 %t85, ptr %l61
  br label %bb21
bb21:
  %t86 = icmp sge i64 0, 0
  br i1 %t86, label %bb22, label %bb23
bb22:
  %t88 = icmp sle i64 0, 2305843009213693951
  br i1 %t88, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb24:
  %t90 = mul i64 0, 4
  %t91 = insertvalue { i64, ptr } undef, i64 0, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb26:
  %t94 = load i64, ptr %l7, !tbaa !24
  %t96 = icmp eq i64 %t94, 0
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t100 = icmp sgt i64 %t98, 0
  store i1 %t100, ptr %l67, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb29
bb29:
  %t102 = load i1, ptr %l67, !tbaa !21
  br i1 %t102, label %bb30, label %bb31
bb30:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l70, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t104, ptr %l71, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 0
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t110 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t108)
  store %"compiler/source:Span" %t110, ptr %l73
  br label %bb32
bb31:
  br label %bb39
bb32:
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t113 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v0, { i64, ptr } %t111)
  store %"compiler/diagmsg:Msg" %t113, ptr %l75
  br label %bb33
bb33:
  %t114 = load ptr, ptr %l70, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l73
  %t116 = load %"compiler/diagmsg:Msg", ptr %l75
  %t117 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t114, %"compiler/source:Span" %t115, %"compiler/diagmsg:Msg" %t116)
  store i64 %t117, ptr %l76
  br label %bb34
bb34:
  %t118 = icmp sge i64 0, 0
  br i1 %t118, label %bb35, label %bb36
bb35:
  %t120 = icmp sle i64 0, 2305843009213693951
  br i1 %t120, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb37:
  %t122 = mul i64 0, 4
  %t123 = insertvalue { i64, ptr } undef, i64 0, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t124, ptr %rv
  br label %ret
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb39:
  %t126 = load i64, ptr %l7, !tbaa !24
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = icmp ne i64 %t126, %t127
  br i1 %t130, label %bb40, label %bb41
bb40:
  %t132 = load i64, ptr %l8, !tbaa !24
  %t133 = load i64, ptr %l7, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  br i1 %t136, label %bb42, label %bb43
bb41:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb46
bb42:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l1, !tbaa !24
  %t140 = load i64, ptr %l8, !tbaa !24
  %t145 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultsFrom(ptr %v0, ptr %s0, ptr %t138, i64 %t139, ptr %l6, i64 %t140)
  store i1 %t145, ptr %l92
  br label %bb44
bb43:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb45
bb44:
  %t146 = load i1, ptr %l92, !tbaa !21
  store i1 %t146, ptr %l87, !tbaa !21
  br label %bb45
bb45:
  %t147 = load i1, ptr %l87, !tbaa !21
  %t148 = xor i1 %t147, true
  store i1 %t148, ptr %l83, !tbaa !21
  br label %bb46
bb46:
  %t150 = load i1, ptr %l83, !tbaa !21
  br i1 %t150, label %bb47, label %bb48
bb47:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l94, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t152, ptr %l95, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr ptr, ptr %t154, i64 0
  %t156 = load ptr, ptr %t155, !tbaa !39
  %t158 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t156)
  store %"compiler/source:Span" %t158, ptr %l97
  br label %bb49
bb48:
  br label %bb56
bb49:
  %t159 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t160 = load i64, ptr %l7, !tbaa !24
  %t161 = load i64, ptr %l8, !tbaa !24
  %t165 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v0, { i64, ptr } %t159, i64 %t160, i64 %t161)
  store %"compiler/diagmsg:Msg" %t165, ptr %l101
  br label %bb50
bb50:
  %t166 = load ptr, ptr %l94, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l97
  %t168 = load %"compiler/diagmsg:Msg", ptr %l101
  %t169 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t166, %"compiler/source:Span" %t167, %"compiler/diagmsg:Msg" %t168)
  store i64 %t169, ptr %l102
  br label %bb51
bb51:
  %t170 = icmp sge i64 0, 0
  br i1 %t170, label %bb52, label %bb53
bb52:
  %t172 = icmp sle i64 0, 2305843009213693951
  br i1 %t172, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_c902484ee6860410_648a649019eab164)
  unreachable
bb54:
  %t174 = mul i64 0, 4
  %t175 = insertvalue { i64, ptr } undef, i64 0, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t176, ptr %rv
  br label %ret
bb55:
  call void @__olang_check_failed(ptr @olang_loc_c902484ee6860410_648a649019eab164)
  unreachable
bb56:
  %t178 = load i64, ptr %l8, !tbaa !24
  store i64 %t178, ptr %l7, !tbaa !24
  %t180 = load i64, ptr %l9, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l10, !tbaa !24
  store ptr %l6, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb57
bb57:
  %t185 = load i64, ptr %l12, !tbaa !24
  store i64 %t185, ptr %l110, !tbaa !24
  %t186 = load ptr, ptr %l11, !tbaa !29
  %t188 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t186)
  store i64 %t188, ptr %l112
  br label %bb58
bb58:
  %t189 = load i64, ptr %l110, !tbaa !24
  %t190 = load i64, ptr %l112, !tbaa !24
  %t191 = icmp slt i64 %t189, %t190
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb59, label %bb60
bb59:
  br label %bb67
bb60:
  br label %bb61
bb61:
  %t195 = load ptr, ptr %l11, !tbaa !29
  %t196 = load i64, ptr %l12, !tbaa !24
  %t199 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t195, i64 %t196)
  store i64 %t199, ptr %l117
  br label %bb62
bb62:
  %t200 = load i64, ptr %l117, !tbaa !24
  store i64 %t200, ptr %l13, !tbaa !24
  %t201 = load i64, ptr %l13, !tbaa !24
  %t203 = add i64 %t201, 1
  %t204 = load i64, ptr %l10, !tbaa !24
  %t207 = icmp sgt i64 %t203, %t204
  br i1 %t207, label %bb63, label %bb64
bb63:
  %t209 = load i64, ptr %l13, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l10, !tbaa !24
  br label %bb65
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t213 = load i64, ptr %l12, !tbaa !24
  %t216 = add i64 %t213, 1
  store i64 %t216, ptr %l12, !tbaa !24
  br label %bb57
bb67:
  %t218 = load i64, ptr %l10, !tbaa !24
  store i64 %t218, ptr %l127, !tbaa !24
  %t219 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t219, ptr %l128, !tbaa !23
  %t220 = load i64, ptr %l127, !tbaa !24
  %t221 = icmp sge i64 %t220, 0
  br i1 %t221, label %bb68, label %bb69
bb68:
  %t223 = load i64, ptr %l127, !tbaa !24
  %t224 = icmp sle i64 %t223, 2305843009213693951
  br i1 %t224, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_e4324c4b30f6563f_ec149b7f01d5683b)
  unreachable
bb70:
  %t226 = load i64, ptr %l127, !tbaa !24
  %t227 = mul i64 %t226, 4
  %t228 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t227)
  %t229 = load i32, ptr %l128, !tbaa !23
  store i64 0, ptr %t230
  br label %fill.231
fill.231:
  %t234 = load i64, ptr %t230
  %t235 = icmp slt i64 %t234, %t226
  br i1 %t235, label %fillb.232, label %filld.233
fillb.232:
  %t236 = getelementptr i32, ptr %t228, i64 %t234
  store i32 %t229, ptr %t236
  %t237 = add i64 %t234, 1
  store i64 %t237, ptr %t230
  br label %fill.231
filld.233:
  %t238 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t228, 1
  store { i64, ptr } %t239, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t241 = load i64, ptr %l7, !tbaa !24
  store i64 %t241, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t243 = load i64, ptr %l16, !tbaa !24
  %t244 = load i64, ptr %l15, !tbaa !24
  %t247 = icmp sgt i64 %t243, %t244
  br i1 %t247, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_e4324c4b30f6563f_ec149b7f01d5683b)
  unreachable
bb72:
  %t249 = load i64, ptr %l17, !tbaa !24
  %t251 = icmp sgt i64 %t249, 0
  br i1 %t251, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb77
bb74:
  %t253 = load i64, ptr %l16, !tbaa !24
  %t254 = load i64, ptr %l15, !tbaa !24
  %t257 = sub i64 %t253, %t254
  %t258 = load i64, ptr %l17, !tbaa !24
  %t261 = add i64 %t257, %t258
  %t263 = sub i64 %t261, 1
  %t264 = load i64, ptr %l17, !tbaa !24
  %t267 = sdiv i64 %t263, %t264
  store i64 %t267, ptr %l139, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l139, !tbaa !24
  br label %bb76
bb76:
  %t269 = load i64, ptr %l139, !tbaa !24
  store i64 %t269, ptr %l136, !tbaa !24
  br label %bb77
bb77:
  %t270 = load i64, ptr %l136, !tbaa !24
  store i64 %t270, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb78
bb78:
  %t271 = load i64, ptr %l19, !tbaa !24
  %t272 = load i64, ptr %l18, !tbaa !24
  %t275 = icmp slt i64 %t271, %t272
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb79, label %bb80
bb79:
  br label %bb92
bb80:
  br label %bb81
bb81:
  %t279 = load i64, ptr %l15, !tbaa !24
  %t280 = load i64, ptr %l19, !tbaa !24
  %t281 = load i64, ptr %l17, !tbaa !24
  %t284 = mul i64 %t280, %t281
  %t287 = add i64 %t279, %t284
  store i64 %t287, ptr %l20, !tbaa !24
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t290, ptr %l158, !tbaa !27
  %t291 = load i64, ptr %l20, !tbaa !24
  %t293 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr ptr, ptr %t294, i64 %t291
  %t296 = load ptr, ptr %t295, !tbaa !39
  %t300 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t289, ptr %t296)
  store i32 %t300, ptr %l162
  br label %bb82
bb82:
  %t301 = load i32, ptr %l162, !tbaa !23
  store i32 %t301, ptr %l21, !tbaa !23
  %t302 = load i32, ptr %l21, !tbaa !23
  %t303 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t306 = icmp eq i32 %t302, %t303
  br i1 %t306, label %bb83, label %bb84
bb83:
  %t308 = icmp sge i64 0, 0
  br i1 %t308, label %bb85, label %bb86
bb84:
  br label %bb89
bb85:
  %t310 = icmp sle i64 0, 2305843009213693951
  br i1 %t310, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6)
  unreachable
bb87:
  %t312 = mul i64 0, 4
  %t313 = insertvalue { i64, ptr } undef, i64 0, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t314, ptr %rv
  br label %ret
bb88:
  call void @__olang_check_failed(ptr @olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6)
  unreachable
bb89:
  %t316 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t316, ptr %l169, !tbaa !27
  %t317 = load i64, ptr %l20, !tbaa !24
  %t320 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t317)
  store i64 %t320, ptr %l172
  br label %bb90
bb90:
  %t321 = load i32, ptr %l21, !tbaa !23
  %t323 = load i64, ptr %l172, !tbaa !24
  %t324 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr i32, ptr %t325, i64 %t323
  store i32 %t321, ptr %t326, !tbaa !33
  br label %bb91
bb91:
  %t327 = load i64, ptr %l19, !tbaa !24
  %t330 = add i64 %t327, 1
  store i64 %t330, ptr %l19, !tbaa !24
  br label %bb78
bb92:
  %t332 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t332, 0
  %t335 = load i64, ptr %l8, !tbaa !24
  %t338 = icmp sgt i64 %t334, %t335
  br i1 %t338, label %bb93, label %bb94
bb93:
  %t340 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t340, ptr %l181, !tbaa !27
  %t341 = load i64, ptr %l9, !tbaa !24
  store i64 %t341, ptr %l182, !tbaa !24
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/check:Checker", ptr %t342, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !29
  store ptr %t345, ptr %l184, !tbaa !29
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t346)
  store ptr %t348, ptr %l186
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t349 = load ptr, ptr %l186, !tbaa !29
  %t351 = getelementptr %"compiler/check:frame", ptr %t349, i32 0, i32 4
  %t352 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t352, ptr %l189, !tbaa !27
  %t353 = load i64, ptr %l8, !tbaa !24
  %t355 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !27
  %t357 = getelementptr ptr, ptr %t356, i64 %t353
  %t358 = load ptr, ptr %t357, !tbaa !39
  %t359 = load ptr, ptr %l184, !tbaa !29
  %t362 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsArgOf(ptr %v0, ptr %v0, ptr %v1, ptr %t359, ptr %t351, ptr %t358)
  store i32 %t362, ptr %l192
  br label %bb96
bb96:
  %t363 = load i32, ptr %l192, !tbaa !23
  %t364 = load i64, ptr %l182, !tbaa !24
  %t365 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr i32, ptr %t366, i64 %t364
  store i32 %t363, ptr %t367, !tbaa !33
  br label %bb97
bb97:
  %t368 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t368, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/check:factsCopy" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsCopied(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l18 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l32 = alloca i64
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l46 = alloca %"compiler/check:factsCopy"
  %rv = alloca %"compiler/check:factsCopy"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = call ptr @__olang_scope_hold(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3afactsCopy_2e0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = call ptr @__olang_region_make(ptr %v1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 50
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l8
  %t16 = load i64, ptr %l4
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  store i64 %t19, ptr %l9, !tbaa !24
  %t20 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2e0
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l4
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_region_make_part(ptr %t23)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l9, !tbaa !24
  br label %bb5
bb5:
  %t26 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l11, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l12, !tbaa !24
  %t30 = load i64, ptr %l12, !tbaa !24
  %t31 = mul i64 %t30, 48
  %t32 = load i64, ptr %l9
  %t33 = inttoptr i64 %t32 to ptr
  %t34 = call ptr @__olang_held_alloc(ptr %t33, i64 %t31)
  %t35 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l13, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l12, !tbaa !24
  %t42 = mul i64 %t41, 48
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t44 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8, i32 0, i32 0
  store { i64, ptr } %t43, ptr %t44, !tbaa !27
  %t45 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2e0
  br i1 %t45, label %bb6, label %bb7
bb6:
  %t47 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  %t51 = icmp eq i64 %t49, 0
  br i1 %t51, label %bb8, label %bb9
bb7:
  %t53 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3afactsCopy_2e0
  br i1 %t53, label %bb10, label %bb11
bb8:
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t55, !tbaa !27
  br label %bb9
bb9:
  %t56 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8, i32 0, i32 0
  %t57 = load i64, ptr %l9
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = load { i64, ptr }, ptr %t56
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = call ptr @__olang_region_or(ptr %t60, ptr null)
  %t62 = icmp ne ptr %t61, null
  %t63 = select i1 %t62, ptr %t61, ptr null
  call void @__olang_region_settle_in(ptr %t58, ptr %t63)
  br label %bb7
bb10:
  %t64 = load i64, ptr %l4
  %t65 = inttoptr i64 %t64 to ptr
  %t66 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8, i32 0, i32 0
  %t67 = load { i64, ptr }, ptr %t66
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = call ptr @__olang_region_or(ptr %t68, ptr null)
  %t70 = call ptr @__olang_region_home(ptr %t69)
  %t71 = icmp ne ptr %t70, null
  %t72 = select i1 %t71, ptr %t70, ptr null
  call void @__olang_region_settle_in(ptr %t65, ptr %t72)
  br label %bb11
bb11:
  %t73 = call ptr @__olang_scope_hold(ptr %v1)
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l18, !tbaa !24
  %t75 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3afactsCopy_2e1
  br i1 %t75, label %bb12, label %bb13
bb12:
  %t77 = call ptr @__olang_region_make(ptr %v1)
  %t78 = ptrtoint ptr %t77 to i64
  store i64 %t78, ptr %l18, !tbaa !24
  br label %bb13
bb13:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 46
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t81
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l22
  %t84 = load i64, ptr %l18
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = call ptr @__olang_scope_hold(ptr %t85)
  %t87 = ptrtoint ptr %t86 to i64
  store i64 %t87, ptr %l23, !tbaa !24
  %t88 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2e0
  br i1 %t88, label %bb14, label %bb15
bb14:
  %t90 = load i64, ptr %l18
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = call ptr @__olang_region_make_part(ptr %t91)
  %t93 = ptrtoint ptr %t92 to i64
  store i64 %t93, ptr %l23, !tbaa !24
  br label %bb15
bb15:
  %t94 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22, i32 0, i32 0
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l25, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l26, !tbaa !24
  %t98 = load i64, ptr %l26, !tbaa !24
  %t99 = mul i64 %t98, 80
  %t100 = load i64, ptr %l23
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = call ptr @__olang_held_alloc(ptr %t101, i64 %t99)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l27, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l26, !tbaa !24
  %t110 = mul i64 %t109, 80
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  %t111 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t112 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22, i32 0, i32 0
  store { i64, ptr } %t111, ptr %t112, !tbaa !27
  %t113 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2e0
  br i1 %t113, label %bb16, label %bb17
bb16:
  %t115 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  %t119 = icmp eq i64 %t117, 0
  br i1 %t119, label %bb18, label %bb19
bb17:
  %t121 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3afactsCopy_2e1
  br i1 %t121, label %bb20, label %bb21
bb18:
  %t123 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t123, !tbaa !27
  br label %bb19
bb19:
  %t124 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22, i32 0, i32 0
  %t125 = load i64, ptr %l23
  %t126 = inttoptr i64 %t125 to ptr
  %t127 = load { i64, ptr }, ptr %t124
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = call ptr @__olang_region_or(ptr %t128, ptr null)
  %t130 = icmp ne ptr %t129, null
  %t131 = select i1 %t130, ptr %t129, ptr null
  call void @__olang_region_settle_in(ptr %t126, ptr %t131)
  br label %bb17
bb20:
  %t132 = load i64, ptr %l18
  %t133 = inttoptr i64 %t132 to ptr
  %t134 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = call ptr @__olang_region_or(ptr %t136, ptr null)
  %t138 = call ptr @__olang_region_home(ptr %t137)
  %t139 = icmp ne ptr %t138, null
  %t140 = select i1 %t139, ptr %t138, ptr null
  call void @__olang_region_settle_in(ptr %t133, ptr %t140)
  br label %bb21
bb21:
  %t141 = call ptr @__olang_scope_hold(ptr %v1)
  %t142 = ptrtoint ptr %t141 to i64
  store i64 %t142, ptr %l32, !tbaa !24
  %t143 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3afactsCopy_2e2
  br i1 %t143, label %bb22, label %bb23
bb22:
  %t145 = call ptr @__olang_region_make(ptr %v1)
  %t146 = ptrtoint ptr %t145 to i64
  store i64 %t146, ptr %l32, !tbaa !24
  br label %bb23
bb23:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/check:frame", ptr %t147, i32 0, i32 62
  %t150 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t149
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %l36
  %t152 = load i64, ptr %l32
  %t153 = inttoptr i64 %t152 to ptr
  %t154 = call ptr @__olang_scope_hold(ptr %t153)
  %t155 = ptrtoint ptr %t154 to i64
  store i64 %t155, ptr %l37, !tbaa !24
  %t156 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2e0
  br i1 %t156, label %bb24, label %bb25
bb24:
  %t158 = load i64, ptr %l32
  %t159 = inttoptr i64 %t158 to ptr
  %t160 = call ptr @__olang_region_make_part(ptr %t159)
  %t161 = ptrtoint ptr %t160 to i64
  store i64 %t161, ptr %l37, !tbaa !24
  br label %bb25
bb25:
  %t162 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l39, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  store i64 %t165, ptr %l40, !tbaa !24
  %t166 = load i64, ptr %l40, !tbaa !24
  %t167 = mul i64 %t166, 56
  %t168 = load i64, ptr %l37
  %t169 = inttoptr i64 %t168 to ptr
  %t170 = call ptr @__olang_held_alloc(ptr %t169, i64 %t167)
  %t171 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l41, !tbaa !27
  %t173 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = load i64, ptr %l40, !tbaa !24
  %t178 = mul i64 %t177, 56
  call void @llvm.memmove.p0.p0.i64(ptr %t174, ptr %t176, i64 %t178, i1 false)
  %t179 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t180 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  store { i64, ptr } %t179, ptr %t180, !tbaa !27
  %t181 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2e0
  br i1 %t181, label %bb26, label %bb27
bb26:
  %t183 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  %t187 = icmp eq i64 %t185, 0
  br i1 %t187, label %bb28, label %bb29
bb27:
  %t189 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3afactsCopy_2e2
  br i1 %t189, label %bb30, label %bb31
bb28:
  %t191 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t191, !tbaa !27
  br label %bb29
bb29:
  %t192 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t193 = load i64, ptr %l37
  %t194 = inttoptr i64 %t193 to ptr
  %t195 = load { i64, ptr }, ptr %t192
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = call ptr @__olang_region_or(ptr %t196, ptr null)
  %t198 = icmp ne ptr %t197, null
  %t199 = select i1 %t198, ptr %t197, ptr null
  call void @__olang_region_settle_in(ptr %t194, ptr %t199)
  br label %bb27
bb30:
  %t200 = load i64, ptr %l32
  %t201 = inttoptr i64 %t200 to ptr
  %t202 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t203 = load { i64, ptr }, ptr %t202
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = call ptr @__olang_region_or(ptr %t204, ptr null)
  %t206 = call ptr @__olang_region_home(ptr %t205)
  %t207 = icmp ne ptr %t206, null
  %t208 = select i1 %t207, ptr %t206, ptr null
  call void @__olang_region_settle_in(ptr %t201, ptr %t208)
  br label %bb31
bb31:
  %t209 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t210 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  %t211 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  %t212 = call %"compiler/check:factsCopy" @compiler_2fcheck_3afactsCopy_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t210, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t211)
  store %"compiler/check:factsCopy" %t212, ptr %l46
  br label %bb32
bb32:
  %t213 = load %"compiler/check:factsCopy", ptr %l46
  store %"compiler/check:factsCopy" %t213, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factsCopy", ptr %rv
  ret %"compiler/check:factsCopy" %rr
}

define dso_local { i32, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eitemOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 8
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = insertvalue { i32, ptr } undef, i32 %t22, 0
  %t27 = insertvalue { i32, ptr } %t25, ptr %t23, 1
  store { i32, ptr } %t27, ptr %rv
  br label %ret
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 9}
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32 }, ptr %t40, i32 0, i32 1
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l5, !tbaa !23
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t46 = getelementptr %"compiler/check:fieldSet", ptr %a2, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = icmp sge i32 %t47, 0
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = load i32, ptr %l5, !tbaa !23
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = insertvalue { i32, ptr } undef, i32 %t51, 0
  %t56 = insertvalue { i32, ptr } %t54, ptr %t52, 1
  store { i32, ptr } %t56, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_a8dc05ade1085e71_1f4ef85bbb60cc55)
  unreachable
bb20:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = insertvalue { i32, ptr } undef, i32 0, 0
  %t61 = insertvalue { i32, ptr } %t59, ptr %t58, 1
  store { i32, ptr } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, ptr %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca [2 x i64]
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca [3 x i64]
  %l24 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l36 = alloca %"compiler/check:laneNode"
  %l38 = alloca ptr
  %l41 = alloca i64
  %l45 = alloca %"compiler/check:laneNode"
  %l50 = alloca %"compiler/check:laneNode"
  %l55 = alloca i1
  %l59 = alloca i32
  %l63 = alloca i1
  %l64 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca ptr
  %l73 = alloca i64
  %l74 = alloca i32
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i32
  %l84 = alloca i64
  %l86 = alloca %"compiler/check:laneNode"
  %l87 = alloca i64
  %l88 = alloca ptr
  %l90 = alloca i1
  %l94 = alloca %"compiler/check:laneNode"
  %l98 = alloca i1
  %l102 = alloca %"compiler/check:laneNode"
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca ptr
  %l112 = alloca %"compiler/check:laneNode"
  %l114 = alloca { i64, ptr }
  %l116 = alloca %"compiler/diagmsg:Msg"
  %l117 = alloca i64
  %l119 = alloca { i64, ptr }
  %l121 = alloca i1
  %l124 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l132 = alloca i1
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca ptr
  %l160 = alloca ptr
  %l164 = alloca i64
  %l165 = alloca ptr
  %l169 = alloca i64
  %l173 = alloca %"compiler/check:laneNode"
  %l178 = alloca %"compiler/check:laneNode"
  %l184 = alloca i1
  %l193 = alloca i1
  %l197 = alloca i1
  %l198 = alloca i1
  %l201 = alloca i1
  %l202 = alloca i1
  %l207 = alloca i32
  %l213 = alloca i32
  %l214 = alloca ptr
  %l215 = alloca %"compiler/source:Span"
  %l218 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l224 = alloca %"compiler/diagmsg:Msg"
  %l225 = alloca i64
  %l230 = alloca ptr
  %l231 = alloca %"compiler/source:Span"
  %l232 = alloca ptr
  %l233 = alloca i64
  %l234 = alloca i32
  %l235 = alloca %"compiler/source:Span"
  %l236 = alloca %"compiler/source:Span"
  %l237 = alloca i64
  %l238 = alloca i64
  %l239 = alloca i64
  %l240 = alloca i32
  %l245 = alloca i64
  %l249 = alloca { i64, ptr }
  %l251 = alloca i32
  %l252 = alloca %"compiler/check:laneNode"
  %l253 = alloca i64
  %l254 = alloca ptr
  %l255 = alloca ptr
  %l256 = alloca %"compiler/source:Span"
  %l257 = alloca %"compiler/source:Span"
  %l258 = alloca { i64, ptr }
  %l259 = alloca i64
  %l260 = alloca i32
  %l261 = alloca %"compiler/source:Span"
  %l262 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v2, ptr %t1, ptr %a4)
  store i64 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l24, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t9, ptr %l26
  br label %bb2
bb2:
  %t10 = load i1, ptr %l26, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb6
bb4:
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t13, ptr %l29
  br label %bb5
bb5:
  %t14 = load i1, ptr %l29, !tbaa !21
  store i1 %t14, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l27, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l30, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t17, ptr %l31, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 0
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l32, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 51
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s1, ptr %t24, i64 %t25)
  store %"compiler/check:laneNode" %t28, ptr %l36
  br label %bb9
bb8:
  br label %bb28
bb9:
  %t29 = getelementptr %"compiler/check:laneNode", ptr %l36, i32 0, i32 8
  %t30 = load i32, ptr %t29, !tbaa !23
  %t31 = load ptr, ptr %l30, !tbaa !29
  %t32 = load ptr, ptr %l32, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v3, ptr %v0, ptr %t31, ptr %t32, i32 %t30)
  store ptr %t34, ptr %l38
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l38, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v0, ptr %t36, ptr %t35)
  store i64 %t40, ptr %l41
  br label %bb11
bb11:
  %t41 = load i64, ptr %l41, !tbaa !24
  store i64 %t41, ptr %l8, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 51
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s1, ptr %t44, i64 %t45)
  store %"compiler/check:laneNode" %t48, ptr %l45
  br label %bb12
bb12:
  %t49 = getelementptr %"compiler/check:laneNode", ptr %l45, i32 0, i32 8
  %t50 = load i32, ptr %t49, !tbaa !23
  store i32 %t50, ptr %l9, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 51
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s1, ptr %t54, i64 %t55)
  store %"compiler/check:laneNode" %t58, ptr %l50
  br label %bb13
bb13:
  %t59 = getelementptr %"compiler/check:laneNode", ptr %l50, i32 0, i32 8
  %t60 = load i32, ptr %t59, !tbaa !23
  store i32 %t60, ptr %l10, !tbaa !23
  %t62 = load i32, ptr %l9, !tbaa !23
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t66 = icmp ne i32 %t62, %t63
  br i1 %t66, label %bb14, label %bb15
bb14:
  %t68 = load i32, ptr %l10, !tbaa !23
  %t69 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t72 = icmp ne i32 %t68, %t69
  store i1 %t72, ptr %l55, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb16
bb16:
  %t74 = load i1, ptr %l55, !tbaa !21
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t75 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t75, ptr %l59, !tbaa !23
  br label %bb19
bb18:
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t77, ptr %l59, !tbaa !23
  br label %bb19
bb19:
  %t79 = load i32, ptr %l59, !tbaa !23
  store i32 %t79, ptr %l11, !tbaa !23
  %t80 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t82 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t80, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t82, ptr %l63
  br label %bb20
bb20:
  %t83 = load i1, ptr %l63, !tbaa !21
  br i1 %t83, label %bb21, label %bb22
bb21:
  store i32 95, ptr %l64
  br label %bb23
bb22:
  store i32 98, ptr %l64
  br label %bb23
bb23:
  %t86 = load i32, ptr %l64, !range !{i32 0, i32 116}
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t90 = insertvalue [2 x i64] undef, i64 %t87, 0
  %t92 = insertvalue [2 x i64] %t90, i64 %t88, 1
  store [2 x i64] %t92, ptr %l13
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l70, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t95, ptr %l71
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l72, !tbaa !29
  %t97 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneCmp, !tbaa !24
  store i64 %t97, ptr %l73, !tbaa !24
  store i32 %t86, ptr %l74
  %t99 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t99, ptr %l75
  %t100 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t100, ptr %l76
  %t101 = load i64, ptr %l6, !tbaa !24
  store i64 %t101, ptr %l77, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  store i64 %t102, ptr %l78, !tbaa !24
  %t103 = load i32, ptr %l11, !tbaa !23
  store i32 %t103, ptr %l79, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = insertvalue { i64, ptr } undef, i64 2, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %l13, 1
  %t108 = load %"compiler/source:Span", ptr %l2
  %t112 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %s1, ptr %t104, { i64, ptr } %t107, %"compiler/source:Span" %t108)
  store i64 %t112, ptr %l84
  br label %bb24
bb24:
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t114 = load i64, ptr %l73, !tbaa !24
  %t115 = load i32, ptr %l74, !range !{i32 0, i32 116}
  %t116 = load %"compiler/source:Span", ptr %l75
  %t117 = load %"compiler/source:Span", ptr %l76
  %t118 = load i64, ptr %l77, !tbaa !24
  %t119 = load i64, ptr %l78, !tbaa !24
  %t120 = load i32, ptr %l79, !tbaa !23
  %t121 = load i64, ptr %l84, !tbaa !24
  %t123 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t114, i32 %t115, %"compiler/source:Span" %t116, %"compiler/source:Span" %t117, i64 %t118, i64 %t119, i64 -1, ptr null, i32 %t120, i64 %t121, i32 %t113, i64 -1)
  store %"compiler/check:laneNode" %t123, ptr %l86
  br label %bb25
bb25:
  %t124 = load ptr, ptr %l72, !tbaa !29
  %t125 = load %"compiler/check:laneNode", ptr %l86
  %t126 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t124, %"compiler/check:laneNode" %t125)
  store i64 %t126, ptr %l87
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l71
  %t129 = load i64, ptr %l87, !tbaa !24
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v4, ptr %t127, %"compiler/source:Span" %t128, i64 %t129)
  store ptr %t130, ptr %l88
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t131 = load ptr, ptr %l88, !tbaa !29
  store ptr %t131, ptr %rv
  br label %ret
bb28:
  %t132 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t132, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t134, ptr %l90
  br label %bb29
bb29:
  %t135 = load i1, ptr %l90, !tbaa !21
  br i1 %t135, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s2
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 51
  %t139 = load i64, ptr %l6, !tbaa !24
  %t142 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t138, i64 %t139)
  store %"compiler/check:laneNode" %t142, ptr %l94
  br label %bb32
bb31:
  br label %bb106
bb32:
  %t143 = getelementptr %"compiler/check:laneNode", ptr %l94, i32 0, i32 8
  %t144 = load i32, ptr %t143, !tbaa !23
  %t145 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t148 = icmp ne i32 %t144, %t145
  br i1 %t148, label %bb33, label %bb34
bb33:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 51
  %t153 = load i64, ptr %l6, !tbaa !24
  %t156 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t152, i64 %t153)
  store %"compiler/check:laneNode" %t156, ptr %l102
  br label %bb35
bb34:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb36
bb35:
  %t157 = getelementptr %"compiler/check:laneNode", ptr %l102, i32 0, i32 8
  %t158 = load i32, ptr %t157, !tbaa !23
  %t159 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t162 = icmp ne i32 %t158, %t159
  store i1 %t162, ptr %l98, !tbaa !21
  br label %bb36
bb36:
  %t164 = load i1, ptr %l98, !tbaa !21
  br i1 %t164, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s3
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l106, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t166, ptr %l107
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l108, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 51
  %t171 = load i64, ptr %l6, !tbaa !24
  %t174 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s3, ptr %t170, i64 %t171)
  store %"compiler/check:laneNode" %t174, ptr %l112
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t175 = getelementptr %"compiler/check:laneNode", ptr %l112, i32 0, i32 8
  %t176 = load i32, ptr %t175, !tbaa !23
  %t177 = load ptr, ptr %l108, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t177, i32 %t176)
  store { i64, ptr } %t179, ptr %l114
  br label %bb40
bb40:
  %t180 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t182 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneMaskBool(ptr %s3, ptr %s3, ptr %v0, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d18, i32 0, i32 1) }, { i64, ptr } %t180)
  store %"compiler/diagmsg:Msg" %t182, ptr %l116
  br label %bb41
bb41:
  %t183 = load ptr, ptr %l106, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l107
  %t185 = load %"compiler/diagmsg:Msg", ptr %l116
  %t186 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t183, %"compiler/source:Span" %t184, %"compiler/diagmsg:Msg" %t185)
  store i64 %t186, ptr %l117
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  store ptr null, ptr %l14, !tbaa !29
  store ptr null, ptr %l15, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t188, ptr %l119, !tbaa !27
  %t189 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr ptr, ptr %t190, i64 0
  %t192 = load ptr, ptr %t191, !tbaa !39
  %t195 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t187, ptr %t192)
  store i1 %t195, ptr %l121
  br label %bb44
bb44:
  %t196 = load i1, ptr %l121, !tbaa !21
  %t197 = xor i1 %t196, true
  br i1 %t197, label %bb45, label %bb46
bb45:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t200, ptr %l124, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr ptr, ptr %t202, i64 0
  %t204 = load ptr, ptr %t203, !tbaa !39
  %t205 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v3, ptr %v0, ptr %t199, ptr %t204, i32 %t205)
  store ptr %t209, ptr %l127
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t210 = load ptr, ptr %l127, !tbaa !29
  store ptr %t210, ptr %l14, !tbaa !29
  br label %bb48
bb48:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t213, ptr %l130, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr ptr, ptr %t215, i64 1
  %t217 = load ptr, ptr %t216, !tbaa !39
  %t220 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t212, ptr %t217)
  store i1 %t220, ptr %l132
  br label %bb49
bb49:
  %t221 = load i1, ptr %l132, !tbaa !21
  %t222 = xor i1 %t221, true
  br i1 %t222, label %bb50, label %bb51
bb50:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t225, ptr %l135, !tbaa !27
  %t226 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr ptr, ptr %t227, i64 1
  %t229 = load ptr, ptr %t228, !tbaa !39
  %t230 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v3, ptr %v0, ptr %t224, ptr %t229, i32 %t230)
  store ptr %t234, ptr %l138
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t235 = load ptr, ptr %l138, !tbaa !29
  store ptr %t235, ptr %l15, !tbaa !29
  br label %bb53
bb53:
  %t237 = load ptr, ptr %l14, !tbaa !29
  %t239 = icmp eq ptr %t237, null
  br i1 %t239, label %bb54, label %bb55
bb54:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l142, !tbaa !29
  %t242 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t242, ptr %l143, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 0
  %t246 = load ptr, ptr %t245, !tbaa !39
  store ptr %t246, ptr %l144, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l15, !tbaa !29
  %t251 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v0, ptr %t247, ptr %t248)
  store i32 %t251, ptr %l147
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t252 = load ptr, ptr %l142, !tbaa !29
  %t253 = load ptr, ptr %l144, !tbaa !29
  %t254 = load i32, ptr %l147, !tbaa !23
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v3, ptr %v0, ptr %t252, ptr %t253, i32 %t254)
  store ptr %t255, ptr %l148
  br label %bb57
bb57:
  %t256 = load ptr, ptr %l148, !tbaa !29
  store ptr %t256, ptr %l14, !tbaa !29
  br label %bb58
bb58:
  %t258 = load ptr, ptr %l15, !tbaa !29
  %t260 = icmp eq ptr %t258, null
  br i1 %t260, label %bb59, label %bb60
bb59:
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l152, !tbaa !29
  %t263 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t263, ptr %l153, !tbaa !27
  %t264 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr ptr, ptr %t265, i64 1
  %t267 = load ptr, ptr %t266, !tbaa !39
  store ptr %t267, ptr %l154, !tbaa !29
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l14, !tbaa !29
  %t272 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v0, ptr %t268, ptr %t269)
  store i32 %t272, ptr %l157
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t273 = load ptr, ptr %l152, !tbaa !29
  %t274 = load ptr, ptr %l154, !tbaa !29
  %t275 = load i32, ptr %l157, !tbaa !23
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v3, ptr %v0, ptr %t273, ptr %t274, i32 %t275)
  store ptr %t276, ptr %l158
  br label %bb62
bb62:
  %t277 = load ptr, ptr %l158, !tbaa !29
  store ptr %t277, ptr %l15, !tbaa !29
  br label %bb63
bb63:
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l160, !tbaa !29
  %t280 = load ptr, ptr %l14, !tbaa !29
  %t282 = icmp eq ptr %t280, null
  br i1 %t282, label %bb64, label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_f29deef1411bcac7_1d318aa8f75ec9a3)
  unreachable
bb65:
  br label %bb66
bb66:
  %t284 = load ptr, ptr %l14, !tbaa !29
  %t285 = load ptr, ptr %l160, !tbaa !29
  %t287 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v0, ptr %t285, ptr %t284)
  store i64 %t287, ptr %l164
  br label %bb67
bb67:
  %t288 = load i64, ptr %l164, !tbaa !24
  store i64 %t288, ptr %l16, !tbaa !24
  %t289 = load ptr, ptr %l0, !tbaa !29
  store ptr %t289, ptr %l165, !tbaa !29
  %t290 = load ptr, ptr %l15, !tbaa !29
  %t292 = icmp eq ptr %t290, null
  br i1 %t292, label %bb68, label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_15db60dea160a9a8_613bb3b113b67e94)
  unreachable
bb69:
  br label %bb70
bb70:
  %t294 = load ptr, ptr %l15, !tbaa !29
  %t295 = load ptr, ptr %l165, !tbaa !29
  %t297 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v0, ptr %t295, ptr %t294)
  store i64 %t297, ptr %l169
  br label %bb71
bb71:
  %t298 = load i64, ptr %l169, !tbaa !24
  store i64 %t298, ptr %l17, !tbaa !24
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 51
  %t302 = load i64, ptr %l16, !tbaa !24
  %t305 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t301, i64 %t302)
  store %"compiler/check:laneNode" %t305, ptr %l173
  br label %bb72
bb72:
  %t306 = getelementptr %"compiler/check:laneNode", ptr %l173, i32 0, i32 8
  %t307 = load i32, ptr %t306, !tbaa !23
  store i32 %t307, ptr %l18, !tbaa !23
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/check:Checker", ptr %t309, i32 0, i32 51
  %t312 = load i64, ptr %l17, !tbaa !24
  %t315 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t311, i64 %t312)
  store %"compiler/check:laneNode" %t315, ptr %l178
  br label %bb73
bb73:
  %t316 = getelementptr %"compiler/check:laneNode", ptr %l178, i32 0, i32 8
  %t317 = load i32, ptr %t316, !tbaa !23
  store i32 %t317, ptr %l19, !tbaa !23
  %t319 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t319, ptr %l20, !tbaa !23
  %t321 = load i32, ptr %l18, !tbaa !23
  %t322 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t325 = icmp ne i32 %t321, %t322
  br i1 %t325, label %bb74, label %bb75
bb74:
  %t327 = load i32, ptr %l19, !tbaa !23
  %t328 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t331 = icmp ne i32 %t327, %t328
  store i1 %t331, ptr %l184, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb76
bb76:
  %t333 = load i1, ptr %l184, !tbaa !21
  br i1 %t333, label %bb77, label %bb78
bb77:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/check:Checker", ptr %t334, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t339 = getelementptr %"compiler/generic:Program", ptr %t337, i32 0, i32 2
  %t340 = load i32, ptr %l18, !tbaa !23
  %t341 = load i32, ptr %l19, !tbaa !23
  %t345 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t339, i32 %t340, i32 %t341)
  store i1 %t345, ptr %l193
  br label %bb79
bb78:
  br label %bb100
bb79:
  %t346 = load i1, ptr %l193, !tbaa !21
  br i1 %t346, label %bb80, label %bb81
bb80:
  %t347 = load i32, ptr %l18, !tbaa !23
  store i32 %t347, ptr %l20, !tbaa !23
  br label %bb99
bb81:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i32, ptr %l18, !tbaa !23
  %t353 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t349, i32 %t350)
  store i1 %t353, ptr %l197
  br label %bb82
bb82:
  %t354 = load i1, ptr %l197, !tbaa !21
  br i1 %t354, label %bb83, label %bb84
bb83:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i32, ptr %l19, !tbaa !23
  %t359 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t355, i32 %t356)
  store i1 %t359, ptr %l201
  br label %bb85
bb84:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb86
bb85:
  %t360 = load i1, ptr %l201, !tbaa !21
  store i1 %t360, ptr %l198, !tbaa !21
  br label %bb86
bb86:
  %t361 = load i1, ptr %l198, !tbaa !21
  br i1 %t361, label %bb87, label %bb88
bb87:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/check:Checker", ptr %t362, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !29
  %t366 = load i32, ptr %l18, !tbaa !23
  %t367 = load i32, ptr %l19, !tbaa !23
  %t371 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t365, i32 %t366, i32 %t367)
  store i32 %t371, ptr %l207
  br label %bb89
bb88:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb90
bb89:
  %t372 = load i32, ptr %l207, !tbaa !23
  %t373 = icmp sge i32 %t372, 0
  store i1 %t373, ptr %l202, !tbaa !21
  br label %bb90
bb90:
  %t375 = load i1, ptr %l202, !tbaa !21
  br i1 %t375, label %bb91, label %bb92
bb91:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/check:Checker", ptr %t376, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !29
  %t380 = load i32, ptr %l18, !tbaa !23
  %t381 = load i32, ptr %l19, !tbaa !23
  %t385 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t379, i32 %t380, i32 %t381)
  store i32 %t385, ptr %l213
  br label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s12
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l214, !tbaa !29
  %t387 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t387, ptr %l215
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load i32, ptr %l18, !tbaa !23
  %t392 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t388, i32 %t389)
  store { i64, ptr } %t392, ptr %l218
  br label %bb94
bb93:
  %t393 = load i32, ptr %l213, !tbaa !23
  store i32 %t393, ptr %l20, !tbaa !23
  br label %bb98
bb94:
  %t394 = load { i64, ptr }, ptr %l218, !tbaa !27
  store { i64, ptr } %t394, ptr %l219, !tbaa !27
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load i32, ptr %l19, !tbaa !23
  %t399 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t395, i32 %t396)
  store { i64, ptr } %t399, ptr %l222
  br label %bb95
bb95:
  %t400 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t401 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t403 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %s12, ptr %s12, ptr %s12, ptr %v0, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d19, i32 0, i32 1) }, { i64, ptr } %t401, { i64, ptr } %t400)
  store %"compiler/diagmsg:Msg" %t403, ptr %l224
  br label %bb96
bb96:
  %t404 = load ptr, ptr %l214, !tbaa !29
  %t405 = load %"compiler/source:Span", ptr %l215
  %t406 = load %"compiler/diagmsg:Msg", ptr %l224
  %t407 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t404, %"compiler/source:Span" %t405, %"compiler/diagmsg:Msg" %t406)
  store i64 %t407, ptr %l225
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s12)
  br label %bb98
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t408 = load i64, ptr %l6, !tbaa !24
  %t409 = load i64, ptr %l16, !tbaa !24
  %t410 = load i64, ptr %l17, !tbaa !24
  %t412 = insertvalue [3 x i64] undef, i64 %t408, 0
  %t414 = insertvalue [3 x i64] %t412, i64 %t409, 1
  %t416 = insertvalue [3 x i64] %t414, i64 %t410, 2
  store [3 x i64] %t416, ptr %l21
  %t418 = load ptr, ptr %l0, !tbaa !29
  store ptr %t418, ptr %l230, !tbaa !29
  %t419 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t419, ptr %l231
  %t420 = load ptr, ptr %l0, !tbaa !29
  store ptr %t420, ptr %l232, !tbaa !29
  %t421 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneSel, !tbaa !24
  store i64 %t421, ptr %l233, !tbaa !24
  store i32 68, ptr %l234
  %t422 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t422, ptr %l235
  %t423 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t423, ptr %l236
  %t424 = load i64, ptr %l6, !tbaa !24
  store i64 %t424, ptr %l237, !tbaa !24
  %t425 = load i64, ptr %l16, !tbaa !24
  store i64 %t425, ptr %l238, !tbaa !24
  %t426 = load i64, ptr %l17, !tbaa !24
  store i64 %t426, ptr %l239, !tbaa !24
  %t427 = load i32, ptr %l20, !tbaa !23
  store i32 %t427, ptr %l240, !tbaa !23
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = insertvalue { i64, ptr } undef, i64 3, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %l21, 1
  %t432 = load %"compiler/source:Span", ptr %l2
  %t436 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %s2, ptr %t428, { i64, ptr } %t431, %"compiler/source:Span" %t432)
  store i64 %t436, ptr %l245
  br label %bb101
bb101:
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t438 = load i64, ptr %l16, !tbaa !24
  %t439 = load i64, ptr %l17, !tbaa !24
  %t440 = mul i64 2, 8
  %t441 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t440)
  %t442 = insertvalue { i64, ptr } undef, i64 2, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t441, 1
  store { i64, ptr } %t443, ptr %l249, !tbaa !27
  %t445 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !27
  %t447 = getelementptr i64, ptr %t446, i64 0
  store i64 %t438, ptr %t447, !tbaa !34
  %t449 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !27
  %t451 = getelementptr i64, ptr %t450, i64 1
  store i64 %t439, ptr %t451, !tbaa !34
  %t452 = load i32, ptr %l20, !tbaa !23
  %t454 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t456 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %s2, ptr %t437, { i64, ptr } %t454, i32 %t452)
  store i32 %t456, ptr %l251
  br label %bb102
bb102:
  %t457 = load i64, ptr %l233, !tbaa !24
  %t458 = load i32, ptr %l234, !range !{i32 0, i32 116}
  %t459 = load %"compiler/source:Span", ptr %l235
  %t460 = load %"compiler/source:Span", ptr %l236
  %t461 = load i64, ptr %l237, !tbaa !24
  %t462 = load i64, ptr %l238, !tbaa !24
  %t463 = load i64, ptr %l239, !tbaa !24
  %t464 = load i32, ptr %l240, !tbaa !23
  %t465 = load i64, ptr %l245, !tbaa !24
  %t466 = load i32, ptr %l251, !tbaa !23
  %t467 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t457, i32 %t458, %"compiler/source:Span" %t459, %"compiler/source:Span" %t460, i64 %t461, i64 %t462, i64 %t463, ptr null, i32 %t464, i64 %t465, i32 %t466, i64 -1)
  store %"compiler/check:laneNode" %t467, ptr %l252
  br label %bb103
bb103:
  %t468 = load ptr, ptr %l232, !tbaa !29
  %t469 = load %"compiler/check:laneNode", ptr %l252
  %t470 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t468, %"compiler/check:laneNode" %t469)
  store i64 %t470, ptr %l253
  br label %bb104
bb104:
  %t471 = load ptr, ptr %l230, !tbaa !29
  %t472 = load %"compiler/source:Span", ptr %l231
  %t473 = load i64, ptr %l253, !tbaa !24
  %t474 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v4, ptr %t471, %"compiler/source:Span" %t472, i64 %t473)
  store ptr %t474, ptr %l254
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t475 = load ptr, ptr %l254, !tbaa !29
  store ptr %t475, ptr %rv
  br label %ret
bb106:
  %t476 = load ptr, ptr %l0, !tbaa !29
  store ptr %t476, ptr %l255, !tbaa !29
  %t477 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t477, ptr %l256
  %t478 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t478, ptr %l257
  %t479 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t479, ptr %l258, !tbaa !27
  %t480 = load i64, ptr %l6, !tbaa !24
  store i64 %t480, ptr %l259, !tbaa !24
  %t481 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t481, ptr %l260, !tbaa !23
  %t482 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t482, ptr %l261
  br label %bb107
bb107:
  %t483 = load ptr, ptr %l255, !tbaa !29
  %t484 = load %"compiler/source:Span", ptr %l256
  %t485 = load %"compiler/source:Span", ptr %l257
  %t486 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t487 = load i64, ptr %l259, !tbaa !24
  %t488 = load i32, ptr %l260, !tbaa !23
  %t489 = load %"compiler/source:Span", ptr %l261
  %t490 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTotal(ptr %v0, ptr %v1, ptr %v4, ptr %t483, %"compiler/source:Span" %t484, %"compiler/source:Span" %t485, { i64, ptr } %t486, i64 %t487, i32 %t488, %"compiler/source:Span" %t489)
  store ptr %t490, ptr %l262
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s0)
  %t491 = load ptr, ptr %l262, !tbaa !29
  store ptr %t491, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberThrough(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l8 = alloca i32
  %l11 = alloca i1
  %l20 = alloca i64
  %l32 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t9 = icmp slt i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i32, ptr %l4, !tbaa !23
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t15 = icmp eq i32 %t11, %t12
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i32 -1, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i32, ptr %l4, !tbaa !23
  %t28 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOf(ptr %v0, ptr %t22, i32 %t23, i32 %a3)
  store i64 %t28, ptr %l20
  br label %bb8
bb8:
  %t29 = load i64, ptr %l20, !tbaa !24
  store i64 %t29, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp slt i64 %t30, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  store i32 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l4, !tbaa !23
  %t38 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberSeen(ptr %v0, ptr %t35, %"compiler/source:Span" %a1, i32 %t37, i64 %t38)
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i32, ptr %l4, !tbaa !23
  %t52 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberType(ptr %v0, ptr %t46, i64 %t47, i32 %t48)
  store i32 %t52, ptr %l32
  br label %bb13
bb13:
  %t53 = load i32, ptr %l32, !tbaa !23
  store i32 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodOverlap(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l10 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l50 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca i32
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i64
  %l77 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca { i64, [3 x i64] }
  %l85 = alloca { i64, ptr }
  %l88 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOverlap(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i64, ptr %l10, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l16, !tbaa !29
  store ptr %t22, ptr %l3, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l19, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t38, i64 %t39)
  store i32 %t42, ptr %l26
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = load i32, ptr %l26, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t45, ptr %l27
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = load i32, ptr %l27, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t46, i32 %t47)
  store { i64, ptr } %t48, ptr %l28
  br label %bb8
bb8:
  %t49 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t49, ptr %l4, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t54 = icmp eq i64 %t52, 0
  br i1 %t54, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l32, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l36
  br label %bb12
bb12:
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t66 = load ptr, ptr %l32, !tbaa !29
  %t67 = load i64, ptr %l36, !tbaa !24
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t66, i64 -1, i64 %t67, i32 %t65, i32 0)
  store ptr %t69, ptr %l38
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t75 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t71, ptr %t72)
  store %"compiler/source:Span" %t75, ptr %l42
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t76, i32 %t80)
  store { i64, ptr } %t83, ptr %l46
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l47, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  store ptr %t90, ptr %l50, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t92, ptr %l52, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 0
  %t96 = load i32, ptr %t95, !tbaa !33
  %t99 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t91, i32 %t96)
  store i32 %t99, ptr %l54
  br label %bb16
bb16:
  %t100 = load ptr, ptr %l50, !tbaa !29
  %t101 = load i32, ptr %l54, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t102, ptr %l55
  br label %bb17
bb17:
  %t103 = load ptr, ptr %l47, !tbaa !29
  %t104 = load i32, ptr %l55, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l56
  br label %bb18
bb18:
  %t106 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t109 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOverlap(ptr %v0, ptr %s0, ptr %v0, { i64, ptr } %t107, { i64, ptr } %t106)
  store %"compiler/diagmsg:Msg" %t109, ptr %l58
  br label %bb19
bb19:
  %t110 = load ptr, ptr %l39, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l42
  %t112 = load %"compiler/diagmsg:Msg", ptr %l58
  %t113 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t110, %"compiler/source:Span" %t111, %"compiler/diagmsg:Msg" %t112)
  store i64 %t113, ptr %l59
  br label %bb20
bb20:
  %t114 = load i64, ptr %l59, !tbaa !24
  store i64 %t114, ptr %l5, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t115)
  br label %bb21
bb21:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t121 = load i64, ptr %l2, !tbaa !24
  %t124 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t120, i64 %t121)
  store ptr %t124, ptr %l64
  br label %bb22
bb22:
  %t125 = load ptr, ptr %l64, !tbaa !29
  store ptr %t125, ptr %l6, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l65, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load i64, ptr %l2, !tbaa !24
  %t134 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t130, i64 %t131)
  store i64 %t134, ptr %l69
  br label %bb23
bb23:
  %t135 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t136 = load ptr, ptr %l65, !tbaa !29
  %t137 = load i64, ptr %l69, !tbaa !24
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t136, i64 -1, i64 %t137, i32 %t135, i32 0)
  store ptr %t139, ptr %l71
  br label %bb24
bb24:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/load:Loader", ptr %t146, i32 0, i32 4
  %t149 = load ptr, ptr %t148, !tbaa !29
  store ptr %t149, ptr %l75, !tbaa !29
  %t150 = load i64, ptr %l5, !tbaa !24
  store i64 %t150, ptr %l76, !tbaa !24
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l77, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l6, !tbaa !29
  %t156 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t152, ptr %t153)
  store %"compiler/source:Span" %t156, ptr %l80
  br label %bb25
bb25:
  %t157 = load ptr, ptr %l77, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l80
  %t159 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t157, %"compiler/source:Span" %t158)
  store { i64, [3 x i64] } %t159, ptr %l81
  br label %bb26
bb26:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l6, !tbaa !29
  %t163 = getelementptr %"compiler/ast:Func", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %t163, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t160, i32 %t164)
  store { i64, ptr } %t167, ptr %l85
  br label %bb27
bb27:
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t170 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t168, i64 %t169)
  %t178 = getelementptr i8, ptr %t177, i64 %t169
  call void @olang_textcopy(ptr %t178, ptr %t171, i64 %t172)
  %t179 = getelementptr i8, ptr %t178, i64 %t172
  call void @olang_textcopy(ptr %t179, ptr %t174, i64 %t175)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t177, 1
  %t184 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s0, ptr %v0, { i64, ptr } %t181)
  store %"compiler/diagmsg:Msg" %t184, ptr %l88
  br label %bb28
bb28:
  %t185 = load ptr, ptr %l75, !tbaa !29
  %t186 = load i64, ptr %l76, !tbaa !24
  %t187 = load { i64, [3 x i64] }, ptr %l81
  %t188 = load %"compiler/diagmsg:Msg", ptr %l88
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t185, i64 %t186, { i64, [3 x i64] } %t187, %"compiler/diagmsg:Msg" %t188)
  br label %bb29
bb29:
  %t189 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t189)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i32
  %l16 = alloca { i64, ptr }
  %l20 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t4, ptr %l2
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 9}
  %t12 = icmp eq i64 %t10, 8
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  br label %bb6
bb5:
  br label %bb9
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l12, !tbaa !23
  %t22 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  store i32 %t23, ptr %l13, !tbaa !23
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s1, ptr %a0, i32 %t25)
  store { i64, ptr } %t28, ptr %l16
  br label %bb7
bb7:
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t32 = trunc i64 %t30 to i32
  %t33 = load i32, ptr %l13, !tbaa !23
  %t35 = add i32 %t33, %t32
  %t36 = load i32, ptr %l12, !tbaa !23
  %t38 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t36, i32 %t35)
  store %"compiler/source:Span" %t38, ptr %l20
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  %t39 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t39, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t40 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t40, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4d673442943c2a5_9663aeaf0b5db41)
  unreachable
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoItemField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca %"compiler/diagmsg:Msg"
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"compiler/msgs:Nearest"
  %l37 = alloca { i64, ptr }
  %l42 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca %"compiler/diagmsg:Msg"
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:fieldSet", ptr %t1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp sge i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/check:fieldSet", ptr %t8, i32 0, i32 0
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call i64 @compiler_2fcheck_2enameIndex(ptr %v1, { i64, ptr } %t11, i32 %t12)
  store i64 %t15, ptr %l15
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t24, ptr %l19
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/check:fieldSet", ptr %t25, i32 0, i32 2
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberIsPrivate(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %t29, { i64, ptr } %t28)
  store %"compiler/diagmsg:Msg" %t31, ptr %l22
  br label %bb8
bb8:
  %t32 = load %"compiler/diagmsg:Msg", ptr %l22
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store %"compiler/diagmsg:Msg" %t32, ptr %t33
  call void @__olang_scope_close(ptr %s0)
  store ptr %t33, ptr %rv
  br label %ret
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t35, i32 %t36)
  store { i64, ptr } %t39, ptr %l26
  br label %bb10
bb10:
  %t40 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t41 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t40)
  store %"compiler/msgs:Nearest" %t41, ptr %l27
  br label %bb11
bb11:
  %t42 = load %"compiler/msgs:Nearest", ptr %l27
  %t43 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t42, ptr %t43
  store ptr %t43, ptr %l3, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/check:fieldSet", ptr %t45, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb13, label %bb14
bb13:
  br label %bb26
bb14:
  br label %bb15
bb15:
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t62, ptr %l37, !tbaa !27
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i32, ptr %t66, i64 %t63
  %t68 = load i32, ptr %t67, !tbaa !33
  store i32 %t68, ptr %l7, !tbaa !23
  %t70 = load i32, ptr %l7, !tbaa !23
  %t72 = icmp ne i32 %t70, 0
  br i1 %t72, label %bb16, label %bb17
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t76 = load i32, ptr %l7, !tbaa !23
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldReadable(ptr %v0, ptr %v1, ptr %t74, ptr %t75, i32 %t76)
  store i1 %t80, ptr %l46
  br label %bb18
bb17:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb19
bb18:
  %t81 = load i1, ptr %l46, !tbaa !21
  store i1 %t81, ptr %l42, !tbaa !21
  br label %bb19
bb19:
  %t82 = load i1, ptr %l42, !tbaa !21
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t83 = load ptr, ptr %l3, !tbaa !29
  store ptr %t83, ptr %l47, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l7, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t84, i32 %t85)
  store { i64, ptr } %t88, ptr %l50
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t89 = load ptr, ptr %l47, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l50, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t89, { i64, ptr } %t90)
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = add i64 %t91, 1
  store i64 %t94, ptr %l5, !tbaa !24
  br label %bb12
bb26:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/check:fieldSet", ptr %t96, i32 0, i32 1
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = icmp sge i32 %t99, 0
  br i1 %t101, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/check:fieldSet", ptr %t103, i32 0, i32 2
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l58, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l2, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l61
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t114 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s0, ptr %s6, ptr %t112)
  store { i64, ptr } %t114, ptr %l63
  br label %bb30
bb30:
  %t115 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t119 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStructPatNoField(ptr %v1, ptr %v0, ptr %s6, ptr %v2, { i64, ptr } %t116, { i64, ptr } %t117, { i64, ptr } %t115)
  store %"compiler/diagmsg:Msg" %t119, ptr %l65
  br label %bb31
bb31:
  %t120 = load %"compiler/diagmsg:Msg", ptr %l65
  %t121 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store %"compiler/diagmsg:Msg" %t120, ptr %t121
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t121, ptr %rv
  br label %ret
bb32:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/check:fieldSet", ptr %t123, i32 0, i32 2
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l68, !tbaa !27
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l2, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t127, i32 %t128)
  store { i64, ptr } %t131, ptr %l71
  br label %bb33
bb33:
  %t132 = load ptr, ptr %l3, !tbaa !29
  %t134 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s0, ptr %s0, ptr %t132)
  store { i64, ptr } %t134, ptr %l73
  br label %bb34
bb34:
  %t135 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t139 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadNoField(ptr %v1, ptr %v0, ptr %s0, ptr %v2, { i64, ptr } %t136, { i64, ptr } %t137, { i64, ptr } %t135)
  store %"compiler/diagmsg:Msg" %t139, ptr %l75
  br label %bb35
bb35:
  %t140 = load %"compiler/diagmsg:Msg", ptr %l75
  %t141 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store %"compiler/diagmsg:Msg" %t140, ptr %t141
  call void @__olang_scope_close(ptr %s0)
  store ptr %t141, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonce(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l36 = alloca i32
  %l37 = alloca i64
  %l49 = alloca ptr
  %rv = alloca ptr
  %t78 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %rv
  br label %ret
bb6:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 18}
  %t19 = icmp eq i64 %t17, 2
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb12, label %bb13
bb12:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 8}
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb14:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t38, i32 0, i32 0
  %t40 = load %"compiler/source:Span", ptr %t39
  store %"compiler/source:Span" %t40, ptr %l3
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t44, i32 0, i32 1
  %t46 = load i32, ptr %t45
  store i32 %t46, ptr %l4, !tbaa !23
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t50, i32 0, i32 2
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l5, !tbaa !23
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9e3e60c51c241998_753bf57c496fa07c)
  unreachable
bb22:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t56)
  store %"compiler/source:Span" %t58, ptr %l31
  br label %bb23
bb23:
  %t59 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t59, ptr %l6
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l32, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t61, ptr %l33
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t65 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t62)
  store i32 %t65, ptr %l36
  br label %bb24
bb24:
  %t66 = load ptr, ptr %l32, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l33
  %t68 = load i32, ptr %l36, !tbaa !23
  %t69 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t66, %"compiler/source:Span" %t67, i32 %t68)
  store i64 %t69, ptr %l37
  br label %bb25
bb25:
  %t70 = load i64, ptr %l37, !tbaa !24
  store i64 %t70, ptr %l7, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l6
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = trunc i64 %t73 to i32
  %t77 = load ptr, ptr %l1, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t81 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t72, 0
  %t83 = insertvalue { %"compiler/source:Span", i32, ptr } %t81, i32 %t75, 1
  %t85 = insertvalue { %"compiler/source:Span", i32, ptr } %t83, ptr %t77, 2
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t85, ptr %t86
  %t87 = load { i64, [3 x i64] }, ptr %t78
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t87, ptr %t89
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t71, ptr %t89)
  br label %bb26
bb26:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l6
  %t94 = load i64, ptr %l7, !tbaa !24
  %t98 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t92, %"compiler/source:Span" %t93, i64 %t94)
  store ptr %t98, ptr %l49
  br label %bb27
bb27:
  %t99 = load ptr, ptr %l49, !tbaa !29
  store ptr %t99, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l42 = alloca i1
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i64
  %l49 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l66 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l75 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l81 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l82 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %l90 = alloca i64
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l98 = alloca i64
  %l100 = alloca { i64, ptr }
  %l101 = alloca i64
  %l102 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l107 = alloca i64
  %l110 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l111 = alloca i64
  %l113 = alloca { i64, ptr }
  %l114 = alloca i64
  %l115 = alloca { i64, ptr }
  %l119 = alloca i64
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l127 = alloca i64
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l131 = alloca { i64, ptr }
  %l136 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 133
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l5
  %t6 = call ptr @__olang_scope_hold(ptr %v2)
  %t7 = ptrtoint ptr %t6 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = call ptr @__olang_region_make_part(ptr %v2)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load i64, ptr %l9, !tbaa !24
  %t17 = mul i64 %t16, 16
  %t18 = load i64, ptr %l6
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  %t21 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l10, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l9, !tbaa !24
  %t28 = mul i64 %t27, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t30 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 0
  store { i64, ptr } %t29, ptr %t30, !tbaa !27
  %t31 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0
  br i1 %t31, label %bb3, label %bb4
bb3:
  %t33 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t37 = icmp eq i64 %t35, 0
  br i1 %t37, label %bb5, label %bb6
bb4:
  %t39 = call ptr @__olang_scope_hold(ptr %v2)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l14, !tbaa !24
  %t41 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1
  br i1 %t41, label %bb7, label %bb8
bb5:
  %t43 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t43, !tbaa !27
  br label %bb6
bb6:
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 0
  %t45 = load i64, ptr %l6
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = load { i64, ptr }, ptr %t44
  %t48 = extractvalue { i64, ptr } %t47, 1
  %t49 = call ptr @__olang_region_or(ptr %t48, ptr null)
  %t50 = icmp ne ptr %t49, null
  %t51 = select i1 %t50, ptr %t49, ptr null
  call void @__olang_region_settle_in(ptr %t46, ptr %t51)
  br label %bb4
bb7:
  %t52 = call ptr @__olang_region_make_part(ptr %v2)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l14, !tbaa !24
  br label %bb8
bb8:
  %t54 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 1
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l16, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l17, !tbaa !24
  %t58 = load i64, ptr %l17, !tbaa !24
  %t59 = mul i64 %t58, 8
  %t60 = load i64, ptr %l14
  %t61 = inttoptr i64 %t60 to ptr
  %t62 = call ptr @__olang_held_alloc(ptr %t61, i64 %t59)
  %t63 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l18, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l17, !tbaa !24
  %t70 = mul i64 %t69, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %t68, i64 %t70, i1 false)
  %t71 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t72 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 1
  store { i64, ptr } %t71, ptr %t72, !tbaa !27
  %t73 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1
  br i1 %t73, label %bb9, label %bb10
bb9:
  %t75 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  %t79 = icmp eq i64 %t77, 0
  br i1 %t79, label %bb11, label %bb12
bb10:
  %t81 = call ptr @__olang_scope_hold(ptr %v2)
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l22, !tbaa !24
  %t83 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2
  br i1 %t83, label %bb13, label %bb14
bb11:
  %t85 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t85, !tbaa !27
  br label %bb12
bb12:
  %t86 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 1
  %t87 = load i64, ptr %l14
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = load { i64, ptr }, ptr %t86
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = call ptr @__olang_region_or(ptr %t90, ptr null)
  %t92 = icmp ne ptr %t91, null
  %t93 = select i1 %t92, ptr %t91, ptr null
  call void @__olang_region_settle_in(ptr %t88, ptr %t93)
  br label %bb10
bb13:
  %t94 = call ptr @__olang_region_make_part(ptr %v2)
  %t95 = ptrtoint ptr %t94 to i64
  store i64 %t95, ptr %l22, !tbaa !24
  br label %bb14
bb14:
  %t96 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l24, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l25, !tbaa !24
  %t100 = load i64, ptr %l25, !tbaa !24
  %t101 = mul i64 %t100, 8
  %t102 = load i64, ptr %l22
  %t103 = inttoptr i64 %t102 to ptr
  %t104 = call ptr @__olang_held_alloc(ptr %t103, i64 %t101)
  %t105 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l26, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l25, !tbaa !24
  %t112 = mul i64 %t111, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %t110, i64 %t112, i1 false)
  %t113 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 2
  store { i64, ptr } %t113, ptr %t114, !tbaa !27
  %t115 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2
  br i1 %t115, label %bb15, label %bb16
bb15:
  %t117 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 2
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t121 = icmp eq i64 %t119, 0
  br i1 %t121, label %bb17, label %bb18
bb16:
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store ptr %t123, ptr %lp2
  %t124 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t125 = load ptr, ptr %lp2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t124, ptr %t125
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l30, !tbaa !29
  %t127 = call ptr @__olang_scope_hold(ptr %v0)
  %t128 = ptrtoint ptr %t127 to i64
  store i64 %t128, ptr %l31, !tbaa !24
  %t129 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e133
  br i1 %t129, label %bb19, label %bb20
bb17:
  %t131 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t131, !tbaa !27
  br label %bb18
bb18:
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 2
  %t133 = load i64, ptr %l22
  %t134 = inttoptr i64 %t133 to ptr
  %t135 = load { i64, ptr }, ptr %t132
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = call ptr @__olang_region_or(ptr %t136, ptr null)
  %t138 = icmp ne ptr %t137, null
  %t139 = select i1 %t138, ptr %t137, ptr null
  call void @__olang_region_settle_in(ptr %t134, ptr %t139)
  br label %bb16
bb19:
  %t140 = call ptr @__olang_region_make(ptr %v0)
  %t141 = ptrtoint ptr %t140 to i64
  store i64 %t141, ptr %l31, !tbaa !24
  br label %bb20
bb20:
  %t142 = load i64, ptr %l31
  %t143 = inttoptr i64 %t142 to ptr
  %t144 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %t143)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t144, ptr %l33
  br label %bb21
bb21:
  %t145 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e133
  br i1 %t145, label %bb22, label %bb23
bb22:
  %t147 = load i64, ptr %l31
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33, i32 0, i32 2
  %t150 = load { i64, ptr }, ptr %t149
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = call ptr @__olang_region_or(ptr %t151, ptr null)
  %t153 = call ptr @__olang_region_home(ptr %t152)
  %t154 = icmp ne ptr %t153, null
  %t155 = select i1 %t154, ptr %t153, ptr null
  %t156 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33, i32 0, i32 1
  %t157 = load { i64, ptr }, ptr %t156
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = call ptr @__olang_region_or(ptr %t158, ptr null)
  %t160 = call ptr @__olang_region_home(ptr %t159)
  %t161 = icmp ne ptr %t160, null
  %t162 = select i1 %t161, ptr %t160, ptr %t155
  %t163 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33, i32 0, i32 0
  %t164 = load { i64, ptr }, ptr %t163
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = call ptr @__olang_region_or(ptr %t165, ptr null)
  %t167 = call ptr @__olang_region_home(ptr %t166)
  %t168 = icmp ne ptr %t167, null
  %t169 = select i1 %t168, ptr %t167, ptr %t162
  call void @__olang_region_settle_in(ptr %t148, ptr %t169)
  br label %bb23
bb23:
  %t170 = load ptr, ptr %l30, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 133
  %t172 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t171
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t172, ptr %l35
  %t173 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33
  %t174 = load ptr, ptr %l30, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 133
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t173, ptr %t175
  %t176 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e133
  br i1 %t176, label %bb24, label %bb25
bb24:
  %t178 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35, i32 0, i32 2
  %t179 = load { i64, ptr }, ptr %t178
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = call ptr @__olang_region_or(ptr %t180, ptr null)
  %t182 = call ptr @__olang_region_home(ptr %t181)
  %t183 = icmp ne ptr %t182, null
  %t184 = select i1 %t183, ptr %t182, ptr null
  %t185 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35, i32 0, i32 1
  %t186 = load { i64, ptr }, ptr %t185
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = call ptr @__olang_region_or(ptr %t187, ptr null)
  %t189 = call ptr @__olang_region_home(ptr %t188)
  %t190 = icmp ne ptr %t189, null
  %t191 = select i1 %t190, ptr %t189, ptr %t184
  %t192 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35, i32 0, i32 0
  %t193 = load { i64, ptr }, ptr %t192
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = call ptr @__olang_region_or(ptr %t194, ptr null)
  %t196 = call ptr @__olang_region_home(ptr %t195)
  %t197 = icmp ne ptr %t196, null
  %t198 = select i1 %t197, ptr %t196, ptr %t191
  call void @__olang_region_drop(ptr %t198)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l35
  br label %bb25
bb25:
  %t199 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0
  br i1 %t199, label %bb26, label %bb27
bb26:
  %t201 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35, i32 0, i32 0
  %t202 = load { i64, ptr }, ptr %t201
  %t203 = extractvalue { i64, ptr } %t202, 0
  %t204 = extractvalue { i64, ptr } %t202, 1
  call void @__olang_region_release_part(ptr %t204, i64 %t203)
  store { i64, ptr } zeroinitializer, ptr %t201
  br label %bb27
bb27:
  %t205 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1
  br i1 %t205, label %bb28, label %bb29
bb28:
  %t207 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35, i32 0, i32 1
  %t208 = load { i64, ptr }, ptr %t207
  %t209 = extractvalue { i64, ptr } %t208, 0
  %t210 = extractvalue { i64, ptr } %t208, 1
  call void @__olang_region_release_part(ptr %t210, i64 %t209)
  store { i64, ptr } zeroinitializer, ptr %t207
  br label %bb29
bb29:
  %t211 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2
  br i1 %t211, label %bb30, label %bb31
bb30:
  %t213 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35, i32 0, i32 2
  %t214 = load { i64, ptr }, ptr %t213
  %t215 = extractvalue { i64, ptr } %t214, 0
  %t216 = extractvalue { i64, ptr } %t214, 1
  call void @__olang_region_release_part(ptr %t216, i64 %t215)
  store { i64, ptr } zeroinitializer, ptr %t213
  br label %bb31
bb31:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t221 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsFixed(ptr %v0, ptr %v1, ptr %t217, ptr %a1)
  store i1 %t221, ptr %l42
  br label %bb32
bb32:
  %t222 = load i1, ptr %l42, !tbaa !21
  %t223 = xor i1 %t222, true
  br i1 %t223, label %bb33, label %bb34
bb33:
  store i32 65536, ptr %l44, !tbaa !23
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l45, !tbaa !29
  %t226 = call ptr @__olang_scope_hold(ptr %v0)
  %t227 = ptrtoint ptr %t226 to i64
  store i64 %t227, ptr %l46, !tbaa !24
  %t228 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e133
  br i1 %t228, label %bb35, label %bb36
bb34:
  br label %bb65
bb35:
  %t230 = call ptr @__olang_region_make(ptr %v0)
  %t231 = ptrtoint ptr %t230 to i64
  store i64 %t231, ptr %l46, !tbaa !24
  br label %bb36
bb36:
  %t232 = load ptr, ptr %lp2
  %t233 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t232
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t233, ptr %l49
  %t235 = load i64, ptr %l46
  %t236 = inttoptr i64 %t235 to ptr
  %t237 = call ptr @__olang_scope_hold(ptr %t236)
  %t238 = ptrtoint ptr %t237 to i64
  store i64 %t238, ptr %l50, !tbaa !24
  %t239 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0
  br i1 %t239, label %bb37, label %bb38
bb37:
  %t241 = load i64, ptr %l46
  %t242 = inttoptr i64 %t241 to ptr
  %t243 = call ptr @__olang_region_make_part(ptr %t242)
  %t244 = ptrtoint ptr %t243 to i64
  store i64 %t244, ptr %l50, !tbaa !24
  br label %bb38
bb38:
  %t245 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 0
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  store { i64, ptr } %t246, ptr %l52, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 0
  store i64 %t248, ptr %l53, !tbaa !24
  %t249 = load i64, ptr %l53, !tbaa !24
  %t250 = mul i64 %t249, 16
  %t251 = load i64, ptr %l50
  %t252 = inttoptr i64 %t251 to ptr
  %t253 = call ptr @__olang_held_alloc(ptr %t252, i64 %t250)
  %t254 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  store { i64, ptr } %t255, ptr %l54, !tbaa !27
  %t256 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = load i64, ptr %l53, !tbaa !24
  %t261 = mul i64 %t260, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t257, ptr %t259, i64 %t261, i1 false)
  %t262 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t263 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 0
  store { i64, ptr } %t262, ptr %t263, !tbaa !27
  %t264 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0
  br i1 %t264, label %bb39, label %bb40
bb39:
  %t266 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 0
  %t267 = load { i64, ptr }, ptr %t266, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 0
  %t270 = icmp eq i64 %t268, 0
  br i1 %t270, label %bb41, label %bb42
bb40:
  %t272 = load i64, ptr %l46
  %t273 = inttoptr i64 %t272 to ptr
  %t274 = call ptr @__olang_scope_hold(ptr %t273)
  %t275 = ptrtoint ptr %t274 to i64
  store i64 %t275, ptr %l58, !tbaa !24
  %t276 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1
  br i1 %t276, label %bb43, label %bb44
bb41:
  %t278 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t278, !tbaa !27
  br label %bb42
bb42:
  %t279 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 0
  %t280 = load i64, ptr %l50
  %t281 = inttoptr i64 %t280 to ptr
  %t282 = load { i64, ptr }, ptr %t279
  %t283 = extractvalue { i64, ptr } %t282, 1
  %t284 = call ptr @__olang_region_or(ptr %t283, ptr null)
  %t285 = icmp ne ptr %t284, null
  %t286 = select i1 %t285, ptr %t284, ptr null
  call void @__olang_region_settle_in(ptr %t281, ptr %t286)
  br label %bb40
bb43:
  %t287 = load i64, ptr %l46
  %t288 = inttoptr i64 %t287 to ptr
  %t289 = call ptr @__olang_region_make_part(ptr %t288)
  %t290 = ptrtoint ptr %t289 to i64
  store i64 %t290, ptr %l58, !tbaa !24
  br label %bb44
bb44:
  %t291 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 1
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  store { i64, ptr } %t292, ptr %l60, !tbaa !27
  %t293 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t293, 0
  store i64 %t294, ptr %l61, !tbaa !24
  %t295 = load i64, ptr %l61, !tbaa !24
  %t296 = mul i64 %t295, 8
  %t297 = load i64, ptr %l58
  %t298 = inttoptr i64 %t297 to ptr
  %t299 = call ptr @__olang_held_alloc(ptr %t298, i64 %t296)
  %t300 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  store { i64, ptr } %t301, ptr %l62, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = load i64, ptr %l61, !tbaa !24
  %t307 = mul i64 %t306, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t303, ptr %t305, i64 %t307, i1 false)
  %t308 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t309 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 1
  store { i64, ptr } %t308, ptr %t309, !tbaa !27
  %t310 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1
  br i1 %t310, label %bb45, label %bb46
bb45:
  %t312 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 1
  %t313 = load { i64, ptr }, ptr %t312, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 0
  %t316 = icmp eq i64 %t314, 0
  br i1 %t316, label %bb47, label %bb48
bb46:
  %t318 = load i64, ptr %l46
  %t319 = inttoptr i64 %t318 to ptr
  %t320 = call ptr @__olang_scope_hold(ptr %t319)
  %t321 = ptrtoint ptr %t320 to i64
  store i64 %t321, ptr %l66, !tbaa !24
  %t322 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2
  br i1 %t322, label %bb49, label %bb50
bb47:
  %t324 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t324, !tbaa !27
  br label %bb48
bb48:
  %t325 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 1
  %t326 = load i64, ptr %l58
  %t327 = inttoptr i64 %t326 to ptr
  %t328 = load { i64, ptr }, ptr %t325
  %t329 = extractvalue { i64, ptr } %t328, 1
  %t330 = call ptr @__olang_region_or(ptr %t329, ptr null)
  %t331 = icmp ne ptr %t330, null
  %t332 = select i1 %t331, ptr %t330, ptr null
  call void @__olang_region_settle_in(ptr %t327, ptr %t332)
  br label %bb46
bb49:
  %t333 = load i64, ptr %l46
  %t334 = inttoptr i64 %t333 to ptr
  %t335 = call ptr @__olang_region_make_part(ptr %t334)
  %t336 = ptrtoint ptr %t335 to i64
  store i64 %t336, ptr %l66, !tbaa !24
  br label %bb50
bb50:
  %t337 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 2
  %t338 = load { i64, ptr }, ptr %t337, !tbaa !27
  store { i64, ptr } %t338, ptr %l68, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  store i64 %t340, ptr %l69, !tbaa !24
  %t341 = load i64, ptr %l69, !tbaa !24
  %t342 = mul i64 %t341, 8
  %t343 = load i64, ptr %l66
  %t344 = inttoptr i64 %t343 to ptr
  %t345 = call ptr @__olang_held_alloc(ptr %t344, i64 %t342)
  %t346 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t345, 1
  store { i64, ptr } %t347, ptr %l70, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = load i64, ptr %l69, !tbaa !24
  %t353 = mul i64 %t352, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t349, ptr %t351, i64 %t353, i1 false)
  %t354 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t355 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 2
  store { i64, ptr } %t354, ptr %t355, !tbaa !27
  %t356 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2
  br i1 %t356, label %bb51, label %bb52
bb51:
  %t358 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 2
  %t359 = load { i64, ptr }, ptr %t358, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 0
  %t362 = icmp eq i64 %t360, 0
  br i1 %t362, label %bb53, label %bb54
bb52:
  %t364 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e133
  br i1 %t364, label %bb55, label %bb56
bb53:
  %t366 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t366, !tbaa !27
  br label %bb54
bb54:
  %t367 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 2
  %t368 = load i64, ptr %l66
  %t369 = inttoptr i64 %t368 to ptr
  %t370 = load { i64, ptr }, ptr %t367
  %t371 = extractvalue { i64, ptr } %t370, 1
  %t372 = call ptr @__olang_region_or(ptr %t371, ptr null)
  %t373 = icmp ne ptr %t372, null
  %t374 = select i1 %t373, ptr %t372, ptr null
  call void @__olang_region_settle_in(ptr %t369, ptr %t374)
  br label %bb52
bb55:
  %t375 = load i64, ptr %l46
  %t376 = inttoptr i64 %t375 to ptr
  %t377 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 2
  %t378 = load { i64, ptr }, ptr %t377
  %t379 = extractvalue { i64, ptr } %t378, 1
  %t380 = call ptr @__olang_region_or(ptr %t379, ptr null)
  %t381 = call ptr @__olang_region_home(ptr %t380)
  %t382 = icmp ne ptr %t381, null
  %t383 = select i1 %t382, ptr %t381, ptr null
  %t384 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 1
  %t385 = load { i64, ptr }, ptr %t384
  %t386 = extractvalue { i64, ptr } %t385, 1
  %t387 = call ptr @__olang_region_or(ptr %t386, ptr null)
  %t388 = call ptr @__olang_region_home(ptr %t387)
  %t389 = icmp ne ptr %t388, null
  %t390 = select i1 %t389, ptr %t388, ptr %t383
  %t391 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49, i32 0, i32 0
  %t392 = load { i64, ptr }, ptr %t391
  %t393 = extractvalue { i64, ptr } %t392, 1
  %t394 = call ptr @__olang_region_or(ptr %t393, ptr null)
  %t395 = call ptr @__olang_region_home(ptr %t394)
  %t396 = icmp ne ptr %t395, null
  %t397 = select i1 %t396, ptr %t395, ptr %t390
  call void @__olang_region_settle_in(ptr %t376, ptr %t397)
  br label %bb56
bb56:
  %t398 = load ptr, ptr %l45, !tbaa !29
  %t399 = getelementptr %"compiler/check:Checker", ptr %t398, i32 0, i32 133
  %t400 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t399
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t400, ptr %l75
  %t401 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49
  %t402 = load ptr, ptr %l45, !tbaa !29
  %t403 = getelementptr %"compiler/check:Checker", ptr %t402, i32 0, i32 133
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t401, ptr %t403
  %t404 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e133
  br i1 %t404, label %bb57, label %bb58
bb57:
  %t406 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l75, i32 0, i32 2
  %t407 = load { i64, ptr }, ptr %t406
  %t408 = extractvalue { i64, ptr } %t407, 1
  %t409 = call ptr @__olang_region_or(ptr %t408, ptr null)
  %t410 = call ptr @__olang_region_home(ptr %t409)
  %t411 = icmp ne ptr %t410, null
  %t412 = select i1 %t411, ptr %t410, ptr null
  %t413 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l75, i32 0, i32 1
  %t414 = load { i64, ptr }, ptr %t413
  %t415 = extractvalue { i64, ptr } %t414, 1
  %t416 = call ptr @__olang_region_or(ptr %t415, ptr null)
  %t417 = call ptr @__olang_region_home(ptr %t416)
  %t418 = icmp ne ptr %t417, null
  %t419 = select i1 %t418, ptr %t417, ptr %t412
  %t420 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l75, i32 0, i32 0
  %t421 = load { i64, ptr }, ptr %t420
  %t422 = extractvalue { i64, ptr } %t421, 1
  %t423 = call ptr @__olang_region_or(ptr %t422, ptr null)
  %t424 = call ptr @__olang_region_home(ptr %t423)
  %t425 = icmp ne ptr %t424, null
  %t426 = select i1 %t425, ptr %t424, ptr %t419
  call void @__olang_region_drop(ptr %t426)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l75
  br label %bb58
bb58:
  %t427 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0
  br i1 %t427, label %bb59, label %bb60
bb59:
  %t429 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l75, i32 0, i32 0
  %t430 = load { i64, ptr }, ptr %t429
  %t431 = extractvalue { i64, ptr } %t430, 0
  %t432 = extractvalue { i64, ptr } %t430, 1
  call void @__olang_region_release_part(ptr %t432, i64 %t431)
  store { i64, ptr } zeroinitializer, ptr %t429
  br label %bb60
bb60:
  %t433 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1
  br i1 %t433, label %bb61, label %bb62
bb61:
  %t435 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l75, i32 0, i32 1
  %t436 = load { i64, ptr }, ptr %t435
  %t437 = extractvalue { i64, ptr } %t436, 0
  %t438 = extractvalue { i64, ptr } %t436, 1
  call void @__olang_region_release_part(ptr %t438, i64 %t437)
  store { i64, ptr } zeroinitializer, ptr %t435
  br label %bb62
bb62:
  %t439 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2
  br i1 %t439, label %bb63, label %bb64
bb63:
  %t441 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l75, i32 0, i32 2
  %t442 = load { i64, ptr }, ptr %t441
  %t443 = extractvalue { i64, ptr } %t442, 0
  %t444 = extractvalue { i64, ptr } %t442, 1
  call void @__olang_region_release_part(ptr %t444, i64 %t443)
  store { i64, ptr } zeroinitializer, ptr %t441
  br label %bb64
bb64:
  %t445 = load i32, ptr %l44, !tbaa !23
  %t446 = insertvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } zeroinitializer, i32 %t445, 0
  store { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t446, ptr %rv
  br label %ret
bb65:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 133
  %t450 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t449
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t450, ptr %l81
  %t451 = call ptr @__olang_scope_hold(ptr %v2)
  %t452 = ptrtoint ptr %t451 to i64
  store i64 %t452, ptr %l82, !tbaa !24
  %t453 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0
  br i1 %t453, label %bb66, label %bb67
bb66:
  %t455 = call ptr @__olang_region_make_part(ptr %v2)
  %t456 = ptrtoint ptr %t455 to i64
  store i64 %t456, ptr %l82, !tbaa !24
  br label %bb67
bb67:
  %t457 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 0
  %t458 = load { i64, ptr }, ptr %t457, !tbaa !27
  store { i64, ptr } %t458, ptr %l84, !tbaa !27
  %t459 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t459, 0
  store i64 %t460, ptr %l85, !tbaa !24
  %t461 = load i64, ptr %l85, !tbaa !24
  %t462 = mul i64 %t461, 16
  %t463 = load i64, ptr %l82
  %t464 = inttoptr i64 %t463 to ptr
  %t465 = call ptr @__olang_held_alloc(ptr %t464, i64 %t462)
  %t466 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t465, 1
  store { i64, ptr } %t467, ptr %l86, !tbaa !27
  %t468 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t469 = load ptr, ptr %t468, !tbaa !27
  %t470 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !27
  %t472 = load i64, ptr %l85, !tbaa !24
  %t473 = mul i64 %t472, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t469, ptr %t471, i64 %t473, i1 false)
  %t474 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t475 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 0
  store { i64, ptr } %t474, ptr %t475, !tbaa !27
  %t476 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0
  br i1 %t476, label %bb68, label %bb69
bb68:
  %t478 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 0
  %t479 = load { i64, ptr }, ptr %t478, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t479, 0
  %t482 = icmp eq i64 %t480, 0
  br i1 %t482, label %bb70, label %bb71
bb69:
  %t484 = call ptr @__olang_scope_hold(ptr %v2)
  %t485 = ptrtoint ptr %t484 to i64
  store i64 %t485, ptr %l90, !tbaa !24
  %t486 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1
  br i1 %t486, label %bb72, label %bb73
bb70:
  %t488 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t488, !tbaa !27
  br label %bb71
bb71:
  %t489 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 0
  %t490 = load i64, ptr %l82
  %t491 = inttoptr i64 %t490 to ptr
  %t492 = load { i64, ptr }, ptr %t489
  %t493 = extractvalue { i64, ptr } %t492, 1
  %t494 = call ptr @__olang_region_or(ptr %t493, ptr null)
  %t495 = icmp ne ptr %t494, null
  %t496 = select i1 %t495, ptr %t494, ptr null
  call void @__olang_region_settle_in(ptr %t491, ptr %t496)
  br label %bb69
bb72:
  %t497 = call ptr @__olang_region_make_part(ptr %v2)
  %t498 = ptrtoint ptr %t497 to i64
  store i64 %t498, ptr %l90, !tbaa !24
  br label %bb73
bb73:
  %t499 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 1
  %t500 = load { i64, ptr }, ptr %t499, !tbaa !27
  store { i64, ptr } %t500, ptr %l92, !tbaa !27
  %t501 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 0
  store i64 %t502, ptr %l93, !tbaa !24
  %t503 = load i64, ptr %l93, !tbaa !24
  %t504 = mul i64 %t503, 8
  %t505 = load i64, ptr %l90
  %t506 = inttoptr i64 %t505 to ptr
  %t507 = call ptr @__olang_held_alloc(ptr %t506, i64 %t504)
  %t508 = insertvalue { i64, ptr } undef, i64 %t503, 0
  %t509 = insertvalue { i64, ptr } %t508, ptr %t507, 1
  store { i64, ptr } %t509, ptr %l94, !tbaa !27
  %t510 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t513 = load ptr, ptr %t512, !tbaa !27
  %t514 = load i64, ptr %l93, !tbaa !24
  %t515 = mul i64 %t514, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t511, ptr %t513, i64 %t515, i1 false)
  %t516 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t517 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 1
  store { i64, ptr } %t516, ptr %t517, !tbaa !27
  %t518 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1
  br i1 %t518, label %bb74, label %bb75
bb74:
  %t520 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 1
  %t521 = load { i64, ptr }, ptr %t520, !tbaa !27
  %t522 = extractvalue { i64, ptr } %t521, 0
  %t524 = icmp eq i64 %t522, 0
  br i1 %t524, label %bb76, label %bb77
bb75:
  %t526 = call ptr @__olang_scope_hold(ptr %v2)
  %t527 = ptrtoint ptr %t526 to i64
  store i64 %t527, ptr %l98, !tbaa !24
  %t528 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2
  br i1 %t528, label %bb78, label %bb79
bb76:
  %t530 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t530, !tbaa !27
  br label %bb77
bb77:
  %t531 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 1
  %t532 = load i64, ptr %l90
  %t533 = inttoptr i64 %t532 to ptr
  %t534 = load { i64, ptr }, ptr %t531
  %t535 = extractvalue { i64, ptr } %t534, 1
  %t536 = call ptr @__olang_region_or(ptr %t535, ptr null)
  %t537 = icmp ne ptr %t536, null
  %t538 = select i1 %t537, ptr %t536, ptr null
  call void @__olang_region_settle_in(ptr %t533, ptr %t538)
  br label %bb75
bb78:
  %t539 = call ptr @__olang_region_make_part(ptr %v2)
  %t540 = ptrtoint ptr %t539 to i64
  store i64 %t540, ptr %l98, !tbaa !24
  br label %bb79
bb79:
  %t541 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 2
  %t542 = load { i64, ptr }, ptr %t541, !tbaa !27
  store { i64, ptr } %t542, ptr %l100, !tbaa !27
  %t543 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t544 = extractvalue { i64, ptr } %t543, 0
  store i64 %t544, ptr %l101, !tbaa !24
  %t545 = load i64, ptr %l101, !tbaa !24
  %t546 = mul i64 %t545, 8
  %t547 = load i64, ptr %l98
  %t548 = inttoptr i64 %t547 to ptr
  %t549 = call ptr @__olang_held_alloc(ptr %t548, i64 %t546)
  %t550 = insertvalue { i64, ptr } undef, i64 %t545, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t549, 1
  store { i64, ptr } %t551, ptr %l102, !tbaa !27
  %t552 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t553 = load ptr, ptr %t552, !tbaa !27
  %t554 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !27
  %t556 = load i64, ptr %l101, !tbaa !24
  %t557 = mul i64 %t556, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t553, ptr %t555, i64 %t557, i1 false)
  %t558 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t559 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 2
  store { i64, ptr } %t558, ptr %t559, !tbaa !27
  %t560 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2
  br i1 %t560, label %bb80, label %bb81
bb80:
  %t562 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 2
  %t563 = load { i64, ptr }, ptr %t562, !tbaa !27
  %t564 = extractvalue { i64, ptr } %t563, 0
  %t566 = icmp eq i64 %t564, 0
  br i1 %t566, label %bb82, label %bb83
bb81:
  %t568 = load ptr, ptr %l0, !tbaa !29
  store ptr %t568, ptr %l106, !tbaa !29
  %t569 = call ptr @__olang_scope_hold(ptr %v0)
  %t570 = ptrtoint ptr %t569 to i64
  store i64 %t570, ptr %l107, !tbaa !24
  %t571 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e133
  br i1 %t571, label %bb84, label %bb85
bb82:
  %t573 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t573, !tbaa !27
  br label %bb83
bb83:
  %t574 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81, i32 0, i32 2
  %t575 = load i64, ptr %l98
  %t576 = inttoptr i64 %t575 to ptr
  %t577 = load { i64, ptr }, ptr %t574
  %t578 = extractvalue { i64, ptr } %t577, 1
  %t579 = call ptr @__olang_region_or(ptr %t578, ptr null)
  %t580 = icmp ne ptr %t579, null
  %t581 = select i1 %t580, ptr %t579, ptr null
  call void @__olang_region_settle_in(ptr %t576, ptr %t581)
  br label %bb81
bb84:
  %t582 = call ptr @__olang_region_make(ptr %v0)
  %t583 = ptrtoint ptr %t582 to i64
  store i64 %t583, ptr %l107, !tbaa !24
  br label %bb85
bb85:
  %t584 = load ptr, ptr %lp2
  %t585 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t584
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t585, ptr %l110
  %t587 = load i64, ptr %l107
  %t588 = inttoptr i64 %t587 to ptr
  %t589 = call ptr @__olang_scope_hold(ptr %t588)
  %t590 = ptrtoint ptr %t589 to i64
  store i64 %t590, ptr %l111, !tbaa !24
  %t591 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0
  br i1 %t591, label %bb86, label %bb87
bb86:
  %t593 = load i64, ptr %l107
  %t594 = inttoptr i64 %t593 to ptr
  %t595 = call ptr @__olang_region_make_part(ptr %t594)
  %t596 = ptrtoint ptr %t595 to i64
  store i64 %t596, ptr %l111, !tbaa !24
  br label %bb87
bb87:
  %t597 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 0
  %t598 = load { i64, ptr }, ptr %t597, !tbaa !27
  store { i64, ptr } %t598, ptr %l113, !tbaa !27
  %t599 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t600 = extractvalue { i64, ptr } %t599, 0
  store i64 %t600, ptr %l114, !tbaa !24
  %t601 = load i64, ptr %l114, !tbaa !24
  %t602 = mul i64 %t601, 16
  %t603 = load i64, ptr %l111
  %t604 = inttoptr i64 %t603 to ptr
  %t605 = call ptr @__olang_held_alloc(ptr %t604, i64 %t602)
  %t606 = insertvalue { i64, ptr } undef, i64 %t601, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t605, 1
  store { i64, ptr } %t607, ptr %l115, !tbaa !27
  %t608 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t609 = load ptr, ptr %t608, !tbaa !27
  %t610 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !27
  %t612 = load i64, ptr %l114, !tbaa !24
  %t613 = mul i64 %t612, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t609, ptr %t611, i64 %t613, i1 false)
  %t614 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t615 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 0
  store { i64, ptr } %t614, ptr %t615, !tbaa !27
  %t616 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0
  br i1 %t616, label %bb88, label %bb89
bb88:
  %t618 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 0
  %t619 = load { i64, ptr }, ptr %t618, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t619, 0
  %t622 = icmp eq i64 %t620, 0
  br i1 %t622, label %bb90, label %bb91
bb89:
  %t624 = load i64, ptr %l107
  %t625 = inttoptr i64 %t624 to ptr
  %t626 = call ptr @__olang_scope_hold(ptr %t625)
  %t627 = ptrtoint ptr %t626 to i64
  store i64 %t627, ptr %l119, !tbaa !24
  %t628 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1
  br i1 %t628, label %bb92, label %bb93
bb90:
  %t630 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t630, !tbaa !27
  br label %bb91
bb91:
  %t631 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 0
  %t632 = load i64, ptr %l111
  %t633 = inttoptr i64 %t632 to ptr
  %t634 = load { i64, ptr }, ptr %t631
  %t635 = extractvalue { i64, ptr } %t634, 1
  %t636 = call ptr @__olang_region_or(ptr %t635, ptr null)
  %t637 = icmp ne ptr %t636, null
  %t638 = select i1 %t637, ptr %t636, ptr null
  call void @__olang_region_settle_in(ptr %t633, ptr %t638)
  br label %bb89
bb92:
  %t639 = load i64, ptr %l107
  %t640 = inttoptr i64 %t639 to ptr
  %t641 = call ptr @__olang_region_make_part(ptr %t640)
  %t642 = ptrtoint ptr %t641 to i64
  store i64 %t642, ptr %l119, !tbaa !24
  br label %bb93
bb93:
  %t643 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 1
  %t644 = load { i64, ptr }, ptr %t643, !tbaa !27
  store { i64, ptr } %t644, ptr %l121, !tbaa !27
  %t645 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t646 = extractvalue { i64, ptr } %t645, 0
  store i64 %t646, ptr %l122, !tbaa !24
  %t647 = load i64, ptr %l122, !tbaa !24
  %t648 = mul i64 %t647, 8
  %t649 = load i64, ptr %l119
  %t650 = inttoptr i64 %t649 to ptr
  %t651 = call ptr @__olang_held_alloc(ptr %t650, i64 %t648)
  %t652 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t651, 1
  store { i64, ptr } %t653, ptr %l123, !tbaa !27
  %t654 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t655 = load ptr, ptr %t654, !tbaa !27
  %t656 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t657 = load ptr, ptr %t656, !tbaa !27
  %t658 = load i64, ptr %l122, !tbaa !24
  %t659 = mul i64 %t658, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t655, ptr %t657, i64 %t659, i1 false)
  %t660 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t661 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 1
  store { i64, ptr } %t660, ptr %t661, !tbaa !27
  %t662 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1
  br i1 %t662, label %bb94, label %bb95
bb94:
  %t664 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 1
  %t665 = load { i64, ptr }, ptr %t664, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t665, 0
  %t668 = icmp eq i64 %t666, 0
  br i1 %t668, label %bb96, label %bb97
bb95:
  %t670 = load i64, ptr %l107
  %t671 = inttoptr i64 %t670 to ptr
  %t672 = call ptr @__olang_scope_hold(ptr %t671)
  %t673 = ptrtoint ptr %t672 to i64
  store i64 %t673, ptr %l127, !tbaa !24
  %t674 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2
  br i1 %t674, label %bb98, label %bb99
bb96:
  %t676 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t676, !tbaa !27
  br label %bb97
bb97:
  %t677 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 1
  %t678 = load i64, ptr %l119
  %t679 = inttoptr i64 %t678 to ptr
  %t680 = load { i64, ptr }, ptr %t677
  %t681 = extractvalue { i64, ptr } %t680, 1
  %t682 = call ptr @__olang_region_or(ptr %t681, ptr null)
  %t683 = icmp ne ptr %t682, null
  %t684 = select i1 %t683, ptr %t682, ptr null
  call void @__olang_region_settle_in(ptr %t679, ptr %t684)
  br label %bb95
bb98:
  %t685 = load i64, ptr %l107
  %t686 = inttoptr i64 %t685 to ptr
  %t687 = call ptr @__olang_region_make_part(ptr %t686)
  %t688 = ptrtoint ptr %t687 to i64
  store i64 %t688, ptr %l127, !tbaa !24
  br label %bb99
bb99:
  %t689 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 2
  %t690 = load { i64, ptr }, ptr %t689, !tbaa !27
  store { i64, ptr } %t690, ptr %l129, !tbaa !27
  %t691 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t692 = extractvalue { i64, ptr } %t691, 0
  store i64 %t692, ptr %l130, !tbaa !24
  %t693 = load i64, ptr %l130, !tbaa !24
  %t694 = mul i64 %t693, 8
  %t695 = load i64, ptr %l127
  %t696 = inttoptr i64 %t695 to ptr
  %t697 = call ptr @__olang_held_alloc(ptr %t696, i64 %t694)
  %t698 = insertvalue { i64, ptr } undef, i64 %t693, 0
  %t699 = insertvalue { i64, ptr } %t698, ptr %t697, 1
  store { i64, ptr } %t699, ptr %l131, !tbaa !27
  %t700 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t701 = load ptr, ptr %t700, !tbaa !27
  %t702 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t703 = load ptr, ptr %t702, !tbaa !27
  %t704 = load i64, ptr %l130, !tbaa !24
  %t705 = mul i64 %t704, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t701, ptr %t703, i64 %t705, i1 false)
  %t706 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t707 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 2
  store { i64, ptr } %t706, ptr %t707, !tbaa !27
  %t708 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2
  br i1 %t708, label %bb100, label %bb101
bb100:
  %t710 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 2
  %t711 = load { i64, ptr }, ptr %t710, !tbaa !27
  %t712 = extractvalue { i64, ptr } %t711, 0
  %t714 = icmp eq i64 %t712, 0
  br i1 %t714, label %bb102, label %bb103
bb101:
  %t716 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e133
  br i1 %t716, label %bb104, label %bb105
bb102:
  %t718 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t718, !tbaa !27
  br label %bb103
bb103:
  %t719 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 2
  %t720 = load i64, ptr %l127
  %t721 = inttoptr i64 %t720 to ptr
  %t722 = load { i64, ptr }, ptr %t719
  %t723 = extractvalue { i64, ptr } %t722, 1
  %t724 = call ptr @__olang_region_or(ptr %t723, ptr null)
  %t725 = icmp ne ptr %t724, null
  %t726 = select i1 %t725, ptr %t724, ptr null
  call void @__olang_region_settle_in(ptr %t721, ptr %t726)
  br label %bb101
bb104:
  %t727 = load i64, ptr %l107
  %t728 = inttoptr i64 %t727 to ptr
  %t729 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 2
  %t730 = load { i64, ptr }, ptr %t729
  %t731 = extractvalue { i64, ptr } %t730, 1
  %t732 = call ptr @__olang_region_or(ptr %t731, ptr null)
  %t733 = call ptr @__olang_region_home(ptr %t732)
  %t734 = icmp ne ptr %t733, null
  %t735 = select i1 %t734, ptr %t733, ptr null
  %t736 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 1
  %t737 = load { i64, ptr }, ptr %t736
  %t738 = extractvalue { i64, ptr } %t737, 1
  %t739 = call ptr @__olang_region_or(ptr %t738, ptr null)
  %t740 = call ptr @__olang_region_home(ptr %t739)
  %t741 = icmp ne ptr %t740, null
  %t742 = select i1 %t741, ptr %t740, ptr %t735
  %t743 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 0
  %t744 = load { i64, ptr }, ptr %t743
  %t745 = extractvalue { i64, ptr } %t744, 1
  %t746 = call ptr @__olang_region_or(ptr %t745, ptr null)
  %t747 = call ptr @__olang_region_home(ptr %t746)
  %t748 = icmp ne ptr %t747, null
  %t749 = select i1 %t748, ptr %t747, ptr %t742
  call void @__olang_region_settle_in(ptr %t728, ptr %t749)
  br label %bb105
bb105:
  %t750 = load ptr, ptr %l106, !tbaa !29
  %t751 = getelementptr %"compiler/check:Checker", ptr %t750, i32 0, i32 133
  %t752 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t751
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t752, ptr %l136
  %t753 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110
  %t754 = load ptr, ptr %l106, !tbaa !29
  %t755 = getelementptr %"compiler/check:Checker", ptr %t754, i32 0, i32 133
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t753, ptr %t755
  %t756 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e133
  br i1 %t756, label %bb106, label %bb107
bb106:
  %t758 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l136, i32 0, i32 2
  %t759 = load { i64, ptr }, ptr %t758
  %t760 = extractvalue { i64, ptr } %t759, 1
  %t761 = call ptr @__olang_region_or(ptr %t760, ptr null)
  %t762 = call ptr @__olang_region_home(ptr %t761)
  %t763 = icmp ne ptr %t762, null
  %t764 = select i1 %t763, ptr %t762, ptr null
  %t765 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l136, i32 0, i32 1
  %t766 = load { i64, ptr }, ptr %t765
  %t767 = extractvalue { i64, ptr } %t766, 1
  %t768 = call ptr @__olang_region_or(ptr %t767, ptr null)
  %t769 = call ptr @__olang_region_home(ptr %t768)
  %t770 = icmp ne ptr %t769, null
  %t771 = select i1 %t770, ptr %t769, ptr %t764
  %t772 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l136, i32 0, i32 0
  %t773 = load { i64, ptr }, ptr %t772
  %t774 = extractvalue { i64, ptr } %t773, 1
  %t775 = call ptr @__olang_region_or(ptr %t774, ptr null)
  %t776 = call ptr @__olang_region_home(ptr %t775)
  %t777 = icmp ne ptr %t776, null
  %t778 = select i1 %t777, ptr %t776, ptr %t771
  call void @__olang_region_drop(ptr %t778)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l136
  br label %bb107
bb107:
  %t779 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0
  br i1 %t779, label %bb108, label %bb109
bb108:
  %t781 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l136, i32 0, i32 0
  %t782 = load { i64, ptr }, ptr %t781
  %t783 = extractvalue { i64, ptr } %t782, 0
  %t784 = extractvalue { i64, ptr } %t782, 1
  call void @__olang_region_release_part(ptr %t784, i64 %t783)
  store { i64, ptr } zeroinitializer, ptr %t781
  br label %bb109
bb109:
  %t785 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1
  br i1 %t785, label %bb110, label %bb111
bb110:
  %t787 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l136, i32 0, i32 1
  %t788 = load { i64, ptr }, ptr %t787
  %t789 = extractvalue { i64, ptr } %t788, 0
  %t790 = extractvalue { i64, ptr } %t788, 1
  call void @__olang_region_release_part(ptr %t790, i64 %t789)
  store { i64, ptr } zeroinitializer, ptr %t787
  br label %bb111
bb111:
  %t791 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2
  br i1 %t791, label %bb112, label %bb113
bb112:
  %t793 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l136, i32 0, i32 2
  %t794 = load { i64, ptr }, ptr %t793
  %t795 = extractvalue { i64, ptr } %t794, 0
  %t796 = extractvalue { i64, ptr } %t794, 1
  call void @__olang_region_release_part(ptr %t796, i64 %t795)
  store { i64, ptr } zeroinitializer, ptr %t793
  br label %bb113
bb113:
  %t797 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81
  %t798 = insertvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } zeroinitializer, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t797, 1
  store { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t798, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }, ptr %rv
  ret { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %rr
}

define dso_local %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l22 = alloca { i64, ptr }
  %l27 = alloca %"compiler/check:ownerAt"
  %l37 = alloca i32
  %l38 = alloca %"compiler/check:ownerAt"
  %l41 = alloca i32
  %l45 = alloca %"compiler/check:ownerAt"
  %l50 = alloca i32
  %l51 = alloca %"compiler/check:ownerAt"
  %l54 = alloca i32
  %l60 = alloca i32
  %l61 = alloca %"compiler/check:ownerAt"
  %l64 = alloca i32
  %l68 = alloca %"compiler/check:ownerAt"
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca { i64, ptr }
  %l78 = alloca i1
  %l81 = alloca i32
  %l85 = alloca %"compiler/check:ownerAt"
  %l87 = alloca %"compiler/check:ownerAt"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"compiler/check:ownerAt"
  %t52 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb23
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v1, ptr %v0, ptr %t28)
  store { i64, ptr } %t30, ptr %l22
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t36 = icmp eq i64 %t34, 0
  br i1 %t36, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s2, i32 %t38, i1 false)
  store %"compiler/check:ownerAt" %t40, ptr %l27
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/check:ownerAt", ptr %l27
  store %"compiler/check:ownerAt" %t41, ptr %rv
  br label %ret
bb10:
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = icmp eq i64 %t44, 1
  br i1 %t46, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l2
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t52
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 0
  store i64 0, ptr %t53
  %t55 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t49, 0
  %t57 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t55, { i64, ptr } %t50, 1
  %t59 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t57, { i64, ptr } %t51, 2
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t59, ptr %t60
  %t61 = load { i64, [5 x i64] }, ptr %t52
  %t63 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t61, ptr %t63
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %v0, ptr %t48, ptr %t63)
  store i32 %t66, ptr %l37
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s3, i32 %t67, i1 false)
  store %"compiler/check:ownerAt" %t68, ptr %l38
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t69 = load %"compiler/check:ownerAt", ptr %l38
  store %"compiler/check:ownerAt" %t69, ptr %rv
  br label %ret
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t70, ptr %t71)
  store i32 %t74, ptr %l41
  br label %bb16
bb16:
  %t75 = load i32, ptr %l41, !tbaa !23
  store i32 %t75, ptr %l6, !tbaa !23
  %t76 = load i32, ptr %l6, !tbaa !23
  %t78 = icmp slt i32 %t76, 0
  br i1 %t78, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s4, i32 %t80, i1 false)
  store %"compiler/check:ownerAt" %t82, ptr %l45
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t83 = load %"compiler/check:ownerAt", ptr %l45
  store %"compiler/check:ownerAt" %t83, ptr %rv
  br label %ret
bb20:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l2
  %t86 = load i32, ptr %l6, !tbaa !23
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t92 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eapplyAt(ptr %v0, ptr %v1, ptr %t84, %"compiler/source:Span" %t85, i32 %t86, { i64, ptr } %t87)
  store i32 %t92, ptr %l50
  br label %bb21
bb21:
  %t93 = load i32, ptr %l50, !tbaa !23
  %t94 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s1, i32 %t93, i1 false)
  store %"compiler/check:ownerAt" %t94, ptr %l51
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t95 = load %"compiler/check:ownerAt", ptr %l51
  store %"compiler/check:ownerAt" %t95, ptr %rv
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_25badba18653f983_c74616522228d697)
  unreachable
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i32 %t100, ptr %l54
  br label %bb29
bb29:
  %t101 = load i32, ptr %l54, !tbaa !23
  store i32 %t101, ptr %l7, !tbaa !23
  %t102 = load i32, ptr %l7, !tbaa !23
  %t104 = icmp sge i32 %t102, 0
  br i1 %t104, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i32, ptr %l7, !tbaa !23
  %t113 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l60
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t114 = load i32, ptr %l60, !tbaa !23
  %t115 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s6, i32 %t114, i1 true)
  store %"compiler/check:ownerAt" %t115, ptr %l61
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t116 = load %"compiler/check:ownerAt", ptr %l61
  store %"compiler/check:ownerAt" %t116, ptr %rv
  br label %ret
bb34:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t121 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  store i32 %t121, ptr %l64
  br label %bb35
bb35:
  %t122 = load i32, ptr %l64, !tbaa !23
  store i32 %t122, ptr %l8, !tbaa !23
  %t123 = load i32, ptr %l8, !tbaa !23
  %t125 = icmp sge i32 %t123, 0
  br i1 %t125, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t127 = load i32, ptr %l8, !tbaa !23
  %t129 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s7, i32 %t127, i1 false)
  store %"compiler/check:ownerAt" %t129, ptr %l68
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load %"compiler/check:ownerAt", ptr %l68
  store %"compiler/check:ownerAt" %t130, ptr %rv
  br label %ret
bb39:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t132 = load ptr, ptr %l69, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb40, label %bb41
bb40:
  %t135 = load ptr, ptr %l69, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 28}
  %t138 = icmp eq i64 %t136, 12
  store i1 %t138, ptr %l70, !tbaa !21
  br label %bb41
bb41:
  %t139 = load i1, ptr %l70, !tbaa !21
  br i1 %t139, label %bb42, label %bb43
bb42:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t142, i32 0, i32 2
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l9, !tbaa !23
  br label %bb44
bb43:
  br label %bb54
bb44:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l9, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t146, i32 %t147)
  store { i64, ptr } %t150, ptr %l77
  br label %bb45
bb45:
  %t151 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t152 = call i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %t151)
  store i1 %t152, ptr %l78
  br label %bb46
bb46:
  %t153 = load i1, ptr %l78, !tbaa !21
  br i1 %t153, label %bb47, label %bb48
bb47:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t158 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t154, ptr %t155)
  store i32 %t158, ptr %l81
  br label %bb49
bb48:
  br label %bb54
bb49:
  %t159 = load i32, ptr %l81, !tbaa !23
  store i32 %t159, ptr %l10, !tbaa !23
  %t160 = load i32, ptr %l10, !tbaa !23
  %t162 = icmp sge i32 %t160, 0
  br i1 %t162, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t164 = load i32, ptr %l10, !tbaa !23
  %t166 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s9, i32 %t164, i1 false)
  store %"compiler/check:ownerAt" %t166, ptr %l85
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t167 = load %"compiler/check:ownerAt", ptr %l85
  store %"compiler/check:ownerAt" %t167, ptr %rv
  br label %ret
bb53:
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_6168eeb228a64802_deceb7d8f3c3ddf6)
  unreachable
bb59:
  %t168 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t170 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s0, i32 %t168, i1 false)
  store %"compiler/check:ownerAt" %t170, ptr %l87
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  %t171 = load %"compiler/check:ownerAt", ptr %l87
  store %"compiler/check:ownerAt" %t171, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:ownerAt", ptr %rv
  ret %"compiler/check:ownerAt" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epacked(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %lp10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %lp17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l34 = alloca i32
  %l39 = alloca i64
  %l42 = alloca i1
  %l51 = alloca i64
  %l54 = alloca i64
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l71 = alloca i32
  %l72 = alloca i32
  %l73 = alloca i32
  %l79 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l84 = alloca i32
  %l85 = alloca i32
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca i64
  %l94 = alloca i64
  %l113 = alloca { i64, ptr }
  %l119 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l125 = alloca i64
  %l128 = alloca i64
  %l146 = alloca ptr
  %l147 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l151 = alloca i32
  %l152 = alloca { i64, ptr }
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca i32
  %l166 = alloca ptr
  %l168 = alloca i32
  %l170 = alloca i64
  %l171 = alloca i32
  %l172 = alloca i32
  %l173 = alloca ptr
  %l174 = alloca %"compiler/source:Span"
  %l175 = alloca i32
  %l176 = alloca i32
  %l178 = alloca { i64, ptr }
  %l182 = alloca i32
  %l184 = alloca %"compiler/typed:Make"
  %l194 = alloca i64
  %l197 = alloca i64
  %l216 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t314 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %t5)
  store i32 %t8, ptr %l34
  br label %bb1
bb1:
  %t9 = load i32, ptr %l34, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t19 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSpreadAt(ptr %v0, ptr %t15, i32 %t9)
  store i64 %t19, ptr %l39
  br label %bb2
bb2:
  %t20 = load i64, ptr %l39, !tbaa !24
  store i64 %t20, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb5
bb4:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp sge i64 %t25, %t28
  store i1 %t31, ptr %l42, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l42, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = sub i64 %t36, 1
  store i64 %t38, ptr %l7, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l51, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l2, !tbaa !24
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueAfter(ptr %v0, ptr %t43, i64 %t44)
  store i64 %t47, ptr %l54
  br label %bb9
bb9:
  %t48 = load i64, ptr %l51, !tbaa !24
  %t49 = load i64, ptr %l54, !tbaa !24
  %t50 = sub i64 %t48, %t49
  store i64 %t50, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  br i1 %t56, label %bb10, label %bb11
bb10:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t63 = add i64 %t61, 1
  %t66 = icmp eq i64 %t60, %t63
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l65, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l66, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t70, ptr %l67, !tbaa !27
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 %t71
  %t76 = load ptr, ptr %t75, !tbaa !39
  %t79 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t76)
  store i32 %t79, ptr %l71
  br label %bb15
bb14:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb18
bb15:
  %t80 = load ptr, ptr %l66, !tbaa !29
  %t81 = load i32, ptr %l71, !tbaa !23
  %t82 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t82, ptr %l72
  br label %bb16
bb16:
  %t83 = load ptr, ptr %l65, !tbaa !29
  %t84 = load i32, ptr %l72, !tbaa !23
  %t85 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t83, i32 %t84)
  store i32 %t85, ptr %l73
  br label %bb17
bb17:
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t87 = load i32, ptr %l73, !tbaa !23
  %t89 = icmp ne i32 %t87, %t86
  store i1 %t89, ptr %l64, !tbaa !21
  br label %bb18
bb18:
  %t91 = load i1, ptr %l64, !tbaa !21
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l79, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t101, ptr %l81, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i32, ptr %t105, i64 %t102
  %t107 = load i32, ptr %t106, !tbaa !33
  %t110 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t100, i32 %t107)
  store i32 %t110, ptr %l84
  br label %bb22
bb22:
  %t111 = load ptr, ptr %l79, !tbaa !29
  %t112 = load i32, ptr %l84, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t113, ptr %l85
  br label %bb23
bb23:
  %t114 = load i32, ptr %l85, !tbaa !23
  store i32 %t114, ptr %l9, !tbaa !23
  %t115 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %l86
  br label %bb24
bb24:
  %t116 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t116, ptr %lp10
  %t117 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  %t118 = load ptr, ptr %lp10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %t118
  store i64 0, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l7, !tbaa !24
  store i64 %t119, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t121 = load i64, ptr %l12, !tbaa !24
  %t122 = load i64, ptr %l11, !tbaa !24
  %t125 = icmp sgt i64 %t121, %t122
  br i1 %t125, label %bb25, label %bb26
bb25:
  %t127 = load i64, ptr %l13, !tbaa !24
  %t129 = icmp sgt i64 %t127, 0
  br i1 %t129, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb30
bb27:
  %t131 = load i64, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = sub i64 %t131, %t132
  %t136 = load i64, ptr %l13, !tbaa !24
  %t139 = add i64 %t135, %t136
  %t141 = sub i64 %t139, 1
  %t142 = load i64, ptr %l13, !tbaa !24
  %t145 = sdiv i64 %t141, %t142
  store i64 %t145, ptr %l94, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb29
bb29:
  %t147 = load i64, ptr %l94, !tbaa !24
  store i64 %t147, ptr %l91, !tbaa !24
  br label %bb30
bb30:
  %t148 = load i64, ptr %l91, !tbaa !24
  store i64 %t148, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  %t149 = load i64, ptr %l15, !tbaa !24
  %t150 = load i64, ptr %l14, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t157 = load i64, ptr %l11, !tbaa !24
  %t158 = load i64, ptr %l15, !tbaa !24
  %t159 = load i64, ptr %l13, !tbaa !24
  %t162 = mul i64 %t158, %t159
  %t165 = add i64 %t157, %t162
  %t167 = load ptr, ptr %lp10
  %t168 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t168, ptr %l113, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr ptr, ptr %t172, i64 %t165
  %t174 = load ptr, ptr %t173, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v3, ptr %v2, ptr %t167, ptr %t174)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t177 = load i64, ptr %l15, !tbaa !24
  %t180 = add i64 %t177, 1
  store i64 %t180, ptr %l15, !tbaa !24
  br label %bb31
bb37:
  %t182 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t182, ptr %l119
  br label %bb38
bb38:
  %t183 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t183, ptr %lp17
  %t184 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l119
  %t185 = load ptr, ptr %lp17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %t185
  %t186 = load i64, ptr %l7, !tbaa !24
  store i64 %t186, ptr %l18, !tbaa !24
  %t188 = load i64, ptr %l8, !tbaa !24
  store i64 %t188, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t190 = load i64, ptr %l19, !tbaa !24
  %t191 = load i64, ptr %l18, !tbaa !24
  %t194 = icmp sgt i64 %t190, %t191
  br i1 %t194, label %bb39, label %bb40
bb39:
  %t196 = load i64, ptr %l20, !tbaa !24
  %t198 = icmp sgt i64 %t196, 0
  br i1 %t198, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb44
bb41:
  %t200 = load i64, ptr %l19, !tbaa !24
  %t201 = load i64, ptr %l18, !tbaa !24
  %t204 = sub i64 %t200, %t201
  %t205 = load i64, ptr %l20, !tbaa !24
  %t208 = add i64 %t204, %t205
  %t210 = sub i64 %t208, 1
  %t211 = load i64, ptr %l20, !tbaa !24
  %t214 = sdiv i64 %t210, %t211
  store i64 %t214, ptr %l128, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l128, !tbaa !24
  br label %bb43
bb43:
  %t216 = load i64, ptr %l128, !tbaa !24
  store i64 %t216, ptr %l125, !tbaa !24
  br label %bb44
bb44:
  %t217 = load i64, ptr %l125, !tbaa !24
  store i64 %t217, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb45
bb45:
  %t218 = load i64, ptr %l22, !tbaa !24
  %t219 = load i64, ptr %l21, !tbaa !24
  %t222 = icmp slt i64 %t218, %t219
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb46, label %bb47
bb46:
  br label %bb53
bb47:
  br label %bb48
bb48:
  %t226 = load i64, ptr %l18, !tbaa !24
  %t227 = load i64, ptr %l22, !tbaa !24
  %t228 = load i64, ptr %l20, !tbaa !24
  %t231 = mul i64 %t227, %t228
  %t234 = add i64 %t226, %t231
  store i64 %t234, ptr %l23, !tbaa !24
  %t236 = load ptr, ptr %lp17
  store ptr %t236, ptr %l146, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l147, !tbaa !29
  %t238 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t238, ptr %l148, !tbaa !27
  %t239 = load i64, ptr %l23, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr ptr, ptr %t242, i64 %t239
  %t244 = load ptr, ptr %t243, !tbaa !39
  store ptr %t244, ptr %l150, !tbaa !29
  %t245 = load i32, ptr %l9, !tbaa !23
  store i32 %t245, ptr %l151, !tbaa !23
  %t246 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t246, ptr %l152, !tbaa !27
  %t247 = load i64, ptr %l23, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr ptr, ptr %t250, i64 %t247
  %t252 = load ptr, ptr %t251, !tbaa !39
  %t254 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t252)
  store %"compiler/source:Span" %t254, ptr %l155
  br label %bb49
bb49:
  %t255 = load ptr, ptr %l147, !tbaa !29
  %t256 = load ptr, ptr %l150, !tbaa !29
  %t257 = load i32, ptr %l151, !tbaa !23
  %t258 = load %"compiler/source:Span", ptr %l155
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v3, ptr %t255, ptr %t256, i32 %t257, %"compiler/source:Span" %t258)
  store ptr %t259, ptr %l156
  br label %bb50
bb50:
  %t260 = load ptr, ptr %l146, !tbaa !29
  %t261 = load ptr, ptr %l156, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v3, ptr %v3, ptr %t260, ptr %t261)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t262 = load i64, ptr %l22, !tbaa !24
  %t265 = add i64 %t262, 1
  store i64 %t265, ptr %l22, !tbaa !24
  br label %bb45
bb53:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  store ptr %t272, ptr %l162, !tbaa !29
  %t273 = load i32, ptr %l9, !tbaa !23
  store i32 %t273, ptr %l163, !tbaa !23
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  store ptr %t279, ptr %l166, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t280)
  store i32 %t282, ptr %l168
  br label %bb54
bb54:
  %t283 = load ptr, ptr %lp17
  %t285 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v3, ptr %t283)
  store i64 %t285, ptr %l170
  br label %bb55
bb55:
  %t286 = load ptr, ptr %l166, !tbaa !29
  %t287 = load i32, ptr %l168, !tbaa !23
  %t288 = load i64, ptr %l170, !tbaa !24
  %t289 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t286, i32 %t287, i64 %t288)
  store i32 %t289, ptr %l171
  br label %bb56
bb56:
  %t290 = load ptr, ptr %l162, !tbaa !29
  %t291 = load i32, ptr %l163, !tbaa !23
  %t292 = load i32, ptr %l171, !tbaa !23
  %t293 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t290, i32 %t291, i32 %t292)
  store i32 %t293, ptr %l172
  br label %bb57
bb57:
  %t294 = load i32, ptr %l172, !tbaa !23
  %t295 = load ptr, ptr %lp10
  store ptr %t295, ptr %l173, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t296, ptr %l174
  store i32 %t294, ptr %l175, !tbaa !23
  store i32 2, ptr %l176
  %t298 = load ptr, ptr %lp17
  %t300 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v3, ptr %v3, ptr %t298)
  store { i64, ptr } %t300, ptr %l178
  br label %bb58
bb58:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l1
  %t306 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t301, i32 1, %"compiler/source:Span" %t302)
  store i32 %t306, ptr %l182
  br label %bb59
bb59:
  %t307 = load i32, ptr %l176, !range !{i32 0, i32 5}
  %t308 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t309 = load i32, ptr %l182, !tbaa !23
  %t311 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t307, i64 0, { i64, ptr } %t308, ptr null, i32 %t309, i32 0, i1 false)
  store %"compiler/typed:Make" %t311, ptr %l184
  br label %bb60
bb60:
  %t312 = load %"compiler/typed:Make", ptr %l184
  %t313 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/typed:Make" %t312, ptr %t313
  store { i64, [5 x i64] } zeroinitializer, ptr %t314
  %t315 = getelementptr { i64, [5 x i64] }, ptr %t314, i32 0, i32 0
  store i64 7, ptr %t315
  %t316 = load %"compiler/source:Span", ptr %l174
  %t317 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t316, 0
  %t318 = load i32, ptr %l175, !tbaa !23
  %t319 = insertvalue { %"compiler/source:Span", i32, ptr } %t317, i32 %t318, 1
  %t321 = insertvalue { %"compiler/source:Span", i32, ptr } %t319, ptr %t313, 2
  %t322 = getelementptr { i64, [5 x i64] }, ptr %t314, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t321, ptr %t322
  %t323 = load { i64, [5 x i64] }, ptr %t314
  %t325 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t323, ptr %t325
  %t326 = load ptr, ptr %l173, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v3, ptr %v3, ptr %t326, ptr %t325)
  br label %bb61
bb61:
  %t328 = load i64, ptr %l8, !tbaa !24
  store i64 %t328, ptr %l25, !tbaa !24
  %t330 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t330, 0
  store i64 %t332, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t334 = load i64, ptr %l26, !tbaa !24
  %t335 = load i64, ptr %l25, !tbaa !24
  %t338 = icmp sgt i64 %t334, %t335
  br i1 %t338, label %bb62, label %bb63
bb62:
  %t340 = load i64, ptr %l27, !tbaa !24
  %t342 = icmp sgt i64 %t340, 0
  br i1 %t342, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l194, !tbaa !24
  br label %bb67
bb64:
  %t344 = load i64, ptr %l26, !tbaa !24
  %t345 = load i64, ptr %l25, !tbaa !24
  %t348 = sub i64 %t344, %t345
  %t349 = load i64, ptr %l27, !tbaa !24
  %t352 = add i64 %t348, %t349
  %t354 = sub i64 %t352, 1
  %t355 = load i64, ptr %l27, !tbaa !24
  %t358 = sdiv i64 %t354, %t355
  store i64 %t358, ptr %l197, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l197, !tbaa !24
  br label %bb66
bb66:
  %t360 = load i64, ptr %l197, !tbaa !24
  store i64 %t360, ptr %l194, !tbaa !24
  br label %bb67
bb67:
  %t361 = load i64, ptr %l194, !tbaa !24
  store i64 %t361, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb68
bb68:
  %t362 = load i64, ptr %l29, !tbaa !24
  %t363 = load i64, ptr %l28, !tbaa !24
  %t366 = icmp slt i64 %t362, %t363
  %t368 = xor i1 %t366, true
  br i1 %t368, label %bb69, label %bb70
bb69:
  br label %bb74
bb70:
  br label %bb71
bb71:
  %t370 = load i64, ptr %l25, !tbaa !24
  %t371 = load i64, ptr %l29, !tbaa !24
  %t372 = load i64, ptr %l27, !tbaa !24
  %t375 = mul i64 %t371, %t372
  %t378 = add i64 %t370, %t375
  %t380 = load ptr, ptr %lp10
  %t381 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t381, ptr %l216, !tbaa !27
  %t384 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr ptr, ptr %t385, i64 %t378
  %t387 = load ptr, ptr %t386, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v3, ptr %v2, ptr %t380, ptr %t387)
  br label %bb72
bb72:
  br label %bb73
bb73:
  %t390 = load i64, ptr %l29, !tbaa !24
  %t393 = add i64 %t390, 1
  store i64 %t393, ptr %l29, !tbaa !24
  br label %bb68
bb74:
  %t395 = load ptr, ptr %lp10
  %t397 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v3, ptr %v3, ptr %t395)
  store { i64, ptr } %t397, ptr %l223
  br label %bb75
bb75:
  %t398 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t398, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadPatternOk(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, i32 }
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca %"compiler/check:payloadItem"
  %l19 = alloca ptr
  %l20 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca %"compiler/diagmsg:Msg"
  %l40 = alloca i64
  %l44 = alloca { i64, i32 }
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca %"compiler/diagmsg:Msg"
  %l52 = alloca i64
  %l55 = alloca ptr
  %l60 = alloca i32
  %l62 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/diagmsg:Msg"
  %l74 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l86 = alloca { i64, ptr }
  %l92 = alloca %"compiler/diagmsg:Msg"
  %l93 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l100 = alloca %"compiler/diagmsg:Msg"
  %l101 = alloca i64
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l106 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l108 = alloca i64
  %l110 = alloca i64
  %l115 = alloca %"compiler/check:payloadItem"
  %l126 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t2 = load ptr, ptr %l19, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l19, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l20, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t21, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t27, i32 0, i32 2
  %t29 = load { i64, ptr }, ptr %t28
  store %"compiler/source:Span" %t17, ptr %l8
  store { i64, ptr } %t29, ptr %l9, !tbaa !27
  %t37 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %t23)
  store ptr %t37, ptr %l34
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l34, !tbaa !29
  store ptr %t38, ptr %l10, !tbaa !29
  %t39 = load ptr, ptr %l10, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l37, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t44, ptr %l38
  %t45 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
  store %"compiler/diagmsg:Msg" %t45, ptr %l39
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t46 = load ptr, ptr %l37, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l38
  %t48 = load %"compiler/diagmsg:Msg", ptr %l39
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t46, %"compiler/source:Span" %t47, %"compiler/diagmsg:Msg" %t48)
  store i64 %t49, ptr %l40
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l10, !tbaa !29
  %t55 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %s0, ptr %t51, ptr %t52)
  store { i64, i32 } %t55, ptr %l44
  br label %bb12
bb12:
  %t56 = load { i64, i32 }, ptr %l44
  store { i64, i32 } %t56, ptr %l11
  %t57 = getelementptr { i64, i32 }, ptr %l11, i32 0, i32 0
  %t58 = load i64, ptr %t57, !tbaa !24
  store i64 %t58, ptr %l12, !tbaa !24
  %t60 = getelementptr { i64, i32 }, ptr %l11, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l13, !tbaa !23
  %t63 = load i64, ptr %l12, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l49, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t68, ptr %l50
  %t69 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
  store %"compiler/diagmsg:Msg" %t69, ptr %l51
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t70 = load ptr, ptr %l49, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l50
  %t72 = load %"compiler/diagmsg:Msg", ptr %l51
  %t73 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t70, %"compiler/source:Span" %t71, %"compiler/diagmsg:Msg" %t72)
  store i64 %t73, ptr %l52
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  store ptr %t78, ptr %l55, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l13, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l60
  br label %bb18
bb18:
  %t89 = load i64, ptr %l12, !tbaa !24
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t91 = load i32, ptr %l60, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %s0, ptr %t90, i32 %t91, i64 %t89)
  store { i64, ptr } %t93, ptr %l62
  br label %bb19
bb19:
  %t94 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t94, ptr %l14, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = icmp eq i64 %t97, 0
  br i1 %t99, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l66, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t102, ptr %l67
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l13, !tbaa !23
  %t105 = load i64, ptr %l12, !tbaa !24
  %t109 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %s4, ptr %t103, i32 %t104, i64 %t105)
  store { i64, ptr } %t109, ptr %l71
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t110 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t112 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %s4, ptr %v0, { i64, ptr } %t110)
  store %"compiler/diagmsg:Msg" %t112, ptr %l73
  br label %bb23
bb23:
  %t113 = load ptr, ptr %l66, !tbaa !29
  %t114 = load %"compiler/source:Span", ptr %l67
  %t115 = load %"compiler/diagmsg:Msg", ptr %l73
  %t116 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t113, %"compiler/source:Span" %t114, %"compiler/diagmsg:Msg" %t115)
  store i64 %t116, ptr %l74
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb25:
  %t118 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t126 = icmp sgt i64 %t120, %t123
  br i1 %t126, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l81, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t129, ptr %l82
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l13, !tbaa !23
  %t132 = load i64, ptr %l12, !tbaa !24
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %s5, ptr %t130, i32 %t131, i64 %t132)
  store { i64, ptr } %t136, ptr %l86
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t137 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t147 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %s5, ptr %v0, { i64, ptr } %t137, i64 %t140, i64 %t143)
  store %"compiler/diagmsg:Msg" %t147, ptr %l92
  br label %bb29
bb29:
  %t148 = load ptr, ptr %l81, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l82
  %t150 = load %"compiler/diagmsg:Msg", ptr %l92
  %t151 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t148, %"compiler/source:Span" %t149, %"compiler/diagmsg:Msg" %t150)
  store i64 %t151, ptr %l93
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb31:
  %t155 = xor i1 %a3, true
  br i1 %t155, label %bb32, label %bb33
bb32:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l97, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t158, ptr %l98
  %t161 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrPatternNeedsName(ptr %v2, ptr %v0, { i64, ptr } %a2)
  store %"compiler/diagmsg:Msg" %t161, ptr %l100
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t162 = load ptr, ptr %l97, !tbaa !29
  %t163 = load %"compiler/source:Span", ptr %l98
  %t164 = load %"compiler/diagmsg:Msg", ptr %l100
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t162, %"compiler/source:Span" %t163, %"compiler/diagmsg:Msg" %t164)
  store i64 %t165, ptr %l101
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb36:
  %t167 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167, ptr %l103
  br label %bb37
bb37:
  %t168 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %l15
  store %olang.scope zeroinitializer, ptr %s7
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t173 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %s7, ptr %t169, ptr %t170)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t173, ptr %l106
  br label %bb38
bb38:
  %t174 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106
  %t175 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t174, ptr %t175
  store ptr %t175, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t177 = load i64, ptr %l17, !tbaa !24
  store i64 %t177, ptr %l108, !tbaa !24
  %t178 = load ptr, ptr %l16, !tbaa !29
  %t180 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eLe_Hf8109b64a4e45220d0da36a987cf38b1(ptr %s7, ptr %t178)
  store i64 %t180, ptr %l110
  br label %bb40
bb40:
  %t181 = load i64, ptr %l108, !tbaa !24
  %t182 = load i64, ptr %l110, !tbaa !24
  %t183 = icmp slt i64 %t181, %t182
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb42:
  br label %bb43
bb43:
  %t187 = load ptr, ptr %l16, !tbaa !29
  %t188 = load i64, ptr %l17, !tbaa !24
  %t191 = call %"compiler/check:payloadItem" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eAt_H64f851f610dd8566f1d7651b626ec99d(ptr %s7, ptr %s7, ptr %t187, i64 %t188)
  store %"compiler/check:payloadItem" %t191, ptr %l115
  br label %bb44
bb44:
  %t192 = load %"compiler/check:payloadItem", ptr %l115
  store %"compiler/check:payloadItem" %t192, ptr %l18
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l8
  %t195 = load i32, ptr %l13, !tbaa !23
  %t196 = load i64, ptr %l12, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t211 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItemOk(ptr %v0, ptr %s8, ptr %s0, ptr %s0, ptr %t193, ptr %l18, %"compiler/source:Span" %t194, i32 %t195, i64 %t196, { i64, ptr } %t197, i64 %t200, ptr %l15, i64 %a4)
  store i1 %t211, ptr %l126
  br label %bb45
bb45:
  %t212 = load i1, ptr %l126, !tbaa !21
  %t213 = xor i1 %t212, true
  br i1 %t213, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t216 = getelementptr %"compiler/check:payloadItem", ptr %l18, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l15, i32 %t217)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  %t220 = load i64, ptr %l17, !tbaa !24
  %t223 = add i64 %t220, 1
  store i64 %t223, ptr %l17, !tbaa !24
  br label %bb39
bb51:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i1
  %l56 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l70 = alloca i32
  %l75 = alloca i32
  %l80 = alloca i32
  %l85 = alloca i32
  %l86 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l18
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = load i32, ptr %l18, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l19
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l21, !tbaa !24
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load i64, ptr %l21, !tbaa !24
  %t28 = icmp sle i64 %t27, 2305843009213693951
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e5e26ce82a519cb4_386557e0c1145fc8)
  unreachable
bb5:
  %t30 = load i64, ptr %l21, !tbaa !24
  %t31 = mul i64 %t30, 4
  %t32 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e5e26ce82a519cb4_386557e0c1145fc8)
  unreachable
bb7:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb12
bb9:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l33, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb11
bb11:
  %t66 = load i64, ptr %l33, !tbaa !24
  store i64 %t66, ptr %l30, !tbaa !24
  br label %bb12
bb12:
  %t67 = load i64, ptr %l30, !tbaa !24
  store i64 %t67, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = sub i64 %t68, 1
  store i64 %t69, ptr %l42, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t70, 2147483648
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = icmp sge i64 %t72, 0
  %t76 = and i1 %t71, %t73
  store i1 %t76, ptr %l45, !tbaa !21
  br label %bb13
bb13:
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = mul i64 %t86, %t87
  %t93 = add i64 %t85, %t90
  store i64 %t93, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t96, ptr %l56, !tbaa !27
  %t97 = load i64, ptr %l10, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i32, ptr %t100, i64 %t97
  %t102 = load i32, ptr %t101, !tbaa !33
  %t105 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i32, ptr %t106, i64 %t95
  store i32 %t102, ptr %t107, !tbaa !33
  br label %bb17
bb17:
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %l9, !tbaa !24
  br label %bb13
bb18:
  %t115 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 0
  store i32 %a2, ptr %t117, !tbaa !33
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  store ptr %t123, ptr %l65, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t129, { i64, ptr } %t130)
  store i32 %t133, ptr %l70
  br label %bb19
bb19:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l1, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l75
  br label %bb20
bb20:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/generic:Program", ptr %t147, i32 0, i32 2
  %t150 = load i32, ptr %l1, !tbaa !23
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t153, ptr %l80
  br label %bb21
bb21:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l1, !tbaa !23
  %t163 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t159, i32 %t160)
  store i32 %t163, ptr %l85
  br label %bb22
bb22:
  %t164 = load ptr, ptr %l65, !tbaa !29
  %t165 = load i32, ptr %l70, !tbaa !23
  %t166 = load i32, ptr %l75, !tbaa !23
  %t167 = load i32, ptr %l80, !tbaa !23
  %t168 = load i32, ptr %l85, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t164, i32 %t165, i32 %t166, i32 %t167, i32 %t168, i64 0, i1 false, i32 0, i64 0)
  store i32 %t169, ptr %l86
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t170 = load i32, ptr %l86, !tbaa !23
  store i32 %t170, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i32, { i64, ptr } }
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %l46 = alloca i32
  %l48 = alloca i1
  %l51 = alloca i32
  %l56 = alloca i32
  %l68 = alloca { i32, { i64, ptr } }
  %l72 = alloca i1
  %l74 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l85 = alloca %"compiler/diagmsg:Msg"
  %l86 = alloca i64
  %l89 = alloca ptr
  %l90 = alloca i1
  %l97 = alloca i32
  %l98 = alloca ptr
  %l99 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l116 = alloca ptr
  %l118 = alloca ptr
  %l122 = alloca %"compiler/names:Ref"
  %l126 = alloca { i64, ptr }
  %l130 = alloca i1
  %l133 = alloca i1
  %l136 = alloca i32
  %l148 = alloca i32
  %l151 = alloca i32
  %l156 = alloca i1
  %l158 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca { i64, ptr }
  %l165 = alloca %"compiler/source:Span"
  %l168 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l177 = alloca i64
  %l179 = alloca i64
  %l180 = alloca %"compiler/diagmsg:Msg"
  %l181 = alloca i64
  %l187 = alloca i32
  %l191 = alloca i1
  %l195 = alloca i1
  %l197 = alloca i1
  %l201 = alloca i1
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i32
  %t271 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i32, ptr %l22, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t9 = icmp sge i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i32, ptr %l2, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t14 = load ptr, ptr %l26, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l26, !tbaa !29
  %t18 = load i64, ptr %t17, !range !{i64 0, i64 28}
  %t20 = icmp eq i64 %t18, 12
  store i1 %t20, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l27, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t24, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  store %"compiler/source:Span" %t26, ptr %l3
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t30, i32 0, i32 1
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l4, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l5, !tbaa !23
  br label %bb9
bb8:
  br label %bb40
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l5, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l38
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = call i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %t46)
  store i1 %t48, ptr %l40
  br label %bb11
bb11:
  %t49 = load i1, ptr %l40, !tbaa !21
  %t50 = xor i1 %t49, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l3
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t55 = load i32, ptr %l5, !tbaa !23
  %t60 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberThrough(ptr %v0, ptr %v1, ptr %t52, %"compiler/source:Span" %t53, ptr %t54, i32 %t55)
  store i32 %t60, ptr %l46
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  %t61 = load i32, ptr %l46, !tbaa !23
  store i32 %t61, ptr %rv
  br label %ret
bb15:
  store i32 -1, ptr %l7, !tbaa !23
  %t62 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t62, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t64, ptr %l48
  br label %bb16
bb16:
  %t65 = load i1, ptr %l48, !tbaa !21
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t70 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  store i32 %t70, ptr %l51
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t71 = load i32, ptr %l51, !tbaa !23
  store i32 %t71, ptr %l7, !tbaa !23
  br label %bb20
bb20:
  %t72 = load i32, ptr %l7, !tbaa !23
  %t74 = icmp slt i32 %t72, 0
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t80 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i32 %t80, ptr %l56
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t81 = load i32, ptr %l56, !tbaa !23
  store i32 %t81, ptr %l7, !tbaa !23
  br label %bb24
bb24:
  %t82 = load i32, ptr %l7, !tbaa !23
  %t84 = icmp slt i32 %t82, 0
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t86 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t86, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t88 = load i32, ptr %l7, !tbaa !23
  %t89 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t92 = icmp eq i32 %t88, %t89
  br i1 %t92, label %bb28, label %bb29
bb28:
  %t94 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t94, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i32, ptr %l7, !tbaa !23
  %t101 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t105 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eProject(ptr %v0, ptr %v0, ptr %s2, ptr %t99, i32 %t100, { i64, ptr } %t101)
  store { i32, { i64, ptr } } %t105, ptr %l68
  br label %bb31
bb31:
  %t106 = load { i32, { i64, ptr } }, ptr %l68
  store { i32, { i64, ptr } } %t106, ptr %l8
  %t107 = getelementptr { i32, { i64, ptr } }, ptr %l8, i32 0, i32 0
  %t108 = load i32, ptr %t107, !tbaa !23
  store i32 %t108, ptr %l9, !tbaa !23
  %t110 = getelementptr { i32, { i64, ptr } }, ptr %l8, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l10, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t113, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t115, ptr %l72
  br label %bb32
bb32:
  %t116 = load i1, ptr %l72, !tbaa !21
  %t117 = xor i1 %t116, true
  br i1 %t117, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l74, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l3
  %t121 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t126 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t120, i64 %t123)
  store %"compiler/source:Span" %t126, ptr %l78
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t127 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t127, ptr %l79, !tbaa !27
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l7, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t128, i32 %t129)
  store { i64, ptr } %t132, ptr %l82
  br label %bb36
bb36:
  %t133 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t138 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoType(ptr %v0, ptr %s8, ptr %s2, ptr %v0, { i64, ptr } %t135, { i64, ptr } %t133, { i64, ptr } %t134)
  store %"compiler/diagmsg:Msg" %t138, ptr %l85
  br label %bb37
bb37:
  %t139 = load ptr, ptr %l74, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l78
  %t141 = load %"compiler/diagmsg:Msg", ptr %l85
  %t142 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t139, %"compiler/source:Span" %t140, %"compiler/diagmsg:Msg" %t141)
  store i64 %t142, ptr %l86
  br label %bb38
bb38:
  %t143 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s2)
  store i32 %t143, ptr %rv
  br label %ret
bb39:
  %t145 = load i32, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t145, ptr %rv
  br label %ret
bb40:
  %t147 = load ptr, ptr %l1, !tbaa !29
  store ptr %t147, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t148 = load ptr, ptr %l89, !tbaa !29
  %t149 = icmp ne ptr %t148, null
  br i1 %t149, label %bb41, label %bb42
bb41:
  %t151 = load ptr, ptr %l89, !tbaa !29
  %t152 = load i64, ptr %t151, !range !{i64 0, i64 28}
  %t154 = icmp eq i64 %t152, 2
  store i1 %t154, ptr %l90, !tbaa !21
  br label %bb42
bb42:
  %t155 = load i1, ptr %l90, !tbaa !21
  br i1 %t155, label %bb43, label %bb44
bb43:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr { i64, [4 x i64] }, ptr %t156, i32 0, i32 1
  %t159 = getelementptr { %"compiler/source:Span", ptr }, ptr %t158, i32 0, i32 1
  %t160 = load ptr, ptr %t159
  store ptr %t160, ptr %l11, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l11, !tbaa !29
  %t166 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t162, ptr %t163)
  store i32 %t166, ptr %l97
  br label %bb46
bb46:
  %t167 = load i32, ptr %l97, !tbaa !23
  store i32 %t167, ptr %rv
  br label %ret
bb47:
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t169 = load ptr, ptr %l98, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb48, label %bb49
bb48:
  %t172 = load ptr, ptr %l98, !tbaa !29
  %t173 = load i64, ptr %t172, !range !{i64 0, i64 28}
  %t175 = icmp eq i64 %t173, 11
  store i1 %t175, ptr %l99, !tbaa !21
  br label %bb49
bb49:
  %t176 = load i1, ptr %l99, !tbaa !21
  br i1 %t176, label %bb50, label %bb51
bb50:
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t179, i32 0, i32 0
  %t181 = load %"compiler/source:Span", ptr %t180
  store %"compiler/source:Span" %t181, ptr %l12
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [4 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t185, i32 0, i32 1
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l13, !tbaa !29
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t191, i32 0, i32 2
  %t193 = load { i64, ptr }, ptr %t192
  store { i64, ptr } %t193, ptr %l14, !tbaa !27
  br label %bb52
bb51:
  br label %bb107
bb52:
  store i1 false, ptr %l15, !tbaa !21
  %t195 = load ptr, ptr %l13, !tbaa !29
  store ptr %t195, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t196 = load ptr, ptr %l108, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb53, label %bb54
bb53:
  %t199 = load ptr, ptr %l108, !tbaa !29
  %t200 = load i64, ptr %t199, !range !{i64 0, i64 28}
  %t202 = icmp eq i64 %t200, 0
  store i1 %t202, ptr %l109, !tbaa !21
  br label %bb54
bb54:
  %t203 = load i1, ptr %l109, !tbaa !21
  br i1 %t203, label %bb55, label %bb56
bb55:
  %t204 = load ptr, ptr %l13, !tbaa !29
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", i32 }, ptr %t206, i32 0, i32 0
  %t208 = load %"compiler/source:Span", ptr %t207
  store %"compiler/source:Span" %t208, ptr %l16
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = getelementptr %"compiler/generic:Program", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  store ptr %t216, ptr %l116, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t217)
  store ptr %t219, ptr %l118
  br label %bb58
bb58:
  %t220 = load ptr, ptr %l118, !tbaa !29
  %t222 = getelementptr %"compiler/check:frame", ptr %t220, i32 0, i32 2
  %t223 = load i64, ptr %t222, !tbaa !24
  %t224 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t225 = load i32, ptr %t224, !tbaa !23
  %t226 = load ptr, ptr %l116, !tbaa !29
  %t229 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t226, i64 %t223, i32 %t225)
  store %"compiler/names:Ref" %t229, ptr %l122
  br label %bb59
bb59:
  %t230 = getelementptr %"compiler/names:Ref", ptr %l122, i32 0, i32 0
  %t231 = load i32, ptr %t230, !range !{i32 0, i32 9}
  %t233 = trunc i64 7 to i32
  %t234 = icmp eq i32 %t231, %t233
  store i1 %t234, ptr %l15, !tbaa !21
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_492feac3979049da_7a1ccb679ec95f6e)
  unreachable
bb65:
  %t236 = load ptr, ptr %l13, !tbaa !29
  %t238 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v1, ptr %v0, ptr %t236)
  store { i64, ptr } %t238, ptr %l126
  br label %bb66
bb66:
  %t239 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t239, ptr %l17, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t244 = icmp eq i64 %t242, 0
  br i1 %t244, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb73
bb68:
  %t246 = load i1, ptr %l15, !tbaa !21
  %t248 = xor i1 %t246, true
  br i1 %t248, label %bb69, label %bb70
bb69:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l13, !tbaa !29
  %t254 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t250, ptr %t251)
  store i32 %t254, ptr %l136
  br label %bb71
bb70:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb72
bb71:
  %t255 = load i32, ptr %l136, !tbaa !23
  %t256 = icmp slt i32 %t255, 0
  store i1 %t256, ptr %l133, !tbaa !21
  br label %bb72
bb72:
  %t258 = load i1, ptr %l133, !tbaa !21
  store i1 %t258, ptr %l130, !tbaa !21
  br label %bb73
bb73:
  %t259 = load i1, ptr %l130, !tbaa !21
  br i1 %t259, label %bb74, label %bb75
bb74:
  store i32 -1, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t261 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t265 = icmp eq i64 %t263, 1
  br i1 %t265, label %bb77, label %bb78
bb77:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l12
  %t269 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t270 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t271
  %t272 = getelementptr { i64, [5 x i64] }, ptr %t271, i32 0, i32 0
  store i64 0, ptr %t272
  %t274 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t268, 0
  %t276 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t274, { i64, ptr } %t269, 1
  %t278 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t276, { i64, ptr } %t270, 2
  %t279 = getelementptr { i64, [5 x i64] }, ptr %t271, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t278, ptr %t279
  %t280 = load { i64, [5 x i64] }, ptr %t271
  %t282 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t280, ptr %t282
  %t285 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %v0, ptr %t267, ptr %t282)
  store i32 %t285, ptr %l148
  br label %bb79
bb78:
  br label %bb80
bb79:
  %t286 = load i32, ptr %l148, !tbaa !23
  store i32 %t286, ptr %rv
  br label %ret
bb80:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load ptr, ptr %l13, !tbaa !29
  %t291 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t287, ptr %t288)
  store i32 %t291, ptr %l151
  br label %bb81
bb81:
  %t292 = load i32, ptr %l151, !tbaa !23
  store i32 %t292, ptr %l18, !tbaa !23
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t297 = load i32, ptr %l18, !tbaa !23
  %t298 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t302 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t296, i32 %t297, { i64, ptr } %t298)
  store i1 %t302, ptr %l156
  br label %bb82
bb82:
  %t303 = load i1, ptr %l156, !tbaa !21
  %t304 = xor i1 %t303, true
  br i1 %t304, label %bb83, label %bb84
bb83:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l158, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t307, 0
  %t311 = icmp sgt i64 %t309, 0
  br i1 %t311, label %bb85, label %bb86
bb84:
  br label %bb94
bb85:
  %t313 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t313, ptr %l163, !tbaa !27
  %t314 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr ptr, ptr %t315, i64 0
  %t317 = load ptr, ptr %t316, !tbaa !39
  %t319 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t317)
  store %"compiler/source:Span" %t319, ptr %l165
  br label %bb87
bb86:
  %t320 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t320, ptr %l162
  br label %bb88
bb87:
  %t322 = load %"compiler/source:Span", ptr %l165
  store %"compiler/source:Span" %t322, ptr %l162
  br label %bb88
bb88:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t324, ptr %l168, !tbaa !27
  %t325 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t325, 0
  %t329 = sub i64 %t327, 1
  %t331 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr i32, ptr %t332, i64 %t329
  %t334 = load i32, ptr %t333, !tbaa !33
  %t337 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t323, i32 %t334)
  store { i64, ptr } %t337, ptr %l173
  br label %bb89
bb89:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/check:Checker", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t342 = load i32, ptr %l18, !tbaa !23
  %t345 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t341, i32 %t342)
  store i64 %t345, ptr %l177
  br label %bb90
bb90:
  %t346 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t348 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t346)
  store i64 %t348, ptr %l179
  br label %bb91
bb91:
  %t349 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t350 = load i64, ptr %l177, !tbaa !24
  %t351 = load i64, ptr %l179, !tbaa !24
  %t352 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v0, { i64, ptr } %t349, i64 %t350, i64 %t351)
  store %"compiler/diagmsg:Msg" %t352, ptr %l180
  br label %bb92
bb92:
  %t353 = load ptr, ptr %l158, !tbaa !29
  %t354 = load %"compiler/source:Span", ptr %l162
  %t355 = load %"compiler/diagmsg:Msg", ptr %l180
  %t356 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t353, %"compiler/source:Span" %t354, %"compiler/diagmsg:Msg" %t355)
  store i64 %t356, ptr %l181
  br label %bb93
bb93:
  %t357 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t357, ptr %rv
  br label %ret
bb94:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load %"compiler/source:Span", ptr %l12
  %t361 = load i32, ptr %l18, !tbaa !23
  %t362 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t367 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eapplyAt(ptr %v0, ptr %v1, ptr %t359, %"compiler/source:Span" %t360, i32 %t361, { i64, ptr } %t362)
  store i32 %t367, ptr %l187
  br label %bb95
bb95:
  %t368 = load i32, ptr %l187, !tbaa !23
  store i32 %t368, ptr %l19, !tbaa !23
  %t369 = load i32, ptr %l19, !tbaa !23
  %t370 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t373 = icmp eq i32 %t369, %t370
  br i1 %t373, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb99
bb97:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load i32, ptr %l19, !tbaa !23
  %t377 = load %"compiler/source:Span", ptr %l12
  %t381 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t375, i32 %t376, %"compiler/source:Span" %t377)
  store i1 %t381, ptr %l195
  br label %bb98
bb98:
  %t382 = load i1, ptr %l195, !tbaa !21
  %t383 = xor i1 %t382, true
  store i1 %t383, ptr %l191, !tbaa !21
  br label %bb99
bb99:
  %t385 = load i1, ptr %l191, !tbaa !21
  br i1 %t385, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l197, !tbaa !21
  br label %bb103
bb101:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/check:Checker", ptr %t386, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !29
  %t390 = load i32, ptr %l19, !tbaa !23
  %t393 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t389, i32 %t390)
  store i1 %t393, ptr %l201
  br label %bb102
bb102:
  %t394 = load i1, ptr %l201, !tbaa !21
  %t395 = xor i1 %t394, true
  store i1 %t395, ptr %l197, !tbaa !21
  br label %bb103
bb103:
  %t397 = load i1, ptr %l197, !tbaa !21
  br i1 %t397, label %bb104, label %bb105
bb104:
  %t398 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t398, ptr %rv
  br label %ret
bb105:
  br label %bb106
bb106:
  %t400 = load i32, ptr %l19, !tbaa !23
  store i32 %t400, ptr %rv
  br label %ret
bb107:
  br i1 true, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  store i32 -1, ptr %rv
  br label %ret
bb111:
  call void @__olang_check_failed(ptr @olang_loc_42af232d2840e8db_efcef566740b002f)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroArgFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %l28 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i32
  %l53 = alloca i1
  %l58 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/check:roArg"
  %l74 = alloca ptr
  %l75 = alloca i1
  %l83 = alloca i64
  %l87 = alloca ptr
  %l90 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l93 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l94 = alloca %"std/pair:Pair.b139c4f75a6545712256427180a82a06"
  %l97 = alloca i1
  %l99 = alloca ptr
  %l104 = alloca %"compiler/check:roDeepArg"
  %l105 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca i1
  %l114 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i64
  %l118 = alloca i64
  %l121 = alloca { i64, [3 x i64] }
  %l122 = alloca { i64, ptr }
  %l123 = alloca i64
  %l125 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l133 = alloca ptr
  %l136 = alloca i32
  %l139 = alloca i32
  %l140 = alloca { i64, ptr }
  %l142 = alloca %"compiler/check:roArg"
  %l143 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca i64
  %l150 = alloca ptr
  %l153 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l156 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l157 = alloca %"std/pair:Pair.b139c4f75a6545712256427180a82a06"
  %l160 = alloca i1
  %l162 = alloca ptr
  %l167 = alloca %"compiler/check:roDeepArg"
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  store i1 %t7, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l17
  br label %bb7
bb7:
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l20, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t22 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t19)
  store i32 %t22, ptr %l23
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = load i32, ptr %l23, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t25, ptr %l24
  br label %bb9
bb9:
  %t26 = load i1, ptr %l24, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t27, i64 %t28, i64 %t29)
  store i1 %t33, ptr %l28
  br label %bb12
bb11:
  br label %bb59
bb12:
  %t34 = load i1, ptr %l28, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l32, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  store ptr %t48, ptr %l35, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l38, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 19
  %t58 = load i64, ptr %l1, !tbaa !24
  %t61 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store ptr %t61, ptr %l42
  br label %bb16
bb16:
  %t62 = load ptr, ptr %l42, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %t64, !tbaa !23
  %t66 = load ptr, ptr %l38, !tbaa !29
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t66, i32 %t65)
  store i32 %t68, ptr %l45
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t70 = load i32, ptr %l45, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t69, i32 %t70)
  store { i64, ptr } %t71, ptr %l46
  br label %bb18
bb18:
  %t72 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t72, ptr %l47, !tbaa !27
  %t73 = load i64, ptr %l2, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i32, ptr %t76, i64 %t73
  %t78 = load i32, ptr %t77, !tbaa !33
  %t79 = load ptr, ptr %l32, !tbaa !29
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t79, i32 %t78)
  store i32 %t81, ptr %l50
  br label %bb19
bb19:
  %t82 = load i32, ptr %l50, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l7, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l53
  br label %bb20
bb20:
  %t88 = load i1, ptr %l53, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store i1 %t96, ptr %l58
  br label %bb24
bb24:
  %t97 = load i1, ptr %l58, !tbaa !21
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 109
  store ptr %t100, ptr %l60, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  store i64 %t101, ptr %l61, !tbaa !24
  %t102 = load i64, ptr %l2, !tbaa !24
  store i64 %t102, ptr %l62, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l4
  %t107 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t103, %"compiler/source:Span" %t104)
  store { i64, [3 x i64] } %t107, ptr %l65
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t108 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t108, ptr %l66, !tbaa !27
  %t109 = call ptr @__olang_scope_hold(ptr %v0)
  %t110 = ptrtoint ptr %t109 to i64
  store i64 %t110, ptr %l67, !tbaa !24
  %t111 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aroArg_2e4
  br i1 %t111, label %bb28, label %bb29
bb28:
  %t113 = call ptr @__olang_region_make(ptr %v0)
  %t114 = ptrtoint ptr %t113 to i64
  store i64 %t114, ptr %l67, !tbaa !24
  br label %bb29
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l7, !tbaa !23
  %t117 = load i64, ptr %l67
  %t118 = inttoptr i64 %t117 to ptr
  %t121 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %t118, ptr %t115, i32 %t116)
  store { i64, ptr } %t121, ptr %l71
  br label %bb30
bb30:
  %t122 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t123 = load i64, ptr %l61, !tbaa !24
  %t124 = load i64, ptr %l62, !tbaa !24
  %t125 = load { i64, [3 x i64] }, ptr %l65
  %t126 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t128 = call %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, i64 %t123, i64 %t124, { i64, [3 x i64] } %t125, { i64, ptr } %t126, { i64, ptr } %t122, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store %"compiler/check:roArg" %t128, ptr %l73
  br label %bb31
bb31:
  %t129 = load ptr, ptr %l60, !tbaa !29
  %t130 = load %"compiler/check:roArg", ptr %l73
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v0, ptr %t129, %"compiler/check:roArg" %t130)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb33:
  %t131 = load ptr, ptr %l3, !tbaa !29
  store ptr %t131, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t132 = load ptr, ptr %l74, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb34, label %bb35
bb34:
  %t135 = load ptr, ptr %l74, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 18}
  %t138 = icmp eq i64 %t136, 3
  store i1 %t138, ptr %l75, !tbaa !21
  br label %bb35
bb35:
  %t139 = load i1, ptr %l75, !tbaa !21
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t142 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t142, i32 0, i32 2
  %t144 = load ptr, ptr %t143
  store ptr %t144, ptr %l8, !tbaa !29
  br label %bb38
bb37:
  br label %bb47
bb38:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l8, !tbaa !29
  %t151 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t146, ptr %t147)
  store i64 %t151, ptr %l83
  br label %bb39
bb39:
  %t152 = load i64, ptr %l83, !tbaa !24
  store i64 %t152, ptr %l9, !tbaa !24
  %t153 = load i64, ptr %l9, !tbaa !24
  %t155 = icmp sge i64 %t153, 0
  br i1 %t155, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 101
  store ptr %t159, ptr %l87, !tbaa !29
  %t160 = load i64, ptr %l6, !tbaa !24
  %t161 = load i64, ptr %l9, !tbaa !24
  %t164 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t160, i64 %t161)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t164, ptr %l90
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t165 = load i64, ptr %l1, !tbaa !24
  %t166 = load i64, ptr %l2, !tbaa !24
  %t169 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t165, i64 %t166)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t169, ptr %l93
  br label %bb43
bb43:
  %t170 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l90
  %t171 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l93
  %t172 = call %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s7, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t170, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t171)
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t172, ptr %l94
  br label %bb44
bb44:
  %t173 = load ptr, ptr %l87, !tbaa !29
  %t174 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l94
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %t173, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t174)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_3ba07a3e63e86523_b4e2f85113e27c0f)
  unreachable
bb52:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i64, ptr %l6, !tbaa !24
  %t179 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t175, i64 %t176)
  store i1 %t179, ptr %l97
  br label %bb53
bb53:
  %t180 = load i1, ptr %l97, !tbaa !21
  br i1 %t180, label %bb54, label %bb55
bb54:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/check:Checker", ptr %t181, i32 0, i32 108
  store ptr %t183, ptr %l99, !tbaa !29
  %t184 = load i64, ptr %l6, !tbaa !24
  %t185 = load ptr, ptr %l3, !tbaa !29
  %t186 = load i64, ptr %l1, !tbaa !24
  %t187 = load i64, ptr %l2, !tbaa !24
  %t192 = call %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v1, ptr %v0, i64 %t184, ptr %t185, i64 %t186, i64 %t187)
  store %"compiler/check:roDeepArg" %t192, ptr %l104
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t193 = load ptr, ptr %l99, !tbaa !29
  %t194 = load %"compiler/check:roDeepArg", ptr %l104
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v0, ptr %t193, %"compiler/check:roDeepArg" %t194)
  br label %bb57
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb59:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l105, !tbaa !29
  %t196 = load ptr, ptr %l3, !tbaa !29
  %t199 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t196)
  store i32 %t199, ptr %l108
  br label %bb60
bb60:
  %t200 = load ptr, ptr %l105, !tbaa !29
  %t201 = load i32, ptr %l108, !tbaa !23
  %t202 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t200, i32 %t201)
  store i1 %t202, ptr %l109
  br label %bb61
bb61:
  %t203 = load i1, ptr %l109, !tbaa !21
  %t204 = xor i1 %t203, true
  br i1 %t204, label %bb62, label %bb63
bb62:
  br label %ret
bb63:
  br label %bb64
bb64:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load ptr, ptr %l3, !tbaa !29
  %t211 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t206, ptr %t207)
  store i1 %t211, ptr %l114
  br label %bb65
bb65:
  %t212 = load i1, ptr %l114, !tbaa !21
  br i1 %t212, label %bb66, label %bb67
bb66:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 102
  store ptr %t215, ptr %l116, !tbaa !29
  %t216 = load i64, ptr %l1, !tbaa !24
  store i64 %t216, ptr %l117, !tbaa !24
  %t217 = load i64, ptr %l2, !tbaa !24
  store i64 %t217, ptr %l118, !tbaa !24
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l4
  %t222 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t218, %"compiler/source:Span" %t219)
  store { i64, [3 x i64] } %t222, ptr %l121
  br label %bb68
bb67:
  br label %bb80
bb68:
  %t223 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t223, ptr %l122, !tbaa !27
  %t224 = call ptr @__olang_scope_hold(ptr %v0)
  %t225 = ptrtoint ptr %t224 to i64
  store i64 %t225, ptr %l123, !tbaa !24
  %t226 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aroArg_2e4
  br i1 %t226, label %bb69, label %bb70
bb69:
  %t228 = call ptr @__olang_region_make(ptr %v0)
  %t229 = ptrtoint ptr %t228 to i64
  store i64 %t229, ptr %l123, !tbaa !24
  br label %bb70
bb70:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l125, !tbaa !29
  %t231 = load ptr, ptr %l3, !tbaa !29
  %t234 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t231)
  store i32 %t234, ptr %l128
  br label %bb71
bb71:
  %t235 = load i64, ptr %l123
  %t236 = inttoptr i64 %t235 to ptr
  %t237 = load ptr, ptr %l125, !tbaa !29
  %t238 = load i32, ptr %l128, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %t236, ptr %t237, i32 %t238)
  store { i64, ptr } %t239, ptr %l129
  br label %bb72
bb72:
  %t240 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t240, ptr %l130, !tbaa !27
  %t241 = call ptr @__olang_scope_hold(ptr %v0)
  %t242 = ptrtoint ptr %t241 to i64
  store i64 %t242, ptr %l131, !tbaa !24
  %t243 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aroArg_2e5
  br i1 %t243, label %bb73, label %bb74
bb73:
  %t245 = call ptr @__olang_region_make(ptr %v0)
  %t246 = ptrtoint ptr %t245 to i64
  store i64 %t246, ptr %l131, !tbaa !24
  br label %bb74
bb74:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l133, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l3, !tbaa !29
  %t252 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t248, ptr %t249)
  store i32 %t252, ptr %l136
  br label %bb75
bb75:
  %t253 = load ptr, ptr %l3, !tbaa !29
  %t256 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t253)
  store i32 %t256, ptr %l139
  br label %bb76
bb76:
  %t257 = load i64, ptr %l131
  %t258 = inttoptr i64 %t257 to ptr
  %t259 = load ptr, ptr %l133, !tbaa !29
  %t260 = load i32, ptr %l136, !tbaa !23
  %t261 = load i32, ptr %l139, !tbaa !23
  %t262 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %t258, ptr %t259, i32 %t260, i32 %t261)
  store { i64, ptr } %t262, ptr %l140
  br label %bb77
bb77:
  %t263 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t264 = load i64, ptr %l131
  %t265 = inttoptr i64 %t264 to ptr
  %t266 = extractvalue { i64, ptr } %t263, 0
  %t267 = extractvalue { i64, ptr } %t263, 1
  %t268 = mul i64 %t266, 1
  %t269 = call ptr @__olang_held_alloc(ptr %t265, i64 %t268)
  call void @llvm.memcpy.p0.p0.i64(ptr %t269, ptr %t267, i64 %t268, i1 false)
  %t270 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  %t272 = load i64, ptr %l117, !tbaa !24
  %t273 = load i64, ptr %l118, !tbaa !24
  %t274 = load { i64, [3 x i64] }, ptr %l121
  %t275 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t276 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t278 = call %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, i64 %t272, i64 %t273, { i64, [3 x i64] } %t274, { i64, ptr } %t275, { i64, ptr } %t276, { i64, ptr } %t271)
  store %"compiler/check:roArg" %t278, ptr %l142
  br label %bb78
bb78:
  %t279 = load ptr, ptr %l116, !tbaa !29
  %t280 = load %"compiler/check:roArg", ptr %l142
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v0, ptr %t279, %"compiler/check:roArg" %t280)
  br label %bb79
bb79:
  br label %ret
bb80:
  %t281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t281, ptr %l143, !tbaa !29
  %t282 = load ptr, ptr %l3, !tbaa !29
  %t284 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t282)
  store ptr %t284, ptr %l145
  br label %bb81
bb81:
  %t285 = load ptr, ptr %l143, !tbaa !29
  %t286 = load ptr, ptr %l145, !tbaa !29
  %t287 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t285, ptr %t286)
  store i64 %t287, ptr %l146
  br label %bb82
bb82:
  %t288 = load i64, ptr %l146, !tbaa !24
  store i64 %t288, ptr %l10, !tbaa !24
  %t289 = load i64, ptr %l10, !tbaa !24
  %t291 = icmp sge i64 %t289, 0
  br i1 %t291, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s12
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 101
  store ptr %t295, ptr %l150, !tbaa !29
  %t296 = load i64, ptr %l6, !tbaa !24
  %t297 = load i64, ptr %l10, !tbaa !24
  %t300 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t296, i64 %t297)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t300, ptr %l153
  br label %bb85
bb84:
  br label %bb89
bb85:
  %t301 = load i64, ptr %l1, !tbaa !24
  %t302 = load i64, ptr %l2, !tbaa !24
  %t305 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t301, i64 %t302)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t305, ptr %l156
  br label %bb86
bb86:
  %t306 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l153
  %t307 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l156
  %t308 = call %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s12, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t306, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t307)
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t308, ptr %l157
  br label %bb87
bb87:
  %t309 = load ptr, ptr %l150, !tbaa !29
  %t310 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l157
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %t309, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t310)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb89:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load i64, ptr %l6, !tbaa !24
  %t315 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t311, i64 %t312)
  store i1 %t315, ptr %l160
  br label %bb90
bb90:
  %t316 = load i1, ptr %l160, !tbaa !21
  br i1 %t316, label %bb91, label %bb92
bb91:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t317, i32 0, i32 108
  store ptr %t319, ptr %l162, !tbaa !29
  %t320 = load i64, ptr %l6, !tbaa !24
  %t321 = load ptr, ptr %l3, !tbaa !29
  %t322 = load i64, ptr %l1, !tbaa !24
  %t323 = load i64, ptr %l2, !tbaa !24
  %t328 = call %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v1, ptr %v0, i64 %t320, ptr %t321, i64 %t322, i64 %t323)
  store %"compiler/check:roDeepArg" %t328, ptr %l167
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t329 = load ptr, ptr %l162, !tbaa !29
  %t330 = load %"compiler/check:roDeepArg", ptr %l167
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v0, ptr %t329, %"compiler/check:roDeepArg" %t330)
  br label %bb94
bb94:
  br label %bb95
bb95:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc2(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %rv = alloca { i64, ptr }
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l8
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l13, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = icmp sge i64 %t26, 0
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t29 = load i64, ptr %l11, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
bb4:
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = load i64, ptr %l14, !tbaa !24
  %t35 = icmp sle i64 %t33, %t34
  br i1 %t35, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
bb6:
  %t37 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l11, !tbaa !24
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = getelementptr i8, ptr %t38, i64 %t39
  %t42 = sub i64 %t40, %t39
  %t43 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estable(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l42 = alloca ptr
  %l46 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca i1
  %l66 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca i32
  %l78 = alloca %"compiler/typed:Payload"
  %l82 = alloca ptr
  %l83 = alloca i1
  %l95 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l100 = alloca i32
  %l101 = alloca ptr
  %l105 = alloca ptr
  %l108 = alloca %"compiler/typed:Elem"
  %l112 = alloca ptr
  %l113 = alloca i1
  %l123 = alloca i1
  %l124 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l128 = alloca i32
  %l131 = alloca ptr
  %rv = alloca ptr
  %t71 = alloca { i64, [4 x i64] }, align 8
  %t146 = alloca { i64, [4 x i64] }, align 8
  %t222 = alloca { i64, [4 x i64] }, align 8
  %t276 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t2 = load ptr, ptr %l18, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l18, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l19, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l19, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t11 = load ptr, ptr %l22, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l22, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l23, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l23, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb10:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t23 = load ptr, ptr %l28, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb11, label %bb12
bb11:
  %t26 = load ptr, ptr %l28, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t30 = load i1, ptr %l29, !tbaa !21
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/source:Span", ptr %t34
  store %"compiler/source:Span" %t35, ptr %l2
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t39, i32 0, i32 1
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l3, !tbaa !23
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l4, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t51, i32 0, i32 3
  %t53 = load i64, ptr %t52
  store i64 %t53, ptr %l5, !tbaa !24
  br label %bb15
bb14:
  br label %bb20
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t59 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estable(ptr %v0, ptr %v1, ptr %v2, ptr %t55, ptr %t56)
  store ptr %t59, ptr %l42
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l42, !tbaa !29
  store ptr %t60, ptr %l6, !tbaa !29
  %t61 = load ptr, ptr %l6, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = load %"compiler/source:Span", ptr %l2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t70 = load i64, ptr %l5, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 0
  store i64 3, ptr %t72
  %t74 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t67, 0
  %t76 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t74, i32 %t68, 1
  %t78 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t76, ptr %t69, 2
  %t80 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t78, i64 %t70, 3
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t80, ptr %t81
  %t82 = load { i64, [4 x i64] }, ptr %t71
  %t84 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t82, ptr %t84
  store ptr %t84, ptr %l46, !tbaa !29
  br label %bb19
bb18:
  store ptr null, ptr %l46, !tbaa !29
  br label %bb19
bb19:
  %t86 = load ptr, ptr %l46, !tbaa !29
  store ptr %t86, ptr %rv
  br label %ret
bb20:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t88 = load ptr, ptr %l53, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load ptr, ptr %l53, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 8}
  %t94 = icmp eq i64 %t92, 5
  store i1 %t94, ptr %l54, !tbaa !21
  br label %bb22
bb22:
  %t95 = load i1, ptr %l54, !tbaa !21
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t98, i32 0, i32 0
  %t100 = load %"compiler/source:Span", ptr %t99
  store %"compiler/source:Span" %t100, ptr %l7
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l8, !tbaa !23
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l9, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l9, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Payload", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estable(ptr %v0, ptr %v1, ptr %v2, ptr %t114, ptr %t118)
  store ptr %t121, ptr %l66
  br label %bb26
bb26:
  %t122 = load ptr, ptr %l66, !tbaa !29
  store ptr %t122, ptr %l10, !tbaa !29
  %t123 = load ptr, ptr %l10, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb27, label %bb28
bb27:
  %t129 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t129, ptr %l71
  %t130 = load i32, ptr %l8, !tbaa !23
  store i32 %t130, ptr %l72, !tbaa !23
  %t131 = load ptr, ptr %l10, !tbaa !29
  %t132 = load ptr, ptr %l9, !tbaa !29
  %t134 = getelementptr %"compiler/typed:Payload", ptr %t132, i32 0, i32 1
  %t135 = load i64, ptr %t134, !tbaa !24
  %t136 = load ptr, ptr %l9, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Payload", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %t138, !range !{i32 0, i32 4}
  %t143 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v2, ptr %v2, ptr %t131, i64 %t135, i32 %t139)
  store %"compiler/typed:Payload" %t143, ptr %l78
  br label %bb29
bb28:
  store ptr null, ptr %l70, !tbaa !29
  br label %bb30
bb29:
  %t144 = load %"compiler/typed:Payload", ptr %l78
  %t145 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Payload" %t144, ptr %t145
  store { i64, [4 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 0
  store i64 5, ptr %t147
  %t148 = load %"compiler/source:Span", ptr %l71
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t148, 0
  %t150 = load i32, ptr %l72, !tbaa !23
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr } %t149, i32 %t150, 1
  %t153 = insertvalue { %"compiler/source:Span", i32, ptr } %t151, ptr %t145, 2
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t153, ptr %t154
  %t155 = load { i64, [4 x i64] }, ptr %t146
  %t157 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t155, ptr %t157
  store ptr %t157, ptr %l70, !tbaa !29
  br label %bb30
bb30:
  %t159 = load ptr, ptr %l70, !tbaa !29
  store ptr %t159, ptr %rv
  br label %ret
bb31:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t161 = load ptr, ptr %l82, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb32, label %bb33
bb32:
  %t164 = load ptr, ptr %l82, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 8}
  %t167 = icmp eq i64 %t165, 4
  store i1 %t167, ptr %l83, !tbaa !21
  br label %bb33
bb33:
  %t168 = load i1, ptr %l83, !tbaa !21
  br i1 %t168, label %bb34, label %bb35
bb34:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [4 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t171, i32 0, i32 0
  %t173 = load %"compiler/source:Span", ptr %t172
  store %"compiler/source:Span" %t173, ptr %l11
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [4 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t177, i32 0, i32 1
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l12, !tbaa !23
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t183, i32 0, i32 2
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l13, !tbaa !29
  br label %bb36
bb35:
  br label %bb43
bb36:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l13, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Elem", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t194 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estable(ptr %v0, ptr %v1, ptr %v2, ptr %t187, ptr %t191)
  store ptr %t194, ptr %l95
  br label %bb37
bb37:
  %t195 = load ptr, ptr %l95, !tbaa !29
  store ptr %t195, ptr %l14, !tbaa !29
  %t196 = load ptr, ptr %l14, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  br i1 %t198, label %bb38, label %bb39
bb38:
  store ptr null, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t201 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t201, ptr %l99
  %t202 = load i32, ptr %l12, !tbaa !23
  store i32 %t202, ptr %l100, !tbaa !23
  %t203 = load ptr, ptr %l14, !tbaa !29
  store ptr %t203, ptr %l101, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l13, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Elem", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonce(ptr %v0, ptr %v1, ptr %v1, ptr %t204, ptr %t208)
  store ptr %t211, ptr %l105
  br label %bb41
bb41:
  %t212 = load ptr, ptr %l13, !tbaa !29
  %t214 = getelementptr %"compiler/typed:Elem", ptr %t212, i32 0, i32 2
  %t215 = load i32, ptr %t214, !range !{i32 0, i32 4}
  %t216 = load ptr, ptr %l101, !tbaa !29
  %t217 = load ptr, ptr %l105, !tbaa !29
  %t219 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v2, ptr %v1, ptr %v2, ptr %t216, ptr %t217, i32 %t215)
  store %"compiler/typed:Elem" %t219, ptr %l108
  br label %bb42
bb42:
  %t220 = load %"compiler/typed:Elem", ptr %l108
  %t221 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Elem" %t220, ptr %t221
  store { i64, [4 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t222, i32 0, i32 0
  store i64 4, ptr %t223
  %t224 = load %"compiler/source:Span", ptr %l99
  %t225 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t224, 0
  %t226 = load i32, ptr %l100, !tbaa !23
  %t227 = insertvalue { %"compiler/source:Span", i32, ptr } %t225, i32 %t226, 1
  %t229 = insertvalue { %"compiler/source:Span", i32, ptr } %t227, ptr %t221, 2
  %t230 = getelementptr { i64, [4 x i64] }, ptr %t222, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t229, ptr %t230
  %t231 = load { i64, [4 x i64] }, ptr %t222
  %t233 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t231, ptr %t233
  store ptr %t233, ptr %rv
  br label %ret
bb43:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t236 = load ptr, ptr %l112, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb44, label %bb45
bb44:
  %t239 = load ptr, ptr %l112, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 8}
  %t242 = icmp eq i64 %t240, 2
  store i1 %t242, ptr %l113, !tbaa !21
  br label %bb45
bb45:
  %t243 = load i1, ptr %l113, !tbaa !21
  br i1 %t243, label %bb46, label %bb47
bb46:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [4 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t246, i32 0, i32 0
  %t248 = load %"compiler/source:Span", ptr %t247
  store %"compiler/source:Span" %t248, ptr %l15
  %t250 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr { i64, [4 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t252, i32 0, i32 1
  %t254 = load i32, ptr %t253
  store i32 %t254, ptr %l16, !tbaa !23
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l17, !tbaa !29
  br label %bb48
bb47:
  br label %bb54
bb48:
  %t262 = load ptr, ptr %l17, !tbaa !29
  %t264 = call i1 @compiler_2fcheck_2epureRead(ptr %v1, ptr %t262)
  store i1 %t264, ptr %l123
  br label %bb49
bb49:
  %t265 = load i1, ptr %l123, !tbaa !21
  br i1 %t265, label %bb50, label %bb51
bb50:
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l124, !tbaa !29
  br label %bb53
bb51:
  %t269 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t269, ptr %l127
  %t270 = load i32, ptr %l16, !tbaa !23
  store i32 %t270, ptr %l128, !tbaa !23
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load ptr, ptr %l17, !tbaa !29
  %t275 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonce(ptr %v0, ptr %v1, ptr %v2, ptr %t271, ptr %t272)
  store ptr %t275, ptr %l131
  br label %bb52
bb52:
  store { i64, [4 x i64] } zeroinitializer, ptr %t276
  %t277 = getelementptr { i64, [4 x i64] }, ptr %t276, i32 0, i32 0
  store i64 2, ptr %t277
  %t278 = load %"compiler/source:Span", ptr %l127
  %t279 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t278, 0
  %t280 = load i32, ptr %l128, !tbaa !23
  %t281 = insertvalue { %"compiler/source:Span", i32, ptr } %t279, i32 %t280, 1
  %t282 = load ptr, ptr %l131, !tbaa !29
  %t283 = insertvalue { %"compiler/source:Span", i32, ptr } %t281, ptr %t282, 2
  %t284 = getelementptr { i64, [4 x i64] }, ptr %t276, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t283, ptr %t284
  %t285 = load { i64, [4 x i64] }, ptr %t276
  %t287 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t285, ptr %t287
  store ptr %t287, ptr %l124, !tbaa !29
  br label %bb53
bb53:
  %t289 = load ptr, ptr %l124, !tbaa !29
  store ptr %t289, ptr %rv
  br label %ret
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store ptr null, ptr %rv
  br label %ret
bb58:
  call void @__olang_check_failed(ptr @olang_loc_d7951065f36562ee_848e8c34c6c42472)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estdTypeModule(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l36 = alloca i1
  %l37 = alloca i1
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l8, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t11)
  store i1 %t13, ptr %l10
  br label %bb3
bb3:
  %t14 = load i1, ptr %l10, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l7, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l14, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l15, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l14, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t32, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = call { i64, ptr } @compiler_2fcheck_2elowerAll(ptr %v1, ptr %s0, { i64, ptr } %t34)
  store { i64, ptr } %t36, ptr %l17
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  %t40 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = extractvalue { i64, ptr } %t47, 0
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t56 = extractvalue { i64, ptr } %t48, 1
  %t57 = extractvalue { i64, ptr } %t48, 0
  %t58 = add i64 %t54, %t57
  %t59 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t50, i64 %t51)
  %t63 = getelementptr i8, ptr %t62, i64 %t51
  call void @olang_textcopy(ptr %t63, ptr %t52, i64 %t53)
  %t64 = getelementptr i8, ptr %t63, i64 %t53
  call void @olang_textcopy(ptr %t64, ptr %t56, i64 %t57)
  %t65 = getelementptr i8, ptr %t64, i64 %t57
  call void @olang_textcopy(ptr %t65, ptr %t59, i64 %t60)
  %t66 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t62, 1
  %t70 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t67)
  %t71 = extractvalue { i32, { i64, ptr } } %t70, 1
  %t72 = extractvalue { i32, { i64, ptr } } %t70, 0
  store i32 %t72, ptr %l27
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb10, label %ok.74, !prof !99
ok.74:
  store { i64, ptr } %t71, ptr %l26
  br label %bb9
bb9:
  %t75 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t75, ptr %l18, !tbaa !27
  br label %bb14
bb10:
  %t76 = load i32, ptr %l27, !tbaa !23
  %t77 = ashr i32 %t76, 16
  %t79 = icmp eq i32 %t77, 1
  br i1 %t79, label %bb11, label %bb12
bb11:
  call void @__olang_errpay_pop()
  br label %bb12
bb12:
  br label %bb13
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l18, !tbaa !27
  br label %bb14
bb14:
  %t81 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t81, ptr %l3, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t85 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t88 = extractvalue { i64, ptr } %t84, 1
  %t89 = extractvalue { i64, ptr } %t84, 0
  %t90 = add i64 %t86, %t89
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t85, i64 %t86)
  %t95 = getelementptr i8, ptr %t94, i64 %t86
  call void @olang_textcopy(ptr %t95, ptr %t88, i64 %t89)
  %t96 = getelementptr i8, ptr %t95, i64 %t89
  call void @olang_textcopy(ptr %t96, ptr %t91, i64 %t92)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t94, 1
  %t101 = extractvalue { i64, ptr } %t98, 0
  %t102 = extractvalue { i64, ptr } %t98, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t109 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t82, { i64, ptr } %t106)
  store i1 %t109, ptr %l36
  br label %bb15
bb15:
  %t110 = load i1, ptr %l36, !tbaa !21
  br i1 %t110, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb19
bb17:
  %t111 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t114 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t117 = extractvalue { i64, ptr } %t113, 1
  %t118 = extractvalue { i64, ptr } %t113, 0
  %t119 = add i64 %t115, %t118
  %t120 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t122 = add i64 %t119, %t121
  %t123 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = getelementptr i8, ptr %t123, i64 %t115
  call void @olang_textcopy(ptr %t124, ptr %t117, i64 %t118)
  %t125 = getelementptr i8, ptr %t124, i64 %t118
  call void @olang_textcopy(ptr %t125, ptr %t120, i64 %t121)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t123, 1
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = extractvalue { i64, ptr } %t127, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t138 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t111, { i64, ptr } %t135)
  store i1 %t138, ptr %l44
  br label %bb18
bb18:
  %t139 = load i1, ptr %l44, !tbaa !21
  store i1 %t139, ptr %l37, !tbaa !21
  br label %bb19
bb19:
  %t140 = load i1, ptr %l37, !tbaa !21
  br i1 %t140, label %bb20, label %bb21
bb20:
  %t141 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = extractvalue { i64, ptr } %t141, 0
  %t145 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t143, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l45, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t149, ptr %l45, !tbaa !27
  br label %bb22
bb22:
  %t151 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  store i64 %t152, ptr %l50, !tbaa !24
  %t153 = load i64, ptr %l50, !tbaa !24
  %t154 = mul i64 %t153, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t154)
  %t156 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  store { i64, ptr } %t157, ptr %l51, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = load i64, ptr %l50, !tbaa !24
  %t163 = mul i64 %t162, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t159, ptr %t161, i64 %t163, i1 false)
  %t164 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t164, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t165 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t165, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreOver(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l37 = alloca ptr
  %l46 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i1
  %l65 = alloca i64
  %l67 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca i32
  %l74 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca ptr
  %l92 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l109 = alloca ptr
  %t38 = alloca { i64, [3 x i64] }, align 8
  %t83 = alloca { i64, [3 x i64] }, align 8
  %t165 = alloca { i64, [4 x i64] }, align 8
  %t181 = alloca { i64, [3 x i64] }, align 8
  %t207 = alloca { i64, [4 x i64] }, align 8
  %t226 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load i32, ptr %l12, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l4, !tbaa !23
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l19
  br label %bb4
bb4:
  %t16 = load i1, ptr %l19, !tbaa !21
  store i1 %t16, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l16, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsDrop(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l23
  br label %bb8
bb8:
  %t23 = load i1, ptr %l23, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebufferField(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  store i1 %t31, ptr %l28
  br label %bb12
bb12:
  %t32 = load i1, ptr %l28, !tbaa !21
  store i1 %t32, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 0
  store i64 1, ptr %t39
  %t41 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t35, 0
  %t43 = insertvalue { %"compiler/source:Span", ptr, ptr } %t41, ptr %t36, 1
  %t45 = insertvalue { %"compiler/source:Span", ptr, ptr } %t43, ptr %t37, 2
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t45, ptr %t46
  %t47 = load { i64, [3 x i64] }, ptr %t38
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t47, ptr %t49
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t34, ptr %t49)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %ret
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estable(ptr %v0, ptr %v1, ptr %v1, ptr %t52, ptr %t53)
  store ptr %t56, ptr %l37
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l37, !tbaa !29
  store ptr %t57, ptr %l5, !tbaa !29
  %t58 = load ptr, ptr %l5, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t62, %"compiler/source:Span" %t63, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %ret
bb22:
  %t66 = load ptr, ptr %l5, !tbaa !29
  store ptr %t66, ptr %l2, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load %"compiler/source:Span", ptr %l1
  %t70 = load i32, ptr %l4, !tbaa !23
  %t74 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t68, %"compiler/source:Span" %t69, i32 %t70)
  store i64 %t74, ptr %l46
  br label %bb23
bb23:
  %t75 = load i64, ptr %l46, !tbaa !24
  store i64 %t75, ptr %l6, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l1
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = trunc i64 %t78 to i32
  %t82 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [3 x i64] }, ptr %t83, i32 0, i32 0
  store i64 0, ptr %t84
  %t86 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t77, 0
  %t88 = insertvalue { %"compiler/source:Span", i32, ptr } %t86, i32 %t80, 1
  %t90 = insertvalue { %"compiler/source:Span", i32, ptr } %t88, ptr %t82, 2
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t83, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t90, ptr %t91
  %t92 = load { i64, [3 x i64] }, ptr %t83
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t92, ptr %t94
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t76, ptr %t94)
  br label %bb24
bb24:
  store i64 -1, ptr %l7, !tbaa !24
  %t97 = load ptr, ptr %l2, !tbaa !29
  store ptr %t97, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t98 = load ptr, ptr %l55, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb25, label %bb26
bb25:
  %t101 = load ptr, ptr %l55, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 8}
  %t104 = icmp eq i64 %t102, 0
  store i1 %t104, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t105 = load i1, ptr %l56, !tbaa !21
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t108, i32 0, i32 0
  %t110 = load %"compiler/source:Span", ptr %t109
  store %"compiler/source:Span" %t110, ptr %l8
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t114, i32 0, i32 1
  %t116 = load i32, ptr %t115
  store i32 %t116, ptr %l9, !tbaa !23
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t120, i32 0, i32 2
  %t122 = load i32, ptr %t121
  store i32 %t122, ptr %l10, !tbaa !23
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t124)
  store ptr %t126, ptr %l67
  br label %bb29
bb28:
  br label %bb34
bb29:
  %t127 = load ptr, ptr %l67, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 23
  %t130 = load i32, ptr %l10, !tbaa !23
  %t132 = sext i32 %t130 to i64
  %t135 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t129, i64 %t132)
  %t136 = extractvalue { i32, i64 } %t135, 1
  %t137 = extractvalue { i32, i64 } %t135, 0
  store i32 %t137, ptr %l73
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb31, label %ok.139, !prof !99
ok.139:
  store i64 %t136, ptr %l72
  br label %bb30
bb30:
  %t140 = load i64, ptr %l72, !tbaa !24
  store i64 %t140, ptr %l65, !tbaa !24
  br label %bb33
bb31:
  br label %bb32
bb32:
  store i64 -1, ptr %l65, !tbaa !24
  br label %bb33
bb33:
  %t141 = load i64, ptr %l65, !tbaa !24
  store i64 %t141, ptr %l7, !tbaa !24
  br label %bb34
bb34:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l74, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l1
  %t145 = load ptr, ptr %l2, !tbaa !29
  %t146 = load i64, ptr %l7, !tbaa !24
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v1, ptr %v0, ptr %t143, %"compiler/source:Span" %t144, ptr %t145, i64 %t146)
  store ptr %t151, ptr %l79
  br label %bb35
bb35:
  %t152 = load ptr, ptr %l74, !tbaa !29
  %t153 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t152, ptr %t153)
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l80, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t155, ptr %l81
  %t156 = load ptr, ptr %l2, !tbaa !29
  store ptr %t156, ptr %l82, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  %t159 = load %"compiler/source:Span", ptr %l1
  %t160 = load i32, ptr %l4, !tbaa !23
  %t161 = load i64, ptr %l6, !tbaa !24
  %t163 = trunc i64 %t161 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 0
  store i64 0, ptr %t166
  %t168 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t159, 0
  %t170 = insertvalue { %"compiler/source:Span", i32, i32 } %t168, i32 %t160, 1
  %t172 = insertvalue { %"compiler/source:Span", i32, i32 } %t170, i32 %t163, 2
  %t173 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t172, ptr %t173
  %t174 = load { i64, [4 x i64] }, ptr %t165
  %t176 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t174, ptr %t176
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t157, %"compiler/source:Span" %t158, ptr %t176)
  store ptr %t180, ptr %l92
  br label %bb37
bb37:
  store { i64, [3 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [3 x i64] }, ptr %t181, i32 0, i32 0
  store i64 1, ptr %t182
  %t183 = load %"compiler/source:Span", ptr %l81
  %t184 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t183, 0
  %t185 = load ptr, ptr %l82, !tbaa !29
  %t186 = insertvalue { %"compiler/source:Span", ptr, ptr } %t184, ptr %t185, 1
  %t187 = load ptr, ptr %l92, !tbaa !29
  %t188 = insertvalue { %"compiler/source:Span", ptr, ptr } %t186, ptr %t187, 2
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t188, ptr %t189
  %t190 = load { i64, [3 x i64] }, ptr %t181
  %t192 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t190, ptr %t192
  %t193 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t193, ptr %t192)
  br label %bb38
bb38:
  %t195 = load i64, ptr %l7, !tbaa !24
  %t197 = icmp sge i64 %t195, 0
  br i1 %t197, label %bb39, label %bb40
bb39:
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l97, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t200, ptr %l98
  %t201 = load %"compiler/source:Span", ptr %l1
  %t202 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t203 = load i64, ptr %l7, !tbaa !24
  %t205 = trunc i64 %t203 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 0
  store i64 0, ptr %t208
  %t210 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t201, 0
  %t212 = insertvalue { %"compiler/source:Span", i32, i32 } %t210, i32 %t202, 1
  %t214 = insertvalue { %"compiler/source:Span", i32, i32 } %t212, i32 %t205, 2
  %t215 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t214, ptr %t215
  %t216 = load { i64, [4 x i64] }, ptr %t207
  %t218 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t216, ptr %t218
  store ptr %t218, ptr %l105, !tbaa !29
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l1
  %t221 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t225 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t219, %"compiler/source:Span" %t220, i32 %t221, i64 1)
  store ptr %t225, ptr %l109
  br label %bb41
bb40:
  br label %bb43
bb41:
  store { i64, [3 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 0
  store i64 1, ptr %t227
  %t228 = load %"compiler/source:Span", ptr %l98
  %t229 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t228, 0
  %t230 = load ptr, ptr %l105, !tbaa !29
  %t231 = insertvalue { %"compiler/source:Span", ptr, ptr } %t229, ptr %t230, 1
  %t232 = load ptr, ptr %l109, !tbaa !29
  %t233 = insertvalue { %"compiler/source:Span", ptr, ptr } %t231, ptr %t232, 2
  %t234 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t233, ptr %t234
  %t235 = load { i64, [3 x i64] }, ptr %t226
  %t237 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t235, ptr %t237
  %t238 = load ptr, ptr %l97, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t238, ptr %t237)
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetDecls(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i1 %a3, i1 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca { i64, [3 x i64] }
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l34 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca { i64, [3 x i64] }
  %l69 = alloca %"compiler/diagmsg:Msg"
  %l70 = alloca i64
  %l72 = alloca i32
  %l75 = alloca ptr
  %l80 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l91 = alloca { i64, [3 x i64] }
  %l95 = alloca { i64, ptr }
  %l97 = alloca %"compiler/diagmsg:Msg"
  %l98 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i1
  %l131 = alloca { i64, ptr }
  %l142 = alloca i1
  %l144 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l155 = alloca { i64, [3 x i64] }
  %l159 = alloca { i64, ptr }
  %l161 = alloca %"compiler/diagmsg:Msg"
  %l162 = alloca i64
  %l168 = alloca ptr
  %l174 = alloca { i64, [3 x i64] }
  %l177 = alloca { i64, ptr }
  %l178 = alloca %"compiler/diagmsg:Msg"
  %l179 = alloca i64
  %l183 = alloca i1
  %l184 = alloca ptr
  %l185 = alloca { i64, [3 x i64] }
  %l188 = alloca { i64, ptr }
  %l189 = alloca %"compiler/diagmsg:Msg"
  %l190 = alloca i64
  %l193 = alloca ptr
  %l194 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i64
  %l201 = alloca ptr
  %l202 = alloca ptr
  %l203 = alloca i1
  %l204 = alloca i1
  %l207 = alloca ptr
  %l208 = alloca i64
  %l214 = alloca %"compiler/source:Span"
  %l216 = alloca i64
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %t88 = alloca { i64, [3 x i64] }, align 8
  %t148 = alloca { i64, [3 x i64] }, align 8
  %t288 = alloca { i64, [3 x i64] }, align 8
  %t333 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i1 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 10
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l34
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l34, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 4
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l6, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/load:Loader", ptr %t31, i32 0, i32 4
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l7, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  %t42 = load i64, ptr %l9, !tbaa !24
  %t43 = load i64, ptr %l10, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb6, label %bb7
bb6:
  br label %bb91
bb7:
  br label %bb8
bb8:
  %t50 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t50, ptr %l48, !tbaa !27
  %t51 = load i64, ptr %l9, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  store ptr %t56, ptr %l11, !tbaa !29
  %t58 = load ptr, ptr %l11, !tbaa !29
  store ptr %t58, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t59 = load ptr, ptr %l51, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb9, label %bb10
bb9:
  %t62 = load ptr, ptr %l51, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 12}
  %t65 = icmp eq i64 %t63, 9
  store i1 %t65, ptr %l52, !tbaa !21
  br label %bb10
bb10:
  %t66 = load i1, ptr %l52, !tbaa !21
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t67 = load ptr, ptr %l11, !tbaa !29
  %t69 = getelementptr { i64, [8 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t69, i32 0, i32 0
  %t71 = load %"compiler/source:Span", ptr %t70
  store %"compiler/source:Span" %t71, ptr %l12
  %t73 = load ptr, ptr %l11, !tbaa !29
  %t75 = getelementptr { i64, [8 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l13, !tbaa !29
  br label %bb13
bb12:
  br label %bb72
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t84 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 1
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = sext i32 %t85 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 0
  store i64 3, ptr %t89
  %t91 = insertvalue { i64, i64, i64 } undef, i64 %t79, 0
  %t93 = insertvalue { i64, i64, i64 } %t91, i64 %t83, 1
  %t95 = insertvalue { i64, i64, i64 } %t93, i64 %t87, 2
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 1
  store { i64, i64, i64 } %t95, ptr %t96
  %t97 = load { i64, [3 x i64] }, ptr %t88
  store { i64, [3 x i64] } %t97, ptr %l14
  %t99 = load i1, ptr %l3, !tbaa !21
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb14, label %bb15
bb14:
  %t103 = load ptr, ptr %l7, !tbaa !29
  store ptr %t103, ptr %l67, !tbaa !29
  %t104 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t104, ptr %l68
  %t105 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetPlace(ptr %v0)
  store %"compiler/diagmsg:Msg" %t105, ptr %l69
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t106 = load ptr, ptr %l67, !tbaa !29
  %t107 = load { i64, [3 x i64] }, ptr %l68
  %t108 = load %"compiler/diagmsg:Msg", ptr %l69
  %t109 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t106, { i64, [3 x i64] } %t107, %"compiler/diagmsg:Msg" %t108)
  store i64 %t109, ptr %l70
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb18:
  %t110 = load ptr, ptr %l13, !tbaa !29
  %t112 = call i32 @compiler_2fcheck_2esetName(ptr %v1, ptr %t110)
  store i32 %t112, ptr %l72
  br label %bb19
bb19:
  %t113 = load i32, ptr %l72, !tbaa !23
  store i32 %t113, ptr %l15, !tbaa !23
  %t114 = load i32, ptr %l15, !tbaa !23
  %t116 = icmp ne i32 %t114, 0
  br i1 %t116, label %bb20, label %bb21
bb20:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load i64, ptr %l1, !tbaa !24
  %t123 = load i32, ptr %l15, !tbaa !23
  %t127 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %s4, ptr %t121, i64 %t122, i32 %t123)
  store ptr %t127, ptr %l80
  br label %bb22
bb21:
  store ptr null, ptr %l75, !tbaa !29
  br label %bb23
bb22:
  %t128 = load ptr, ptr %l80, !tbaa !29
  store ptr %t128, ptr %l75, !tbaa !29
  br label %bb23
bb23:
  %t129 = load ptr, ptr %l75, !tbaa !29
  store ptr %t129, ptr %l16, !tbaa !29
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t132 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t130)
  store %"compiler/source:Span" %t132, ptr %l82
  br label %bb24
bb24:
  %t133 = load %"compiler/source:Span", ptr %l82
  store %"compiler/source:Span" %t133, ptr %l17
  %t134 = load ptr, ptr %l16, !tbaa !29
  %t136 = icmp eq ptr %t134, null
  br i1 %t136, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t138 = load ptr, ptr %l7, !tbaa !29
  store ptr %t138, ptr %l85, !tbaa !29
  %t139 = load i64, ptr %l6, !tbaa !24
  %t140 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  %t144 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 1
  %t145 = load i32, ptr %t144, !tbaa !23
  %t147 = sext i32 %t145 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t148
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t148, i32 0, i32 0
  store i64 3, ptr %t149
  %t151 = insertvalue { i64, i64, i64 } undef, i64 %t139, 0
  %t153 = insertvalue { i64, i64, i64 } %t151, i64 %t143, 1
  %t155 = insertvalue { i64, i64, i64 } %t153, i64 %t147, 2
  %t156 = getelementptr { i64, [3 x i64] }, ptr %t148, i32 0, i32 1
  store { i64, i64, i64 } %t155, ptr %t156
  %t157 = load { i64, [3 x i64] }, ptr %t148
  store { i64, [3 x i64] } %t157, ptr %l91
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l6, !tbaa !24
  %t160 = load %"compiler/source:Span", ptr %l17
  %t164 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc2(ptr %v0, ptr %s6, ptr %t158, i64 %t159, %"compiler/source:Span" %t160)
  store { i64, ptr } %t164, ptr %l95
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t165 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t167 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetTarget(ptr %s6, ptr %v0, { i64, ptr } %t165)
  store %"compiler/diagmsg:Msg" %t167, ptr %l97
  br label %bb28
bb28:
  %t168 = load ptr, ptr %l85, !tbaa !29
  %t169 = load { i64, [3 x i64] }, ptr %l91
  %t170 = load %"compiler/diagmsg:Msg", ptr %l97
  %t171 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t168, { i64, [3 x i64] } %t169, %"compiler/diagmsg:Msg" %t170)
  store i64 %t171, ptr %l98
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb30:
  store i64 -1, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t172 = load ptr, ptr %l16, !tbaa !29
  %t174 = getelementptr %"compiler/ast:VarDecl", ptr %t172, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t179 = load i64, ptr %l20, !tbaa !24
  %t180 = load i64, ptr %l19, !tbaa !24
  %t183 = icmp sgt i64 %t179, %t180
  br i1 %t183, label %bb31, label %bb32
bb31:
  %t185 = load i64, ptr %l21, !tbaa !24
  %t187 = icmp sgt i64 %t185, 0
  br i1 %t187, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb36
bb33:
  %t189 = load i64, ptr %l20, !tbaa !24
  %t190 = load i64, ptr %l19, !tbaa !24
  %t193 = sub i64 %t189, %t190
  %t194 = load i64, ptr %l21, !tbaa !24
  %t197 = add i64 %t193, %t194
  %t199 = sub i64 %t197, 1
  %t200 = load i64, ptr %l21, !tbaa !24
  %t203 = sdiv i64 %t199, %t200
  store i64 %t203, ptr %l108, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb35
bb35:
  %t205 = load i64, ptr %l108, !tbaa !24
  store i64 %t205, ptr %l105, !tbaa !24
  br label %bb36
bb36:
  %t206 = load i64, ptr %l105, !tbaa !24
  store i64 %t206, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  %t207 = load i64, ptr %l22, !tbaa !24
  %t208 = sub i64 %t207, 1
  store i64 %t208, ptr %l117, !tbaa !24
  %t209 = load i64, ptr %l22, !tbaa !24
  %t210 = icmp slt i64 %t209, 2147483648
  %t211 = load i64, ptr %l23, !tbaa !24
  %t212 = icmp sge i64 %t211, 0
  %t215 = and i1 %t210, %t212
  store i1 %t215, ptr %l120, !tbaa !21
  br label %bb37
bb37:
  %t216 = load i64, ptr %l23, !tbaa !24
  %t217 = load i64, ptr %l22, !tbaa !24
  %t220 = icmp slt i64 %t216, %t217
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb38, label %bb39
bb38:
  br label %bb45
bb39:
  br label %bb40
bb40:
  %t224 = load i64, ptr %l19, !tbaa !24
  %t225 = load i64, ptr %l23, !tbaa !24
  %t226 = load i64, ptr %l21, !tbaa !24
  %t229 = mul i64 %t225, %t226
  %t232 = add i64 %t224, %t229
  store i64 %t232, ptr %l24, !tbaa !24
  %t234 = load ptr, ptr %l16, !tbaa !29
  %t236 = getelementptr %"compiler/ast:VarDecl", ptr %t234, i32 0, i32 0
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  store { i64, ptr } %t237, ptr %l131, !tbaa !27
  %t238 = load i64, ptr %l24, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr i32, ptr %t241, i64 %t238
  %t243 = load i32, ptr %t242, !tbaa !33
  %t244 = load i32, ptr %l15, !tbaa !23
  %t247 = icmp eq i32 %t243, %t244
  br i1 %t247, label %bb41, label %bb42
bb41:
  %t249 = load i64, ptr %l24, !tbaa !24
  store i64 %t249, ptr %l18, !tbaa !24
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t251 = load i64, ptr %l23, !tbaa !24
  %t254 = add i64 %t251, 1
  store i64 %t254, ptr %l23, !tbaa !24
  br label %bb37
bb45:
  %t256 = load i64, ptr %l18, !tbaa !24
  %t258 = icmp slt i64 %t256, 0
  br i1 %t258, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb48
bb47:
  %t260 = load ptr, ptr %l16, !tbaa !29
  %t262 = getelementptr %"compiler/ast:VarDecl", ptr %t260, i32 0, i32 1
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l144, !tbaa !27
  %t264 = load i64, ptr %l18, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr %"compiler/source:Span", ptr %t267, i64 %t264
  %t269 = getelementptr %"compiler/source:Span", ptr %t268, i32 0, i32 0
  %t270 = load i32, ptr %t269, !tbaa !23
  %t271 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 0
  %t272 = load i32, ptr %t271, !tbaa !23
  %t275 = icmp sgt i32 %t270, %t272
  store i1 %t275, ptr %l142, !tbaa !21
  br label %bb48
bb48:
  %t277 = load i1, ptr %l142, !tbaa !21
  br i1 %t277, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t278 = load ptr, ptr %l7, !tbaa !29
  store ptr %t278, ptr %l149, !tbaa !29
  %t279 = load i64, ptr %l6, !tbaa !24
  %t280 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t281 = load i32, ptr %t280, !tbaa !23
  %t283 = sext i32 %t281 to i64
  %t284 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 1
  %t285 = load i32, ptr %t284, !tbaa !23
  %t287 = sext i32 %t285 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t288
  %t289 = getelementptr { i64, [3 x i64] }, ptr %t288, i32 0, i32 0
  store i64 3, ptr %t289
  %t291 = insertvalue { i64, i64, i64 } undef, i64 %t279, 0
  %t293 = insertvalue { i64, i64, i64 } %t291, i64 %t283, 1
  %t295 = insertvalue { i64, i64, i64 } %t293, i64 %t287, 2
  %t296 = getelementptr { i64, [3 x i64] }, ptr %t288, i32 0, i32 1
  store { i64, i64, i64 } %t295, ptr %t296
  %t297 = load { i64, [3 x i64] }, ptr %t288
  store { i64, [3 x i64] } %t297, ptr %l155
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load i64, ptr %l6, !tbaa !24
  %t300 = load %"compiler/source:Span", ptr %l17
  %t304 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc2(ptr %v0, ptr %s11, ptr %t298, i64 %t299, %"compiler/source:Span" %t300)
  store { i64, ptr } %t304, ptr %l159
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t305 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t307 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetTarget(ptr %s11, ptr %v0, { i64, ptr } %t305)
  store %"compiler/diagmsg:Msg" %t307, ptr %l161
  br label %bb52
bb52:
  %t308 = load ptr, ptr %l149, !tbaa !29
  %t309 = load { i64, [3 x i64] }, ptr %l155
  %t310 = load %"compiler/diagmsg:Msg", ptr %l161
  %t311 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t308, { i64, [3 x i64] } %t309, %"compiler/diagmsg:Msg" %t310)
  store i64 %t311, ptr %l162
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb54:
  %t312 = load i64, ptr %l18, !tbaa !24
  %t313 = load ptr, ptr %l16, !tbaa !29
  %t315 = getelementptr %"compiler/ast:VarDecl", ptr %t313, i32 0, i32 3
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t321 = icmp slt i64 %t312, %t318
  br i1 %t321, label %bb55, label %bb56
bb55:
  %t323 = load ptr, ptr %l7, !tbaa !29
  store ptr %t323, ptr %l168, !tbaa !29
  %t324 = load i64, ptr %l6, !tbaa !24
  %t325 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t326 = load i32, ptr %t325, !tbaa !23
  %t328 = sext i32 %t326 to i64
  %t329 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 1
  %t330 = load i32, ptr %t329, !tbaa !23
  %t332 = sext i32 %t330 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t333
  %t334 = getelementptr { i64, [3 x i64] }, ptr %t333, i32 0, i32 0
  store i64 3, ptr %t334
  %t336 = insertvalue { i64, i64, i64 } undef, i64 %t324, 0
  %t338 = insertvalue { i64, i64, i64 } %t336, i64 %t328, 1
  %t340 = insertvalue { i64, i64, i64 } %t338, i64 %t332, 2
  %t341 = getelementptr { i64, [3 x i64] }, ptr %t333, i32 0, i32 1
  store { i64, i64, i64 } %t340, ptr %t341
  %t342 = load { i64, [3 x i64] }, ptr %t333
  store { i64, [3 x i64] } %t342, ptr %l174
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l15, !tbaa !23
  %t347 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t343, i32 %t344)
  store { i64, ptr } %t347, ptr %l177
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t348 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t349 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetHasValue(ptr %v0, ptr %v0, { i64, ptr } %t348)
  store %"compiler/diagmsg:Msg" %t349, ptr %l178
  br label %bb58
bb58:
  %t350 = load ptr, ptr %l168, !tbaa !29
  %t351 = load { i64, [3 x i64] }, ptr %l174
  %t352 = load %"compiler/diagmsg:Msg", ptr %l178
  %t353 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t350, { i64, [3 x i64] } %t351, %"compiler/diagmsg:Msg" %t352)
  store i64 %t353, ptr %l179
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb60:
  %t354 = load i1, ptr %l4, !tbaa !21
  br i1 %t354, label %bb61, label %bb62
bb61:
  %t356 = load ptr, ptr %l5, !tbaa !29
  %t357 = load i32, ptr %l15, !tbaa !23
  %t360 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v2, ptr %t356, i32 %t357)
  store i1 %t360, ptr %l183
  br label %bb63
bb62:
  br label %bb71
bb63:
  %t361 = load i1, ptr %l183, !tbaa !21
  br i1 %t361, label %bb64, label %bb65
bb64:
  %t362 = load ptr, ptr %l7, !tbaa !29
  store ptr %t362, ptr %l184, !tbaa !29
  %t363 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t363, ptr %l185
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load i32, ptr %l15, !tbaa !23
  %t368 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t364, i32 %t365)
  store { i64, ptr } %t368, ptr %l188
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t369 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t370 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetTwice(ptr %v0, ptr %v0, { i64, ptr } %t369)
  store %"compiler/diagmsg:Msg" %t370, ptr %l189
  br label %bb67
bb67:
  %t371 = load ptr, ptr %l184, !tbaa !29
  %t372 = load { i64, [3 x i64] }, ptr %l185
  %t373 = load %"compiler/diagmsg:Msg", ptr %l189
  %t374 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t371, { i64, [3 x i64] } %t372, %"compiler/diagmsg:Msg" %t373)
  store i64 %t374, ptr %l190
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t375 = load ptr, ptr %l5, !tbaa !29
  %t376 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v2, ptr %t375, i32 %t376, i1 true)
  br label %bb70
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s4)
  br label %bb89
bb72:
  %t379 = load ptr, ptr %l11, !tbaa !29
  store ptr %t379, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t380 = load ptr, ptr %l193, !tbaa !29
  %t381 = icmp ne ptr %t380, null
  br i1 %t381, label %bb73, label %bb74
bb73:
  %t383 = load ptr, ptr %l193, !tbaa !29
  %t384 = load i64, ptr %t383, !range !{i64 0, i64 12}
  %t386 = icmp eq i64 %t384, 8
  store i1 %t386, ptr %l194, !tbaa !21
  br label %bb74
bb74:
  %t387 = load i1, ptr %l194, !tbaa !21
  br i1 %t387, label %bb75, label %bb76
bb75:
  %t388 = load ptr, ptr %l11, !tbaa !29
  %t390 = getelementptr { i64, [8 x i64] }, ptr %t388, i32 0, i32 1
  %t391 = getelementptr { %"compiler/source:Span", ptr }, ptr %t390, i32 0, i32 1
  %t392 = load ptr, ptr %t391
  store ptr %t392, ptr %l25, !tbaa !29
  br label %bb77
bb76:
  br label %bb84
bb77:
  %t394 = load ptr, ptr %l0, !tbaa !29
  store ptr %t394, ptr %l199, !tbaa !29
  %t395 = load i64, ptr %l1, !tbaa !24
  store i64 %t395, ptr %l200, !tbaa !24
  %t396 = load ptr, ptr %l25, !tbaa !29
  store ptr %t396, ptr %l201, !tbaa !29
  %t397 = load ptr, ptr %l25, !tbaa !29
  store ptr %t397, ptr %l202, !tbaa !29
  %t398 = load i1, ptr %l3, !tbaa !21
  store i1 %t398, ptr %l203, !tbaa !21
  %t399 = load i1, ptr %l4, !tbaa !21
  store i1 %t399, ptr %l204, !tbaa !21
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = getelementptr %"compiler/generic:Program", ptr %t403, i32 0, i32 0
  %t406 = load ptr, ptr %t405, !tbaa !29
  store ptr %t406, ptr %l207, !tbaa !29
  %t407 = load i64, ptr %l1, !tbaa !24
  store i64 %t407, ptr %l208, !tbaa !24
  %t408 = load ptr, ptr %l25, !tbaa !29
  %t410 = getelementptr %"compiler/ast:TopIf", ptr %t408, i32 0, i32 0
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t413 = icmp eq ptr %t411, null
  br i1 %t413, label %bb78, label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_c6f64016a09fc530_b8b2abed7e41fd2c)
  unreachable
bb79:
  br label %bb80
bb80:
  %t415 = load ptr, ptr %l25, !tbaa !29
  %t417 = getelementptr %"compiler/ast:TopIf", ptr %t415, i32 0, i32 0
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t420 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t418)
  store %"compiler/source:Span" %t420, ptr %l214
  br label %bb81
bb81:
  %t421 = getelementptr %"compiler/source:Span", ptr %l214, i32 0, i32 0
  %t422 = load i32, ptr %t421, !tbaa !23
  %t423 = load ptr, ptr %l207, !tbaa !29
  %t424 = load i64, ptr %l208, !tbaa !24
  %t426 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t423, i64 %t424, i32 %t422)
  store i64 %t426, ptr %l216
  br label %bb82
bb82:
  %t427 = load ptr, ptr %l5, !tbaa !29
  %t428 = load ptr, ptr %l199, !tbaa !29
  %t429 = load i64, ptr %l200, !tbaa !24
  %t430 = load ptr, ptr %l201, !tbaa !29
  %t431 = load ptr, ptr %l202, !tbaa !29
  %t432 = load i1, ptr %l203, !tbaa !21
  %t433 = load i1, ptr %l204, !tbaa !21
  %t434 = load i64, ptr %l216, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIf(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t428, i64 %t429, ptr %t430, ptr %t431, i1 %t432, i1 %t433, i64 %t434, i64 0, ptr %t427)
  br label %bb83
bb83:
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_37fb0db160a44e56_e10956c528b68142)
  unreachable
bb89:
  br label %bb90
bb90:
  %t436 = load i64, ptr %l9, !tbaa !24
  %t439 = add i64 %t436, 1
  store i64 %t439, ptr %l9, !tbaa !24
  br label %bb5
bb91:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evariadicArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %lp4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l27 = alloca i1
  %l32 = alloca i1
  %l37 = alloca ptr
  %l39 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l71 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca ptr
  %l90 = alloca ptr
  %l96 = alloca i32
  %l100 = alloca i1
  %l103 = alloca i1
  %l105 = alloca i1
  %l110 = alloca i32
  %l112 = alloca i32
  %l118 = alloca i32
  %l125 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l132 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l138 = alloca i32
  %l140 = alloca ptr
  %l143 = alloca i64
  %l149 = alloca i64
  %l152 = alloca i64
  %l174 = alloca ptr
  %l175 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca i32
  %l182 = alloca { i64, ptr }
  %l185 = alloca %"compiler/source:Span"
  %l186 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l195 = alloca i1
  %l197 = alloca ptr
  %l199 = alloca ptr
  %l200 = alloca { i64, ptr }
  %l203 = alloca %"compiler/source:Span"
  %l205 = alloca i1
  %l214 = alloca ptr
  %l215 = alloca i32
  %l218 = alloca ptr
  %l220 = alloca i32
  %l223 = alloca i32
  %l224 = alloca i32
  %l225 = alloca %"compiler/source:Span"
  %l226 = alloca i32
  %l227 = alloca i32
  %l231 = alloca { i64, ptr }
  %l235 = alloca i32
  %l237 = alloca %"compiler/typed:Make"
  %rv = alloca ptr
  %t449 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l3, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l32
  br label %bb3
bb2:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb4
bb3:
  %t17 = load i1, ptr %l32, !tbaa !21
  store i1 %t17, ptr %l27, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l27, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  %t21 = load i32, ptr %l3, !tbaa !23
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayLit(ptr %v0, ptr %v1, ptr %v2, ptr %t19, %"compiler/source:Span" %t20, i32 %t21, { i64, ptr } %t22, i1 false)
  store ptr %t27, ptr %l37
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t28 = load ptr, ptr %l37, !tbaa !29
  store ptr %t28, ptr %rv
  br label %ret
bb8:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l39, !tbaa !24
  %t32 = load i64, ptr %l39, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load i64, ptr %l39, !tbaa !24
  %t36 = icmp sle i64 %t35, 1152921504606846975
  br i1 %t36, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e10237a768a7da34_a1fa84f4f434b2e0)
  unreachable
bb11:
  %t38 = load i64, ptr %l39, !tbaa !24
  %t39 = mul i64 %t38, 8
  %t40 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t43 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t43, ptr %lp4
  %t45 = load ptr, ptr %lp4
  store { i64, ptr } %t42, ptr %t45, !tbaa !27
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t46, ptr %l5, !tbaa !23
  store i64 0, ptr %l6, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = icmp sgt i64 %t52, %t53
  br i1 %t56, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e10237a768a7da34_a1fa84f4f434b2e0)
  unreachable
bb13:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp sgt i64 %t58, 0
  br i1 %t60, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb18
bb15:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = add i64 %t66, %t67
  %t72 = sub i64 %t70, 1
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = sdiv i64 %t72, %t73
  store i64 %t76, ptr %l52, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb17
bb17:
  %t78 = load i64, ptr %l52, !tbaa !24
  store i64 %t78, ptr %l49, !tbaa !24
  br label %bb18
bb18:
  %t79 = load i64, ptr %l49, !tbaa !24
  store i64 %t79, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t80 = load i64, ptr %l10, !tbaa !24
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb20, label %bb21
bb20:
  br label %bb47
bb21:
  br label %bb22
bb22:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = mul i64 %t89, %t90
  %t96 = add i64 %t88, %t93
  store i64 %t96, ptr %l11, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t99, ptr %l71, !tbaa !27
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 %t100
  %t105 = load ptr, ptr %t104, !tbaa !39
  %t108 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t98, ptr %t105)
  store i1 %t108, ptr %l74
  br label %bb23
bb23:
  %t109 = load i1, ptr %l74, !tbaa !21
  br i1 %t109, label %bb24, label %bb25
bb24:
  br label %bb46
bb25:
  br label %bb26
bb26:
  %t110 = load i64, ptr %l11, !tbaa !24
  store i64 %t110, ptr %l75, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l76, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t113, ptr %l78, !tbaa !27
  %t114 = load i64, ptr %l11, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr ptr, ptr %t117, i64 %t114
  %t119 = load ptr, ptr %t118, !tbaa !39
  %t121 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t112, ptr %t119, i32 %t121)
  store ptr %t125, ptr %l83
  br label %bb27
bb27:
  %t126 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t126, ptr %l84, !tbaa !27
  %t127 = load i64, ptr %l11, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t127
  %t132 = load ptr, ptr %t131, !tbaa !39
  %t134 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t132)
  store %"compiler/source:Span" %t134, ptr %l87
  br label %bb28
bb28:
  %t135 = load ptr, ptr %l76, !tbaa !29
  %t136 = load ptr, ptr %l83, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l87
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v2, ptr %t135, ptr %t136, %"compiler/source:Span" %t137)
  store ptr %t138, ptr %l88
  br label %bb29
bb29:
  %t139 = load ptr, ptr %l88, !tbaa !29
  %t141 = load ptr, ptr %lp4
  %t142 = load i64, ptr %l75, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr ptr, ptr %t144, i64 %t142
  store ptr %t139, ptr %t145, !tbaa !39
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l90, !tbaa !29
  %t147 = load i64, ptr %l11, !tbaa !24
  %t148 = load ptr, ptr %lp4
  %t150 = getelementptr { i64, ptr }, ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr ptr, ptr %t151, i64 %t147
  %t153 = load ptr, ptr %t152, !tbaa !39
  store ptr %t153, ptr %l12, !tbaa !29
  %t155 = load ptr, ptr %l12, !tbaa !29
  %t157 = icmp eq ptr %t155, null
  br i1 %t157, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_a69c1b36a006a603_82104839c45e26c7)
  unreachable
bb31:
  br label %bb32
bb32:
  %t159 = load ptr, ptr %l12, !tbaa !29
  %t160 = load ptr, ptr %l90, !tbaa !29
  %t162 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v2, ptr %t160, ptr %t159)
  store i32 %t162, ptr %l96
  br label %bb33
bb33:
  %t163 = load i32, ptr %l96, !tbaa !23
  store i32 %t163, ptr %l13, !tbaa !23
  %t164 = load i32, ptr %l5, !tbaa !23
  %t165 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t168 = icmp eq i32 %t164, %t165
  br i1 %t168, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb37
bb35:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l13, !tbaa !23
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t174, ptr %l103
  br label %bb36
bb36:
  %t175 = load i1, ptr %l103, !tbaa !21
  %t176 = xor i1 %t175, true
  store i1 %t176, ptr %l100, !tbaa !21
  br label %bb37
bb37:
  %t178 = load i1, ptr %l100, !tbaa !21
  br i1 %t178, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb41
bb39:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t183 = load i32, ptr %l5, !tbaa !23
  %t184 = load i32, ptr %l13, !tbaa !23
  %t188 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t182, i32 %t183, i32 %t184)
  store i32 %t188, ptr %l110
  br label %bb40
bb40:
  %t189 = load i32, ptr %l110, !tbaa !23
  %t190 = icmp slt i32 %t189, 0
  store i1 %t190, ptr %l105, !tbaa !21
  br label %bb41
bb41:
  %t192 = load i1, ptr %l105, !tbaa !21
  br i1 %t192, label %bb42, label %bb43
bb42:
  %t193 = load i32, ptr %l13, !tbaa !23
  store i32 %t193, ptr %l112, !tbaa !23
  br label %bb45
bb43:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t199 = load i32, ptr %l5, !tbaa !23
  %t200 = load i32, ptr %l13, !tbaa !23
  %t204 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t198, i32 %t199, i32 %t200)
  store i32 %t204, ptr %l118
  br label %bb44
bb44:
  %t205 = load i32, ptr %l118, !tbaa !23
  store i32 %t205, ptr %l112, !tbaa !23
  br label %bb45
bb45:
  %t206 = load i32, ptr %l112, !tbaa !23
  store i32 %t206, ptr %l5, !tbaa !23
  br label %bb46
bb46:
  %t207 = load i64, ptr %l10, !tbaa !24
  %t210 = add i64 %t207, 1
  store i64 %t210, ptr %l10, !tbaa !24
  br label %bb19
bb47:
  %t212 = load i32, ptr %l5, !tbaa !23
  %t213 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t216 = icmp eq i32 %t212, %t213
  br i1 %t216, label %bb48, label %bb49
bb48:
  %t218 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t222 = icmp sgt i64 %t220, 0
  store i1 %t222, ptr %l125, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb50
bb50:
  %t224 = load i1, ptr %l125, !tbaa !21
  br i1 %t224, label %bb51, label %bb52
bb51:
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l129, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t226, ptr %l130
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t228, ptr %l132, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr ptr, ptr %t230, i64 0
  %t232 = load ptr, ptr %t231, !tbaa !39
  %t234 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t238 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t227, ptr %t232, i32 %t234)
  store ptr %t238, ptr %l136
  br label %bb53
bb52:
  br label %bb56
bb53:
  %t239 = load ptr, ptr %l136, !tbaa !29
  %t241 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t239)
  store i32 %t241, ptr %l138
  br label %bb54
bb54:
  %t242 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t243 = load ptr, ptr %l129, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l130
  %t245 = load i32, ptr %l138, !tbaa !23
  %t247 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayLit(ptr %v0, ptr %v1, ptr %v2, ptr %t243, %"compiler/source:Span" %t244, i32 %t245, { i64, ptr } %t242, i1 false)
  store ptr %t247, ptr %l140
  br label %bb55
bb55:
  %t248 = load ptr, ptr %l140, !tbaa !29
  store ptr %t248, ptr %rv
  br label %ret
bb56:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/check:Checker", ptr %t249, i32 0, i32 47
  %t253 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t251)
  store i64 %t253, ptr %l143
  br label %bb57
bb57:
  %t254 = load i64, ptr %l143, !tbaa !24
  store i64 %t254, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t255 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t255, 0
  store i64 %t257, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t259 = load i64, ptr %l16, !tbaa !24
  %t260 = load i64, ptr %l15, !tbaa !24
  %t263 = icmp sgt i64 %t259, %t260
  br i1 %t263, label %bb58, label %bb59
bb58:
  %t265 = load i64, ptr %l17, !tbaa !24
  %t267 = icmp sgt i64 %t265, 0
  br i1 %t267, label %bb60, label %bb61
bb59:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb63
bb60:
  %t269 = load i64, ptr %l16, !tbaa !24
  %t270 = load i64, ptr %l15, !tbaa !24
  %t273 = sub i64 %t269, %t270
  %t274 = load i64, ptr %l17, !tbaa !24
  %t277 = add i64 %t273, %t274
  %t279 = sub i64 %t277, 1
  %t280 = load i64, ptr %l17, !tbaa !24
  %t283 = sdiv i64 %t279, %t280
  store i64 %t283, ptr %l152, !tbaa !24
  br label %bb62
bb61:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb62
bb62:
  %t285 = load i64, ptr %l152, !tbaa !24
  store i64 %t285, ptr %l149, !tbaa !24
  br label %bb63
bb63:
  %t286 = load i64, ptr %l149, !tbaa !24
  store i64 %t286, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb64
bb64:
  %t287 = load i64, ptr %l19, !tbaa !24
  %t288 = load i64, ptr %l18, !tbaa !24
  %t291 = icmp slt i64 %t287, %t288
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb65, label %bb66
bb65:
  br label %bb85
bb66:
  br label %bb67
bb67:
  %t295 = load i64, ptr %l15, !tbaa !24
  %t296 = load i64, ptr %l19, !tbaa !24
  %t297 = load i64, ptr %l17, !tbaa !24
  %t300 = mul i64 %t296, %t297
  %t303 = add i64 %t295, %t300
  store i64 %t303, ptr %l20, !tbaa !24
  %t305 = load i64, ptr %l20, !tbaa !24
  %t306 = load ptr, ptr %lp4
  %t308 = getelementptr { i64, ptr }, ptr %t306, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr ptr, ptr %t309, i64 %t305
  %t311 = load ptr, ptr %t310, !tbaa !39
  %t313 = icmp eq ptr %t311, null
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb68, label %bb69
bb68:
  %t317 = load ptr, ptr %l0, !tbaa !29
  store ptr %t317, ptr %l175, !tbaa !29
  %t318 = load i64, ptr %l20, !tbaa !24
  %t319 = load ptr, ptr %lp4
  %t321 = getelementptr { i64, ptr }, ptr %t319, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr ptr, ptr %t322, i64 %t318
  %t324 = load ptr, ptr %t323, !tbaa !39
  store ptr %t324, ptr %l21, !tbaa !29
  %t326 = load ptr, ptr %l21, !tbaa !29
  %t328 = icmp eq ptr %t326, null
  br i1 %t328, label %bb70, label %bb71
bb69:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t331, ptr %l188, !tbaa !27
  %t332 = load i64, ptr %l20, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr ptr, ptr %t335, i64 %t332
  %t337 = load ptr, ptr %t336, !tbaa !39
  %t338 = load i32, ptr %l5, !tbaa !23
  %t342 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t330, ptr %t337, i32 %t338)
  store ptr %t342, ptr %l192
  br label %bb75
bb70:
  call void @__olang_check_failed(ptr @olang_loc_ddfcf2b97caa4282_7a2ed02469d97696)
  unreachable
bb71:
  br label %bb72
bb72:
  %t343 = load ptr, ptr %l21, !tbaa !29
  store ptr %t343, ptr %l180, !tbaa !29
  %t344 = load i32, ptr %l5, !tbaa !23
  store i32 %t344, ptr %l181, !tbaa !23
  %t345 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t345, ptr %l182, !tbaa !27
  %t346 = load i64, ptr %l20, !tbaa !24
  %t348 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr ptr, ptr %t349, i64 %t346
  %t351 = load ptr, ptr %t350, !tbaa !39
  %t353 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t351)
  store %"compiler/source:Span" %t353, ptr %l185
  br label %bb73
bb73:
  %t354 = load ptr, ptr %l175, !tbaa !29
  %t355 = load ptr, ptr %l180, !tbaa !29
  %t356 = load i32, ptr %l181, !tbaa !23
  %t357 = load %"compiler/source:Span", ptr %l185
  %t358 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t354, ptr %t355, i32 %t356, %"compiler/source:Span" %t357)
  store ptr %t358, ptr %l186
  br label %bb74
bb74:
  %t359 = load ptr, ptr %l186, !tbaa !29
  store ptr %t359, ptr %l174, !tbaa !29
  br label %bb76
bb75:
  %t360 = load ptr, ptr %l192, !tbaa !29
  store ptr %t360, ptr %l174, !tbaa !29
  br label %bb76
bb76:
  %t361 = load ptr, ptr %l174, !tbaa !29
  store ptr %t361, ptr %l22, !tbaa !29
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load i32, ptr %l5, !tbaa !23
  %t366 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t362, i32 %t363)
  store i1 %t366, ptr %l195
  br label %bb77
bb77:
  %t367 = load i1, ptr %l195, !tbaa !21
  %t368 = xor i1 %t367, true
  br i1 %t368, label %bb78, label %bb79
bb78:
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l197, !tbaa !29
  %t371 = load ptr, ptr %l22, !tbaa !29
  store ptr %t371, ptr %l199, !tbaa !29
  %t373 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t373, ptr %l200, !tbaa !27
  %t374 = load i64, ptr %l20, !tbaa !24
  %t376 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr ptr, ptr %t377, i64 %t374
  %t379 = load ptr, ptr %t378, !tbaa !39
  %t381 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t379)
  store %"compiler/source:Span" %t381, ptr %l203
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t382 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t383 = load ptr, ptr %l197, !tbaa !29
  %t384 = load ptr, ptr %l199, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l203
  %t387 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t383, ptr %t384, %"compiler/source:Span" %t385, i64 %t382)
  store i1 %t387, ptr %l205
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 47
  %t391 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t390, ptr %t391)
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t394 = load i64, ptr %l19, !tbaa !24
  %t397 = add i64 %t394, 1
  store i64 %t397, ptr %l19, !tbaa !24
  br label %bb64
bb85:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/check:Checker", ptr %t399, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !29
  %t404 = getelementptr %"compiler/generic:Program", ptr %t402, i32 0, i32 2
  store ptr %t404, ptr %l214, !tbaa !29
  %t405 = load i32, ptr %l5, !tbaa !23
  store i32 %t405, ptr %l215, !tbaa !23
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/check:Checker", ptr %t406, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = getelementptr %"compiler/generic:Program", ptr %t409, i32 0, i32 2
  store ptr %t411, ptr %l218, !tbaa !29
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t412)
  store i32 %t414, ptr %l220
  br label %bb86
bb86:
  %t415 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t415, 0
  %t418 = load ptr, ptr %l218, !tbaa !29
  %t419 = load i32, ptr %l220, !tbaa !23
  %t421 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t418, i32 %t419, i64 %t417)
  store i32 %t421, ptr %l223
  br label %bb87
bb87:
  %t422 = load ptr, ptr %l214, !tbaa !29
  %t423 = load i32, ptr %l215, !tbaa !23
  %t424 = load i32, ptr %l223, !tbaa !23
  %t425 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t422, i32 %t423, i32 %t424)
  store i32 %t425, ptr %l224
  br label %bb88
bb88:
  %t426 = load i32, ptr %l224, !tbaa !23
  %t427 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t427, ptr %l225
  store i32 %t426, ptr %l226, !tbaa !23
  store i32 2, ptr %l227
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/check:Checker", ptr %t429, i32 0, i32 47
  %t432 = load i64, ptr %l14, !tbaa !24
  %t435 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t431, i64 %t432)
  store { i64, ptr } %t435, ptr %l231
  br label %bb89
bb89:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load %"compiler/source:Span", ptr %l1
  %t441 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t436, i32 1, %"compiler/source:Span" %t437)
  store i32 %t441, ptr %l235
  br label %bb90
bb90:
  %t442 = load i32, ptr %l227, !range !{i32 0, i32 5}
  %t443 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t444 = load i32, ptr %l235, !tbaa !23
  %t446 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v2, ptr %v2, i32 %t442, i64 0, { i64, ptr } %t443, ptr null, i32 %t444, i32 0, i1 false)
  store %"compiler/typed:Make" %t446, ptr %l237
  br label %bb91
bb91:
  %t447 = load %"compiler/typed:Make", ptr %l237
  %t448 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t447, ptr %t448
  store { i64, [5 x i64] } zeroinitializer, ptr %t449
  %t450 = getelementptr { i64, [5 x i64] }, ptr %t449, i32 0, i32 0
  store i64 7, ptr %t450
  %t451 = load %"compiler/source:Span", ptr %l225
  %t452 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t451, 0
  %t453 = load i32, ptr %l226, !tbaa !23
  %t454 = insertvalue { %"compiler/source:Span", i32, ptr } %t452, i32 %t453, 1
  %t456 = insertvalue { %"compiler/source:Span", i32, ptr } %t454, ptr %t448, 2
  %t457 = getelementptr { i64, [5 x i64] }, ptr %t449, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t456, ptr %t457
  %t458 = load { i64, [5 x i64] }, ptr %t449
  %t460 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t458, ptr %t460
  store ptr %t460, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %lp11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca { i64, [3 x i64] }
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i64
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca i64
  %l53 = alloca ptr
  %l56 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca i1
  %l66 = alloca i64
  %l70 = alloca i32
  %l74 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l93 = alloca i32
  %l94 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l117 = alloca i64
  %l120 = alloca ptr
  %l133 = alloca i64
  %l136 = alloca i64
  %l157 = alloca i1
  %l162 = alloca i1
  %l163 = alloca { i64, ptr }
  %l174 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l182 = alloca ptr
  %l187 = alloca i32
  %l188 = alloca i64
  %l189 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l194 = alloca { i64, [3 x i64] }
  %l195 = alloca i64
  %l197 = alloca ptr
  %l201 = alloca { i64, ptr }
  %l204 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l210 = alloca ptr
  %l223 = alloca ptr
  %l226 = alloca i1
  %l227 = alloca i1
  %l230 = alloca i1
  %l235 = alloca i32
  %l241 = alloca ptr
  %l246 = alloca i32
  %l247 = alloca { i64, ptr }
  %l254 = alloca { i64, ptr }
  %l259 = alloca i1
  %l260 = alloca ptr
  %l261 = alloca %"compiler/source:Span"
  %l264 = alloca { i64, ptr }
  %l265 = alloca { i64, ptr }
  %l266 = alloca ptr
  %l271 = alloca i32
  %l272 = alloca { i64, ptr }
  %l274 = alloca %"compiler/diagmsg:Msg"
  %l275 = alloca i64
  %l280 = alloca ptr
  %l288 = alloca ptr
  %l295 = alloca i1
  %l298 = alloca i64
  %l301 = alloca ptr
  %l304 = alloca ptr
  %l308 = alloca i32
  %l309 = alloca i32
  %l310 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l313 = alloca ptr
  %l314 = alloca %"compiler/source:Span"
  %l315 = alloca i32
  %l316 = alloca i64
  %l317 = alloca ptr
  %l321 = alloca ptr
  %l322 = alloca { i64, ptr }
  %l323 = alloca ptr
  %l327 = alloca ptr
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t203 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l32
  br label %bb1
bb1:
  %t6 = load i1, ptr %l32, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l33, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l34
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t9, i32 %t10)
  store { i64, ptr } %t13, ptr %l37
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t14 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t14, ptr %l38, !tbaa !27
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l39, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l44
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l39, !tbaa !29
  %t27 = load i32, ptr %l44, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l45
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t32 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoZeroNonNull(ptr %s1, ptr %s1, ptr %v0, { i64, ptr } %t30, { i64, ptr } %t29)
  store %"compiler/diagmsg:Msg" %t32, ptr %l47
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l33, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l34
  %t35 = load %"compiler/diagmsg:Msg", ptr %l47
  %t36 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t33, %"compiler/source:Span" %t34, %"compiler/diagmsg:Msg" %t35)
  store i64 %t36, ptr %l48
  br label %bb8
bb8:
  %t37 = load i64, ptr %l48, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %t38, i64 %t37)
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t42, %"compiler/source:Span" %t43)
  store ptr %t46, ptr %l53
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  %t47 = load ptr, ptr %l53, !tbaa !29
  store ptr %t47, ptr %rv
  br label %ret
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l2, !tbaa !23
  %t52 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullableArray(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l56
  br label %bb12
bb12:
  %t53 = load i1, ptr %l56, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t56 = load i32, ptr %l2, !tbaa !23
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %t54, %"compiler/source:Span" %t55, i32 %t56)
  store ptr %t60, ptr %l60
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t61 = load ptr, ptr %l60, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l63
  br label %bb17
bb17:
  %t67 = load i1, ptr %l63, !tbaa !21
  br i1 %t67, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t72, ptr %l66
  br label %bb20
bb19:
  br label %bb92
bb20:
  %t73 = load i64, ptr %l66, !tbaa !24
  store i64 %t73, ptr %l4, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = load i32, ptr %l2, !tbaa !23
  %t81 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t81, ptr %l70
  br label %bb21
bb21:
  %t82 = load i32, ptr %l70, !tbaa !23
  store i32 %t82, ptr %l5, !tbaa !23
  %t83 = load i32, ptr %l5, !tbaa !23
  %t84 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t87 = icmp ne i32 %t83, %t84
  br i1 %t87, label %bb22, label %bb23
bb22:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  store ptr %t94, ptr %l77, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 2
  %t101 = load i32, ptr %l5, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l82
  br label %bb24
bb23:
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb26, label %bb27
bb24:
  %t107 = load ptr, ptr %l77, !tbaa !29
  %t108 = load i32, ptr %l82, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t107, i32 %t108)
  store { i64, ptr } %t109, ptr %l83
  br label %bb25
bb25:
  %t110 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t110, ptr %l74, !tbaa !27
  br label %bb30
bb26:
  %t111 = icmp sle i64 0, 2305843009213693951
  br i1 %t111, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_39114b2b59f3c1de_f97787d703923df2)
  unreachable
bb28:
  %t113 = mul i64 0, 4
  %t114 = insertvalue { i64, ptr } undef, i64 0, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t115, ptr %l74, !tbaa !27
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_39114b2b59f3c1de_f97787d703923df2)
  unreachable
bb30:
  %t117 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t117, ptr %l6, !tbaa !27
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  store ptr %t121, ptr %l88, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l2, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l93
  br label %bb31
bb31:
  %t132 = load ptr, ptr %l88, !tbaa !29
  %t133 = load i32, ptr %l93, !tbaa !23
  %t134 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t132, i32 %t133)
  store ptr %t134, ptr %l94
  br label %bb32
bb32:
  %t135 = load ptr, ptr %l94, !tbaa !29
  store ptr %t135, ptr %l7, !tbaa !29
  %t136 = icmp sge i64 0, 0
  br i1 %t136, label %bb33, label %bb34
bb33:
  %t138 = icmp sle i64 0, 1152921504606846975
  br i1 %t138, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_bfa34a8929429713_51639094391671e7)
  unreachable
bb35:
  %t140 = mul i64 0, 8
  %t141 = insertvalue { i64, ptr } undef, i64 0, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t142, ptr %l8, !tbaa !27
  %t144 = load ptr, ptr %l7, !tbaa !29
  %t146 = icmp eq ptr %t144, null
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_bfa34a8929429713_51639094391671e7)
  unreachable
bb37:
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t152 = getelementptr %"compiler/ast:TypeDecl", ptr %t150, i32 0, i32 3
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = icmp eq ptr %t153, null
  %t157 = xor i1 %t155, true
  store i1 %t157, ptr %l101, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb39
bb39:
  %t159 = load i1, ptr %l101, !tbaa !21
  br i1 %t159, label %bb40, label %bb41
bb40:
  %t160 = load ptr, ptr %l7, !tbaa !29
  %t162 = getelementptr %"compiler/ast:TypeDecl", ptr %t160, i32 0, i32 3
  %t163 = load ptr, ptr %t162, !tbaa !29
  store ptr %t163, ptr %l9, !tbaa !29
  %t165 = load ptr, ptr %l9, !tbaa !29
  store ptr %t165, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t166 = load ptr, ptr %l108, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb42, label %bb43
bb41:
  br label %bb53
bb42:
  %t169 = load ptr, ptr %l108, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 5}
  %t172 = icmp eq i64 %t170, 0
  store i1 %t172, ptr %l109, !tbaa !21
  br label %bb43
bb43:
  %t173 = load i1, ptr %l109, !tbaa !21
  br i1 %t173, label %bb44, label %bb45
bb44:
  %t174 = load ptr, ptr %l9, !tbaa !29
  %t176 = getelementptr { i64, [6 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { ptr }, ptr %t176, i32 0, i32 0
  %t178 = load ptr, ptr %t177
  store ptr %t178, ptr %l10, !tbaa !29
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t180 = load ptr, ptr %l10, !tbaa !29
  %t182 = getelementptr %"compiler/ast:StructBody", ptr %t180, i32 0, i32 0
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l8, !tbaa !27
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_37a2617a6fdca52f_9113ce984ee2ba6b)
  unreachable
bb52:
  br label %bb53
bb53:
  %t185 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t185, 0
  store i64 %t187, ptr %l117, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load %"compiler/source:Span", ptr %l1
  %t192 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v1, ptr %t188, %"compiler/source:Span" %t189)
  store ptr %t192, ptr %l120
  br label %bb54
bb54:
  %t193 = load i64, ptr %l117, !tbaa !24
  %t194 = icmp sge i64 %t193, 0
  br i1 %t194, label %bb55, label %bb56
bb55:
  %t196 = load i64, ptr %l117, !tbaa !24
  %t197 = icmp sle i64 %t196, 1152921504606846975
  br i1 %t197, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_cffeba9c7beed71d_692ce8f7e2902011)
  unreachable
bb57:
  %t199 = load i64, ptr %l117, !tbaa !24
  %t200 = mul i64 %t199, 8
  %t201 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t200)
  %t202 = load ptr, ptr %l120, !tbaa !29
  store i64 0, ptr %t203
  br label %fill.204
fill.204:
  %t207 = load i64, ptr %t203
  %t208 = icmp slt i64 %t207, %t199
  br i1 %t208, label %fillb.205, label %filld.206
fillb.205:
  %t209 = getelementptr ptr, ptr %t201, i64 %t207
  store ptr %t202, ptr %t209
  %t210 = add i64 %t207, 1
  store i64 %t210, ptr %t203
  br label %fill.204
filld.206:
  %t211 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t201, 1
  %t213 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t213, ptr %lp11
  %t215 = load ptr, ptr %lp11
  store { i64, ptr } %t212, ptr %t215, !tbaa !27
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 29
  %t219 = load i32, ptr %t218, !tbaa !23
  store i32 %t219, ptr %l12, !tbaa !23
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l2, !tbaa !23
  %t225 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 29
  store i32 %t222, ptr %t225, !tbaa !23
  store i64 0, ptr %l13, !tbaa !24
  %t226 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t226, 0
  store i64 %t228, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t230 = load i64, ptr %l14, !tbaa !24
  %t231 = load i64, ptr %l13, !tbaa !24
  %t234 = icmp sgt i64 %t230, %t231
  br i1 %t234, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_cffeba9c7beed71d_692ce8f7e2902011)
  unreachable
bb59:
  %t236 = load i64, ptr %l15, !tbaa !24
  %t238 = icmp sgt i64 %t236, 0
  br i1 %t238, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb64
bb61:
  %t240 = load i64, ptr %l14, !tbaa !24
  %t241 = load i64, ptr %l13, !tbaa !24
  %t244 = sub i64 %t240, %t241
  %t245 = load i64, ptr %l15, !tbaa !24
  %t248 = add i64 %t244, %t245
  %t250 = sub i64 %t248, 1
  %t251 = load i64, ptr %l15, !tbaa !24
  %t254 = sdiv i64 %t250, %t251
  store i64 %t254, ptr %l136, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb63
bb63:
  %t256 = load i64, ptr %l136, !tbaa !24
  store i64 %t256, ptr %l133, !tbaa !24
  br label %bb64
bb64:
  %t257 = load i64, ptr %l133, !tbaa !24
  store i64 %t257, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb65
bb65:
  %t258 = load i64, ptr %l17, !tbaa !24
  %t259 = load i64, ptr %l16, !tbaa !24
  %t262 = icmp slt i64 %t258, %t259
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb66, label %bb67
bb66:
  br label %bb90
bb67:
  br label %bb68
bb68:
  %t266 = load i64, ptr %l13, !tbaa !24
  %t267 = load i64, ptr %l17, !tbaa !24
  %t268 = load i64, ptr %l15, !tbaa !24
  %t271 = mul i64 %t267, %t268
  %t274 = add i64 %t266, %t271
  store i64 %t274, ptr %l18, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t280 = icmp sgt i64 %t278, 0
  br i1 %t280, label %bb69, label %bb70
bb69:
  %t282 = load i64, ptr %l18, !tbaa !24
  %t283 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t288 = icmp slt i64 %t282, %t285
  store i1 %t288, ptr %l157, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb71
bb71:
  %t290 = load i1, ptr %l157, !tbaa !21
  br i1 %t290, label %bb72, label %bb73
bb72:
  %t291 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t291, ptr %l163, !tbaa !27
  %t292 = load i64, ptr %l18, !tbaa !24
  %t294 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr ptr, ptr %t295, i64 %t292
  %t297 = load ptr, ptr %t296, !tbaa !39
  %t299 = getelementptr %"compiler/ast:Param", ptr %t297, i32 0, i32 3
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t302 = icmp eq ptr %t300, null
  %t304 = xor i1 %t302, true
  store i1 %t304, ptr %l162, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb74
bb74:
  %t306 = load i1, ptr %l162, !tbaa !21
  store i1 %t306, ptr %l19, !tbaa !21
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 18
  %t310 = load { i64, [3 x i64] }, ptr %t309
  store { i64, [3 x i64] } %t310, ptr %l20
  %t312 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t312, 0
  %t316 = icmp sgt i64 %t314, 0
  br i1 %t316, label %bb75, label %bb76
bb75:
  %t318 = load i64, ptr %l18, !tbaa !24
  %t319 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t324 = icmp slt i64 %t318, %t321
  store i1 %t324, ptr %l174, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb77
bb77:
  %t326 = load i1, ptr %l174, !tbaa !21
  br i1 %t326, label %bb78, label %bb79
bb78:
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l179, !tbaa !29
  %t328 = load ptr, ptr %l0, !tbaa !29
  store ptr %t328, ptr %l180, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/check:Checker", ptr %t329, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !29
  store ptr %t332, ptr %l182, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = getelementptr %"compiler/check:Checker", ptr %t333, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !29
  %t338 = getelementptr %"compiler/generic:Program", ptr %t336, i32 0, i32 2
  %t339 = load i32, ptr %l2, !tbaa !23
  %t342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t338, i32 %t339)
  store i32 %t342, ptr %l187
  br label %bb80
bb79:
  br label %bb83
bb80:
  %t343 = load ptr, ptr %l182, !tbaa !29
  %t344 = load i32, ptr %l187, !tbaa !23
  %t345 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t343, i32 %t344)
  store i64 %t345, ptr %l188
  br label %bb81
bb81:
  %t346 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t346, ptr %l189, !tbaa !27
  %t347 = load i64, ptr %l18, !tbaa !24
  %t349 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr ptr, ptr %t350, i64 %t347
  %t352 = load ptr, ptr %t351, !tbaa !39
  %t354 = getelementptr %"compiler/ast:Param", ptr %t352, i32 0, i32 2
  %t355 = load ptr, ptr %t354, !tbaa !29
  store ptr %t355, ptr %l192, !tbaa !29
  %t356 = load ptr, ptr %l192, !tbaa !29
  %t357 = call ptr @__olang_scope_of(ptr %t356, ptr null)
  %t358 = call ptr @__olang_scope_hold(ptr %t357)
  %t359 = ptrtoint ptr %t358 to i64
  %t361 = inttoptr i64 %t359 to ptr
  %t362 = load ptr, ptr %l180, !tbaa !29
  %t363 = load i64, ptr %l188, !tbaa !24
  %t364 = load ptr, ptr %l192, !tbaa !29
  %t365 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %t361, ptr %t362, i64 %t363, ptr %t364)
  store { i64, [3 x i64] } %t365, ptr %l194
  br label %bb82
bb82:
  %t366 = load { i64, [3 x i64] }, ptr %l194
  %t367 = load ptr, ptr %l179, !tbaa !29
  %t368 = getelementptr %"compiler/check:Checker", ptr %t367, i32 0, i32 18
  store { i64, [3 x i64] } %t366, ptr %t368
  br label %bb83
bb83:
  %t369 = load i64, ptr %l18, !tbaa !24
  store i64 %t369, ptr %l195, !tbaa !24
  %t370 = load i1, ptr %l19, !tbaa !21
  br i1 %t370, label %bb84, label %bb85
bb84:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load %"compiler/source:Span", ptr %l1
  %t374 = load i64, ptr %l18, !tbaa !24
  %t375 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t375, ptr %l201, !tbaa !27
  %t376 = load i64, ptr %l18, !tbaa !24
  %t378 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !27
  %t380 = getelementptr i32, ptr %t379, i64 %t376
  %t381 = load i32, ptr %t380, !tbaa !33
  %t386 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %t372, %"compiler/source:Span" %t373, i64 %t374, i32 %t381)
  store ptr %t386, ptr %l204
  br label %bb86
bb85:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load %"compiler/source:Span", ptr %l1
  %t389 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t389, ptr %l207, !tbaa !27
  %t390 = load i64, ptr %l18, !tbaa !24
  %t392 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr i32, ptr %t393, i64 %t390
  %t395 = load i32, ptr %t394, !tbaa !33
  %t399 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %t387, %"compiler/source:Span" %t388, i32 %t395)
  store ptr %t399, ptr %l210
  br label %bb87
bb86:
  %t400 = load ptr, ptr %l204, !tbaa !29
  store ptr %t400, ptr %l197, !tbaa !29
  br label %bb88
bb87:
  %t401 = load ptr, ptr %l210, !tbaa !29
  store ptr %t401, ptr %l197, !tbaa !29
  br label %bb88
bb88:
  %t402 = load ptr, ptr %l197, !tbaa !29
  %t403 = load ptr, ptr %lp11
  %t404 = load i64, ptr %l195, !tbaa !24
  %t405 = getelementptr { i64, ptr }, ptr %t403, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !27
  %t407 = getelementptr ptr, ptr %t406, i64 %t404
  store ptr %t402, ptr %t407, !tbaa !39
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load { i64, [3 x i64] }, ptr %l20
  %t412 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 18
  store { i64, [3 x i64] } %t409, ptr %t412
  br label %bb89
bb89:
  %t413 = load i64, ptr %l17, !tbaa !24
  %t416 = add i64 %t413, 1
  store i64 %t416, ptr %l17, !tbaa !24
  br label %bb65
bb90:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load i32, ptr %l12, !tbaa !23
  %t422 = getelementptr %"compiler/check:Checker", ptr %t418, i32 0, i32 29
  store i32 %t419, ptr %t422, !tbaa !23
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load %"compiler/source:Span", ptr %l1
  %t425 = load i32, ptr %l2, !tbaa !23
  %t426 = load i64, ptr %l4, !tbaa !24
  %t427 = load ptr, ptr %lp11
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  %t434 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v1, ptr %v1, ptr %t423, %"compiler/source:Span" %t424, i32 %t425, i64 %t426, { i64, ptr } %t428, i1 true)
  store ptr %t434, ptr %l223
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s3)
  %t435 = load ptr, ptr %l223, !tbaa !29
  store ptr %t435, ptr %rv
  br label %ret
bb92:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load i32, ptr %l2, !tbaa !23
  %t440 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t436, i32 %t437)
  store i1 %t440, ptr %l226
  br label %bb93
bb93:
  %t441 = load i1, ptr %l226, !tbaa !21
  br i1 %t441, label %bb94, label %bb95
bb94:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load i32, ptr %l2, !tbaa !23
  %t446 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t442, i32 %t443)
  store i1 %t446, ptr %l230
  br label %bb96
bb95:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb97
bb96:
  %t447 = load i1, ptr %l230, !tbaa !21
  %t448 = xor i1 %t447, true
  store i1 %t448, ptr %l227, !tbaa !21
  br label %bb97
bb97:
  %t450 = load i1, ptr %l227, !tbaa !21
  br i1 %t450, label %bb98, label %bb99
bb98:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/check:Checker", ptr %t451, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t455 = load i32, ptr %l2, !tbaa !23
  %t458 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t454, i32 %t455, i64 0)
  store i32 %t458, ptr %l235
  br label %bb100
bb99:
  br label %bb127
bb100:
  %t459 = load i32, ptr %l235, !tbaa !23
  store i32 %t459, ptr %l21, !tbaa !23
  %t460 = load i32, ptr %l21, !tbaa !23
  %t461 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t464 = icmp ne i32 %t460, %t461
  br i1 %t464, label %bb101, label %bb102
bb101:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t468 = getelementptr %"compiler/check:Checker", ptr %t466, i32 0, i32 1
  %t469 = load ptr, ptr %t468, !tbaa !29
  %t471 = getelementptr %"compiler/generic:Program", ptr %t469, i32 0, i32 2
  store ptr %t471, ptr %l241, !tbaa !29
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/check:Checker", ptr %t472, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t477 = getelementptr %"compiler/generic:Program", ptr %t475, i32 0, i32 2
  %t478 = load i32, ptr %l21, !tbaa !23
  %t481 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t477, i32 %t478)
  store i32 %t481, ptr %l246
  br label %bb103
bb102:
  br label %bb126
bb103:
  %t482 = load ptr, ptr %l241, !tbaa !29
  %t483 = load i32, ptr %l246, !tbaa !23
  %t484 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t482, i32 %t483)
  store { i64, ptr } %t484, ptr %l247
  br label %bb104
bb104:
  %t485 = load { i64, ptr }, ptr %l247, !tbaa !27
  store { i64, ptr } %t485, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t486 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t486, 0
  store i64 %t488, ptr %l24, !tbaa !24
  br label %bb105
bb105:
  %t490 = load i64, ptr %l23, !tbaa !24
  %t491 = load i64, ptr %l24, !tbaa !24
  %t494 = icmp slt i64 %t490, %t491
  %t496 = xor i1 %t494, true
  br i1 %t496, label %bb106, label %bb107
bb106:
  br label %bb121
bb107:
  br label %bb108
bb108:
  %t498 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t498, ptr %l254, !tbaa !27
  %t499 = load i64, ptr %l23, !tbaa !24
  %t501 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr i32, ptr %t502, i64 %t499
  %t504 = load i32, ptr %t503, !tbaa !33
  store i32 %t504, ptr %l25, !tbaa !23
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load i32, ptr %l25, !tbaa !23
  %t510 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t506, i32 %t507)
  store i1 %t510, ptr %l259
  br label %bb109
bb109:
  %t511 = load i1, ptr %l259, !tbaa !21
  br i1 %t511, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s15
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l260, !tbaa !29
  %t513 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t513, ptr %l261
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i32, ptr %l25, !tbaa !23
  %t518 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t514, i32 %t515)
  store { i64, ptr } %t518, ptr %l264
  br label %bb112
bb111:
  br label %bb119
bb112:
  %t519 = load { i64, ptr }, ptr %l264, !tbaa !27
  store { i64, ptr } %t519, ptr %l265, !tbaa !27
  %t520 = load ptr, ptr %l0, !tbaa !29
  store ptr %t520, ptr %l266, !tbaa !29
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/check:Checker", ptr %t521, i32 0, i32 1
  %t524 = load ptr, ptr %t523, !tbaa !29
  %t526 = getelementptr %"compiler/generic:Program", ptr %t524, i32 0, i32 2
  %t527 = load i32, ptr %l25, !tbaa !23
  %t530 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t526, i32 %t527)
  store i32 %t530, ptr %l271
  br label %bb113
bb113:
  %t531 = load ptr, ptr %l266, !tbaa !29
  %t532 = load i32, ptr %l271, !tbaa !23
  %t533 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t531, i32 %t532)
  store { i64, ptr } %t533, ptr %l272
  br label %bb114
bb114:
  %t534 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t535 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t537 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoZeroNonNull(ptr %s15, ptr %s15, ptr %v0, { i64, ptr } %t535, { i64, ptr } %t534)
  store %"compiler/diagmsg:Msg" %t537, ptr %l274
  br label %bb115
bb115:
  %t538 = load ptr, ptr %l260, !tbaa !29
  %t539 = load %"compiler/source:Span", ptr %l261
  %t540 = load %"compiler/diagmsg:Msg", ptr %l274
  %t541 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t538, %"compiler/source:Span" %t539, %"compiler/diagmsg:Msg" %t540)
  store i64 %t541, ptr %l275
  br label %bb116
bb116:
  %t542 = load i64, ptr %l275, !tbaa !24
  %t543 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %t543, i64 %t542)
  br label %bb117
bb117:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load %"compiler/source:Span", ptr %l1
  %t551 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t547, %"compiler/source:Span" %t548)
  store ptr %t551, ptr %l280
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s15)
  %t552 = load ptr, ptr %l280, !tbaa !29
  store ptr %t552, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t553 = load i64, ptr %l23, !tbaa !24
  %t556 = add i64 %t553, 1
  store i64 %t556, ptr %l23, !tbaa !24
  br label %bb105
bb121:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load %"compiler/source:Span", ptr %l1
  %t560 = load i32, ptr %l2, !tbaa !23
  %t561 = load i32, ptr %l21, !tbaa !23
  %t566 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseZero(ptr %v0, ptr %v1, ptr %t558, %"compiler/source:Span" %t559, i32 %t560, i32 %t561)
  store ptr %t566, ptr %l288
  br label %bb122
bb122:
  %t567 = load ptr, ptr %l288, !tbaa !29
  store ptr %t567, ptr %l27, !tbaa !29
  %t568 = load ptr, ptr %l27, !tbaa !29
  %t570 = icmp eq ptr %t568, null
  %t572 = xor i1 %t570, true
  br i1 %t572, label %bb123, label %bb124
bb123:
  %t574 = load ptr, ptr %l27, !tbaa !29
  store ptr %t574, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load i32, ptr %l2, !tbaa !23
  %t580 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %t576, i32 %t577)
  store i1 %t580, ptr %l295
  br label %bb128
bb128:
  %t581 = load i1, ptr %l295, !tbaa !21
  br i1 %t581, label %bb129, label %bb130
bb129:
  store %olang.scope zeroinitializer, ptr %s18
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t583 = load i32, ptr %l2, !tbaa !23
  %t586 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t582, i32 %t583)
  store i64 %t586, ptr %l298
  br label %bb131
bb130:
  br label %bb138
bb131:
  %t587 = load i64, ptr %l298, !tbaa !24
  store i64 %t587, ptr %l28, !tbaa !24
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t590 = getelementptr %"compiler/check:Checker", ptr %t588, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !29
  %t593 = getelementptr %"compiler/generic:Program", ptr %t591, i32 0, i32 2
  store ptr %t593, ptr %l301, !tbaa !29
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t596 = getelementptr %"compiler/check:Checker", ptr %t594, i32 0, i32 1
  %t597 = load ptr, ptr %t596, !tbaa !29
  %t599 = getelementptr %"compiler/generic:Program", ptr %t597, i32 0, i32 2
  store ptr %t599, ptr %l304, !tbaa !29
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = getelementptr %"compiler/check:Checker", ptr %t600, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !29
  %t604 = load i32, ptr %l2, !tbaa !23
  %t607 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t603, i32 %t604)
  store i32 %t607, ptr %l308
  br label %bb132
bb132:
  %t608 = load ptr, ptr %l304, !tbaa !29
  %t609 = load i32, ptr %l308, !tbaa !23
  %t610 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t608, i32 %t609)
  store i32 %t610, ptr %l309
  br label %bb133
bb133:
  %t611 = load ptr, ptr %l301, !tbaa !29
  %t612 = load i32, ptr %l309, !tbaa !23
  %t613 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s18, ptr %t611, i32 %t612)
  store { i64, ptr } %t613, ptr %l310
  br label %bb134
bb134:
  %t614 = load { i64, ptr }, ptr %l310, !tbaa !27
  store { i64, ptr } %t614, ptr %l311, !tbaa !27
  %t615 = getelementptr { i64, ptr }, ptr %l311, i32 0, i32 1
  %t616 = load ptr, ptr %t615, !tbaa !27
  %t617 = getelementptr i32, ptr %t616, i64 0
  %t618 = load i32, ptr %t617, !tbaa !33
  %t620 = load ptr, ptr %l0, !tbaa !29
  store ptr %t620, ptr %l313, !tbaa !29
  %t621 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t621, ptr %l314
  %t622 = load i32, ptr %l2, !tbaa !23
  store i32 %t622, ptr %l315, !tbaa !23
  %t623 = load i64, ptr %l28, !tbaa !24
  store i64 %t623, ptr %l316, !tbaa !24
  %t624 = load ptr, ptr %l0, !tbaa !29
  store ptr %t624, ptr %l317, !tbaa !29
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t626 = load %"compiler/source:Span", ptr %l1
  %t631 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t625, %"compiler/source:Span" %t626, i32 %t618)
  store ptr %t631, ptr %l321
  br label %bb135
bb135:
  %t632 = load ptr, ptr %l317, !tbaa !29
  %t633 = load ptr, ptr %l321, !tbaa !29
  %t634 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t632, ptr %t633)
  store { i64, ptr } %t634, ptr %l322
  br label %bb136
bb136:
  %t635 = load ptr, ptr %l313, !tbaa !29
  %t636 = load %"compiler/source:Span", ptr %l314
  %t637 = load i32, ptr %l315, !tbaa !23
  %t638 = load i64, ptr %l316, !tbaa !24
  %t639 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t640 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v0, ptr %v1, ptr %t635, %"compiler/source:Span" %t636, i32 %t637, i64 %t638, { i64, ptr } %t639, i1 true)
  store ptr %t640, ptr %l323
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s18)
  %t641 = load ptr, ptr %l323, !tbaa !29
  store ptr %t641, ptr %rv
  br label %ret
bb138:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load %"compiler/source:Span", ptr %l1
  %t644 = load i32, ptr %l2, !tbaa !23
  %t648 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t642, %"compiler/source:Span" %t643, i32 %t644, i64 0)
  store ptr %t648, ptr %l327
  br label %bb139
bb139:
  %t649 = load ptr, ptr %l327, !tbaa !29
  store ptr %t649, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2eeffectOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t3 = trunc i64 25 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb9
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t8 = trunc i64 26 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t13 = trunc i64 27 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t18 = trunc i64 28 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb21
bb10:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t23 = trunc i64 29 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t28 = trunc i64 41 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d652d3791394a9d9_f08137453595c3ad)
  unreachable
bb21:
  %t31 = load i1, ptr %l1, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2elowerAll(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca i8
  %l24 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store ptr %l1, ptr %l17, !tbaa !29
  %t27 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t23)
  store i8 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load i8, ptr %l19, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t28, i8 %t29)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t30, 1
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb2
bb9:
  %t36 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t36, ptr %l24
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t37, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/check:factsCopy" @compiler_2fcheck_3afactsCopy_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %rv = alloca %"compiler/check:factsCopy"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:factsCopy" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, 0
  %t10 = insertvalue %"compiler/check:factsCopy" %t8, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, 1
  %t12 = insertvalue %"compiler/check:factsCopy" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, 2
  store %"compiler/check:factsCopy" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factsCopy", ptr %rv
  ret %"compiler/check:factsCopy" %rr
}

define dso_local %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/check:roArg"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/check:roArg" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/check:roArg" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/check:roArg" %t16, { i64, [3 x i64] } %a2, 2
  %t20 = insertvalue %"compiler/check:roArg" %t18, { i64, ptr } %a3, 3
  %t22 = insertvalue %"compiler/check:roArg" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/check:roArg" %t22, { i64, ptr } %a5, 5
  store %"compiler/check:roArg" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roArg", ptr %rv
  ret %"compiler/check:roArg" %rr
}

define dso_local %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:roDeepArg"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:roDeepArg" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:roDeepArg" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/check:roDeepArg" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:roDeepArg" %t14, i64 %a3, 3
  store %"compiler/check:roDeepArg" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roDeepArg", ptr %rv
  ret %"compiler/check:roDeepArg" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare ptr @__olang_scope_of(ptr, ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d6 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d7 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d8 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Overflow" }>, align 8
@.d9 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d10 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d11 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Invalid" }>, align 8
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3afactsCopy_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
@olang_2esole_2ecompiler_2fcheck_3afactsCopy_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3afactsCopy_2e2 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2e0 = weak hidden constant i1 false
@.d14 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"LanesEqual" }>, align 8
@.d15 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"LanesLess" }>, align 8
@.d16 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"LanesEqual" }>, align 8
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Select" }>, align 8
@.d18 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'Select'" }>, align 8
@.d19 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'Select'" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3aChecker_2e133 = weak hidden constant i1 false
declare void @__olang_region_drop(ptr) noinline
declare void @__olang_region_release_part(ptr, i64) noinline
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3aroArg_2e4 = weak hidden constant i1 false
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3aroArg_2e5 = weak hidden constant i1 false
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d26 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare void @__olang_errpay_pop()
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\0Atype " }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\0Atype " }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"a store over a value with destructors to run, reached through what a call gives (O15)" }>, align 8
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eendedWhy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:AnySlot" %a1)
declare i1 @compiler_2fcheck_2ehasNamed(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_e1138a3bee8dfd28_1d9c93b07a3bbf3c = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyDefault(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNoCopy(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ecdebd42147a0915_28ece6113815da89 = external constant [0 x i8]
@olang_loc_b35cdd4155941ff6_f61ebbb89c67ebca = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNoMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eNewAnyTable(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteAnyMethod(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/diagmsg:Msg" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H0986089bcad3c266fbd2f46fa03b07d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_94214b31169ec8c4_68c852e51d74cc68 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_d48ba9fb56fa57b5_9836703f13f4bc39 = external constant [0 x i8]
@olang_loc_964ce48e3719b9fe_ecf9d1875d849bc2 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
@olang_loc_fd984862ae15b7b5_96e74f0ca55af519 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFieldHolds(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_656971ecbb067a73_942081a116b7a267 = external constant [0 x i8]
@olang_loc_7e33472f03e5a723_adcfc8d4e22973ef = external constant [0 x i8]
@olang_loc_d27f09f1ed434aae_8d18f82803f9a31a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStructPatPositional(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatPositionAfterName(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWholeCaseNamed(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2enameIndex(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldReadable(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldBothWays(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
@olang_loc_82b73da87554a50f_4f07d83e7e807a5b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
@olang_loc_ea1bc73a77e68519_ca6969815981751d = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, i32 %a5)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_854899d5724a103b_e7dfb19072d83fa7 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6)
@olang_loc_852b58c2eb82b3cc_e47a0c64d3951188 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i1 %a3)
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolledCompr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3, i32 %a4)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValueType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eComprehensionReferences(ptr %v0)
@olang_loc_db57390f6fdf03bc_f3fc0cbffafab9c0 = external constant [0 x i8]
declare %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, i32 %a1, ptr %a2, i1 %a3, { i64, ptr } %a4, { i64, ptr } %a5, i1 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eComprNeedsTry(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, i32 %a3, i1 %a4, ptr %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2eLen__H7de3be79b8c6c838ec83b81887d1384a(ptr %v0, ptr %a0)
declare %"compiler/check:unsetCand" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2eAt_3ccompiler_2fcheck_3aunsetCand_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6df6a05cb53c1036d843c871c36d7669(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2)
declare { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hdfbdd2f3b8a36ed711bc69ab15f6e663(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc0ff66bb3944c98d4b07067782057742(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsetLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esplitLet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, ptr %a5)
@olang_loc_84d9a2b634770df4_5bbab0c17a6f4768 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_45d73a08c1eee64c_a811f88d32b1fa78 = external constant [0 x i8]
declare %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ekillAssigned(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:factsMark" %a1, { i64, ptr } %a2)
@G_2ecompiler_2fcheck_2eWhyCalled = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ekillPaths(ptr %v0, ptr %a0, i64 %a1)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsRestored(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:factsCopy" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_d97e23b04dcff800_367dc3876d150fb4 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_ad4dc9fe288360e2_6bae22496d237a26 = external constant [0 x i8]
@olang_loc_29ea0c7d0dcef6fa_322b22c08f06752e = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_57182574fbaa5aef_a841f6796e4dcc63 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_414cc8b7f33d3de6_fda2437ae6b3c3f2 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eisMember(ptr %v0, ptr %a0)
@olang_loc_9722fccfe35ee7b_558e4c381c37f7e7 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowPath(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2equietPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9c172245b700a898_5abd6adb0e722504 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
@olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarIndex(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrSetArgUnwanted(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_c902484ee6860410_648a649019eab164 = external constant [0 x i8]
@olang_loc_e4324c4b30f6563f_ec149b7f01d5683b = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsArgOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_a8dc05ade1085e71_1f4ef85bbb60cc55 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2fcheck_2eLaneCmp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2)
declare %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10, i64 %a11)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneMaskBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f29deef1411bcac7_1d318aa8f75ec9a3 = external constant [0 x i8]
@olang_loc_15db60dea160a9a8_613bb3b113b67e94 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2fcheck_2eLaneSel = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTotal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4, i32 %a5, %"compiler/source:Span" %a6)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberSeen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOverlap(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOverlap(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
@olang_loc_4d673442943c2a5_9663aeaf0b5db41 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberIsPrivate(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStructPatNoField(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadNoField(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_9e3e60c51c241998_753bf57c496fa07c = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsFixed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %v0, i32 %a0, i1 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eapplyAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_25badba18653f983_c74616522228d697 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %a0)
@olang_loc_6168eeb228a64802_deceb7d8f3c3ddf6 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSpreadAt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueAfter(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrPatternNeedsName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eLe_Hf8109b64a4e45220d0da36a987cf38b1(ptr %v0, ptr %a0)
declare %"compiler/check:payloadItem" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eAt_H64f851f610dd8566f1d7651b626ec99d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItemOk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, { i64, ptr } %a5, i64 %a6, ptr %a7, i64 %a8)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e5e26ce82a519cb4_386557e0c1145fc8 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eProject(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_492feac3979049da_7a1ccb679ec95f6e = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_42af232d2840e8db_efcef566740b002f = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roArg" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %a0, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %a1)
@olang_loc_3ba07a3e63e86523_b4e2f85113e27c0f = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roDeepArg" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_acadf2af31b93e38_18751a402ed16b84 = external constant [0 x i8]
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0)
@olang_loc_d7951065f36562ee_848e8c34c6c42472 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetPlace(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %a0)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetTarget(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetHasValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_c6f64016a09fc530_b8b2abed7e41fd2c = external constant [0 x i8]
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i1 %a4, i1 %a5, i64 %a6, i64 %a7, ptr %a8)
@olang_loc_37fb0db160a44e56_e10956c528b68142 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayLit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, i1 %a4)
@olang_loc_e10237a768a7da34_a1fa84f4f434b2e0 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_a69c1b36a006a603_82104839c45e26c7 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_ddfcf2b97caa4282_7a2ed02469d97696 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoZeroNonNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullableArray(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_39114b2b59f3c1de_f97787d703923df2 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_bfa34a8929429713_51639094391671e7 = external constant [0 x i8]
@olang_loc_37a2617a6fdca52f_9113ce984ee2ba6b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_cffeba9c7beed71d_692ce8f7e2902011 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, { i64, ptr } %a4, i1 %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d652d3791394a9d9_f08137453595c3ad = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
