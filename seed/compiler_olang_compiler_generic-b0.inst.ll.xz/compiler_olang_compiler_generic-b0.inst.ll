; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" = type { i64, { i64, ptr } }
%"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f" = type { i64, %"compiler/generic:FnDefault" }
%"compiler/generic:FnDefault" = type { i64, ptr, %"compiler/generic:Context" }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:MapEntry.95cb3716f5e1d3684dad74c70ff67b94" = type { i64, %"compiler/generic:pattern" }
%"compiler/generic:pattern" = type { ptr, i64, i64, i32, ptr }
%"std/prelude/map:MapEntry.7fb975561c60190182bf1dc558f822cc" = type { i32, %"compiler/generic:Origin" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/map:MapEntry.7f41ee1d8873fb5d9e205986eba07862" = type { i32, ptr }
%"std/prelude/map:MapEntry.6d1319ba4e7d62d710d6eb2bd20b54d6" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/prelude/map:MapEntry.5542d6b65526e0d56036f5be9fbe5707" = type { %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", i32 }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"std/prelude/map:MapEntry.40558edfe60a5d42211fa379e7d0964c" = type { %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", i64 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32, i32 }
%"compiler/generic:instance" = type { i64, i32, i32, { i64, ptr }, { i64, ptr }, %"compiler/generic:Origin" }
%"compiler/generic:varRow" = type { i64, i32, i32, i32, i32 }
define dso_local void @std_2fprelude_2farray_2esortByPositions_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { ptr, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l26 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i1
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t170 = alloca { { ptr, ptr }, { i64, ptr }, ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  store { ptr, ptr } %pg1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr @G_2estd_2fprelude_2farray_2esortRun, !tbaa !24
  %t9 = icmp sle i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load { ptr, ptr }, ptr %l1
  %t17 = extractvalue { ptr, ptr } %t13, 0
  %t18 = extractvalue { ptr, ptr } %t13, 1
  call void @std_2fprelude_2farray_2esortInsertion_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t11, i64 0, i64 %t12, ptr %t17, ptr %t18)
  br label %bb3
bb2:
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  store i64 %t25, ptr %l26, !tbaa !24
  br label %bb8
bb7:
  %t27 = load i64, ptr %l2, !tbaa !24
  store i64 %t27, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t29 = load i64, ptr %l26, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = icmp sle i64 %t32, 1152921504606846975
  br i1 %t33, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_76034d9107c45234_e5fc9ad4bd22d0c8)
  unreachable
bb11:
  %t35 = load i64, ptr %l26, !tbaa !24
  %t36 = mul i64 %t35, 8
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_76034d9107c45234_e5fc9ad4bd22d0c8)
  unreachable
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb15:
  br label %bb16
bb16:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  %t53 = add i64 %t49, %t50
  store i64 %t53, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l2, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t61 = load i64, ptr %l2, !tbaa !24
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  %t67 = sub i64 %t63, %t64
  store i64 %t67, ptr %l45, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l46, !tbaa !24
  %t70 = icmp sge i64 0, 0
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load i64, ptr %l45, !tbaa !24
  %t73 = icmp sle i64 0, %t72
  br i1 %t73, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ef7b433399c50f59_19799ad7b52ed855)
  unreachable
bb22:
  %t75 = load i64, ptr %l45, !tbaa !24
  %t76 = load i64, ptr %l46, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_ef7b433399c50f59_19799ad7b52ed855)
  unreachable
bb24:
  %t79 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l45, !tbaa !24
  %t82 = getelementptr i64, ptr %t80, i64 0
  %t83 = sub i64 %t81, 0
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sub i64 %t87, %t88
  store i64 %t91, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_ef7b433399c50f59_19799ad7b52ed855)
  unreachable
bb26:
  %t99 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb31
bb28:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l60, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb30
bb30:
  %t119 = load i64, ptr %l60, !tbaa !24
  store i64 %t119, ptr %l57, !tbaa !24
  br label %bb31
bb31:
  %t120 = load i64, ptr %l57, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t121 = load i64, ptr %l10, !tbaa !24
  %t122 = sub i64 %t121, 1
  store i64 %t122, ptr %l69, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = icmp slt i64 %t123, 2147483648
  %t125 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sge i64 %t125, 0
  %t129 = and i1 %t124, %t126
  store i1 %t129, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t140 = load i64, ptr %l9, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l12, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t148, ptr %l82, !tbaa !27
  %t149 = load i64, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l4, !tbaa !24
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = add i64 %t150, %t151
  %t157 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i64, ptr %t158, i64 %t149
  store i64 %t154, ptr %t159, !tbaa !34
  br label %bb36
bb36:
  %t160 = load i64, ptr %l11, !tbaa !24
  %t163 = add i64 %t160, 1
  store i64 %t163, ptr %l11, !tbaa !24
  br label %bb32
bb37:
  %t165 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t166 = load { ptr, ptr }, ptr %l1
  %t167 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t168 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr null, i32 1
  %t169 = ptrtoint ptr %t168 to i64
  %t171 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 0
  store { ptr, ptr } %t166, ptr %t171, !tbaa !28
  %t173 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 1
  store { i64, ptr } %t167, ptr %t173, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t175 = call ptr @__olang_scope_hold(ptr %v1)
  %t176 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 2
  store ptr %t175, ptr %t176, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t177 = call ptr @__olang_scope_hold(ptr %v0)
  %t178 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 3
  store ptr %t177, ptr %t178, !tbaa !28
  %t179 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t180 = insertvalue { ptr, ptr } %t179, ptr %t170, 1
  %t183 = extractvalue { ptr, ptr } %t180, 0
  %t184 = extractvalue { ptr, ptr } %t180, 1
  call void @std_2fprelude_2farray_2esortMergeBuffered_3cI64_2c_20_3f_3e_clone1_olang_lambda_16955(ptr %s0, ptr %s2, { i64, ptr } %t165, ptr %t183, ptr %t184)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t185 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t186 = load i64, ptr %l4, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2farray_2esortPermute_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %s0, { i64, ptr } %t185, i64 %t186, { i64, ptr } %t187)
  br label %bb40
bb40:
  %t191 = load i64, ptr %l5, !tbaa !24
  store i64 %t191, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  br label %bb13
bb42:
  %t193 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  store i64 %t193, ptr %l13, !tbaa !24
  br label %bb43
bb43:
  %t195 = load i64, ptr %l13, !tbaa !24
  %t196 = load i64, ptr %l2, !tbaa !24
  %t199 = icmp slt i64 %t195, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb44, label %bb45
bb44:
  br label %bb59
bb45:
  br label %bb46
bb46:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb47
bb47:
  %t203 = load i64, ptr %l4, !tbaa !24
  %t204 = load i64, ptr %l13, !tbaa !24
  %t207 = add i64 %t203, %t204
  %t208 = load i64, ptr %l2, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb48, label %bb49
bb48:
  br label %bb57
bb49:
  br label %bb50
bb50:
  %t215 = load i64, ptr %l4, !tbaa !24
  %t216 = load i64, ptr %l13, !tbaa !24
  %t218 = mul i64 2, %t216
  %t221 = add i64 %t215, %t218
  store i64 %t221, ptr %l14, !tbaa !24
  %t223 = load i64, ptr %l14, !tbaa !24
  %t224 = load i64, ptr %l2, !tbaa !24
  %t227 = icmp sgt i64 %t223, %t224
  br i1 %t227, label %bb51, label %bb52
bb51:
  %t229 = load i64, ptr %l2, !tbaa !24
  store i64 %t229, ptr %l14, !tbaa !24
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t231 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t232 = load i64, ptr %l4, !tbaa !24
  %t233 = load i64, ptr %l4, !tbaa !24
  %t234 = load i64, ptr %l13, !tbaa !24
  %t237 = add i64 %t233, %t234
  %t238 = load i64, ptr %l14, !tbaa !24
  %t239 = load { ptr, ptr }, ptr %l1
  %t245 = extractvalue { ptr, ptr } %t239, 0
  %t246 = extractvalue { ptr, ptr } %t239, 1
  call void @std_2fprelude_2farray_2esortMerge_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t231, i64 %t232, i64 %t237, i64 %t238, ptr %t245, ptr %t246)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t247 = load i64, ptr %l14, !tbaa !24
  store i64 %t247, ptr %l4, !tbaa !24
  br label %bb56
bb56:
  br label %bb47
bb57:
  %t249 = load i64, ptr %l13, !tbaa !24
  %t252 = mul i64 %t249, 2
  store i64 %t252, ptr %l13, !tbaa !24
  br label %bb58
bb58:
  br label %bb43
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortMerge_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3, ptr %a4c, ptr %a4e) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { ptr, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l47 = alloca i1
  %l57 = alloca i64
  %l60 = alloca i64
  %l99 = alloca i1
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l107 = alloca i1
  %l150 = alloca i1
  %l152 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l160 = alloca i1
  %l171 = alloca i1
  %l182 = alloca i1
  %l194 = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  store { ptr, ptr } %pg4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t1, %t2
  %t7 = icmp eq i64 %t5, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb3
bb2:
  br label %bb27
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sdiv i64 %t25, 2
  store i64 %t27, ptr %l7, !tbaa !24
  %t29 = load { ptr, ptr }, ptr %l4
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l41, !tbaa !27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i32, ptr %t34, i64 %t31
  %t36 = load i32, ptr %t35, !tbaa !33
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l44, !tbaa !27
  %t38 = load i64, ptr %l1, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 %t38
  %t43 = load i32, ptr %t42, !tbaa !33
  %t45 = extractvalue { ptr, ptr } %t29, 0
  %t46 = extractvalue { ptr, ptr } %t29, 1
  %t49 = call i1 %t45(ptr %t46, i32 %t36, i32 %t43)
  store i1 %t49, ptr %l47
  br label %bb7
bb7:
  %t50 = load i1, ptr %l47, !tbaa !21
  store i1 %t50, ptr %l39, !tbaa !21
  br label %bb8
bb8:
  %t51 = load i1, ptr %l39, !tbaa !21
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l5, !tbaa !24
  br label %bb11
bb10:
  %t56 = load i64, ptr %l7, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  br label %bb12
bb12:
  br label %bb3
bb13:
  %t58 = load i64, ptr %l1, !tbaa !24
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = sub i64 %t60, 1
  store i64 %t62, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = icmp sgt i64 %t64, %t65
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t70 = load i64, ptr %l10, !tbaa !24
  %t72 = icmp sgt i64 %t70, 0
  br i1 %t72, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb19
bb16:
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = sub i64 %t74, %t75
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t84 = sub i64 %t82, 1
  %t85 = load i64, ptr %l10, !tbaa !24
  %t88 = sdiv i64 %t84, %t85
  store i64 %t88, ptr %l60, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb18
bb18:
  %t90 = load i64, ptr %l60, !tbaa !24
  store i64 %t90, ptr %l57, !tbaa !24
  br label %bb19
bb19:
  %t91 = load i64, ptr %l57, !tbaa !24
  store i64 %t91, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb20
bb20:
  %t92 = load i64, ptr %l12, !tbaa !24
  %t93 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb21, label %bb22
bb21:
  br label %bb26
bb22:
  br label %bb23
bb23:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t101 = load i64, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t108 = add i64 %t100, %t105
  store i64 %t108, ptr %l13, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t111 = load i64, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = add i64 %t112, 1
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, { i64, ptr } %t110, i64 %t111, i64 %t114)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = add i64 %t118, 1
  store i64 %t121, ptr %l12, !tbaa !24
  br label %bb20
bb26:
  br label %ret
bb27:
  %t123 = load i64, ptr %l3, !tbaa !24
  %t124 = load i64, ptr %l2, !tbaa !24
  %t127 = sub i64 %t123, %t124
  %t129 = icmp eq i64 %t127, 1
  br i1 %t129, label %bb28, label %bb29
bb28:
  %t131 = load i64, ptr %l1, !tbaa !24
  store i64 %t131, ptr %l14, !tbaa !24
  %t133 = load i64, ptr %l2, !tbaa !24
  store i64 %t133, ptr %l15, !tbaa !24
  br label %bb30
bb29:
  br label %bb48
bb30:
  %t135 = load i64, ptr %l14, !tbaa !24
  %t136 = load i64, ptr %l15, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb31, label %bb32
bb31:
  br label %bb40
bb32:
  br label %bb33
bb33:
  %t143 = load i64, ptr %l14, !tbaa !24
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = add i64 %t143, %t144
  %t149 = sdiv i64 %t147, 2
  store i64 %t149, ptr %l16, !tbaa !24
  %t151 = load { ptr, ptr }, ptr %l4
  %t152 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t152, ptr %l101, !tbaa !27
  %t153 = load i64, ptr %l2, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i32, ptr %t156, i64 %t153
  %t158 = load i32, ptr %t157, !tbaa !33
  %t159 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t159, ptr %l104, !tbaa !27
  %t160 = load i64, ptr %l16, !tbaa !24
  %t162 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i32, ptr %t163, i64 %t160
  %t165 = load i32, ptr %t164, !tbaa !33
  %t167 = extractvalue { ptr, ptr } %t151, 0
  %t168 = extractvalue { ptr, ptr } %t151, 1
  %t171 = call i1 %t167(ptr %t168, i32 %t158, i32 %t165)
  store i1 %t171, ptr %l107
  br label %bb34
bb34:
  %t172 = load i1, ptr %l107, !tbaa !21
  store i1 %t172, ptr %l99, !tbaa !21
  br label %bb35
bb35:
  %t173 = load i1, ptr %l99, !tbaa !21
  %t174 = xor i1 %t173, true
  br i1 %t174, label %bb36, label %bb37
bb36:
  %t176 = load i64, ptr %l16, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l14, !tbaa !24
  br label %bb38
bb37:
  %t180 = load i64, ptr %l16, !tbaa !24
  store i64 %t180, ptr %l15, !tbaa !24
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb30
bb40:
  %t182 = load i64, ptr %l2, !tbaa !24
  store i64 %t182, ptr %l17, !tbaa !24
  br label %bb41
bb41:
  %t184 = load i64, ptr %l17, !tbaa !24
  %t185 = load i64, ptr %l14, !tbaa !24
  %t188 = icmp sgt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb42, label %bb43
bb42:
  br label %bb47
bb43:
  br label %bb44
bb44:
  %t192 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t193 = load i64, ptr %l17, !tbaa !24
  %t194 = load i64, ptr %l17, !tbaa !24
  %t196 = sub i64 %t194, 1
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, { i64, ptr } %t192, i64 %t193, i64 %t196)
  br label %bb45
bb45:
  %t200 = load i64, ptr %l17, !tbaa !24
  %t203 = sub i64 %t200, 1
  store i64 %t203, ptr %l17, !tbaa !24
  br label %bb46
bb46:
  br label %bb41
bb47:
  br label %ret
bb48:
  %t205 = load i64, ptr %l1, !tbaa !24
  %t206 = load i64, ptr %l3, !tbaa !24
  %t209 = add i64 %t205, %t206
  %t211 = sdiv i64 %t209, 2
  store i64 %t211, ptr %l18, !tbaa !24
  %t213 = load i64, ptr %l18, !tbaa !24
  %t214 = load i64, ptr %l2, !tbaa !24
  %t217 = add i64 %t213, %t214
  store i64 %t217, ptr %l19, !tbaa !24
  %t219 = load i64, ptr %l1, !tbaa !24
  store i64 %t219, ptr %l20, !tbaa !24
  %t221 = load i64, ptr %l2, !tbaa !24
  store i64 %t221, ptr %l21, !tbaa !24
  %t223 = load i64, ptr %l2, !tbaa !24
  %t224 = load i64, ptr %l18, !tbaa !24
  %t227 = icmp sgt i64 %t223, %t224
  br i1 %t227, label %bb49, label %bb50
bb49:
  %t229 = load i64, ptr %l19, !tbaa !24
  %t230 = load i64, ptr %l3, !tbaa !24
  %t233 = sub i64 %t229, %t230
  store i64 %t233, ptr %l20, !tbaa !24
  %t235 = load i64, ptr %l18, !tbaa !24
  store i64 %t235, ptr %l21, !tbaa !24
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t237 = load i64, ptr %l19, !tbaa !24
  %t239 = sub i64 %t237, 1
  store i64 %t239, ptr %l22, !tbaa !24
  br label %bb52
bb52:
  %t241 = load i64, ptr %l20, !tbaa !24
  %t242 = load i64, ptr %l21, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb53, label %bb54
bb53:
  br label %bb62
bb54:
  br label %bb55
bb55:
  %t249 = load i64, ptr %l20, !tbaa !24
  %t250 = load i64, ptr %l21, !tbaa !24
  %t253 = add i64 %t249, %t250
  %t255 = sdiv i64 %t253, 2
  store i64 %t255, ptr %l23, !tbaa !24
  %t257 = load { ptr, ptr }, ptr %l4
  %t258 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t258, ptr %l152, !tbaa !27
  %t259 = load i64, ptr %l22, !tbaa !24
  %t260 = load i64, ptr %l23, !tbaa !24
  %t263 = sub i64 %t259, %t260
  %t265 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr i32, ptr %t266, i64 %t263
  %t268 = load i32, ptr %t267, !tbaa !33
  %t269 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t269, ptr %l157, !tbaa !27
  %t270 = load i64, ptr %l23, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i32, ptr %t273, i64 %t270
  %t275 = load i32, ptr %t274, !tbaa !33
  %t277 = extractvalue { ptr, ptr } %t257, 0
  %t278 = extractvalue { ptr, ptr } %t257, 1
  %t281 = call i1 %t277(ptr %t278, i32 %t268, i32 %t275)
  store i1 %t281, ptr %l160
  br label %bb56
bb56:
  %t282 = load i1, ptr %l160, !tbaa !21
  store i1 %t282, ptr %l150, !tbaa !21
  br label %bb57
bb57:
  %t283 = load i1, ptr %l150, !tbaa !21
  %t284 = xor i1 %t283, true
  br i1 %t284, label %bb58, label %bb59
bb58:
  %t286 = load i64, ptr %l23, !tbaa !24
  %t288 = add i64 %t286, 1
  store i64 %t288, ptr %l20, !tbaa !24
  br label %bb60
bb59:
  %t290 = load i64, ptr %l23, !tbaa !24
  store i64 %t290, ptr %l21, !tbaa !24
  br label %bb60
bb60:
  br label %bb61
bb61:
  br label %bb52
bb62:
  %t292 = load i64, ptr %l19, !tbaa !24
  %t293 = load i64, ptr %l20, !tbaa !24
  %t296 = sub i64 %t292, %t293
  store i64 %t296, ptr %l24, !tbaa !24
  %t298 = load i64, ptr %l20, !tbaa !24
  %t299 = load i64, ptr %l2, !tbaa !24
  %t302 = icmp slt i64 %t298, %t299
  br i1 %t302, label %bb63, label %bb64
bb63:
  %t304 = load i64, ptr %l2, !tbaa !24
  %t305 = load i64, ptr %l24, !tbaa !24
  %t308 = icmp slt i64 %t304, %t305
  store i1 %t308, ptr %l171, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb65
bb65:
  %t310 = load i1, ptr %l171, !tbaa !21
  br i1 %t310, label %bb66, label %bb67
bb66:
  %t311 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t312 = load i64, ptr %l20, !tbaa !24
  %t313 = load i64, ptr %l2, !tbaa !24
  %t314 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2farray_2esortRotate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, { i64, ptr } %t311, i64 %t312, i64 %t313, i64 %t314)
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  %t319 = load i64, ptr %l1, !tbaa !24
  %t320 = load i64, ptr %l20, !tbaa !24
  %t323 = icmp slt i64 %t319, %t320
  br i1 %t323, label %bb70, label %bb71
bb70:
  %t325 = load i64, ptr %l20, !tbaa !24
  %t326 = load i64, ptr %l18, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  store i1 %t329, ptr %l182, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb72
bb72:
  %t331 = load i1, ptr %l182, !tbaa !21
  br i1 %t331, label %bb73, label %bb74
bb73:
  %t332 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t333 = load i64, ptr %l1, !tbaa !24
  %t334 = load i64, ptr %l20, !tbaa !24
  %t335 = load i64, ptr %l18, !tbaa !24
  %t336 = load { ptr, ptr }, ptr %l4
  %t342 = extractvalue { ptr, ptr } %t336, 0
  %t343 = extractvalue { ptr, ptr } %t336, 1
  call void @std_2fprelude_2farray_2esortMerge_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t332, i64 %t333, i64 %t334, i64 %t335, ptr %t342, ptr %t343)
  br label %bb75
bb74:
  br label %bb77
bb75:
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t344 = load i64, ptr %l18, !tbaa !24
  %t345 = load i64, ptr %l24, !tbaa !24
  %t348 = icmp slt i64 %t344, %t345
  br i1 %t348, label %bb78, label %bb79
bb78:
  %t350 = load i64, ptr %l24, !tbaa !24
  %t351 = load i64, ptr %l3, !tbaa !24
  %t354 = icmp slt i64 %t350, %t351
  store i1 %t354, ptr %l194, !tbaa !21
  br label %bb80
bb79:
  store i1 false, ptr %l194, !tbaa !21
  br label %bb80
bb80:
  %t356 = load i1, ptr %l194, !tbaa !21
  br i1 %t356, label %bb81, label %bb82
bb81:
  %t357 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t358 = load i64, ptr %l18, !tbaa !24
  %t359 = load i64, ptr %l24, !tbaa !24
  %t360 = load i64, ptr %l3, !tbaa !24
  %t361 = load { ptr, ptr }, ptr %l4
  %t367 = extractvalue { ptr, ptr } %t361, 0
  %t368 = extractvalue { ptr, ptr } %t361, 1
  call void @std_2fprelude_2farray_2esortMerge_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t357, i64 %t358, i64 %t359, i64 %t360, ptr %t367, ptr %t368)
  br label %bb83
bb82:
  br label %bb85
bb83:
  br label %bb84
bb84:
  br label %bb85
bb85:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortRotate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l82 = alloca i64
  %l85 = alloca i64
  %l127 = alloca i64
  %l130 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t5 = sub i64 %t1, %a1
  store i64 %t5, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = sub i64 %a3, %t8
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp ne i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  br label %bb35
bb3:
  br label %bb4
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i64 0, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  store i64 %t27, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l12, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  store i64 %t35, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = load i64, ptr %l12, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb20, label %bb21
bb7:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb12
bb9:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l44, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l44, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l41, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l11, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t84 = load i64, ptr %l2, !tbaa !24
  %t85 = load i64, ptr %l4, !tbaa !24
  %t88 = sub i64 %t84, %t85
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = add i64 %t88, %t89
  %t93 = load i64, ptr %l2, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = add i64 %t93, %t94
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, { i64, ptr } %t83, i64 %t92, i64 %t97)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l10, !tbaa !24
  br label %bb13
bb19:
  %t106 = load i64, ptr %l4, !tbaa !24
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t106, %t108
  store i64 %t111, ptr %l4, !tbaa !24
  br label %bb33
bb20:
  %t113 = load i64, ptr %l14, !tbaa !24
  %t115 = icmp sgt i64 %t113, 0
  br i1 %t115, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb25
bb22:
  %t117 = load i64, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = sub i64 %t117, %t118
  %t122 = load i64, ptr %l14, !tbaa !24
  %t125 = add i64 %t121, %t122
  %t127 = sub i64 %t125, 1
  %t128 = load i64, ptr %l14, !tbaa !24
  %t131 = sdiv i64 %t127, %t128
  store i64 %t131, ptr %l85, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb24
bb24:
  %t133 = load i64, ptr %l85, !tbaa !24
  store i64 %t133, ptr %l82, !tbaa !24
  br label %bb25
bb25:
  %t134 = load i64, ptr %l82, !tbaa !24
  store i64 %t134, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb26
bb26:
  %t135 = load i64, ptr %l16, !tbaa !24
  %t136 = load i64, ptr %l15, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t143 = load i64, ptr %l12, !tbaa !24
  %t144 = load i64, ptr %l16, !tbaa !24
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = mul i64 %t144, %t145
  %t151 = add i64 %t143, %t148
  store i64 %t151, ptr %l17, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t154 = load i64, ptr %l2, !tbaa !24
  %t155 = load i64, ptr %l4, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l17, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t163 = load i64, ptr %l2, !tbaa !24
  %t164 = load i64, ptr %l5, !tbaa !24
  %t167 = add i64 %t163, %t164
  %t168 = load i64, ptr %l4, !tbaa !24
  %t171 = sub i64 %t167, %t168
  %t172 = load i64, ptr %l17, !tbaa !24
  %t175 = add i64 %t171, %t172
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, { i64, ptr } %t153, i64 %t162, i64 %t175)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l16, !tbaa !24
  br label %bb26
bb32:
  %t184 = load i64, ptr %l5, !tbaa !24
  %t186 = load i64, ptr %l4, !tbaa !24
  %t189 = sub i64 %t184, %t186
  store i64 %t189, ptr %l5, !tbaa !24
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb1
bb35:
  store i64 0, ptr %l18, !tbaa !24
  %t191 = load i64, ptr %l4, !tbaa !24
  store i64 %t191, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t193 = load i64, ptr %l19, !tbaa !24
  %t194 = load i64, ptr %l18, !tbaa !24
  %t197 = icmp sgt i64 %t193, %t194
  br i1 %t197, label %bb36, label %bb37
bb36:
  %t199 = load i64, ptr %l20, !tbaa !24
  %t201 = icmp sgt i64 %t199, 0
  br i1 %t201, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb41
bb38:
  %t203 = load i64, ptr %l19, !tbaa !24
  %t204 = load i64, ptr %l18, !tbaa !24
  %t207 = sub i64 %t203, %t204
  %t208 = load i64, ptr %l20, !tbaa !24
  %t211 = add i64 %t207, %t208
  %t213 = sub i64 %t211, 1
  %t214 = load i64, ptr %l20, !tbaa !24
  %t217 = sdiv i64 %t213, %t214
  store i64 %t217, ptr %l130, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb40
bb40:
  %t219 = load i64, ptr %l130, !tbaa !24
  store i64 %t219, ptr %l127, !tbaa !24
  br label %bb41
bb41:
  %t220 = load i64, ptr %l127, !tbaa !24
  store i64 %t220, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb42
bb42:
  %t221 = load i64, ptr %l22, !tbaa !24
  %t222 = load i64, ptr %l21, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb43, label %bb44
bb43:
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t229 = load i64, ptr %l18, !tbaa !24
  %t230 = load i64, ptr %l22, !tbaa !24
  %t231 = load i64, ptr %l20, !tbaa !24
  %t234 = mul i64 %t230, %t231
  %t237 = add i64 %t229, %t234
  store i64 %t237, ptr %l23, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t240 = load i64, ptr %l2, !tbaa !24
  %t241 = load i64, ptr %l4, !tbaa !24
  %t244 = sub i64 %t240, %t241
  %t245 = load i64, ptr %l23, !tbaa !24
  %t248 = add i64 %t244, %t245
  %t249 = load i64, ptr %l2, !tbaa !24
  %t250 = load i64, ptr %l23, !tbaa !24
  %t253 = add i64 %t249, %t250
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, { i64, ptr } %t239, i64 %t248, i64 %t253)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t257 = load i64, ptr %l22, !tbaa !24
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %l22, !tbaa !24
  br label %bb42
bb48:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cBool_3e_3e_2ePut_3cI64_2c_20Array_3cBool_3e_3e(ptr %v0, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %t21 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a636095cf79013fe_ac8eb0a082fd0652)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a636095cf79013fe_ac8eb0a082fd0652)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t81, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l32, !tbaa !24
  %t91 = call ptr @__olang_region_make_part(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l33, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l34, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l35, !tbaa !24
  %t96 = load i64, ptr %l35, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = load i64, ptr %l33
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = call ptr @__olang_held_alloc(ptr %t99, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l36, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l35, !tbaa !24
  %t108 = mul i64 %t107, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t104, ptr %t106, i64 %t108, i1 false)
  %t109 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb17, label %bb18
bb16:
  br label %bb19
bb17:
  store { i64, ptr } zeroinitializer, ptr %l36, !tbaa !27
  br label %bb18
bb18:
  %t114 = load i64, ptr %l33
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l36
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l31, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load i64, ptr %l32, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t125, i64 %t123
  %t127 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t126, i32 0, i32 1
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l39, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t130 = load ptr, ptr %l31, !tbaa !29
  %t131 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 0
  %t132 = load i64, ptr %l32, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t134, i64 %t132
  %t136 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t135, i32 0, i32 1
  store { i64, ptr } %t129, ptr %t136, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l39
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  call void @__olang_region_release_part(ptr %t139, i64 %t138)
  store { i64, ptr } zeroinitializer, ptr %l39
  br label %ret
bb19:
  br label %bb20
bb20:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l4, !tbaa !24
  %t143 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t140, i32 0, i32 1
  %t145 = getelementptr { i64, ptr }, ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i64, ptr %t146, i64 %t141
  %t148 = load i64, ptr %t147, !tbaa !34
  store i64 %t148, ptr %l4, !tbaa !24
  br label %bb11
bb21:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i64, ptr %l3, !tbaa !24
  %t152 = load i64, ptr %l1, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cBool_3e_3e_2eadd_3cI64_2c_20Array_3cBool_3e_3e(ptr %v0, ptr %t150, i64 %t151, i64 %t152, { i64, ptr } %t153)
  br label %bb22
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3aFnDefaul_Hd788588fd8d312087c3727af589f0064(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f"
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca i64
  %l72 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_4247c7537790cd68_ca1df51cce72f33c)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_4247c7537790cd68_ca1df51cce72f33c)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t54 = mul i64 %t50, 184
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4247c7537790cd68_ca1df51cce72f33c)
  unreachable
bb10:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f", ptr %t72, i64 %t69
  %t74 = load %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f", ptr %t73
  store %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f" zeroinitializer, ptr %t73
  store %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f" %t74, ptr %l41
  %t75 = load i64, ptr %l33, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f", ptr %t77, i64 %t75
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %l41, i64 184, i1 false)
  %t79 = load i64, ptr %l33, !tbaa !24
  %t80 = add i64 %t79, 1
  store i64 %t80, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t81 = load i64, ptr %l5, !tbaa !24
  %t84 = add i64 %t81, 1
  store i64 %t84, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t86 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t87 = load ptr, ptr %l21, !tbaa !29
  %t88 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t87, i32 0, i32 0
  store { i64, ptr } %t86, ptr %t88, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t91, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l49, !tbaa !29
  store { i64, ptr } %t94, ptr %l50, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t98, i32 0, i32 3
  %t101 = load i64, ptr %t100, !tbaa !24
  store i64 %t101, ptr %l52, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l53, !tbaa !24
  %t104 = icmp sge i64 0, 0
  br i1 %t104, label %bb16, label %bb17
bb16:
  %t106 = load i64, ptr %l52, !tbaa !24
  %t107 = icmp sle i64 0, %t106
  br i1 %t107, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_ecf6018803603945_317c3a2f2a3fcb29)
  unreachable
bb18:
  %t109 = load i64, ptr %l52, !tbaa !24
  %t110 = load i64, ptr %l53, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_ecf6018803603945_317c3a2f2a3fcb29)
  unreachable
bb20:
  %t113 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l52, !tbaa !24
  %t116 = getelementptr i64, ptr %t114, i64 0
  %t117 = sub i64 %t115, 0
  %t118 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t116, 1
  store { i64, ptr } %t119, ptr %l7, !tbaa !27
  %t121 = load i64, ptr %l1, !tbaa !24
  %t123 = call ptr @__olang_region_make_part(ptr %v0)
  %t124 = ptrtoint ptr %t123 to i64
  store i64 %t124, ptr %l59, !tbaa !24
  store i64 %t121, ptr %l60, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t128 = load i64, ptr %l60, !tbaa !24
  %t129 = extractvalue { i64, ptr } %t126, 0
  %t130 = mul i64 %t129, 8
  %t131 = mul i64 %t128, 8
  %t132 = extractvalue { i64, ptr } %t126, 1
  %t133 = call ptr @__olang_grow_in_place(ptr %t132, i64 %t130, i64 %t131, i64 %t128)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, i64 %t128, i64 0
  %t136 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t133, 1
  store { i64, ptr } %t137, ptr %l63, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  %t141 = icmp ne i64 %t139, 0
  br i1 %t141, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ecf6018803603945_317c3a2f2a3fcb29)
  unreachable
bb22:
  %t143 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t143, ptr %l61, !tbaa !27
  br label %bb24
bb23:
  %t144 = load i64, ptr %l60, !tbaa !24
  %t145 = mul i64 %t144, 8
  %t146 = load i64, ptr %l59
  %t147 = inttoptr i64 %t146 to ptr
  %t148 = call ptr @__olang_held_alloc(ptr %t147, i64 %t145)
  %t149 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l61, !tbaa !27
  store i64 0, ptr %l66, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  %t151 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  %t154 = icmp eq i64 %t152, 0
  br i1 %t154, label %bb31, label %bb32
bb25:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t162 = icmp slt i64 %t156, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t166 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t166, ptr %l72, !tbaa !27
  %t167 = load i64, ptr %l9, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i64, ptr %t170, i64 %t167
  %t172 = load i64, ptr %t171, !tbaa !34
  %t174 = load i64, ptr %l66, !tbaa !24
  %t175 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i64, ptr %t176, i64 %t174
  store i64 %t172, ptr %t177, !tbaa !34
  %t178 = load i64, ptr %l66, !tbaa !24
  %t179 = add i64 %t178, 1
  store i64 %t179, ptr %l66, !tbaa !24
  br label %bb29
bb29:
  %t180 = load i64, ptr %l9, !tbaa !24
  %t183 = add i64 %t180, 1
  store i64 %t183, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  br label %bb24
bb31:
  store { i64, ptr } zeroinitializer, ptr %l61, !tbaa !27
  br label %bb32
bb32:
  %t185 = load i64, ptr %l59
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = load { i64, ptr }, ptr %l61
  %t188 = extractvalue { i64, ptr } %t187, 1
  %t189 = call ptr @__olang_region_or(ptr %t188, ptr null)
  %t190 = icmp ne ptr %t189, null
  %t191 = select i1 %t190, ptr %t189, ptr null
  call void @__olang_region_settle_in(ptr %t186, ptr %t191)
  %t192 = load ptr, ptr %l49, !tbaa !29
  %t193 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t192, i32 0, i32 1
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  store { i64, ptr } %t194, ptr %l80, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t196 = load ptr, ptr %l49, !tbaa !29
  %t197 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t196, i32 0, i32 1
  store { i64, ptr } %t195, ptr %t197, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l80
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t200 = extractvalue { i64, ptr } %t198, 1
  call void @__olang_region_release_part(ptr %t200, i64 %t199)
  store { i64, ptr } zeroinitializer, ptr %l80
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3aFnDefaul_Heccae358bebde09a47984c7dc693f64e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/generic:FnDefault"
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca %"compiler/generic:FnDefault"
  %l35 = alloca %"compiler/generic:FnDefault"
  %l36 = alloca %"compiler/generic:FnDefault"
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca %"compiler/generic:FnDefault"
  %l45 = alloca %"compiler/generic:FnDefault"
  %s0 = alloca %olang.scope
  %t21 = alloca i64
  %t91 = alloca %"compiler/generic:FnDefault", align 8
  %t156 = alloca %"compiler/generic:FnDefault", align 8
  %t161 = alloca %"compiler/generic:FnDefault", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 176, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_472096c2de1d38f3_d3b25c2128de691f)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_472096c2de1d38f3_d3b25c2128de691f)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f", ptr %t81, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l32, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l33, ptr %l2, i64 176, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aFnDefault(ptr %t91, ptr %v0, ptr %l33)
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %t91, i64 176, i1 false)
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t93 = load ptr, ptr %l31, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t93, i32 0, i32 0
  %t95 = load i64, ptr %l32, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f", ptr %t97, i64 %t95
  %t99 = getelementptr %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f", ptr %t98, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t99, i64 176, i1 false)
  %t100 = load ptr, ptr %l31, !tbaa !29
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t100, i32 0, i32 0
  %t102 = load i64, ptr %l32, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f", ptr %t104, i64 %t102
  %t106 = getelementptr %"std/prelude/map:MapEntry.c3a20c9d6394e4553a3c4ede61a8182f", ptr %t105, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %l35, i64 176, i1 false)
  %t107 = getelementptr %"compiler/generic:FnDefault", ptr %l36, i32 0, i32 2
  %t108 = getelementptr %"compiler/generic:Context", ptr %t107, i32 0, i32 2
  %t109 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t108, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t112 = extractvalue { i64, ptr } %t110, 1
  call void @__olang_region_release_part(ptr %t112, i64 %t111)
  store { i64, ptr } zeroinitializer, ptr %t109
  %t113 = getelementptr %"compiler/generic:FnDefault", ptr %l36, i32 0, i32 2
  %t114 = getelementptr %"compiler/generic:Context", ptr %t113, i32 0, i32 2
  %t115 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t114, i32 0, i32 1
  %t116 = load { i64, ptr }, ptr %t115
  %t117 = extractvalue { i64, ptr } %t116, 0
  %t118 = extractvalue { i64, ptr } %t116, 1
  call void @__olang_region_release_part(ptr %t118, i64 %t117)
  store { i64, ptr } zeroinitializer, ptr %t115
  %t119 = getelementptr %"compiler/generic:FnDefault", ptr %l36, i32 0, i32 2
  %t120 = getelementptr %"compiler/generic:Context", ptr %t119, i32 0, i32 2
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t120, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121
  %t123 = extractvalue { i64, ptr } %t122, 0
  %t124 = extractvalue { i64, ptr } %t122, 1
  call void @__olang_region_release_part(ptr %t124, i64 %t123)
  store { i64, ptr } zeroinitializer, ptr %t121
  %t125 = getelementptr %"compiler/generic:FnDefault", ptr %l36, i32 0, i32 2
  %t126 = getelementptr %"compiler/generic:Context", ptr %t125, i32 0, i32 3
  %t127 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t126, i32 0, i32 0
  %t128 = load { i64, ptr }, ptr %t127
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  call void @__olang_region_release_part(ptr %t130, i64 %t129)
  store { i64, ptr } zeroinitializer, ptr %t127
  %t131 = getelementptr %"compiler/generic:FnDefault", ptr %l36, i32 0, i32 2
  %t132 = getelementptr %"compiler/generic:Context", ptr %t131, i32 0, i32 3
  %t133 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t132, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133
  %t135 = extractvalue { i64, ptr } %t134, 0
  %t136 = extractvalue { i64, ptr } %t134, 1
  call void @__olang_region_release_part(ptr %t136, i64 %t135)
  store { i64, ptr } zeroinitializer, ptr %t133
  %t137 = getelementptr %"compiler/generic:FnDefault", ptr %l36, i32 0, i32 2
  %t138 = getelementptr %"compiler/generic:Context", ptr %t137, i32 0, i32 3
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t138, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139
  %t141 = extractvalue { i64, ptr } %t140, 0
  %t142 = extractvalue { i64, ptr } %t140, 1
  call void @__olang_region_release_part(ptr %t142, i64 %t141)
  store { i64, ptr } zeroinitializer, ptr %t139
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  br label %bb19
bb19:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i64, ptr %l4, !tbaa !24
  %t146 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t143, i32 0, i32 1
  %t148 = getelementptr { i64, ptr }, ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i64, ptr %t149, i64 %t144
  %t151 = load i64, ptr %t150, !tbaa !34
  store i64 %t151, ptr %l4, !tbaa !24
  br label %bb11
bb20:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l40, !tbaa !29
  %t154 = load i64, ptr %l3, !tbaa !24
  store i64 %t154, ptr %l41, !tbaa !24
  %t155 = load i64, ptr %l1, !tbaa !24
  store i64 %t155, ptr %l42, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %l2, i64 176, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aFnDefault(ptr %t156, ptr %s0, ptr %l43)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t156, i64 176, i1 false)
  br label %bb21
bb21:
  %t158 = load ptr, ptr %l40, !tbaa !29
  %t159 = load i64, ptr %l41, !tbaa !24
  %t160 = load i64, ptr %l42, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t161, ptr %l45, i64 176, i1 false)
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3aFnDefaul_H7b6ff798d6bfbdc8007da25519526074(ptr %v0, ptr %v0, ptr %t158, i64 %t159, i64 %t160, ptr %t161)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3apattern__H70f3bc8493d5ade4dd208a176cd9992e(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca i64
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_424e014fd526cac2_9b0d8ae77cce30c6)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_424e014fd526cac2_9b0d8ae77cce30c6)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.95cb3716f5e1d3684dad74c70ff67b94", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 48
  %t58 = mul i64 %t55, 48
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_424e014fd526cac2_9b0d8ae77cce30c6)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 48
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  store { i64, ptr } %t84, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.95cb3716f5e1d3684dad74c70ff67b94", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.95cb3716f5e1d3684dad74c70ff67b94", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.95cb3716f5e1d3684dad74c70ff67b94", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.95cb3716f5e1d3684dad74c70ff67b94" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d83600b5e7480cbf_fab8298361e1a8a3)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d83600b5e7480cbf_fab8298361e1a8a3)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  %t142 = call ptr @__olang_region_make_part(ptr %v0)
  %t143 = ptrtoint ptr %t142 to i64
  store i64 %t143, ptr %l63, !tbaa !24
  store i64 %t140, ptr %l64, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t147 = load i64, ptr %l64, !tbaa !24
  %t148 = extractvalue { i64, ptr } %t145, 0
  %t149 = mul i64 %t148, 8
  %t150 = mul i64 %t147, 8
  %t151 = extractvalue { i64, ptr } %t145, 1
  %t152 = call ptr @__olang_grow_in_place(ptr %t151, i64 %t149, i64 %t150, i64 %t147)
  %t153 = icmp ne ptr %t152, null
  %t154 = select i1 %t153, i64 %t147, i64 0
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t152, 1
  store { i64, ptr } %t156, ptr %l67, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t160 = icmp ne i64 %t158, 0
  br i1 %t160, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_d83600b5e7480cbf_fab8298361e1a8a3)
  unreachable
bb25:
  %t162 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t162, ptr %l65, !tbaa !27
  br label %bb27
bb26:
  %t163 = load i64, ptr %l64, !tbaa !24
  %t164 = mul i64 %t163, 8
  %t165 = load i64, ptr %l63
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = call ptr @__olang_held_alloc(ptr %t166, i64 %t164)
  %t168 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l65, !tbaa !27
  store i64 0, ptr %l70, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t170 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t173 = icmp eq i64 %t171, 0
  br i1 %t173, label %bb34, label %bb35
bb28:
  %t175 = load i64, ptr %l9, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t181 = icmp slt i64 %t175, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t185 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t185, ptr %l76, !tbaa !27
  %t186 = load i64, ptr %l9, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i64, ptr %t189, i64 %t186
  %t191 = load i64, ptr %t190, !tbaa !34
  %t193 = load i64, ptr %l70, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i64, ptr %t195, i64 %t193
  store i64 %t191, ptr %t196, !tbaa !34
  %t197 = load i64, ptr %l70, !tbaa !24
  %t198 = add i64 %t197, 1
  store i64 %t198, ptr %l70, !tbaa !24
  br label %bb32
bb32:
  %t199 = load i64, ptr %l9, !tbaa !24
  %t202 = add i64 %t199, 1
  store i64 %t202, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
bb34:
  store { i64, ptr } zeroinitializer, ptr %l65, !tbaa !27
  br label %bb35
bb35:
  %t204 = load i64, ptr %l63
  %t205 = inttoptr i64 %t204 to ptr
  %t206 = load { i64, ptr }, ptr %l65
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = call ptr @__olang_region_or(ptr %t207, ptr null)
  %t209 = icmp ne ptr %t208, null
  %t210 = select i1 %t209, ptr %t208, ptr null
  call void @__olang_region_settle_in(ptr %t205, ptr %t210)
  %t211 = load ptr, ptr %l53, !tbaa !29
  %t212 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t211, i32 0, i32 1
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  store { i64, ptr } %t213, ptr %l84, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t215 = load ptr, ptr %l53, !tbaa !29
  %t216 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t215, i32 0, i32 1
  store { i64, ptr } %t214, ptr %t216, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l84
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = extractvalue { i64, ptr } %t217, 1
  call void @__olang_region_release_part(ptr %t219, i64 %t218)
  store { i64, ptr } zeroinitializer, ptr %l84
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H1659232ec5f27314223d5adb35155dd7(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_b1f2e293d1841901_4750c40c7d225ae5)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b1f2e293d1841901_4750c40c7d225ae5)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.7fb975561c60190182bf1dc558f822cc", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 40
  %t60 = mul i64 %t57, 40
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_b1f2e293d1841901_4750c40c7d225ae5)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 40
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.7fb975561c60190182bf1dc558f822cc", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.7fb975561c60190182bf1dc558f822cc", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.7fb975561c60190182bf1dc558f822cc", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.7fb975561c60190182bf1dc558f822cc" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_8908c37f94f41b94_f896b74e367fd488)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_8908c37f94f41b94_f896b74e367fd488)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_8908c37f94f41b94_f896b74e367fd488)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H5d47a9ff77b1816ed60f51933ec989fa(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f2d22541057d02e6_4bf36498492ff95a)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f2d22541057d02e6_4bf36498492ff95a)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.7f41ee1d8873fb5d9e205986eba07862", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 16
  %t60 = mul i64 %t57, 16
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_f2d22541057d02e6_4bf36498492ff95a)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 16
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.7f41ee1d8873fb5d9e205986eba07862", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.7f41ee1d8873fb5d9e205986eba07862", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.7f41ee1d8873fb5d9e205986eba07862", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.7f41ee1d8873fb5d9e205986eba07862" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e021c7dee8d07043_8b1c6ceb7e401ab7)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e021c7dee8d07043_8b1c6ceb7e401ab7)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_e021c7dee8d07043_8b1c6ceb7e401ab7)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H71f9c4c37948dac4a02c48569efe36d8(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca i64
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_153df0a8ead63d0e_a94d5c6d518d2e82)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_153df0a8ead63d0e_a94d5c6d518d2e82)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.6d1319ba4e7d62d710d6eb2bd20b54d6", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 24
  %t58 = mul i64 %t55, 24
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_153df0a8ead63d0e_a94d5c6d518d2e82)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 24
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  store { i64, ptr } %t84, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.6d1319ba4e7d62d710d6eb2bd20b54d6", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.6d1319ba4e7d62d710d6eb2bd20b54d6", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.6d1319ba4e7d62d710d6eb2bd20b54d6", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.6d1319ba4e7d62d710d6eb2bd20b54d6" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_a0ae30da54d0890b_f5bc649b08e23b7f)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_a0ae30da54d0890b_f5bc649b08e23b7f)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  %t142 = call ptr @__olang_region_make_part(ptr %v0)
  %t143 = ptrtoint ptr %t142 to i64
  store i64 %t143, ptr %l63, !tbaa !24
  store i64 %t140, ptr %l64, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t147 = load i64, ptr %l64, !tbaa !24
  %t148 = extractvalue { i64, ptr } %t145, 0
  %t149 = mul i64 %t148, 8
  %t150 = mul i64 %t147, 8
  %t151 = extractvalue { i64, ptr } %t145, 1
  %t152 = call ptr @__olang_grow_in_place(ptr %t151, i64 %t149, i64 %t150, i64 %t147)
  %t153 = icmp ne ptr %t152, null
  %t154 = select i1 %t153, i64 %t147, i64 0
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t152, 1
  store { i64, ptr } %t156, ptr %l67, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t160 = icmp ne i64 %t158, 0
  br i1 %t160, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a0ae30da54d0890b_f5bc649b08e23b7f)
  unreachable
bb25:
  %t162 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t162, ptr %l65, !tbaa !27
  br label %bb27
bb26:
  %t163 = load i64, ptr %l64, !tbaa !24
  %t164 = mul i64 %t163, 8
  %t165 = load i64, ptr %l63
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = call ptr @__olang_held_alloc(ptr %t166, i64 %t164)
  %t168 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l65, !tbaa !27
  store i64 0, ptr %l70, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t170 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t173 = icmp eq i64 %t171, 0
  br i1 %t173, label %bb34, label %bb35
bb28:
  %t175 = load i64, ptr %l9, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t181 = icmp slt i64 %t175, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t185 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t185, ptr %l76, !tbaa !27
  %t186 = load i64, ptr %l9, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i64, ptr %t189, i64 %t186
  %t191 = load i64, ptr %t190, !tbaa !34
  %t193 = load i64, ptr %l70, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i64, ptr %t195, i64 %t193
  store i64 %t191, ptr %t196, !tbaa !34
  %t197 = load i64, ptr %l70, !tbaa !24
  %t198 = add i64 %t197, 1
  store i64 %t198, ptr %l70, !tbaa !24
  br label %bb32
bb32:
  %t199 = load i64, ptr %l9, !tbaa !24
  %t202 = add i64 %t199, 1
  store i64 %t202, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
bb34:
  store { i64, ptr } zeroinitializer, ptr %l65, !tbaa !27
  br label %bb35
bb35:
  %t204 = load i64, ptr %l63
  %t205 = inttoptr i64 %t204 to ptr
  %t206 = load { i64, ptr }, ptr %l65
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = call ptr @__olang_region_or(ptr %t207, ptr null)
  %t209 = icmp ne ptr %t208, null
  %t210 = select i1 %t209, ptr %t208, ptr null
  call void @__olang_region_settle_in(ptr %t205, ptr %t210)
  %t211 = load ptr, ptr %l53, !tbaa !29
  %t212 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t211, i32 0, i32 1
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  store { i64, ptr } %t213, ptr %l84, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t215 = load ptr, ptr %l53, !tbaa !29
  %t216 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t215, i32 0, i32 1
  store { i64, ptr } %t214, ptr %t216, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l84
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = extractvalue { i64, ptr } %t217, 1
  call void @__olang_region_release_part(ptr %t219, i64 %t218)
  store { i64, ptr } zeroinitializer, ptr %l84
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H6ae9068f04760d2472542eec6f80b60f(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f4ca39d23b48ddc0_d428944bb2e0809c)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f4ca39d23b48ddc0_d428944bb2e0809c)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.5542d6b65526e0d56036f5be9fbe5707", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 24
  %t60 = mul i64 %t57, 24
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_f4ca39d23b48ddc0_d428944bb2e0809c)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 24
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.5542d6b65526e0d56036f5be9fbe5707", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.5542d6b65526e0d56036f5be9fbe5707", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.5542d6b65526e0d56036f5be9fbe5707", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.5542d6b65526e0d56036f5be9fbe5707" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_85bf9a49d45aa91d_5f417b4be3707e09)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_85bf9a49d45aa91d_5f417b4be3707e09)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_85bf9a49d45aa91d_5f417b4be3707e09)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H9ca65df0565ef98699181851972a5be4(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_be44e4abb37d4756_842685c925b4a8a)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_be44e4abb37d4756_842685c925b4a8a)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.40558edfe60a5d42211fa379e7d0964c", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 24
  %t60 = mul i64 %t57, 24
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_be44e4abb37d4756_842685c925b4a8a)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 24
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.40558edfe60a5d42211fa379e7d0964c", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.40558edfe60a5d42211fa379e7d0964c", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.40558edfe60a5d42211fa379e7d0964c", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.40558edfe60a5d42211fa379e7d0964c" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_bdae068e8f08bcb3_e871f0f59d7edd67)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_bdae068e8f08bcb3_e871f0f59d7edd67)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_bdae068e8f08bcb3_e871f0f59d7edd67)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2eroom_H68aeeb5e4645698cd8c17639ff15f5a9(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_feef3777c198d7c7_86294585b53bfea3)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_feef3777c198d7c7_86294585b53bfea3)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/generic:AnySlot", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 40
  %t93 = mul i64 %t90, 40
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_feef3777c198d7c7_86294585b53bfea3)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 40
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/generic:AnySlot", ptr %t132, i64 %t129
  %t134 = load %"compiler/generic:AnySlot", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/generic:AnySlot", ptr %t138, i64 %t136
  store %"compiler/generic:AnySlot" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eroo_H58d88ddcdd6f644c144828a9d0bdbf68(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_dcb3fd3f44cef52b_f3a38eace5d78dc7)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_dcb3fd3f44cef52b_f3a38eace5d78dc7)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/generic:instance", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 80
  %t93 = mul i64 %t90, 80
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_dcb3fd3f44cef52b_f3a38eace5d78dc7)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 80
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/generic:instance", ptr %t132, i64 %t129
  %t134 = load %"compiler/generic:instance", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/generic:instance", ptr %t138, i64 %t136
  store %"compiler/generic:instance" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2eroom_3ccompiler_2fgeneric_3avarRow_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_c34983b252bb2a76_4eb9f1c2f2dbb32a)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_c34983b252bb2a76_4eb9f1c2f2dbb32a)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/generic:varRow", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 24
  %t93 = mul i64 %t90, 24
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_c34983b252bb2a76_4eb9f1c2f2dbb32a)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 24
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/generic:varRow", ptr %t132, i64 %t129
  %t134 = load %"compiler/generic:varRow", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/generic:varRow", ptr %t138, i64 %t136
  store %"compiler/generic:varRow" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
define internal i1 @olang_lambda_0(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { ptr, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load { i64, ptr }, ptr %cp1, !tbaa !28
  store { i64, ptr } %cv1, ptr %l3
  %vq0 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t2, ptr %l6, !tbaa !27
  %t5 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr i32, ptr %t6, i64 %a0
  %t8 = load i32, ptr %t7, !tbaa !33
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i32, ptr %t13, i64 %a1
  %t15 = load i32, ptr %t14, !tbaa !33
  %t17 = extractvalue { ptr, ptr } %cv0, 0
  %t18 = extractvalue { ptr, ptr } %cv0, 1
  %t21 = call i1 %t17(ptr %t18, i32 %t8, i32 %t15)
  store i1 %t21, ptr %l12
  br label %bb1
bb1:
  %t22 = load i1, ptr %l12, !tbaa !21
  store i1 %t22, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t23 = load i1, ptr %l4, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_release_part(ptr, i64) noinline
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_grow_in_place(ptr, i64, i64, i64) noinline
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aFnDefault(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/generic:FnDefault"
  %l3 = alloca %"compiler/generic:Context"
  %t3 = alloca %"compiler/generic:Context", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 176, i1 false)
  %t2 = getelementptr %"compiler/generic:FnDefault", ptr %l1, i32 0, i32 2
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %t3, ptr %v0, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %t3, i64 160, i1 false)
  br label %bb1
bb1:
  %t5 = getelementptr %"compiler/generic:FnDefault", ptr %l1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l3, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/generic:Context"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 160, i1 false)
  %t2 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  %t4 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %t2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  %t6 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %t6
  %t7 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %t7)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t11 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare ptr @__olang_scope_mine_slow(ptr) noinline
@G_2estd_2fprelude_2farray_2esortRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\18\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2farray_2esortInsertion_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, ptr %a3c, ptr %a3e)
@G_2estd_2fprelude_2farray_2esortBlock = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\30\00\00\00\00\00\00" }>, align 8
@olang_loc_76034d9107c45234_e5fc9ad4bd22d0c8 = external constant [0 x i8]
@olang_loc_ef7b433399c50f59_19799ad7b52ed855 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2esortMergeBuffered_3cI64_2c_20_3f_3e_clone1_olang_lambda_16955(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fprelude_2farray_2esortPermute_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2farray_2esortSwap_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_a636095cf79013fe_ac8eb0a082fd0652 = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cBool_3e_3e_2eadd_3cI64_2c_20Array_3cBool_3e_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2eroom_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %a0)
@olang_loc_4247c7537790cd68_ca1df51cce72f33c = external constant [0 x i8]
@olang_loc_ecf6018803603945_317c3a2f2a3fcb29 = external constant [0 x i8]
@olang_loc_472096c2de1d38f3_d3b25c2128de691f = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3aFnDefaul_H7b6ff798d6bfbdc8007da25519526074(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
@olang_loc_424e014fd526cac2_9b0d8ae77cce30c6 = external constant [0 x i8]
@olang_loc_d83600b5e7480cbf_fab8298361e1a8a3 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__H9009f93429b3aef40abc291fa3177e1e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eroom_3cI32_2c_20I64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H02407ede99a6674a5c710b5dc85842f1(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H9f95e70f9102dd245b2084c7071394cf(ptr %v0, ptr %a0)
@olang_loc_b1f2e293d1841901_4750c40c7d225ae5 = external constant [0 x i8]
@olang_loc_8908c37f94f41b94_f896b74e367fd488 = external constant [0 x i8]
@olang_loc_f2d22541057d02e6_4bf36498492ff95a = external constant [0 x i8]
@olang_loc_e021c7dee8d07043_8b1c6ceb7e401ab7 = external constant [0 x i8]
@olang_loc_153df0a8ead63d0e_a94d5c6d518d2e82 = external constant [0 x i8]
@olang_loc_a0ae30da54d0890b_f5bc649b08e23b7f = external constant [0 x i8]
@olang_loc_f4ca39d23b48ddc0_d428944bb2e0809c = external constant [0 x i8]
@olang_loc_85bf9a49d45aa91d_5f417b4be3707e09 = external constant [0 x i8]
@olang_loc_be44e4abb37d4756_842685c925b4a8a = external constant [0 x i8]
@olang_loc_bdae068e8f08bcb3_e871f0f59d7edd67 = external constant [0 x i8]
@olang_loc_feef3777c198d7c7_86294585b53bfea3 = external constant [0 x i8]
@olang_loc_dcb3fd3f44cef52b_f3a38eace5d78dc7 = external constant [0 x i8]
@olang_loc_c34983b252bb2a76_4eb9f1c2f2dbb32a = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eroom_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
