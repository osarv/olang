; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i64, i64, i1, i64, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" = type { %"compiler/generic:Origin", i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/typed:SiteInfo" = type { i32, %"compiler/source:Span" }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/check:roOrigin" = type { ptr, i1 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
%"compiler/typed:ScopeRel" = type { i64, i64, %"compiler/source:Span" }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Outlives" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
define dso_local i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 13
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = call i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %t35)
  store i1 %t37, ptr %l19
  br label %bb16
bb16:
  %t38 = load i1, ptr %l19, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t40 = load ptr, ptr %l20, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb18, label %bb19
bb18:
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 22
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb19
bb19:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb20, label %bb21
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = call i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %t54)
  store i1 %t56, ptr %l27
  br label %bb23
bb23:
  %t57 = load i1, ptr %l27, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
bb24:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t25 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t21)
  store i1 %t25, ptr %l16
  br label %bb5
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompares(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 73 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 75 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 77 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0
  %t20 = trunc i64 78 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0
  %t26 = trunc i64 79 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0
  %t32 = trunc i64 80 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l7 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %t4)
  store i64 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i64, ptr %l7, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i1
  %l15 = alloca i32
  %l16 = alloca i1
  %l21 = alloca ptr
  %l26 = alloca i32
  %l29 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l45 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l56 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca ptr
  %l69 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i32, ptr %l15
  store i32 %t23, ptr %l3
  %t24 = load i32, ptr %l3
  %t26 = trunc i64 21 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb48
bb11:
  %t29 = load i32, ptr %l3
  %t31 = trunc i64 19 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l1, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l26
  br label %bb15
bb15:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = add i64 %t45, 1
  %t48 = load ptr, ptr %l21, !tbaa !29
  %t49 = load i32, ptr %l26, !tbaa !23
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %t48, i32 %t49, i64 %t47)
  store i1 %t51, ptr %l29
  br label %bb16
bb16:
  %t52 = load i1, ptr %l29, !tbaa !21
  store i1 %t52, ptr %l16, !tbaa !21
  br label %bb48
bb17:
  %t53 = load i32, ptr %l3
  %t55 = trunc i64 22 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t58 = load i32, ptr %l3
  %t60 = trunc i64 23 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l34, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l37, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l42
  br label %bb23
bb23:
  %t80 = load ptr, ptr %l37, !tbaa !29
  %t81 = load i32, ptr %l42, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t80, i32 %t81)
  store { i64, ptr } %t82, ptr %l43
  br label %bb24
bb24:
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load ptr, ptr %l34, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v0, ptr %t84, { i64, ptr } %t85, i64 %t83)
  store i1 %t87, ptr %l45
  br label %bb25
bb25:
  %t88 = load i1, ptr %l45, !tbaa !21
  store i1 %t88, ptr %l16, !tbaa !21
  br label %bb48
bb26:
  %t89 = load i32, ptr %l3
  %t91 = trunc i64 18 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb43
bb29:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t98 = load i32, ptr %l1, !tbaa !23
  %t101 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l51
  br label %bb30
bb30:
  %t102 = load i1, ptr %l51, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l53, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  store ptr %t109, ptr %l56, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l1, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l61
  br label %bb33
bb32:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb42
bb33:
  %t120 = load ptr, ptr %l56, !tbaa !29
  %t121 = load i32, ptr %l61, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t120, i32 %t121)
  store { i64, ptr } %t122, ptr %l62
  br label %bb34
bb34:
  %t123 = load i64, ptr %l2, !tbaa !24
  %t124 = load ptr, ptr %l53, !tbaa !29
  %t125 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t127 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v0, ptr %t124, { i64, ptr } %t125, i64 %t123)
  store i1 %t127, ptr %l64
  br label %bb35
bb35:
  %t128 = load i1, ptr %l64, !tbaa !21
  br i1 %t128, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb41
bb37:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l66, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  store ptr %t135, ptr %l69, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  %t142 = load i32, ptr %l1, !tbaa !23
  %t145 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t141, i32 %t142)
  store i32 %t145, ptr %l74
  br label %bb38
bb38:
  %t146 = load ptr, ptr %l69, !tbaa !29
  %t147 = load i32, ptr %l74, !tbaa !23
  %t148 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t146, i32 %t147)
  store { i64, ptr } %t148, ptr %l75
  br label %bb39
bb39:
  %t149 = load i64, ptr %l2, !tbaa !24
  %t150 = load ptr, ptr %l66, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t153 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v0, ptr %t150, { i64, ptr } %t151, i64 %t149)
  store i1 %t153, ptr %l77
  br label %bb40
bb40:
  %t154 = load i1, ptr %l77, !tbaa !21
  store i1 %t154, ptr %l65, !tbaa !21
  br label %bb41
bb41:
  %t155 = load i1, ptr %l65, !tbaa !21
  store i1 %t155, ptr %l52, !tbaa !21
  br label %bb42
bb42:
  %t156 = load i1, ptr %l52, !tbaa !21
  store i1 %t156, ptr %l16, !tbaa !21
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_6d92d89bf6179935_a746df8e6ee4ce11)
  unreachable
bb48:
  %t157 = load i1, ptr %l16, !tbaa !21
  store i1 %t157, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseHas(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l10 = alloca i32
  %l15 = alloca i64
  %l17 = alloca i1
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l30 = alloca i32
  %l32 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i1
  %l51 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i32, ptr %l10, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = load i32, ptr %l2, !tbaa !23
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t15, i32 %t16, i32 %t17)
  store i64 %t21, ptr %l15
  br label %bb2
bb2:
  %t22 = load i64, ptr %l15, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb6
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr %l2, !tbaa !23
  %t34 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %t28, i32 %t29, i32 %t30)
  store i64 %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load i64, ptr %l22, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  store i1 %t36, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l17, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l27
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l30
  br label %bb11
bb11:
  %t51 = load i32, ptr %l30, !tbaa !23
  store i32 %t51, ptr %l5, !tbaa !23
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 4, ptr @.d0 })
  store i1 %t54, ptr %l32
  br label %bb12
bb12:
  %t55 = load i1, ptr %l32, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l5, !tbaa !23
  %t65 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t61, i32 %t62)
  store i1 %t65, ptr %l37
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t66 = load i1, ptr %l37, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
bb16:
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t69 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t67, { i64, ptr } { i64 8, ptr @.d1 })
  store i1 %t69, ptr %l39
  br label %bb17
bb17:
  %t70 = load i1, ptr %l39, !tbaa !21
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l5, !tbaa !23
  %t80 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l44
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i1, ptr %l44, !tbaa !21
  store i1 %t81, ptr %rv
  br label %ret
bb21:
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t82, { i64, ptr } { i64 6, ptr @.d2 })
  store i1 %t84, ptr %l46
  br label %bb22
bb22:
  %t85 = load i1, ptr %l46, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %l5, !tbaa !23
  %t95 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t91, i32 %t92)
  store i1 %t95, ptr %l51
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t96 = load i1, ptr %l51, !tbaa !21
  store i1 %t96, ptr %rv
  br label %ret
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebraceAfter(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l10 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l22 = alloca i32
  %l24 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca ptr
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l69 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Case", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Case", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb3:
  call void @__olang_check_failed(ptr @olang_loc_6eddca2d598ce6fb_9d8bffc2796cf667)
  unreachable
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Case", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t29)
  store %"compiler/source:Span" %t31, ptr %l16
  br label %bb6
bb6:
  %t32 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 1
  %t33 = load i32, ptr %t32, !tbaa !23
  store i32 %t33, ptr %l10, !tbaa !23
  br label %bb11
bb7:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Case", ptr %t35, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l24, !tbaa !27
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Case", ptr %t39, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = sub i64 %t44, 1
  %t48 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t53 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t51)
  store %"compiler/source:Span" %t53, ptr %l30
  br label %bb9
bb8:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Case", ptr %t54, i32 0, i32 0
  %t57 = getelementptr %"compiler/source:Span", ptr %t56, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  store i32 %t58, ptr %l22, !tbaa !23
  br label %bb10
bb9:
  %t60 = getelementptr %"compiler/source:Span", ptr %l30, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l22, !tbaa !23
  br label %bb10
bb10:
  %t63 = load i32, ptr %l22, !tbaa !23
  store i32 %t63, ptr %l10, !tbaa !23
  br label %bb11
bb11:
  %t64 = load i32, ptr %l10, !tbaa !23
  store i32 %t64, ptr %l2, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 5
  store ptr %t73, ptr %l37, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t74)
  store ptr %t76, ptr %l39
  br label %bb12
bb12:
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t79 = getelementptr %"compiler/check:frame", ptr %t77, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = load ptr, ptr %l37, !tbaa !29
  %t83 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t81, i64 %t80)
  store ptr %t83, ptr %l42
  br label %bb13
bb13:
  %t84 = load ptr, ptr %l42, !tbaa !29
  %t86 = getelementptr %"compiler/load:Module", ptr %t84, i32 0, i32 6
  %t87 = load ptr, ptr %t86, !tbaa !29
  store ptr %t87, ptr %l3, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f64a0f855cc2648c_4038adf1240cd248)
  unreachable
bb15:
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t96 = getelementptr %"compiler/source:Source", ptr %t93, i32 0, i32 1
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l4, !tbaa !27
  %t99 = load i32, ptr %l2, !tbaa !23
  %t101 = sext i32 %t99 to i64
  store i64 %t101, ptr %l5, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  %t103 = load i64, ptr %l5, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t109 = icmp slt i64 %t103, %t106
  br i1 %t109, label %bb18, label %bb19
bb18:
  %t111 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t111, ptr %l57, !tbaa !27
  %t112 = load i64, ptr %l5, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i8, ptr %t115, i64 %t112
  %t117 = load i8, ptr %t116, !tbaa !32
  %t119 = icmp ne i8 %t117, 123
  store i1 %t119, ptr %l56, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t121 = load i1, ptr %l56, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb22:
  br label %bb23
bb23:
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb24
bb24:
  br label %bb17
bb25:
  %t128 = load i64, ptr %l5, !tbaa !24
  %t130 = trunc i64 %t128 to i32
  %t131 = load i64, ptr %l5, !tbaa !24
  %t133 = add i64 %t131, 1
  %t135 = trunc i64 %t133 to i32
  %t138 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t130, i32 %t135)
  store %"compiler/source:Span" %t138, ptr %l69
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t139 = load %"compiler/source:Span", ptr %l69
  store %"compiler/source:Span" %t139, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l30 = alloca i64
  %l33 = alloca i64
  %l56 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l79 = alloca %"compiler/source:Span"
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/source:Span", ptr %l1
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t2)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb4
bb3:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t13, ptr %l18, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = sub i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp ne i8 %t23, 93
  store i1 %t25, ptr %l17, !tbaa !21
  br label %bb4
bb4:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb10:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l33, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l33, !tbaa !24
  store i64 %t60, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l30, !tbaa !24
  store i64 %t61, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l6, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = sub i64 %t82, 1
  %t88 = sub i64 %t84, %t78
  store i64 %t88, ptr %l10, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t90, ptr %l56, !tbaa !27
  %t91 = load i64, ptr %l10, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i8, ptr %t94, i64 %t91
  %t96 = load i8, ptr %t95, !tbaa !32
  %t98 = icmp eq i8 %t96, 93
  br i1 %t98, label %bb18, label %bb19
bb18:
  %t100 = load i64, ptr %l3, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l3, !tbaa !24
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t104, ptr %l62, !tbaa !27
  %t105 = load i64, ptr %l10, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i8, ptr %t108, i64 %t105
  %t110 = load i8, ptr %t109, !tbaa !32
  %t112 = icmp eq i8 %t110, 91
  br i1 %t112, label %bb21, label %bb22
bb21:
  %t114 = load i64, ptr %l3, !tbaa !24
  %t116 = sub i64 %t114, 1
  store i64 %t116, ptr %l3, !tbaa !24
  %t118 = load i64, ptr %l3, !tbaa !24
  %t120 = icmp eq i64 %t118, 0
  br i1 %t120, label %bb23, label %bb24
bb22:
  br label %bb27
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t122 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t123 = load i32, ptr %t122, !tbaa !23
  %t124 = load i64, ptr %l10, !tbaa !24
  %t126 = trunc i64 %t124 to i32
  %t129 = add i32 %t123, %t126
  %t130 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t131 = load i32, ptr %t130, !tbaa !23
  %t132 = load i64, ptr %l10, !tbaa !24
  %t134 = add i64 %t132, 1
  %t136 = trunc i64 %t134 to i32
  %t139 = add i32 %t131, %t136
  %t142 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t129, i32 %t139)
  store %"compiler/source:Span" %t142, ptr %l79
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  %t143 = load %"compiler/source:Span", ptr %l79
  store %"compiler/source:Span" %t143, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  %t144 = load i64, ptr %l8, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l8, !tbaa !24
  br label %bb14
bb29:
  %t148 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t148, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %a1)
  store %"compiler/source:Span" %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l4
  %t7 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t5, %"compiler/source:Span" %t6, i64 1)
  store %"compiler/source:Span" %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i32
  %l62 = alloca i32
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i32
  %l67 = alloca %"compiler/source:Span"
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l98 = alloca ptr
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l121 = alloca i1
  %l122 = alloca { i64, ptr }
  %l127 = alloca i1
  %l128 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l137 = alloca %"compiler/msgs:Msg"
  %l138 = alloca i64
  %l143 = alloca ptr
  %l146 = alloca i1
  %l147 = alloca { i64, ptr }
  %l153 = alloca i1
  %l156 = alloca i32
  %l158 = alloca i32
  %l160 = alloca i1
  %l161 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca %"compiler/msgs:Msg"
  %l171 = alloca i64
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l181 = alloca { i64, ptr }
  %l183 = alloca %"compiler/msgs:Msg"
  %l184 = alloca i64
  %l189 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t42 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l12, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t12, { i64, ptr } %t13)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t16, %"compiler/source:Span" %t17)
  store ptr %t20, ptr %l20
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load ptr, ptr %l20, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l25
  br label %bb7
bb7:
  %t32 = load i32, ptr %l25
  %t34 = trunc i64 21 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l28, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t38, ptr %l29
  %t39 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t39, ptr %l30
  %t40 = load i32, ptr %l5, !tbaa !23
  store i32 %t40, ptr %l31, !tbaa !23
  %t41 = load ptr, ptr %l3, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [1 x i64] }, ptr %t42, i32 0, i32 0
  store i64 2, ptr %t43
  %t45 = insertvalue { ptr } undef, ptr %t41, 0
  %t46 = getelementptr { i64, [1 x i64] }, ptr %t42, i32 0, i32 1
  store { ptr } %t45, ptr %t46
  %t47 = load { i64, [1 x i64] }, ptr %t42
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store { i64, [1 x i64] } %t47, ptr %t49
  store ptr %t49, ptr %l34, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t50, ptr %l35, !tbaa !27
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb10, label %bb11
bb9:
  br label %bb15
bb10:
  %t53 = icmp sle i64 0, 1152921504606846975
  br i1 %t53, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c23231398495940d_3184fca2d3133de9)
  unreachable
bb12:
  %t55 = mul i64 0, 8
  %t56 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 0, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l28, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l29
  %t61 = load %"compiler/source:Span", ptr %l30
  %t62 = load i32, ptr %l31, !tbaa !23
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %t59, %"compiler/source:Span" %t60, %"compiler/source:Span" %t61, i32 %t62, ptr %t63, i64 -1, ptr null, { i64, ptr } %t64, { i64, ptr } %t58)
  store ptr %t66, ptr %l39
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_c23231398495940d_3184fca2d3133de9)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t67 = load ptr, ptr %l39, !tbaa !29
  store ptr %t67, ptr %rv
  br label %ret
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l41, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l5, !tbaa !23
  %t76 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l44
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/load:Loader", ptr %t83, i32 0, i32 3
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t86, { i64, ptr } { i64 4, ptr @.d3 })
  store i32 %t88, ptr %l49
  br label %bb17
bb17:
  %t89 = load ptr, ptr %l41, !tbaa !29
  %t90 = load i32, ptr %l44, !tbaa !23
  %t91 = load i32, ptr %l49, !tbaa !23
  %t92 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t89, i32 %t90, i32 %t91)
  store i64 %t92, ptr %l50
  br label %bb18
bb18:
  %t93 = load i64, ptr %l50, !tbaa !24
  store i64 %t93, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t96 = icmp slt i64 %t94, 0
  br i1 %t96, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l54, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l5, !tbaa !23
  %t106 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l57
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 3
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s3, ptr %t116, { i64, ptr } { i64 4, ptr @.d4 })
  store i32 %t118, ptr %l62
  br label %bb22
bb22:
  %t119 = load ptr, ptr %l54, !tbaa !29
  %t120 = load i32, ptr %l57, !tbaa !23
  %t121 = load i32, ptr %l62, !tbaa !23
  %t122 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t119, i32 %t120, i32 %t121)
  store i64 %t122, ptr %l63
  br label %bb23
bb23:
  %t123 = load i64, ptr %l63, !tbaa !24
  store i64 %t123, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l64, !tbaa !29
  %t125 = load i64, ptr %l6, !tbaa !24
  store i64 %t125, ptr %l65, !tbaa !24
  %t126 = load i32, ptr %l5, !tbaa !23
  store i32 %t126, ptr %l66, !tbaa !23
  %t127 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t127, ptr %l67
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l2
  %t132 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t128, %"compiler/source:Span" %t129)
  store { i64, ptr } %t132, ptr %l70
  br label %bb25
bb25:
  %t133 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t134 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s0, { i64, ptr } %t133)
  store { i64, ptr } %t134, ptr %l71
  br label %bb26
bb26:
  %t135 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = mul i64 %t136, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t142 = load ptr, ptr %l64, !tbaa !29
  %t143 = load i64, ptr %l65, !tbaa !24
  %t144 = load i32, ptr %l66, !tbaa !23
  %t145 = load %"compiler/source:Span", ptr %l67
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %s0, ptr %s0, ptr %t142, i64 %t143, i32 %t144, { i64, ptr } { i64 4, ptr @.d5 }, %"compiler/source:Span" %t145, { i64, ptr } %t141)
  store i1 %t147, ptr %l73
  br label %bb27
bb27:
  %t148 = load i64, ptr %l6, !tbaa !24
  %t150 = icmp sge i64 %t148, 0
  br i1 %t150, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l76, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l77
  %t154 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t154, ptr %l78
  %t155 = load i64, ptr %l6, !tbaa !24
  store i64 %t155, ptr %l79, !tbaa !24
  %t156 = load ptr, ptr %l3, !tbaa !29
  store ptr %t156, ptr %l81, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t158, ptr %l82, !tbaa !27
  %t159 = icmp sge i64 0, 0
  br i1 %t159, label %bb30, label %bb31
bb29:
  br label %bb39
bb30:
  %t161 = icmp sle i64 0, 1152921504606846975
  br i1 %t161, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_dec816aeadd109e0_adcbe0bcced90c1c)
  unreachable
bb32:
  %t163 = mul i64 0, 8
  %t164 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 0, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l85, !tbaa !27
  %t167 = icmp sge i64 0, 0
  br i1 %t167, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_dec816aeadd109e0_adcbe0bcced90c1c)
  unreachable
bb34:
  %t169 = icmp sle i64 0, 2305843009213693951
  br i1 %t169, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_98ffdf46f6e43303_7907d8ed59f5817f)
  unreachable
bb36:
  %t171 = mul i64 0, 4
  %t172 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 0, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t175 = load ptr, ptr %l76, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l77
  %t177 = load %"compiler/source:Span", ptr %l78
  %t178 = load i64, ptr %l79, !tbaa !24
  %t179 = load ptr, ptr %l81, !tbaa !29
  %t180 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t183 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %s4, ptr %t175, %"compiler/source:Span" %t176, %"compiler/source:Span" %t177, i64 %t178, ptr %t179, { i64, ptr } %t180, { i64, ptr } %t181, { i64, ptr } %t174)
  store ptr %t183, ptr %l89
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_98ffdf46f6e43303_7907d8ed59f5817f)
  unreachable
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t184 = load ptr, ptr %l89, !tbaa !29
  store ptr %t184, ptr %rv
  br label %ret
bb39:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/load:Loader", ptr %t191, i32 0, i32 5
  store ptr %t193, ptr %l93, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t194)
  store ptr %t196, ptr %l95
  br label %bb40
bb40:
  %t197 = load ptr, ptr %l95, !tbaa !29
  %t199 = getelementptr %"compiler/check:frame", ptr %t197, i32 0, i32 1
  %t200 = load i64, ptr %t199, !tbaa !24
  %t201 = load ptr, ptr %l93, !tbaa !29
  %t203 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t201, i64 %t200)
  store ptr %t203, ptr %l98
  br label %bb41
bb41:
  %t204 = load ptr, ptr %l98, !tbaa !29
  %t206 = getelementptr %"compiler/load:Module", ptr %t204, i32 0, i32 6
  %t207 = load ptr, ptr %t206, !tbaa !29
  store ptr %t207, ptr %l7, !tbaa !29
  %t209 = load ptr, ptr %l7, !tbaa !29
  %t211 = icmp eq ptr %t209, null
  br i1 %t211, label %bb42, label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_4b3a1421aaa5396_3ffde41a88bcce4a)
  unreachable
bb43:
  br label %bb44
bb44:
  %t213 = load ptr, ptr %l7, !tbaa !29
  %t216 = getelementptr %"compiler/source:Source", ptr %t213, i32 0, i32 1
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l8, !tbaa !27
  %t219 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t220 = load i32, ptr %t219, !tbaa !23
  %t222 = sext i32 %t220 to i64
  %t224 = sub i64 %t222, 1
  store i64 %t224, ptr %l9, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s5
  %t226 = load i64, ptr %l9, !tbaa !24
  %t228 = icmp sgt i64 %t226, 0
  br i1 %t228, label %bb46, label %bb47
bb46:
  %t230 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t230, ptr %l112, !tbaa !27
  %t231 = load i64, ptr %l9, !tbaa !24
  %t233 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i8, ptr %t234, i64 %t231
  %t236 = load i8, ptr %t235, !tbaa !32
  %t238 = icmp eq i8 %t236, 32
  store i1 %t238, ptr %l111, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb48
bb48:
  %t240 = load i1, ptr %l111, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t243 = load i64, ptr %l9, !tbaa !24
  %t245 = sub i64 %t243, 1
  store i64 %t245, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb52:
  br label %bb45
bb53:
  %t247 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t248 = load i32, ptr %t247, !tbaa !23
  %t250 = icmp sgt i32 %t248, 0
  br i1 %t250, label %bb54, label %bb55
bb54:
  %t252 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t252, ptr %l122, !tbaa !27
  %t253 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t254 = load i32, ptr %t253, !tbaa !23
  %t256 = sext i32 %t254 to i64
  %t258 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i8, ptr %t259, i64 %t256
  %t261 = load i8, ptr %t260, !tbaa !32
  %t263 = icmp eq i8 %t261, 40
  store i1 %t263, ptr %l121, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb56
bb56:
  %t265 = load i1, ptr %l121, !tbaa !21
  br i1 %t265, label %bb57, label %bb58
bb57:
  %t266 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t266, ptr %l128, !tbaa !27
  %t267 = load i64, ptr %l9, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i8, ptr %t270, i64 %t267
  %t272 = load i8, ptr %t271, !tbaa !32
  %t274 = icmp eq i8 %t272, 34
  store i1 %t274, ptr %l127, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb59
bb59:
  %t276 = load i1, ptr %l127, !tbaa !21
  br i1 %t276, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l132, !tbaa !29
  %t278 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t279 = load i32, ptr %t278, !tbaa !23
  %t280 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t281 = load i32, ptr %t280, !tbaa !23
  %t283 = add i32 %t281, 1
  %t286 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t279, i32 %t283)
  store %"compiler/source:Span" %t286, ptr %l136
  br label %bb62
bb61:
  br label %bb67
bb62:
  %t287 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %s6)
  store %"compiler/msgs:Msg" %t287, ptr %l137
  br label %bb63
bb63:
  %t288 = load ptr, ptr %l132, !tbaa !29
  %t289 = load %"compiler/source:Span", ptr %l136
  %t290 = load %"compiler/msgs:Msg", ptr %l137
  %t291 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t288, %"compiler/source:Span" %t289, %"compiler/msgs:Msg" %t290)
  store i64 %t291, ptr %l138
  br label %bb64
bb64:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t292, { i64, ptr } %t293)
  br label %bb65
bb65:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l1
  %t300 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t296, %"compiler/source:Span" %t297)
  store ptr %t300, ptr %l143
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t301 = load ptr, ptr %l143, !tbaa !29
  store ptr %t301, ptr %rv
  br label %ret
bb67:
  %t302 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t303 = load i32, ptr %t302, !tbaa !23
  %t305 = icmp sgt i32 %t303, 0
  br i1 %t305, label %bb68, label %bb69
bb68:
  %t307 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t307, ptr %l147, !tbaa !27
  %t308 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t309 = load i32, ptr %t308, !tbaa !23
  %t311 = sext i32 %t309 to i64
  %t313 = sub i64 %t311, 1
  %t315 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr i8, ptr %t316, i64 %t313
  %t318 = load i8, ptr %t317, !tbaa !32
  %t320 = icmp eq i8 %t318, 36
  br i1 %t320, label %bb70, label %bb71
bb69:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb78
bb70:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i32, ptr %l5, !tbaa !23
  %t326 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t322, i32 %t323)
  store i32 %t326, ptr %l156
  br label %bb72
bb71:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb74
bb72:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t327)
  store i32 %t329, ptr %l158
  br label %bb73
bb73:
  %t330 = load i32, ptr %l156, !tbaa !23
  %t331 = load i32, ptr %l158, !tbaa !23
  %t332 = icmp eq i32 %t330, %t331
  store i1 %t332, ptr %l153, !tbaa !21
  br label %bb74
bb74:
  %t334 = load i1, ptr %l153, !tbaa !21
  br i1 %t334, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l160, !tbaa !21
  br label %bb77
bb76:
  %t335 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t335, ptr %l161, !tbaa !27
  %t336 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t337 = load i32, ptr %t336, !tbaa !23
  %t339 = sext i32 %t337 to i64
  %t341 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr i8, ptr %t342, i64 %t339
  %t344 = load i8, ptr %t343, !tbaa !32
  %t346 = icmp eq i8 %t344, 34
  store i1 %t346, ptr %l160, !tbaa !21
  br label %bb77
bb77:
  %t348 = load i1, ptr %l160, !tbaa !21
  store i1 %t348, ptr %l146, !tbaa !21
  br label %bb78
bb78:
  %t349 = load i1, ptr %l146, !tbaa !21
  br i1 %t349, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s7
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l166, !tbaa !29
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load %"compiler/source:Span", ptr %l2
  %t355 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t351, %"compiler/source:Span" %t352, i64 1)
  store %"compiler/source:Span" %t355, ptr %l169
  br label %bb81
bb80:
  br label %bb86
bb81:
  %t356 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %s7)
  store %"compiler/msgs:Msg" %t356, ptr %l170
  br label %bb82
bb82:
  %t357 = load ptr, ptr %l166, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l169
  %t359 = load %"compiler/msgs:Msg", ptr %l170
  %t360 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t357, %"compiler/source:Span" %t358, %"compiler/msgs:Msg" %t359)
  store i64 %t360, ptr %l171
  br label %bb83
bb83:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t361, { i64, ptr } %t362)
  br label %bb84
bb84:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l1
  %t369 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t365, %"compiler/source:Span" %t366)
  store ptr %t369, ptr %l176
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t370 = load ptr, ptr %l176, !tbaa !29
  store ptr %t370, ptr %rv
  br label %ret
bb86:
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l177, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t372, ptr %l178
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i32, ptr %l5, !tbaa !23
  %t377 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t373, i32 %t374)
  store { i64, ptr } %t377, ptr %l181
  br label %bb87
bb87:
  %t378 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t379 = extractvalue { i64, ptr } %t378, 0
  %t380 = extractvalue { i64, ptr } %t378, 1
  %t381 = mul i64 %t379, 1
  %t382 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t381)
  call void @llvm.memcpy.p0.p0.i64(ptr %t382, ptr %t380, i64 %t381, i1 false)
  %t383 = insertvalue { i64, ptr } undef, i64 %t379, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  %t386 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotCallable(ptr %s0, ptr %s0, { i64, ptr } %t384)
  store %"compiler/msgs:Msg" %t386, ptr %l183
  br label %bb88
bb88:
  %t387 = load ptr, ptr %l177, !tbaa !29
  %t388 = load %"compiler/source:Span", ptr %l178
  %t389 = load %"compiler/msgs:Msg", ptr %l183
  %t390 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t387, %"compiler/source:Span" %t388, %"compiler/msgs:Msg" %t389)
  store i64 %t390, ptr %l184
  br label %bb89
bb89:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t391, { i64, ptr } %t392)
  br label %bb90
bb90:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l1
  %t399 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t395, %"compiler/source:Span" %t396)
  store ptr %t399, ptr %l189
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s0)
  %t400 = load ptr, ptr %l189, !tbaa !29
  store ptr %t400, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeErrors(ptr %v0, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l14 = alloca i32
  %l19 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t16, i64 %t19)
  store i32 %t22, ptr %l14
  br label %bb6
bb6:
  %t23 = load i32, ptr %l14, !tbaa !23
  store i32 %t23, ptr %l4, !tbaa !23
  br label %bb13
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t29, i32 %a2)
  store i32 %t33, ptr %l19
  br label %bb11
bb11:
  %t34 = load i32, ptr %l19, !tbaa !23
  store i32 %t34, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_27c62905650ee804_ddef4b1ccc198ce0)
  unreachable
bb13:
  %t35 = load i32, ptr %l4, !tbaa !23
  store i32 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i64
  %l26 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca { i64, [3 x i64] }
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"compiler/msgs:Msg"
  %l42 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr i8, ptr %t8, i64 0
  %t10 = load i8, ptr %t9, !tbaa !32
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t10)
  store i1 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 12
  %t18 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l13
  br label %bb5
bb5:
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = icmp eq i64 %t19, 0
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb12
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %a1)
  store i32 %t38, ptr %l23
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i32, ptr %l23, !tbaa !23
  %t41 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t41, ptr %l24
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t42)
  store ptr %t44, ptr %l26
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i64, ptr %l24, !tbaa !24
  %t51 = icmp eq i64 %t49, %t48
  store i1 %t51, ptr %l15, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l15, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/load:Loader", ptr %t60, i32 0, i32 4
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t68 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t64, %"compiler/source:Span" %a3)
  store { i64, [3 x i64] } %t68, ptr %l36
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l39
  br label %bb17
bb17:
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  %t76 = extractvalue { i64, ptr } %t74, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  %t82 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsPrivate(ptr %s0, ptr %s0, { i64, ptr } %t80)
  store %"compiler/msgs:Msg" %t82, ptr %l41
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l33, !tbaa !29
  %t84 = load { i64, [3 x i64] }, ptr %l36
  %t85 = load %"compiler/msgs:Msg", ptr %l41
  %t86 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s0, ptr %t83, { i64, [3 x i64] } %t84, %"compiler/msgs:Msg" %t85)
  store i64 %t86, ptr %l42
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %lp16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %lp23 = alloca ptr
  %l26 = alloca i32
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i1
  %l52 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i1
  %l71 = alloca i64
  %l78 = alloca ptr
  %l81 = alloca ptr
  %l84 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l100 = alloca i64
  %l104 = alloca { i64, ptr }
  %l107 = alloca %"compiler/msgs:Msg"
  %l108 = alloca i64
  %l112 = alloca ptr
  %l116 = alloca i1
  %l117 = alloca %"compiler/source:Span"
  %l118 = alloca i32
  %l122 = alloca ptr
  %l127 = alloca ptr
  %l132 = alloca i32
  %l133 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l137 = alloca %"compiler/source:Span"
  %l138 = alloca i32
  %l142 = alloca %"compiler/typed:Payload"
  %l150 = alloca i64
  %l153 = alloca i64
  %l171 = alloca { i64, ptr }
  %l174 = alloca %"compiler/source:Span"
  %l175 = alloca { i64, ptr }
  %l181 = alloca ptr
  %l182 = alloca %"compiler/source:Span"
  %l183 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l193 = alloca ptr
  %l202 = alloca ptr
  %s1 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  %t208 = alloca { i64, [4 x i64] }, align 8
  %t258 = alloca { i64, [4 x i64] }, align 8
  %t339 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i32, ptr %l26, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l28
  br label %bb2
bb2:
  %t10 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t10, ptr %l5
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t12 = load ptr, ptr %l29, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l29, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l30, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l30, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32 }, ptr %t22, i32 0, i32 0
  %t24 = load %"compiler/source:Span", ptr %t23
  store %"compiler/source:Span" %t24, ptr %l6
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32 }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l7, !tbaa !23
  br label %bb7
bb6:
  br label %bb14
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l7, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t32, i32 %t33)
  store { i64, ptr } %t36, ptr %l39
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t37, { i64, ptr } { i64 1, ptr @.d6 })
  store i1 %t38, ptr %l40
  br label %bb9
bb9:
  %t39 = load i1, ptr %l40, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l6
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t40, %"compiler/source:Span" %t41, i32 %t42, i64 1)
  store ptr %t46, ptr %l44
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t47 = load ptr, ptr %l44, !tbaa !29
  store ptr %t47, ptr %rv
  br label %ret
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb72
bb14:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t49 = load ptr, ptr %l45, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l45, !tbaa !29
  %t53 = load i64, ptr %t52
  %t55 = icmp eq i64 %t53, 15
  store i1 %t55, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t56 = load i1, ptr %l46, !tbaa !21
  br i1 %t56, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t57, ptr %t58, i32 %t59)
  store i64 %t63, ptr %l52
  br label %bb20
bb20:
  %t64 = load i64, ptr %l52, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp sge i64 %t65, 0
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l5
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t72 = load i64, ptr %l8, !tbaa !24
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t69, %"compiler/source:Span" %t70, ptr %t71, i64 %t72)
  store ptr %t77, ptr %l59
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t78 = load ptr, ptr %l59, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb24:
  br label %bb72
bb25:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t80 = load ptr, ptr %l60, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l60, !tbaa !29
  %t84 = load i64, ptr %t83
  %t86 = icmp eq i64 %t84, 12
  store i1 %t86, ptr %l61, !tbaa !21
  br label %bb27
bb27:
  %t87 = load i1, ptr %l61, !tbaa !21
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t90, i32 0, i32 1
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l9, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t96, i32 0, i32 2
  %t98 = load { i64, ptr }, ptr %t97
  store { i64, ptr } %t98, ptr %l10, !tbaa !27
  br label %bb30
bb29:
  br label %bb71
bb30:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l9, !tbaa !29
  %t102 = load i32, ptr %l4, !tbaa !23
  %t106 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t100, ptr %t101, i32 %t102)
  store i64 %t106, ptr %l71
  br label %bb31
bb31:
  %t107 = load i64, ptr %l71, !tbaa !24
  store i64 %t107, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = icmp sge i64 %t108, 0
  br i1 %t110, label %bb32, label %bb33
bb32:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l5
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t115 = load i64, ptr %l11, !tbaa !24
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t112, %"compiler/source:Span" %t113, ptr %t114, i64 %t115)
  store ptr %t120, ptr %l78
  br label %bb34
bb33:
  br label %bb70
bb34:
  %t121 = load ptr, ptr %l78, !tbaa !29
  store ptr %t121, ptr %l12, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  store ptr %t127, ptr %l81, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  store ptr %t133, ptr %l84, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = load i32, ptr %l4, !tbaa !23
  %t139 = load i64, ptr %l11, !tbaa !24
  %t143 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t137, i32 %t138, i64 %t139)
  store i32 %t143, ptr %l89
  br label %bb35
bb35:
  %t144 = load ptr, ptr %l84, !tbaa !29
  %t145 = load i32, ptr %l89, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t146, ptr %l90
  br label %bb36
bb36:
  %t147 = load ptr, ptr %l81, !tbaa !29
  %t148 = load i32, ptr %l90, !tbaa !23
  %t149 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t147, i32 %t148)
  store { i64, ptr } %t149, ptr %l91
  br label %bb37
bb37:
  %t150 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t150, ptr %l13, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t159 = icmp ne i64 %t153, %t156
  br i1 %t159, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l97, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t162, ptr %l98
  %t163 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  store i64 %t165, ptr %l100, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t170 = icmp eq i64 %t168, 1
  br i1 %t170, label %bb40, label %bb41
bb39:
  br label %bb46
bb40:
  store { i64, ptr } { i64 0, ptr @.d7 }, ptr %l104, !tbaa !27
  br label %bb42
bb41:
  store { i64, ptr } { i64 1, ptr @.d8 }, ptr %l104, !tbaa !27
  br label %bb42
bb42:
  %t172 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = load i64, ptr %l100, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t178 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s7, ptr %s7, i64 %t175, { i64, ptr } %t176, i64 %t174)
  store %"compiler/msgs:Msg" %t178, ptr %l107
  br label %bb43
bb43:
  %t179 = load ptr, ptr %l97, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l98
  %t181 = load %"compiler/msgs:Msg", ptr %l107
  %t182 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t179, %"compiler/source:Span" %t180, %"compiler/msgs:Msg" %t181)
  store i64 %t182, ptr %l108
  br label %bb44
bb44:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l5
  %t185 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t183, %"compiler/source:Span" %t184, i32 %t185, i64 0)
  store ptr %t189, ptr %l112
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  %t190 = load ptr, ptr %l112, !tbaa !29
  store ptr %t190, ptr %rv
  br label %ret
bb46:
  %t191 = load ptr, ptr %l2, !tbaa !29
  store ptr %t191, ptr %l14, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i32, ptr %l3, !tbaa !23
  %t197 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t193, i32 %t194)
  store i1 %t197, ptr %l116
  br label %bb47
bb47:
  %t198 = load i1, ptr %l116, !tbaa !21
  br i1 %t198, label %bb48, label %bb49
bb48:
  %t199 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t199, ptr %l117
  %t200 = load i32, ptr %l4, !tbaa !23
  store i32 %t200, ptr %l118, !tbaa !23
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l5
  %t203 = load ptr, ptr %l2, !tbaa !29
  %t207 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t201, %"compiler/source:Span" %t202, ptr %t203)
  store ptr %t207, ptr %l122
  br label %bb50
bb49:
  br label %bb51
bb50:
  store { i64, [4 x i64] } zeroinitializer, ptr %t208
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 0
  store i64 2, ptr %t209
  %t210 = load %"compiler/source:Span", ptr %l117
  %t211 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t210, 0
  %t212 = load i32, ptr %l118, !tbaa !23
  %t213 = insertvalue { %"compiler/source:Span", i32, ptr } %t211, i32 %t212, 1
  %t214 = load ptr, ptr %l122, !tbaa !29
  %t215 = insertvalue { %"compiler/source:Span", i32, ptr } %t213, ptr %t214, 2
  %t216 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t215, ptr %t216
  %t217 = load { i64, [4 x i64] }, ptr %t208
  %t219 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t217, ptr %t219
  store ptr %t219, ptr %l14, !tbaa !29
  br label %bb51
bb51:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/generic:Program", ptr %t224, i32 0, i32 2
  store ptr %t226, ptr %l127, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = getelementptr %"compiler/generic:Program", ptr %t230, i32 0, i32 2
  %t233 = load i32, ptr %l4, !tbaa !23
  %t236 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t232, i32 %t233)
  store i32 %t236, ptr %l132
  br label %bb52
bb52:
  %t237 = load ptr, ptr %l127, !tbaa !29
  %t238 = load i32, ptr %l132, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t237, i32 %t238)
  store { i64, ptr } %t239, ptr %l133
  br label %bb53
bb53:
  %t240 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t240, ptr %l134, !tbaa !27
  %t241 = load i64, ptr %l11, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i32, ptr %t244, i64 %t241
  %t246 = load i32, ptr %t245, !tbaa !33
  %t248 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t248, ptr %l137
  store i32 %t246, ptr %l138, !tbaa !23
  %t250 = load ptr, ptr %l14, !tbaa !29
  %t251 = load i64, ptr %l11, !tbaa !24
  %t255 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t250, i64 %t251, i32 0)
  store %"compiler/typed:Payload" %t255, ptr %l142
  br label %bb54
bb54:
  %t256 = load %"compiler/typed:Payload", ptr %l142
  %t257 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t256, ptr %t257
  store { i64, [4 x i64] } zeroinitializer, ptr %t258
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 0
  store i64 5, ptr %t259
  %t260 = load %"compiler/source:Span", ptr %l137
  %t261 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t260, 0
  %t262 = load i32, ptr %l138, !tbaa !23
  %t263 = insertvalue { %"compiler/source:Span", i32, ptr } %t261, i32 %t262, 1
  %t265 = insertvalue { %"compiler/source:Span", i32, ptr } %t263, ptr %t257, 2
  %t266 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t265, ptr %t266
  %t267 = load { i64, [4 x i64] }, ptr %t258
  %t268 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t268, ptr %lp16
  %t270 = load ptr, ptr %lp16
  store { i64, [4 x i64] } %t267, ptr %t270
  store i64 0, ptr %l17, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t271, 0
  store i64 %t273, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t275 = load i64, ptr %l18, !tbaa !24
  %t276 = load i64, ptr %l17, !tbaa !24
  %t279 = icmp sgt i64 %t275, %t276
  br i1 %t279, label %bb55, label %bb56
bb55:
  %t281 = load i64, ptr %l19, !tbaa !24
  %t283 = icmp sgt i64 %t281, 0
  br i1 %t283, label %bb57, label %bb58
bb56:
  store i64 0, ptr %l150, !tbaa !24
  br label %bb60
bb57:
  %t285 = load i64, ptr %l18, !tbaa !24
  %t286 = load i64, ptr %l17, !tbaa !24
  %t289 = sub i64 %t285, %t286
  %t290 = load i64, ptr %l19, !tbaa !24
  %t293 = add i64 %t289, %t290
  %t295 = sub i64 %t293, 1
  %t296 = load i64, ptr %l19, !tbaa !24
  %t299 = sdiv i64 %t295, %t296
  store i64 %t299, ptr %l153, !tbaa !24
  br label %bb59
bb58:
  store i64 0, ptr %l153, !tbaa !24
  br label %bb59
bb59:
  %t301 = load i64, ptr %l153, !tbaa !24
  store i64 %t301, ptr %l150, !tbaa !24
  br label %bb60
bb60:
  %t302 = load i64, ptr %l150, !tbaa !24
  store i64 %t302, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s10
  %t303 = load i64, ptr %l21, !tbaa !24
  %t304 = load i64, ptr %l20, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb69
bb63:
  br label %bb64
bb64:
  %t311 = load i64, ptr %l17, !tbaa !24
  %t312 = load i64, ptr %l21, !tbaa !24
  %t313 = load i64, ptr %l19, !tbaa !24
  %t316 = mul i64 %t312, %t313
  %t319 = add i64 %t311, %t316
  store i64 %t319, ptr %l22, !tbaa !24
  %t321 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t321, ptr %l171, !tbaa !27
  %t322 = load i64, ptr %l22, !tbaa !24
  %t324 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr ptr, ptr %t325, i64 %t322
  %t327 = load ptr, ptr %t326, !tbaa !39
  %t329 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t327)
  store %"compiler/source:Span" %t329, ptr %l174
  br label %bb65
bb65:
  %t330 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t330, ptr %l175, !tbaa !27
  %t331 = load i64, ptr %l22, !tbaa !24
  %t333 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = getelementptr i32, ptr %t334, i64 %t331
  %t336 = load i32, ptr %t335, !tbaa !33
  %t337 = load ptr, ptr %lp16
  %t338 = load i64, ptr %l22, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t339
  %t340 = getelementptr { i64, [4 x i64] }, ptr %t339, i32 0, i32 0
  store i64 3, ptr %t340
  %t341 = load %"compiler/source:Span", ptr %l174
  %t342 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t341, 0
  %t344 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t342, i32 %t336, 1
  %t346 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t344, ptr %t337, 2
  %t348 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t346, i64 %t338, 3
  %t349 = getelementptr { i64, [4 x i64] }, ptr %t339, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t348, ptr %t349
  %t350 = load { i64, [4 x i64] }, ptr %t339
  %t351 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t351, ptr %lp23
  %t353 = load ptr, ptr %lp23
  store { i64, [4 x i64] } %t350, ptr %t353
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l181, !tbaa !29
  %t355 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t355, ptr %l182
  %t356 = load ptr, ptr %l12, !tbaa !29
  store ptr %t356, ptr %l183, !tbaa !29
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t358, ptr %l185, !tbaa !27
  %t359 = load i64, ptr %l22, !tbaa !24
  %t361 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr ptr, ptr %t362, i64 %t359
  %t364 = load ptr, ptr %t363, !tbaa !39
  %t365 = load ptr, ptr %lp23
  %t366 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t366, ptr %l189, !tbaa !27
  %t367 = load i64, ptr %l22, !tbaa !24
  %t369 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = getelementptr i32, ptr %t370, i64 %t367
  %t372 = load i32, ptr %t371, !tbaa !33
  %t377 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v1, ptr %t357, ptr %t364, ptr %t365, i32 %t372)
  store ptr %t377, ptr %l192
  br label %bb66
bb66:
  %t378 = load ptr, ptr %l181, !tbaa !29
  %t379 = load %"compiler/source:Span", ptr %l182
  %t380 = load ptr, ptr %l183, !tbaa !29
  %t381 = load ptr, ptr %l192, !tbaa !29
  %t382 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %t378, %"compiler/source:Span" %t379, ptr %t380, ptr %t381)
  store ptr %t382, ptr %l193
  br label %bb67
bb67:
  %t383 = load ptr, ptr %l193, !tbaa !29
  store ptr %t383, ptr %l12, !tbaa !29
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  %t384 = load i64, ptr %l21, !tbaa !24
  %t386 = add i64 %t384, 1
  store i64 %t386, ptr %l21, !tbaa !24
  br label %bb61
bb69:
  %t388 = load ptr, ptr %l12, !tbaa !29
  store ptr %t388, ptr %rv
  br label %ret
bb70:
  br label %bb72
bb71:
  br label %bb72
bb72:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load %"compiler/source:Span", ptr %l5
  %t392 = load ptr, ptr %l2, !tbaa !29
  %t393 = load ptr, ptr %l1, !tbaa !29
  %t394 = load i32, ptr %l3, !tbaa !23
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %t390, %"compiler/source:Span" %t391, ptr %t392, ptr %t393, i32 %t394)
  store ptr %t400, ptr %l202
  br label %bb73
bb73:
  %t401 = load ptr, ptr %l202, !tbaa !29
  store ptr %t401, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %lp13 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca { i64, ptr }
  %l37 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca i32
  %l46 = alloca ptr
  %l53 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca %"compiler/source:Span"
  %l60 = alloca { i64, ptr }
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca ptr
  %l72 = alloca ptr
  %l74 = alloca i32
  %l78 = alloca i64
  %l81 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l94 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca %"compiler/source:Span"
  %l100 = alloca i32
  %l101 = alloca ptr
  %l105 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l110 = alloca %"compiler/source:Span"
  %l112 = alloca { i64, ptr }
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca i32
  %l123 = alloca { i64, ptr }
  %l126 = alloca %"compiler/typed:Seq"
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca ptr
  %l132 = alloca i64
  %l134 = alloca i64
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca i32
  %l142 = alloca ptr
  %l144 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca %"compiler/typed:Cond"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t171 = alloca { i64, [3 x i64] }, align 8
  %t249 = alloca { i64, [5 x i64] }, align 8
  %t302 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Chain", ptr %t8, i32 0, i32 0
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l19, !tbaa !27
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i32, ptr %t15, i64 %t12
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l7
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l22, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Chain", ptr %t20, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l24, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  %t31 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t29)
  store %"compiler/source:Span" %t31, ptr %l27
  br label %bb1
bb1:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Chain", ptr %t32, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l29, !tbaa !27
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  %t40 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  %t45 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t43)
  store %"compiler/source:Span" %t45, ptr %l33
  br label %bb2
bb2:
  %t46 = load i32, ptr %l7
  %t48 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t46)
  store { i64, ptr } %t48, ptr %l35
  br label %bb3
bb3:
  %t49 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l27
  %t53 = load %"compiler/source:Span", ptr %l33
  %t55 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t51, %"compiler/source:Span" %t52, %"compiler/source:Span" %t53, i64 %t50)
  store %"compiler/source:Span" %t55, ptr %l37
  br label %bb4
bb4:
  %t56 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t56, ptr %l8
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = add i64 %t57, 2
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp sge i64 %t59, %t60
  br i1 %t63, label %bb5, label %bb6
bb5:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l42, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l43
  %t67 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t67, ptr %l44
  %t68 = load i32, ptr %l7
  store i32 %t68, ptr %l45
  %t69 = load ptr, ptr %l5, !tbaa !29
  store ptr %t69, ptr %l46, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 31
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = add i64 %t77, 1
  %t82 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t72, i64 %t79)
  store ptr %t82, ptr %l53
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Chain", ptr %t83, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l55, !tbaa !27
  %t87 = load i64, ptr %l4, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr ptr, ptr %t90, i64 %t87
  %t92 = load ptr, ptr %t91, !tbaa !39
  %t94 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t92)
  store %"compiler/source:Span" %t94, ptr %l58
  br label %bb8
bb8:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Chain", ptr %t95, i32 0, i32 1
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l60, !tbaa !27
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = add i64 %t99, 1
  %t103 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr ptr, ptr %t104, i64 %t101
  %t106 = load ptr, ptr %t105, !tbaa !39
  %t108 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t106)
  store %"compiler/source:Span" %t108, ptr %l64
  br label %bb9
bb9:
  %t109 = load ptr, ptr %l42, !tbaa !29
  %t110 = load %"compiler/source:Span", ptr %l43
  %t111 = load %"compiler/source:Span", ptr %l44
  %t112 = load i32, ptr %l45
  %t113 = load ptr, ptr %l46, !tbaa !29
  %t114 = load ptr, ptr %l53, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l58
  %t116 = load %"compiler/source:Span", ptr %l64
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t109, %"compiler/source:Span" %t110, %"compiler/source:Span" %t111, i32 %t112, ptr %t113, ptr %t114, %"compiler/source:Span" %t115, %"compiler/source:Span" %t116)
  store ptr %t117, ptr %l65
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t118 = load ptr, ptr %l65, !tbaa !29
  store ptr %t118, ptr %rv
  br label %ret
bb11:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 31
  %t122 = load i64, ptr %l3, !tbaa !24
  %t123 = load i64, ptr %l4, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = add i64 %t126, 1
  %t131 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s0, ptr %t121, i64 %t128)
  store ptr %t131, ptr %l72
  br label %bb12
bb12:
  %t132 = load ptr, ptr %l72, !tbaa !29
  %t134 = call i32 @compiler_2fcheck_2etypeOf(ptr %s0, ptr %t132)
  store i32 %t134, ptr %l74
  br label %bb13
bb13:
  %t135 = load i32, ptr %l74, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  %t142 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t136, %"compiler/source:Span" %t137, i32 %t135)
  store i64 %t142, ptr %l78
  br label %bb14
bb14:
  %t143 = load i64, ptr %l78, !tbaa !24
  store i64 %t143, ptr %l10, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 32
  %t148 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l81
  br label %bb15
bb15:
  %t149 = load i64, ptr %l81, !tbaa !24
  store i64 %t149, ptr %l11, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 32
  store ptr %t152, ptr %l83, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l84
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = trunc i64 %t154 to i32
  store i32 %t156, ptr %l87, !tbaa !23
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 31
  %t161 = load i64, ptr %l3, !tbaa !24
  %t162 = load i64, ptr %l4, !tbaa !24
  %t165 = add i64 %t161, %t162
  %t167 = add i64 %t165, 1
  %t170 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t160, i64 %t167)
  store ptr %t170, ptr %l94
  br label %bb16
bb16:
  store { i64, [3 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 0
  store i64 0, ptr %t172
  %t173 = load %"compiler/source:Span", ptr %l84
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t173, 0
  %t175 = load i32, ptr %l87, !tbaa !23
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } %t174, i32 %t175, 1
  %t177 = load ptr, ptr %l94, !tbaa !29
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, ptr %t177, 2
  %t179 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t178, ptr %t179
  %t180 = load { i64, [3 x i64] }, ptr %t171
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t180, ptr %t182
  %t183 = load ptr, ptr %l83, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t183, ptr %t182)
  br label %bb17
bb17:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l97, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t186, ptr %l98
  %t187 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t187, ptr %l99
  %t188 = load i32, ptr %l7
  store i32 %t188, ptr %l100
  %t189 = load ptr, ptr %l5, !tbaa !29
  store ptr %t189, ptr %l101, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t192 = load i64, ptr %l10, !tbaa !24
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t190, %"compiler/source:Span" %t191, i64 %t192)
  store ptr %t196, ptr %l105
  br label %bb18
bb18:
  %t197 = load ptr, ptr %l2, !tbaa !29
  %t199 = getelementptr %"compiler/ast:Chain", ptr %t197, i32 0, i32 1
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  store { i64, ptr } %t200, ptr %l107, !tbaa !27
  %t201 = load i64, ptr %l4, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr ptr, ptr %t204, i64 %t201
  %t206 = load ptr, ptr %t205, !tbaa !39
  %t208 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t206)
  store %"compiler/source:Span" %t208, ptr %l110
  br label %bb19
bb19:
  %t209 = load ptr, ptr %l2, !tbaa !29
  %t211 = getelementptr %"compiler/ast:Chain", ptr %t209, i32 0, i32 1
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l112, !tbaa !27
  %t213 = load i64, ptr %l4, !tbaa !24
  %t215 = add i64 %t213, 1
  %t217 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr ptr, ptr %t218, i64 %t215
  %t220 = load ptr, ptr %t219, !tbaa !39
  %t222 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t220)
  store %"compiler/source:Span" %t222, ptr %l116
  br label %bb20
bb20:
  %t223 = load ptr, ptr %l97, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l98
  %t225 = load %"compiler/source:Span", ptr %l99
  %t226 = load i32, ptr %l100
  %t227 = load ptr, ptr %l101, !tbaa !29
  %t228 = load ptr, ptr %l105, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l110
  %t230 = load %"compiler/source:Span", ptr %l116
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t223, %"compiler/source:Span" %t224, %"compiler/source:Span" %t225, i32 %t226, ptr %t227, ptr %t228, %"compiler/source:Span" %t229, %"compiler/source:Span" %t230)
  store ptr %t231, ptr %l117
  br label %bb21
bb21:
  %t232 = load ptr, ptr %l117, !tbaa !29
  store ptr %t232, ptr %l12, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t233, ptr %l118
  %t234 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t234, ptr %l119, !tbaa !23
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 32
  %t238 = load i64, ptr %l11, !tbaa !24
  %t241 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t237, i64 %t238)
  store { i64, ptr } %t241, ptr %l123
  br label %bb22
bb22:
  %t242 = load ptr, ptr %l12, !tbaa !29
  %t244 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t246 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t244, ptr %t242)
  store %"compiler/typed:Seq" %t246, ptr %l126
  br label %bb23
bb23:
  %t247 = load %"compiler/typed:Seq", ptr %l126
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t247, ptr %t248
  store { i64, [5 x i64] } zeroinitializer, ptr %t249
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t249, i32 0, i32 0
  store i64 12, ptr %t250
  %t251 = load %"compiler/source:Span", ptr %l118
  %t252 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t251, 0
  %t253 = load i32, ptr %l119, !tbaa !23
  %t254 = insertvalue { %"compiler/source:Span", i32, ptr } %t252, i32 %t253, 1
  %t256 = insertvalue { %"compiler/source:Span", i32, ptr } %t254, ptr %t248, 2
  %t257 = getelementptr { i64, [5 x i64] }, ptr %t249, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t256, ptr %t257
  %t258 = load { i64, [5 x i64] }, ptr %t249
  %t259 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t259, ptr %lp13
  %t261 = load ptr, ptr %lp13
  store { i64, [5 x i64] } %t258, ptr %t261
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l129, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t263, ptr %l130
  %t264 = load ptr, ptr %l2, !tbaa !29
  store ptr %t264, ptr %l131, !tbaa !29
  %t265 = load i64, ptr %l3, !tbaa !24
  store i64 %t265, ptr %l132, !tbaa !24
  %t266 = load i64, ptr %l4, !tbaa !24
  %t268 = add i64 %t266, 1
  store i64 %t268, ptr %l134, !tbaa !24
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  %t271 = load i64, ptr %l10, !tbaa !24
  %t275 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t269, %"compiler/source:Span" %t270, i64 %t271)
  store ptr %t275, ptr %l138
  br label %bb24
bb24:
  %t276 = load ptr, ptr %l129, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l130
  %t278 = load ptr, ptr %l131, !tbaa !29
  %t279 = load i64, ptr %l132, !tbaa !24
  %t280 = load i64, ptr %l134, !tbaa !24
  %t281 = load ptr, ptr %l138, !tbaa !29
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %t276, %"compiler/source:Span" %t277, ptr %t278, i64 %t279, i64 %t280, ptr %t281)
  store ptr %t282, ptr %l139
  br label %bb25
bb25:
  %t283 = load ptr, ptr %l139, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t284, ptr %l140
  %t285 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t285, ptr %l141, !tbaa !23
  %t286 = load ptr, ptr %lp13
  store ptr %t286, ptr %l142, !tbaa !29
  store ptr %t283, ptr %l144, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load %"compiler/source:Span", ptr %l1
  %t291 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t295 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t289, %"compiler/source:Span" %t290, i32 %t291, i64 0)
  store ptr %t295, ptr %l148
  br label %bb26
bb26:
  %t296 = load ptr, ptr %l142, !tbaa !29
  %t297 = load ptr, ptr %l144, !tbaa !29
  %t298 = load ptr, ptr %l148, !tbaa !29
  %t299 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t296, ptr %t297, ptr %t298)
  store %"compiler/typed:Cond" %t299, ptr %l149
  br label %bb27
bb27:
  %t300 = load %"compiler/typed:Cond", ptr %l149
  %t301 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t300, ptr %t301
  store { i64, [5 x i64] } zeroinitializer, ptr %t302
  %t303 = getelementptr { i64, [5 x i64] }, ptr %t302, i32 0, i32 0
  store i64 11, ptr %t303
  %t304 = load %"compiler/source:Span", ptr %l140
  %t305 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t304, 0
  %t306 = load i32, ptr %l141, !tbaa !23
  %t307 = insertvalue { %"compiler/source:Span", i32, ptr } %t305, i32 %t306, 1
  %t309 = insertvalue { %"compiler/source:Span", i32, ptr } %t307, ptr %t301, 2
  %t310 = getelementptr { i64, [5 x i64] }, ptr %t302, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t309, ptr %t310
  %t311 = load { i64, [5 x i64] }, ptr %t302
  %t313 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t311, ptr %t313
  call void @__olang_scope_close(ptr %s0)
  store ptr %t313, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckCtor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca %"compiler/generic:Origin"
  %l5 = alloca i1
  %l9 = alloca %"compiler/generic:Origin"
  %l12 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l25 = alloca i32
  %l31 = alloca ptr
  %l37 = alloca { i64, [3 x i64] }
  %l40 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %t69 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %t4, i32 %t5)
  store %"compiler/generic:Origin" %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load %"compiler/generic:Origin", ptr %l9
  store %"compiler/generic:Origin" %t9, ptr %l4
  %t10 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l17
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t25 = load i32, ptr %l17
  %t27 = trunc i64 18 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t30 = load i1, ptr %l12, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l2, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l25
  br label %bb8
bb7:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t41 = load i32, ptr %l25, !tbaa !23
  %t42 = icmp ne i32 %t41, 0
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t44 = load i1, ptr %l20, !tbaa !21
  store i1 %t44, ptr %l5, !tbaa !21
  %t45 = load i1, ptr %l5, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/load:Loader", ptr %t53, i32 0, i32 4
  %t56 = load ptr, ptr %t55, !tbaa !29
  store ptr %t56, ptr %l31, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 0
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 1
  %t60 = getelementptr %"compiler/source:Span", ptr %t59, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t63 = sext i32 %t61 to i64
  %t64 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 1
  %t65 = getelementptr %"compiler/source:Span", ptr %t64, i32 0, i32 1
  %t66 = load i32, ptr %t65, !tbaa !23
  %t68 = sext i32 %t66 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t69
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t69, i32 0, i32 0
  store i64 3, ptr %t70
  %t72 = insertvalue { i64, i64, i64 } undef, i64 %t58, 0
  %t74 = insertvalue { i64, i64, i64 } %t72, i64 %t63, 1
  %t76 = insertvalue { i64, i64, i64 } %t74, i64 %t68, 2
  %t77 = getelementptr { i64, [3 x i64] }, ptr %t69, i32 0, i32 1
  store { i64, i64, i64 } %t76, ptr %t77
  %t78 = load { i64, [3 x i64] }, ptr %t69
  store { i64, [3 x i64] } %t78, ptr %l37
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeInstNote(ptr %v0, ptr %s1, ptr %t79, i32 %t80)
  store { i64, ptr } %t83, ptr %l40
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t84 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load ptr, ptr %l31, !tbaa !29
  %t92 = load { i64, [3 x i64] }, ptr %l37
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %s1, ptr %t91, { i64, [3 x i64] } %t92, { i64, ptr } %t90)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorChecked(ptr %v0, ptr %t94, i64 %a1, i32 %t96, i32 %a3)
  br label %bb15
bb15:
  %t102 = load i1, ptr %l5, !tbaa !21
  br i1 %t102, label %bb16, label %bb17
bb16:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/load:Loader", ptr %t110, i32 0, i32 4
  %t113 = load ptr, ptr %t112, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %t113)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedForm(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l12 = alloca i64
  %l17 = alloca ptr
  %l25 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = extractvalue { i64, ptr } { i64 7, ptr @.d9 }, 1
  %t5 = extractvalue { i64, ptr } { i64 7, ptr @.d9 }, 0
  %t7 = extractvalue { i64, ptr } %a2, 1
  %t8 = extractvalue { i64, ptr } %a2, 0
  %t9 = add i64 %t5, %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t4, i64 %t5)
  %t11 = getelementptr i8, ptr %t10, i64 %t5
  call void @olang_textcopy(ptr %t11, ptr %t7, i64 %t8)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t10, 1
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t16 = extractvalue { i64, ptr } %t13, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t26 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t1, i32 %a1, { i64, ptr } %t20, i64 %a3)
  store i64 %t26, ptr %l12
  br label %bb1
bb1:
  %t27 = load i64, ptr %l12, !tbaa !24
  store i64 %t27, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp slt i64 %t28, 0
  br i1 %t30, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t33)
  store ptr %t35, ptr %l17
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l17, !tbaa !29
  store ptr %t36, ptr %l5, !tbaa !29
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 16
  %t40 = load i64, ptr %t39, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb6, label %bb7
bb6:
  %t44 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t44, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t46 = load ptr, ptr %l5, !tbaa !29
  %t48 = getelementptr %"compiler/check:frame", ptr %t46, i32 0, i32 15
  %t49 = load i64, ptr %t48, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l25, !tbaa !29
  %t54 = load ptr, ptr %l25, !tbaa !29
  %t55 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 18
  %t56 = load i64, ptr %t55, !tbaa !24
  %t58 = add i64 %t56, 1
  %t60 = load ptr, ptr %l25, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 18
  store i64 %t58, ptr %t61, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echosenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l17 = alloca i1
  %l23 = alloca %"compiler/source:Span"
  %l27 = alloca i1
  %l33 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb28
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Cond", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Cond", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb12
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593)
  unreachable
bb9:
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Cond", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t41)
  store %"compiler/source:Span" %t43, ptr %l23
  br label %bb11
bb11:
  %t44 = getelementptr %"compiler/source:Span", ptr %l23, i32 0, i32 1
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t50 = icmp sle i32 %t45, %t47
  store i1 %t50, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l17, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Cond", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593)
  unreachable
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Cond", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l33
  br label %bb18
bb18:
  %t66 = getelementptr %"compiler/source:Span", ptr %l33, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t68 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t72 = icmp eq i32 %t67, %t69
  store i1 %t72, ptr %l27, !tbaa !21
  br label %bb19
bb19:
  %t74 = load i1, ptr %l27, !tbaa !21
  br i1 %t74, label %bb20, label %bb21
bb20:
  store ptr %a0, ptr %l37, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Cond", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  br i1 %t81, label %bb22, label %bb23
bb21:
  br label %bb27
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593)
  unreachable
bb23:
  br label %bb24
bb24:
  %t83 = load ptr, ptr %l3, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Cond", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t86)
  store %"compiler/source:Span" %t88, ptr %l43
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l37, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l43
  %t91 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t89, %"compiler/source:Span" %t90, i64 2)
  store %"compiler/source:Span" %t91, ptr %l44
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t92 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t92, ptr %rv
  br label %ret
bb27:
  br label %bb36
bb28:
  %t93 = load ptr, ptr %l1, !tbaa !29
  store ptr %t93, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t97 = load ptr, ptr %l45, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 13
  store i1 %t100, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t101 = load i1, ptr %l46, !tbaa !21
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l4
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s3
  %t108 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t111 = load i32, ptr %t110, !tbaa !23
  %t113 = add i32 %t111, 5
  %t116 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t109, i32 %t113)
  store %"compiler/source:Span" %t116, ptr %l54
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load %"compiler/source:Span", ptr %l54
  store %"compiler/source:Span" %t117, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t118 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t118, ptr %l55
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  %t119 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t119, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca i32
  %l97 = alloca ptr
  %l101 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca i1
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca i32
  %l119 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca i1
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l138 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca %"compiler/typed:Promote"
  %l148 = alloca ptr
  %l149 = alloca i1
  %l158 = alloca %"compiler/source:Span"
  %l159 = alloca i32
  %l161 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l168 = alloca { i64, [2 x i64] }
  %l173 = alloca i32
  %l176 = alloca %"compiler/typed:Call"
  %l180 = alloca ptr
  %l181 = alloca i1
  %l194 = alloca { i64, ptr }
  %l199 = alloca ptr
  %l206 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca i32
  %l211 = alloca i32
  %l213 = alloca i64
  %l214 = alloca { i64, ptr }
  %l215 = alloca ptr
  %l220 = alloca i32
  %l223 = alloca %"compiler/typed:Make"
  %l227 = alloca ptr
  %l228 = alloca i1
  %l241 = alloca %"compiler/source:Span"
  %l242 = alloca i32
  %l243 = alloca i32
  %l244 = alloca i32
  %l248 = alloca { i64, ptr }
  %l251 = alloca ptr
  %l252 = alloca i1
  %l261 = alloca %"compiler/source:Span"
  %l262 = alloca i32
  %l267 = alloca ptr
  %l272 = alloca ptr
  %l277 = alloca ptr
  %l280 = alloca %"compiler/typed:Slice"
  %l284 = alloca ptr
  %l285 = alloca i1
  %l298 = alloca ptr
  %l305 = alloca ptr
  %l307 = alloca %"compiler/source:Span"
  %l308 = alloca i32
  %l313 = alloca ptr
  %l314 = alloca ptr
  %l319 = alloca ptr
  %l320 = alloca %"compiler/typed:Cond"
  %l324 = alloca ptr
  %l325 = alloca i1
  %l334 = alloca %"compiler/source:Span"
  %l335 = alloca i64
  %l339 = alloca ptr
  %l342 = alloca ptr
  %l343 = alloca i1
  %l352 = alloca ptr
  %l353 = alloca i1
  %l365 = alloca ptr
  %l367 = alloca %"compiler/source:Span"
  %l368 = alloca ptr
  %rv = alloca ptr
  %t31 = alloca { i64, [5 x i64] }, align 8
  %t81 = alloca { i64, [5 x i64] }, align 8
  %t145 = alloca { i64, [5 x i64] }, align 8
  %t196 = alloca { i64, [5 x i64] }, align 8
  %t263 = alloca { i64, [5 x i64] }, align 8
  %t345 = alloca { i64, [5 x i64] }, align 8
  %t459 = alloca { i64, [5 x i64] }, align 8
  %t522 = alloca { i64, [5 x i64] }, align 8
  %t609 = alloca { i64, [5 x i64] }, align 8
  %t706 = alloca { i64, [5 x i64] }, align 8
  %t755 = alloca { i64, [5 x i64] }, align 8
  %t813 = alloca { i64, [4 x i64] }, align 8
  %t821 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t2 = load ptr, ptr %l47, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l47, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l48, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l48, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t24, i32 0, i32 2
  %t26 = load i64, ptr %t25
  store i64 %t26, ptr %l5, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t28 = load %"compiler/source:Span", ptr %l3
  %t29 = load i32, ptr %l4, !tbaa !23
  %t30 = load i64, ptr %l5, !tbaa !24
  store { i64, [5 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t34 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t28, 0
  %t36 = insertvalue { %"compiler/source:Span", i32, i64 } %t34, i32 %t29, 1
  %t38 = insertvalue { %"compiler/source:Span", i32, i64 } %t36, i64 %t30, 2
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t38, ptr %t39
  %t40 = load { i64, [5 x i64] }, ptr %t31
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t40, ptr %t42
  store ptr %t42, ptr %rv
  br label %ret
bb6:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t45 = load ptr, ptr %l62, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load ptr, ptr %l62, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 1
  store i1 %t51, ptr %l63, !tbaa !21
  br label %bb8
bb8:
  %t52 = load i1, ptr %l63, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l6
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l7, !tbaa !23
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load i64, ptr %t68
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t73, i32 0, i32 3
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l9, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t77 = load %"compiler/source:Span", ptr %l6
  %t78 = load i32, ptr %l7, !tbaa !23
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load ptr, ptr %l9, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 0
  store i64 1, ptr %t82
  %t84 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t77, 0
  %t86 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t84, i32 %t78, 1
  %t88 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t86, i64 %t79, 2
  %t90 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t88, ptr %t80, 3
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t90, ptr %t91
  %t92 = load { i64, [5 x i64] }, ptr %t81
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t92, ptr %t94
  store ptr %t94, ptr %rv
  br label %ret
bb12:
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t97 = load ptr, ptr %l80, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb13, label %bb14
bb13:
  %t100 = load ptr, ptr %l80, !tbaa !29
  %t101 = load i64, ptr %t100
  %t103 = icmp eq i64 %t101, 2
  store i1 %t103, ptr %l81, !tbaa !21
  br label %bb14
bb14:
  %t104 = load i1, ptr %l81, !tbaa !21
  br i1 %t104, label %bb15, label %bb16
bb15:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t107, i32 0, i32 0
  %t109 = load %"compiler/source:Span", ptr %t108
  store %"compiler/source:Span" %t109, ptr %l10
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t113, i32 0, i32 1
  %t115 = load i32, ptr %t114
  store i32 %t115, ptr %l11, !tbaa !23
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l12, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t125, i32 0, i32 3
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l13, !tbaa !23
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t129 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t129, ptr %l92
  %t130 = load i32, ptr %l11, !tbaa !23
  store i32 %t130, ptr %l93, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t133 = load i64, ptr %l2, !tbaa !24
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %t131, ptr %t132, i64 %t133)
  store ptr %t137, ptr %l97
  br label %bb18
bb18:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l13, !tbaa !23
  %t140 = load i64, ptr %l2, !tbaa !24
  %t144 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t138, i32 %t139, i64 %t140)
  store i32 %t144, ptr %l101
  br label %bb19
bb19:
  store { i64, [5 x i64] } zeroinitializer, ptr %t145
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 0
  store i64 2, ptr %t146
  %t147 = load %"compiler/source:Span", ptr %l92
  %t148 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t147, 0
  %t149 = load i32, ptr %l93, !tbaa !23
  %t150 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t148, i32 %t149, 1
  %t151 = load ptr, ptr %l97, !tbaa !29
  %t152 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t150, ptr %t151, 2
  %t153 = load i32, ptr %l101, !tbaa !23
  %t154 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t152, i32 %t153, 3
  %t155 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t154, ptr %t155
  %t156 = load { i64, [5 x i64] }, ptr %t145
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t156, ptr %t158
  store ptr %t158, ptr %rv
  br label %ret
bb20:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t161 = load ptr, ptr %l104, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb21, label %bb22
bb21:
  %t164 = load ptr, ptr %l104, !tbaa !29
  %t165 = load i64, ptr %t164
  %t167 = icmp eq i64 %t165, 3
  store i1 %t167, ptr %l105, !tbaa !21
  br label %bb22
bb22:
  %t168 = load i1, ptr %l105, !tbaa !21
  br i1 %t168, label %bb23, label %bb24
bb23:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [5 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t171, i32 0, i32 0
  %t173 = load %"compiler/source:Span", ptr %t172
  store %"compiler/source:Span" %t173, ptr %l14
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [5 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t177, i32 0, i32 1
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l15, !tbaa !23
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t183, i32 0, i32 2
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l16, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t187 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t187, ptr %l114
  %t188 = load i32, ptr %l15, !tbaa !23
  store i32 %t188, ptr %l115, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l16, !tbaa !29
  %t191 = load i64, ptr %l2, !tbaa !24
  %t195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %t189, ptr %t190, i64 %t191)
  store ptr %t195, ptr %l119
  br label %bb26
bb26:
  store { i64, [5 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 0
  store i64 3, ptr %t197
  %t198 = load %"compiler/source:Span", ptr %l114
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t198, 0
  %t200 = load i32, ptr %l115, !tbaa !23
  %t201 = insertvalue { %"compiler/source:Span", i32, ptr } %t199, i32 %t200, 1
  %t202 = load ptr, ptr %l119, !tbaa !29
  %t203 = insertvalue { %"compiler/source:Span", i32, ptr } %t201, ptr %t202, 2
  %t204 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t203, ptr %t204
  %t205 = load { i64, [5 x i64] }, ptr %t196
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t205, ptr %t207
  store ptr %t207, ptr %rv
  br label %ret
bb27:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t210 = load ptr, ptr %l122, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb28, label %bb29
bb28:
  %t213 = load ptr, ptr %l122, !tbaa !29
  %t214 = load i64, ptr %t213
  %t216 = icmp eq i64 %t214, 5
  store i1 %t216, ptr %l123, !tbaa !21
  br label %bb29
bb29:
  %t217 = load i1, ptr %l123, !tbaa !21
  br i1 %t217, label %bb30, label %bb31
bb30:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t220, i32 0, i32 0
  %t222 = load %"compiler/source:Span", ptr %t221
  store %"compiler/source:Span" %t222, ptr %l17
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [5 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t226, i32 0, i32 1
  %t228 = load i32, ptr %t227
  store i32 %t228, ptr %l18, !tbaa !23
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr { i64, [5 x i64] }, ptr %t230, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t232, i32 0, i32 2
  %t234 = load ptr, ptr %t233
  store ptr %t234, ptr %l19, !tbaa !29
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t236 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t236, ptr %l132
  %t237 = load i32, ptr %l18, !tbaa !23
  store i32 %t237, ptr %l133, !tbaa !23
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l19, !tbaa !29
  %t241 = getelementptr %"compiler/typed:Promote", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t243 = load i64, ptr %l2, !tbaa !24
  %t247 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t238, ptr %t242, i64 %t243)
  store ptr %t247, ptr %l138
  br label %bb33
bb33:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l19, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Promote", ptr %t249, i32 0, i32 1
  %t252 = load i32, ptr %t251, !tbaa !23
  %t253 = load i64, ptr %l2, !tbaa !24
  %t257 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t248, i32 %t252, i64 %t253)
  store i32 %t257, ptr %l143
  br label %bb34
bb34:
  %t258 = load ptr, ptr %l138, !tbaa !29
  %t259 = load i32, ptr %l143, !tbaa !23
  %t260 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v0, ptr %t258, i32 %t259)
  store %"compiler/typed:Promote" %t260, ptr %l144
  br label %bb35
bb35:
  %t261 = load %"compiler/typed:Promote", ptr %l144
  %t262 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Promote" %t261, ptr %t262
  store { i64, [5 x i64] } zeroinitializer, ptr %t263
  %t264 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 0
  store i64 5, ptr %t264
  %t265 = load %"compiler/source:Span", ptr %l132
  %t266 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t265, 0
  %t267 = load i32, ptr %l133, !tbaa !23
  %t268 = insertvalue { %"compiler/source:Span", i32, ptr } %t266, i32 %t267, 1
  %t270 = insertvalue { %"compiler/source:Span", i32, ptr } %t268, ptr %t262, 2
  %t271 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t270, ptr %t271
  %t272 = load { i64, [5 x i64] }, ptr %t263
  %t274 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t272, ptr %t274
  store ptr %t274, ptr %rv
  br label %ret
bb36:
  %t276 = load ptr, ptr %l1, !tbaa !29
  store ptr %t276, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t277 = load ptr, ptr %l148, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb37, label %bb38
bb37:
  %t280 = load ptr, ptr %l148, !tbaa !29
  %t281 = load i64, ptr %t280
  %t283 = icmp eq i64 %t281, 6
  store i1 %t283, ptr %l149, !tbaa !21
  br label %bb38
bb38:
  %t284 = load i1, ptr %l149, !tbaa !21
  br i1 %t284, label %bb39, label %bb40
bb39:
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr { i64, [5 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t287, i32 0, i32 0
  %t289 = load %"compiler/source:Span", ptr %t288
  store %"compiler/source:Span" %t289, ptr %l20
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [5 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t293, i32 0, i32 1
  %t295 = load i32, ptr %t294
  store i32 %t295, ptr %l21, !tbaa !23
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr { i64, [5 x i64] }, ptr %t297, i32 0, i32 1
  %t300 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t299, i32 0, i32 2
  %t301 = load ptr, ptr %t300
  store ptr %t301, ptr %l22, !tbaa !29
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t303 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t303, ptr %l158
  %t304 = load i32, ptr %l21, !tbaa !23
  store i32 %t304, ptr %l159, !tbaa !23
  %t305 = load ptr, ptr %l22, !tbaa !29
  %t307 = getelementptr %"compiler/typed:Call", ptr %t305, i32 0, i32 0
  %t308 = load ptr, ptr %t307, !tbaa !29
  store ptr %t308, ptr %l161, !tbaa !29
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l22, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Call", ptr %t310, i32 0, i32 1
  %t313 = load { i64, ptr }, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l2, !tbaa !24
  %t318 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %t309, { i64, ptr } %t313, i64 %t314)
  store { i64, ptr } %t318, ptr %l166
  br label %bb42
bb42:
  %t319 = load ptr, ptr %l22, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Call", ptr %t319, i32 0, i32 2
  %t322 = load { i64, [2 x i64] }, ptr %t321
  store { i64, [2 x i64] } %t322, ptr %l168
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l22, !tbaa !29
  %t326 = getelementptr %"compiler/typed:Call", ptr %t324, i32 0, i32 3
  %t327 = load i32, ptr %t326, !tbaa !23
  %t328 = load i64, ptr %l2, !tbaa !24
  %t332 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t323, i32 %t327, i64 %t328)
  store i32 %t332, ptr %l173
  br label %bb43
bb43:
  %t333 = load ptr, ptr %l22, !tbaa !29
  %t335 = getelementptr %"compiler/typed:Call", ptr %t333, i32 0, i32 4
  %t336 = load i1, ptr %t335, !tbaa !21
  %t337 = load ptr, ptr %l161, !tbaa !29
  %t338 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t339 = load { i64, [2 x i64] }, ptr %l168
  %t340 = load i32, ptr %l173, !tbaa !23
  %t342 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v1, ptr %v0, ptr %v0, ptr %t337, { i64, ptr } %t338, { i64, [2 x i64] } %t339, i32 %t340, i1 %t336, i1 false)
  store %"compiler/typed:Call" %t342, ptr %l176
  br label %bb44
bb44:
  %t343 = load %"compiler/typed:Call", ptr %l176
  %t344 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t343, ptr %t344
  store { i64, [5 x i64] } zeroinitializer, ptr %t345
  %t346 = getelementptr { i64, [5 x i64] }, ptr %t345, i32 0, i32 0
  store i64 6, ptr %t346
  %t347 = load %"compiler/source:Span", ptr %l158
  %t348 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t347, 0
  %t349 = load i32, ptr %l159, !tbaa !23
  %t350 = insertvalue { %"compiler/source:Span", i32, ptr } %t348, i32 %t349, 1
  %t352 = insertvalue { %"compiler/source:Span", i32, ptr } %t350, ptr %t344, 2
  %t353 = getelementptr { i64, [5 x i64] }, ptr %t345, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t352, ptr %t353
  %t354 = load { i64, [5 x i64] }, ptr %t345
  %t356 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t354, ptr %t356
  store ptr %t356, ptr %rv
  br label %ret
bb45:
  %t358 = load ptr, ptr %l1, !tbaa !29
  store ptr %t358, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t359 = load ptr, ptr %l180, !tbaa !29
  %t360 = icmp ne ptr %t359, null
  br i1 %t360, label %bb46, label %bb47
bb46:
  %t362 = load ptr, ptr %l180, !tbaa !29
  %t363 = load i64, ptr %t362
  %t365 = icmp eq i64 %t363, 7
  store i1 %t365, ptr %l181, !tbaa !21
  br label %bb47
bb47:
  %t366 = load i1, ptr %l181, !tbaa !21
  br i1 %t366, label %bb48, label %bb49
bb48:
  %t367 = load ptr, ptr %l1, !tbaa !29
  %t369 = getelementptr { i64, [5 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t369, i32 0, i32 0
  %t371 = load %"compiler/source:Span", ptr %t370
  store %"compiler/source:Span" %t371, ptr %l23
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [5 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t375, i32 0, i32 1
  %t377 = load i32, ptr %t376
  store i32 %t377, ptr %l24, !tbaa !23
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [5 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t381, i32 0, i32 2
  %t383 = load ptr, ptr %t382
  store ptr %t383, ptr %l25, !tbaa !29
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l25, !tbaa !29
  %t388 = getelementptr %"compiler/typed:Make", ptr %t386, i32 0, i32 2
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  %t390 = load i64, ptr %l2, !tbaa !24
  %t394 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %t385, { i64, ptr } %t389, i64 %t390)
  store { i64, ptr } %t394, ptr %l194
  br label %bb51
bb51:
  %t395 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t395, ptr %l26, !tbaa !27
  store ptr null, ptr %l27, !tbaa !29
  %t396 = load ptr, ptr %l25, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Make", ptr %t396, i32 0, i32 3
  %t399 = load ptr, ptr %t398, !tbaa !29
  %t401 = icmp eq ptr %t399, null
  %t403 = xor i1 %t401, true
  br i1 %t403, label %bb52, label %bb53
bb52:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l199, !tbaa !29
  %t406 = load ptr, ptr %l25, !tbaa !29
  %t408 = getelementptr %"compiler/typed:Make", ptr %t406, i32 0, i32 3
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = icmp eq ptr %t409, null
  br i1 %t411, label %bb54, label %bb55
bb53:
  br label %bb58
bb54:
  call void @__olang_check_failed(ptr @olang_loc_4aef7e9433005aa6_9cd0eb13e1392442)
  unreachable
bb55:
  br label %bb56
bb56:
  %t413 = load ptr, ptr %l25, !tbaa !29
  %t415 = getelementptr %"compiler/typed:Make", ptr %t413, i32 0, i32 3
  %t416 = load ptr, ptr %t415, !tbaa !29
  %t417 = load i64, ptr %l2, !tbaa !24
  %t418 = load ptr, ptr %l199, !tbaa !29
  %t421 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t418, ptr %t416, i64 %t417)
  store ptr %t421, ptr %l206
  br label %bb57
bb57:
  %t422 = load ptr, ptr %l206, !tbaa !29
  store ptr %t422, ptr %l27, !tbaa !29
  br label %bb58
bb58:
  %t424 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t424, ptr %l208
  %t425 = load i32, ptr %l24, !tbaa !23
  store i32 %t425, ptr %l209, !tbaa !23
  %t426 = load ptr, ptr %l25, !tbaa !29
  %t428 = getelementptr %"compiler/typed:Make", ptr %t426, i32 0, i32 0
  %t429 = load i32, ptr %t428
  store i32 %t429, ptr %l211
  %t430 = load ptr, ptr %l25, !tbaa !29
  %t432 = getelementptr %"compiler/typed:Make", ptr %t430, i32 0, i32 1
  %t433 = load i64, ptr %t432, !tbaa !24
  store i64 %t433, ptr %l213, !tbaa !24
  %t434 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t434, ptr %l214, !tbaa !27
  %t435 = load ptr, ptr %l27, !tbaa !29
  store ptr %t435, ptr %l215, !tbaa !29
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load ptr, ptr %l25, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Make", ptr %t437, i32 0, i32 4
  %t440 = load i32, ptr %t439, !tbaa !23
  %t441 = load i64, ptr %l2, !tbaa !24
  %t445 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t436, i32 %t440, i64 %t441)
  store i32 %t445, ptr %l220
  br label %bb59
bb59:
  %t446 = load ptr, ptr %l25, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Make", ptr %t446, i32 0, i32 5
  %t449 = load i32, ptr %t448
  %t450 = load i32, ptr %l211
  %t451 = load i64, ptr %l213, !tbaa !24
  %t452 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t453 = load ptr, ptr %l215, !tbaa !29
  %t454 = load i32, ptr %l220, !tbaa !23
  %t456 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t450, i64 %t451, { i64, ptr } %t452, ptr %t453, i32 %t454, i32 %t449)
  store %"compiler/typed:Make" %t456, ptr %l223
  br label %bb60
bb60:
  %t457 = load %"compiler/typed:Make", ptr %l223
  %t458 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Make" %t457, ptr %t458
  store { i64, [5 x i64] } zeroinitializer, ptr %t459
  %t460 = getelementptr { i64, [5 x i64] }, ptr %t459, i32 0, i32 0
  store i64 7, ptr %t460
  %t461 = load %"compiler/source:Span", ptr %l208
  %t462 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t461, 0
  %t463 = load i32, ptr %l209, !tbaa !23
  %t464 = insertvalue { %"compiler/source:Span", i32, ptr } %t462, i32 %t463, 1
  %t466 = insertvalue { %"compiler/source:Span", i32, ptr } %t464, ptr %t458, 2
  %t467 = getelementptr { i64, [5 x i64] }, ptr %t459, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t466, ptr %t467
  %t468 = load { i64, [5 x i64] }, ptr %t459
  %t470 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t468, ptr %t470
  store ptr %t470, ptr %rv
  br label %ret
bb61:
  %t472 = load ptr, ptr %l1, !tbaa !29
  store ptr %t472, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t473 = load ptr, ptr %l227, !tbaa !29
  %t474 = icmp ne ptr %t473, null
  br i1 %t474, label %bb62, label %bb63
bb62:
  %t476 = load ptr, ptr %l227, !tbaa !29
  %t477 = load i64, ptr %t476
  %t479 = icmp eq i64 %t477, 9
  store i1 %t479, ptr %l228, !tbaa !21
  br label %bb63
bb63:
  %t480 = load i1, ptr %l228, !tbaa !21
  br i1 %t480, label %bb64, label %bb65
bb64:
  %t481 = load ptr, ptr %l1, !tbaa !29
  %t483 = getelementptr { i64, [5 x i64] }, ptr %t481, i32 0, i32 1
  %t484 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t483, i32 0, i32 0
  %t485 = load %"compiler/source:Span", ptr %t484
  store %"compiler/source:Span" %t485, ptr %l28
  %t487 = load ptr, ptr %l1, !tbaa !29
  %t489 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 1
  %t490 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t489, i32 0, i32 1
  %t491 = load i32, ptr %t490
  store i32 %t491, ptr %l29, !tbaa !23
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t495 = getelementptr { i64, [5 x i64] }, ptr %t493, i32 0, i32 1
  %t496 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t495, i32 0, i32 2
  %t497 = load i32, ptr %t496
  store i32 %t497, ptr %l30
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = getelementptr { i64, [5 x i64] }, ptr %t499, i32 0, i32 1
  %t502 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t501, i32 0, i32 3
  %t503 = load i32, ptr %t502
  store i32 %t503, ptr %l31
  %t505 = load ptr, ptr %l1, !tbaa !29
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t507, i32 0, i32 4
  %t509 = load { i64, ptr }, ptr %t508
  store { i64, ptr } %t509, ptr %l32, !tbaa !27
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t511 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t511, ptr %l241
  %t512 = load i32, ptr %l29, !tbaa !23
  store i32 %t512, ptr %l242, !tbaa !23
  %t513 = load i32, ptr %l30
  store i32 %t513, ptr %l243
  %t514 = load i32, ptr %l31
  store i32 %t514, ptr %l244
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t517 = load i64, ptr %l2, !tbaa !24
  %t521 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %t515, { i64, ptr } %t516, i64 %t517)
  store { i64, ptr } %t521, ptr %l248
  br label %bb67
bb67:
  store { i64, [5 x i64] } zeroinitializer, ptr %t522
  %t523 = getelementptr { i64, [5 x i64] }, ptr %t522, i32 0, i32 0
  store i64 9, ptr %t523
  %t524 = load %"compiler/source:Span", ptr %l241
  %t525 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t524, 0
  %t526 = load i32, ptr %l242, !tbaa !23
  %t527 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t525, i32 %t526, 1
  %t528 = load i32, ptr %l243
  %t529 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t527, i32 %t528, 2
  %t530 = load i32, ptr %l244
  %t531 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t529, i32 %t530, 3
  %t532 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t533 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t531, { i64, ptr } %t532, 4
  %t534 = getelementptr { i64, [5 x i64] }, ptr %t522, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t533, ptr %t534
  %t535 = load { i64, [5 x i64] }, ptr %t522
  %t537 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t535, ptr %t537
  store ptr %t537, ptr %rv
  br label %ret
bb68:
  %t539 = load ptr, ptr %l1, !tbaa !29
  store ptr %t539, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t540 = load ptr, ptr %l251, !tbaa !29
  %t541 = icmp ne ptr %t540, null
  br i1 %t541, label %bb69, label %bb70
bb69:
  %t543 = load ptr, ptr %l251, !tbaa !29
  %t544 = load i64, ptr %t543
  %t546 = icmp eq i64 %t544, 10
  store i1 %t546, ptr %l252, !tbaa !21
  br label %bb70
bb70:
  %t547 = load i1, ptr %l252, !tbaa !21
  br i1 %t547, label %bb71, label %bb72
bb71:
  %t548 = load ptr, ptr %l1, !tbaa !29
  %t550 = getelementptr { i64, [5 x i64] }, ptr %t548, i32 0, i32 1
  %t551 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t550, i32 0, i32 0
  %t552 = load %"compiler/source:Span", ptr %t551
  store %"compiler/source:Span" %t552, ptr %l33
  %t554 = load ptr, ptr %l1, !tbaa !29
  %t556 = getelementptr { i64, [5 x i64] }, ptr %t554, i32 0, i32 1
  %t557 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t556, i32 0, i32 1
  %t558 = load i32, ptr %t557
  store i32 %t558, ptr %l34, !tbaa !23
  %t560 = load ptr, ptr %l1, !tbaa !29
  %t562 = getelementptr { i64, [5 x i64] }, ptr %t560, i32 0, i32 1
  %t563 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t562, i32 0, i32 2
  %t564 = load ptr, ptr %t563
  store ptr %t564, ptr %l35, !tbaa !29
  br label %bb73
bb72:
  br label %bb78
bb73:
  %t566 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t566, ptr %l261
  %t567 = load i32, ptr %l34, !tbaa !23
  store i32 %t567, ptr %l262, !tbaa !23
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t569 = load ptr, ptr %l35, !tbaa !29
  %t571 = getelementptr %"compiler/typed:Slice", ptr %t569, i32 0, i32 0
  %t572 = load ptr, ptr %t571, !tbaa !29
  %t573 = load i64, ptr %l2, !tbaa !24
  %t577 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %t568, ptr %t572, i64 %t573)
  store ptr %t577, ptr %l267
  br label %bb74
bb74:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load ptr, ptr %l35, !tbaa !29
  %t581 = getelementptr %"compiler/typed:Slice", ptr %t579, i32 0, i32 1
  %t582 = load ptr, ptr %t581, !tbaa !29
  %t583 = load i64, ptr %l2, !tbaa !24
  %t587 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t578, ptr %t582, i64 %t583)
  store ptr %t587, ptr %l272
  br label %bb75
bb75:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load ptr, ptr %l35, !tbaa !29
  %t591 = getelementptr %"compiler/typed:Slice", ptr %t589, i32 0, i32 2
  %t592 = load ptr, ptr %t591, !tbaa !29
  %t593 = load i64, ptr %l2, !tbaa !24
  %t597 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t588, ptr %t592, i64 %t593)
  store ptr %t597, ptr %l277
  br label %bb76
bb76:
  %t598 = load ptr, ptr %l35, !tbaa !29
  %t600 = getelementptr %"compiler/typed:Slice", ptr %t598, i32 0, i32 3
  %t601 = load i32, ptr %t600
  %t602 = load ptr, ptr %l267, !tbaa !29
  %t603 = load ptr, ptr %l272, !tbaa !29
  %t604 = load ptr, ptr %l277, !tbaa !29
  %t606 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t602, ptr %t603, ptr %t604, i32 %t601)
  store %"compiler/typed:Slice" %t606, ptr %l280
  br label %bb77
bb77:
  %t607 = load %"compiler/typed:Slice", ptr %l280
  %t608 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Slice" %t607, ptr %t608
  store { i64, [5 x i64] } zeroinitializer, ptr %t609
  %t610 = getelementptr { i64, [5 x i64] }, ptr %t609, i32 0, i32 0
  store i64 10, ptr %t610
  %t611 = load %"compiler/source:Span", ptr %l261
  %t612 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t611, 0
  %t613 = load i32, ptr %l262, !tbaa !23
  %t614 = insertvalue { %"compiler/source:Span", i32, ptr } %t612, i32 %t613, 1
  %t616 = insertvalue { %"compiler/source:Span", i32, ptr } %t614, ptr %t608, 2
  %t617 = getelementptr { i64, [5 x i64] }, ptr %t609, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t616, ptr %t617
  %t618 = load { i64, [5 x i64] }, ptr %t609
  %t620 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t618, ptr %t620
  store ptr %t620, ptr %rv
  br label %ret
bb78:
  %t622 = load ptr, ptr %l1, !tbaa !29
  store ptr %t622, ptr %l284, !tbaa !29
  store i1 false, ptr %l285, !tbaa !21
  %t623 = load ptr, ptr %l284, !tbaa !29
  %t624 = icmp ne ptr %t623, null
  br i1 %t624, label %bb79, label %bb80
bb79:
  %t626 = load ptr, ptr %l284, !tbaa !29
  %t627 = load i64, ptr %t626
  %t629 = icmp eq i64 %t627, 11
  store i1 %t629, ptr %l285, !tbaa !21
  br label %bb80
bb80:
  %t630 = load i1, ptr %l285, !tbaa !21
  br i1 %t630, label %bb81, label %bb82
bb81:
  %t631 = load ptr, ptr %l1, !tbaa !29
  %t633 = getelementptr { i64, [5 x i64] }, ptr %t631, i32 0, i32 1
  %t634 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t633, i32 0, i32 0
  %t635 = load %"compiler/source:Span", ptr %t634
  store %"compiler/source:Span" %t635, ptr %l36
  %t637 = load ptr, ptr %l1, !tbaa !29
  %t639 = getelementptr { i64, [5 x i64] }, ptr %t637, i32 0, i32 1
  %t640 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t639, i32 0, i32 1
  %t641 = load i32, ptr %t640
  store i32 %t641, ptr %l37, !tbaa !23
  %t643 = load ptr, ptr %l1, !tbaa !29
  %t645 = getelementptr { i64, [5 x i64] }, ptr %t643, i32 0, i32 1
  %t646 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t645, i32 0, i32 2
  %t647 = load ptr, ptr %t646
  store ptr %t647, ptr %l38, !tbaa !29
  br label %bb83
bb82:
  br label %bb94
bb83:
  store ptr null, ptr %l39, !tbaa !29
  %t649 = load ptr, ptr %l38, !tbaa !29
  %t651 = getelementptr %"compiler/typed:Cond", ptr %t649, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !29
  %t654 = icmp eq ptr %t652, null
  %t656 = xor i1 %t654, true
  br i1 %t656, label %bb84, label %bb85
bb84:
  %t658 = load ptr, ptr %l0, !tbaa !29
  store ptr %t658, ptr %l298, !tbaa !29
  %t659 = load ptr, ptr %l38, !tbaa !29
  %t661 = getelementptr %"compiler/typed:Cond", ptr %t659, i32 0, i32 1
  %t662 = load ptr, ptr %t661, !tbaa !29
  %t664 = icmp eq ptr %t662, null
  br i1 %t664, label %bb86, label %bb87
bb85:
  br label %bb90
bb86:
  call void @__olang_check_failed(ptr @olang_loc_89a248f11218248d_cad7b116269b1029)
  unreachable
bb87:
  br label %bb88
bb88:
  %t666 = load ptr, ptr %l38, !tbaa !29
  %t668 = getelementptr %"compiler/typed:Cond", ptr %t666, i32 0, i32 1
  %t669 = load ptr, ptr %t668, !tbaa !29
  %t670 = load i64, ptr %l2, !tbaa !24
  %t671 = load ptr, ptr %l298, !tbaa !29
  %t674 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t671, ptr %t669, i64 %t670)
  store ptr %t674, ptr %l305
  br label %bb89
bb89:
  %t675 = load ptr, ptr %l305, !tbaa !29
  store ptr %t675, ptr %l39, !tbaa !29
  br label %bb90
bb90:
  %t677 = load %"compiler/source:Span", ptr %l36
  store %"compiler/source:Span" %t677, ptr %l307
  %t678 = load i32, ptr %l37, !tbaa !23
  store i32 %t678, ptr %l308, !tbaa !23
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load ptr, ptr %l38, !tbaa !29
  %t682 = getelementptr %"compiler/typed:Cond", ptr %t680, i32 0, i32 0
  %t683 = load ptr, ptr %t682, !tbaa !29
  %t684 = load i64, ptr %l2, !tbaa !24
  %t688 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t679, ptr %t683, i64 %t684)
  store ptr %t688, ptr %l313
  br label %bb91
bb91:
  %t689 = load ptr, ptr %l39, !tbaa !29
  store ptr %t689, ptr %l314, !tbaa !29
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load ptr, ptr %l38, !tbaa !29
  %t693 = getelementptr %"compiler/typed:Cond", ptr %t691, i32 0, i32 2
  %t694 = load ptr, ptr %t693, !tbaa !29
  %t695 = load i64, ptr %l2, !tbaa !24
  %t699 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t690, ptr %t694, i64 %t695)
  store ptr %t699, ptr %l319
  br label %bb92
bb92:
  %t700 = load ptr, ptr %l313, !tbaa !29
  %t701 = load ptr, ptr %l314, !tbaa !29
  %t702 = load ptr, ptr %l319, !tbaa !29
  %t703 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t700, ptr %t701, ptr %t702)
  store %"compiler/typed:Cond" %t703, ptr %l320
  br label %bb93
bb93:
  %t704 = load %"compiler/typed:Cond", ptr %l320
  %t705 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t704, ptr %t705
  store { i64, [5 x i64] } zeroinitializer, ptr %t706
  %t707 = getelementptr { i64, [5 x i64] }, ptr %t706, i32 0, i32 0
  store i64 11, ptr %t707
  %t708 = load %"compiler/source:Span", ptr %l307
  %t709 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t708, 0
  %t710 = load i32, ptr %l308, !tbaa !23
  %t711 = insertvalue { %"compiler/source:Span", i32, ptr } %t709, i32 %t710, 1
  %t713 = insertvalue { %"compiler/source:Span", i32, ptr } %t711, ptr %t705, 2
  %t714 = getelementptr { i64, [5 x i64] }, ptr %t706, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t713, ptr %t714
  %t715 = load { i64, [5 x i64] }, ptr %t706
  %t717 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t715, ptr %t717
  store ptr %t717, ptr %rv
  br label %ret
bb94:
  %t719 = load ptr, ptr %l1, !tbaa !29
  store ptr %t719, ptr %l324, !tbaa !29
  store i1 false, ptr %l325, !tbaa !21
  %t720 = load ptr, ptr %l324, !tbaa !29
  %t721 = icmp ne ptr %t720, null
  br i1 %t721, label %bb95, label %bb96
bb95:
  %t723 = load ptr, ptr %l324, !tbaa !29
  %t724 = load i64, ptr %t723
  %t726 = icmp eq i64 %t724, 17
  store i1 %t726, ptr %l325, !tbaa !21
  br label %bb96
bb96:
  %t727 = load i1, ptr %l325, !tbaa !21
  br i1 %t727, label %bb97, label %bb98
bb97:
  %t728 = load ptr, ptr %l1, !tbaa !29
  %t730 = getelementptr { i64, [5 x i64] }, ptr %t728, i32 0, i32 1
  %t731 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t730, i32 0, i32 0
  %t732 = load %"compiler/source:Span", ptr %t731
  store %"compiler/source:Span" %t732, ptr %l40
  %t734 = load ptr, ptr %l1, !tbaa !29
  %t736 = getelementptr { i64, [5 x i64] }, ptr %t734, i32 0, i32 1
  %t737 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t736, i32 0, i32 1
  %t738 = load i64, ptr %t737
  store i64 %t738, ptr %l41, !tbaa !24
  %t740 = load ptr, ptr %l1, !tbaa !29
  %t742 = getelementptr { i64, [5 x i64] }, ptr %t740, i32 0, i32 1
  %t743 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t742, i32 0, i32 2
  %t744 = load ptr, ptr %t743
  store ptr %t744, ptr %l42, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t746 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t746, ptr %l334
  %t747 = load i64, ptr %l41, !tbaa !24
  store i64 %t747, ptr %l335, !tbaa !24
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t749 = load ptr, ptr %l42, !tbaa !29
  %t750 = load i64, ptr %l2, !tbaa !24
  %t754 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t748, ptr %t749, i64 %t750)
  store ptr %t754, ptr %l339
  br label %bb100
bb100:
  store { i64, [5 x i64] } zeroinitializer, ptr %t755
  %t756 = getelementptr { i64, [5 x i64] }, ptr %t755, i32 0, i32 0
  store i64 17, ptr %t756
  %t757 = load %"compiler/source:Span", ptr %l334
  %t758 = insertvalue { %"compiler/source:Span", i64, ptr } undef, %"compiler/source:Span" %t757, 0
  %t759 = load i64, ptr %l335, !tbaa !24
  %t760 = insertvalue { %"compiler/source:Span", i64, ptr } %t758, i64 %t759, 1
  %t761 = load ptr, ptr %l339, !tbaa !29
  %t762 = insertvalue { %"compiler/source:Span", i64, ptr } %t760, ptr %t761, 2
  %t763 = getelementptr { i64, [5 x i64] }, ptr %t755, i32 0, i32 1
  store { %"compiler/source:Span", i64, ptr } %t762, ptr %t763
  %t764 = load { i64, [5 x i64] }, ptr %t755
  %t766 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t764, ptr %t766
  store ptr %t766, ptr %rv
  br label %ret
bb101:
  %t768 = load ptr, ptr %l1, !tbaa !29
  store ptr %t768, ptr %l342, !tbaa !29
  store i1 false, ptr %l343, !tbaa !21
  %t769 = load ptr, ptr %l342, !tbaa !29
  %t770 = icmp ne ptr %t769, null
  br i1 %t770, label %bb102, label %bb103
bb102:
  %t772 = load ptr, ptr %l342, !tbaa !29
  %t773 = load i64, ptr %t772
  %t775 = icmp eq i64 %t773, 15
  store i1 %t775, ptr %l343, !tbaa !21
  br label %bb103
bb103:
  %t776 = load i1, ptr %l343, !tbaa !21
  br i1 %t776, label %bb104, label %bb105
bb104:
  %t777 = load ptr, ptr %l1, !tbaa !29
  %t779 = getelementptr { i64, [5 x i64] }, ptr %t777, i32 0, i32 1
  %t780 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t779, i32 0, i32 0
  %t781 = load %"compiler/source:Span", ptr %t780
  store %"compiler/source:Span" %t781, ptr %l43
  %t783 = load ptr, ptr %l1, !tbaa !29
  %t785 = getelementptr { i64, [5 x i64] }, ptr %t783, i32 0, i32 1
  %t786 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t785, i32 0, i32 1
  %t787 = load i32, ptr %t786
  store i32 %t787, ptr %l44, !tbaa !23
  %t789 = load ptr, ptr %l1, !tbaa !29
  %t791 = getelementptr { i64, [5 x i64] }, ptr %t789, i32 0, i32 1
  %t792 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t791, i32 0, i32 2
  %t793 = load ptr, ptr %t792
  store ptr %t793, ptr %l45, !tbaa !29
  br label %bb106
bb105:
  br label %bb114
bb106:
  %t795 = load ptr, ptr %l45, !tbaa !29
  store ptr %t795, ptr %l352, !tbaa !29
  store i1 false, ptr %l353, !tbaa !21
  %t796 = load ptr, ptr %l352, !tbaa !29
  %t797 = icmp ne ptr %t796, null
  br i1 %t797, label %bb107, label %bb108
bb107:
  %t799 = load ptr, ptr %l352, !tbaa !29
  %t800 = load i64, ptr %t799
  %t802 = icmp eq i64 %t800, 0
  store i1 %t802, ptr %l353, !tbaa !21
  br label %bb108
bb108:
  %t803 = load i1, ptr %l353, !tbaa !21
  br i1 %t803, label %bb109, label %bb110
bb109:
  %t804 = load ptr, ptr %l45, !tbaa !29
  %t806 = getelementptr { i64, [4 x i64] }, ptr %t804, i32 0, i32 1
  %t807 = getelementptr { i32 }, ptr %t806, i32 0, i32 0
  %t808 = load i32, ptr %t807
  store i32 %t808, ptr %l46, !tbaa !23
  br label %bb111
bb110:
  br label %bb112
bb111:
  %t810 = load %"compiler/source:Span", ptr %l43
  %t811 = load i32, ptr %l44, !tbaa !23
  %t812 = load i32, ptr %l46, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t813
  %t814 = getelementptr { i64, [4 x i64] }, ptr %t813, i32 0, i32 0
  store i64 0, ptr %t814
  %t816 = insertvalue { i32 } undef, i32 %t812, 0
  %t817 = getelementptr { i64, [4 x i64] }, ptr %t813, i32 0, i32 1
  store { i32 } %t816, ptr %t817
  %t818 = load { i64, [4 x i64] }, ptr %t813
  %t820 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t818, ptr %t820
  store { i64, [5 x i64] } zeroinitializer, ptr %t821
  %t822 = getelementptr { i64, [5 x i64] }, ptr %t821, i32 0, i32 0
  store i64 15, ptr %t822
  %t824 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t810, 0
  %t826 = insertvalue { %"compiler/source:Span", i32, ptr } %t824, i32 %t811, 1
  %t828 = insertvalue { %"compiler/source:Span", i32, ptr } %t826, ptr %t820, 2
  %t829 = getelementptr { i64, [5 x i64] }, ptr %t821, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t828, ptr %t829
  %t830 = load { i64, [5 x i64] }, ptr %t821
  %t832 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t830, ptr %t832
  store ptr %t832, ptr %rv
  br label %ret
bb112:
  br label %bb113
bb113:
  br label %bb115
bb114:
  br label %bb115
bb115:
  %t834 = load ptr, ptr %l0, !tbaa !29
  store ptr %t834, ptr %l365, !tbaa !29
  %t835 = load ptr, ptr %l1, !tbaa !29
  %t837 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t835)
  store %"compiler/source:Span" %t837, ptr %l367
  br label %bb116
bb116:
  %t838 = load ptr, ptr %l365, !tbaa !29
  %t839 = load %"compiler/source:Span", ptr %l367
  %t840 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t838, %"compiler/source:Span" %t839)
  store ptr %t840, ptr %l368
  br label %bb117
bb117:
  %t841 = load ptr, ptr %l368, !tbaa !29
  store ptr %t841, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/generic:Context" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectContext(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l9 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca i64
  %l24 = alloca i32
  %l25 = alloca %"compiler/generic:Context"
  %l34 = alloca %"compiler/generic:Context"
  %l36 = alloca ptr
  %l39 = alloca %"compiler/generic:Context"
  %rv = alloca %"compiler/generic:Context"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 10
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t29, i64 %t30)
  store i64 %t33, ptr %l20
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t37, i64 %t38)
  store i32 %t41, ptr %l24
  br label %bb6
bb6:
  %t42 = load ptr, ptr %l16, !tbaa !29
  %t43 = load i64, ptr %l20, !tbaa !24
  %t44 = load i32, ptr %l24, !tbaa !23
  %t45 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %v0, ptr %v1, ptr %t42, i64 %t43, i32 %t44)
  store %"compiler/generic:Context" %t45, ptr %l25
  br label %bb7
bb7:
  %t46 = load %"compiler/generic:Context", ptr %l25
  store %"compiler/generic:Context" %t46, ptr %rv
  br label %ret
bb8:
  %t47 = load { i64, [2 x i64] }, ptr %l2
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 1
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t53 = getelementptr { i32, i32 }, ptr %t52, i32 0, i32 0
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l4, !tbaa !23
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t57 = getelementptr { i32, i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l5, !tbaa !23
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  %t65 = load i32, ptr %l5, !tbaa !23
  %t69 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorContext(ptr %v0, ptr %v1, ptr %t63, i32 %t64, i32 %t65)
  store %"compiler/generic:Context" %t69, ptr %l34
  br label %bb12
bb12:
  %t70 = load %"compiler/generic:Context", ptr %l34
  store %"compiler/generic:Context" %t70, ptr %rv
  br label %ret
bb13:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t71)
  store ptr %t73, ptr %l36
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t76 = getelementptr %"compiler/check:frame", ptr %t74, i32 0, i32 1
  %t77 = load i64, ptr %t76, !tbaa !24
  %t79 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v1, i64 %t77, i64 -1)
  store %"compiler/generic:Context" %t79, ptr %l39
  br label %bb15
bb15:
  %t80 = load %"compiler/generic:Context", ptr %l39
  store %"compiler/generic:Context" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Context", ptr %rv
  ret %"compiler/generic:Context" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 10
  store ptr %t13, ptr %l7, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t14)
  store ptr %t16, ptr %l9
  br label %bb4
bb3:
  %t17 = extractvalue { i64, ptr } { i64 58, ptr @.d10 }, 1
  %t18 = extractvalue { i64, ptr } { i64 58, ptr @.d10 }, 0
  %t19 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  call void @__olang_check_failed_text(ptr @olang_loc_43d20343d6f566de_136f8b7be912828a, { i64, ptr } %t20)
  unreachable
bb4:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 0
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t27 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t25, i64 %t24)
  store ptr %t27, ptr %l12
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l12, !tbaa !29
  store ptr %t28, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edataLength(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 3
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { { i64, ptr } }, ptr %t27, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %rv
  br label %ret
bb11:
  store i64 -1, ptr %rv
  br label %ret
bb12:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i32
  %l14 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Catch", ptr %t2, i32 0, i32 0
  %t5 = load %"compiler/source:Span", ptr %t4
  %t8 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t1, %"compiler/source:Span" %t5)
  store { i64, ptr } %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 7, ptr @.d11 })
  %t11 = extractvalue { i32, i64 } %t10, 1
  %t12 = extractvalue { i32, i64 } %t10, 0
  store i32 %t12, ptr %l9
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14
ok.14:
  store i64 %t11, ptr %l8
  br label %bb2
bb2:
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp slt i64 %t17, 0
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store %"compiler/source:Span" %t25, ptr %l14
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t26, ptr %rv
  br label %ret
bb9:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Catch", ptr %t27, i32 0, i32 0
  %t30 = getelementptr %"compiler/source:Span", ptr %t29, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = trunc i64 %t32 to i32
  %t37 = add i32 %t31, %t34
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Catch", ptr %t38, i32 0, i32 0
  %t41 = getelementptr %"compiler/source:Span", ptr %t40, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = trunc i64 %t43 to i32
  %t48 = add i32 %t42, %t45
  %t50 = add i32 %t48, 7
  %t53 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t37, i32 %t50)
  store %"compiler/source:Span" %t53, ptr %l26
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l26 = alloca i32
  %l30 = alloca %"compiler/typed:Block"
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t60 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l3
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %t22, %"compiler/source:Span" %t23, ptr %t24)
  store ptr %t28, ptr %l16
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l16, !tbaa !29
  store ptr %t29, ptr %rv
  br label %ret
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l17, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t31)
  store %"compiler/source:Span" %t33, ptr %l19
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l19
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s2, ptr %t34, %"compiler/source:Span" %t35, { i64, ptr } { i64 20, ptr @.d12 })
  br label %bb9
bb9:
  store %"compiler/source:Span" %a1, ptr %l20
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t37)
  store ptr %t39, ptr %l22
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t42 = getelementptr %"compiler/check:frame", ptr %t40, i32 0, i32 7
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = trunc i64 %t43 to i32
  store i32 %t45, ptr %l26, !tbaa !23
  %t47 = icmp sge i64 0, 0
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = icmp sle i64 0, 1152921504606846975
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_823a266be2210958_13324b84b1c75d64)
  unreachable
bb13:
  %t51 = mul i64 0, 8
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 0, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t55 = load i32, ptr %l26, !tbaa !23
  %t57 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t55, { i64, ptr } %t54)
  store %"compiler/typed:Block" %t57, ptr %l30
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_823a266be2210958_13324b84b1c75d64)
  unreachable
bb15:
  %t58 = load %"compiler/typed:Block", ptr %l30
  %t59 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t58, ptr %t59
  store { i64, [3 x i64] } zeroinitializer, ptr %t60
  %t61 = getelementptr { i64, [3 x i64] }, ptr %t60, i32 0, i32 0
  store i64 10, ptr %t61
  %t62 = load %"compiler/source:Span", ptr %l20
  %t63 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t62, 0
  %t65 = insertvalue { %"compiler/source:Span", ptr } %t63, ptr %t59, 1
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t60, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t65, ptr %t66
  %t67 = load { i64, [3 x i64] }, ptr %t60
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t67, ptr %t69
  call void @__olang_scope_close(ptr %s2)
  store ptr %t69, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqShaped(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca i32
  %l41 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i32
  %l61 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %a2)
  store i32 %t20, ptr %l13
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l14
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l15
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp eq i64 %t30, 2
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l24, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i32, ptr %t43, i64 1
  %t45 = load i32, ptr %t44, !tbaa !33
  %t48 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t40, i32 %t45)
  store i32 %t48, ptr %l26
  br label %bb6
bb5:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb21
bb6:
  %t49 = load ptr, ptr %l22, !tbaa !29
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l27
  br label %bb7
bb7:
  %t52 = load i32, ptr %l27
  %t54 = trunc i64 25 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb9:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l33, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l36, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l38, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 1
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t69, i32 %t74)
  store i32 %t77, ptr %l40
  br label %bb10
bb10:
  %t78 = load ptr, ptr %l36, !tbaa !29
  %t79 = load i32, ptr %l40, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t80, ptr %l41
  br label %bb11
bb11:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l1, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l46
  br label %bb12
bb12:
  %t91 = load ptr, ptr %l33, !tbaa !29
  %t92 = load i32, ptr %l41, !tbaa !23
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t91, i32 %t92, i32 %t93)
  store i1 %t94, ptr %l47
  br label %bb13
bb13:
  %t95 = load i1, ptr %l47, !tbaa !21
  store i1 %t95, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t96 = load i1, ptr %l30, !tbaa !21
  br i1 %t96, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb16:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l51, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t104, ptr %l53, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i32, ptr %t106, i64 1
  %t108 = load i32, ptr %t107, !tbaa !33
  %t111 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t103, i32 %t108)
  store i32 %t111, ptr %l55
  br label %bb17
bb17:
  %t112 = load ptr, ptr %l51, !tbaa !29
  %t113 = load i32, ptr %l55, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t114, ptr %l56
  br label %bb18
bb18:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l1, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l61
  br label %bb19
bb19:
  %t125 = load i32, ptr %l56, !tbaa !23
  %t126 = load i32, ptr %l61, !tbaa !23
  %t127 = icmp eq i32 %t125, %t126
  store i1 %t127, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t129 = load i1, ptr %l48, !tbaa !21
  store i1 %t129, ptr %l19, !tbaa !21
  br label %bb21
bb21:
  %t130 = load i1, ptr %l19, !tbaa !21
  store i1 %t130, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/ast:Path"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l15 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l25 = alloca %"compiler/ast:Path"
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l33 = alloca i32
  %l40 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l49 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca i1
  %l62 = alloca i1
  %l65 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i64
  %l73 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l83 = alloca i32
  %l86 = alloca { i64, ptr }
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca { i64, [3 x i64] }
  %l96 = alloca { i64, ptr }
  %l98 = alloca %"compiler/msgs:Msg"
  %l99 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, i32 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Path", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = icmp slt i64 %t8, 2
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = insertvalue { i64, i32 } undef, i64 -1, 0
  %t15 = insertvalue { i64, i32 } %t13, i32 %t12, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, i32 } %t15, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Path", ptr %t17, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l15
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Path", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t25, 1
  store i64 %t27, ptr %l19, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l20, !tbaa !24
  %t30 = icmp sge i64 0, 0
  br i1 %t30, label %bb4, label %bb5
bb4:
  %t32 = load i64, ptr %l19, !tbaa !24
  %t33 = icmp sle i64 0, %t32
  br i1 %t33, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_40b38b3f39a757f8_637d931d9ca8f3a4)
  unreachable
bb6:
  %t35 = load i64, ptr %l19, !tbaa !24
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_40b38b3f39a757f8_637d931d9ca8f3a4)
  unreachable
bb8:
  %t39 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l19, !tbaa !24
  %t42 = getelementptr i32, ptr %t40, i64 0
  %t43 = sub i64 %t41, 0
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  %t46 = load %"compiler/source:Span", ptr %l15
  %t48 = call %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v1, ptr %s0, %"compiler/source:Span" %t46, { i64, ptr } %t45)
  store %"compiler/ast:Path" %t48, ptr %l25
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_40b38b3f39a757f8_637d931d9ca8f3a4)
  unreachable
bb10:
  %t49 = load %"compiler/ast:Path", ptr %l25
  store %"compiler/ast:Path" %t49, ptr %l3
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l27, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t54)
  store ptr %t56, ptr %l29
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l29, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 4
  %t60 = load ptr, ptr %l27, !tbaa !29
  %t63 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %s0, ptr %t60, ptr %t59, ptr %l3)
  store i32 %t63, ptr %l33
  br label %bb12
bb12:
  %t64 = load i32, ptr %l33, !tbaa !23
  store i32 %t64, ptr %l4, !tbaa !23
  %t65 = load i32, ptr %l4, !tbaa !23
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t69 = icmp eq i32 %t65, %t66
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t71 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t72 = insertvalue { i64, i32 } undef, i64 -1, 0
  %t74 = insertvalue { i64, i32 } %t72, i32 %t71, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, i32 } %t74, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Path", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l40, !tbaa !27
  %t80 = load i64, ptr %l2, !tbaa !24
  %t82 = sub i64 %t80, 1
  %t84 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i32, ptr %t85, i64 %t82
  %t87 = load i32, ptr %t86, !tbaa !33
  store i32 %t87, ptr %l5, !tbaa !23
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l44, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l4, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l49
  br label %bb16
bb16:
  %t100 = load i32, ptr %l5, !tbaa !23
  %t101 = load ptr, ptr %l44, !tbaa !29
  %t102 = load i32, ptr %l49, !tbaa !23
  %t104 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %t101, i32 %t102, i32 %t100)
  store i64 %t104, ptr %l51
  br label %bb17
bb17:
  %t105 = load i64, ptr %l51, !tbaa !24
  store i64 %t105, ptr %l6, !tbaa !24
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = icmp sge i64 %t106, 0
  br i1 %t108, label %bb18, label %bb19
bb18:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i32, ptr %l5, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t110, i32 %t111)
  store { i64, ptr } %t114, ptr %l57
  br label %bb20
bb19:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb22
bb20:
  %t115 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t115, ptr %l58, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i8, ptr %t117, i64 0
  %t119 = load i8, ptr %t118, !tbaa !32
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t119)
  store i1 %t121, ptr %l60
  br label %bb21
bb21:
  %t122 = load i1, ptr %l60, !tbaa !21
  %t123 = xor i1 %t122, true
  store i1 %t123, ptr %l54, !tbaa !21
  br label %bb22
bb22:
  %t125 = load i1, ptr %l54, !tbaa !21
  br i1 %t125, label %bb23, label %bb24
bb23:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  store ptr %t131, ptr %l65, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load i32, ptr %l4, !tbaa !23
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t141, ptr %l70
  br label %bb25
bb24:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb28
bb25:
  %t142 = load ptr, ptr %l65, !tbaa !29
  %t143 = load i32, ptr %l70, !tbaa !23
  %t144 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t142, i32 %t143)
  store i64 %t144, ptr %l71
  br label %bb26
bb26:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t145)
  store ptr %t147, ptr %l73
  br label %bb27
bb27:
  %t148 = load ptr, ptr %l73, !tbaa !29
  %t150 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 1
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load i64, ptr %l71, !tbaa !24
  %t154 = icmp ne i64 %t152, %t151
  store i1 %t154, ptr %l62, !tbaa !21
  br label %bb28
bb28:
  %t156 = load i1, ptr %l62, !tbaa !21
  br i1 %t156, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 0
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/load:Loader", ptr %t163, i32 0, i32 4
  %t166 = load ptr, ptr %t165, !tbaa !29
  store ptr %t166, ptr %l80, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l81, !tbaa !29
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/ast:Path", ptr %t168, i32 0, i32 0
  %t171 = getelementptr %"compiler/source:Span", ptr %t170, i32 0, i32 1
  %t172 = load i32, ptr %t171, !tbaa !23
  store i32 %t172, ptr %l83, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l5, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t173, i32 %t174)
  store { i64, ptr } %t177, ptr %l86
  br label %bb31
bb30:
  br label %bb37
bb31:
  %t178 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t181 = trunc i64 %t179 to i32
  %t182 = load i32, ptr %l83, !tbaa !23
  %t184 = sub i32 %t182, %t181
  %t185 = load ptr, ptr %l1, !tbaa !29
  %t187 = getelementptr %"compiler/ast:Path", ptr %t185, i32 0, i32 0
  %t188 = getelementptr %"compiler/source:Span", ptr %t187, i32 0, i32 1
  %t189 = load i32, ptr %t188, !tbaa !23
  %t192 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t184, i32 %t189)
  store %"compiler/source:Span" %t192, ptr %l92
  br label %bb32
bb32:
  %t193 = load ptr, ptr %l81, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l92
  %t195 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t193, %"compiler/source:Span" %t194)
  store { i64, [3 x i64] } %t195, ptr %l93
  br label %bb33
bb33:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l5, !tbaa !23
  %t200 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t196, i32 %t197)
  store { i64, ptr } %t200, ptr %l96
  br label %bb34
bb34:
  %t201 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 0
  %t203 = extractvalue { i64, ptr } %t201, 1
  %t204 = mul i64 %t202, 1
  %t205 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t204)
  call void @llvm.memcpy.p0.p0.i64(ptr %t205, ptr %t203, i64 %t204, i1 false)
  %t206 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  %t209 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordIsPrivate(ptr %s3, ptr %s3, { i64, ptr } %t207)
  store %"compiler/msgs:Msg" %t209, ptr %l98
  br label %bb35
bb35:
  %t210 = load ptr, ptr %l80, !tbaa !29
  %t211 = load { i64, [3 x i64] }, ptr %l93
  %t212 = load %"compiler/msgs:Msg", ptr %l98
  %t213 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s3, ptr %t210, { i64, [3 x i64] } %t211, %"compiler/msgs:Msg" %t212)
  store i64 %t213, ptr %l99
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb37:
  %t214 = load i64, ptr %l6, !tbaa !24
  %t215 = load i32, ptr %l4, !tbaa !23
  %t217 = insertvalue { i64, i32 } undef, i64 %t214, 0
  %t219 = insertvalue { i64, i32 } %t217, i32 %t215, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, i32 } %t219, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i32 }, ptr %rv
  ret { i64, i32 } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l22 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l31 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"compiler/source:Span"
  %l42 = alloca %"compiler/msgs:Msg"
  %l43 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/msgs:Msg"
  %l60 = alloca i64
  %l64 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l96 = alloca { i64, ptr }
  %l100 = alloca i32
  %l101 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sge i64 0, 0
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t7 = icmp sle i64 0, 2305843009213693951
  br i1 %t7, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb5:
  %t9 = mul i64 0, 4
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 0, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l22
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l22, !tbaa !29
  store ptr %t22, ptr %l4, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Func", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t23, i32 %t27)
  store { i64, ptr } %t30, ptr %l26
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Func", ptr %t32, i32 0, i32 5
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t43 = getelementptr %"compiler/ast:Func", ptr %t41, i32 0, i32 5
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l31, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l31, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp eq i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l37, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t54, ptr %l38, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr ptr, ptr %t56, i64 0
  %t58 = load ptr, ptr %t57, !tbaa !39
  %t60 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t58)
  store %"compiler/source:Span" %t60, ptr %l40
  br label %bb15
bb14:
  br label %bb22
bb15:
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %s2, { i64, ptr } %t61)
  store %"compiler/msgs:Msg" %t63, ptr %l42
  br label %bb16
bb16:
  %t64 = load ptr, ptr %l37, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l40
  %t66 = load %"compiler/msgs:Msg", ptr %l42
  %t67 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t64, %"compiler/source:Span" %t65, %"compiler/msgs:Msg" %t66)
  store i64 %t67, ptr %l43
  br label %bb17
bb17:
  %t68 = icmp sge i64 0, 0
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t70 = icmp sle i64 0, 2305843009213693951
  br i1 %t70, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb20:
  %t72 = mul i64 0, 4
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 0, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t75, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb22:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t83 = icmp ne i64 %t77, %t80
  br i1 %t83, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l51, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t86, ptr %l52, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr ptr, ptr %t88, i64 0
  %t90 = load ptr, ptr %t89, !tbaa !39
  %t92 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t90)
  store %"compiler/source:Span" %t92, ptr %l54
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t94 = load i64, ptr %l6, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t101 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s3, { i64, ptr } %t93, i64 %t94, i64 %t97)
  store %"compiler/msgs:Msg" %t101, ptr %l59
  br label %bb26
bb26:
  %t102 = load ptr, ptr %l51, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l54
  %t104 = load %"compiler/msgs:Msg", ptr %l59
  %t105 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t102, %"compiler/source:Span" %t103, %"compiler/msgs:Msg" %t104)
  store i64 %t105, ptr %l60
  br label %bb27
bb27:
  %t106 = icmp sge i64 0, 0
  br i1 %t106, label %bb28, label %bb29
bb28:
  %t108 = icmp sle i64 0, 2305843009213693951
  br i1 %t108, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb30:
  %t110 = mul i64 0, 4
  %t111 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 0, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t113, ptr %rv
  br label %ret
bb31:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb32:
  %t115 = load i64, ptr %l6, !tbaa !24
  store i64 %t115, ptr %l64, !tbaa !24
  %t116 = load i64, ptr %l64, !tbaa !24
  %t117 = icmp sge i64 %t116, 0
  br i1 %t117, label %bb33, label %bb34
bb33:
  %t119 = load i64, ptr %l64, !tbaa !24
  %t120 = icmp sle i64 %t119, 2305843009213693951
  br i1 %t120, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_c902484ee6860410_648a649019eab164)
  unreachable
bb35:
  %t122 = load i64, ptr %l64, !tbaa !24
  %t123 = mul i64 %t122, 4
  %t124 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t123)
  %t125 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  store { i64, ptr } %t126, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l6, !tbaa !24
  store i64 %t128, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l9, !tbaa !24
  %t131 = load i64, ptr %l8, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  br i1 %t134, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_c902484ee6860410_648a649019eab164)
  unreachable
bb37:
  %t136 = load i64, ptr %l10, !tbaa !24
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb42
bb39:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t141 = load i64, ptr %l8, !tbaa !24
  %t144 = sub i64 %t140, %t141
  %t145 = load i64, ptr %l10, !tbaa !24
  %t148 = add i64 %t144, %t145
  %t150 = sub i64 %t148, 1
  %t151 = load i64, ptr %l10, !tbaa !24
  %t154 = sdiv i64 %t150, %t151
  store i64 %t154, ptr %l75, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb41
bb41:
  %t156 = load i64, ptr %l75, !tbaa !24
  store i64 %t156, ptr %l72, !tbaa !24
  br label %bb42
bb42:
  %t157 = load i64, ptr %l72, !tbaa !24
  store i64 %t157, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t158 = load i64, ptr %l12, !tbaa !24
  %t159 = load i64, ptr %l11, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb56
bb45:
  br label %bb46
bb46:
  %t166 = load i64, ptr %l8, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t168 = load i64, ptr %l10, !tbaa !24
  %t171 = mul i64 %t167, %t168
  %t174 = add i64 %t166, %t171
  store i64 %t174, ptr %l13, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t176, ptr %l93, !tbaa !27
  %t177 = load i64, ptr %l13, !tbaa !24
  store i64 %t177, ptr %l94, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t179, ptr %l96, !tbaa !27
  %t180 = load i64, ptr %l13, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr ptr, ptr %t183, i64 %t180
  %t185 = load ptr, ptr %t184, !tbaa !39
  %t189 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t178, ptr %t185)
  store i32 %t189, ptr %l100
  br label %bb47
bb47:
  %t190 = load i32, ptr %l100, !tbaa !23
  %t191 = load i64, ptr %l94, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i32, ptr %t193, i64 %t191
  store i32 %t190, ptr %t194, !tbaa !33
  %t195 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t195, ptr %l101, !tbaa !27
  %t196 = load i64, ptr %l13, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr i32, ptr %t199, i64 %t196
  %t201 = load i32, ptr %t200, !tbaa !33
  %t202 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t205 = icmp eq i32 %t201, %t202
  br i1 %t205, label %bb48, label %bb49
bb48:
  %t207 = icmp sge i64 0, 0
  br i1 %t207, label %bb50, label %bb51
bb49:
  br label %bb54
bb50:
  %t209 = icmp sle i64 0, 2305843009213693951
  br i1 %t209, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_e4324c4b30f6563f_ec149b7f01d5683b)
  unreachable
bb52:
  %t211 = mul i64 0, 4
  %t212 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t211)
  %t213 = insertvalue { i64, ptr } undef, i64 0, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  call void @__olang_scope_close(ptr %s5)
  store { i64, ptr } %t214, ptr %rv
  br label %ret
bb53:
  call void @__olang_check_failed(ptr @olang_loc_e4324c4b30f6563f_ec149b7f01d5683b)
  unreachable
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb55:
  %t216 = load i64, ptr %l12, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l12, !tbaa !24
  br label %bb43
bb56:
  %t220 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t220, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprPattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %lp19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %lp26 = alloca ptr
  %l29 = alloca i32
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca i1
  %l49 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i1
  %l67 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i1
  %l86 = alloca i64
  %l93 = alloca ptr
  %l96 = alloca ptr
  %l99 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca i32
  %l106 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca i64
  %l119 = alloca { i64, ptr }
  %l122 = alloca %"compiler/msgs:Msg"
  %l123 = alloca i64
  %l127 = alloca ptr
  %l131 = alloca i1
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l137 = alloca ptr
  %l142 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca i32
  %l157 = alloca %"compiler/typed:Payload"
  %l165 = alloca i64
  %l168 = alloca i64
  %l186 = alloca { i64, ptr }
  %l189 = alloca %"compiler/source:Span"
  %l190 = alloca { i64, ptr }
  %l196 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca ptr
  %l200 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l209 = alloca ptr
  %l210 = alloca ptr
  %l219 = alloca ptr
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca ptr
  %t55 = alloca { i64, [4 x i64] }, align 8
  %t237 = alloca { i64, [4 x i64] }, align 8
  %t287 = alloca { i64, [4 x i64] }, align 8
  %t368 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l29
  br label %bb1
bb1:
  %t6 = load i32, ptr %l29, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l31
  br label %bb2
bb2:
  %t10 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t10, ptr %l8
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t12 = load ptr, ptr %l32, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l32, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l33, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l33, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32 }, ptr %t22, i32 0, i32 0
  %t24 = load %"compiler/source:Span", ptr %t23
  store %"compiler/source:Span" %t24, ptr %l9
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32 }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l10, !tbaa !23
  br label %bb7
bb6:
  br label %bb18
bb7:
  %t34 = xor i1 %a6, true
  br i1 %t34, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l10, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t40, ptr %l44
  br label %bb10
bb9:
  br label %bb17
bb10:
  %t41 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 1, ptr @.d13 })
  store i1 %t42, ptr %l45
  br label %bb11
bb11:
  %t43 = load i1, ptr %l45, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l9
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t44, %"compiler/source:Span" %t45, i32 %t46, i64 1)
  store ptr %t50, ptr %l49
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  %t51 = load ptr, ptr %l49, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l9
  %t54 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 0
  store i64 3, ptr %t56
  %t58 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t53, 0
  %t60 = insertvalue { %"compiler/source:Span", i32 } %t58, i32 %t54, 1
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t60, ptr %t61
  %t62 = load { i64, [4 x i64] }, ptr %t55
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t62, ptr %t64
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t68 = load i64, ptr %l5, !tbaa !24
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v0, ptr %t52, ptr %t64, ptr %t65, i32 %t66, ptr %t67, i64 %t68)
  store ptr %t75, ptr %l59
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  %t76 = load ptr, ptr %l59, !tbaa !29
  store ptr %t76, ptr %rv
  br label %ret
bb17:
  br label %bb76
bb18:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t78 = load ptr, ptr %l60, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t81 = load ptr, ptr %l60, !tbaa !29
  %t82 = load i64, ptr %t81
  %t84 = icmp eq i64 %t82, 15
  store i1 %t84, ptr %l61, !tbaa !21
  br label %bb20
bb20:
  %t85 = load i1, ptr %l61, !tbaa !21
  br i1 %t85, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb29
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t88 = load i32, ptr %l7, !tbaa !23
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t86, ptr %t87, i32 %t88)
  store i64 %t92, ptr %l67
  br label %bb24
bb24:
  %t93 = load i64, ptr %l67, !tbaa !24
  store i64 %t93, ptr %l11, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sge i64 %t94, 0
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l8
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load i64, ptr %l11, !tbaa !24
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, ptr %t100, i64 %t101)
  store ptr %t106, ptr %l74
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t107 = load ptr, ptr %l74, !tbaa !29
  store ptr %t107, ptr %rv
  br label %ret
bb28:
  br label %bb76
bb29:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t109 = load ptr, ptr %l75, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t112 = load ptr, ptr %l75, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 12
  store i1 %t115, ptr %l76, !tbaa !21
  br label %bb31
bb31:
  %t116 = load i1, ptr %l76, !tbaa !21
  br i1 %t116, label %bb32, label %bb33
bb32:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l12, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t125, i32 0, i32 2
  %t127 = load { i64, ptr }, ptr %t126
  store { i64, ptr } %t127, ptr %l13, !tbaa !27
  br label %bb34
bb33:
  br label %bb75
bb34:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l12, !tbaa !29
  %t131 = load i32, ptr %l7, !tbaa !23
  %t135 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t129, ptr %t130, i32 %t131)
  store i64 %t135, ptr %l86
  br label %bb35
bb35:
  %t136 = load i64, ptr %l86, !tbaa !24
  store i64 %t136, ptr %l14, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l8
  %t143 = load ptr, ptr %l2, !tbaa !29
  %t144 = load i64, ptr %l14, !tbaa !24
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t141, %"compiler/source:Span" %t142, ptr %t143, i64 %t144)
  store ptr %t149, ptr %l93
  br label %bb38
bb37:
  br label %bb74
bb38:
  %t150 = load ptr, ptr %l93, !tbaa !29
  store ptr %t150, ptr %l15, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  store ptr %t156, ptr %l96, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  store ptr %t162, ptr %l99, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load i32, ptr %l7, !tbaa !23
  %t168 = load i64, ptr %l14, !tbaa !24
  %t172 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t166, i32 %t167, i64 %t168)
  store i32 %t172, ptr %l104
  br label %bb39
bb39:
  %t173 = load ptr, ptr %l99, !tbaa !29
  %t174 = load i32, ptr %l104, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t175, ptr %l105
  br label %bb40
bb40:
  %t176 = load ptr, ptr %l96, !tbaa !29
  %t177 = load i32, ptr %l105, !tbaa !23
  %t178 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t176, i32 %t177)
  store { i64, ptr } %t178, ptr %l106
  br label %bb41
bb41:
  %t179 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t179, ptr %l16, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t188 = icmp ne i64 %t182, %t185
  br i1 %t188, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l112, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t191, ptr %l113
  %t192 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t192, 0
  store i64 %t194, ptr %l115, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t199 = icmp eq i64 %t197, 1
  br i1 %t199, label %bb44, label %bb45
bb43:
  br label %bb50
bb44:
  store { i64, ptr } { i64 0, ptr @.d14 }, ptr %l119, !tbaa !27
  br label %bb46
bb45:
  store { i64, ptr } { i64 1, ptr @.d15 }, ptr %l119, !tbaa !27
  br label %bb46
bb46:
  %t201 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = load i64, ptr %l115, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t207 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s8, ptr %s8, i64 %t204, { i64, ptr } %t205, i64 %t203)
  store %"compiler/msgs:Msg" %t207, ptr %l122
  br label %bb47
bb47:
  %t208 = load ptr, ptr %l112, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l113
  %t210 = load %"compiler/msgs:Msg", ptr %l122
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t208, %"compiler/source:Span" %t209, %"compiler/msgs:Msg" %t210)
  store i64 %t211, ptr %l123
  br label %bb48
bb48:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l8
  %t214 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t218 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t212, %"compiler/source:Span" %t213, i32 %t214, i64 0)
  store ptr %t218, ptr %l127
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  %t219 = load ptr, ptr %l127, !tbaa !29
  store ptr %t219, ptr %rv
  br label %ret
bb50:
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l17, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i32, ptr %l3, !tbaa !23
  %t226 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t222, i32 %t223)
  store i1 %t226, ptr %l131
  br label %bb51
bb51:
  %t227 = load i1, ptr %l131, !tbaa !21
  br i1 %t227, label %bb52, label %bb53
bb52:
  %t228 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t228, ptr %l132
  %t229 = load i32, ptr %l7, !tbaa !23
  store i32 %t229, ptr %l133, !tbaa !23
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l8
  %t232 = load ptr, ptr %l2, !tbaa !29
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t230, %"compiler/source:Span" %t231, ptr %t232)
  store ptr %t236, ptr %l137
  br label %bb54
bb53:
  br label %bb55
bb54:
  store { i64, [4 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 0
  store i64 2, ptr %t238
  %t239 = load %"compiler/source:Span", ptr %l132
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t239, 0
  %t241 = load i32, ptr %l133, !tbaa !23
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, i32 %t241, 1
  %t243 = load ptr, ptr %l137, !tbaa !29
  %t244 = insertvalue { %"compiler/source:Span", i32, ptr } %t242, ptr %t243, 2
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t244, ptr %t245
  %t246 = load { i64, [4 x i64] }, ptr %t237
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t246, ptr %t248
  store ptr %t248, ptr %l17, !tbaa !29
  br label %bb55
bb55:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 2
  store ptr %t255, ptr %l142, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/generic:Program", ptr %t259, i32 0, i32 2
  %t262 = load i32, ptr %l7, !tbaa !23
  %t265 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t261, i32 %t262)
  store i32 %t265, ptr %l147
  br label %bb56
bb56:
  %t266 = load ptr, ptr %l142, !tbaa !29
  %t267 = load i32, ptr %l147, !tbaa !23
  %t268 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t266, i32 %t267)
  store { i64, ptr } %t268, ptr %l148
  br label %bb57
bb57:
  %t269 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t269, ptr %l149, !tbaa !27
  %t270 = load i64, ptr %l14, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i32, ptr %t273, i64 %t270
  %t275 = load i32, ptr %t274, !tbaa !33
  %t277 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t277, ptr %l152
  store i32 %t275, ptr %l153, !tbaa !23
  %t279 = load ptr, ptr %l17, !tbaa !29
  %t280 = load i64, ptr %l14, !tbaa !24
  %t284 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t279, i64 %t280, i32 0)
  store %"compiler/typed:Payload" %t284, ptr %l157
  br label %bb58
bb58:
  %t285 = load %"compiler/typed:Payload", ptr %l157
  %t286 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t285, ptr %t286
  store { i64, [4 x i64] } zeroinitializer, ptr %t287
  %t288 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 0
  store i64 5, ptr %t288
  %t289 = load %"compiler/source:Span", ptr %l152
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t289, 0
  %t291 = load i32, ptr %l153, !tbaa !23
  %t292 = insertvalue { %"compiler/source:Span", i32, ptr } %t290, i32 %t291, 1
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr } %t292, ptr %t286, 2
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t294, ptr %t295
  %t296 = load { i64, [4 x i64] }, ptr %t287
  %t297 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t297, ptr %lp19
  %t299 = load ptr, ptr %lp19
  store { i64, [4 x i64] } %t296, ptr %t299
  store i64 0, ptr %l20, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  store i64 %t302, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t304 = load i64, ptr %l21, !tbaa !24
  %t305 = load i64, ptr %l20, !tbaa !24
  %t308 = icmp sgt i64 %t304, %t305
  br i1 %t308, label %bb59, label %bb60
bb59:
  %t310 = load i64, ptr %l22, !tbaa !24
  %t312 = icmp sgt i64 %t310, 0
  br i1 %t312, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l165, !tbaa !24
  br label %bb64
bb61:
  %t314 = load i64, ptr %l21, !tbaa !24
  %t315 = load i64, ptr %l20, !tbaa !24
  %t318 = sub i64 %t314, %t315
  %t319 = load i64, ptr %l22, !tbaa !24
  %t322 = add i64 %t318, %t319
  %t324 = sub i64 %t322, 1
  %t325 = load i64, ptr %l22, !tbaa !24
  %t328 = sdiv i64 %t324, %t325
  store i64 %t328, ptr %l168, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb63
bb63:
  %t330 = load i64, ptr %l168, !tbaa !24
  store i64 %t330, ptr %l165, !tbaa !24
  br label %bb64
bb64:
  %t331 = load i64, ptr %l165, !tbaa !24
  store i64 %t331, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb65
bb65:
  store %olang.scope zeroinitializer, ptr %s11
  %t332 = load i64, ptr %l24, !tbaa !24
  %t333 = load i64, ptr %l23, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb67:
  br label %bb68
bb68:
  %t340 = load i64, ptr %l20, !tbaa !24
  %t341 = load i64, ptr %l24, !tbaa !24
  %t342 = load i64, ptr %l22, !tbaa !24
  %t345 = mul i64 %t341, %t342
  %t348 = add i64 %t340, %t345
  store i64 %t348, ptr %l25, !tbaa !24
  %t350 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t350, ptr %l186, !tbaa !27
  %t351 = load i64, ptr %l25, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 %t351
  %t356 = load ptr, ptr %t355, !tbaa !39
  %t358 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t356)
  store %"compiler/source:Span" %t358, ptr %l189
  br label %bb69
bb69:
  %t359 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t359, ptr %l190, !tbaa !27
  %t360 = load i64, ptr %l25, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr i32, ptr %t363, i64 %t360
  %t365 = load i32, ptr %t364, !tbaa !33
  %t366 = load ptr, ptr %lp19
  %t367 = load i64, ptr %l25, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t368
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 0
  store i64 3, ptr %t369
  %t370 = load %"compiler/source:Span", ptr %l189
  %t371 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t370, 0
  %t373 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t371, i32 %t365, 1
  %t375 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t373, ptr %t366, 2
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t375, i64 %t367, 3
  %t378 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t377, ptr %t378
  %t379 = load { i64, [4 x i64] }, ptr %t368
  %t380 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t380, ptr %lp26
  %t382 = load ptr, ptr %lp26
  store { i64, [4 x i64] } %t379, ptr %t382
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l196, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t384, ptr %l197
  %t385 = load ptr, ptr %l15, !tbaa !29
  store ptr %t385, ptr %l198, !tbaa !29
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t387, ptr %l200, !tbaa !27
  %t388 = load i64, ptr %l25, !tbaa !24
  %t390 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr ptr, ptr %t391, i64 %t388
  %t393 = load ptr, ptr %t392, !tbaa !39
  %t394 = load ptr, ptr %lp26
  %t395 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t395, ptr %l204, !tbaa !27
  %t396 = load i64, ptr %l25, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i32, ptr %t399, i64 %t396
  %t401 = load i32, ptr %t400, !tbaa !33
  %t402 = load ptr, ptr %l4, !tbaa !29
  %t403 = load i64, ptr %l5, !tbaa !24
  %t410 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprPattern(ptr %v0, ptr %v1, ptr %t386, ptr %t393, ptr %t394, i32 %t401, ptr %t402, i64 %t403, i1 false)
  store ptr %t410, ptr %l209
  br label %bb70
bb70:
  %t411 = load ptr, ptr %l196, !tbaa !29
  %t412 = load %"compiler/source:Span", ptr %l197
  %t413 = load ptr, ptr %l198, !tbaa !29
  %t414 = load ptr, ptr %l209, !tbaa !29
  %t415 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %t411, %"compiler/source:Span" %t412, ptr %t413, ptr %t414)
  store ptr %t415, ptr %l210
  br label %bb71
bb71:
  %t416 = load ptr, ptr %l210, !tbaa !29
  store ptr %t416, ptr %l15, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb72:
  %t417 = load i64, ptr %l24, !tbaa !24
  %t419 = add i64 %t417, 1
  store i64 %t419, ptr %l24, !tbaa !24
  br label %bb65
bb73:
  %t421 = load ptr, ptr %l15, !tbaa !29
  store ptr %t421, ptr %rv
  br label %ret
bb74:
  br label %bb76
bb75:
  br label %bb76
bb76:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load %"compiler/source:Span", ptr %l8
  %t425 = load ptr, ptr %l2, !tbaa !29
  %t426 = load ptr, ptr %l1, !tbaa !29
  %t427 = load i32, ptr %l3, !tbaa !23
  %t433 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %t423, %"compiler/source:Span" %t424, ptr %t425, ptr %t426, i32 %t427)
  store ptr %t433, ptr %l219
  br label %bb77
bb77:
  %t434 = load ptr, ptr %l219, !tbaa !29
  store ptr %t434, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l9 = alloca ptr
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l3, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t18, ptr %t19, i32 %t21)
  store ptr %t25, ptr %l18
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l18, !tbaa !29
  store ptr %t26, ptr %l4, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load ptr, ptr %l4, !tbaa !29
  store ptr %t33, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load i32, ptr %l2, !tbaa !23
  store i32 %t37, ptr %l25, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t42 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  store %"compiler/source:Span" %t42, ptr %l28
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l23, !tbaa !29
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = load i32, ptr %l25, !tbaa !23
  %t46 = load %"compiler/source:Span", ptr %l28
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t43, ptr %t44, i32 %t45, %"compiler/source:Span" %t46)
  store ptr %t47, ptr %l29
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l29, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l20 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i1
  %l32 = alloca i32
  %l39 = alloca i32
  %l43 = alloca i1
  %l48 = alloca i32
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca %"compiler/source:Span"
  %l64 = alloca i32
  %l67 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca ptr
  %l82 = alloca ptr
  %rv = alloca ptr
  %t105 = alloca { i64, [5 x i64] }, align 8
  %t140 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_12a7e56ab193c888_f3ea9b5a769b449c)
  unreachable
bb11:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t13 = xor i1 %t10, true
  br i1 %t13, label %bb12, label %bb13
bb12:
  store ptr null, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t16)
  store i32 %t19, ptr %l20
  br label %bb15
bb15:
  %t20 = load i32, ptr %l20, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l23
  br label %bb16
bb16:
  %t26 = load i32, ptr %l23, !tbaa !23
  store i32 %t26, ptr %l7, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  br i1 %t31, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb20
bb18:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l7, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l32
  br label %bb19
bb19:
  %t43 = load i32, ptr %l32, !tbaa !23
  %t44 = icmp ne i32 %t43, 0
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb20
bb20:
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb21, label %bb22
bb21:
  store ptr null, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l6, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l39
  br label %bb24
bb24:
  %t58 = load i32, ptr %l39
  %t60 = trunc i64 19 to i32
  %t61 = icmp eq i32 %t58, %t60
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb28
bb26:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l6, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l48
  br label %bb27
bb27:
  %t75 = load i32, ptr %l48, !tbaa !23
  %t76 = icmp eq i32 %t75, 0
  store i1 %t76, ptr %l43, !tbaa !21
  br label %bb28
bb28:
  %t78 = load i1, ptr %l43, !tbaa !21
  br i1 %t78, label %bb29, label %bb30
bb29:
  store ptr null, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t80)
  store ptr %t82, ptr %l52
  br label %bb32
bb32:
  %t83 = load ptr, ptr %l52, !tbaa !29
  store ptr %t83, ptr %l8, !tbaa !29
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb33, label %bb34
bb33:
  store ptr null, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l56, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t90, ptr %l57
  %t91 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t91, ptr %l58
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l6, !tbaa !23
  %t99 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t97, i32 %t98, i64 %t99)
  store i32 %t103, ptr %l64
  br label %bb36
bb36:
  %t104 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 0
  store i64 3, ptr %t106
  %t107 = load %"compiler/source:Span", ptr %l58
  %t108 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t107, 0
  %t109 = load i32, ptr %l64, !tbaa !23
  %t110 = insertvalue { %"compiler/source:Span", i32, ptr } %t108, i32 %t109, 1
  %t112 = insertvalue { %"compiler/source:Span", i32, ptr } %t110, ptr %t104, 2
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t112, ptr %t113
  %t114 = load { i64, [5 x i64] }, ptr %t105
  %t116 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t114, ptr %t116
  store ptr %t116, ptr %l67, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l3, !tbaa !23
  %t124 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t122, i32 %t123, i64 %t124)
  store i32 %t128, ptr %l73
  br label %bb37
bb37:
  %t129 = load ptr, ptr %l56, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l57
  %t131 = load ptr, ptr %l67, !tbaa !29
  %t132 = load i32, ptr %l73, !tbaa !23
  %t133 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t129, %"compiler/source:Span" %t130, ptr %t131, i32 %t132)
  store ptr %t133, ptr %l74
  br label %bb38
bb38:
  %t134 = load ptr, ptr %l74, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l4
  %t137 = load %"compiler/source:Span", ptr %l4
  %t138 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 0
  store i64 2, ptr %t141
  %t143 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t137, 0
  %t145 = insertvalue { %"compiler/source:Span", i32, ptr } %t143, i32 %t138, 1
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } %t145, ptr %t134, 2
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t147, ptr %t148
  %t149 = load { i64, [4 x i64] }, ptr %t140
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t149, ptr %t151
  %t155 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t135, %"compiler/source:Span" %t136, ptr %t151)
  store ptr %t155, ptr %l82
  br label %bb39
bb39:
  %t156 = load ptr, ptr %l82, !tbaa !29
  store ptr %t156, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForms(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l15 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i32
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l73 = alloca ptr
  %l77 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i1
  %l84 = alloca ptr
  %l86 = alloca i64
  %l87 = alloca i64
  %l91 = alloca i1
  %l95 = alloca i64
  %l104 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca i64
  %l118 = alloca i32
  %l121 = alloca i32
  %l122 = alloca ptr
  %l126 = alloca i64
  %l128 = alloca ptr
  %l139 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l142 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l143 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l145 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l146 = alloca i32
  %l152 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l156 = alloca i32
  %l165 = alloca { i64, ptr }
  %l171 = alloca i64
  %l175 = alloca ptr
  %l179 = alloca i1
  %l181 = alloca ptr
  %l183 = alloca i64
  %l184 = alloca i64
  %l188 = alloca i1
  %l192 = alloca i64
  %l201 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l210 = alloca i1
  %l212 = alloca i64
  %l214 = alloca { i64, ptr }
  %l217 = alloca i64
  %l218 = alloca i64
  %l224 = alloca { i64, ptr }
  %l226 = alloca i1
  %l228 = alloca i8
  %l230 = alloca i64
  %l231 = alloca i64
  %l236 = alloca { i64, ptr }
  %l238 = alloca i64
  %l240 = alloca ptr
  %l243 = alloca ptr
  %l246 = alloca ptr
  %l250 = alloca i32
  %l251 = alloca i32
  %l252 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l255 = alloca i32
  %l257 = alloca ptr
  %l258 = alloca i32
  %l264 = alloca i32
  %l265 = alloca i64
  %l268 = alloca i1
  %l272 = alloca i1
  %l274 = alloca ptr
  %l276 = alloca i64
  %l277 = alloca i64
  %l279 = alloca ptr
  %l281 = alloca i64
  %l282 = alloca i64
  %l284 = alloca ptr
  %l287 = alloca i64
  %l288 = alloca i32
  %l289 = alloca ptr
  %l290 = alloca ptr
  %l292 = alloca ptr
  %l293 = alloca i64
  %l297 = alloca i32
  %l298 = alloca i64
  %l299 = alloca i64
  %l300 = alloca i32
  %l305 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l318 = alloca i32
  %l322 = alloca ptr
  %l326 = alloca i64
  %l328 = alloca ptr
  %l331 = alloca i64
  %l332 = alloca ptr
  %l335 = alloca %"compiler/source:Span"
  %l336 = alloca { i64, ptr }
  %l337 = alloca { i64, ptr }
  %l338 = alloca { i64, ptr }
  %l341 = alloca { i64, ptr }
  %l343 = alloca %"compiler/msgs:Msg"
  %l344 = alloca i64
  %l349 = alloca i64
  %l352 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l45
  br label %bb1
bb1:
  %t7 = load i64, ptr %l45, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb7
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l52, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l52, !tbaa !24
  store i64 %t34, ptr %l49, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l49, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l1, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l6, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t57, i64 %t58)
  store ptr %t61, ptr %l73
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l73, !tbaa !29
  store ptr %t62, ptr %l7, !tbaa !29
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Func", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb16
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t73, i64 %t74)
  store i1 %t77, ptr %l81
  br label %bb15
bb15:
  %t78 = load i1, ptr %l81, !tbaa !21
  store i1 %t78, ptr %l77, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l77, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb21
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  store ptr %t83, ptr %l84, !tbaa !29
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t84)
  store i64 %t86, ptr %l86
  br label %bb19
bb19:
  %t87 = load ptr, ptr %l84, !tbaa !29
  %t88 = load i64, ptr %l86, !tbaa !24
  %t89 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t89, ptr %l87
  br label %bb20
bb20:
  %t90 = load i64, ptr %l87, !tbaa !24
  %t91 = icmp sgt i64 %t90, 0
  store i1 %t91, ptr %l82, !tbaa !21
  br label %bb21
bb21:
  %t93 = load i1, ptr %l82, !tbaa !21
  br i1 %t93, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb23:
  br label %bb24
bb24:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 3
  %t97 = load i1, ptr %t96, !tbaa !21
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t106, ptr %l95
  br label %bb27
bb26:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb28
bb27:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 7
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load i64, ptr %l95, !tbaa !24
  %t119 = icmp ne i64 %t117, %t116
  store i1 %t119, ptr %l91, !tbaa !21
  br label %bb28
bb28:
  %t121 = load i1, ptr %l91, !tbaa !21
  br i1 %t121, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb30:
  br label %bb31
bb31:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l7, !tbaa !29
  %t125 = getelementptr %"compiler/ast:Func", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %t125, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t122, i32 %t126)
  store { i64, ptr } %t129, ptr %l104
  br label %bb32
bb32:
  %t130 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t130, ptr %l8, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t135 = icmp eq i64 %t133, 0
  br i1 %t135, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb34:
  br label %bb35
bb35:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t141 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v0, ptr %s2, ptr %t137, { i64, ptr } %t138)
  store { i64, ptr } %t141, ptr %l110
  br label %bb36
bb36:
  %t142 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t142, ptr %l9, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t145 = call i64 @compiler_2fcheck_2eopShapeOf(ptr %s2, { i64, ptr } %t143)
  store i64 %t145, ptr %l112
  br label %bb37
bb37:
  %t146 = load i64, ptr %l112, !tbaa !24
  store i64 %t146, ptr %l10, !tbaa !24
  %t147 = load i64, ptr %l10, !tbaa !24
  %t149 = icmp slt i64 %t147, 0
  br i1 %t149, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb39:
  br label %bb40
bb40:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = load i64, ptr %l6, !tbaa !24
  %t158 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t154, i64 %t155)
  store i32 %t158, ptr %l118
  br label %bb41
bb41:
  %t159 = load i32, ptr %l118, !tbaa !23
  store i32 %t159, ptr %l11, !tbaa !23
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i64, ptr %l6, !tbaa !24
  %t164 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnErrors(ptr %v0, ptr %t160, i64 %t161)
  store i32 %t164, ptr %l121
  br label %bb42
bb42:
  %t165 = load i32, ptr %l121, !tbaa !23
  store i32 %t165, ptr %l12, !tbaa !23
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l122, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t171 = load i64, ptr %l6, !tbaa !24
  %t174 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t170, i64 %t171)
  store i64 %t174, ptr %l126
  br label %bb43
bb43:
  %t175 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t176 = load ptr, ptr %l122, !tbaa !29
  %t177 = load i64, ptr %l126, !tbaa !24
  %t179 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t176, i64 -1, i64 %t177, i32 %t175, i32 0)
  store ptr %t179, ptr %l128
  br label %bb44
bb44:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l6, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t184 = load i64, ptr %l10, !tbaa !24
  %t185 = load i32, ptr %l11, !tbaa !23
  %t186 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForm(ptr %v0, ptr %v0, ptr %s2, ptr %t180, i64 %t181, { i64, ptr } %t182, { i64, ptr } %t183, i64 %t184, i32 %t185, i32 %t186)
  br label %bb45
bb45:
  %t194 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t194)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb47:
  %t196 = load i64, ptr %l5, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l5, !tbaa !24
  br label %bb8
bb48:
  %t200 = load ptr, ptr @__olang_prog_scope
  %t201 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t200)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t201, ptr %l139
  br label %bb49
bb49:
  %t202 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l139
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t202, ptr %l13
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 16
  %t207 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t205)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t207, ptr %l142
  br label %bb50
bb50:
  %t208 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l142
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t208, ptr %l14
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s9
  %t210 = call { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %l14)
  %t211 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t210, 1
  %t212 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t210, 0
  store i32 %t212, ptr %l146
  %t213 = icmp ne i32 %t212, 0
  br i1 %t213, label %bb53, label %ok.214
ok.214:
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t211, ptr %l145
  br label %bb52
bb52:
  %t215 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l145
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t215, ptr %l143
  br label %bb57
bb53:
  %t216 = load i32, ptr %l146, !tbaa !23
  %t217 = ashr i32 %t216, 16
  %t219 = icmp eq i32 %t217, 1
  br i1 %t219, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_78dfa72e33b60bd8_3b4814a7819e5504)
  unreachable
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb57:
  %t221 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l143
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t221, ptr %l15
  %t222 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l15, i32 0, i32 0
  %t223 = load i64, ptr %t222, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l13, i64 %t223)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb59:
  br label %bb51
bb60:
  store ptr %l13, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s11
  %t227 = load ptr, ptr %l16, !tbaa !29
  %t228 = load i64, ptr %l17, !tbaa !24
  %t231 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t227, i64 %t228)
  %t232 = extractvalue { i32, { i64, ptr } } %t231, 1
  %t233 = extractvalue { i32, { i64, ptr } } %t231, 0
  store i32 %t233, ptr %l156
  %t234 = icmp ne i32 %t233, 0
  br i1 %t234, label %bb63, label %ok.235
ok.235:
  store { i64, ptr } %t232, ptr %l155
  br label %bb62
bb62:
  %t236 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t236, ptr %l152, !tbaa !27
  br label %bb67
bb63:
  %t237 = load i32, ptr %l156, !tbaa !23
  %t238 = ashr i32 %t237, 16
  %t240 = icmp eq i32 %t238, 1
  br i1 %t240, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_e8223b07530edea9_6c94d0d58286c0f5)
  unreachable
bb66:
  call void @__olang_scope_close(ptr %s11)
  br label %bb178
bb67:
  %t242 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t242, ptr %l18, !tbaa !27
  %t243 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t243, 0
  store i64 %t245, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s12
  %t247 = load i64, ptr %l20, !tbaa !24
  %t248 = load i64, ptr %l19, !tbaa !24
  %t251 = icmp slt i64 %t247, %t248
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s12)
  br label %bb176
bb70:
  br label %bb71
bb71:
  %t255 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t255, ptr %l165, !tbaa !27
  %t256 = load i64, ptr %l20, !tbaa !24
  %t258 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i64, ptr %t259, i64 %t256
  %t261 = load i64, ptr %t260, !tbaa !34
  store i64 %t261, ptr %l21, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/check:Checker", ptr %t263, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t267 = load i64, ptr %l21, !tbaa !24
  %t270 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t266, i64 %t267)
  store i64 %t270, ptr %l171
  br label %bb72
bb72:
  %t271 = load i64, ptr %l171, !tbaa !24
  store i64 %t271, ptr %l22, !tbaa !24
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t272, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !29
  %t276 = load i64, ptr %l22, !tbaa !24
  %t279 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t275, i64 %t276)
  store ptr %t279, ptr %l175
  br label %bb73
bb73:
  %t280 = load ptr, ptr %l175, !tbaa !29
  store ptr %t280, ptr %l23, !tbaa !29
  %t281 = load ptr, ptr %l23, !tbaa !29
  %t283 = getelementptr %"compiler/ast:Func", ptr %t281, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t286 = icmp eq ptr %t284, null
  br i1 %t286, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l179, !tbaa !21
  br label %bb78
bb75:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/check:Checker", ptr %t288, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !29
  store ptr %t291, ptr %l181, !tbaa !29
  %t292 = load i64, ptr %l22, !tbaa !24
  %t294 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t292)
  store i64 %t294, ptr %l183
  br label %bb76
bb76:
  %t295 = load ptr, ptr %l181, !tbaa !29
  %t296 = load i64, ptr %l183, !tbaa !24
  %t297 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t295, i64 %t296)
  store i64 %t297, ptr %l184
  br label %bb77
bb77:
  %t298 = load i64, ptr %l184, !tbaa !24
  %t299 = icmp eq i64 %t298, 0
  store i1 %t299, ptr %l179, !tbaa !21
  br label %bb78
bb78:
  %t301 = load i1, ptr %l179, !tbaa !21
  br i1 %t301, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s12)
  br label %bb175
bb80:
  br label %bb81
bb81:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/check:Checker", ptr %t302, i32 0, i32 3
  %t305 = load i1, ptr %t304, !tbaa !21
  br i1 %t305, label %bb82, label %bb83
bb82:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t311 = load i64, ptr %l22, !tbaa !24
  %t314 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t310, i64 %t311)
  store i64 %t314, ptr %l192
  br label %bb84
bb83:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb85
bb84:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Program", ptr %t318, i32 0, i32 0
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = getelementptr %"compiler/load:Loader", ptr %t321, i32 0, i32 7
  %t324 = load i64, ptr %t323, !tbaa !24
  %t325 = load i64, ptr %l192, !tbaa !24
  %t327 = icmp ne i64 %t325, %t324
  store i1 %t327, ptr %l188, !tbaa !21
  br label %bb85
bb85:
  %t329 = load i1, ptr %l188, !tbaa !21
  br i1 %t329, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s12)
  br label %bb175
bb87:
  br label %bb88
bb88:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l23, !tbaa !29
  %t333 = getelementptr %"compiler/ast:Func", ptr %t331, i32 0, i32 2
  %t334 = load i32, ptr %t333, !tbaa !23
  %t337 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t330, i32 %t334)
  store { i64, ptr } %t337, ptr %l201
  br label %bb89
bb89:
  %t338 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t338, ptr %l24, !tbaa !27
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t343 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v0, ptr %s12, ptr %t339, { i64, ptr } %t340)
  store { i64, ptr } %t343, ptr %l204
  br label %bb90
bb90:
  %t344 = load { i64, ptr }, ptr %l204, !tbaa !27
  store { i64, ptr } %t344, ptr %l25, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t345, 0
  %t348 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t348, 0
  %t353 = icmp eq i64 %t347, %t350
  br i1 %t353, label %bb91, label %bb92
bb91:
  store i1 true, ptr %l210, !tbaa !21
  br label %bb94
bb92:
  %t355 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t357 = call i64 @compiler_2fcheck_2eopShapeOf(ptr %s12, { i64, ptr } %t355)
  store i64 %t357, ptr %l212
  br label %bb93
bb93:
  %t358 = load i64, ptr %l212, !tbaa !24
  %t359 = icmp slt i64 %t358, 0
  store i1 %t359, ptr %l210, !tbaa !21
  br label %bb94
bb94:
  %t361 = load i1, ptr %l210, !tbaa !21
  br i1 %t361, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s12)
  br label %bb175
bb96:
  br label %bb97
bb97:
  %t362 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t362, ptr %l214, !tbaa !27
  %t363 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t363, 0
  store i64 %t366, ptr %l217, !tbaa !24
  %t367 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t367, 0
  store i64 %t368, ptr %l218, !tbaa !24
  %t369 = icmp sge i64 7, 0
  br i1 %t369, label %bb98, label %bb99
bb98:
  %t371 = load i64, ptr %l217, !tbaa !24
  %t372 = icmp sle i64 7, %t371
  br i1 %t372, label %bb100, label %bb101
bb99:
  call void @__olang_check_failed(ptr @olang_loc_ad1cdf552c08c341_1b6bb8f4178aae4d)
  unreachable
bb100:
  %t374 = load i64, ptr %l217, !tbaa !24
  %t375 = load i64, ptr %l218, !tbaa !24
  %t376 = icmp sle i64 %t374, %t375
  br i1 %t376, label %bb102, label %bb103
bb101:
  call void @__olang_check_failed(ptr @olang_loc_ad1cdf552c08c341_1b6bb8f4178aae4d)
  unreachable
bb102:
  %t378 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !27
  %t380 = load i64, ptr %l217, !tbaa !24
  %t381 = getelementptr i8, ptr %t379, i64 7
  %t382 = sub i64 %t380, 7
  %t383 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t381, 1
  %t386 = extractvalue { i64, ptr } %t384, 1
  %t387 = extractvalue { i64, ptr } %t384, 0
  %t388 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t387)
  call void @olang_textcopy(ptr %t388, ptr %t386, i64 %t387)
  %t389 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t388, 1
  store { i64, ptr } %t390, ptr %l26, !tbaa !27
  %t392 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t392, ptr %l224, !tbaa !27
  %t393 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !27
  %t395 = getelementptr i8, ptr %t394, i64 0
  %t396 = load i8, ptr %t395, !tbaa !32
  %t398 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %t396)
  store i1 %t398, ptr %l226
  br label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_ad1cdf552c08c341_1b6bb8f4178aae4d)
  unreachable
bb104:
  %t399 = load i1, ptr %l226, !tbaa !21
  br i1 %t399, label %bb105, label %bb106
bb105:
  %t400 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr i8, ptr %t401, i64 0
  %t403 = load i8, ptr %t402, !tbaa !32
  %t405 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t403)
  store i8 %t405, ptr %l228
  br label %bb107
bb106:
  br label %bb117
bb107:
  %t406 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t408 = extractvalue { i64, ptr } %t406, 0
  store i64 %t408, ptr %l230, !tbaa !24
  %t409 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t409, 0
  store i64 %t410, ptr %l231, !tbaa !24
  %t411 = icmp sge i64 1, 0
  br i1 %t411, label %bb108, label %bb109
bb108:
  %t413 = load i64, ptr %l230, !tbaa !24
  %t414 = icmp sle i64 1, %t413
  br i1 %t414, label %bb110, label %bb111
bb109:
  call void @__olang_check_failed(ptr @olang_loc_a6850fee211a02d4_462adb773114c70)
  unreachable
bb110:
  %t416 = load i64, ptr %l230, !tbaa !24
  %t417 = load i64, ptr %l231, !tbaa !24
  %t418 = icmp sle i64 %t416, %t417
  br i1 %t418, label %bb112, label %bb113
bb111:
  call void @__olang_check_failed(ptr @olang_loc_a6850fee211a02d4_462adb773114c70)
  unreachable
bb112:
  %t420 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = load i64, ptr %l230, !tbaa !24
  %t423 = getelementptr i8, ptr %t421, i64 1
  %t424 = sub i64 %t422, 1
  %t425 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t423, 1
  %t427 = load i8, ptr %l228, !tbaa !22
  %t429 = extractvalue { i64, ptr } %t426, 1
  %t430 = extractvalue { i64, ptr } %t426, 0
  %t431 = add i64 1, %t430
  %t432 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t431)
  store i8 %t427, ptr %t432
  %t433 = getelementptr i8, ptr %t432, i64 1
  call void @olang_textcopy(ptr %t433, ptr %t429, i64 %t430)
  %t434 = insertvalue { i64, ptr } undef, i64 %t431, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t432, 1
  store { i64, ptr } %t435, ptr %l236, !tbaa !27
  %t436 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t437 = extractvalue { i64, ptr } %t436, 0
  %t438 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t439 = extractvalue { i64, ptr } %t438, 0
  store i64 %t439, ptr %l238, !tbaa !24
  %t441 = load i64, ptr %l238, !tbaa !24
  %t442 = icmp eq i64 %t437, %t441
  br i1 %t442, label %bb114, label %bb115
bb113:
  call void @__olang_check_failed(ptr @olang_loc_a6850fee211a02d4_462adb773114c70)
  unreachable
bb114:
  %t444 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t445 = load ptr, ptr %t444, !tbaa !27
  %t446 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = load i64, ptr %l238, !tbaa !24
  %t449 = mul i64 %t448, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t445, ptr %t447, i64 %t449, i1 false)
  br label %bb116
bb115:
  %t450 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t450, ptr %l26, !tbaa !27
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t451 = load ptr, ptr %l0, !tbaa !29
  store ptr %t451, ptr %l240, !tbaa !29
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t454 = getelementptr %"compiler/check:Checker", ptr %t452, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t457 = getelementptr %"compiler/generic:Program", ptr %t455, i32 0, i32 2
  store ptr %t457, ptr %l243, !tbaa !29
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/check:Checker", ptr %t458, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !29
  %t463 = getelementptr %"compiler/generic:Program", ptr %t461, i32 0, i32 2
  store ptr %t463, ptr %l246, !tbaa !29
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = getelementptr %"compiler/check:Checker", ptr %t464, i32 0, i32 1
  %t467 = load ptr, ptr %t466, !tbaa !29
  %t468 = load i64, ptr %l22, !tbaa !24
  %t471 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t467, i64 %t468)
  store i32 %t471, ptr %l250
  br label %bb118
bb118:
  %t472 = load ptr, ptr %l246, !tbaa !29
  %t473 = load i32, ptr %l250, !tbaa !23
  %t474 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t472, i32 %t473)
  store i32 %t474, ptr %l251
  br label %bb119
bb119:
  %t475 = load ptr, ptr %l243, !tbaa !29
  %t476 = load i32, ptr %l251, !tbaa !23
  %t477 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t475, i32 %t476)
  store { i64, ptr } %t477, ptr %l252
  br label %bb120
bb120:
  %t478 = load { i64, ptr }, ptr %l252, !tbaa !27
  store { i64, ptr } %t478, ptr %l253, !tbaa !27
  %t479 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t480 = load ptr, ptr %t479, !tbaa !27
  %t481 = getelementptr i32, ptr %t480, i64 0
  %t482 = load i32, ptr %t481, !tbaa !33
  %t483 = load ptr, ptr %l240, !tbaa !29
  %t485 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t483, i32 %t482)
  store i32 %t485, ptr %l255
  br label %bb121
bb121:
  %t486 = load i32, ptr %l255, !tbaa !23
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t489 = getelementptr %"compiler/check:Checker", ptr %t487, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !29
  store ptr %t490, ptr %l257, !tbaa !29
  store i32 %t486, ptr %l258, !tbaa !23
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = getelementptr %"compiler/check:Checker", ptr %t492, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !29
  %t497 = getelementptr %"compiler/generic:Program", ptr %t495, i32 0, i32 0
  %t498 = load ptr, ptr %t497, !tbaa !29
  %t500 = getelementptr %"compiler/load:Loader", ptr %t498, i32 0, i32 3
  %t501 = load ptr, ptr %t500, !tbaa !29
  %t502 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t505 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s12, ptr %t501, { i64, ptr } %t502)
  store i32 %t505, ptr %l264
  br label %bb122
bb122:
  %t506 = load ptr, ptr %l257, !tbaa !29
  %t507 = load i32, ptr %l258, !tbaa !23
  %t508 = load i32, ptr %l264, !tbaa !23
  %t509 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t506, i32 %t507, i32 %t508)
  store i64 %t509, ptr %l265
  br label %bb123
bb123:
  %t510 = load i64, ptr %l265, !tbaa !24
  store i64 %t510, ptr %l28, !tbaa !24
  %t511 = load i64, ptr %l28, !tbaa !24
  %t513 = icmp slt i64 %t511, 0
  br i1 %t513, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l268, !tbaa !21
  br label %bb126
bb125:
  %t515 = load i64, ptr %l28, !tbaa !24
  %t516 = load i64, ptr %l22, !tbaa !24
  %t519 = icmp eq i64 %t515, %t516
  store i1 %t519, ptr %l268, !tbaa !21
  br label %bb126
bb126:
  %t521 = load i1, ptr %l268, !tbaa !21
  br i1 %t521, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l272, !tbaa !21
  br label %bb133
bb128:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t524 = getelementptr %"compiler/check:Checker", ptr %t522, i32 0, i32 1
  %t525 = load ptr, ptr %t524, !tbaa !29
  store ptr %t525, ptr %l274, !tbaa !29
  %t526 = load i64, ptr %l28, !tbaa !24
  %t528 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t526)
  store i64 %t528, ptr %l276
  br label %bb129
bb129:
  %t529 = load ptr, ptr %l274, !tbaa !29
  %t530 = load i64, ptr %l276, !tbaa !24
  %t531 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t529, i64 %t530)
  store i64 %t531, ptr %l277
  br label %bb130
bb130:
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t534 = getelementptr %"compiler/check:Checker", ptr %t532, i32 0, i32 1
  %t535 = load ptr, ptr %t534, !tbaa !29
  store ptr %t535, ptr %l279, !tbaa !29
  %t536 = load i64, ptr %l22, !tbaa !24
  %t538 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t536)
  store i64 %t538, ptr %l281
  br label %bb131
bb131:
  %t539 = load ptr, ptr %l279, !tbaa !29
  %t540 = load i64, ptr %l281, !tbaa !24
  %t541 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t539, i64 %t540)
  store i64 %t541, ptr %l282
  br label %bb132
bb132:
  %t542 = load i64, ptr %l277, !tbaa !24
  %t543 = load i64, ptr %l282, !tbaa !24
  %t544 = icmp ne i64 %t542, %t543
  store i1 %t544, ptr %l272, !tbaa !21
  br label %bb133
bb133:
  %t546 = load i1, ptr %l272, !tbaa !21
  br i1 %t546, label %bb134, label %bb135
bb134:
  call void @__olang_scope_close(ptr %s12)
  br label %bb175
bb135:
  br label %bb136
bb136:
  %t547 = load ptr, ptr %l0, !tbaa !29
  store ptr %t547, ptr %l284, !tbaa !29
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t549 = load i64, ptr %l21, !tbaa !24
  %t552 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t548, i64 %t549)
  store i64 %t552, ptr %l287
  br label %bb137
bb137:
  %t553 = load ptr, ptr %l284, !tbaa !29
  %t554 = load i64, ptr %l287, !tbaa !24
  %t555 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t553, i64 %t554)
  store i32 %t555, ptr %l288
  br label %bb138
bb138:
  %t556 = load i32, ptr %l288, !tbaa !23
  store i32 %t556, ptr %l29, !tbaa !23
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l289, !tbaa !29
  %t558 = load ptr, ptr %l0, !tbaa !29
  store ptr %t558, ptr %l290, !tbaa !29
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/check:Checker", ptr %t559, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !29
  store ptr %t562, ptr %l292, !tbaa !29
  %t563 = load i64, ptr %l28, !tbaa !24
  store i64 %t563, ptr %l293, !tbaa !24
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t566 = getelementptr %"compiler/check:Checker", ptr %t564, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !29
  %t568 = load i64, ptr %l21, !tbaa !24
  %t571 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t567, i64 %t568)
  store i32 %t571, ptr %l297
  br label %bb139
bb139:
  %t572 = load ptr, ptr %l292, !tbaa !29
  %t573 = load i64, ptr %l293, !tbaa !24
  %t574 = load i32, ptr %l297, !tbaa !23
  %t575 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t572, i64 %t573, i32 %t574)
  store i64 %t575, ptr %l298
  br label %bb140
bb140:
  %t576 = load ptr, ptr %l290, !tbaa !29
  %t577 = load i64, ptr %l298, !tbaa !24
  %t578 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t576, i64 %t577)
  store i64 %t578, ptr %l299
  br label %bb141
bb141:
  %t579 = load ptr, ptr %l289, !tbaa !29
  %t580 = load i64, ptr %l299, !tbaa !24
  %t581 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t579, i64 %t580)
  store i32 %t581, ptr %l300
  br label %bb142
bb142:
  %t582 = load i32, ptr %l300, !tbaa !23
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t585 = getelementptr %"compiler/check:Checker", ptr %t583, i32 0, i32 1
  %t586 = load ptr, ptr %t585, !tbaa !29
  %t588 = getelementptr %"compiler/generic:Program", ptr %t586, i32 0, i32 2
  %t592 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t588, i32 %t582)
  store { i64, ptr } %t592, ptr %l305
  br label %bb143
bb143:
  %t593 = load { i64, ptr }, ptr %l305, !tbaa !27
  store { i64, ptr } %t593, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t594 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t596 = extractvalue { i64, ptr } %t594, 0
  store i64 %t596, ptr %l33, !tbaa !24
  br label %bb144
bb144:
  store %olang.scope zeroinitializer, ptr %s21
  %t598 = load i64, ptr %l32, !tbaa !24
  %t599 = load i64, ptr %l33, !tbaa !24
  %t602 = icmp slt i64 %t598, %t599
  %t604 = xor i1 %t602, true
  br i1 %t604, label %bb145, label %bb146
bb145:
  call void @__olang_scope_close(ptr %s21)
  br label %bb174
bb146:
  br label %bb147
bb147:
  %t606 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t606, ptr %l312, !tbaa !27
  %t607 = load i64, ptr %l32, !tbaa !24
  %t609 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t610 = load ptr, ptr %t609, !tbaa !27
  %t611 = getelementptr i32, ptr %t610, i64 %t607
  %t612 = load i32, ptr %t611, !tbaa !33
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load i32, ptr %l29, !tbaa !23
  %t620 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t614, i32 %t615, i32 %t612)
  store i32 %t620, ptr %l318
  br label %bb148
bb148:
  %t621 = load i32, ptr %l318, !tbaa !23
  store i32 %t621, ptr %l35, !tbaa !23
  %t622 = load i32, ptr %l35, !tbaa !23
  %t623 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t626 = icmp ne i32 %t622, %t623
  br i1 %t626, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s22
  %t628 = load ptr, ptr %l0, !tbaa !29
  store ptr %t628, ptr %l322, !tbaa !29
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t631 = getelementptr %"compiler/check:Checker", ptr %t629, i32 0, i32 1
  %t632 = load ptr, ptr %t631, !tbaa !29
  %t633 = load i64, ptr %l22, !tbaa !24
  %t636 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t632, i64 %t633)
  store i64 %t636, ptr %l326
  br label %bb151
bb150:
  br label %bb172
bb151:
  %t637 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t638 = load ptr, ptr %l322, !tbaa !29
  %t639 = load i64, ptr %l326, !tbaa !24
  %t641 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t638, i64 -1, i64 %t639, i32 %t637, i32 0)
  store ptr %t641, ptr %l328
  br label %bb152
bb152:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load i64, ptr %l21, !tbaa !24
  %t646 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstContexts(ptr %v0, ptr %t642, i64 %t643)
  store i64 %t646, ptr %l331
  br label %bb153
bb153:
  %t647 = load i64, ptr %l331, !tbaa !24
  store i64 %t647, ptr %l36, !tbaa !24
  %t648 = load ptr, ptr %l0, !tbaa !29
  store ptr %t648, ptr %l332, !tbaa !29
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t650 = load ptr, ptr %l23, !tbaa !29
  %t653 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t649, ptr %t650)
  store %"compiler/source:Span" %t653, ptr %l335
  br label %bb154
bb154:
  %t654 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t654, ptr %l336, !tbaa !27
  %t655 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t655, ptr %l337, !tbaa !27
  %t656 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t656, ptr %l338, !tbaa !27
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load i32, ptr %l35, !tbaa !23
  %t661 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s22, ptr %t657, i32 %t658)
  store { i64, ptr } %t661, ptr %l341
  br label %bb155
bb155:
  %t662 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t663 = extractvalue { i64, ptr } %t662, 0
  %t664 = extractvalue { i64, ptr } %t662, 1
  %t665 = mul i64 %t663, 1
  %t666 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t665)
  call void @llvm.memcpy.p0.p0.i64(ptr %t666, ptr %t664, i64 %t665, i1 false)
  %t667 = insertvalue { i64, ptr } undef, i64 %t663, 0
  %t668 = insertvalue { i64, ptr } %t667, ptr %t666, 1
  %t669 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t670 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t671 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t673 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCheckedNotSuperset(ptr %v0, ptr %s12, ptr %s12, ptr %s22, ptr %s22, { i64, ptr } %t669, { i64, ptr } %t670, { i64, ptr } %t671, { i64, ptr } %t668)
  store %"compiler/msgs:Msg" %t673, ptr %l343
  br label %bb156
bb156:
  %t674 = load ptr, ptr %l332, !tbaa !29
  %t675 = load %"compiler/source:Span", ptr %l335
  %t676 = load %"compiler/msgs:Msg", ptr %l343
  %t677 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t674, %"compiler/source:Span" %t675, %"compiler/msgs:Msg" %t676)
  store i64 %t677, ptr %l344
  br label %bb157
bb157:
  store i64 0, ptr %l37, !tbaa !24
  %t678 = load i64, ptr %l36, !tbaa !24
  store i64 %t678, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t680 = load i64, ptr %l38, !tbaa !24
  %t681 = load i64, ptr %l37, !tbaa !24
  %t684 = icmp sgt i64 %t680, %t681
  br i1 %t684, label %bb158, label %bb159
bb158:
  %t686 = load i64, ptr %l39, !tbaa !24
  %t688 = icmp sgt i64 %t686, 0
  br i1 %t688, label %bb160, label %bb161
bb159:
  store i64 0, ptr %l349, !tbaa !24
  br label %bb163
bb160:
  %t690 = load i64, ptr %l38, !tbaa !24
  %t691 = load i64, ptr %l37, !tbaa !24
  %t694 = sub i64 %t690, %t691
  %t695 = load i64, ptr %l39, !tbaa !24
  %t698 = add i64 %t694, %t695
  %t700 = sub i64 %t698, 1
  %t701 = load i64, ptr %l39, !tbaa !24
  %t704 = sdiv i64 %t700, %t701
  store i64 %t704, ptr %l352, !tbaa !24
  br label %bb162
bb161:
  store i64 0, ptr %l352, !tbaa !24
  br label %bb162
bb162:
  %t706 = load i64, ptr %l352, !tbaa !24
  store i64 %t706, ptr %l349, !tbaa !24
  br label %bb163
bb163:
  %t707 = load i64, ptr %l349, !tbaa !24
  store i64 %t707, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb164
bb164:
  store %olang.scope zeroinitializer, ptr %s24
  %t708 = load i64, ptr %l41, !tbaa !24
  %t709 = load i64, ptr %l40, !tbaa !24
  %t712 = icmp slt i64 %t708, %t709
  %t714 = xor i1 %t712, true
  br i1 %t714, label %bb165, label %bb166
bb165:
  call void @__olang_scope_close(ptr %s24)
  br label %bb170
bb166:
  br label %bb167
bb167:
  %t716 = load i64, ptr %l37, !tbaa !24
  %t717 = load i64, ptr %l41, !tbaa !24
  %t718 = load i64, ptr %l39, !tbaa !24
  %t721 = mul i64 %t717, %t718
  %t724 = add i64 %t716, %t721
  store i64 %t724, ptr %l42, !tbaa !24
  %t726 = load ptr, ptr %l0, !tbaa !29
  %t728 = getelementptr %"compiler/check:Checker", ptr %t726, i32 0, i32 1
  %t729 = load ptr, ptr %t728, !tbaa !29
  %t731 = getelementptr %"compiler/generic:Program", ptr %t729, i32 0, i32 0
  %t732 = load ptr, ptr %t731, !tbaa !29
  %t734 = getelementptr %"compiler/load:Loader", ptr %t732, i32 0, i32 4
  %t735 = load ptr, ptr %t734, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %t735)
  br label %bb168
bb168:
  call void @__olang_scope_close(ptr %s24)
  br label %bb169
bb169:
  %t737 = load i64, ptr %l41, !tbaa !24
  %t739 = add i64 %t737, 1
  store i64 %t739, ptr %l41, !tbaa !24
  br label %bb164
bb170:
  %t741 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t741)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s21)
  br label %bb174
bb172:
  call void @__olang_scope_close(ptr %s21)
  br label %bb173
bb173:
  %t743 = load i64, ptr %l32, !tbaa !24
  %t745 = add i64 %t743, 1
  store i64 %t745, ptr %l32, !tbaa !24
  br label %bb144
bb174:
  call void @__olang_scope_close(ptr %s12)
  br label %bb175
bb175:
  %t747 = load i64, ptr %l20, !tbaa !24
  %t749 = add i64 %t747, 1
  store i64 %t749, ptr %l20, !tbaa !24
  br label %bb68
bb176:
  %t751 = load i64, ptr %l17, !tbaa !24
  %t752 = load i64, ptr %l19, !tbaa !24
  %t755 = add i64 %t751, %t752
  store i64 %t755, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb177
bb177:
  br label %bb61
bb178:
  %t757 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t757)
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l18 = alloca i32
  %l22 = alloca i64
  %l25 = alloca i64
  %l45 = alloca i1
  %l49 = alloca %"compiler/source:Span"
  %l54 = alloca i32
  %l58 = alloca ptr
  %l65 = alloca i32
  %l74 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i64
  %l89 = alloca i1
  %l97 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca %"compiler/msgs:Msg"
  %l110 = alloca i64
  %l114 = alloca ptr
  %l119 = alloca i32
  %l120 = alloca { i64, ptr }
  %l125 = alloca i1
  %l126 = alloca { i64, ptr }
  %l131 = alloca i1
  %l134 = alloca i1
  %l136 = alloca i1
  %l140 = alloca i32
  %l145 = alloca i64
  %l149 = alloca i64
  %l155 = alloca ptr
  %l160 = alloca i32
  %l161 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l174 = alloca i1
  %l176 = alloca i1
  %l179 = alloca ptr
  %l184 = alloca i32
  %l185 = alloca i64
  %l187 = alloca ptr
  %l191 = alloca i1
  %l192 = alloca ptr
  %l195 = alloca ptr
  %l200 = alloca i32
  %l201 = alloca i32
  %l202 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l205 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca %"compiler/source:Span"
  %l210 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l215 = alloca %"compiler/msgs:Msg"
  %l216 = alloca i64
  %l218 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  %t83 = alloca { i64, [4 x i64] }, align 8
  %t434 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load i32, ptr %l18, !tbaa !23
  store i32 %t6, ptr %l6, !tbaa !23
  store i64 0, ptr %l7, !tbaa !24
  store i64 4, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l9, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l9, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l9, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l25, !tbaa !24
  store i64 %t33, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l22, !tbaa !24
  store i64 %t34, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l11, !tbaa !24
  %t36 = load i64, ptr %l10, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l11, !tbaa !24
  %t45 = load i64, ptr %l9, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l12, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l6, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l45
  br label %bb12
bb12:
  %t58 = load i1, ptr %l45, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v0, ptr %t61, ptr %t62)
  br label %bb16
bb16:
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l49
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l6, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l54
  br label %bb17
bb17:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l1
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t76, %"compiler/source:Span" %t77, ptr %t78)
  store ptr %t82, ptr %l58
  br label %bb18
bb18:
  store { i64, [4 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 0
  store i64 2, ptr %t84
  %t85 = load %"compiler/source:Span", ptr %l49
  %t86 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t85, 0
  %t87 = load i32, ptr %l54, !tbaa !23
  %t88 = insertvalue { %"compiler/source:Span", i32, ptr } %t86, i32 %t87, 1
  %t89 = load ptr, ptr %l58, !tbaa !29
  %t90 = insertvalue { %"compiler/source:Span", i32, ptr } %t88, ptr %t89, 2
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t83
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t92, ptr %t94
  store ptr %t94, ptr %l5, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l6, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l65
  br label %bb19
bb19:
  %t106 = load i32, ptr %l65, !tbaa !23
  store i32 %t106, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l11, !tbaa !24
  br label %bb8
bb21:
  %t111 = load i32, ptr %l6, !tbaa !23
  %t112 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t115 = icmp eq i32 %t111, %t112
  br i1 %t115, label %bb22, label %bb23
bb22:
  store ptr null, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l6, !tbaa !23
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t118, i32 %t119)
  store i1 %t122, ptr %l74
  br label %bb25
bb25:
  %t123 = load i1, ptr %l74, !tbaa !21
  br i1 %t123, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l75, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t125, ptr %l76
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l6, !tbaa !23
  %t130 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t126, i32 %t127)
  store { i64, ptr } %t130, ptr %l79
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t131 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  %t133 = extractvalue { i64, ptr } %t131, 1
  %t134 = mul i64 %t132, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l80, !tbaa !27
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l4, !tbaa !23
  %t142 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t138, i32 %t139)
  store { i64, ptr } %t142, ptr %l83
  br label %bb29
bb29:
  %t143 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t145 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %s6, ptr %v0, ptr %s6, { i64, ptr } %t143, { i64, ptr } %t144)
  store %"compiler/msgs:Msg" %t145, ptr %l84
  br label %bb30
bb30:
  %t146 = load ptr, ptr %l75, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l76
  %t148 = load %"compiler/msgs:Msg", ptr %l84
  %t149 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t146, %"compiler/source:Span" %t147, %"compiler/msgs:Msg" %t148)
  store i64 %t149, ptr %l85
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  store ptr null, ptr %rv
  br label %ret
bb32:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i32, ptr %l6, !tbaa !23
  %t155 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t151, i32 %t152)
  store i1 %t155, ptr %l89
  br label %bb33
bb33:
  %t156 = load i1, ptr %l89, !tbaa !21
  %t157 = xor i1 %t156, true
  br i1 %t157, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s7, ptr %t159, %"compiler/source:Span" %t160, { i64, ptr } { i64 31, ptr @.d16 })
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  store ptr null, ptr %rv
  br label %ret
bb37:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l6, !tbaa !23
  %t166 = load i32, ptr %l4, !tbaa !23
  %t170 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %t164, i32 %t165, i32 %t166)
  store i64 %t170, ptr %l97
  br label %bb38
bb38:
  %t171 = load i64, ptr %l97, !tbaa !24
  store i64 %t171, ptr %l13, !tbaa !24
  %t172 = load i64, ptr %l13, !tbaa !24
  %t174 = icmp slt i64 %t172, 0
  br i1 %t174, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l100, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t177, ptr %l101
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l6, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t178, i32 %t179)
  store { i64, ptr } %t182, ptr %l104
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t183 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  %t185 = extractvalue { i64, ptr } %t183, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l105, !tbaa !27
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l4, !tbaa !23
  %t194 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t190, i32 %t191)
  store { i64, ptr } %t194, ptr %l108
  br label %bb42
bb42:
  %t195 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t197 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchMember(ptr %s8, ptr %v0, ptr %s8, { i64, ptr } %t195, { i64, ptr } %t196)
  store %"compiler/msgs:Msg" %t197, ptr %l109
  br label %bb43
bb43:
  %t198 = load ptr, ptr %l100, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l101
  %t200 = load %"compiler/msgs:Msg", ptr %l109
  %t201 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t198, %"compiler/source:Span" %t199, %"compiler/msgs:Msg" %t200)
  store i64 %t201, ptr %l110
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s8)
  store ptr null, ptr %rv
  br label %ret
bb45:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  store ptr %t208, ptr %l114, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/generic:Program", ptr %t212, i32 0, i32 2
  %t215 = load i32, ptr %l6, !tbaa !23
  %t218 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t214, i32 %t215)
  store i32 %t218, ptr %l119
  br label %bb46
bb46:
  %t219 = load ptr, ptr %l114, !tbaa !29
  %t220 = load i32, ptr %l119, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t219, i32 %t220)
  store { i64, ptr } %t221, ptr %l120
  br label %bb47
bb47:
  %t222 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t222, ptr %l14, !tbaa !27
  %t223 = load i64, ptr %l13, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t229 = icmp slt i64 %t223, %t226
  br i1 %t229, label %bb48, label %bb49
bb48:
  %t231 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t231, ptr %l126, !tbaa !27
  %t232 = load i64, ptr %l13, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  %t238 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t241 = icmp eq i32 %t237, %t238
  store i1 %t241, ptr %l125, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb50
bb50:
  %t243 = load i1, ptr %l125, !tbaa !21
  br i1 %t243, label %bb51, label %bb52
bb51:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i32, ptr %l6, !tbaa !23
  %t248 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t244, i32 %t245, i64 -1)
  store i1 %t248, ptr %l134
  br label %bb53
bb52:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb54
bb53:
  %t249 = load i1, ptr %l134, !tbaa !21
  %t250 = xor i1 %t249, true
  store i1 %t250, ptr %l131, !tbaa !21
  br label %bb54
bb54:
  %t252 = load i1, ptr %l131, !tbaa !21
  br i1 %t252, label %bb55, label %bb56
bb55:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t257 = load i32, ptr %l6, !tbaa !23
  %t260 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t256, i32 %t257)
  store i32 %t260, ptr %l140
  br label %bb57
bb56:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb58
bb57:
  %t261 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t262 = load i32, ptr %l140, !tbaa !23
  %t264 = icmp ne i32 %t262, %t261
  store i1 %t264, ptr %l136, !tbaa !21
  br label %bb58
bb58:
  %t266 = load i1, ptr %l136, !tbaa !21
  br i1 %t266, label %bb59, label %bb60
bb59:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l6, !tbaa !23
  %t271 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t267, i32 %t268)
  store i64 %t271, ptr %l145
  br label %bb61
bb60:
  br label %bb69
bb61:
  %t272 = load i64, ptr %l145, !tbaa !24
  store i64 %t272, ptr %l15, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 15
  %t276 = load i64, ptr %l15, !tbaa !24
  %t279 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t275, i64 %t276)
  store i64 %t279, ptr %l149
  br label %bb62
bb62:
  %t280 = load i64, ptr %l149, !tbaa !24
  %t281 = icmp eq i64 %t280, 0
  br i1 %t281, label %bb63, label %bb64
bb63:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %t283, i64 %t284)
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/check:Checker", ptr %t287, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !29
  %t292 = getelementptr %"compiler/generic:Program", ptr %t290, i32 0, i32 2
  store ptr %t292, ptr %l155, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/generic:Program", ptr %t296, i32 0, i32 2
  %t299 = load i32, ptr %l6, !tbaa !23
  %t302 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t298, i32 %t299)
  store i32 %t302, ptr %l160
  br label %bb66
bb66:
  %t303 = load ptr, ptr %l155, !tbaa !29
  %t304 = load i32, ptr %l160, !tbaa !23
  %t305 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t303, i32 %t304)
  store { i64, ptr } %t305, ptr %l161
  br label %bb67
bb67:
  %t306 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t306, ptr %l14, !tbaa !27
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t307 = load i64, ptr %l13, !tbaa !24
  %t308 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t313 = icmp sge i64 %t307, %t310
  br i1 %t313, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s11
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s11, ptr %t315, %"compiler/source:Span" %t316, { i64, ptr } { i64 32, ptr @.d17 })
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s11)
  store ptr null, ptr %rv
  br label %ret
bb73:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load i32, ptr %l4, !tbaa !23
  %t324 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t320, i32 %t321)
  store { i64, ptr } %t324, ptr %l171
  br label %bb74
bb74:
  %t325 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t325, ptr %l172, !tbaa !27
  %t326 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr i8, ptr %t327, i64 0
  %t329 = load i8, ptr %t328, !tbaa !32
  %t331 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t329)
  store i1 %t331, ptr %l174
  br label %bb75
bb75:
  %t332 = load i1, ptr %l174, !tbaa !21
  %t333 = xor i1 %t332, true
  br i1 %t333, label %bb76, label %bb77
bb76:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/check:Checker", ptr %t335, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t340 = getelementptr %"compiler/generic:Program", ptr %t338, i32 0, i32 2
  store ptr %t340, ptr %l179, !tbaa !29
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = getelementptr %"compiler/generic:Program", ptr %t344, i32 0, i32 2
  %t347 = load i32, ptr %l6, !tbaa !23
  %t350 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t346, i32 %t347)
  store i32 %t350, ptr %l184
  br label %bb78
bb77:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb81
bb78:
  %t351 = load ptr, ptr %l179, !tbaa !29
  %t352 = load i32, ptr %l184, !tbaa !23
  %t353 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t351, i32 %t352)
  store i64 %t353, ptr %l185
  br label %bb79
bb79:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t354)
  store ptr %t356, ptr %l187
  br label %bb80
bb80:
  %t357 = load ptr, ptr %l187, !tbaa !29
  %t359 = getelementptr %"compiler/check:frame", ptr %t357, i32 0, i32 1
  %t360 = load i64, ptr %t359, !tbaa !24
  %t361 = load i64, ptr %l185, !tbaa !24
  %t363 = icmp ne i64 %t361, %t360
  store i1 %t363, ptr %l176, !tbaa !21
  br label %bb81
bb81:
  %t365 = load i1, ptr %l176, !tbaa !21
  br i1 %t365, label %bb82, label %bb83
bb82:
  %t366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t366, ptr %l192, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/check:Checker", ptr %t367, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t372 = getelementptr %"compiler/generic:Program", ptr %t370, i32 0, i32 2
  store ptr %t372, ptr %l195, !tbaa !29
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/check:Checker", ptr %t373, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t378 = getelementptr %"compiler/generic:Program", ptr %t376, i32 0, i32 2
  %t379 = load i32, ptr %l6, !tbaa !23
  %t382 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l200
  br label %bb84
bb83:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb88
bb84:
  %t383 = load ptr, ptr %l195, !tbaa !29
  %t384 = load i32, ptr %l200, !tbaa !23
  %t385 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t383, i32 %t384)
  store i32 %t385, ptr %l201
  br label %bb85
bb85:
  %t386 = load ptr, ptr %l192, !tbaa !29
  %t387 = load i32, ptr %l201, !tbaa !23
  %t388 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t386, i32 %t387)
  store { i64, ptr } %t388, ptr %l202
  br label %bb86
bb86:
  %t389 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t389, ptr %l203, !tbaa !27
  %t390 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr i8, ptr %t391, i64 0
  %t393 = load i8, ptr %t392, !tbaa !32
  %t395 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t393)
  store i1 %t395, ptr %l205
  br label %bb87
bb87:
  %t396 = load i1, ptr %l205, !tbaa !21
  store i1 %t396, ptr %l191, !tbaa !21
  br label %bb88
bb88:
  %t397 = load i1, ptr %l191, !tbaa !21
  br i1 %t397, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s12
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l206, !tbaa !29
  %t399 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t399, ptr %l207
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load i32, ptr %l4, !tbaa !23
  %t404 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t400, i32 %t401)
  store { i64, ptr } %t404, ptr %l210
  br label %bb91
bb90:
  br label %bb95
bb91:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i32, ptr %l6, !tbaa !23
  %t409 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t405, i32 %t406)
  store { i64, ptr } %t409, ptr %l213
  br label %bb92
bb92:
  %t410 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t410, 0
  %t412 = extractvalue { i64, ptr } %t410, 1
  %t413 = mul i64 %t411, 1
  %t414 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t413)
  call void @llvm.memcpy.p0.p0.i64(ptr %t414, ptr %t412, i64 %t413, i1 false)
  %t415 = insertvalue { i64, ptr } undef, i64 %t411, 0
  %t416 = insertvalue { i64, ptr } %t415, ptr %t414, 1
  %t417 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t419 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMemberIsPrivate(ptr %v0, ptr %s12, ptr %s12, { i64, ptr } %t417, { i64, ptr } %t416)
  store %"compiler/msgs:Msg" %t419, ptr %l215
  br label %bb93
bb93:
  %t420 = load ptr, ptr %l206, !tbaa !29
  %t421 = load %"compiler/source:Span", ptr %l207
  %t422 = load %"compiler/msgs:Msg", ptr %l215
  %t423 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t420, %"compiler/source:Span" %t421, %"compiler/msgs:Msg" %t422)
  store i64 %t423, ptr %l216
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s12)
  br label %bb95
bb95:
  %t424 = load %"compiler/source:Span", ptr %l1
  %t425 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t425, ptr %l218, !tbaa !27
  %t426 = load i64, ptr %l13, !tbaa !24
  %t428 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr i32, ptr %t429, i64 %t426
  %t431 = load i32, ptr %t430, !tbaa !33
  %t432 = load ptr, ptr %l5, !tbaa !29
  %t433 = load i64, ptr %l13, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t434
  %t435 = getelementptr { i64, [4 x i64] }, ptr %t434, i32 0, i32 0
  store i64 3, ptr %t435
  %t437 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t424, 0
  %t439 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t437, i32 %t431, 1
  %t441 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t439, ptr %t432, 2
  %t443 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t441, i64 %t433, 3
  %t444 = getelementptr { i64, [4 x i64] }, ptr %t434, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t443, ptr %t444
  %t445 = load { i64, [4 x i64] }, ptr %t434
  %t447 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t445, ptr %t447
  store ptr %t447, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldDeclAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l26 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l63 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca i1
  %l83 = alloca { i64, ptr }
  %l97 = alloca { i64, [3 x i64] }
  %l102 = alloca i1
  %l114 = alloca { i64, ptr }
  %l125 = alloca { i64, [3 x i64] }
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, [3 x i64] }
  %t33 = alloca { i64, [3 x i64] }, align 8
  %t75 = alloca { i64, [3 x i64] }, align 8
  %t243 = alloca { i64, [3 x i64] }, align 8
  %t259 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l26
  br label %bb1
bb1:
  %t11 = load i32, ptr %l26, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t15, i32 %t16)
  store ptr %t19, ptr %l30
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l30, !tbaa !29
  store ptr %t20, ptr %l4, !tbaa !29
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb5
bb4:
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TypeDecl", ptr %t25, i32 0, i32 3
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  store i1 %t30, ptr %l33, !tbaa !21
  br label %bb5
bb5:
  %t32 = load i1, ptr %l33, !tbaa !21
  br i1 %t32, label %bb6, label %bb7
bb6:
  store { i64, [3 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [3 x i64] }, ptr %t33, i32 0, i32 0
  store i64 0, ptr %t34
  %t35 = load { i64, [3 x i64] }, ptr %t33
  store { i64, [3 x i64] } %t35, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t40, i32 %t41)
  store i64 %t44, ptr %l41
  br label %bb9
bb9:
  %t45 = load i64, ptr %l41, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TypeDecl", ptr %t46, i32 0, i32 3
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l6, !tbaa !29
  %t51 = load ptr, ptr %l6, !tbaa !29
  store ptr %t51, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t52 = load ptr, ptr %l44, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb10, label %bb11
bb10:
  %t55 = load ptr, ptr %l44, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 0
  store i1 %t58, ptr %l45, !tbaa !21
  br label %bb11
bb11:
  %t59 = load i1, ptr %l45, !tbaa !21
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = getelementptr { i64, [6 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { ptr }, ptr %t62, i32 0, i32 0
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l7, !tbaa !29
  br label %bb14
bb13:
  br label %bb63
bb14:
  %t66 = load ptr, ptr %l7, !tbaa !29
  %t68 = getelementptr %"compiler/ast:StructBody", ptr %t66, i32 0, i32 2
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t73 = icmp eq i64 %t71, 0
  br i1 %t73, label %bb15, label %bb16
bb15:
  store { i64, [3 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t75, i32 0, i32 0
  store i64 0, ptr %t76
  %t77 = load { i64, [3 x i64] }, ptr %t75
  store { i64, [3 x i64] } %t77, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l8, !tbaa !24
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t81 = getelementptr %"compiler/ast:StructBody", ptr %t79, i32 0, i32 2
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l11, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb20:
  br label %bb21
bb21:
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t96, ptr %l63, !tbaa !27
  %t97 = load i64, ptr %l10, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  store ptr %t102, ptr %l12, !tbaa !29
  %t104 = load ptr, ptr %l12, !tbaa !29
  store ptr %t104, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t105 = load ptr, ptr %l66, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb22, label %bb23
bb22:
  %t108 = load ptr, ptr %l66, !tbaa !29
  %t109 = load i64, ptr %t108
  %t111 = icmp eq i64 %t109, 1
  store i1 %t111, ptr %l67, !tbaa !21
  br label %bb23
bb23:
  %t112 = load i1, ptr %l67, !tbaa !21
  br i1 %t112, label %bb24, label %bb25
bb24:
  %t113 = load ptr, ptr %l12, !tbaa !29
  %t115 = getelementptr { i64, [5 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", ptr }, ptr %t115, i32 0, i32 1
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l13, !tbaa !29
  br label %bb26
bb25:
  br label %bb59
bb26:
  %t119 = load ptr, ptr %l13, !tbaa !29
  %t121 = getelementptr %"compiler/ast:VarDecl", ptr %t119, i32 0, i32 5
  %t122 = load i1, ptr %t121, !tbaa !21
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb28:
  br label %bb29
bb29:
  %t126 = load ptr, ptr %l13, !tbaa !29
  %t128 = getelementptr %"compiler/ast:VarDecl", ptr %t126, i32 0, i32 0
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l16, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t135 = load i64, ptr %l15, !tbaa !24
  %t136 = load i64, ptr %l16, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb32:
  br label %bb33
bb33:
  %t143 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t143, ptr %l83, !tbaa !27
  %t144 = load i64, ptr %l15, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 %t144
  %t149 = load i32, ptr %t148, !tbaa !33
  store i32 %t149, ptr %l17, !tbaa !23
  %t151 = load i64, ptr %l8, !tbaa !24
  %t155 = icmp eq i64 %t151, %a2
  br i1 %t155, label %bb34, label %bb35
bb34:
  %t157 = load ptr, ptr %l13, !tbaa !29
  %t159 = getelementptr %"compiler/ast:VarDecl", ptr %t157, i32 0, i32 2
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb36, label %bb37
bb35:
  br label %bb56
bb36:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i64, ptr %l5, !tbaa !24
  %t168 = load ptr, ptr %l13, !tbaa !29
  %t170 = getelementptr %"compiler/ast:VarDecl", ptr %t168, i32 0, i32 2
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t175 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t166, i64 %t167, ptr %t171)
  store { i64, [3 x i64] } %t175, ptr %l97
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  %t176 = load { i64, [3 x i64] }, ptr %l97
  store { i64, [3 x i64] } %t176, ptr %rv
  br label %ret
bb39:
  %t177 = load ptr, ptr %l7, !tbaa !29
  %t179 = getelementptr %"compiler/ast:StructBody", ptr %t177, i32 0, i32 0
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t184 = icmp sgt i64 %t182, 0
  br i1 %t184, label %bb40, label %bb41
bb40:
  %t186 = load ptr, ptr %l13, !tbaa !29
  %t188 = getelementptr %"compiler/ast:VarDecl", ptr %t186, i32 0, i32 4
  %t189 = load i1, ptr %t188, !tbaa !21
  %t191 = xor i1 %t189, true
  store i1 %t191, ptr %l102, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb42
bb42:
  %t193 = load i1, ptr %l102, !tbaa !21
  br i1 %t193, label %bb43, label %bb44
bb43:
  %t194 = load ptr, ptr %l7, !tbaa !29
  %t196 = getelementptr %"compiler/ast:StructBody", ptr %t194, i32 0, i32 0
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t199, 0
  store i64 %t201, ptr %l20, !tbaa !24
  br label %bb45
bb44:
  br label %bb55
bb45:
  store %olang.scope zeroinitializer, ptr %s14
  %t203 = load i64, ptr %l19, !tbaa !24
  %t204 = load i64, ptr %l20, !tbaa !24
  %t207 = icmp slt i64 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s14)
  br label %bb54
bb47:
  br label %bb48
bb48:
  %t211 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t211, ptr %l114, !tbaa !27
  %t212 = load i64, ptr %l19, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr ptr, ptr %t215, i64 %t212
  %t217 = load ptr, ptr %t216, !tbaa !39
  store ptr %t217, ptr %l21, !tbaa !29
  %t219 = load ptr, ptr %l21, !tbaa !29
  %t221 = getelementptr %"compiler/ast:Param", ptr %t219, i32 0, i32 1
  %t222 = load i32, ptr %t221, !tbaa !23
  %t223 = load i32, ptr %l17, !tbaa !23
  %t226 = icmp eq i32 %t222, %t223
  br i1 %t226, label %bb49, label %bb50
bb49:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i64, ptr %l5, !tbaa !24
  %t230 = load ptr, ptr %l21, !tbaa !29
  %t232 = getelementptr %"compiler/ast:Param", ptr %t230, i32 0, i32 2
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t237 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t228, i64 %t229, ptr %t233)
  store { i64, [3 x i64] } %t237, ptr %l125
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  %t238 = load { i64, [3 x i64] }, ptr %l125
  store { i64, [3 x i64] } %t238, ptr %rv
  br label %ret
bb52:
  call void @__olang_scope_close(ptr %s14)
  br label %bb53
bb53:
  %t239 = load i64, ptr %l19, !tbaa !24
  %t241 = add i64 %t239, 1
  store i64 %t241, ptr %l19, !tbaa !24
  br label %bb45
bb54:
  br label %bb55
bb55:
  store { i64, [3 x i64] } zeroinitializer, ptr %t243
  %t244 = getelementptr { i64, [3 x i64] }, ptr %t243, i32 0, i32 0
  store i64 0, ptr %t244
  %t245 = load { i64, [3 x i64] }, ptr %t243
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  store { i64, [3 x i64] } %t245, ptr %rv
  br label %ret
bb56:
  %t247 = load i64, ptr %l8, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb57:
  %t251 = load i64, ptr %l15, !tbaa !24
  %t253 = add i64 %t251, 1
  store i64 %t253, ptr %l15, !tbaa !24
  br label %bb30
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb61:
  %t255 = load i64, ptr %l10, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l10, !tbaa !24
  br label %bb18
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  store { i64, [3 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t259, i32 0, i32 0
  store i64 0, ptr %t260
  %t261 = load { i64, [3 x i64] }, ptr %t259
  store { i64, [3 x i64] } %t261, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local { ptr, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitQuiet(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca i64
  %l17 = alloca i64
  %l22 = alloca ptr
  %l31 = alloca i64
  %rv = alloca { ptr, i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/load:Loader", ptr %t20, i32 0, i32 4
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l17
  br label %bb2
bb2:
  %t26 = load i64, ptr %l17, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t27, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
  store ptr %t35, ptr %l22
  br label %bb3
bb3:
  %t36 = load ptr, ptr %l22, !tbaa !29
  store ptr %t36, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/load:Loader", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t46)
  br label %bb4
bb4:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/load:Loader", ptr %t54, i32 0, i32 4
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l31
  br label %bb5
bb5:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l31, !tbaa !24
  %t63 = icmp eq i64 %t61, %t60
  store i1 %t63, ptr %l7, !tbaa !21
  %t65 = load i1, ptr %l7, !tbaa !21
  br i1 %t65, label %bb6, label %bb7
bb6:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/load:Loader", ptr %t73, i32 0, i32 4
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t76, i64 %t77)
  br label %bb8
bb7:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/load:Loader", ptr %t86, i32 0, i32 4
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t89, i64 %t90)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t94 = load i1, ptr %l7, !tbaa !21
  %t96 = insertvalue { ptr, i1 } undef, ptr %t93, 0
  %t98 = insertvalue { ptr, i1 } %t96, i1 %t94, 1
  store { ptr, i1 } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { ptr, i1 }, ptr %rv
  ret { ptr, i1 } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/generic:Origin"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca ptr
  %l15 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l33 = alloca ptr
  %l38 = alloca i64
  %l45 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l53 = alloca { i64, ptr }
  %l54 = alloca %"compiler/msgs:Msg"
  %l55 = alloca i64
  %l58 = alloca ptr
  %l62 = alloca i1
  %l66 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l75 = alloca { i64, ptr }
  %l76 = alloca %"compiler/msgs:Msg"
  %l77 = alloca i64
  %l80 = alloca ptr
  %l85 = alloca i32
  %l90 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca i32
  %l101 = alloca { i64, [3 x i64] }
  %l102 = alloca i1
  %l105 = alloca ptr
  %l108 = alloca i1
  %l112 = alloca i1
  %l117 = alloca ptr
  %l121 = alloca i32
  %l126 = alloca ptr
  %l128 = alloca ptr
  %l130 = alloca i64
  %l131 = alloca %"compiler/source:Span"
  %l133 = alloca i64
  %l134 = alloca %"compiler/generic:Origin"
  %l139 = alloca i64
  %l145 = alloca i1
  %l146 = alloca ptr
  %l150 = alloca i32
  %l152 = alloca i1
  %l156 = alloca ptr
  %l159 = alloca i64
  %l163 = alloca i32
  %l166 = alloca i1
  %l169 = alloca ptr
  %l174 = alloca i32
  %l179 = alloca i32
  %l182 = alloca i32
  %l187 = alloca i32
  %l188 = alloca i32
  %l190 = alloca ptr
  %l191 = alloca i64
  %l194 = alloca { i64, [3 x i64] }
  %l195 = alloca ptr
  %l199 = alloca ptr
  %l202 = alloca { i64, ptr }
  %l205 = alloca %"compiler/check:roFn"
  %l209 = alloca ptr
  %l213 = alloca i1
  %l217 = alloca i64
  %l220 = alloca ptr
  %l225 = alloca i32
  %l226 = alloca { i64, ptr }
  %l231 = alloca ptr
  %l232 = alloca i32
  %l237 = alloca i64
  %l238 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t502 = alloca { i64, [4 x i64] }, align 8
  %t510 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 0, ptr %l4, !tbaa !23
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t8, i64 %t9)
  store i1 %t12, ptr %l19
  br label %bb3
bb2:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i1, ptr %l19, !tbaa !21
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l15, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l15, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l23, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t21)
  store i64 %t23, ptr %l25
  br label %bb7
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb9
bb7:
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = load i64, ptr %l25, !tbaa !24
  %t26 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t26, ptr %l26
  br label %bb8
bb8:
  %t27 = load i64, ptr %l26, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  store i1 %t28, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t31)
  store i64 %t33, ptr %l29
  br label %bb12
bb11:
  br label %bb48
bb12:
  %t34 = load i64, ptr %l29, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l2, !tbaa !24
  %t42 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t38, i64 %t39)
  store ptr %t42, ptr %l33
  br label %bb13
bb13:
  %t43 = load ptr, ptr %l33, !tbaa !29
  store ptr %t43, ptr %l6, !tbaa !29
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 5
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l6, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Func", ptr %t53, i32 0, i32 5
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l38, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb16
bb16:
  %t60 = load i64, ptr %l38, !tbaa !24
  store i64 %t60, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t64, i64 %t65)
  store i64 %t68, ptr %l45
  br label %bb17
bb17:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l45, !tbaa !24
  %t72 = icmp sgt i64 %t70, %t69
  br i1 %t72, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l48, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t75, ptr %l49
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t76, i32 %t80)
  store { i64, ptr } %t83, ptr %l53
  br label %bb20
bb19:
  br label %bb24
bb20:
  %t84 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t85 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLengthsNotAValue(ptr %v0, ptr %s2, { i64, ptr } %t84)
  store %"compiler/msgs:Msg" %t85, ptr %l54
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l48, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l49
  %t88 = load %"compiler/msgs:Msg", ptr %l54
  %t89 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t86, %"compiler/source:Span" %t87, %"compiler/msgs:Msg" %t88)
  store i64 %t89, ptr %l55
  br label %bb22
bb22:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load %"compiler/source:Span", ptr %l1
  %t94 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t90, %"compiler/source:Span" %t91)
  store ptr %t94, ptr %l58
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t95 = load ptr, ptr %l58, !tbaa !29
  store ptr %t95, ptr %rv
  br label %ret
bb24:
  %t96 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t100 = icmp eq i64 %t98, 0
  br i1 %t100, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb28
bb26:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t106 = load i64, ptr %l5, !tbaa !24
  %t109 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t105, i64 %t106)
  store i64 %t109, ptr %l66
  br label %bb27
bb27:
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = load i64, ptr %l66, !tbaa !24
  %t115 = icmp ne i64 %t113, %t112
  store i1 %t115, ptr %l62, !tbaa !21
  br label %bb28
bb28:
  %t117 = load i1, ptr %l62, !tbaa !21
  br i1 %t117, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l70, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t119, ptr %l71
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l6, !tbaa !29
  %t123 = getelementptr %"compiler/ast:Func", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t120, i32 %t124)
  store { i64, ptr } %t127, ptr %l75
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t128 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t129 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotAValue(ptr %v0, ptr %s3, { i64, ptr } %t128)
  store %"compiler/msgs:Msg" %t129, ptr %l76
  br label %bb32
bb32:
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l71
  %t132 = load %"compiler/msgs:Msg", ptr %l76
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t130, %"compiler/source:Span" %t131, %"compiler/msgs:Msg" %t132)
  store i64 %t133, ptr %l77
  br label %bb33
bb33:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t134, %"compiler/source:Span" %t135)
  store ptr %t138, ptr %l80
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t139 = load ptr, ptr %l80, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb35:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t145, { i64, ptr } %t146)
  store i32 %t149, ptr %l85
  br label %bb36
bb36:
  %t150 = load i32, ptr %l85, !tbaa !23
  store i32 %t150, ptr %l4, !tbaa !23
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l5, !tbaa !24
  %t153 = load i32, ptr %l4, !tbaa !23
  %t154 = load %"compiler/source:Span", ptr %l1
  %t159 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebound(ptr %v0, ptr %t151, i64 %t152, i32 %t153, %"compiler/source:Span" %t154)
  store i1 %t159, ptr %l90
  br label %bb37
bb37:
  %t160 = load i1, ptr %l90, !tbaa !21
  %t161 = xor i1 %t160, true
  br i1 %t161, label %bb38, label %bb39
bb38:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l1
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t163, %"compiler/source:Span" %t164)
  store ptr %t167, ptr %l94
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t168 = load ptr, ptr %l94, !tbaa !29
  store ptr %t168, ptr %rv
  br label %ret
bb41:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  store ptr %t172, ptr %l96, !tbaa !29
  %t173 = load i64, ptr %l2, !tbaa !24
  store i64 %t173, ptr %l97, !tbaa !24
  %t174 = load i32, ptr %l4, !tbaa !23
  store i32 %t174, ptr %l98, !tbaa !23
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i64, ptr %l2, !tbaa !24
  %t179 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnNameAt(ptr %v0, ptr %t175, i64 %t176)
  store { i64, [3 x i64] } %t179, ptr %l101
  br label %bb42
bb42:
  %t180 = load ptr, ptr %l96, !tbaa !29
  %t181 = load i64, ptr %l97, !tbaa !24
  %t182 = load i32, ptr %l98, !tbaa !23
  %t183 = load { i64, [3 x i64] }, ptr %l101
  %t184 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnTooDeep(ptr %v0, ptr %t180, i64 %t181, i32 %t182, { i64, [3 x i64] } %t183)
  store i1 %t184, ptr %l102
  br label %bb43
bb43:
  %t185 = load i1, ptr %l102, !tbaa !21
  br i1 %t185, label %bb44, label %bb45
bb44:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  %t190 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t186, %"compiler/source:Span" %t187)
  store ptr %t190, ptr %l105
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t191 = load ptr, ptr %l105, !tbaa !29
  store ptr %t191, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t192 = load i64, ptr %l2, !tbaa !24
  %t194 = icmp slt i64 %t192, 0
  br i1 %t194, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb52
bb50:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t200 = load i64, ptr %l2, !tbaa !24
  %t203 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t199, i64 %t200)
  store i1 %t203, ptr %l112
  br label %bb51
bb51:
  %t204 = load i1, ptr %l112, !tbaa !21
  store i1 %t204, ptr %l108, !tbaa !21
  br label %bb52
bb52:
  %t205 = load i1, ptr %l108, !tbaa !21
  br i1 %t205, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s6
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s6, ptr %t206, %"compiler/source:Span" %t207, { i64, ptr } { i64 35, ptr @.d18 })
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  %t214 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t210, %"compiler/source:Span" %t211)
  store ptr %t214, ptr %l117
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t215 = load ptr, ptr %l117, !tbaa !29
  store ptr %t215, ptr %rv
  br label %ret
bb57:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t220 = load i64, ptr %l2, !tbaa !24
  %t223 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t219, i64 %t220)
  store i32 %t223, ptr %l121
  br label %bb58
bb58:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 30
  %t230 = load %"compiler/generic:Origin", ptr %t229
  store %"compiler/generic:Origin" %t230, ptr %l8
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  store ptr %t235, ptr %l126, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t236)
  store ptr %t238, ptr %l128
  br label %bb59
bb59:
  %t239 = load ptr, ptr %l128, !tbaa !29
  %t241 = getelementptr %"compiler/check:frame", ptr %t239, i32 0, i32 2
  %t242 = load i64, ptr %t241, !tbaa !24
  store i64 %t242, ptr %l130, !tbaa !24
  %t243 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t243, ptr %l131
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %t244)
  store i64 %t246, ptr %l133
  br label %bb60
bb60:
  %t247 = load i64, ptr %l130, !tbaa !24
  %t248 = load %"compiler/source:Span", ptr %l131
  %t249 = load i64, ptr %l133, !tbaa !24
  %t250 = call %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %s0, i64 %t247, %"compiler/source:Span" %t248, i64 %t249)
  store %"compiler/generic:Origin" %t250, ptr %l134
  br label %bb61
bb61:
  %t251 = load %"compiler/generic:Origin", ptr %l134
  %t252 = load ptr, ptr %l126, !tbaa !29
  %t253 = getelementptr %"compiler/generic:Program", ptr %t252, i32 0, i32 30
  store %"compiler/generic:Origin" %t251, ptr %t253
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t254, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t258 = load i64, ptr %l2, !tbaa !24
  %t259 = load i32, ptr %l4, !tbaa !23
  %t263 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t257, i64 %t258, i32 %t259)
  store i64 %t263, ptr %l139
  br label %bb62
bb62:
  %t264 = load i64, ptr %l139, !tbaa !24
  store i64 %t264, ptr %l9, !tbaa !24
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t269 = load %"compiler/generic:Origin", ptr %l8
  %t272 = getelementptr %"compiler/generic:Program", ptr %t268, i32 0, i32 30
  store %"compiler/generic:Origin" %t269, ptr %t272
  %t273 = load i32, ptr %l4, !tbaa !23
  %t275 = icmp ne i32 %t273, 0
  br i1 %t275, label %bb63, label %bb64
bb63:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l146, !tbaa !29
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t282 = load i64, ptr %l9, !tbaa !24
  %t285 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t281, i64 %t282)
  store i32 %t285, ptr %l150
  br label %bb65
bb64:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb67
bb65:
  %t286 = load %"compiler/source:Span", ptr %l1
  %t287 = load ptr, ptr %l146, !tbaa !29
  %t288 = load i32, ptr %l150, !tbaa !23
  %t290 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t287, i32 %t288, %"compiler/source:Span" %t286)
  store i1 %t290, ptr %l152
  br label %bb66
bb66:
  %t291 = load i1, ptr %l152, !tbaa !21
  %t292 = xor i1 %t291, true
  store i1 %t292, ptr %l145, !tbaa !21
  br label %bb67
bb67:
  %t294 = load i1, ptr %l145, !tbaa !21
  br i1 %t294, label %bb68, label %bb69
bb68:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l1
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t295, %"compiler/source:Span" %t296)
  store ptr %t299, ptr %l156
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t300 = load ptr, ptr %l156, !tbaa !29
  store ptr %t300, ptr %rv
  br label %ret
bb71:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i64, ptr %l9, !tbaa !24
  %t305 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t301, i64 %t302)
  store i64 %t305, ptr %l159
  br label %bb72
bb72:
  %t306 = load i64, ptr %l159, !tbaa !24
  store i64 %t306, ptr %l10, !tbaa !24
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t311 = load i64, ptr %l9, !tbaa !24
  %t314 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t310, i64 %t311)
  store i32 %t314, ptr %l163
  br label %bb73
bb73:
  %t315 = load i32, ptr %l163, !tbaa !23
  store i32 %t315, ptr %l11, !tbaa !23
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load i32, ptr %l11, !tbaa !23
  %t320 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t316, i32 %t317)
  store i1 %t320, ptr %l166
  br label %bb74
bb74:
  %t321 = load i1, ptr %l166, !tbaa !21
  br i1 %t321, label %bb75, label %bb76
bb75:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/check:Checker", ptr %t322, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t327 = getelementptr %"compiler/generic:Program", ptr %t325, i32 0, i32 2
  store ptr %t327, ptr %l169, !tbaa !29
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/check:Checker", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = getelementptr %"compiler/generic:Program", ptr %t331, i32 0, i32 2
  %t334 = load i32, ptr %l11, !tbaa !23
  %t337 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t333, i32 %t334)
  store i32 %t337, ptr %l174
  br label %bb77
bb76:
  br label %bb82
bb77:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/check:Checker", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = getelementptr %"compiler/generic:Program", ptr %t341, i32 0, i32 2
  %t344 = load i32, ptr %l11, !tbaa !23
  %t347 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t343, i32 %t344)
  store i32 %t347, ptr %l179
  br label %bb78
bb78:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i64, ptr %l10, !tbaa !24
  %t352 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t348, i64 %t349)
  store i32 %t352, ptr %l182
  br label %bb79
bb79:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/check:Checker", ptr %t353, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !29
  %t358 = getelementptr %"compiler/generic:Program", ptr %t356, i32 0, i32 2
  %t359 = load i32, ptr %l11, !tbaa !23
  %t362 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t358, i32 %t359)
  store i32 %t362, ptr %l187
  br label %bb80
bb80:
  %t363 = load ptr, ptr %l169, !tbaa !29
  %t364 = load i32, ptr %l174, !tbaa !23
  %t365 = load i32, ptr %l179, !tbaa !23
  %t366 = load i32, ptr %l182, !tbaa !23
  %t367 = load i32, ptr %l187, !tbaa !23
  %t368 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t363, i32 %t364, i32 %t365, i32 %t366, i32 %t367, i64 0)
  store i32 %t368, ptr %l188
  br label %bb81
bb81:
  %t369 = load i32, ptr %l188, !tbaa !23
  store i32 %t369, ptr %l11, !tbaa !23
  br label %bb82
bb82:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/check:Checker", ptr %t370, i32 0, i32 59
  store ptr %t372, ptr %l190, !tbaa !29
  %t373 = load i64, ptr %l10, !tbaa !24
  store i64 %t373, ptr %l191, !tbaa !24
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load %"compiler/source:Span", ptr %l1
  %t378 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t374, %"compiler/source:Span" %t375)
  store { i64, [3 x i64] } %t378, ptr %l194
  br label %bb83
bb83:
  %t379 = load ptr, ptr %l0, !tbaa !29
  store ptr %t379, ptr %l195, !tbaa !29
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t384 = load i64, ptr %l2, !tbaa !24
  %t387 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t383, i64 %t384)
  store ptr %t387, ptr %l199
  br label %bb84
bb84:
  %t388 = load ptr, ptr %l199, !tbaa !29
  %t390 = getelementptr %"compiler/ast:Func", ptr %t388, i32 0, i32 2
  %t391 = load i32, ptr %t390, !tbaa !23
  %t392 = load ptr, ptr %l195, !tbaa !29
  %t394 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t392, i32 %t391)
  store { i64, ptr } %t394, ptr %l202
  br label %bb85
bb85:
  %t395 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 1
  %t396 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 0
  %t397 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 1
  %t399 = extractvalue { i64, ptr } %t397, 0
  %t400 = add i64 %t396, %t399
  %t401 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t402 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  %t403 = add i64 %t400, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t395, i64 %t396)
  %t405 = getelementptr i8, ptr %t404, i64 %t396
  call void @olang_textcopy(ptr %t405, ptr %t398, i64 %t399)
  %t406 = getelementptr i8, ptr %t405, i64 %t399
  call void @olang_textcopy(ptr %t406, ptr %t401, i64 %t402)
  %t407 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t404, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = extractvalue { i64, ptr } %t408, 1
  %t412 = mul i64 %t410, 1
  %t413 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t412)
  call void @llvm.memcpy.p0.p0.i64(ptr %t413, ptr %t411, i64 %t412, i1 false)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t413, 1
  %t416 = load i64, ptr %l191, !tbaa !24
  %t417 = load { i64, [3 x i64] }, ptr %l194
  %t419 = call %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v0, i64 %t416, i64 0, { i64, [3 x i64] } %t417, { i64, ptr } %t415)
  store %"compiler/check:roFn" %t419, ptr %l205
  br label %bb86
bb86:
  %t420 = load ptr, ptr %l190, !tbaa !29
  %t421 = load %"compiler/check:roFn", ptr %l205
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v0, ptr %t420, %"compiler/check:roFn" %t421)
  br label %bb87
bb87:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/check:Checker", ptr %t422, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !29
  %t426 = load i64, ptr %l2, !tbaa !24
  %t429 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t425, i64 %t426)
  store ptr %t429, ptr %l209
  br label %bb88
bb88:
  %t430 = load ptr, ptr %l209, !tbaa !29
  store ptr %t430, ptr %l12, !tbaa !29
  %t431 = load ptr, ptr %l12, !tbaa !29
  %t433 = getelementptr %"compiler/ast:Func", ptr %t431, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t436 = icmp eq ptr %t434, null
  br i1 %t436, label %bb89, label %bb90
bb89:
  %t438 = load ptr, ptr %l12, !tbaa !29
  %t440 = getelementptr %"compiler/ast:Func", ptr %t438, i32 0, i32 3
  %t441 = load ptr, ptr %t440, !tbaa !29
  %t443 = getelementptr %"compiler/ast:Sig", ptr %t441, i32 0, i32 0
  %t444 = load { i64, ptr }, ptr %t443, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t444, 0
  store i64 %t446, ptr %l217, !tbaa !24
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !29
  %t452 = getelementptr %"compiler/generic:Program", ptr %t450, i32 0, i32 2
  store ptr %t452, ptr %l220, !tbaa !29
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/check:Checker", ptr %t453, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t458 = getelementptr %"compiler/generic:Program", ptr %t456, i32 0, i32 2
  %t459 = load i32, ptr %l11, !tbaa !23
  %t462 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t458, i32 %t459)
  store i32 %t462, ptr %l225
  br label %bb91
bb90:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb93
bb91:
  %t463 = load ptr, ptr %l220, !tbaa !29
  %t464 = load i32, ptr %l225, !tbaa !23
  %t465 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t463, i32 %t464)
  store { i64, ptr } %t465, ptr %l226
  br label %bb92
bb92:
  %t466 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 0
  %t468 = load i64, ptr %l217, !tbaa !24
  %t470 = icmp eq i64 %t468, %t467
  store i1 %t470, ptr %l213, !tbaa !21
  br label %bb93
bb93:
  %t472 = load i1, ptr %l213, !tbaa !21
  br i1 %t472, label %bb94, label %bb95
bb94:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t475 = getelementptr %"compiler/check:Checker", ptr %t473, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !29
  %t478 = getelementptr %"compiler/generic:Program", ptr %t476, i32 0, i32 2
  store ptr %t478, ptr %l231, !tbaa !29
  %t479 = load i32, ptr %l11, !tbaa !23
  store i32 %t479, ptr %l232, !tbaa !23
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = getelementptr %"compiler/check:Checker", ptr %t480, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !29
  %t484 = load ptr, ptr %l12, !tbaa !29
  %t486 = getelementptr %"compiler/ast:Func", ptr %t484, i32 0, i32 3
  %t487 = load ptr, ptr %t486, !tbaa !29
  %t490 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v0, ptr %t483, ptr %t487)
  store i64 %t490, ptr %l237
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t491 = load ptr, ptr %l231, !tbaa !29
  %t492 = load i32, ptr %l232, !tbaa !23
  %t493 = load i64, ptr %l237, !tbaa !24
  %t494 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t491, i32 %t492, i64 %t493)
  store i32 %t494, ptr %l238
  br label %bb97
bb97:
  %t495 = load i32, ptr %l238, !tbaa !23
  store i32 %t495, ptr %l11, !tbaa !23
  br label %bb98
bb98:
  %t496 = load %"compiler/source:Span", ptr %l1
  %t497 = load i32, ptr %l11, !tbaa !23
  %t498 = load i64, ptr %l10, !tbaa !24
  %t500 = trunc i64 %t498 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t502
  %t503 = getelementptr { i64, [4 x i64] }, ptr %t502, i32 0, i32 0
  store i64 0, ptr %t503
  %t505 = insertvalue { i32 } undef, i32 %t500, 0
  %t506 = getelementptr { i64, [4 x i64] }, ptr %t502, i32 0, i32 1
  store { i32 } %t505, ptr %t506
  %t507 = load { i64, [4 x i64] }, ptr %t502
  %t509 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t507, ptr %t509
  store { i64, [5 x i64] } zeroinitializer, ptr %t510
  %t511 = getelementptr { i64, [5 x i64] }, ptr %t510, i32 0, i32 0
  store i64 15, ptr %t511
  %t513 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t496, 0
  %t515 = insertvalue { %"compiler/source:Span", i32, ptr } %t513, i32 %t497, 1
  %t517 = insertvalue { %"compiler/source:Span", i32, ptr } %t515, ptr %t509, 2
  %t518 = getelementptr { i64, [5 x i64] }, ptr %t510, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t517, ptr %t518
  %t519 = load { i64, [5 x i64] }, ptr %t510
  %t521 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t519, ptr %t521
  call void @__olang_scope_close(ptr %s0)
  store ptr %t521, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/check:litv"
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"compiler/check:litv"
  %l15 = alloca { i1, i64 }
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca %"compiler/check:litv"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/check:litv"
  %l23 = alloca %"compiler/check:litv"
  %l24 = alloca double
  %l25 = alloca double
  %l26 = alloca { i1, i64 }
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca { i1, i64 }
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"compiler/check:litv"
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l40 = alloca %"compiler/check:litv"
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca i32
  %l81 = alloca i64
  %l82 = alloca i32
  %l83 = alloca %"compiler/check:litv"
  %l86 = alloca %"compiler/check:litv"
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i32
  %l92 = alloca i64
  %l93 = alloca i32
  %l94 = alloca i64
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca i32
  %l98 = alloca i64
  %l99 = alloca i32
  %l100 = alloca %"compiler/check:litv"
  %l103 = alloca %"compiler/check:litv"
  %l105 = alloca %"compiler/check:litv"
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l114 = alloca double
  %l116 = alloca double
  %l117 = alloca i32
  %l118 = alloca %"compiler/check:litv"
  %l120 = alloca %"compiler/check:litv"
  %l121 = alloca %"compiler/check:litv"
  %l122 = alloca ptr
  %l123 = alloca i1
  %l131 = alloca %"compiler/check:litv"
  %l132 = alloca ptr
  %l133 = alloca i1
  %l143 = alloca %"compiler/check:litv"
  %l146 = alloca %"compiler/check:litv"
  %l152 = alloca %"compiler/check:litv"
  %l154 = alloca { i1, i64 }
  %l159 = alloca %"compiler/check:litv"
  %l163 = alloca %"compiler/check:litv"
  %l164 = alloca %"compiler/check:litv"
  %l167 = alloca i1
  %l170 = alloca i1
  %l175 = alloca %"compiler/check:litv"
  %l178 = alloca %"compiler/check:litv"
  %l179 = alloca ptr
  %l180 = alloca i1
  %l191 = alloca %"compiler/check:litv"
  %l194 = alloca %"compiler/check:litv"
  %l197 = alloca i1
  %l200 = alloca %"compiler/check:litv"
  %l202 = alloca i1
  %l205 = alloca i1
  %l207 = alloca %"compiler/check:litv"
  %l209 = alloca double
  %l214 = alloca double
  %l223 = alloca %"compiler/check:litv"
  %l229 = alloca %"compiler/check:litv"
  %l235 = alloca %"compiler/check:litv"
  %l241 = alloca %"compiler/check:litv"
  %l242 = alloca %"compiler/check:litv"
  %l244 = alloca { i1, i64 }
  %l248 = alloca { i1, i64 }
  %l257 = alloca %"compiler/check:litv"
  %l265 = alloca %"compiler/check:litv"
  %l270 = alloca i1
  %l275 = alloca %"compiler/check:litv"
  %l282 = alloca i1
  %l286 = alloca %"compiler/check:litv"
  %l289 = alloca i1
  %l292 = alloca i1
  %l297 = alloca i64
  %l303 = alloca i64
  %l311 = alloca %"compiler/check:litv"
  %l313 = alloca i1
  %l315 = alloca i1
  %l319 = alloca %"compiler/check:litv"
  %l321 = alloca i1
  %l325 = alloca i1
  %l327 = alloca %"compiler/check:litv"
  %l332 = alloca i1
  %l335 = alloca i1
  %l339 = alloca i1
  %l346 = alloca %"compiler/check:litv"
  %l349 = alloca i1
  %l352 = alloca i1
  %l358 = alloca %"compiler/check:litv"
  %l361 = alloca i1
  %l364 = alloca i1
  %l367 = alloca i1
  %l372 = alloca i64
  %l376 = alloca i64
  %l380 = alloca %"compiler/check:litv"
  %l382 = alloca %"compiler/check:litv"
  %l385 = alloca i1
  %l388 = alloca i1
  %l392 = alloca i64
  %l394 = alloca %"compiler/check:litv"
  %l395 = alloca %"compiler/check:litv"
  %l396 = alloca %"compiler/check:litv"
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t5, ptr %l40
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load %"compiler/check:litv", ptr %l40
  store %"compiler/check:litv" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t8 = load ptr, ptr %l41, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l41, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 1
  store i1 %t14, ptr %l42, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l42, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l2
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l3
  br label %bb9
bb8:
  br label %bb66
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l2
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t28, %"compiler/source:Span" %t29)
  store { i64, ptr } %t32, ptr %l51
  br label %bb10
bb10:
  %t33 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load i32, ptr %l3
  %t36 = trunc i64 2 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp sgt i64 %t41, 2
  br i1 %t43, label %bb13, label %bb14
bb12:
  br label %bb54
bb13:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l58, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i8, ptr %t47, i64 0
  %t49 = load i8, ptr %t48, !tbaa !32
  %t51 = icmp eq i8 %t49, 48
  store i1 %t51, ptr %l57, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l57, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t54, ptr %l62, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 1
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = icmp eq i8 %t58, 120
  br i1 %t60, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb27
bb18:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb20
bb19:
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t62, ptr %l66, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 1
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp eq i8 %t66, 88
  store i1 %t68, ptr %l65, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l65, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb23
bb22:
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 1
  %t75 = load i8, ptr %t74, !tbaa !32
  %t77 = icmp eq i8 %t75, 98
  store i1 %t77, ptr %l69, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l69, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb26
bb25:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l74, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i8, ptr %t82, i64 1
  %t84 = load i8, ptr %t83, !tbaa !32
  %t86 = icmp eq i8 %t84, 66
  store i1 %t86, ptr %l73, !tbaa !21
  br label %bb26
bb26:
  %t88 = load i1, ptr %l73, !tbaa !21
  store i1 %t88, ptr %l61, !tbaa !21
  br label %bb27
bb27:
  %t89 = load i1, ptr %l61, !tbaa !21
  br i1 %t89, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t90, ptr %l78, !tbaa !27
  %t91 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 0)
  %t92 = extractvalue { i32, i64 } %t91, 1
  %t93 = extractvalue { i32, i64 } %t91, 0
  store i32 %t93, ptr %l80
  %t94 = icmp ne i32 %t93, 0
  br i1 %t94, label %bb31, label %ok.95
ok.95:
  store i64 %t92, ptr %l79
  br label %bb30
bb29:
  br label %bb38
bb30:
  %t96 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t97 = load i64, ptr %l79, !tbaa !24
  %t98 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t96, i64 %t97)
  %t99 = extractvalue { i32, i64 } %t98, 1
  %t100 = extractvalue { i32, i64 } %t98, 0
  store i32 %t100, ptr %l82
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb34, label %ok.102
ok.102:
  store i64 %t99, ptr %l81
  br label %bb33
bb31:
  br label %bb32
bb32:
  %t103 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t103, ptr %l83
  br label %bb35
bb33:
  %t104 = load i64, ptr %l81, !tbaa !65
  store i64 %t104, ptr %l77, !tbaa !65
  br label %bb36
bb34:
  br label %bb32
bb35:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  %t105 = load %"compiler/check:litv", ptr %l83
  store %"compiler/check:litv" %t105, ptr %rv
  br label %ret
bb36:
  %t106 = load i64, ptr %l77, !tbaa !65
  %t110 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t106)
  store %"compiler/check:litv" %t110, ptr %l86
  br label %bb37
bb37:
  %t111 = load %"compiler/check:litv", ptr %l86
  store %"compiler/check:litv" %t111, ptr %l6
  %t112 = getelementptr %"compiler/check:litv", ptr %l6, i32 0, i32 5
  store i1 true, ptr %t112, !tbaa !21
  %t113 = load %"compiler/check:litv", ptr %l6
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store %"compiler/check:litv" %t113, ptr %rv
  br label %ret
bb38:
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t115, ptr %l89, !tbaa !27
  %t116 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s3, i64 0)
  %t117 = extractvalue { i32, i64 } %t116, 1
  %t118 = extractvalue { i32, i64 } %t116, 0
  store i32 %t118, ptr %l91
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb40, label %ok.120
ok.120:
  store i64 %t117, ptr %l90
  br label %bb39
bb39:
  %t121 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t122 = load i64, ptr %l90, !tbaa !24
  %t123 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t121, i64 %t122)
  %t124 = extractvalue { i32, i64 } %t123, 1
  %t125 = extractvalue { i32, i64 } %t123, 0
  store i32 %t125, ptr %l93
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb43, label %ok.127
ok.127:
  store i64 %t124, ptr %l92
  br label %bb42
bb40:
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l95, !tbaa !27
  %t129 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 0)
  %t130 = extractvalue { i32, i64 } %t129, 1
  %t131 = extractvalue { i32, i64 } %t129, 0
  store i32 %t131, ptr %l97
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb45, label %ok.133
ok.133:
  store i64 %t130, ptr %l96
  br label %bb44
bb42:
  %t134 = load i64, ptr %l92, !tbaa !24
  store i64 %t134, ptr %l88, !tbaa !24
  br label %bb52
bb43:
  br label %bb41
bb44:
  %t135 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t136 = load i64, ptr %l96, !tbaa !24
  %t137 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t135, i64 %t136)
  %t138 = extractvalue { i32, i64 } %t137, 1
  %t139 = extractvalue { i32, i64 } %t137, 0
  store i32 %t139, ptr %l99
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb48, label %ok.141
ok.141:
  store i64 %t138, ptr %l98
  br label %bb47
bb45:
  br label %bb46
bb46:
  %t142 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t142, ptr %l100
  br label %bb49
bb47:
  %t143 = load i64, ptr %l98, !tbaa !65
  store i64 %t143, ptr %l94, !tbaa !65
  br label %bb50
bb48:
  br label %bb46
bb49:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  %t144 = load %"compiler/check:litv", ptr %l100
  store %"compiler/check:litv" %t144, ptr %rv
  br label %ret
bb50:
  %t145 = load i64, ptr %l94, !tbaa !65
  %t149 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s6, i1 true, i1 false, i1 true, i64 %t145, double 0x0000000000000000)
  store %"compiler/check:litv" %t149, ptr %l103
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  %t150 = load %"compiler/check:litv", ptr %l103
  store %"compiler/check:litv" %t150, ptr %rv
  br label %ret
bb52:
  %t151 = load i64, ptr %l88, !tbaa !24
  %t154 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t151)
  store %"compiler/check:litv" %t154, ptr %l105
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s3)
  %t155 = load %"compiler/check:litv", ptr %l105
  store %"compiler/check:litv" %t155, ptr %rv
  br label %ret
bb54:
  %t156 = load i32, ptr %l3
  %t158 = trunc i64 3 to i32
  %t159 = icmp eq i32 %t156, %t158
  br i1 %t159, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s8
  %t161 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 1, ptr @.d21 }, ptr %l110, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d22 }, ptr %l111, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t166 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t161, { i64, ptr } %t164, { i64, ptr } %t165)
  store { i64, ptr } %t166, ptr %l112
  br label %bb57
bb56:
  br label %bb64
bb57:
  %t167 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t171 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %s8, { i64, ptr } %t167)
  %t172 = extractvalue { i32, double } %t171, 1
  %t173 = extractvalue { i32, double } %t171, 0
  store i32 %t173, ptr %l117
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb59, label %ok.175
ok.175:
  store double %t172, ptr %l116
  br label %bb58
bb58:
  %t176 = load double, ptr %l116, !tbaa !26
  store double %t176, ptr %l114, !tbaa !26
  br label %bb62
bb59:
  br label %bb60
bb60:
  %t177 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t177, ptr %l118
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s8)
  %t178 = load %"compiler/check:litv", ptr %l118
  store %"compiler/check:litv" %t178, ptr %rv
  br label %ret
bb62:
  %t179 = load double, ptr %l114, !tbaa !26
  %t182 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t179)
  store %"compiler/check:litv" %t182, ptr %l120
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  %t183 = load %"compiler/check:litv", ptr %l120
  store %"compiler/check:litv" %t183, ptr %rv
  br label %ret
bb64:
  %t184 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t184, ptr %l121
  br label %bb65
bb65:
  %t185 = load %"compiler/check:litv", ptr %l121
  store %"compiler/check:litv" %t185, ptr %rv
  br label %ret
bb66:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t187 = load ptr, ptr %l122, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb67, label %bb68
bb67:
  %t190 = load ptr, ptr %l122, !tbaa !29
  %t191 = load i64, ptr %t190
  %t193 = icmp eq i64 %t191, 2
  store i1 %t193, ptr %l123, !tbaa !21
  br label %bb68
bb68:
  %t194 = load i1, ptr %l123, !tbaa !21
  br i1 %t194, label %bb69, label %bb70
bb69:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", ptr }, ptr %t197, i32 0, i32 1
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l11, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load ptr, ptr %l11, !tbaa !29
  %t206 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t201, ptr %t202)
  store %"compiler/check:litv" %t206, ptr %l131
  br label %bb72
bb72:
  %t207 = load %"compiler/check:litv", ptr %l131
  store %"compiler/check:litv" %t207, ptr %rv
  br label %ret
bb73:
  %t208 = load ptr, ptr %l1, !tbaa !29
  store ptr %t208, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t209 = load ptr, ptr %l132, !tbaa !29
  %t210 = icmp ne ptr %t209, null
  br i1 %t210, label %bb74, label %bb75
bb74:
  %t212 = load ptr, ptr %l132, !tbaa !29
  %t213 = load i64, ptr %t212
  %t215 = icmp eq i64 %t213, 3
  store i1 %t215, ptr %l133, !tbaa !21
  br label %bb75
bb75:
  %t216 = load i1, ptr %l133, !tbaa !21
  br i1 %t216, label %bb76, label %bb77
bb76:
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr { i64, [5 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t219, i32 0, i32 1
  %t221 = load i32, ptr %t220
  store i32 %t221, ptr %l12
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t225, i32 0, i32 2
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l13, !tbaa !29
  br label %bb78
bb77:
  br label %bb108
bb78:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l13, !tbaa !29
  %t234 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t229, ptr %t230)
  store %"compiler/check:litv" %t234, ptr %l143
  br label %bb79
bb79:
  %t235 = load %"compiler/check:litv", ptr %l143
  store %"compiler/check:litv" %t235, ptr %l14
  %t236 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 0
  %t237 = load i1, ptr %t236, !tbaa !21
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb80, label %bb81
bb80:
  %t241 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t241, ptr %l146
  br label %bb82
bb81:
  br label %bb83
bb82:
  %t242 = load %"compiler/check:litv", ptr %l146
  store %"compiler/check:litv" %t242, ptr %rv
  br label %ret
bb83:
  %t243 = load i32, ptr %l12
  %t245 = trunc i64 50 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb84, label %bb85
bb84:
  %t248 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 1
  %t249 = load i1, ptr %t248, !tbaa !21
  br i1 %t249, label %bb86, label %bb87
bb85:
  br label %bb96
bb86:
  %t251 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 4
  %t252 = load double, ptr %t251, !tbaa !26
  %t254 = fneg double %t252
  %t256 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t254)
  store %"compiler/check:litv" %t256, ptr %l152
  br label %bb88
bb87:
  br label %bb89
bb88:
  %t257 = load %"compiler/check:litv", ptr %l152
  store %"compiler/check:litv" %t257, ptr %rv
  br label %ret
bb89:
  %t258 = load %"compiler/check:litv", ptr %l14
  %t260 = call { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t258)
  store { i1, i64 } %t260, ptr %l154
  br label %bb90
bb90:
  %t261 = load { i1, i64 }, ptr %l154
  store { i1, i64 } %t261, ptr %l15
  %t262 = getelementptr { i1, i64 }, ptr %l15, i32 0, i32 0
  %t263 = load i1, ptr %t262, !tbaa !21
  store i1 %t263, ptr %l16, !tbaa !21
  %t265 = getelementptr { i1, i64 }, ptr %l15, i32 0, i32 1
  %t266 = load i64, ptr %t265, !tbaa !65
  store i64 %t266, ptr %l17, !tbaa !65
  %t268 = load i64, ptr %l17, !tbaa !65
  %t270 = icmp ne i64 %t268, 0
  br i1 %t270, label %bb91, label %bb92
bb91:
  %t272 = load i1, ptr %l16, !tbaa !21
  %t274 = xor i1 %t272, true
  %t275 = load i64, ptr %l17, !tbaa !65
  %t278 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t274, i64 %t275)
  store %"compiler/check:litv" %t278, ptr %l163
  br label %bb93
bb92:
  %t279 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 0)
  store %"compiler/check:litv" %t279, ptr %l164
  br label %bb94
bb93:
  %t280 = load %"compiler/check:litv", ptr %l163
  store %"compiler/check:litv" %t280, ptr %l159
  br label %bb95
bb94:
  %t281 = load %"compiler/check:litv", ptr %l164
  store %"compiler/check:litv" %t281, ptr %l159
  br label %bb95
bb95:
  %t282 = load %"compiler/check:litv", ptr %l159
  store %"compiler/check:litv" %t282, ptr %rv
  br label %ret
bb96:
  %t283 = load i32, ptr %l12
  %t285 = trunc i64 84 to i32
  %t286 = icmp eq i32 %t283, %t285
  br i1 %t286, label %bb97, label %bb98
bb97:
  %t288 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 1
  %t289 = load i1, ptr %t288, !tbaa !21
  %t291 = xor i1 %t289, true
  store i1 %t291, ptr %l167, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb99
bb99:
  %t293 = load i1, ptr %l167, !tbaa !21
  br i1 %t293, label %bb100, label %bb101
bb100:
  %t294 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 2
  %t295 = load i1, ptr %t294, !tbaa !21
  %t297 = xor i1 %t295, true
  store i1 %t297, ptr %l170, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb102
bb102:
  %t299 = load i1, ptr %l170, !tbaa !21
  br i1 %t299, label %bb103, label %bb104
bb103:
  %t300 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 3
  %t301 = load i64, ptr %t300, !tbaa !24
  %t303 = xor i64 %t301, -1
  %t305 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t303)
  store %"compiler/check:litv" %t305, ptr %l175
  br label %bb105
bb104:
  br label %bb106
bb105:
  %t306 = load %"compiler/check:litv", ptr %l175
  store %"compiler/check:litv" %t306, ptr %l18
  %t307 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 5
  %t308 = load i1, ptr %t307, !tbaa !21
  %t310 = getelementptr %"compiler/check:litv", ptr %l18, i32 0, i32 5
  store i1 %t308, ptr %t310, !tbaa !21
  %t311 = load %"compiler/check:litv", ptr %l18
  store %"compiler/check:litv" %t311, ptr %rv
  br label %ret
bb106:
  %t313 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t313, ptr %l178
  br label %bb107
bb107:
  %t314 = load %"compiler/check:litv", ptr %l178
  store %"compiler/check:litv" %t314, ptr %rv
  br label %ret
bb108:
  %t315 = load ptr, ptr %l1, !tbaa !29
  store ptr %t315, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t316 = load ptr, ptr %l179, !tbaa !29
  %t317 = icmp ne ptr %t316, null
  br i1 %t317, label %bb109, label %bb110
bb109:
  %t319 = load ptr, ptr %l179, !tbaa !29
  %t320 = load i64, ptr %t319
  %t322 = icmp eq i64 %t320, 5
  store i1 %t322, ptr %l180, !tbaa !21
  br label %bb110
bb110:
  %t323 = load i1, ptr %l180, !tbaa !21
  br i1 %t323, label %bb111, label %bb112
bb111:
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr { i64, [5 x i64] }, ptr %t324, i32 0, i32 1
  %t327 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t326, i32 0, i32 1
  %t328 = load i32, ptr %t327
  store i32 %t328, ptr %l19
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr { i64, [5 x i64] }, ptr %t330, i32 0, i32 1
  %t333 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t332, i32 0, i32 2
  %t334 = load ptr, ptr %t333
  store ptr %t334, ptr %l20, !tbaa !29
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t338 = getelementptr { i64, [5 x i64] }, ptr %t336, i32 0, i32 1
  %t339 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t338, i32 0, i32 3
  %t340 = load ptr, ptr %t339
  store ptr %t340, ptr %l21, !tbaa !29
  br label %bb113
bb112:
  br label %bb270
bb113:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l20, !tbaa !29
  %t346 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t342, ptr %t343)
  store %"compiler/check:litv" %t346, ptr %l191
  br label %bb114
bb114:
  %t347 = load %"compiler/check:litv", ptr %l191
  store %"compiler/check:litv" %t347, ptr %l22
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l21, !tbaa !29
  %t352 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t348, ptr %t349)
  store %"compiler/check:litv" %t352, ptr %l194
  br label %bb115
bb115:
  %t353 = load %"compiler/check:litv", ptr %l194
  store %"compiler/check:litv" %t353, ptr %l23
  %t354 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 0
  %t355 = load i1, ptr %t354, !tbaa !21
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb116, label %bb117
bb116:
  store i1 true, ptr %l197, !tbaa !21
  br label %bb118
bb117:
  %t359 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 0
  %t360 = load i1, ptr %t359, !tbaa !21
  %t362 = xor i1 %t360, true
  store i1 %t362, ptr %l197, !tbaa !21
  br label %bb118
bb118:
  %t364 = load i1, ptr %l197, !tbaa !21
  br i1 %t364, label %bb119, label %bb120
bb119:
  %t365 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t365, ptr %l200
  br label %bb121
bb120:
  br label %bb122
bb121:
  %t366 = load %"compiler/check:litv", ptr %l200
  store %"compiler/check:litv" %t366, ptr %rv
  br label %ret
bb122:
  %t367 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 1
  %t368 = load i1, ptr %t367, !tbaa !21
  br i1 %t368, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb125
bb124:
  %t370 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 1
  %t371 = load i1, ptr %t370, !tbaa !21
  store i1 %t371, ptr %l202, !tbaa !21
  br label %bb125
bb125:
  %t373 = load i1, ptr %l202, !tbaa !21
  br i1 %t373, label %bb126, label %bb127
bb126:
  %t374 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t375 = load i1, ptr %t374, !tbaa !21
  br i1 %t375, label %bb128, label %bb129
bb127:
  br label %bb158
bb128:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb130
bb129:
  %t377 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t378 = load i1, ptr %t377, !tbaa !21
  store i1 %t378, ptr %l205, !tbaa !21
  br label %bb130
bb130:
  %t380 = load i1, ptr %l205, !tbaa !21
  br i1 %t380, label %bb131, label %bb132
bb131:
  %t381 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t381, ptr %l207
  br label %bb133
bb132:
  br label %bb134
bb133:
  %t382 = load %"compiler/check:litv", ptr %l207
  store %"compiler/check:litv" %t382, ptr %rv
  br label %ret
bb134:
  %t383 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 1
  %t384 = load i1, ptr %t383, !tbaa !21
  br i1 %t384, label %bb135, label %bb136
bb135:
  %t386 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 4
  %t387 = load double, ptr %t386, !tbaa !26
  store double %t387, ptr %l209, !tbaa !26
  br label %bb137
bb136:
  %t389 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t390 = load i64, ptr %t389, !tbaa !24
  %t392 = sitofp i64 %t390 to double
  store double %t392, ptr %l209, !tbaa !26
  br label %bb137
bb137:
  %t394 = load double, ptr %l209, !tbaa !26
  store double %t394, ptr %l24, !tbaa !26
  %t395 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 1
  %t396 = load i1, ptr %t395, !tbaa !21
  br i1 %t396, label %bb138, label %bb139
bb138:
  %t398 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 4
  %t399 = load double, ptr %t398, !tbaa !26
  store double %t399, ptr %l214, !tbaa !26
  br label %bb140
bb139:
  %t401 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t402 = load i64, ptr %t401, !tbaa !24
  %t404 = sitofp i64 %t402 to double
  store double %t404, ptr %l214, !tbaa !26
  br label %bb140
bb140:
  %t406 = load double, ptr %l214, !tbaa !26
  store double %t406, ptr %l25, !tbaa !26
  %t407 = load i32, ptr %l19
  %t409 = trunc i64 49 to i32
  %t410 = icmp eq i32 %t407, %t409
  br i1 %t410, label %bb141, label %bb142
bb141:
  %t412 = load double, ptr %l24, !tbaa !26
  %t413 = load double, ptr %l25, !tbaa !26
  %t416 = fadd double %t412, %t413
  %t418 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t416)
  store %"compiler/check:litv" %t418, ptr %l223
  br label %bb143
bb142:
  br label %bb144
bb143:
  %t419 = load %"compiler/check:litv", ptr %l223
  store %"compiler/check:litv" %t419, ptr %rv
  br label %ret
bb144:
  %t420 = load i32, ptr %l19
  %t422 = trunc i64 50 to i32
  %t423 = icmp eq i32 %t420, %t422
  br i1 %t423, label %bb145, label %bb146
bb145:
  %t425 = load double, ptr %l24, !tbaa !26
  %t426 = load double, ptr %l25, !tbaa !26
  %t429 = fsub double %t425, %t426
  %t431 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t429)
  store %"compiler/check:litv" %t431, ptr %l229
  br label %bb147
bb146:
  br label %bb148
bb147:
  %t432 = load %"compiler/check:litv", ptr %l229
  store %"compiler/check:litv" %t432, ptr %rv
  br label %ret
bb148:
  %t433 = load i32, ptr %l19
  %t435 = trunc i64 51 to i32
  %t436 = icmp eq i32 %t433, %t435
  br i1 %t436, label %bb149, label %bb150
bb149:
  %t438 = load double, ptr %l24, !tbaa !26
  %t439 = load double, ptr %l25, !tbaa !26
  %t442 = fmul double %t438, %t439
  %t444 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t442)
  store %"compiler/check:litv" %t444, ptr %l235
  br label %bb151
bb150:
  br label %bb152
bb151:
  %t445 = load %"compiler/check:litv", ptr %l235
  store %"compiler/check:litv" %t445, ptr %rv
  br label %ret
bb152:
  %t446 = load i32, ptr %l19
  %t448 = trunc i64 52 to i32
  %t449 = icmp eq i32 %t446, %t448
  br i1 %t449, label %bb153, label %bb154
bb153:
  %t451 = load double, ptr %l24, !tbaa !26
  %t452 = load double, ptr %l25, !tbaa !26
  %t455 = fdiv double %t451, %t452
  %t457 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t455)
  store %"compiler/check:litv" %t457, ptr %l241
  br label %bb155
bb154:
  br label %bb156
bb155:
  %t458 = load %"compiler/check:litv", ptr %l241
  store %"compiler/check:litv" %t458, ptr %rv
  br label %ret
bb156:
  %t459 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t459, ptr %l242
  br label %bb157
bb157:
  %t460 = load %"compiler/check:litv", ptr %l242
  store %"compiler/check:litv" %t460, ptr %rv
  br label %ret
bb158:
  %t461 = load %"compiler/check:litv", ptr %l22
  %t463 = call { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t461)
  store { i1, i64 } %t463, ptr %l244
  br label %bb159
bb159:
  %t464 = load { i1, i64 }, ptr %l244
  store { i1, i64 } %t464, ptr %l26
  %t465 = getelementptr { i1, i64 }, ptr %l26, i32 0, i32 0
  %t466 = load i1, ptr %t465, !tbaa !21
  store i1 %t466, ptr %l27, !tbaa !21
  %t468 = getelementptr { i1, i64 }, ptr %l26, i32 0, i32 1
  %t469 = load i64, ptr %t468, !tbaa !65
  store i64 %t469, ptr %l28, !tbaa !65
  %t471 = load %"compiler/check:litv", ptr %l23
  %t473 = call { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t471)
  store { i1, i64 } %t473, ptr %l248
  br label %bb160
bb160:
  %t474 = load { i1, i64 }, ptr %l248
  store { i1, i64 } %t474, ptr %l29
  %t475 = getelementptr { i1, i64 }, ptr %l29, i32 0, i32 0
  %t476 = load i1, ptr %t475, !tbaa !21
  store i1 %t476, ptr %l30, !tbaa !21
  %t478 = getelementptr { i1, i64 }, ptr %l29, i32 0, i32 1
  %t479 = load i64, ptr %t478, !tbaa !65
  store i64 %t479, ptr %l31, !tbaa !65
  %t481 = load i32, ptr %l19
  %t483 = trunc i64 49 to i32
  %t484 = icmp eq i32 %t481, %t483
  br i1 %t484, label %bb161, label %bb162
bb161:
  %t486 = load i1, ptr %l27, !tbaa !21
  %t487 = load i64, ptr %l28, !tbaa !65
  %t488 = load i1, ptr %l30, !tbaa !21
  %t489 = load i64, ptr %l31, !tbaa !65
  %t494 = call %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %t486, i64 %t487, i1 %t488, i64 %t489)
  store %"compiler/check:litv" %t494, ptr %l257
  br label %bb163
bb162:
  br label %bb164
bb163:
  %t495 = load %"compiler/check:litv", ptr %l257
  store %"compiler/check:litv" %t495, ptr %rv
  br label %ret
bb164:
  %t496 = load i32, ptr %l19
  %t498 = trunc i64 50 to i32
  %t499 = icmp eq i32 %t496, %t498
  br i1 %t499, label %bb165, label %bb166
bb165:
  %t501 = load i1, ptr %l27, !tbaa !21
  %t502 = load i64, ptr %l28, !tbaa !65
  %t503 = load i1, ptr %l30, !tbaa !21
  %t505 = xor i1 %t503, true
  %t506 = load i64, ptr %l31, !tbaa !65
  %t511 = call %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %t501, i64 %t502, i1 %t505, i64 %t506)
  store %"compiler/check:litv" %t511, ptr %l265
  br label %bb167
bb166:
  br label %bb168
bb167:
  %t512 = load %"compiler/check:litv", ptr %l265
  store %"compiler/check:litv" %t512, ptr %rv
  br label %ret
bb168:
  %t513 = load i32, ptr %l19
  %t515 = trunc i64 51 to i32
  %t516 = icmp eq i32 %t513, %t515
  br i1 %t516, label %bb169, label %bb170
bb169:
  %t518 = load i64, ptr %l28, !tbaa !65
  %t520 = icmp ne i64 %t518, 0
  br i1 %t520, label %bb171, label %bb172
bb170:
  br label %bb182
bb171:
  %t522 = load i64, ptr %l31, !tbaa !65
  %t523 = load i64, ptr %l28, !tbaa !65
  %t525 = udiv i64 -1, %t523
  %t528 = icmp ugt i64 %t522, %t525
  store i1 %t528, ptr %l270, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l270, !tbaa !21
  br label %bb173
bb173:
  %t530 = load i1, ptr %l270, !tbaa !21
  br i1 %t530, label %bb174, label %bb175
bb174:
  %t531 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t531, ptr %l275
  br label %bb176
bb175:
  br label %bb177
bb176:
  %t532 = load %"compiler/check:litv", ptr %l275
  store %"compiler/check:litv" %t532, ptr %rv
  br label %ret
bb177:
  %t533 = load i64, ptr %l28, !tbaa !65
  %t534 = load i64, ptr %l31, !tbaa !65
  %t537 = mul i64 %t533, %t534
  store i64 %t537, ptr %l32, !tbaa !65
  %t539 = load i1, ptr %l27, !tbaa !21
  %t540 = load i1, ptr %l30, !tbaa !21
  %t543 = icmp ne i1 %t539, %t540
  br i1 %t543, label %bb178, label %bb179
bb178:
  %t545 = load i64, ptr %l32, !tbaa !65
  %t547 = icmp ne i64 %t545, 0
  store i1 %t547, ptr %l282, !tbaa !21
  br label %bb180
bb179:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb180
bb180:
  %t549 = load i64, ptr %l32, !tbaa !65
  %t550 = load i1, ptr %l282, !tbaa !21
  %t552 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t550, i64 %t549)
  store %"compiler/check:litv" %t552, ptr %l286
  br label %bb181
bb181:
  %t553 = load %"compiler/check:litv", ptr %l286
  store %"compiler/check:litv" %t553, ptr %rv
  br label %ret
bb182:
  %t554 = load i32, ptr %l19
  %t556 = trunc i64 81 to i32
  %t557 = icmp eq i32 %t554, %t556
  br i1 %t557, label %bb183, label %bb184
bb183:
  store i1 true, ptr %l289, !tbaa !21
  br label %bb185
bb184:
  %t559 = load i32, ptr %l19
  %t561 = trunc i64 82 to i32
  %t562 = icmp eq i32 %t559, %t561
  store i1 %t562, ptr %l289, !tbaa !21
  br label %bb185
bb185:
  %t564 = load i1, ptr %l289, !tbaa !21
  br i1 %t564, label %bb186, label %bb187
bb186:
  store i1 true, ptr %l292, !tbaa !21
  br label %bb188
bb187:
  %t565 = load i32, ptr %l19
  %t567 = trunc i64 83 to i32
  %t568 = icmp eq i32 %t565, %t567
  store i1 %t568, ptr %l292, !tbaa !21
  br label %bb188
bb188:
  %t570 = load i1, ptr %l292, !tbaa !21
  br i1 %t570, label %bb189, label %bb190
bb189:
  %t571 = load i32, ptr %l19
  %t573 = trunc i64 81 to i32
  %t574 = icmp eq i32 %t571, %t573
  br i1 %t574, label %bb191, label %bb192
bb190:
  br label %bb211
bb191:
  %t576 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t577 = load i64, ptr %t576, !tbaa !24
  %t578 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t579 = load i64, ptr %t578, !tbaa !24
  %t582 = and i64 %t577, %t579
  store i64 %t582, ptr %l297, !tbaa !24
  br label %bb196
bb192:
  %t584 = load i32, ptr %l19
  %t586 = trunc i64 82 to i32
  %t587 = icmp eq i32 %t584, %t586
  br i1 %t587, label %bb193, label %bb194
bb193:
  %t589 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t590 = load i64, ptr %t589, !tbaa !24
  %t591 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t592 = load i64, ptr %t591, !tbaa !24
  %t595 = or i64 %t590, %t592
  store i64 %t595, ptr %l303, !tbaa !24
  br label %bb195
bb194:
  %t597 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t598 = load i64, ptr %t597, !tbaa !24
  %t599 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t600 = load i64, ptr %t599, !tbaa !24
  %t603 = xor i64 %t598, %t600
  store i64 %t603, ptr %l303, !tbaa !24
  br label %bb195
bb195:
  %t605 = load i64, ptr %l303, !tbaa !24
  store i64 %t605, ptr %l297, !tbaa !24
  br label %bb196
bb196:
  %t606 = load i64, ptr %l297, !tbaa !24
  store i64 %t606, ptr %l33, !tbaa !24
  %t607 = load i64, ptr %l33, !tbaa !24
  %t609 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t607)
  store %"compiler/check:litv" %t609, ptr %l311
  br label %bb197
bb197:
  %t610 = load %"compiler/check:litv", ptr %l311
  store %"compiler/check:litv" %t610, ptr %l34
  %t611 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t612 = load i1, ptr %t611, !tbaa !21
  br i1 %t612, label %bb198, label %bb199
bb198:
  store i1 true, ptr %l313, !tbaa !21
  br label %bb200
bb199:
  %t614 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t615 = load i1, ptr %t614, !tbaa !21
  store i1 %t615, ptr %l313, !tbaa !21
  br label %bb200
bb200:
  %t617 = load i1, ptr %l313, !tbaa !21
  br i1 %t617, label %bb201, label %bb202
bb201:
  %t618 = load i64, ptr %l33, !tbaa !24
  %t620 = icmp slt i64 %t618, 0
  store i1 %t620, ptr %l315, !tbaa !21
  br label %bb203
bb202:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb203
bb203:
  %t622 = load i1, ptr %l315, !tbaa !21
  br i1 %t622, label %bb204, label %bb205
bb204:
  store %olang.scope zeroinitializer, ptr %s29
  %t623 = load i64, ptr %l33, !tbaa !24
  %t625 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s29, i1 true, i1 false, i1 true, i64 %t623, double 0x0000000000000000)
  store %"compiler/check:litv" %t625, ptr %l319
  br label %bb206
bb205:
  br label %bb207
bb206:
  %t626 = load %"compiler/check:litv", ptr %l319
  store %"compiler/check:litv" %t626, ptr %l34
  call void @__olang_scope_close(ptr %s29)
  br label %bb207
bb207:
  %t627 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 5
  %t628 = load i1, ptr %t627, !tbaa !21
  br i1 %t628, label %bb208, label %bb209
bb208:
  store i1 true, ptr %l321, !tbaa !21
  br label %bb210
bb209:
  %t630 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 5
  %t631 = load i1, ptr %t630, !tbaa !21
  store i1 %t631, ptr %l321, !tbaa !21
  br label %bb210
bb210:
  %t633 = load i1, ptr %l321, !tbaa !21
  %t634 = getelementptr %"compiler/check:litv", ptr %l34, i32 0, i32 5
  store i1 %t633, ptr %t634, !tbaa !21
  %t635 = load %"compiler/check:litv", ptr %l34
  store %"compiler/check:litv" %t635, ptr %rv
  br label %ret
bb211:
  %t637 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t638 = load i1, ptr %t637, !tbaa !21
  br i1 %t638, label %bb212, label %bb213
bb212:
  store i1 true, ptr %l325, !tbaa !21
  br label %bb214
bb213:
  %t640 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t641 = load i1, ptr %t640, !tbaa !21
  store i1 %t641, ptr %l325, !tbaa !21
  br label %bb214
bb214:
  %t643 = load i1, ptr %l325, !tbaa !21
  br i1 %t643, label %bb215, label %bb216
bb215:
  %t644 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t644, ptr %l327
  br label %bb217
bb216:
  br label %bb218
bb217:
  %t645 = load %"compiler/check:litv", ptr %l327
  store %"compiler/check:litv" %t645, ptr %rv
  br label %ret
bb218:
  %t646 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t647 = load i64, ptr %t646, !tbaa !24
  store i64 %t647, ptr %l35, !tbaa !24
  %t649 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t650 = load i64, ptr %t649, !tbaa !24
  store i64 %t650, ptr %l36, !tbaa !24
  %t652 = load i32, ptr %l19
  %t654 = trunc i64 52 to i32
  %t655 = icmp eq i32 %t652, %t654
  br i1 %t655, label %bb219, label %bb220
bb219:
  %t657 = load i64, ptr %l36, !tbaa !24
  %t659 = icmp ne i64 %t657, 0
  store i1 %t659, ptr %l332, !tbaa !21
  br label %bb221
bb220:
  store i1 false, ptr %l332, !tbaa !21
  br label %bb221
bb221:
  %t661 = load i1, ptr %l332, !tbaa !21
  br i1 %t661, label %bb222, label %bb223
bb222:
  %t662 = load i64, ptr %l35, !tbaa !24
  %t663 = sub i64 -9223372036854775807, 1
  %t666 = icmp eq i64 %t662, %t663
  br i1 %t666, label %bb224, label %bb225
bb223:
  store i1 false, ptr %l335, !tbaa !21
  br label %bb227
bb224:
  %t668 = load i64, ptr %l36, !tbaa !24
  %t670 = icmp eq i64 %t668, -1
  store i1 %t670, ptr %l339, !tbaa !21
  br label %bb226
bb225:
  store i1 false, ptr %l339, !tbaa !21
  br label %bb226
bb226:
  %t672 = load i1, ptr %l339, !tbaa !21
  %t673 = xor i1 %t672, true
  store i1 %t673, ptr %l335, !tbaa !21
  br label %bb227
bb227:
  %t675 = load i1, ptr %l335, !tbaa !21
  br i1 %t675, label %bb228, label %bb229
bb228:
  %t676 = load i64, ptr %l35, !tbaa !24
  %t677 = load i64, ptr %l36, !tbaa !24
  %t680 = sdiv i64 %t676, %t677
  %t682 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t680)
  store %"compiler/check:litv" %t682, ptr %l346
  br label %bb230
bb229:
  br label %bb231
bb230:
  %t683 = load %"compiler/check:litv", ptr %l346
  store %"compiler/check:litv" %t683, ptr %rv
  br label %ret
bb231:
  %t684 = load i32, ptr %l19
  %t686 = trunc i64 53 to i32
  %t687 = icmp eq i32 %t684, %t686
  br i1 %t687, label %bb232, label %bb233
bb232:
  %t689 = load i64, ptr %l36, !tbaa !24
  %t691 = icmp ne i64 %t689, 0
  store i1 %t691, ptr %l349, !tbaa !21
  br label %bb234
bb233:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb234
bb234:
  %t693 = load i1, ptr %l349, !tbaa !21
  br i1 %t693, label %bb235, label %bb236
bb235:
  %t694 = load i64, ptr %l36, !tbaa !24
  %t696 = icmp ne i64 %t694, -1
  store i1 %t696, ptr %l352, !tbaa !21
  br label %bb237
bb236:
  store i1 false, ptr %l352, !tbaa !21
  br label %bb237
bb237:
  %t698 = load i1, ptr %l352, !tbaa !21
  br i1 %t698, label %bb238, label %bb239
bb238:
  %t699 = load i64, ptr %l35, !tbaa !24
  %t700 = load i64, ptr %l36, !tbaa !24
  %t703 = srem i64 %t699, %t700
  %t705 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t703)
  store %"compiler/check:litv" %t705, ptr %l358
  br label %bb240
bb239:
  br label %bb241
bb240:
  %t706 = load %"compiler/check:litv", ptr %l358
  store %"compiler/check:litv" %t706, ptr %rv
  br label %ret
bb241:
  %t707 = load i32, ptr %l19
  %t709 = trunc i64 86 to i32
  %t710 = icmp eq i32 %t707, %t709
  br i1 %t710, label %bb242, label %bb243
bb242:
  %t712 = load i1, ptr %l27, !tbaa !21
  %t714 = xor i1 %t712, true
  store i1 %t714, ptr %l361, !tbaa !21
  br label %bb244
bb243:
  store i1 false, ptr %l361, !tbaa !21
  br label %bb244
bb244:
  %t716 = load i1, ptr %l361, !tbaa !21
  br i1 %t716, label %bb245, label %bb246
bb245:
  %t717 = load i64, ptr %l36, !tbaa !24
  %t719 = icmp sge i64 %t717, 0
  store i1 %t719, ptr %l364, !tbaa !21
  br label %bb247
bb246:
  store i1 false, ptr %l364, !tbaa !21
  br label %bb247
bb247:
  %t721 = load i1, ptr %l364, !tbaa !21
  br i1 %t721, label %bb248, label %bb249
bb248:
  %t722 = load i64, ptr %l36, !tbaa !24
  %t724 = icmp slt i64 %t722, 64
  store i1 %t724, ptr %l367, !tbaa !21
  br label %bb250
bb249:
  store i1 false, ptr %l367, !tbaa !21
  br label %bb250
bb250:
  %t726 = load i1, ptr %l367, !tbaa !21
  br i1 %t726, label %bb251, label %bb252
bb251:
  %t727 = load i64, ptr %l28, !tbaa !65
  %t728 = load i64, ptr %l36, !tbaa !24
  store i64 %t728, ptr %l372, !tbaa !65
  %t731 = load i64, ptr %l372, !tbaa !65
  %t732 = load i64, ptr %l372, !tbaa !65
  %t733 = shl i64 %t727, %t732
  store i64 %t733, ptr %l37, !tbaa !65
  %t735 = load i64, ptr %l37, !tbaa !65
  %t736 = load i64, ptr %l36, !tbaa !24
  store i64 %t736, ptr %l376, !tbaa !65
  %t739 = load i64, ptr %l376, !tbaa !65
  %t740 = load i64, ptr %l376, !tbaa !65
  %t741 = lshr i64 %t735, %t740
  %t742 = load i64, ptr %l28, !tbaa !65
  %t745 = icmp ne i64 %t741, %t742
  br i1 %t745, label %bb253, label %bb254
bb252:
  br label %bb258
bb253:
  %t747 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t747, ptr %l380
  br label %bb255
bb254:
  br label %bb256
bb255:
  %t748 = load %"compiler/check:litv", ptr %l380
  store %"compiler/check:litv" %t748, ptr %rv
  br label %ret
bb256:
  %t749 = load i64, ptr %l37, !tbaa !65
  %t751 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 false, i64 %t749)
  store %"compiler/check:litv" %t751, ptr %l382
  br label %bb257
bb257:
  %t752 = load %"compiler/check:litv", ptr %l382
  store %"compiler/check:litv" %t752, ptr %rv
  br label %ret
bb258:
  %t753 = load i32, ptr %l19
  %t755 = trunc i64 87 to i32
  %t756 = icmp eq i32 %t753, %t755
  br i1 %t756, label %bb259, label %bb260
bb259:
  %t758 = load i64, ptr %l36, !tbaa !24
  %t760 = icmp sge i64 %t758, 0
  store i1 %t760, ptr %l385, !tbaa !21
  br label %bb261
bb260:
  store i1 false, ptr %l385, !tbaa !21
  br label %bb261
bb261:
  %t762 = load i1, ptr %l385, !tbaa !21
  br i1 %t762, label %bb262, label %bb263
bb262:
  %t763 = load i64, ptr %l36, !tbaa !24
  %t765 = icmp slt i64 %t763, 64
  store i1 %t765, ptr %l388, !tbaa !21
  br label %bb264
bb263:
  store i1 false, ptr %l388, !tbaa !21
  br label %bb264
bb264:
  %t767 = load i1, ptr %l388, !tbaa !21
  br i1 %t767, label %bb265, label %bb266
bb265:
  %t768 = load i64, ptr %l35, !tbaa !24
  %t769 = load i64, ptr %l36, !tbaa !24
  store i64 %t769, ptr %l392, !tbaa !24
  %t771 = load i64, ptr %l392, !tbaa !24
  %t772 = load i64, ptr %l392, !tbaa !24
  %t773 = ashr i64 %t768, %t772
  %t775 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t773)
  store %"compiler/check:litv" %t775, ptr %l394
  br label %bb267
bb266:
  br label %bb268
bb267:
  %t776 = load %"compiler/check:litv", ptr %l394
  store %"compiler/check:litv" %t776, ptr %rv
  br label %ret
bb268:
  %t777 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t777, ptr %l395
  br label %bb269
bb269:
  %t778 = load %"compiler/check:litv", ptr %l395
  store %"compiler/check:litv" %t778, ptr %rv
  br label %ret
bb270:
  %t779 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t779, ptr %l396
  br label %bb271
bb271:
  %t780 = load %"compiler/check:litv", ptr %l396
  store %"compiler/check:litv" %t780, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l41 = alloca i64
  %l44 = alloca i64
  %l63 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l77 = alloca { i64, [2 x i64] }
  %l82 = alloca i32
  %l85 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  %t133 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i32, ptr %l2, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t1, i64 %t4)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l16
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 22
  %t12 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t11, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t26, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i32, ptr %l2, !tbaa !23
  %t37 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t31, i64 %t32, i32 %t33)
  store ptr %t37, ptr %l30
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l30, !tbaa !29
  store ptr %t38, ptr %l5, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t39, ptr %l31
  br label %bb10
bb10:
  %t40 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t40, ptr %l6
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb11, label %bb12
bb11:
  store i64 0, ptr %l7, !tbaa !24
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t47, i32 0, i32 0
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp sgt i64 %t54, %t55
  br i1 %t58, label %bb13, label %bb14
bb12:
  br label %bb28
bb13:
  %t60 = load i64, ptr %l9, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb18
bb15:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = sub i64 %t72, 1
  %t75 = load i64, ptr %l9, !tbaa !24
  %t78 = sdiv i64 %t74, %t75
  store i64 %t78, ptr %l44, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb17
bb17:
  %t80 = load i64, ptr %l44, !tbaa !24
  store i64 %t80, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t81 = load i64, ptr %l41, !tbaa !24
  store i64 %t81, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb21:
  br label %bb22
bb22:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t91 = load i64, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l12, !tbaa !24
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/ast:VarDecl", ptr %t100, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l63, !tbaa !27
  %t104 = load i64, ptr %l12, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 %t104
  %t109 = load i32, ptr %t108, !tbaa !33
  %t110 = load i32, ptr %l2, !tbaa !23
  %t113 = icmp eq i32 %t109, %t110
  br i1 %t113, label %bb23, label %bb24
bb23:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = getelementptr %"compiler/ast:VarDecl", ptr %t115, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l69, !tbaa !27
  %t119 = load i64, ptr %l12, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr %"compiler/source:Span", ptr %t122, i64 %t119
  %t124 = load %"compiler/source:Span", ptr %t123
  store %"compiler/source:Span" %t124, ptr %l6
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l11, !tbaa !24
  br label %bb19
bb27:
  br label %bb28
bb28:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l74, !tbaa !29
  %t131 = load i64, ptr %l1, !tbaa !24
  %t132 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 0
  store i64 6, ptr %t134
  %t136 = insertvalue { i64, i32 } undef, i64 %t131, 0
  %t138 = insertvalue { i64, i32 } %t136, i32 %t132, 1
  %t139 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 1
  store { i64, i32 } %t138, ptr %t139
  %t140 = load { i64, [2 x i64] }, ptr %t133
  store { i64, [2 x i64] } %t140, ptr %l77
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t146, i32 0, i32 %t147, i32 0, i32 0, i64 0)
  store i32 %t150, ptr %l82
  br label %bb29
bb29:
  %t151 = load i64, ptr %l1, !tbaa !24
  %t152 = load %"compiler/source:Span", ptr %l6
  %t153 = load ptr, ptr %l74, !tbaa !29
  %t154 = load { i64, [2 x i64] }, ptr %l77
  %t155 = load i32, ptr %l82, !tbaa !23
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t153, { i64, [2 x i64] } %t154, i32 %t155, i64 %t151, %"compiler/source:Span" %t152)
  store i64 %t158, ptr %l85
  br label %bb30
bb30:
  %t159 = load i64, ptr %l85, !tbaa !24
  store i64 %t159, ptr %l4, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 22
  %t163 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t164 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t162, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t163, i64 %t164)
  br label %bb31
bb31:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %t168, i64 %t169)
  br label %bb32
bb32:
  %t172 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t172, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasResultScope(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t18)
  store ptr %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %t23, !tbaa !23
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s2, ptr %t25, i32 %t24)
  store { i64, ptr } %t27, ptr %l18
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = mul i64 %t29, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t48, ptr %l26, !tbaa !27
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i64, ptr %t52, i64 %t49
  %t54 = load i64, ptr %t53, !tbaa !34
  %t57 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t60 = icmp eq i64 %t54, %t57
  br i1 %t60, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t63 = load i64, ptr %l2, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l2, !tbaa !24
  br label %bb7
bb15:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholds(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l29 = alloca { i64, ptr }
  %rv = alloca ptr
  %t38 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyCall(ptr %v0, ptr %v1, ptr %v2, ptr %t1, %"compiler/source:Span" %t2, i64 %a2, i32 %t4, { i64, ptr } %a3, ptr %a4, ptr %a5)
  store ptr %t15, ptr %l15
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l15, !tbaa !29
  store ptr %t16, ptr %l6, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 31
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l18
  br label %bb2
bb2:
  %t22 = load i64, ptr %l18, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 31
  %t26 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t25, ptr %t26)
  br label %bb3
bb3:
  %t29 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t29, ptr %l22
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t30, ptr %l23, !tbaa !23
  store i32 32, ptr %l24
  store i32 2, ptr %l25
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 31
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t33, i64 %t34)
  store { i64, ptr } %t37, ptr %l29
  br label %bb4
bb4:
  store { i64, [5 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 0
  store i64 9, ptr %t39
  %t40 = load %"compiler/source:Span", ptr %l22
  %t41 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t40, 0
  %t42 = load i32, ptr %l23, !tbaa !23
  %t43 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t41, i32 %t42, 1
  %t44 = load i32, ptr %l24
  %t45 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t43, i32 %t44, 2
  %t46 = load i32, ptr %l25
  %t47 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t45, i32 %t46, 3
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t47, { i64, ptr } %t48, 4
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t49, ptr %t50
  %t51 = load { i64, [5 x i64] }, ptr %t38
  %t53 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t51, ptr %t53
  store ptr %t53, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0) #0 {
entry:
  %l4 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t6, { i64, ptr } { i64 3, ptr @.d23 })
  store i32 %t8, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l4, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/msgs:Msg"
  %l16 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/msgs:Msg"
  %l25 = alloca i64
  %l30 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/msgs:Msg"
  %l34 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i1
  %l44 = alloca i32
  %l46 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i1
  %l53 = alloca i32
  %l58 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i32, ptr %l7, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store %"compiler/source:Span" %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %s1)
  store %"compiler/msgs:Msg" %t18, ptr %l15
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l14
  %t21 = load %"compiler/msgs:Msg", ptr %l15
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t19, %"compiler/source:Span" %t20, %"compiler/msgs:Msg" %t21)
  store i64 %t22, ptr %l16
  br label %bb6
bb6:
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t23, ptr %rv
  br label %ret
bb7:
  %t25 = load i32, ptr %l4, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t29 = icmp eq i32 %t25, %t26
  br i1 %t29, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l23
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %s2)
  store %"compiler/msgs:Msg" %t35, ptr %l24
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l23
  %t38 = load %"compiler/msgs:Msg", ptr %l24
  %t39 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t36, %"compiler/source:Span" %t37, %"compiler/msgs:Msg" %t38)
  store i64 %t39, ptr %l25
  br label %bb12
bb12:
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t40, ptr %rv
  br label %ret
bb13:
  %t42 = load i32, ptr %l4, !tbaa !23
  %t43 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t46 = icmp eq i32 %t42, %t43
  br i1 %t46, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l30, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t49)
  store %"compiler/source:Span" %t51, ptr %l32
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t52 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotInferable(ptr %s3)
  store %"compiler/msgs:Msg" %t52, ptr %l33
  br label %bb17
bb17:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l32
  %t55 = load %"compiler/msgs:Msg", ptr %l33
  %t56 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t53, %"compiler/source:Span" %t54, %"compiler/msgs:Msg" %t55)
  store i64 %t56, ptr %l34
  br label %bb18
bb18:
  %t57 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  store i32 %t57, ptr %rv
  br label %ret
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l4, !tbaa !23
  %t63 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t63, ptr %l38
  br label %bb20
bb20:
  %t64 = load i1, ptr %l38, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l4, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l44
  br label %bb23
bb22:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb25
bb23:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t75)
  store i32 %t77, ptr %l46
  br label %bb24
bb24:
  %t78 = load i32, ptr %l44, !tbaa !23
  %t79 = load i32, ptr %l46, !tbaa !23
  %t80 = icmp eq i32 %t78, %t79
  store i1 %t80, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l39, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l2, !tbaa !29
  store ptr %t83, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t84 = load ptr, ptr %l48, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb28, label %bb29
bb27:
  br label %bb36
bb28:
  %t87 = load ptr, ptr %l48, !tbaa !29
  %t88 = load i64, ptr %t87
  %t90 = icmp eq i64 %t88, 1
  store i1 %t90, ptr %l49, !tbaa !21
  br label %bb29
bb29:
  %t91 = load i1, ptr %l49, !tbaa !21
  br i1 %t91, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t92)
  store i32 %t94, ptr %l53
  br label %bb33
bb33:
  %t95 = load i32, ptr %l53, !tbaa !23
  store i32 %t95, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t98 = xor i1 %a3, true
  br i1 %t98, label %bb37, label %bb38
bb37:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l4, !tbaa !23
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l58
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t105 = load i32, ptr %l58, !tbaa !23
  store i32 %t105, ptr %rv
  br label %ret
bb40:
  %t106 = load i32, ptr %l4, !tbaa !23
  store i32 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstContexts(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/generic:Origin"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca i64
  %l26 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l57 = alloca %"compiler/generic:Origin"
  %l60 = alloca ptr
  %l63 = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  %l70 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l95 = alloca ptr
  %l97 = alloca i64
  %l101 = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  %l105 = alloca ptr
  %l111 = alloca { i64, [3 x i64] }
  %l114 = alloca { i64, ptr }
  %l119 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  %t193 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l18
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l2
  store i64 %a1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 32, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t10 = icmp sgt i64 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t14 = icmp sgt i64 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = sub i64 %t16, %t17
  %t21 = load i64, ptr %l6, !tbaa !24
  %t24 = add i64 %t20, %t21
  %t26 = sub i64 %t24, 1
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = sdiv i64 %t26, %t27
  store i64 %t30, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l26, !tbaa !24
  store i64 %t32, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l23, !tbaa !24
  store i64 %t33, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i64, ptr %l8, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb10:
  br label %bb11
bb11:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = mul i64 %t43, %t44
  %t50 = add i64 %t42, %t47
  store i64 %t50, ptr %l9, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  store ptr %t57, ptr %l46, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l3, !tbaa !24
  %t65 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t61, i64 %t62)
  store i32 %t65, ptr %l50
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l46, !tbaa !29
  %t67 = load i32, ptr %l50, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t66, i32 %t67)
  store { i64, ptr } %t68, ptr %l51
  br label %bb13
bb13:
  %t69 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t72 = icmp eq i64 %t70, 0
  br i1 %t72, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb15:
  br label %bb16
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = load i64, ptr %l3, !tbaa !24
  %t81 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t77, i64 %t78)
  store %"compiler/generic:Origin" %t81, ptr %l57
  br label %bb17
bb17:
  %t82 = load %"compiler/generic:Origin", ptr %l57
  store %"compiler/generic:Origin" %t82, ptr %l10
  %t83 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 0
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb19:
  br label %bb20
bb20:
  store ptr %l2, ptr %l60, !tbaa !29
  %t88 = load %"compiler/generic:Origin", ptr %l10
  %t89 = load i64, ptr %l3, !tbaa !24
  %t92 = call %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_2ector(ptr %s2, %"compiler/generic:Origin" %t88, i64 %t89)
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t92, ptr %l63
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l60, !tbaa !29
  %t94 = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l63
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgene_Hab8c1f447f20692126e9ac95b8c4eed1(ptr %s0, ptr %t93, %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t94)
  br label %bb22
bb22:
  %t95 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 2
  %t96 = load i64, ptr %t95, !tbaa !24
  %t98 = icmp slt i64 %t96, 0
  br i1 %t98, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t100 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  store i64 %t101, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l8, !tbaa !24
  br label %bb8
bb27:
  store i64 0, ptr %l11, !tbaa !24
  %t108 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgene_H5c18f35d323c054291b84f82e2e04ce4(ptr %s0, ptr %l2)
  store i64 %t108, ptr %l70
  br label %bb28
bb28:
  %t109 = load i64, ptr %l70, !tbaa !24
  store i64 %t109, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t110 = load i64, ptr %l12, !tbaa !24
  %t111 = load i64, ptr %l11, !tbaa !24
  %t114 = icmp sgt i64 %t110, %t111
  br i1 %t114, label %bb29, label %bb30
bb29:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t118 = icmp sgt i64 %t116, 0
  br i1 %t118, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb34
bb31:
  %t120 = load i64, ptr %l12, !tbaa !24
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = sub i64 %t120, %t121
  %t125 = load i64, ptr %l13, !tbaa !24
  %t128 = add i64 %t124, %t125
  %t130 = sub i64 %t128, 1
  %t131 = load i64, ptr %l13, !tbaa !24
  %t134 = sdiv i64 %t130, %t131
  store i64 %t134, ptr %l77, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb33
bb33:
  %t136 = load i64, ptr %l77, !tbaa !24
  store i64 %t136, ptr %l74, !tbaa !24
  br label %bb34
bb34:
  %t137 = load i64, ptr %l74, !tbaa !24
  store i64 %t137, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t138 = load i64, ptr %l15, !tbaa !24
  %t139 = load i64, ptr %l14, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t146 = load i64, ptr %l11, !tbaa !24
  %t147 = load i64, ptr %l15, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t151 = mul i64 %t147, %t148
  %t154 = add i64 %t146, %t151
  store i64 %t154, ptr %l16, !tbaa !24
  store ptr %l2, ptr %l95, !tbaa !29
  %t157 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgene_H5c18f35d323c054291b84f82e2e04ce4(ptr %s0, ptr %l2)
  store i64 %t157, ptr %l97
  br label %bb39
bb39:
  %t158 = load i64, ptr %l97, !tbaa !24
  %t159 = sub i64 %t158, 1
  %t160 = load i64, ptr %l16, !tbaa !24
  %t163 = sub i64 %t159, %t160
  %t164 = load ptr, ptr %l95, !tbaa !29
  %t166 = call %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgene_Ha7edd413db41d676beea2becd98544e8(ptr %s0, ptr %t164, i64 %t163)
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t166, ptr %l101
  br label %bb40
bb40:
  %t167 = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l101
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t167, ptr %l17
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 0
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/load:Loader", ptr %t174, i32 0, i32 4
  %t177 = load ptr, ptr %t176, !tbaa !29
  store ptr %t177, ptr %l105, !tbaa !29
  %t178 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 0
  %t179 = getelementptr %"compiler/generic:Origin", ptr %t178, i32 0, i32 0
  %t180 = load i64, ptr %t179, !tbaa !24
  %t181 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 0
  %t182 = getelementptr %"compiler/generic:Origin", ptr %t181, i32 0, i32 1
  %t183 = getelementptr %"compiler/source:Span", ptr %t182, i32 0, i32 0
  %t184 = load i32, ptr %t183, !tbaa !23
  %t186 = sext i32 %t184 to i64
  %t187 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 0
  %t188 = getelementptr %"compiler/generic:Origin", ptr %t187, i32 0, i32 1
  %t189 = getelementptr %"compiler/source:Span", ptr %t188, i32 0, i32 1
  %t190 = load i32, ptr %t189, !tbaa !23
  %t192 = sext i32 %t190 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 0
  store i64 3, ptr %t194
  %t196 = insertvalue { i64, i64, i64 } undef, i64 %t180, 0
  %t198 = insertvalue { i64, i64, i64 } %t196, i64 %t186, 1
  %t200 = insertvalue { i64, i64, i64 } %t198, i64 %t192, 2
  %t201 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 1
  store { i64, i64, i64 } %t200, ptr %t201
  %t202 = load { i64, [3 x i64] }, ptr %t193
  store { i64, [3 x i64] } %t202, ptr %l111
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 1
  %t205 = load i64, ptr %t204, !tbaa !24
  %t208 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %s8, ptr %t203, i64 %t205)
  store { i64, ptr } %t208, ptr %l114
  br label %bb41
bb41:
  %t209 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  %t211 = extractvalue { i64, ptr } %t209, 1
  %t212 = mul i64 %t210, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  %t216 = load ptr, ptr %l105, !tbaa !29
  %t217 = load { i64, [3 x i64] }, ptr %l111
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %s8, ptr %t216, { i64, [3 x i64] } %t217, { i64, ptr } %t215)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb43:
  %t219 = load i64, ptr %l15, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l15, !tbaa !24
  br label %bb35
bb44:
  %t224 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgene_H5c18f35d323c054291b84f82e2e04ce4(ptr %s0, ptr %l2)
  store i64 %t224, ptr %l119
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t225 = load i64, ptr %l119, !tbaa !24
  store i64 %t225, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca i64
  %l17 = alloca i64
  %l20 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l62 = alloca %"compiler/generic:varRow"
  %l64 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 17, ptr @.d24 })
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t7, i64 %t8)
  store i64 %t11, ptr %l16
  br label %bb3
bb3:
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t12)
  store i64 %t13, ptr %l17
  br label %bb4
bb4:
  %t14 = load i64, ptr %l17, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  store ptr %t20, ptr %l20, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t24, i64 %t25)
  store i32 %t28, ptr %l24
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = load i32, ptr %l24, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t31, ptr %l25
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t32, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb9:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l34, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l34, !tbaa !24
  store i64 %t63, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l31, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l10, !tbaa !24
  store ptr %l2, ptr %l52, !tbaa !29
  %t83 = load i64, ptr %l10, !tbaa !24
  %t85 = icmp eq i64 %t83, 0
  br i1 %t85, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 7, ptr @.d25 }, ptr %l55, !tbaa !27
  br label %bb19
bb18:
  store { i64, ptr } { i64 2, ptr @.d26 }, ptr %l55, !tbaa !27
  br label %bb19
bb19:
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = load { i64, ptr }, ptr %l55, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t87, { i64, ptr } %t88)
  br label %bb20
bb20:
  store ptr %l2, ptr %l56, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l57, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load i64, ptr %l3, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t99 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t93, i64 %t94, i64 %t95)
  store %"compiler/generic:varRow" %t99, ptr %l62
  br label %bb21
bb21:
  %t100 = getelementptr %"compiler/generic:varRow", ptr %l62, i32 0, i32 1
  %t101 = load i32, ptr %t100, !tbaa !23
  %t102 = load ptr, ptr %l57, !tbaa !29
  %t104 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t102, i32 %t101)
  store { i64, ptr } %t104, ptr %l64
  br label %bb22
bb22:
  %t105 = load ptr, ptr %l56, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l64, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t105, { i64, ptr } %t106)
  br label %bb23
bb23:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } { i64 3, ptr @.d27 })
  br label %bb24
bb24:
  store ptr %l2, ptr %l66, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t109, ptr %l68, !tbaa !27
  %t110 = load i64, ptr %l10, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i32, ptr %t113, i64 %t110
  %t115 = load i32, ptr %t114, !tbaa !33
  %t118 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t108, i32 %t115)
  store { i64, ptr } %t118, ptr %l71
  br label %bb25
bb25:
  %t119 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t126 = load ptr, ptr %l66, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t126, { i64, ptr } %t125)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l9, !tbaa !24
  br label %bb13
bb28:
  %t133 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t133, ptr %l76
  br label %bb29
bb29:
  %t134 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t134, ptr %l77, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l78, !tbaa !24
  %t137 = load i64, ptr %l78, !tbaa !24
  %t138 = mul i64 %t137, 1
  %t139 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l79, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l78, !tbaa !24
  %t147 = mul i64 %t146, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t143, ptr %t145, i64 %t147, i1 false)
  %t148 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t148, ptr %l77, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t149 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t149, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i32, ptr %l8
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l15
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l11, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l12 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l36 = alloca i32
  %l40 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i32
  %l55 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca ptr
  %l78 = alloca ptr
  %l81 = alloca ptr
  %l86 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i32
  %l89 = alloca { i64, ptr }
  %l90 = alloca i1
  %l96 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %a1)
  store i32 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load i32, ptr %l12, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l15, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l20
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i32, ptr %l20, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l21
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp ne i64 %t32, 1
  br i1 %t34, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb7
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 0
  %t41 = load i32, ptr %t40, !tbaa !33
  %t44 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t36, i32 %t41)
  store i1 %t44, ptr %l29
  br label %bb6
bb6:
  %t45 = load i1, ptr %l29, !tbaa !21
  %t46 = xor i1 %t45, true
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb7
bb7:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l36
  br label %bb11
bb11:
  %t60 = load i32, ptr %l36, !tbaa !23
  store i32 %t60, ptr %l4, !tbaa !23
  %t61 = load i32, ptr %l4, !tbaa !23
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t65 = icmp eq i32 %t61, %t62
  br i1 %t65, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb14
bb13:
  %t67 = load i32, ptr %l4, !tbaa !23
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t71 = icmp eq i32 %t67, %t68
  store i1 %t71, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb18
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l4, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l49
  br label %bb17
bb17:
  %t84 = load i32, ptr %l49
  %t86 = trunc i64 22 to i32
  %t87 = icmp eq i32 %t84, %t86
  store i1 %t87, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l44, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  store ptr %t96, ptr %l55, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l2, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l60
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l55, !tbaa !29
  %t108 = load i32, ptr %l60, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t107, i32 %t108)
  store { i64, ptr } %t109, ptr %l61
  br label %bb23
bb23:
  %t110 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t110, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l7, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t115 = load i64, ptr %l6, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb26:
  br label %bb27
bb27:
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t123, ptr %l68, !tbaa !27
  %t124 = load i64, ptr %l6, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 %t124
  %t129 = load i32, ptr %t128, !tbaa !33
  store i32 %t129, ptr %l8, !tbaa !23
  %t131 = load i32, ptr %l8, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t135 = icmp ne i32 %t131, %t132
  br i1 %t135, label %bb28, label %bb29
bb28:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l75, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  store ptr %t143, ptr %l78, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/generic:Program", ptr %t147, i32 0, i32 2
  store ptr %t149, ptr %l81, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  %t156 = load i32, ptr %l8, !tbaa !23
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l86
  br label %bb30
bb29:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb35
bb30:
  %t160 = load ptr, ptr %l81, !tbaa !29
  %t161 = load i32, ptr %l86, !tbaa !23
  %t162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t160, i32 %t161)
  store i32 %t162, ptr %l87
  br label %bb31
bb31:
  %t163 = load ptr, ptr %l78, !tbaa !29
  %t164 = load i32, ptr %l87, !tbaa !23
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t165, ptr %l88
  br label %bb32
bb32:
  %t166 = load ptr, ptr %l75, !tbaa !29
  %t167 = load i32, ptr %l88, !tbaa !23
  %t168 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t166, i32 %t167)
  store { i64, ptr } %t168, ptr %l89
  br label %bb33
bb33:
  %t169 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t170 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t169, { i64, ptr } { i64 9, ptr @.d28 })
  store i1 %t170, ptr %l90
  br label %bb34
bb34:
  %t171 = load i1, ptr %l90, !tbaa !21
  store i1 %t171, ptr %l74, !tbaa !21
  br label %bb35
bb35:
  %t172 = load i1, ptr %l74, !tbaa !21
  br i1 %t172, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb39:
  %t174 = load i64, ptr %l6, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l6, !tbaa !24
  br label %bb24
bb40:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l2, !tbaa !23
  %t182 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t178, i32 %t179)
  store i1 %t182, ptr %l96
  br label %bb41
bb41:
  %t183 = load i1, ptr %l96, !tbaa !21
  store i1 %t183, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l3 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t6, i32 %a1)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l31 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t17, i32 %a2)
  store i32 %t21, ptr %l14
  br label %bb2
bb2:
  %t22 = load i32, ptr %l14, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  %t23 = load i32, ptr %l3, !tbaa !23
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = icmp eq i32 %t23, %t24
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l23
  br label %bb6
bb6:
  %t40 = load i32, ptr %l23
  %t42 = trunc i64 27 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l31
  br label %bb9
bb9:
  %t55 = load i32, ptr %l31
  %t57 = trunc i64 27 to i32
  %t58 = icmp eq i32 %t55, %t57
  store i1 %t58, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t60 = load i1, ptr %l26, !tbaa !21
  store i1 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l31 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l56 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l15
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t3, ptr %lp2
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t5 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/check:frame", ptr %t6, i32 0, i32 25
  store ptr %t8, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v1, ptr %t10, i64 %t11)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l22
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb4, label %ok.18
ok.18:
  store { i64, ptr } %t15, ptr %l21
  br label %bb3
bb3:
  %t19 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  br label %bb8
bb4:
  %t20 = load i32, ptr %l22, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_1010397456489e66_cacc16b72eedbd12)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb8:
  %t25 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t38 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t38, ptr %l31, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i32, ptr %t42, i64 %t39
  %t44 = load i32, ptr %t43, !tbaa !33
  %t46 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t46, i32 %t44)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l7, !tbaa !24
  br label %bb9
bb15:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t54, %t55
  store i64 %t58, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb2
bb17:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 26
  store ptr %t62, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  %t64 = load ptr, ptr %l9, !tbaa !29
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v1, ptr %t64, i64 %t65)
  %t69 = extractvalue { i32, { i64, ptr } } %t68, 1
  %t70 = extractvalue { i32, { i64, ptr } } %t68, 0
  store i32 %t70, ptr %l47
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb20, label %ok.72
ok.72:
  store { i64, ptr } %t69, ptr %l46
  br label %bb19
bb19:
  %t73 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t73, ptr %l43, !tbaa !27
  br label %bb24
bb20:
  %t74 = load i32, ptr %l47, !tbaa !23
  %t75 = ashr i32 %t74, 16
  %t77 = icmp eq i32 %t75, 1
  br i1 %t77, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_fb9d93c6082892c7_80b52fbeeb5e713)
  unreachable
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb24:
  %t79 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t79, ptr %l11, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  store i64 %t82, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t84 = load i64, ptr %l13, !tbaa !24
  %t85 = load i64, ptr %l12, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t92 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t92, ptr %l56, !tbaa !27
  %t93 = load i64, ptr %l13, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t93
  %t98 = load i32, ptr %t97, !tbaa !33
  %t100 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t100, i32 %t98)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t104 = load i64, ptr %l13, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l13, !tbaa !24
  br label %bb25
bb31:
  %t108 = load i64, ptr %l10, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = add i64 %t108, %t109
  store i64 %t112, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  br label %bb18
bb33:
  %t114 = load ptr, ptr %lp2
  %t115 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t114
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l30 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l7, !tbaa !23
  %t32 = load i32, ptr %l7, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l7, !tbaa !23
  %t41 = add i64 %a3, 1
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t36, i32 %t37, i32 %a2, i64 %t41)
  store i1 %t46, ptr %l30
  br label %bb8
bb7:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  %t47 = load i1, ptr %l30, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb2
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l27 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t15, ptr %l14
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb7:
  br label %bb8
bb8:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t29, ptr %l21, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i32, ptr %t33, i64 %t30
  %t35 = load i32, ptr %t34, !tbaa !33
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t37, i32 %t35, i64 %a2)
  store i1 %t43, ptr %l27
  br label %bb9
bb9:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb5
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca %"compiler/check:litv"
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/check:litv" %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = getelementptr %"compiler/check:litv", ptr %l8, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t15 = load ptr, ptr %l11, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 2
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i1 %t30, ptr %l19
  br label %bb10
bb10:
  %t31 = load i1, ptr %l19, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 8
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l3, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t49, i32 0, i32 3
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  store i1 %t57, ptr %l30
  br label %bb17
bb17:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t63 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t59, ptr %t60)
  store i1 %t63, ptr %l34
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb21
bb20:
  %t64 = load i1, ptr %l34, !tbaa !21
  store i1 %t64, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t65 = load i1, ptr %l31, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l7 = alloca %"compiler/typed:Local"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %a1)
  store %"compiler/typed:Local" %t10, ptr %l7
  br label %bb2
bb2:
  %t11 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchValueMismatch(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca %"compiler/msgs:Msg"
  %l30 = alloca i64
  %l33 = alloca i32
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l45 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l61 = alloca %"compiler/msgs:Msg"
  %l62 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l71 = alloca i32
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l80 = alloca %"compiler/msgs:Msg"
  %l81 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t6 = load i32, ptr %l8, !tbaa !23
  %t8 = icmp eq i32 %t6, %t5
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l16
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i1, ptr %l16, !tbaa !21
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t23, ptr %l18
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l19, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l22
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load i32, ptr %l22, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t30, i32 %t31)
  store { i64, ptr } %t32, ptr %l23
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l24, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %s1, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l27
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t52 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullToArray(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t52, { i64, ptr } %t51)
  store %"compiler/msgs:Msg" %t54, ptr %l29
  br label %bb11
bb11:
  %t55 = load ptr, ptr %l17, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l18
  %t57 = load %"compiler/msgs:Msg", ptr %l29
  %t58 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t55, %"compiler/source:Span" %t56, %"compiler/msgs:Msg" %t57)
  store i64 %t58, ptr %l30
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t62 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t59)
  store i32 %t62, ptr %l33
  br label %bb14
bb14:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t64 = load i32, ptr %l33, !tbaa !23
  %t66 = icmp eq i32 %t64, %t63
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t72, ptr %l39
  br label %bb17
bb16:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb18
bb17:
  %t73 = load i1, ptr %l39, !tbaa !21
  store i1 %t73, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  %t74 = load i1, ptr %l36, !tbaa !21
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  %t81 = load i32, ptr %l3, !tbaa !23
  %t84 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t80, i32 %t81)
  store i1 %t84, ptr %l45
  br label %bb21
bb20:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb22
bb21:
  %t85 = load i1, ptr %l45, !tbaa !21
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t88 = load i1, ptr %l40, !tbaa !21
  br i1 %t88, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l47, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t90, ptr %l48
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l3, !tbaa !23
  %t95 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t91, i32 %t92)
  store { i64, ptr } %t95, ptr %l51
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t96 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = extractvalue { i64, ptr } %t96, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l52, !tbaa !27
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l53, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l3, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l58
  br label %bb26
bb26:
  %t114 = load ptr, ptr %l53, !tbaa !29
  %t115 = load i32, ptr %l58, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t114, i32 %t115)
  store { i64, ptr } %t116, ptr %l59
  br label %bb27
bb27:
  %t117 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  %t119 = extractvalue { i64, ptr } %t117, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t124 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t126 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullToNonNull(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t124, { i64, ptr } %t123)
  store %"compiler/msgs:Msg" %t126, ptr %l61
  br label %bb28
bb28:
  %t127 = load ptr, ptr %l47, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l48
  %t129 = load %"compiler/msgs:Msg", ptr %l61
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t127, %"compiler/source:Span" %t128, %"compiler/msgs:Msg" %t129)
  store i64 %t130, ptr %l62
  br label %bb29
bb29:
  %t131 = load i64, ptr %l62, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %t132, i64 %t131)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l65, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t137, ptr %l66
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l67, !tbaa !29
  %t139 = load i32, ptr %l2, !tbaa !23
  %t140 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t143 = icmp ne i32 %t139, %t140
  br i1 %t143, label %bb32, label %bb33
bb32:
  %t145 = load i32, ptr %l2, !tbaa !23
  store i32 %t145, ptr %l71, !tbaa !23
  br label %bb34
bb33:
  %t147 = load i32, ptr %l3, !tbaa !23
  store i32 %t147, ptr %l71, !tbaa !23
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l67, !tbaa !29
  %t150 = load i32, ptr %l71, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t149, i32 %t150)
  store { i64, ptr } %t151, ptr %l74
  br label %bb35
bb35:
  %t152 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l75, !tbaa !27
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l4, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %s0, ptr %t159, ptr %t160)
  store { i64, ptr } %t163, ptr %l78
  br label %bb36
bb36:
  %t164 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  %t171 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t173 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueTypes(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t171, { i64, ptr } %t170)
  store %"compiler/msgs:Msg" %t173, ptr %l80
  br label %bb37
bb37:
  %t174 = load ptr, ptr %l65, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l66
  %t176 = load %"compiler/msgs:Msg", ptr %l80
  %t177 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t174, %"compiler/source:Span" %t175, %"compiler/msgs:Msg" %t176)
  store i64 %t177, ptr %l81
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedBranch(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca { i64, i64, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca i1
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l28 = alloca %"compiler/typed:Local"
  %l29 = alloca i32
  %l33 = alloca i1
  %l37 = alloca i1
  %l42 = alloca ptr
  %l54 = alloca i64
  %l59 = alloca { i64, i64, i64 }
  %l84 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t38 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:Branch", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp sgt i64 %t10, 0
  store i1 %t12, ptr %l15, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Branch", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l22, !tbaa !27
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t19)
  store ptr %t21, ptr %l24
  br label %bb6
bb5:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb13
bb6:
  %t22 = load ptr, ptr %l24, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 7
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t24, i64 %t25)
  store %"compiler/typed:Local" %t28, ptr %l28
  br label %bb7
bb7:
  %t29 = getelementptr %"compiler/typed:Local", ptr %l28, i32 0, i32 0
  %t30 = load i32, ptr %t29, !tbaa !23
  store i32 %t30, ptr %l29, !tbaa !23
  %t31 = icmp sge i64 1, 0
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = icmp sle i64 1, 2305843009213693951
  br i1 %t33, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_baa1666d9ed0001e_5936281468ac2d52)
  unreachable
bb10:
  %t35 = mul i64 1, 4
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  %t37 = load i32, ptr %l29, !tbaa !23
  store i64 0, ptr %t38
  br label %fill.39
fill.39:
  %t42 = load i64, ptr %t38
  %t43 = icmp slt i64 %t42, 1
  br i1 %t43, label %fillb.40, label %filld.41
fillb.40:
  %t44 = getelementptr i32, ptr %t36, i64 %t42
  store i32 %t37, ptr %t44
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %t38
  br label %fill.39
filld.41:
  %t46 = insertvalue { i64, ptr } undef, i64 1, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t36, 1
  %t48 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t50 = call i1 @compiler_2fcheck_2eassignsName(ptr %v1, ptr %s0, { i64, ptr } %t48, { i64, ptr } %t47)
  store i1 %t50, ptr %l33
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_baa1666d9ed0001e_5936281468ac2d52)
  unreachable
bb12:
  %t51 = load i1, ptr %l33, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t54 = load i1, ptr %l20, !tbaa !21
  store i1 %t54, ptr %l6, !tbaa !21
  %t55 = load i1, ptr %l6, !tbaa !21
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  store i1 %t61, ptr %l37, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t63 = load i1, ptr %l37, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  store ptr %t68, ptr %l42
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load ptr, ptr %l42, !tbaa !29
  store ptr %t69, ptr %rv
  br label %ret
bb20:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Branch", ptr %t70, i32 0, i32 2
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/load:Loader", ptr %t83, i32 0, i32 4
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr %"compiler/ast:Branch", ptr %t87, i32 0, i32 2
  %t90 = load i64, ptr %t89, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t86, i64 %t90)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 32
  %t97 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l54
  br label %bb25
bb25:
  %t98 = load i64, ptr %l54, !tbaa !24
  store i64 %t98, ptr %l7, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/ast:Branch", ptr %t100, i32 0, i32 0
  %t103 = load %"compiler/source:Span", ptr %t102
  %t107 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t99, i32 1, %"compiler/source:Span" %t103)
  store { i64, i64, i64 } %t107, ptr %l59
  br label %bb26
bb26:
  %t108 = load { i64, i64, i64 }, ptr %l59
  store { i64, i64, i64 } %t108, ptr %l8
  %t109 = getelementptr { i64, i64, i64 }, ptr %l8, i32 0, i32 0
  %t110 = load i64, ptr %t109, !tbaa !24
  store i64 %t110, ptr %l9, !tbaa !24
  %t112 = getelementptr { i64, i64, i64 }, ptr %l8, i32 0, i32 1
  %t113 = load i64, ptr %t112, !tbaa !24
  store i64 %t113, ptr %l10, !tbaa !24
  %t115 = getelementptr { i64, i64, i64 }, ptr %l8, i32 0, i32 2
  %t116 = load i64, ptr %t115, !tbaa !24
  store i64 %t116, ptr %l11, !tbaa !24
  %t118 = load i1, ptr %l6, !tbaa !21
  br i1 %t118, label %bb27, label %bb28
bb27:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr %"compiler/ast:Branch", ptr %t121, i32 0, i32 0
  %t124 = load %"compiler/source:Span", ptr %t123
  %t125 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrow(ptr %v0, ptr %t120, %"compiler/source:Span" %t124, i64 %t125, i64 %a3)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t131 = load ptr, ptr %l4, !tbaa !29
  %t133 = icmp eq ptr %t131, null
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb31, label %bb32
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l4, !tbaa !29
  %t140 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v2, ptr %t137, ptr %t138, i1 %a5, i64 %t140)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr %"compiler/ast:Branch", ptr %t146, i32 0, i32 1
  %t149 = load { i64, ptr }, ptr %t148, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t145, { i64, ptr } %t149)
  br label %bb35
bb35:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l9, !tbaa !24
  %t154 = load i64, ptr %l10, !tbaa !24
  %t155 = load i64, ptr %l11, !tbaa !24
  %t156 = load i64, ptr %l7, !tbaa !24
  %t162 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t152, i64 %t153, i64 %t154, i64 %t155, i64 %t156)
  store ptr %t162, ptr %l84
  br label %bb36
bb36:
  %t163 = load ptr, ptr %l84, !tbaa !29
  store ptr %t163, ptr %l12, !tbaa !29
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr %"compiler/ast:Branch", ptr %t164, i32 0, i32 2
  %t167 = load i64, ptr %t166, !tbaa !24
  %t169 = icmp sge i64 %t167, 0
  br i1 %t169, label %bb37, label %bb38
bb37:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 0
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/load:Loader", ptr %t177, i32 0, i32 4
  %t180 = load ptr, ptr %t179, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t180)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t182 = load ptr, ptr %l12, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t182, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotStmtSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t24, i32 0, i32 3
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t29)
  store %"compiler/source:Span" %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l21
  br label %bb7
bb7:
  %t35 = load i32, ptr %l2
  %t37 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s1, i32 %t35)
  store { i64, ptr } %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l19
  %t42 = load %"compiler/source:Span", ptr %l21
  %t44 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t40, %"compiler/source:Span" %t41, %"compiler/source:Span" %t42, i64 %t39)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t45 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t45, ptr %rv
  br label %ret
bb10:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 15
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l5
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t63, i32 0, i32 2
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l6, !tbaa !23
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t67 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t67, ptr %l34
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l6, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l37
  br label %bb16
bb16:
  %t73 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = load %"compiler/source:Span", ptr %l34
  %t77 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t75, i64 %t74)
  store %"compiler/source:Span" %t77, ptr %l39
  br label %bb17
bb17:
  %t78 = load %"compiler/source:Span", ptr %l39
  store %"compiler/source:Span" %t78, ptr %rv
  br label %ret
bb18:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t79)
  store %"compiler/source:Span" %t81, ptr %l41
  br label %bb19
bb19:
  %t82 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t82, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb9
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 84
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t19)
  store ptr %t21, ptr %l12
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i32, ptr %l2, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s1, i64 %t25, i64 %t28)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, ptr %l17
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l10, !tbaa !29
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33, i1 true)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/check:fixedInit"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca i1
  %l44 = alloca i64
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l54 = alloca %"compiler/names:Ref"
  %l59 = alloca i1
  %l61 = alloca ptr
  %l65 = alloca i1
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l74 = alloca %"compiler/names:Ref"
  %l81 = alloca i1
  %l85 = alloca i64
  %l88 = alloca i1
  %l90 = alloca ptr
  %l92 = alloca ptr
  %l96 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l97 = alloca i1
  %l99 = alloca %"compiler/check:fixedInit"
  %l101 = alloca ptr
  %l103 = alloca ptr
  %l107 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l108 = alloca %"compiler/check:fixedInit"
  %l109 = alloca i32
  %l121 = alloca i1
  %l122 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l159 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i1
  %l172 = alloca ptr
  %l173 = alloca i1
  %l182 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i1
  %l211 = alloca i1
  %l212 = alloca i1
  %l217 = alloca i1
  %l218 = alloca ptr
  %l219 = alloca i1
  %l232 = alloca i1
  %l233 = alloca i1
  %l238 = alloca i1
  %l239 = alloca i1
  %l244 = alloca i1
  %l245 = alloca ptr
  %l246 = alloca i1
  %l255 = alloca i1
  %l256 = alloca ptr
  %l257 = alloca i1
  %l267 = alloca i64
  %l269 = alloca i1
  %l274 = alloca i1
  %l275 = alloca i1
  %l279 = alloca i1
  %l280 = alloca ptr
  %l281 = alloca i1
  %l292 = alloca i1
  %l293 = alloca i1
  %l297 = alloca i1
  %l298 = alloca ptr
  %l299 = alloca i1
  %l310 = alloca i1
  %l311 = alloca i1
  %l315 = alloca i1
  %l316 = alloca ptr
  %l317 = alloca i1
  %l330 = alloca i1
  %l331 = alloca i1
  %l335 = alloca i1
  %l336 = alloca i1
  %l340 = alloca i1
  %l341 = alloca ptr
  %l342 = alloca i1
  %l347 = alloca ptr
  %l348 = alloca i1
  %l353 = alloca ptr
  %l354 = alloca i1
  %l359 = alloca ptr
  %l360 = alloca i1
  %l368 = alloca i1
  %l369 = alloca ptr
  %l370 = alloca i1
  %l381 = alloca i1
  %l382 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t7 = load ptr, ptr %l30, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l30, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l31, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l31, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32 }, ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb52
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l3
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesLocal(ptr %v0, ptr %t27, %"compiler/source:Span" %t28)
  store i1 %t31, ptr %l40
  br label %bb9
bb9:
  %t32 = load i1, ptr %l40, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l4, !tbaa !23
  %t39 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l44
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t40 = load i64, ptr %l44, !tbaa !24
  %t41 = icmp slt i64 %t40, 0
  call void @__olang_scope_close(ptr %s2)
  store i1 %t41, ptr %rv
  br label %ret
bb13:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l48, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t50)
  store ptr %t52, ptr %l50
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l50, !tbaa !29
  %t55 = getelementptr %"compiler/check:frame", ptr %t53, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  %t57 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  %t59 = load ptr, ptr %l48, !tbaa !29
  %t62 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t59, i64 %t56, i32 %t58)
  store %"compiler/names:Ref" %t62, ptr %l54
  br label %bb15
bb15:
  %t63 = getelementptr %"compiler/names:Ref", ptr %l54, i32 0, i32 0
  %t64 = load i32, ptr %t63
  %t66 = trunc i64 8 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb16, label %bb17
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 81
  %t72 = load i1, ptr %t71, !tbaa !21
  br i1 %t72, label %bb18, label %bb19
bb17:
  br label %bb23
bb18:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t74)
  store ptr %t76, ptr %l61
  br label %bb20
bb19:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb22
bb20:
  %t77 = load ptr, ptr %l61, !tbaa !29
  %t79 = getelementptr %"compiler/check:frame", ptr %t77, i32 0, i32 4
  %t80 = getelementptr %"compiler/generic:Context", ptr %t79, i32 0, i32 2
  %t81 = load i32, ptr %l4, !tbaa !23
  %t84 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t80, i32 %t81)
  store i1 %t84, ptr %l65
  br label %bb21
bb21:
  %t85 = load i1, ptr %l65, !tbaa !21
  store i1 %t85, ptr %l59, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  %t86 = load i1, ptr %l59, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb23:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  store ptr %t93, ptr %l68, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t94)
  store ptr %t96, ptr %l70
  br label %bb24
bb24:
  %t97 = load ptr, ptr %l70, !tbaa !29
  %t99 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 2
  %t100 = load i64, ptr %t99, !tbaa !24
  %t101 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t103 = load ptr, ptr %l68, !tbaa !29
  %t106 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t103, i64 %t100, i32 %t102)
  store %"compiler/names:Ref" %t106, ptr %l74
  br label %bb25
bb25:
  %t107 = getelementptr %"compiler/names:Ref", ptr %l74, i32 0, i32 0
  %t108 = load i32, ptr %t107
  %t110 = trunc i64 1 to i32
  %t111 = icmp eq i32 %t108, %t110
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t117 = load i32, ptr %l4, !tbaa !23
  %t120 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v2, ptr %t116, i32 %t117)
  store i1 %t120, ptr %l81
  br label %bb29
bb29:
  %t121 = load i1, ptr %l81, !tbaa !21
  br i1 %t121, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l4, !tbaa !23
  %t127 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t123, i32 %t124)
  store i64 %t127, ptr %l85
  br label %bb33
bb33:
  %t128 = load i64, ptr %l85, !tbaa !24
  store i64 %t128, ptr %l5, !tbaa !24
  %t129 = load i64, ptr %l5, !tbaa !24
  %t131 = icmp slt i64 %t129, 0
  br i1 %t131, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb39
bb35:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 84
  store ptr %t135, ptr %l90, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t136)
  store ptr %t138, ptr %l92
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l92, !tbaa !29
  %t141 = getelementptr %"compiler/check:frame", ptr %t139, i32 0, i32 0
  %t142 = load i64, ptr %t141, !tbaa !24
  %t143 = load i64, ptr %l5, !tbaa !24
  %t146 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t142, i64 %t143)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t146, ptr %l96
  br label %bb37
bb37:
  %t147 = load ptr, ptr %l90, !tbaa !29
  %t148 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l96
  %t149 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t147, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t148)
  store i1 %t149, ptr %l97
  br label %bb38
bb38:
  %t150 = load i1, ptr %l97, !tbaa !21
  store i1 %t150, ptr %l88, !tbaa !21
  br label %bb39
bb39:
  %t151 = load i1, ptr %l88, !tbaa !21
  br i1 %t151, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/check:Checker", ptr %t153, i32 0, i32 83
  store ptr %t155, ptr %l101, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t156)
  store ptr %t158, ptr %l103
  br label %bb43
bb43:
  %t159 = load ptr, ptr %l103, !tbaa !29
  %t161 = getelementptr %"compiler/check:frame", ptr %t159, i32 0, i32 0
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load i64, ptr %l5, !tbaa !24
  %t166 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t162, i64 %t163)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t166, ptr %l107
  br label %bb44
bb44:
  %t167 = load ptr, ptr %l101, !tbaa !29
  %t168 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l107
  %t169 = call { i32, %"compiler/check:fixedInit" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6f2dcaa3b3ff2363ea7964270c7a6b31(ptr %v0, ptr %v0, ptr %t167, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t168)
  %t170 = extractvalue { i32, %"compiler/check:fixedInit" } %t169, 1
  %t171 = extractvalue { i32, %"compiler/check:fixedInit" } %t169, 0
  store i32 %t171, ptr %l109
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb46, label %ok.173
ok.173:
  store %"compiler/check:fixedInit" %t170, ptr %l108
  br label %bb45
bb45:
  %t174 = load %"compiler/check:fixedInit", ptr %l108
  store %"compiler/check:fixedInit" %t174, ptr %l99
  br label %bb48
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb48:
  %t176 = load %"compiler/check:fixedInit", ptr %l99
  store %"compiler/check:fixedInit" %t176, ptr %l6
  %t177 = load ptr, ptr %l2, !tbaa !29
  %t178 = load i32, ptr %l4, !tbaa !23
  %t179 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v2, ptr %t177, i32 %t178, i64 %t179)
  br label %bb49
bb49:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 85
  %t186 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t185, i64 %t186)
  br label %bb50
bb50:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:fixedInit", ptr %l6, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = load ptr, ptr %l2, !tbaa !29
  %t197 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v0, ptr %v2, ptr %t189, ptr %t191, ptr %t193)
  store i1 %t197, ptr %l121
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s2)
  %t198 = load i1, ptr %l121, !tbaa !21
  store i1 %t198, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t199 = load ptr, ptr %l1, !tbaa !29
  store ptr %t199, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t200 = load ptr, ptr %l123, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb54, label %bb55
bb54:
  %t203 = load ptr, ptr %l123, !tbaa !29
  %t204 = load i64, ptr %t203
  %t206 = icmp eq i64 %t204, 1
  store i1 %t206, ptr %l124, !tbaa !21
  br label %bb55
bb55:
  %t207 = load i1, ptr %l124, !tbaa !21
  br i1 %t207, label %bb56, label %bb57
bb56:
  br label %bb62
bb57:
  %t208 = load ptr, ptr %l1, !tbaa !29
  store ptr %t208, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t209 = load ptr, ptr %l127, !tbaa !29
  %t210 = icmp ne ptr %t209, null
  br i1 %t210, label %bb58, label %bb59
bb58:
  %t212 = load ptr, ptr %l127, !tbaa !29
  %t213 = load i64, ptr %t212
  %t215 = icmp eq i64 %t213, 26
  store i1 %t215, ptr %l128, !tbaa !21
  br label %bb59
bb59:
  %t216 = load i1, ptr %l128, !tbaa !21
  br i1 %t216, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb220
bb63:
  %t217 = load ptr, ptr %l1, !tbaa !29
  store ptr %t217, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t218 = load ptr, ptr %l131, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb64, label %bb65
bb64:
  %t221 = load ptr, ptr %l131, !tbaa !29
  %t222 = load i64, ptr %t221
  %t224 = icmp eq i64 %t222, 2
  store i1 %t224, ptr %l132, !tbaa !21
  br label %bb65
bb65:
  %t225 = load i1, ptr %l132, !tbaa !21
  br i1 %t225, label %bb66, label %bb67
bb66:
  %t226 = load ptr, ptr %l1, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr }, ptr %t228, i32 0, i32 1
  %t230 = load ptr, ptr %t229
  store ptr %t230, ptr %l7, !tbaa !29
  br label %bb80
bb67:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t233 = load ptr, ptr %l137, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb68, label %bb69
bb68:
  %t236 = load ptr, ptr %l137, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 3
  store i1 %t239, ptr %l138, !tbaa !21
  br label %bb69
bb69:
  %t240 = load i1, ptr %l138, !tbaa !21
  br i1 %t240, label %bb70, label %bb71
bb70:
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 2
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l7, !tbaa !29
  br label %bb80
bb71:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t248 = load ptr, ptr %l143, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb72, label %bb73
bb72:
  %t251 = load ptr, ptr %l143, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 4
  store i1 %t254, ptr %l144, !tbaa !21
  br label %bb73
bb73:
  %t255 = load i1, ptr %l144, !tbaa !21
  br i1 %t255, label %bb74, label %bb75
bb74:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l7, !tbaa !29
  br label %bb80
bb75:
  %t262 = load ptr, ptr %l1, !tbaa !29
  store ptr %t262, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t263 = load ptr, ptr %l149, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb76, label %bb77
bb76:
  %t266 = load ptr, ptr %l149, !tbaa !29
  %t267 = load i64, ptr %t266
  %t269 = icmp eq i64 %t267, 15
  store i1 %t269, ptr %l150, !tbaa !21
  br label %bb77
bb77:
  %t270 = load i1, ptr %l150, !tbaa !21
  br i1 %t270, label %bb78, label %bb79
bb78:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr { i64, [5 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t273, i32 0, i32 1
  %t275 = load ptr, ptr %t274
  store ptr %t275, ptr %l7, !tbaa !29
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l7, !tbaa !29
  %t280 = load ptr, ptr %l2, !tbaa !29
  %t284 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t277, ptr %t278, ptr %t280)
  store i1 %t284, ptr %l159
  br label %bb81
bb81:
  %t285 = load i1, ptr %l159, !tbaa !21
  store i1 %t285, ptr %l122, !tbaa !21
  br label %bb220
bb82:
  %t286 = load ptr, ptr %l1, !tbaa !29
  store ptr %t286, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t287 = load ptr, ptr %l160, !tbaa !29
  %t288 = icmp ne ptr %t287, null
  br i1 %t288, label %bb83, label %bb84
bb83:
  %t290 = load ptr, ptr %l160, !tbaa !29
  %t291 = load i64, ptr %t290
  %t293 = icmp eq i64 %t291, 9
  store i1 %t293, ptr %l161, !tbaa !21
  br label %bb84
bb84:
  %t294 = load i1, ptr %l161, !tbaa !21
  br i1 %t294, label %bb85, label %bb86
bb85:
  %t295 = load ptr, ptr %l1, !tbaa !29
  %t297 = getelementptr { i64, [5 x i64] }, ptr %t295, i32 0, i32 1
  %t298 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t297, i32 0, i32 1
  %t299 = load ptr, ptr %t298
  store ptr %t299, ptr %l8, !tbaa !29
  br label %bb95
bb86:
  %t301 = load ptr, ptr %l1, !tbaa !29
  store ptr %t301, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t302 = load ptr, ptr %l166, !tbaa !29
  %t303 = icmp ne ptr %t302, null
  br i1 %t303, label %bb87, label %bb88
bb87:
  %t305 = load ptr, ptr %l166, !tbaa !29
  %t306 = load i64, ptr %t305
  %t308 = icmp eq i64 %t306, 11
  store i1 %t308, ptr %l167, !tbaa !21
  br label %bb88
bb88:
  %t309 = load i1, ptr %l167, !tbaa !21
  br i1 %t309, label %bb89, label %bb90
bb89:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr { i64, [5 x i64] }, ptr %t310, i32 0, i32 1
  %t313 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t312, i32 0, i32 1
  %t314 = load ptr, ptr %t313
  store ptr %t314, ptr %l8, !tbaa !29
  br label %bb95
bb90:
  %t316 = load ptr, ptr %l1, !tbaa !29
  store ptr %t316, ptr %l172, !tbaa !29
  store i1 false, ptr %l173, !tbaa !21
  %t317 = load ptr, ptr %l172, !tbaa !29
  %t318 = icmp ne ptr %t317, null
  br i1 %t318, label %bb91, label %bb92
bb91:
  %t320 = load ptr, ptr %l172, !tbaa !29
  %t321 = load i64, ptr %t320
  %t323 = icmp eq i64 %t321, 14
  store i1 %t323, ptr %l173, !tbaa !21
  br label %bb92
bb92:
  %t324 = load i1, ptr %l173, !tbaa !21
  br i1 %t324, label %bb93, label %bb94
bb93:
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr { i64, [5 x i64] }, ptr %t325, i32 0, i32 1
  %t328 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t327, i32 0, i32 1
  %t329 = load ptr, ptr %t328
  store ptr %t329, ptr %l8, !tbaa !29
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l8, !tbaa !29
  %t334 = load ptr, ptr %l2, !tbaa !29
  %t338 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t331, ptr %t332, ptr %t334)
  store i1 %t338, ptr %l182
  br label %bb96
bb96:
  %t339 = load i1, ptr %l182, !tbaa !21
  store i1 %t339, ptr %l122, !tbaa !21
  br label %bb220
bb97:
  %t340 = load ptr, ptr %l1, !tbaa !29
  store ptr %t340, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t341 = load ptr, ptr %l183, !tbaa !29
  %t342 = icmp ne ptr %t341, null
  br i1 %t342, label %bb98, label %bb99
bb98:
  %t344 = load ptr, ptr %l183, !tbaa !29
  %t345 = load i64, ptr %t344
  %t347 = icmp eq i64 %t345, 5
  store i1 %t347, ptr %l184, !tbaa !21
  br label %bb99
bb99:
  %t348 = load i1, ptr %l184, !tbaa !21
  br i1 %t348, label %bb100, label %bb101
bb100:
  %t349 = load ptr, ptr %l1, !tbaa !29
  %t351 = getelementptr { i64, [5 x i64] }, ptr %t349, i32 0, i32 1
  %t352 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t351, i32 0, i32 2
  %t353 = load ptr, ptr %t352
  store ptr %t353, ptr %l9, !tbaa !29
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr { i64, [5 x i64] }, ptr %t355, i32 0, i32 1
  %t358 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t357, i32 0, i32 3
  %t359 = load ptr, ptr %t358
  store ptr %t359, ptr %l10, !tbaa !29
  br label %bb110
bb101:
  %t361 = load ptr, ptr %l1, !tbaa !29
  store ptr %t361, ptr %l191, !tbaa !29
  store i1 false, ptr %l192, !tbaa !21
  %t362 = load ptr, ptr %l191, !tbaa !29
  %t363 = icmp ne ptr %t362, null
  br i1 %t363, label %bb102, label %bb103
bb102:
  %t365 = load ptr, ptr %l191, !tbaa !29
  %t366 = load i64, ptr %t365
  %t368 = icmp eq i64 %t366, 6
  store i1 %t368, ptr %l192, !tbaa !21
  br label %bb103
bb103:
  %t369 = load i1, ptr %l192, !tbaa !21
  br i1 %t369, label %bb104, label %bb105
bb104:
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t372 = getelementptr { i64, [5 x i64] }, ptr %t370, i32 0, i32 1
  %t373 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t372, i32 0, i32 1
  %t374 = load ptr, ptr %t373
  store ptr %t374, ptr %l9, !tbaa !29
  %t376 = load ptr, ptr %l1, !tbaa !29
  %t378 = getelementptr { i64, [5 x i64] }, ptr %t376, i32 0, i32 1
  %t379 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t378, i32 0, i32 2
  %t380 = load ptr, ptr %t379
  store ptr %t380, ptr %l10, !tbaa !29
  br label %bb110
bb105:
  %t382 = load ptr, ptr %l1, !tbaa !29
  store ptr %t382, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t383 = load ptr, ptr %l199, !tbaa !29
  %t384 = icmp ne ptr %t383, null
  br i1 %t384, label %bb106, label %bb107
bb106:
  %t386 = load ptr, ptr %l199, !tbaa !29
  %t387 = load i64, ptr %t386
  %t389 = icmp eq i64 %t387, 10
  store i1 %t389, ptr %l200, !tbaa !21
  br label %bb107
bb107:
  %t390 = load i1, ptr %l200, !tbaa !21
  br i1 %t390, label %bb108, label %bb109
bb108:
  %t391 = load ptr, ptr %l1, !tbaa !29
  %t393 = getelementptr { i64, [5 x i64] }, ptr %t391, i32 0, i32 1
  %t394 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t393, i32 0, i32 1
  %t395 = load ptr, ptr %t394
  store ptr %t395, ptr %l9, !tbaa !29
  %t397 = load ptr, ptr %l1, !tbaa !29
  %t399 = getelementptr { i64, [5 x i64] }, ptr %t397, i32 0, i32 1
  %t400 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t399, i32 0, i32 2
  %t401 = load ptr, ptr %t400
  store ptr %t401, ptr %l10, !tbaa !29
  br label %bb110
bb109:
  br label %bb116
bb110:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t404 = load ptr, ptr %l9, !tbaa !29
  %t406 = load ptr, ptr %l2, !tbaa !29
  %t410 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t403, ptr %t404, ptr %t406)
  store i1 %t410, ptr %l211
  br label %bb111
bb111:
  %t411 = load i1, ptr %l211, !tbaa !21
  br i1 %t411, label %bb112, label %bb113
bb112:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load ptr, ptr %l10, !tbaa !29
  %t415 = load ptr, ptr %l2, !tbaa !29
  %t419 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t412, ptr %t413, ptr %t415)
  store i1 %t419, ptr %l217
  br label %bb114
bb113:
  store i1 false, ptr %l212, !tbaa !21
  br label %bb115
bb114:
  %t420 = load i1, ptr %l217, !tbaa !21
  store i1 %t420, ptr %l212, !tbaa !21
  br label %bb115
bb115:
  %t421 = load i1, ptr %l212, !tbaa !21
  store i1 %t421, ptr %l122, !tbaa !21
  br label %bb220
bb116:
  %t422 = load ptr, ptr %l1, !tbaa !29
  store ptr %t422, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t423 = load ptr, ptr %l218, !tbaa !29
  %t424 = icmp ne ptr %t423, null
  br i1 %t424, label %bb117, label %bb118
bb117:
  %t426 = load ptr, ptr %l218, !tbaa !29
  %t427 = load i64, ptr %t426
  %t429 = icmp eq i64 %t427, 8
  store i1 %t429, ptr %l219, !tbaa !21
  br label %bb118
bb118:
  %t430 = load i1, ptr %l219, !tbaa !21
  br i1 %t430, label %bb119, label %bb120
bb119:
  %t431 = load ptr, ptr %l1, !tbaa !29
  %t433 = getelementptr { i64, [5 x i64] }, ptr %t431, i32 0, i32 1
  %t434 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t433, i32 0, i32 1
  %t435 = load ptr, ptr %t434
  store ptr %t435, ptr %l11, !tbaa !29
  %t437 = load ptr, ptr %l1, !tbaa !29
  %t439 = getelementptr { i64, [5 x i64] }, ptr %t437, i32 0, i32 1
  %t440 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t439, i32 0, i32 2
  %t441 = load ptr, ptr %t440
  store ptr %t441, ptr %l12, !tbaa !29
  %t443 = load ptr, ptr %l1, !tbaa !29
  %t445 = getelementptr { i64, [5 x i64] }, ptr %t443, i32 0, i32 1
  %t446 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t445, i32 0, i32 3
  %t447 = load ptr, ptr %t446
  store ptr %t447, ptr %l13, !tbaa !29
  br label %bb121
bb120:
  br label %bb131
bb121:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t450 = load ptr, ptr %l11, !tbaa !29
  %t452 = load ptr, ptr %l2, !tbaa !29
  %t456 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t449, ptr %t450, ptr %t452)
  store i1 %t456, ptr %l232
  br label %bb122
bb122:
  %t457 = load i1, ptr %l232, !tbaa !21
  br i1 %t457, label %bb123, label %bb124
bb123:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t459 = load ptr, ptr %l12, !tbaa !29
  %t461 = load ptr, ptr %l2, !tbaa !29
  %t465 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t458, ptr %t459, ptr %t461)
  store i1 %t465, ptr %l238
  br label %bb125
bb124:
  store i1 false, ptr %l233, !tbaa !21
  br label %bb126
bb125:
  %t466 = load i1, ptr %l238, !tbaa !21
  store i1 %t466, ptr %l233, !tbaa !21
  br label %bb126
bb126:
  %t467 = load i1, ptr %l233, !tbaa !21
  br i1 %t467, label %bb127, label %bb128
bb127:
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t469 = load ptr, ptr %l13, !tbaa !29
  %t471 = load ptr, ptr %l2, !tbaa !29
  %t475 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t468, ptr %t469, ptr %t471)
  store i1 %t475, ptr %l244
  br label %bb129
bb128:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb130
bb129:
  %t476 = load i1, ptr %l244, !tbaa !21
  store i1 %t476, ptr %l239, !tbaa !21
  br label %bb130
bb130:
  %t477 = load i1, ptr %l239, !tbaa !21
  store i1 %t477, ptr %l122, !tbaa !21
  br label %bb220
bb131:
  %t478 = load ptr, ptr %l1, !tbaa !29
  store ptr %t478, ptr %l245, !tbaa !29
  store i1 false, ptr %l246, !tbaa !21
  %t479 = load ptr, ptr %l245, !tbaa !29
  %t480 = icmp ne ptr %t479, null
  br i1 %t480, label %bb132, label %bb133
bb132:
  %t482 = load ptr, ptr %l245, !tbaa !29
  %t483 = load i64, ptr %t482
  %t485 = icmp eq i64 %t483, 7
  store i1 %t485, ptr %l246, !tbaa !21
  br label %bb133
bb133:
  %t486 = load i1, ptr %l246, !tbaa !21
  br i1 %t486, label %bb134, label %bb135
bb134:
  %t487 = load ptr, ptr %l1, !tbaa !29
  %t489 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 1
  %t490 = getelementptr { %"compiler/source:Span", ptr }, ptr %t489, i32 0, i32 1
  %t491 = load ptr, ptr %t490
  store ptr %t491, ptr %l14, !tbaa !29
  br label %bb136
bb135:
  br label %bb138
bb136:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load ptr, ptr %l14, !tbaa !29
  %t496 = getelementptr %"compiler/ast:Chain", ptr %t494, i32 0, i32 1
  %t497 = load { i64, ptr }, ptr %t496, !tbaa !27
  %t498 = load ptr, ptr %l2, !tbaa !29
  %t502 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t493, { i64, ptr } %t497, ptr %t498)
  store i1 %t502, ptr %l255
  br label %bb137
bb137:
  %t503 = load i1, ptr %l255, !tbaa !21
  store i1 %t503, ptr %l122, !tbaa !21
  br label %bb220
bb138:
  %t504 = load ptr, ptr %l1, !tbaa !29
  store ptr %t504, ptr %l256, !tbaa !29
  store i1 false, ptr %l257, !tbaa !21
  %t505 = load ptr, ptr %l256, !tbaa !29
  %t506 = icmp ne ptr %t505, null
  br i1 %t506, label %bb139, label %bb140
bb139:
  %t508 = load ptr, ptr %l256, !tbaa !29
  %t509 = load i64, ptr %t508
  %t511 = icmp eq i64 %t509, 12
  store i1 %t511, ptr %l257, !tbaa !21
  br label %bb140
bb140:
  %t512 = load i1, ptr %l257, !tbaa !21
  br i1 %t512, label %bb141, label %bb142
bb141:
  %t513 = load ptr, ptr %l1, !tbaa !29
  %t515 = getelementptr { i64, [5 x i64] }, ptr %t513, i32 0, i32 1
  %t516 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t515, i32 0, i32 1
  %t517 = load ptr, ptr %t516
  store ptr %t517, ptr %l15, !tbaa !29
  %t519 = load ptr, ptr %l1, !tbaa !29
  %t521 = getelementptr { i64, [5 x i64] }, ptr %t519, i32 0, i32 1
  %t522 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t521, i32 0, i32 2
  %t523 = load { i64, ptr }, ptr %t522
  store { i64, ptr } %t523, ptr %l16, !tbaa !27
  br label %bb143
bb142:
  br label %bb153
bb143:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load ptr, ptr %l15, !tbaa !29
  %t527 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t531 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v1, ptr %t525, ptr %t526, { i64, ptr } %t527)
  store i64 %t531, ptr %l267
  br label %bb144
bb144:
  %t532 = load i64, ptr %l267, !tbaa !24
  %t533 = icmp sge i64 %t532, 0
  br i1 %t533, label %bb145, label %bb146
bb145:
  store i1 true, ptr %l269, !tbaa !21
  br label %bb152
bb146:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load ptr, ptr %l15, !tbaa !29
  %t538 = load ptr, ptr %l2, !tbaa !29
  %t542 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t535, ptr %t536, ptr %t538)
  store i1 %t542, ptr %l274
  br label %bb147
bb147:
  %t543 = load i1, ptr %l274, !tbaa !21
  br i1 %t543, label %bb148, label %bb149
bb148:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t545 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t546 = load ptr, ptr %l2, !tbaa !29
  %t550 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t544, { i64, ptr } %t545, ptr %t546)
  store i1 %t550, ptr %l279
  br label %bb150
bb149:
  store i1 false, ptr %l275, !tbaa !21
  br label %bb151
bb150:
  %t551 = load i1, ptr %l279, !tbaa !21
  store i1 %t551, ptr %l275, !tbaa !21
  br label %bb151
bb151:
  %t552 = load i1, ptr %l275, !tbaa !21
  store i1 %t552, ptr %l269, !tbaa !21
  br label %bb152
bb152:
  %t553 = load i1, ptr %l269, !tbaa !21
  store i1 %t553, ptr %l122, !tbaa !21
  br label %bb220
bb153:
  %t554 = load ptr, ptr %l1, !tbaa !29
  store ptr %t554, ptr %l280, !tbaa !29
  store i1 false, ptr %l281, !tbaa !21
  %t555 = load ptr, ptr %l280, !tbaa !29
  %t556 = icmp ne ptr %t555, null
  br i1 %t556, label %bb154, label %bb155
bb154:
  %t558 = load ptr, ptr %l280, !tbaa !29
  %t559 = load i64, ptr %t558
  %t561 = icmp eq i64 %t559, 13
  store i1 %t561, ptr %l281, !tbaa !21
  br label %bb155
bb155:
  %t562 = load i1, ptr %l281, !tbaa !21
  br i1 %t562, label %bb156, label %bb157
bb156:
  %t563 = load ptr, ptr %l1, !tbaa !29
  %t565 = getelementptr { i64, [5 x i64] }, ptr %t563, i32 0, i32 1
  %t566 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t565, i32 0, i32 1
  %t567 = load ptr, ptr %t566
  store ptr %t567, ptr %l17, !tbaa !29
  %t569 = load ptr, ptr %l1, !tbaa !29
  %t571 = getelementptr { i64, [5 x i64] }, ptr %t569, i32 0, i32 1
  %t572 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t571, i32 0, i32 3
  %t573 = load { i64, ptr }, ptr %t572
  store { i64, ptr } %t573, ptr %l18, !tbaa !27
  br label %bb158
bb157:
  br label %bb164
bb158:
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t576 = load ptr, ptr %l17, !tbaa !29
  %t578 = load ptr, ptr %l2, !tbaa !29
  %t582 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t575, ptr %t576, ptr %t578)
  store i1 %t582, ptr %l292
  br label %bb159
bb159:
  %t583 = load i1, ptr %l292, !tbaa !21
  br i1 %t583, label %bb160, label %bb161
bb160:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t586 = load ptr, ptr %l2, !tbaa !29
  %t590 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t584, { i64, ptr } %t585, ptr %t586)
  store i1 %t590, ptr %l297
  br label %bb162
bb161:
  store i1 false, ptr %l293, !tbaa !21
  br label %bb163
bb162:
  %t591 = load i1, ptr %l297, !tbaa !21
  store i1 %t591, ptr %l293, !tbaa !21
  br label %bb163
bb163:
  %t592 = load i1, ptr %l293, !tbaa !21
  store i1 %t592, ptr %l122, !tbaa !21
  br label %bb220
bb164:
  %t593 = load ptr, ptr %l1, !tbaa !29
  store ptr %t593, ptr %l298, !tbaa !29
  store i1 false, ptr %l299, !tbaa !21
  %t594 = load ptr, ptr %l298, !tbaa !29
  %t595 = icmp ne ptr %t594, null
  br i1 %t595, label %bb165, label %bb166
bb165:
  %t597 = load ptr, ptr %l298, !tbaa !29
  %t598 = load i64, ptr %t597
  %t600 = icmp eq i64 %t598, 16
  store i1 %t600, ptr %l299, !tbaa !21
  br label %bb166
bb166:
  %t601 = load i1, ptr %l299, !tbaa !21
  br i1 %t601, label %bb167, label %bb168
bb167:
  %t602 = load ptr, ptr %l1, !tbaa !29
  %t604 = getelementptr { i64, [5 x i64] }, ptr %t602, i32 0, i32 1
  %t605 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t604, i32 0, i32 1
  %t606 = load ptr, ptr %t605
  store ptr %t606, ptr %l19, !tbaa !29
  %t608 = load ptr, ptr %l1, !tbaa !29
  %t610 = getelementptr { i64, [5 x i64] }, ptr %t608, i32 0, i32 1
  %t611 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t610, i32 0, i32 2
  %t612 = load { i64, ptr }, ptr %t611
  store { i64, ptr } %t612, ptr %l20, !tbaa !27
  br label %bb169
bb168:
  br label %bb175
bb169:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load ptr, ptr %l19, !tbaa !29
  %t617 = load ptr, ptr %l2, !tbaa !29
  %t621 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t614, ptr %t615, ptr %t617)
  store i1 %t621, ptr %l310
  br label %bb170
bb170:
  %t622 = load i1, ptr %l310, !tbaa !21
  br i1 %t622, label %bb171, label %bb172
bb171:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t625 = load ptr, ptr %l2, !tbaa !29
  %t629 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t623, { i64, ptr } %t624, ptr %t625)
  store i1 %t629, ptr %l315
  br label %bb173
bb172:
  store i1 false, ptr %l311, !tbaa !21
  br label %bb174
bb173:
  %t630 = load i1, ptr %l315, !tbaa !21
  store i1 %t630, ptr %l311, !tbaa !21
  br label %bb174
bb174:
  %t631 = load i1, ptr %l311, !tbaa !21
  store i1 %t631, ptr %l122, !tbaa !21
  br label %bb220
bb175:
  %t632 = load ptr, ptr %l1, !tbaa !29
  store ptr %t632, ptr %l316, !tbaa !29
  store i1 false, ptr %l317, !tbaa !21
  %t633 = load ptr, ptr %l316, !tbaa !29
  %t634 = icmp ne ptr %t633, null
  br i1 %t634, label %bb176, label %bb177
bb176:
  %t636 = load ptr, ptr %l316, !tbaa !29
  %t637 = load i64, ptr %t636
  %t639 = icmp eq i64 %t637, 17
  store i1 %t639, ptr %l317, !tbaa !21
  br label %bb177
bb177:
  %t640 = load i1, ptr %l317, !tbaa !21
  br i1 %t640, label %bb178, label %bb179
bb178:
  %t641 = load ptr, ptr %l1, !tbaa !29
  %t643 = getelementptr { i64, [5 x i64] }, ptr %t641, i32 0, i32 1
  %t644 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t643, i32 0, i32 1
  %t645 = load ptr, ptr %t644
  store ptr %t645, ptr %l21, !tbaa !29
  %t647 = load ptr, ptr %l1, !tbaa !29
  %t649 = getelementptr { i64, [5 x i64] }, ptr %t647, i32 0, i32 1
  %t650 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t649, i32 0, i32 2
  %t651 = load ptr, ptr %t650
  store ptr %t651, ptr %l22, !tbaa !29
  %t653 = load ptr, ptr %l1, !tbaa !29
  %t655 = getelementptr { i64, [5 x i64] }, ptr %t653, i32 0, i32 1
  %t656 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t655, i32 0, i32 3
  %t657 = load ptr, ptr %t656
  store ptr %t657, ptr %l23, !tbaa !29
  br label %bb180
bb179:
  br label %bb190
bb180:
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t660 = load ptr, ptr %l21, !tbaa !29
  %t662 = load ptr, ptr %l2, !tbaa !29
  %t666 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t659, ptr %t660, ptr %t662)
  store i1 %t666, ptr %l330
  br label %bb181
bb181:
  %t667 = load i1, ptr %l330, !tbaa !21
  br i1 %t667, label %bb182, label %bb183
bb182:
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t669 = load ptr, ptr %l22, !tbaa !29
  %t670 = load ptr, ptr %l2, !tbaa !29
  %t674 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t668, ptr %t669, ptr %t670)
  store i1 %t674, ptr %l335
  br label %bb184
bb183:
  store i1 false, ptr %l331, !tbaa !21
  br label %bb185
bb184:
  %t675 = load i1, ptr %l335, !tbaa !21
  store i1 %t675, ptr %l331, !tbaa !21
  br label %bb185
bb185:
  %t676 = load i1, ptr %l331, !tbaa !21
  br i1 %t676, label %bb186, label %bb187
bb186:
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t678 = load ptr, ptr %l23, !tbaa !29
  %t679 = load ptr, ptr %l2, !tbaa !29
  %t683 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t677, ptr %t678, ptr %t679)
  store i1 %t683, ptr %l340
  br label %bb188
bb187:
  store i1 false, ptr %l336, !tbaa !21
  br label %bb189
bb188:
  %t684 = load i1, ptr %l340, !tbaa !21
  store i1 %t684, ptr %l336, !tbaa !21
  br label %bb189
bb189:
  %t685 = load i1, ptr %l336, !tbaa !21
  store i1 %t685, ptr %l122, !tbaa !21
  br label %bb220
bb190:
  %t686 = load ptr, ptr %l1, !tbaa !29
  store ptr %t686, ptr %l341, !tbaa !29
  store i1 false, ptr %l342, !tbaa !21
  %t687 = load ptr, ptr %l341, !tbaa !29
  %t688 = icmp ne ptr %t687, null
  br i1 %t688, label %bb191, label %bb192
bb191:
  %t690 = load ptr, ptr %l341, !tbaa !29
  %t691 = load i64, ptr %t690
  %t693 = icmp eq i64 %t691, 18
  store i1 %t693, ptr %l342, !tbaa !21
  br label %bb192
bb192:
  %t694 = load i1, ptr %l342, !tbaa !21
  br i1 %t694, label %bb193, label %bb194
bb193:
  %t695 = load ptr, ptr %l1, !tbaa !29
  %t697 = getelementptr { i64, [5 x i64] }, ptr %t695, i32 0, i32 1
  %t698 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t697, i32 0, i32 2
  %t699 = load { i64, ptr }, ptr %t698
  store { i64, ptr } %t699, ptr %l24, !tbaa !27
  br label %bb207
bb194:
  %t701 = load ptr, ptr %l1, !tbaa !29
  store ptr %t701, ptr %l347, !tbaa !29
  store i1 false, ptr %l348, !tbaa !21
  %t702 = load ptr, ptr %l347, !tbaa !29
  %t703 = icmp ne ptr %t702, null
  br i1 %t703, label %bb195, label %bb196
bb195:
  %t705 = load ptr, ptr %l347, !tbaa !29
  %t706 = load i64, ptr %t705
  %t708 = icmp eq i64 %t706, 19
  store i1 %t708, ptr %l348, !tbaa !21
  br label %bb196
bb196:
  %t709 = load i1, ptr %l348, !tbaa !21
  br i1 %t709, label %bb197, label %bb198
bb197:
  %t710 = load ptr, ptr %l1, !tbaa !29
  %t712 = getelementptr { i64, [5 x i64] }, ptr %t710, i32 0, i32 1
  %t713 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t712, i32 0, i32 1
  %t714 = load { i64, ptr }, ptr %t713
  store { i64, ptr } %t714, ptr %l24, !tbaa !27
  br label %bb207
bb198:
  %t716 = load ptr, ptr %l1, !tbaa !29
  store ptr %t716, ptr %l353, !tbaa !29
  store i1 false, ptr %l354, !tbaa !21
  %t717 = load ptr, ptr %l353, !tbaa !29
  %t718 = icmp ne ptr %t717, null
  br i1 %t718, label %bb199, label %bb200
bb199:
  %t720 = load ptr, ptr %l353, !tbaa !29
  %t721 = load i64, ptr %t720
  %t723 = icmp eq i64 %t721, 21
  store i1 %t723, ptr %l354, !tbaa !21
  br label %bb200
bb200:
  %t724 = load i1, ptr %l354, !tbaa !21
  br i1 %t724, label %bb201, label %bb202
bb201:
  %t725 = load ptr, ptr %l1, !tbaa !29
  %t727 = getelementptr { i64, [5 x i64] }, ptr %t725, i32 0, i32 1
  %t728 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t727, i32 0, i32 1
  %t729 = load { i64, ptr }, ptr %t728
  store { i64, ptr } %t729, ptr %l24, !tbaa !27
  br label %bb207
bb202:
  %t731 = load ptr, ptr %l1, !tbaa !29
  store ptr %t731, ptr %l359, !tbaa !29
  store i1 false, ptr %l360, !tbaa !21
  %t732 = load ptr, ptr %l359, !tbaa !29
  %t733 = icmp ne ptr %t732, null
  br i1 %t733, label %bb203, label %bb204
bb203:
  %t735 = load ptr, ptr %l359, !tbaa !29
  %t736 = load i64, ptr %t735
  %t738 = icmp eq i64 %t736, 25
  store i1 %t738, ptr %l360, !tbaa !21
  br label %bb204
bb204:
  %t739 = load i1, ptr %l360, !tbaa !21
  br i1 %t739, label %bb205, label %bb206
bb205:
  %t740 = load ptr, ptr %l1, !tbaa !29
  %t742 = getelementptr { i64, [5 x i64] }, ptr %t740, i32 0, i32 1
  %t743 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t742, i32 0, i32 1
  %t744 = load { i64, ptr }, ptr %t743
  store { i64, ptr } %t744, ptr %l24, !tbaa !27
  br label %bb207
bb206:
  br label %bb209
bb207:
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t747 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t748 = load ptr, ptr %l2, !tbaa !29
  %t752 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t746, { i64, ptr } %t747, ptr %t748)
  store i1 %t752, ptr %l368
  br label %bb208
bb208:
  %t753 = load i1, ptr %l368, !tbaa !21
  store i1 %t753, ptr %l122, !tbaa !21
  br label %bb220
bb209:
  %t754 = load ptr, ptr %l1, !tbaa !29
  store ptr %t754, ptr %l369, !tbaa !29
  store i1 false, ptr %l370, !tbaa !21
  %t755 = load ptr, ptr %l369, !tbaa !29
  %t756 = icmp ne ptr %t755, null
  br i1 %t756, label %bb210, label %bb211
bb210:
  %t758 = load ptr, ptr %l369, !tbaa !29
  %t759 = load i64, ptr %t758
  %t761 = icmp eq i64 %t759, 22
  store i1 %t761, ptr %l370, !tbaa !21
  br label %bb211
bb211:
  %t762 = load i1, ptr %l370, !tbaa !21
  br i1 %t762, label %bb212, label %bb213
bb212:
  %t763 = load ptr, ptr %l1, !tbaa !29
  %t765 = getelementptr { i64, [5 x i64] }, ptr %t763, i32 0, i32 1
  %t766 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t765, i32 0, i32 1
  %t767 = load ptr, ptr %t766
  store ptr %t767, ptr %l25, !tbaa !29
  %t769 = load ptr, ptr %l1, !tbaa !29
  %t771 = getelementptr { i64, [5 x i64] }, ptr %t769, i32 0, i32 1
  %t772 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t771, i32 0, i32 2
  %t773 = load { i64, ptr }, ptr %t772
  store { i64, ptr } %t773, ptr %l26, !tbaa !27
  br label %bb214
bb213:
  br label %bb219
bb214:
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t776 = load ptr, ptr %l25, !tbaa !29
  %t778 = load ptr, ptr %l2, !tbaa !29
  %t782 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %t775, ptr %t776, ptr %t778)
  store i1 %t782, ptr %l381
  br label %bb215
bb215:
  %t783 = load i1, ptr %l381, !tbaa !21
  br i1 %t783, label %bb216, label %bb217
bb216:
  %t784 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t786 = extractvalue { i64, ptr } %t784, 0
  %t788 = icmp eq i64 %t786, 0
  store i1 %t788, ptr %l382, !tbaa !21
  br label %bb218
bb217:
  store i1 false, ptr %l382, !tbaa !21
  br label %bb218
bb218:
  %t790 = load i1, ptr %l382, !tbaa !21
  store i1 %t790, ptr %l122, !tbaa !21
  br label %bb220
bb219:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb220
bb220:
  %t791 = load i1, ptr %l122, !tbaa !21
  store i1 %t791, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l52 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l11
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t19 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l14
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_cabdf486839d2fe5_195cd685fa5544d9)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t46 = icmp slt i64 %t40, %t43
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t48, ptr %l29, !tbaa !27
  %t49 = load i64, ptr %l5, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 %t49
  %t54 = load i8, ptr %t53, !tbaa !32
  %t56 = icmp eq i8 %t54, 32
  br i1 %t56, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb12
bb9:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb11
bb10:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l34, !tbaa !27
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 41
  store i1 %t66, ptr %l33, !tbaa !21
  br label %bb11
bb11:
  %t68 = load i1, ptr %l33, !tbaa !21
  store i1 %t68, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t69 = load i1, ptr %l28, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  br label %bb6
bb17:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t82 = icmp sge i64 %t76, %t79
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t84, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = trunc i64 %t86 to i32
  %t89 = load i64, ptr %l5, !tbaa !24
  %t93 = add i64 %t89, %a2
  %t95 = trunc i64 %t93 to i32
  %t98 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t88, i32 %t95)
  store %"compiler/source:Span" %t98, ptr %l52
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t99 = load %"compiler/source:Span", ptr %l52
  store %"compiler/source:Span" %t99, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca i8
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i64
  %l31 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t3 = load ptr, ptr %t2, !tbaa !27
  %t4 = getelementptr i8, ptr %t3, i64 0
  %t5 = load i8, ptr %t4, !tbaa !32
  %t7 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %t5)
  store i8 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t9, 0
  store i64 %t12, ptr %l9, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l10, !tbaa !24
  %t15 = icmp sge i64 1, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = icmp sle i64 1, %t17
  br i1 %t18, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_8ba315a61b976e68_980c0dda48bb0a1c)
  unreachable
bb4:
  %t20 = load i64, ptr %l9, !tbaa !24
  %t21 = load i64, ptr %l10, !tbaa !24
  %t22 = icmp sle i64 %t20, %t21
  br i1 %t22, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8ba315a61b976e68_980c0dda48bb0a1c)
  unreachable
bb6:
  %t24 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l9, !tbaa !24
  %t27 = getelementptr i8, ptr %t25, i64 1
  %t28 = sub i64 %t26, 1
  %t29 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  %t31 = load i8, ptr %l5, !tbaa !22
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = extractvalue { i64, ptr } %t30, 0
  %t35 = add i64 1, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t35)
  store i8 %t31, ptr %t36
  %t37 = getelementptr i8, ptr %t36, i64 1
  call void @olang_textcopy(ptr %t37, ptr %t33, i64 %t34)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t40, ptr %lp2
  %t42 = load ptr, ptr %lp2
  store { i64, ptr } %t39, ptr %t42, !tbaa !27
  %t43 = load ptr, ptr %lp2
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t48 = icmp sgt i64 %t46, 7
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8ba315a61b976e68_980c0dda48bb0a1c)
  unreachable
bb8:
  %t50 = load ptr, ptr %lp2
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l20, !tbaa !24
  %t53 = icmp sge i64 0, 0
  br i1 %t53, label %bb10, label %bb11
bb9:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb17
bb10:
  %t55 = icmp sle i64 0, 7
  br i1 %t55, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_36514fdaa766da45_2324f4da794b0789)
  unreachable
bb12:
  %t57 = load i64, ptr %l20, !tbaa !24
  %t58 = icmp sle i64 7, %t57
  br i1 %t58, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_36514fdaa766da45_2324f4da794b0789)
  unreachable
bb14:
  %t60 = load ptr, ptr %lp2
  %t61 = getelementptr { i64, ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 0
  %t64 = sub i64 7, 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t66, { i64, ptr } { i64 7, ptr @.d29 })
  store i1 %t68, ptr %l25
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_36514fdaa766da45_2324f4da794b0789)
  unreachable
bb16:
  %t69 = load i1, ptr %l25, !tbaa !21
  store i1 %t69, ptr %l19, !tbaa !21
  br label %bb17
bb17:
  %t70 = load i1, ptr %l19, !tbaa !21
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t71 = load ptr, ptr %lp2
  %t72 = getelementptr { i64, ptr }, ptr %t71, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 7
  %t75 = load i8, ptr %t74, !tbaa !32
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t75)
  store i1 %t77, ptr %l28
  br label %bb20
bb19:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb21
bb20:
  %t78 = load i1, ptr %l28, !tbaa !21
  store i1 %t78, ptr %l26, !tbaa !21
  br label %bb21
bb21:
  %t79 = load i1, ptr %l26, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %lp2
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l30, !tbaa !24
  %t84 = load ptr, ptr %lp2
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l31, !tbaa !24
  %t87 = icmp sge i64 7, 0
  br i1 %t87, label %bb24, label %bb25
bb23:
  br label %bb30
bb24:
  %t89 = load i64, ptr %l30, !tbaa !24
  %t90 = icmp sle i64 7, %t89
  br i1 %t90, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_36514fdaa766da45_2324f4da794b0789)
  unreachable
bb26:
  %t92 = load i64, ptr %l30, !tbaa !24
  %t93 = load i64, ptr %l31, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_36514fdaa766da45_2324f4da794b0789)
  unreachable
bb28:
  %t96 = load ptr, ptr %lp2
  %t97 = getelementptr { i64, ptr }, ptr %t96, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = load i64, ptr %l30, !tbaa !24
  %t100 = getelementptr i8, ptr %t98, i64 7
  %t101 = sub i64 %t99, 7
  %t102 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  %t105 = extractvalue { i64, ptr } %t103, 1
  %t106 = extractvalue { i64, ptr } %t103, 0
  %t107 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t105, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t109, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_36514fdaa766da45_2324f4da794b0789)
  unreachable
bb30:
  %t111 = load ptr, ptr %lp2
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t112, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca ptr
  %l14 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l23 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l39 = alloca { i64, [3 x i64] }
  store ptr %a0, ptr %l0
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t14 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v0, ptr %t11, ptr %t9, i64 %a4)
  store { i64, [2 x i64] } %t14, ptr %l14
  br label %bb2
bb2:
  %t15 = load { i64, [2 x i64] }, ptr %l14
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t16, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 0, { i64, [2 x i64] } %t15)
  store i64 %t27, ptr %l21
  br label %bb3
bb3:
  %t28 = load i64, ptr %l21, !tbaa !24
  store i64 %t28, ptr %l7, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l23
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l23, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %l7, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ePus_H9afb0399fee55ed1ef4b4d03ad72cb66(ptr %v0, ptr %t34, i32 %t37)
  br label %bb5
bb5:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb6, label %bb7
bb6:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t47)
  store ptr %t49, ptr %l33
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t50 = load ptr, ptr %l33, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 3
  store ptr %t52, ptr %l35, !tbaa !29
  %t53 = load i64, ptr %l7, !tbaa !24
  store i64 %t53, ptr %l36, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t58 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  store { i64, [3 x i64] } %t58, ptr %l39
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = load i64, ptr %l36, !tbaa !24
  %t61 = load { i64, [3 x i64] }, ptr %l39
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t59, i64 %t60, { i64, [3 x i64] } %t61)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l19 = alloca i64
  %l27 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 24
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettle(ptr %v0, ptr %v0, ptr %t10, ptr %t11)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 0
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 20
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb12
bb8:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/load:Loader", ptr %t32, i32 0, i32 4
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l19
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 39
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr %l19, !tbaa !24
  %t44 = icmp sgt i64 %t42, %t41
  store i1 %t44, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t46 = load i1, ptr %l14, !tbaa !21
  store i1 %t46, ptr %l11, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l11, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 82
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 0
  %t54 = load i64, ptr %t53, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t50, i64 %t54, i1 true)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 12
  %t61 = call { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H89a3697e96ae7f34894afc674ffcde65(ptr %v0, ptr %v0, ptr %t59)
  %t62 = extractvalue { i32, ptr } %t61, 1
  %t63 = extractvalue { i32, ptr } %t61, 0
  store i32 %t63, ptr %l31
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb18, label %ok.65
ok.65:
  store ptr %t62, ptr %l30
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l30, !tbaa !29
  store ptr %t66, ptr %l27, !tbaa !29
  br label %bb20
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"compiler/typed:SiteInfo"
  %l10 = alloca ptr
  %l15 = alloca %"compiler/typed:SiteInfo"
  %l19 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 10
  %t13 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t9, i64 %a2)
  store ptr %t13, ptr %l10
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 9
  %t17 = load i32, ptr %l1, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call %"compiler/typed:SiteInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eAt_Hc70ee24fb8cd4f4ed4bbdcaa906642ed(ptr %v0, ptr %t16, i64 %t19)
  store %"compiler/typed:SiteInfo" %t22, ptr %l15
  br label %bb5
bb5:
  %t23 = load %"compiler/typed:SiteInfo", ptr %l15
  store %"compiler/typed:SiteInfo" %t23, ptr %l3
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/typed:SiteInfo", ptr %l3, i32 0, i32 0
  %t26 = load i32, ptr %t25
  %t27 = getelementptr %"compiler/typed:SiteInfo", ptr %l3, i32 0, i32 1
  %t28 = load %"compiler/source:Span", ptr %t27
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t24, i32 %t26, %"compiler/source:Span" %t28)
  store i32 %t32, ptr %l19
  br label %bb6
bb6:
  %t33 = load i32, ptr %l19, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l8 = alloca i32
  %l14 = alloca i1
  %l19 = alloca i32
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t11, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l14
  br label %bb4
bb3:
  br label %bb14
bb4:
  %t25 = load i1, ptr %l14, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l19
  br label %bb8
bb8:
  %t34 = load i32, ptr %l19
  %t37 = trunc i64 4 to i32
  %t38 = icmp eq i32 %t34, %t37
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l27
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load i32, ptr %l27, !tbaa !23
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t53, ptr %l28
  br label %bb12
bb12:
  %t54 = load i1, ptr %l28, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t61, i32 %t62)
  store i1 %t65, ptr %l34
  br label %bb15
bb15:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb18
bb17:
  %t67 = load i32, ptr %l1, !tbaa !23
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t71 = icmp eq i32 %t67, %t68
  store i1 %t71, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t73 = load i1, ptr %l35, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereset(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca ptr
  %l15 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l17 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca ptr
  %l21 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca ptr
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca ptr
  %l27 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca ptr
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca ptr
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca ptr
  %l33 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca ptr
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca ptr
  %l37 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca ptr
  %l39 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca ptr
  %l42 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca ptr
  %l44 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca ptr
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca ptr
  %l48 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca ptr
  %l50 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca ptr
  %l52 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca ptr
  %l54 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca ptr
  %l56 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca ptr
  %l58 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca ptr
  %l60 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca ptr
  %l62 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca ptr
  %l64 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca ptr
  %l66 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca ptr
  %l68 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca ptr
  %l70 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca ptr
  %l72 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca ptr
  %l74 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca ptr
  %l76 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca ptr
  %l78 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca ptr
  %l80 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca ptr
  %l82 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca ptr
  %l84 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca ptr
  %l86 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca ptr
  %l88 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca ptr
  %l90 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca ptr
  %l92 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca ptr
  %l94 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca ptr
  %l96 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l97 = alloca ptr
  %l98 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca ptr
  %l100 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca ptr
  %l102 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l103 = alloca ptr
  %l104 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l105 = alloca ptr
  %l106 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l3, !tbaa !29
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l4
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t10
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l5, !tbaa !29
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l6
  br label %bb3
bb3:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %t15
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l7, !tbaa !29
  %t17 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l8
  br label %bb4
bb4:
  %t18 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t19 = load ptr, ptr %l7, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %t20
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 14
  store i64 0, ptr %t23, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l10, !tbaa !29
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l11
  br label %bb5
bb5:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %t28
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l12, !tbaa !29
  %t30 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l13
  br label %bb6
bb6:
  %t31 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t32 = load ptr, ptr %l12, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 16
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %t33
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l14, !tbaa !29
  %t35 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l15
  br label %bb7
bb7:
  %t36 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t37 = load ptr, ptr %l14, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 19
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %t38
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l16, !tbaa !29
  %t40 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l17
  br label %bb8
bb8:
  %t41 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  %t42 = load ptr, ptr %l16, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 20
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %t43
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t48 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 21
  store i32 %t45, ptr %t48, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l20, !tbaa !29
  %t50 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l21
  br label %bb9
bb9:
  %t51 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 22
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %t53
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l22, !tbaa !29
  %t55 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l23
  br label %bb10
bb10:
  %t56 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  %t57 = load ptr, ptr %l22, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 23
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %t58
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l24, !tbaa !29
  %t60 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l25
  br label %bb11
bb11:
  %t61 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  %t62 = load ptr, ptr %l24, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %t63
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l26, !tbaa !29
  %t65 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l27
  br label %bb12
bb12:
  %t66 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  %t67 = load ptr, ptr %l26, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 25
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %t68
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l28, !tbaa !29
  %t70 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l29
  br label %bb13
bb13:
  %t71 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  %t72 = load ptr, ptr %l28, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 26
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %t73
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l30, !tbaa !29
  %t75 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l31
  br label %bb14
bb14:
  %t76 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  %t77 = load ptr, ptr %l30, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %t78
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l32, !tbaa !29
  %t80 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %l33
  br label %bb15
bb15:
  %t81 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  %t82 = load ptr, ptr %l32, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 28
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %t83
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l34, !tbaa !29
  %t85 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l35
  br label %bb16
bb16:
  %t86 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  %t87 = load ptr, ptr %l34, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 31
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %t88
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l36, !tbaa !29
  %t90 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %l37
  br label %bb17
bb17:
  %t91 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  %t92 = load ptr, ptr %l36, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %t93
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l38, !tbaa !29
  %t95 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %l39
  br label %bb18
bb18:
  %t96 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  %t97 = load ptr, ptr %l38, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 33
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %t98
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 34
  store i32 0, ptr %t101, !tbaa !23
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l41, !tbaa !29
  %t103 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t103, ptr %l42
  br label %bb19
bb19:
  %t104 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  %t105 = load ptr, ptr %l41, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 45
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %t106
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l43, !tbaa !29
  %t108 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %l44
  br label %bb20
bb20:
  %t109 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  %t110 = load ptr, ptr %l43, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 46
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t109, ptr %t111
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l45, !tbaa !29
  %t113 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t113, ptr %l46
  br label %bb21
bb21:
  %t114 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  %t115 = load ptr, ptr %l45, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 47
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %t116
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l47, !tbaa !29
  %t118 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %l48
  br label %bb22
bb22:
  %t119 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  %t120 = load ptr, ptr %l47, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 48
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t119, ptr %t121
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l49, !tbaa !29
  %t123 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t123, ptr %l50
  br label %bb23
bb23:
  %t124 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  %t125 = load ptr, ptr %l49, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 50
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %t126
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l51, !tbaa !29
  %t128 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %l52
  br label %bb24
bb24:
  %t129 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  %t130 = load ptr, ptr %l51, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 52
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t129, ptr %t131
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l53, !tbaa !29
  %t133 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %l54
  br label %bb25
bb25:
  %t134 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  %t135 = load ptr, ptr %l53, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 53
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %t136
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l55, !tbaa !29
  %t138 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %l56
  br label %bb26
bb26:
  %t139 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  %t140 = load ptr, ptr %l55, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 54
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t139, ptr %t141
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l57, !tbaa !29
  %t143 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, ptr %l58
  br label %bb27
bb27:
  %t144 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  %t145 = load ptr, ptr %l57, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 55
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %t146
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l59, !tbaa !29
  %t148 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %l60
  br label %bb28
bb28:
  %t149 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  %t150 = load ptr, ptr %l59, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 56
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t149, ptr %t151
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l61, !tbaa !29
  %t153 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H94cbbacdefacbf11591e45fa927fb1cb(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t153, ptr %l62
  br label %bb29
bb29:
  %t154 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  %t155 = load ptr, ptr %l61, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 57
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %t156
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l63, !tbaa !29
  %t158 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, ptr %l64
  br label %bb30
bb30:
  %t159 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  %t160 = load ptr, ptr %l63, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 58
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t159, ptr %t161
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l65, !tbaa !29
  %t163 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t163, ptr %l66
  br label %bb31
bb31:
  %t164 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  %t165 = load ptr, ptr %l65, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 59
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %t166
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l67, !tbaa !29
  %t168 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2flis_H596e3d714cead58c6bb1a410db388b73(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t168, ptr %l68
  br label %bb32
bb32:
  %t169 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  %t170 = load ptr, ptr %l67, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 60
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t169, ptr %t171
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l69, !tbaa !29
  %t173 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t173, ptr %l70
  br label %bb33
bb33:
  %t174 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  %t175 = load ptr, ptr %l69, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 61
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t174, ptr %t176
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l71, !tbaa !29
  %t178 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t178, ptr %l72
  br label %bb34
bb34:
  %t179 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l72
  %t180 = load ptr, ptr %l71, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 62
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t179, ptr %t181
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l73, !tbaa !29
  %t183 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l74
  br label %bb35
bb35:
  %t184 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  %t185 = load ptr, ptr %l73, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 63
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %t186
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l75, !tbaa !29
  %t188 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroDeepArg_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t188, ptr %l76
  br label %bb36
bb36:
  %t189 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  %t190 = load ptr, ptr %l75, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t190, i32 0, i32 64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t189, ptr %t191
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l77, !tbaa !29
  %t193 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t193, ptr %l78
  br label %bb37
bb37:
  %t194 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  %t195 = load ptr, ptr %l77, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 65
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t194, ptr %t196
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l79, !tbaa !29
  %t198 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t198, ptr %l80
  br label %bb38
bb38:
  %t199 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  %t200 = load ptr, ptr %l79, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 66
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t199, ptr %t201
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l81, !tbaa !29
  %t203 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t203, ptr %l82
  br label %bb39
bb39:
  %t204 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  %t205 = load ptr, ptr %l81, !tbaa !29
  %t206 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 67
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t204, ptr %t206
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l83, !tbaa !29
  %t208 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t208, ptr %l84
  br label %bb40
bb40:
  %t209 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  %t210 = load ptr, ptr %l83, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 68
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t209, ptr %t211
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l85, !tbaa !29
  %t213 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t213, ptr %l86
  br label %bb41
bb41:
  %t214 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  %t215 = load ptr, ptr %l85, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t215, i32 0, i32 73
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t214, ptr %t216
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l87, !tbaa !29
  %t218 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t218, ptr %l88
  br label %bb42
bb42:
  %t219 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  %t220 = load ptr, ptr %l87, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 74
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %t221
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l89, !tbaa !29
  %t223 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t223, ptr %l90
  br label %bb43
bb43:
  %t224 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  %t225 = load ptr, ptr %l89, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 75
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t224, ptr %t226
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l91, !tbaa !29
  %t228 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t228, ptr %l92
  br label %bb44
bb44:
  %t229 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  %t230 = load ptr, ptr %l91, !tbaa !29
  %t231 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 76
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t229, ptr %t231
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l93, !tbaa !29
  %t233 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t233, ptr %l94
  br label %bb45
bb45:
  %t234 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l94
  %t235 = load ptr, ptr %l93, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 77
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %t236
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l95, !tbaa !29
  %t238 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %l96
  br label %bb46
bb46:
  %t239 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  %t240 = load ptr, ptr %l95, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 78
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t239, ptr %t241
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l97, !tbaa !29
  %t243 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t243, ptr %l98
  br label %bb47
bb47:
  %t244 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  %t245 = load ptr, ptr %l97, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 79
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t244, ptr %t246
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l99, !tbaa !29
  %t248 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t248, ptr %l100
  br label %bb48
bb48:
  %t249 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  %t250 = load ptr, ptr %l99, !tbaa !29
  %t251 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 82
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t249, ptr %t251
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l101, !tbaa !29
  %t253 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t253, ptr %l102
  br label %bb49
bb49:
  %t254 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l102
  %t255 = load ptr, ptr %l101, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t255, i32 0, i32 83
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t254, ptr %t256
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l103, !tbaa !29
  %t258 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t258, ptr %l104
  br label %bb50
bb50:
  %t259 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  %t260 = load ptr, ptr %l103, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t260, i32 0, i32 84
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t259, ptr %t261
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l105, !tbaa !29
  %t263 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t263, ptr %l106
  br label %bb51
bb51:
  %t264 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l106
  %t265 = load ptr, ptr %l105, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 85
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t264, ptr %t266
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i1
  %l23 = alloca i32
  %l26 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l8
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l6, !tbaa !29
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l11
  br label %bb4
bb4:
  %t16 = load i1, ptr %l11, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l5, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t20)
  store i32 %t23, ptr %l15
  br label %bb9
bb9:
  %t24 = load i32, ptr %l15, !tbaa !23
  store i32 %t24, ptr %l2, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l18
  br label %bb10
bb10:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l2, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t41 = load i32, ptr %l23, !tbaa !23
  store i32 %t41, ptr %l2, !tbaa !23
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l26
  br label %bb15
bb15:
  %t47 = load i1, ptr %l26, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb16, label %bb17
bb16:
  br label %ret
bb17:
  br label %bb18
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 63
  store ptr %t52, ptr %l29, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t53)
  store ptr %t55, ptr %l31
  br label %bb19
bb19:
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t58 = getelementptr %"compiler/check:frame", ptr %t56, i32 0, i32 0
  %t59 = load i64, ptr %t58, !tbaa !24
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t63 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, ptr %v0, i64 %t59, ptr %t60)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t63, ptr %l35
  br label %bb20
bb20:
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l35
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compil_H33d643ee420c12f578033f46e688097e(ptr %v0, ptr %v0, ptr %t64, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t65)
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

define dso_local %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  %t11 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t7, i64 %a1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %rv
  ret %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLend(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l15 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %t9, ptr %t10, %"compiler/source:Span" %a2)
  store %"compiler/source:Span" %t15, ptr %l11
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store i32 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t22)
  store i32 %t25, ptr %l18
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i32, ptr %l15, !tbaa !23
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %s1, ptr %t26, i32 %t27, i32 %t28)
  store { i64, ptr } %t29, ptr %l19
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %s1, ptr %s1, { i64, ptr } %t36)
  store %"compiler/msgs:Msg" %t38, ptr %l21
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l7, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l11
  %t41 = load %"compiler/msgs:Msg", ptr %l21
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t39, %"compiler/source:Span" %t40, %"compiler/msgs:Msg" %t41)
  store i64 %t42, ptr %l22
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca %"compiler/typed:Local"
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l25 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l26 = alloca i1
  %l27 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t22 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t20, i32 %t19)
  store %"compiler/typed:Local" %t22, ptr %l12
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 4
  %t24 = load i32, ptr %t23
  %t26 = trunc i64 0 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %t29)
  store i1 %t31, ptr %l17
  br label %bb10
bb9:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb10:
  %t32 = load i1, ptr %l17, !tbaa !21
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l15, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 54
  store ptr %t37, ptr %l21, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t44 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t38, i64 %t41)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t44, ptr %l25
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l21, !tbaa !29
  %t46 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l25
  %t47 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %t45, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t46)
  %t48 = extractvalue { i32, i1 } %t47, 1
  %t49 = extractvalue { i32, i1 } %t47, 0
  store i32 %t49, ptr %l27
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb17, label %ok.51
ok.51:
  store i1 %t48, ptr %l26
  br label %bb16
bb16:
  %t52 = load i1, ptr %l26, !tbaa !21
  store i1 %t52, ptr %l19, !tbaa !21
  br label %bb19
bb17:
  br label %bb18
bb18:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l19, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
bb20:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/check:roOrigin"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca %"compiler/check:roOrigin"
  %l16 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l26 = alloca %"compiler/check:roOrigin"
  %l28 = alloca ptr
  %l32 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l33 = alloca %"compiler/check:roOrigin"
  %l34 = alloca i32
  %l35 = alloca %"compiler/check:roOrigin"
  %l43 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i1
  %l70 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca i1
  %l83 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i1
  %l91 = alloca ptr
  %l96 = alloca ptr
  %l98 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i1
  %l117 = alloca %"compiler/check:roOrigin"
  %l119 = alloca ptr
  %l123 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l124 = alloca %"compiler/check:roOrigin"
  %l125 = alloca i32
  %l126 = alloca %"compiler/check:roOrigin"
  %l130 = alloca i1
  %l136 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t5, 32
  store i1 %t7, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t12 = load ptr, ptr %l20, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l20, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l3, !tbaa !23
  br label %bb11
bb10:
  br label %bb22
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 55
  store ptr %t28, ptr %l28, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t32 = sext i32 %t30 to i64
  %t35 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t29, i64 %t32)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35, ptr %l32
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l28, !tbaa !29
  %t37 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l32
  %t38 = call { i32, %"compiler/check:roOrigin" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hfc56ff01c357e6bb827daf7012f18a86(ptr %v0, ptr %v0, ptr %t36, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t37)
  %t39 = extractvalue { i32, %"compiler/check:roOrigin" } %t38, 1
  %t40 = extractvalue { i32, %"compiler/check:roOrigin" } %t38, 0
  store i32 %t40, ptr %l34
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb14, label %ok.42
ok.42:
  store %"compiler/check:roOrigin" %t39, ptr %l33
  br label %bb13
bb13:
  %t43 = load %"compiler/check:roOrigin", ptr %l33
  store %"compiler/check:roOrigin" %t43, ptr %l26
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t44 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v0, ptr null, i1 false)
  store %"compiler/check:roOrigin" %t44, ptr %l35
  br label %bb16
bb16:
  %t45 = load %"compiler/check:roOrigin", ptr %l35
  store %"compiler/check:roOrigin" %t45, ptr %l26
  br label %bb17
bb17:
  %t46 = load %"compiler/check:roOrigin", ptr %l26
  store %"compiler/check:roOrigin" %t46, ptr %l4
  %t47 = getelementptr %"compiler/check:roOrigin", ptr %l4, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:roOrigin", ptr %l4, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  %t59 = add i64 %t57, 1
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v0, ptr %t54, ptr %t56, i64 %t59)
  store i64 %t63, ptr %l43
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t64 = load i64, ptr %l43, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb21:
  %t65 = load i32, ptr %l3, !tbaa !23
  %t67 = sext i32 %t65 to i64
  store i64 %t67, ptr %rv
  br label %ret
bb22:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t70 = load ptr, ptr %l46, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t73 = load ptr, ptr %l46, !tbaa !29
  %t74 = load i64, ptr %t73
  %t76 = icmp eq i64 %t74, 3
  store i1 %t76, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t77 = load i1, ptr %l47, !tbaa !21
  br i1 %t77, label %bb25, label %bb26
bb25:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  store ptr %t82, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = load i64, ptr %l2, !tbaa !24
  %t89 = add i64 %t87, 1
  %t93 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t84, ptr %t85, i64 %t89)
  store i64 %t93, ptr %l57
  br label %bb28
bb28:
  %t94 = load i64, ptr %l57, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
bb29:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t96 = load ptr, ptr %l58, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb30, label %bb31
bb30:
  %t99 = load ptr, ptr %l58, !tbaa !29
  %t100 = load i64, ptr %t99
  %t102 = icmp eq i64 %t100, 4
  store i1 %t102, ptr %l59, !tbaa !21
  br label %bb31
bb31:
  %t103 = load i1, ptr %l59, !tbaa !21
  br i1 %t103, label %bb32, label %bb33
bb32:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l6, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Elem", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = load i64, ptr %l2, !tbaa !24
  %t118 = add i64 %t116, 1
  %t122 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t110, ptr %t114, i64 %t118)
  store i64 %t122, ptr %l70
  br label %bb35
bb35:
  %t123 = load i64, ptr %l70, !tbaa !24
  store i64 %t123, ptr %rv
  br label %ret
bb36:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t125 = load ptr, ptr %l71, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb37, label %bb38
bb37:
  %t128 = load ptr, ptr %l71, !tbaa !29
  %t129 = load i64, ptr %t128
  %t131 = icmp eq i64 %t129, 5
  store i1 %t131, ptr %l72, !tbaa !21
  br label %bb38
bb38:
  %t132 = load i1, ptr %l72, !tbaa !21
  br i1 %t132, label %bb39, label %bb40
bb39:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t135, i32 0, i32 2
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l7, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Payload", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = load i64, ptr %l2, !tbaa !24
  %t147 = add i64 %t145, 1
  %t151 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t139, ptr %t143, i64 %t147)
  store i64 %t151, ptr %l83
  br label %bb42
bb42:
  %t152 = load i64, ptr %l83, !tbaa !24
  store i64 %t152, ptr %rv
  br label %ret
bb43:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t154 = load ptr, ptr %l84, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb44, label %bb45
bb44:
  %t157 = load ptr, ptr %l84, !tbaa !29
  %t158 = load i64, ptr %t157
  %t160 = icmp eq i64 %t158, 6
  store i1 %t160, ptr %l85, !tbaa !21
  br label %bb45
bb45:
  %t161 = load i1, ptr %l85, !tbaa !21
  br i1 %t161, label %bb46, label %bb47
bb46:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t164, i32 0, i32 2
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l8, !tbaa !29
  br label %bb48
bb47:
  br label %bb55
bb48:
  %t168 = load ptr, ptr %l8, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %t168)
  store ptr %t170, ptr %l91
  br label %bb49
bb49:
  %t171 = load ptr, ptr %l91, !tbaa !29
  store ptr %t171, ptr %l9, !tbaa !29
  %t172 = load ptr, ptr %l9, !tbaa !29
  %t173 = load ptr, ptr %l8, !tbaa !29
  %t176 = icmp eq ptr %t172, %t173
  br i1 %t176, label %bb50, label %bb51
bb50:
  store i64 -1, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l96, !tbaa !29
  %t180 = load ptr, ptr %l9, !tbaa !29
  %t182 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t180)
  store ptr %t182, ptr %l98
  br label %bb53
bb53:
  %t183 = load i64, ptr %l2, !tbaa !24
  %t185 = add i64 %t183, 1
  %t186 = load ptr, ptr %l96, !tbaa !29
  %t187 = load ptr, ptr %l98, !tbaa !29
  %t189 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t186, ptr %t187, i64 %t185)
  store i64 %t189, ptr %l101
  br label %bb54
bb54:
  %t190 = load i64, ptr %l101, !tbaa !24
  store i64 %t190, ptr %rv
  br label %ret
bb55:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t192 = load ptr, ptr %l102, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb56, label %bb57
bb56:
  %t195 = load ptr, ptr %l102, !tbaa !29
  %t196 = load i64, ptr %t195
  %t198 = icmp eq i64 %t196, 2
  store i1 %t198, ptr %l103, !tbaa !21
  br label %bb57
bb57:
  %t199 = load i1, ptr %l103, !tbaa !21
  br i1 %t199, label %bb58, label %bb59
bb58:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t202, i32 0, i32 2
  %t204 = load ptr, ptr %t203
  store ptr %t204, ptr %l10, !tbaa !29
  br label %bb60
bb59:
  br label %bb83
bb60:
  %t206 = load ptr, ptr %l10, !tbaa !29
  %t208 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %t206)
  store ptr %t208, ptr %l109
  br label %bb61
bb61:
  %t209 = load ptr, ptr %l109, !tbaa !29
  %t210 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t209)
  store ptr %t210, ptr %l110
  br label %bb62
bb62:
  %t211 = load ptr, ptr %l110, !tbaa !29
  store ptr %t211, ptr %l11, !tbaa !29
  %t212 = load ptr, ptr %l11, !tbaa !29
  store ptr %t212, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t213 = load ptr, ptr %l111, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb63, label %bb64
bb63:
  %t216 = load ptr, ptr %l111, !tbaa !29
  %t217 = load i64, ptr %t216
  %t219 = icmp eq i64 %t217, 0
  store i1 %t219, ptr %l112, !tbaa !21
  br label %bb64
bb64:
  %t220 = load i1, ptr %l112, !tbaa !21
  br i1 %t220, label %bb65, label %bb66
bb65:
  %t221 = load ptr, ptr %l11, !tbaa !29
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t223, i32 0, i32 2
  %t225 = load i32, ptr %t224
  store i32 %t225, ptr %l12, !tbaa !23
  br label %bb67
bb66:
  br label %bb81
bb67:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 55
  store ptr %t229, ptr %l119, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l12, !tbaa !23
  %t233 = sext i32 %t231 to i64
  %t236 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t230, i64 %t233)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t236, ptr %l123
  br label %bb68
bb68:
  %t237 = load ptr, ptr %l119, !tbaa !29
  %t238 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l123
  %t239 = call { i32, %"compiler/check:roOrigin" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hfc56ff01c357e6bb827daf7012f18a86(ptr %v0, ptr %v0, ptr %t237, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t238)
  %t240 = extractvalue { i32, %"compiler/check:roOrigin" } %t239, 1
  %t241 = extractvalue { i32, %"compiler/check:roOrigin" } %t239, 0
  store i32 %t241, ptr %l125
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb70, label %ok.243
ok.243:
  store %"compiler/check:roOrigin" %t240, ptr %l124
  br label %bb69
bb69:
  %t244 = load %"compiler/check:roOrigin", ptr %l124
  store %"compiler/check:roOrigin" %t244, ptr %l117
  br label %bb73
bb70:
  br label %bb71
bb71:
  %t245 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v0, ptr null, i1 false)
  store %"compiler/check:roOrigin" %t245, ptr %l126
  br label %bb72
bb72:
  %t246 = load %"compiler/check:roOrigin", ptr %l126
  store %"compiler/check:roOrigin" %t246, ptr %l117
  br label %bb73
bb73:
  %t247 = load %"compiler/check:roOrigin", ptr %l117
  store %"compiler/check:roOrigin" %t247, ptr %l13
  %t248 = getelementptr %"compiler/check:roOrigin", ptr %l13, i32 0, i32 0
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = icmp eq ptr %t249, null
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb74, label %bb75
bb74:
  %t255 = getelementptr %"compiler/check:roOrigin", ptr %l13, i32 0, i32 1
  %t256 = load i1, ptr %t255, !tbaa !21
  store i1 %t256, ptr %l130, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb76
bb76:
  %t258 = load i1, ptr %l130, !tbaa !21
  br i1 %t258, label %bb77, label %bb78
bb77:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/check:roOrigin", ptr %l13, i32 0, i32 0
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t262 = load i64, ptr %l2, !tbaa !24
  %t264 = add i64 %t262, 1
  %t268 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v0, ptr %t259, ptr %t261, i64 %t264)
  store i64 %t268, ptr %l136
  br label %bb79
bb78:
  br label %bb80
bb79:
  %t269 = load i64, ptr %l136, !tbaa !24
  store i64 %t269, ptr %rv
  br label %ret
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  store i64 -1, ptr %rv
  br label %ret
bb83:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i1
  %l23 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t25 = load i32, ptr %l15
  %t27 = trunc i64 19 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l10, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l2, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = icmp eq i32 %t41, 0
  store i1 %t42, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t44 = load i1, ptr %l18, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca %"std/prelude/text:StringBuilder"
  %l53 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l79 = alloca i64
  %l82 = alloca i64
  %l103 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l133 = alloca i64
  %l135 = alloca { i64, ptr }
  %l140 = alloca i1
  %l141 = alloca i1
  %l145 = alloca i1
  %l151 = alloca ptr
  %l155 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l169 = alloca i32
  %l181 = alloca i64
  %l184 = alloca i1
  %l185 = alloca i1
  %l189 = alloca i1
  %l198 = alloca ptr
  %l202 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l214 = alloca i32
  %l215 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l229 = alloca ptr
  %l231 = alloca { i64, ptr }
  %l236 = alloca i32
  %l243 = alloca i32
  %l244 = alloca ptr
  %l247 = alloca ptr
  %l252 = alloca i32
  %l253 = alloca i32
  %l254 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l261 = alloca i32
  %l262 = alloca { i64, ptr }
  %l267 = alloca i64
  %l273 = alloca i64
  %l276 = alloca i64
  %l296 = alloca i1
  %l298 = alloca i64
  %l312 = alloca i64
  %l315 = alloca i64
  %l335 = alloca i1
  %l337 = alloca i64
  %l344 = alloca ptr
  %l345 = alloca { i64, ptr }
  %l347 = alloca { i64, ptr }
  %l350 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l362 = alloca { i64, ptr }
  %l363 = alloca i64
  %l364 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l42, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t8, i64 %t9)
  store i64 %t12, ptr %l46
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l42, !tbaa !29
  %t14 = load i64, ptr %l46, !tbaa !24
  %t15 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t13, i64 %t14)
  store ptr %t15, ptr %l47
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l47, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  %t24 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t24, ptr %l51
  br label %bb3
bb3:
  %t25 = load i32, ptr %l51, !tbaa !23
  store i32 %t25, ptr %l4, !tbaa !23
  %t26 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t26, ptr %l52
  br label %bb4
bb4:
  %t27 = load %"std/prelude/text:StringBuilder", ptr %l52
  store %"std/prelude/text:StringBuilder" %t27, ptr %l5
  store ptr %l5, ptr %l53, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %t31, !tbaa !23
  %t35 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t28, i32 %t32)
  store { i64, ptr } %t35, ptr %l57
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l53, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l57, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t36, { i64, ptr } %t37)
  br label %bb6
bb6:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 40)
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  store ptr %t44, ptr %l61, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l66
  br label %bb8
bb8:
  %t55 = load ptr, ptr %l61, !tbaa !29
  %t56 = load i32, ptr %l66, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t55, i32 %t56)
  store { i64, ptr } %t57, ptr %l67
  br label %bb9
bb9:
  %t58 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t58, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb10, label %bb11
bb10:
  store i64 1, ptr %l7, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  store i64 0, ptr %l8, !tbaa !24
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 3
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Sig", ptr %t71, i32 0, i32 0
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  store i64 %t76, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb13, label %bb14
bb13:
  %t84 = load i64, ptr %l10, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb18
bb15:
  %t88 = load i64, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l10, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l82, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb17
bb17:
  %t104 = load i64, ptr %l82, !tbaa !24
  store i64 %t104, ptr %l79, !tbaa !24
  br label %bb18
bb18:
  %t105 = load i64, ptr %l79, !tbaa !24
  store i64 %t105, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t106 = load i64, ptr %l12, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb21:
  br label %bb22
bb22:
  %t114 = load i64, ptr %l8, !tbaa !24
  %t115 = load i64, ptr %l12, !tbaa !24
  %t116 = load i64, ptr %l10, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  store i64 %t122, ptr %l13, !tbaa !24
  %t124 = load i64, ptr %l13, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l5, { i64, ptr } { i64 2, ptr @.d30 })
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  store ptr %l5, ptr %l103, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t132 = getelementptr %"compiler/ast:Func", ptr %t130, i32 0, i32 3
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/ast:Sig", ptr %t133, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l107, !tbaa !27
  %t137 = load i64, ptr %l13, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr ptr, ptr %t140, i64 %t137
  %t142 = load ptr, ptr %t141, !tbaa !39
  %t144 = getelementptr %"compiler/ast:Param", ptr %t142, i32 0, i32 1
  %t145 = load i32, ptr %t144, !tbaa !23
  %t148 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t129, i32 %t145)
  store { i64, ptr } %t148, ptr %l111
  br label %bb27
bb27:
  %t149 = load ptr, ptr %l103, !tbaa !29
  %t150 = load { i64, ptr }, ptr %l111, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t149, { i64, ptr } %t150)
  br label %bb28
bb28:
  %t151 = load i64, ptr %l7, !tbaa !24
  %t152 = load i64, ptr %l13, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t156 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t161 = icmp slt i64 %t155, %t158
  br i1 %t161, label %bb29, label %bb30
bb29:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 32)
  br label %bb31
bb30:
  br label %bb46
bb31:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t165, ptr %l121, !tbaa !27
  %t166 = load i64, ptr %l7, !tbaa !24
  %t167 = load i64, ptr %l13, !tbaa !24
  %t170 = add i64 %t166, %t167
  %t172 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i32, ptr %t173, i64 %t170
  %t175 = load i32, ptr %t174, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %s0, ptr %t164, ptr %l5, i32 %t175, i1 false)
  br label %bb32
bb32:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l4, !tbaa !23
  %t186 = load i64, ptr %l7, !tbaa !24
  %t187 = load i64, ptr %l13, !tbaa !24
  %t190 = add i64 %t186, %t187
  %t194 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t184, i32 %t185, i64 %t190)
  store i64 %t194, ptr %l133
  br label %bb33
bb33:
  %t195 = load i64, ptr %l133, !tbaa !24
  store i64 %t195, ptr %l14, !tbaa !24
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t197, ptr %l135, !tbaa !27
  %t198 = load i64, ptr %l7, !tbaa !24
  %t199 = load i64, ptr %l13, !tbaa !24
  %t202 = add i64 %t198, %t199
  %t204 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 %t202
  %t207 = load i32, ptr %t206, !tbaa !33
  %t210 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t196, i32 %t207)
  store i1 %t210, ptr %l140
  br label %bb34
bb34:
  %t211 = load i1, ptr %l140, !tbaa !21
  br i1 %t211, label %bb35, label %bb36
bb35:
  %t212 = load i64, ptr %l14, !tbaa !24
  %t213 = load i64, ptr %l7, !tbaa !24
  %t216 = icmp sge i64 %t212, %t213
  store i1 %t216, ptr %l141, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb37
bb37:
  %t218 = load i1, ptr %l141, !tbaa !21
  br i1 %t218, label %bb38, label %bb39
bb38:
  %t219 = load i64, ptr %l14, !tbaa !24
  %t220 = load i64, ptr %l7, !tbaa !24
  %t223 = sub i64 %t219, %t220
  %t224 = load i64, ptr %l13, !tbaa !24
  %t227 = icmp slt i64 %t223, %t224
  store i1 %t227, ptr %l145, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb40
bb40:
  %t229 = load i1, ptr %l145, !tbaa !21
  br i1 %t229, label %bb41, label %bb42
bb41:
  store ptr %l5, ptr %l151, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l3, !tbaa !29
  %t233 = getelementptr %"compiler/ast:Func", ptr %t231, i32 0, i32 3
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = getelementptr %"compiler/ast:Sig", ptr %t234, i32 0, i32 0
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  store { i64, ptr } %t237, ptr %l155, !tbaa !27
  %t238 = load i64, ptr %l14, !tbaa !24
  %t239 = load i64, ptr %l7, !tbaa !24
  %t242 = sub i64 %t238, %t239
  %t244 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr ptr, ptr %t245, i64 %t242
  %t247 = load ptr, ptr %t246, !tbaa !39
  %t249 = getelementptr %"compiler/ast:Param", ptr %t247, i32 0, i32 1
  %t250 = load i32, ptr %t249, !tbaa !23
  %t253 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t230, i32 %t250)
  store { i64, ptr } %t253, ptr %l161
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t254 = load ptr, ptr %l151, !tbaa !29
  %t255 = load { i64, ptr }, ptr %l161, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t254, { i64, ptr } %t255)
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb47:
  %t256 = load i64, ptr %l12, !tbaa !24
  %t258 = add i64 %t256, 1
  store i64 %t258, ptr %l12, !tbaa !24
  br label %bb19
bb48:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 41)
  br label %bb49
bb49:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 2
  %t267 = load i32, ptr %l4, !tbaa !23
  %t270 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t266, i32 %t267)
  store i32 %t270, ptr %l169
  br label %bb50
bb50:
  %t271 = load i32, ptr %l169, !tbaa !23
  store i32 %t271, ptr %l15, !tbaa !23
  %t272 = load i32, ptr %l15, !tbaa !23
  %t273 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t276 = icmp ne i32 %t272, %t273
  br i1 %t276, label %bb51, label %bb52
bb51:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 32)
  br label %bb53
bb52:
  br label %bb68
bb53:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %s0, ptr %t279, ptr %l5, i32 %t280, i1 false)
  br label %bb54
bb54:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t284, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = getelementptr %"compiler/generic:Program", ptr %t287, i32 0, i32 2
  %t290 = load i32, ptr %l4, !tbaa !23
  %t293 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t289, i32 %t290, i64 0)
  store i64 %t293, ptr %l181
  br label %bb55
bb55:
  %t294 = load i64, ptr %l181, !tbaa !24
  store i64 %t294, ptr %l16, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load i32, ptr %l15, !tbaa !23
  %t299 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t295, i32 %t296)
  store i1 %t299, ptr %l184
  br label %bb56
bb56:
  %t300 = load i1, ptr %l184, !tbaa !21
  br i1 %t300, label %bb57, label %bb58
bb57:
  %t301 = load i64, ptr %l16, !tbaa !24
  %t302 = load i64, ptr %l7, !tbaa !24
  %t305 = icmp sge i64 %t301, %t302
  store i1 %t305, ptr %l185, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb59
bb59:
  %t307 = load i1, ptr %l185, !tbaa !21
  br i1 %t307, label %bb60, label %bb61
bb60:
  %t308 = load i64, ptr %l16, !tbaa !24
  %t309 = load i64, ptr %l7, !tbaa !24
  %t312 = sub i64 %t308, %t309
  %t313 = load ptr, ptr %l3, !tbaa !29
  %t315 = getelementptr %"compiler/ast:Func", ptr %t313, i32 0, i32 3
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t318 = getelementptr %"compiler/ast:Sig", ptr %t316, i32 0, i32 0
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t324 = icmp slt i64 %t312, %t321
  store i1 %t324, ptr %l189, !tbaa !21
  br label %bb62
bb61:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb62
bb62:
  %t326 = load i1, ptr %l189, !tbaa !21
  br i1 %t326, label %bb63, label %bb64
bb63:
  store ptr %l5, ptr %l198, !tbaa !29
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l3, !tbaa !29
  %t330 = getelementptr %"compiler/ast:Func", ptr %t328, i32 0, i32 3
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = getelementptr %"compiler/ast:Sig", ptr %t331, i32 0, i32 0
  %t334 = load { i64, ptr }, ptr %t333, !tbaa !27
  store { i64, ptr } %t334, ptr %l202, !tbaa !27
  %t335 = load i64, ptr %l16, !tbaa !24
  %t336 = load i64, ptr %l7, !tbaa !24
  %t339 = sub i64 %t335, %t336
  %t341 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr ptr, ptr %t342, i64 %t339
  %t344 = load ptr, ptr %t343, !tbaa !39
  %t346 = getelementptr %"compiler/ast:Param", ptr %t344, i32 0, i32 1
  %t347 = load i32, ptr %t346, !tbaa !23
  %t350 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t327, i32 %t347)
  store { i64, ptr } %t350, ptr %l208
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t351 = load ptr, ptr %l198, !tbaa !29
  %t352 = load { i64, ptr }, ptr %l208, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t351, { i64, ptr } %t352)
  br label %bb66
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/check:Checker", ptr %t353, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !29
  %t358 = getelementptr %"compiler/generic:Program", ptr %t356, i32 0, i32 2
  store ptr %t358, ptr %l211, !tbaa !29
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t363 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t359, i64 %a2)
  store i32 %t363, ptr %l214
  br label %bb69
bb69:
  %t364 = load ptr, ptr %l211, !tbaa !29
  %t365 = load i32, ptr %l214, !tbaa !23
  %t366 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t364, i32 %t365)
  store { i64, ptr } %t366, ptr %l215
  br label %bb70
bb70:
  %t367 = load { i64, ptr }, ptr %l215, !tbaa !27
  store i1 true, ptr %l18, !tbaa !21
  store { i64, ptr } %t367, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t370 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t370, 0
  store i64 %t372, ptr %l21, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s11
  %t374 = load i64, ptr %l20, !tbaa !24
  %t375 = load i64, ptr %l21, !tbaa !24
  %t378 = icmp slt i64 %t374, %t375
  %t380 = xor i1 %t378, true
  br i1 %t380, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb141
bb73:
  br label %bb74
bb74:
  %t382 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t382, ptr %l223, !tbaa !27
  %t383 = load i64, ptr %l20, !tbaa !24
  %t385 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr i32, ptr %t386, i64 %t383
  %t388 = load i32, ptr %t387, !tbaa !33
  store i32 %t388, ptr %l22, !tbaa !23
  %t390 = load i32, ptr %l22, !tbaa !23
  %t391 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t394 = icmp eq i32 %t390, %t391
  br i1 %t394, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s11)
  br label %bb140
bb76:
  br label %bb77
bb77:
  store ptr %l5, ptr %l229, !tbaa !29
  %t396 = load i1, ptr %l18, !tbaa !21
  br i1 %t396, label %bb78, label %bb79
bb78:
  store { i64, ptr } { i64 3, ptr @.d31 }, ptr %l231, !tbaa !27
  br label %bb80
bb79:
  store { i64, ptr } { i64 2, ptr @.d32 }, ptr %l231, !tbaa !27
  br label %bb80
bb80:
  %t398 = load ptr, ptr %l229, !tbaa !29
  %t399 = load { i64, ptr }, ptr %l231, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t398, { i64, ptr } %t399)
  br label %bb81
bb81:
  store i1 false, ptr %l18, !tbaa !21
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = getelementptr %"compiler/generic:Program", ptr %t403, i32 0, i32 2
  %t406 = load i32, ptr %l22, !tbaa !23
  %t409 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t405, i32 %t406)
  store i32 %t409, ptr %l236
  br label %bb82
bb82:
  %t410 = load i32, ptr %l236
  %t412 = trunc i64 28 to i32
  %t413 = icmp eq i32 %t410, %t412
  br i1 %t413, label %bb83, label %bb84
bb83:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/check:Checker", ptr %t415, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t420 = getelementptr %"compiler/generic:Program", ptr %t418, i32 0, i32 2
  %t421 = load i32, ptr %l22, !tbaa !23
  %t424 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t420, i32 %t421)
  store i32 %t424, ptr %l243
  br label %bb85
bb84:
  br label %bb138
bb85:
  %t425 = load i32, ptr %l243, !tbaa !23
  store i32 %t425, ptr %l23, !tbaa !23
  %t426 = load ptr, ptr %l0, !tbaa !29
  store ptr %t426, ptr %l244, !tbaa !29
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/check:Checker", ptr %t427, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t432 = getelementptr %"compiler/generic:Program", ptr %t430, i32 0, i32 2
  store ptr %t432, ptr %l247, !tbaa !29
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/check:Checker", ptr %t433, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !29
  %t438 = getelementptr %"compiler/generic:Program", ptr %t436, i32 0, i32 2
  %t439 = load i32, ptr %l23, !tbaa !23
  %t442 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t438, i32 %t439)
  store i32 %t442, ptr %l252
  br label %bb86
bb86:
  %t443 = load ptr, ptr %l247, !tbaa !29
  %t444 = load i32, ptr %l252, !tbaa !23
  %t445 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t443, i32 %t444)
  store i32 %t445, ptr %l253
  br label %bb87
bb87:
  %t446 = load ptr, ptr %l244, !tbaa !29
  %t447 = load i32, ptr %l253, !tbaa !23
  %t448 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t446, i32 %t447)
  store { i64, ptr } %t448, ptr %l254
  br label %bb88
bb88:
  %t449 = load { i64, ptr }, ptr %l254, !tbaa !27
  store { i64, ptr } %t449, ptr %l24, !tbaa !27
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/check:Checker", ptr %t450, i32 0, i32 1
  %t453 = load ptr, ptr %t452, !tbaa !29
  store ptr %t453, ptr %l256, !tbaa !29
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/check:Checker", ptr %t454, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !29
  %t459 = getelementptr %"compiler/generic:Program", ptr %t457, i32 0, i32 2
  %t460 = load i32, ptr %l23, !tbaa !23
  %t463 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t459, i32 %t460)
  store i32 %t463, ptr %l261
  br label %bb89
bb89:
  %t464 = load ptr, ptr %l256, !tbaa !29
  %t465 = load i32, ptr %l261, !tbaa !23
  %t466 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t464, i32 %t465)
  store { i64, ptr } %t466, ptr %l262
  br label %bb90
bb90:
  %t467 = load { i64, ptr }, ptr %l262, !tbaa !27
  store { i64, ptr } %t467, ptr %l25, !tbaa !27
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = getelementptr %"compiler/check:Checker", ptr %t468, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !29
  %t473 = getelementptr %"compiler/generic:Program", ptr %t471, i32 0, i32 2
  %t474 = load i32, ptr %l22, !tbaa !23
  %t477 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t473, i32 %t474)
  store i64 %t477, ptr %l267
  br label %bb91
bb91:
  %t478 = load i64, ptr %l267, !tbaa !65
  store i64 %t478, ptr %l26, !tbaa !65
  store i1 true, ptr %l27, !tbaa !21
  store i64 0, ptr %l28, !tbaa !24
  %t479 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t479, 0
  store i64 %t481, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t483 = load i64, ptr %l29, !tbaa !24
  %t484 = load i64, ptr %l28, !tbaa !24
  %t487 = icmp sgt i64 %t483, %t484
  br i1 %t487, label %bb92, label %bb93
bb92:
  %t489 = load i64, ptr %l30, !tbaa !24
  %t491 = icmp sgt i64 %t489, 0
  br i1 %t491, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l273, !tbaa !24
  br label %bb97
bb94:
  %t493 = load i64, ptr %l29, !tbaa !24
  %t494 = load i64, ptr %l28, !tbaa !24
  %t497 = sub i64 %t493, %t494
  %t498 = load i64, ptr %l30, !tbaa !24
  %t501 = add i64 %t497, %t498
  %t503 = sub i64 %t501, 1
  %t504 = load i64, ptr %l30, !tbaa !24
  %t507 = sdiv i64 %t503, %t504
  store i64 %t507, ptr %l276, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l276, !tbaa !24
  br label %bb96
bb96:
  %t509 = load i64, ptr %l276, !tbaa !24
  store i64 %t509, ptr %l273, !tbaa !24
  br label %bb97
bb97:
  %t510 = load i64, ptr %l273, !tbaa !24
  store i64 %t510, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s15
  %t511 = load i64, ptr %l32, !tbaa !24
  %t512 = load i64, ptr %l31, !tbaa !24
  %t515 = icmp slt i64 %t511, %t512
  %t517 = xor i1 %t515, true
  br i1 %t517, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s15)
  br label %bb109
bb100:
  br label %bb101
bb101:
  %t519 = load i64, ptr %l28, !tbaa !24
  %t520 = load i64, ptr %l32, !tbaa !24
  %t521 = load i64, ptr %l30, !tbaa !24
  %t524 = mul i64 %t520, %t521
  %t527 = add i64 %t519, %t524
  store i64 %t527, ptr %l33, !tbaa !24
  %t529 = load i64, ptr %l33, !tbaa !24
  %t531 = icmp slt i64 %t529, 64
  br i1 %t531, label %bb102, label %bb103
bb102:
  %t533 = load i64, ptr %l26, !tbaa !65
  %t534 = load i64, ptr %l33, !tbaa !24
  store i64 %t534, ptr %l298, !tbaa !24
  %t535 = load i64, ptr %l298, !tbaa !24
  %t536 = load i64, ptr %l298, !tbaa !24
  %t537 = shl i64 1, %t536
  %t540 = and i64 %t533, %t537
  %t542 = icmp eq i64 %t540, 0
  store i1 %t542, ptr %l296, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l296, !tbaa !21
  br label %bb104
bb104:
  %t544 = load i1, ptr %l296, !tbaa !21
  br i1 %t544, label %bb105, label %bb106
bb105:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb107
bb106:
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s15)
  br label %bb108
bb108:
  %t545 = load i64, ptr %l32, !tbaa !24
  %t547 = add i64 %t545, 1
  store i64 %t547, ptr %l32, !tbaa !24
  br label %bb98
bb109:
  %t549 = load i1, ptr %l27, !tbaa !21
  br i1 %t549, label %bb110, label %bb111
bb110:
  %t551 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l5, { i64, ptr } %t551)
  br label %bb112
bb111:
  br label %bb113
bb112:
  call void @__olang_scope_close(ptr %s11)
  br label %bb140
bb113:
  store i1 true, ptr %l34, !tbaa !21
  store i64 0, ptr %l35, !tbaa !24
  %t554 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t554, 0
  store i64 %t556, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t558 = load i64, ptr %l36, !tbaa !24
  %t559 = load i64, ptr %l35, !tbaa !24
  %t562 = icmp sgt i64 %t558, %t559
  br i1 %t562, label %bb114, label %bb115
bb114:
  %t564 = load i64, ptr %l37, !tbaa !24
  %t566 = icmp sgt i64 %t564, 0
  br i1 %t566, label %bb116, label %bb117
bb115:
  store i64 0, ptr %l312, !tbaa !24
  br label %bb119
bb116:
  %t568 = load i64, ptr %l36, !tbaa !24
  %t569 = load i64, ptr %l35, !tbaa !24
  %t572 = sub i64 %t568, %t569
  %t573 = load i64, ptr %l37, !tbaa !24
  %t576 = add i64 %t572, %t573
  %t578 = sub i64 %t576, 1
  %t579 = load i64, ptr %l37, !tbaa !24
  %t582 = sdiv i64 %t578, %t579
  store i64 %t582, ptr %l315, !tbaa !24
  br label %bb118
bb117:
  store i64 0, ptr %l315, !tbaa !24
  br label %bb118
bb118:
  %t584 = load i64, ptr %l315, !tbaa !24
  store i64 %t584, ptr %l312, !tbaa !24
  br label %bb119
bb119:
  %t585 = load i64, ptr %l312, !tbaa !24
  store i64 %t585, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s20
  %t586 = load i64, ptr %l39, !tbaa !24
  %t587 = load i64, ptr %l38, !tbaa !24
  %t590 = icmp slt i64 %t586, %t587
  %t592 = xor i1 %t590, true
  br i1 %t592, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s20)
  br label %bb137
bb122:
  br label %bb123
bb123:
  %t594 = load i64, ptr %l35, !tbaa !24
  %t595 = load i64, ptr %l39, !tbaa !24
  %t596 = load i64, ptr %l37, !tbaa !24
  %t599 = mul i64 %t595, %t596
  %t602 = add i64 %t594, %t599
  store i64 %t602, ptr %l40, !tbaa !24
  %t604 = load i64, ptr %l40, !tbaa !24
  %t606 = icmp slt i64 %t604, 64
  br i1 %t606, label %bb124, label %bb125
bb124:
  %t608 = load i64, ptr %l26, !tbaa !65
  %t609 = load i64, ptr %l40, !tbaa !24
  store i64 %t609, ptr %l337, !tbaa !24
  %t610 = load i64, ptr %l337, !tbaa !24
  %t611 = load i64, ptr %l337, !tbaa !24
  %t612 = shl i64 1, %t611
  %t615 = and i64 %t608, %t612
  %t617 = icmp ne i64 %t615, 0
  store i1 %t617, ptr %l335, !tbaa !21
  br label %bb126
bb125:
  store i1 false, ptr %l335, !tbaa !21
  br label %bb126
bb126:
  %t619 = load i1, ptr %l335, !tbaa !21
  br i1 %t619, label %bb127, label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s21
  %t620 = load i1, ptr %l34, !tbaa !21
  %t622 = xor i1 %t620, true
  br i1 %t622, label %bb129, label %bb130
bb128:
  br label %bb135
bb129:
  store %olang.scope zeroinitializer, ptr %s22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %l5, { i64, ptr } { i64 2, ptr @.d33 })
  br label %bb131
bb130:
  br label %bb132
bb131:
  call void @__olang_scope_close(ptr %s22)
  br label %bb132
bb132:
  store ptr %l5, ptr %l344, !tbaa !29
  %t625 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t625, ptr %l345, !tbaa !27
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t627 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t627, ptr %l347, !tbaa !27
  %t628 = load i64, ptr %l40, !tbaa !24
  %t630 = getelementptr { i64, ptr }, ptr %l347, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !27
  %t632 = getelementptr i32, ptr %t631, i64 %t628
  %t633 = load i32, ptr %t632, !tbaa !33
  %t636 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t626, i32 %t633)
  store { i64, ptr } %t636, ptr %l350
  br label %bb133
bb133:
  %t637 = load { i64, ptr }, ptr %l345, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t637, 1
  %t639 = extractvalue { i64, ptr } %t637, 0
  %t640 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 1
  %t641 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 0
  %t642 = add i64 %t639, %t641
  %t643 = load { i64, ptr }, ptr %l350, !tbaa !27
  %t644 = extractvalue { i64, ptr } %t643, 1
  %t645 = extractvalue { i64, ptr } %t643, 0
  %t646 = add i64 %t642, %t645
  %t647 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t646)
  call void @olang_textcopy(ptr %t647, ptr %t638, i64 %t639)
  %t648 = getelementptr i8, ptr %t647, i64 %t639
  call void @olang_textcopy(ptr %t648, ptr %t640, i64 %t641)
  %t649 = getelementptr i8, ptr %t648, i64 %t641
  call void @olang_textcopy(ptr %t649, ptr %t644, i64 %t645)
  %t650 = insertvalue { i64, ptr } undef, i64 %t646, 0
  %t651 = insertvalue { i64, ptr } %t650, ptr %t647, 1
  %t653 = extractvalue { i64, ptr } %t651, 0
  %t654 = extractvalue { i64, ptr } %t651, 1
  %t655 = mul i64 %t653, 1
  %t656 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t655)
  call void @llvm.memcpy.p0.p0.i64(ptr %t656, ptr %t654, i64 %t655, i1 false)
  %t657 = insertvalue { i64, ptr } undef, i64 %t653, 0
  %t658 = insertvalue { i64, ptr } %t657, ptr %t656, 1
  %t659 = load ptr, ptr %l344, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %t659, { i64, ptr } %t658)
  br label %bb134
bb134:
  store i1 false, ptr %l34, !tbaa !21
  call void @__olang_scope_close(ptr %s21)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s20)
  br label %bb136
bb136:
  %t661 = load i64, ptr %l39, !tbaa !24
  %t663 = add i64 %t661, 1
  store i64 %t663, ptr %l39, !tbaa !24
  br label %bb120
bb137:
  call void @__olang_scope_close(ptr %s11)
  br label %bb140
bb138:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t666 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %s0, ptr %t665, ptr %l5, i32 %t666, i1 false)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s11)
  br label %bb140
bb140:
  %t670 = load i64, ptr %l20, !tbaa !24
  %t672 = add i64 %t670, 1
  store i64 %t672, ptr %l20, !tbaa !24
  br label %bb71
bb141:
  %t675 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l5)
  store { i64, ptr } %t675, ptr %l361
  br label %bb142
bb142:
  %t676 = load { i64, ptr }, ptr %l361, !tbaa !27
  store { i64, ptr } %t676, ptr %l362, !tbaa !27
  %t677 = load { i64, ptr }, ptr %l362, !tbaa !27
  %t678 = extractvalue { i64, ptr } %t677, 0
  store i64 %t678, ptr %l363, !tbaa !24
  %t679 = load i64, ptr %l363, !tbaa !24
  %t680 = mul i64 %t679, 1
  %t681 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t680)
  %t682 = insertvalue { i64, ptr } undef, i64 %t679, 0
  %t683 = insertvalue { i64, ptr } %t682, ptr %t681, 1
  store { i64, ptr } %t683, ptr %l364, !tbaa !27
  %t684 = getelementptr { i64, ptr }, ptr %l364, i32 0, i32 1
  %t685 = load ptr, ptr %t684, !tbaa !27
  %t686 = getelementptr { i64, ptr }, ptr %l362, i32 0, i32 1
  %t687 = load ptr, ptr %t686, !tbaa !27
  %t688 = load i64, ptr %l363, !tbaa !24
  %t689 = mul i64 %t688, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t685, ptr %t687, i64 %t689, i1 false)
  %t690 = load { i64, ptr }, ptr %l364, !tbaa !27
  store { i64, ptr } %t690, ptr %l362, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t691 = load { i64, ptr }, ptr %l362, !tbaa !27
  store { i64, ptr } %t691, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextLit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca i32
  %l11 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %rv = alloca ptr
  %t28 = alloca { i64, [2 x i64] }, align 8
  %t36 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1, ptr %l2
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t12, i32 %t13, i64 %t11)
  store i32 %t15, ptr %l9
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l11
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l13, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %t23, %"compiler/source:Span" %t24)
  store { i64, ptr } %t27, ptr %l16
  br label %bb4
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 0
  store i64 1, ptr %t29
  %t30 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t31 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t30, 0
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, ptr } } %t31, ptr %t32
  %t33 = load { i64, [2 x i64] }, ptr %t28
  %t35 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t33, ptr %t35
  store { i64, [5 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 0
  store i64 1, ptr %t37
  %t38 = load %"compiler/source:Span", ptr %l2
  %t39 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t38, 0
  %t40 = load i32, ptr %l9, !tbaa !23
  %t41 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t39, i32 %t40, 1
  %t42 = load i64, ptr %l13, !tbaa !24
  %t43 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t41, i64 %t42, 2
  %t45 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t43, ptr %t35, 3
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t45, ptr %t46
  %t47 = load { i64, [5 x i64] }, ptr %t36
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t47, ptr %t49
  store ptr %t49, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca %"compiler/source:Span"
  %l39 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t22, ptr %l14
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l17
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = load %"compiler/source:Span", ptr %l14
  %t32 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t30, i64 %t29)
  store %"compiler/source:Span" %t32, ptr %l19
  br label %bb7
bb7:
  %t33 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t33, ptr %rv
  br label %ret
bb8:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = load i64, ptr %t38
  %t41 = icmp eq i64 %t39, 16
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t53 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketOf(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store %"compiler/source:Span" %t53, ptr %l28
  br label %bb14
bb14:
  %t54 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t54, ptr %rv
  br label %ret
bb15:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 2
  store i1 %t62, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t63 = load i1, ptr %l30, !tbaa !21
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr }, ptr %t66, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l5, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t74 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteAt(ptr %v0, ptr %v1, ptr %t70, ptr %t71)
  store %"compiler/source:Span" %t74, ptr %l37
  br label %bb21
bb21:
  %t75 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t75, ptr %rv
  br label %ret
bb22:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t76)
  store %"compiler/source:Span" %t78, ptr %l39
  br label %bb23
bb23:
  %t79 = load %"compiler/source:Span", ptr %l39
  store %"compiler/source:Span" %t79, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritten(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, %"compiler/check:ctSource" %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l26 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l44 = alloca i64
  %l47 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i1
  %l86 = alloca ptr
  %l88 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l95 = alloca %"compiler/typed:ScopeRel"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ContractBlock", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t15, i32 %t16)
  store { i64, ptr } %t19, ptr %l26
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = getelementptr %"compiler/ast:ContractBlock", ptr %t21, i32 0, i32 2
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb7:
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t38, ptr %l35, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  store ptr %t44, ptr %l9, !tbaa !29
  store i64 -1, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t46 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Outlives", ptr %t46, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t53 = load i64, ptr %l12, !tbaa !24
  %t54 = load i64, ptr %l11, !tbaa !24
  %t57 = icmp sgt i64 %t53, %t54
  br i1 %t57, label %bb9, label %bb10
bb9:
  %t59 = load i64, ptr %l13, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb14
bb11:
  %t63 = load i64, ptr %l12, !tbaa !24
  %t64 = load i64, ptr %l11, !tbaa !24
  %t67 = sub i64 %t63, %t64
  %t68 = load i64, ptr %l13, !tbaa !24
  %t71 = add i64 %t67, %t68
  %t73 = sub i64 %t71, 1
  %t74 = load i64, ptr %l13, !tbaa !24
  %t77 = sdiv i64 %t73, %t74
  store i64 %t77, ptr %l47, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb13
bb13:
  %t79 = load i64, ptr %l47, !tbaa !24
  store i64 %t79, ptr %l44, !tbaa !24
  br label %bb14
bb14:
  %t80 = load i64, ptr %l44, !tbaa !24
  store i64 %t80, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load i64, ptr %l15, !tbaa !24
  %t82 = load i64, ptr %l14, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t89 = load i64, ptr %l11, !tbaa !24
  %t90 = load i64, ptr %l15, !tbaa !24
  %t91 = load i64, ptr %l13, !tbaa !24
  %t94 = mul i64 %t90, %t91
  %t97 = add i64 %t89, %t94
  store i64 %t97, ptr %l16, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l2, !tbaa !23
  %t101 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t103 = load ptr, ptr %l9, !tbaa !29
  %t105 = getelementptr %"compiler/ast:Outlives", ptr %t103, i32 0, i32 1
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l70, !tbaa !27
  %t107 = load i64, ptr %l16, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i32, ptr %t110, i64 %t107
  %t112 = load i32, ptr %t111, !tbaa !33
  %t113 = load ptr, ptr %l9, !tbaa !29
  %t115 = getelementptr %"compiler/ast:Outlives", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l74, !tbaa !27
  %t117 = load i64, ptr %l16, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr %"compiler/source:Span", ptr %t120, i64 %t117
  %t122 = load %"compiler/source:Span", ptr %t121
  %t129 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2escopeVarOf(ptr %v0, ptr %s0, ptr %v1, ptr %t99, i32 %t100, { i64, ptr } %t101, %"compiler/check:ctSource" %a3, i32 %t112, %"compiler/source:Span" %t122)
  store i64 %t129, ptr %l77
  br label %bb19
bb19:
  %t130 = load i64, ptr %l77, !tbaa !24
  store i64 %t130, ptr %l17, !tbaa !24
  %t131 = load i64, ptr %l17, !tbaa !24
  %t133 = icmp sge i64 %t131, 0
  br i1 %t133, label %bb20, label %bb21
bb20:
  %t135 = load i64, ptr %l10, !tbaa !24
  %t137 = icmp sge i64 %t135, 0
  store i1 %t137, ptr %l80, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb22
bb22:
  %t139 = load i1, ptr %l80, !tbaa !21
  br i1 %t139, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 10
  %t146 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t142, i64 %a1)
  store ptr %t146, ptr %l86
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t147 = load ptr, ptr %l86, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Body", ptr %t147, i32 0, i32 12
  store ptr %t149, ptr %l88, !tbaa !29
  %t150 = load i64, ptr %l10, !tbaa !24
  %t151 = load i64, ptr %l17, !tbaa !24
  %t152 = load ptr, ptr %l9, !tbaa !29
  %t154 = getelementptr %"compiler/ast:Outlives", ptr %t152, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l92, !tbaa !27
  %t156 = load i64, ptr %l16, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr %"compiler/source:Span", ptr %t159, i64 %t156
  %t161 = load %"compiler/source:Span", ptr %t160
  %t165 = call %"compiler/typed:ScopeRel" @compiler_2ftyped_3aScopeRel_2ector(ptr %s6, i64 %t150, i64 %t151, %"compiler/source:Span" %t161)
  store %"compiler/typed:ScopeRel" %t165, ptr %l95
  br label %bb26
bb26:
  %t166 = load ptr, ptr %l88, !tbaa !29
  %t167 = load %"compiler/typed:ScopeRel", ptr %l95
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeRel_3e_2ePu_H3d39058be51439e1c4066e8dcab52826(ptr %v0, ptr %t166, %"compiler/typed:ScopeRel" %t167)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  %t168 = load i64, ptr %l17, !tbaa !24
  store i64 %t168, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t170 = load i64, ptr %l15, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l15, !tbaa !24
  br label %bb15
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  %t174 = load i64, ptr %l7, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l7, !tbaa !24
  br label %bb5
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompoundOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 61 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 49, ptr %l1
  br label %bb45
bb4:
  %t7 = load i32, ptr %l0
  %t9 = trunc i64 62 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i32 50, ptr %l1
  br label %bb45
bb8:
  %t13 = load i32, ptr %l0
  %t15 = trunc i64 63 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i32 51, ptr %l1
  br label %bb45
bb12:
  %t19 = load i32, ptr %l0
  %t21 = trunc i64 64 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 52, ptr %l1
  br label %bb45
bb16:
  %t25 = load i32, ptr %l0
  %t27 = trunc i64 65 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 53, ptr %l1
  br label %bb45
bb20:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 66 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 86, ptr %l1
  br label %bb45
bb24:
  %t37 = load i32, ptr %l0
  %t39 = trunc i64 67 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i32 87, ptr %l1
  br label %bb45
bb28:
  %t43 = load i32, ptr %l0
  %t45 = trunc i64 68 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 81, ptr %l1
  br label %bb45
bb32:
  %t49 = load i32, ptr %l0
  %t51 = trunc i64 69 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i32 82, ptr %l1
  br label %bb45
bb36:
  %t55 = load i32, ptr %l0
  %t57 = trunc i64 70 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i32 83, ptr %l1
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i32 0, ptr %l1
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5)
  unreachable
bb45:
  %t62 = load i32, ptr %l1
  store i32 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2efieldSpans(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l44 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:StructBody", ptr %t5, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp eq i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %lp1
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:StructBody", ptr %t17, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb7:
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l25, !tbaa !27
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t35
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %t40, ptr %l5, !tbaa !29
  %t42 = load ptr, ptr %l5, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 1
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr }, ptr %t53, i32 0, i32 1
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t57 = load ptr, ptr %l6, !tbaa !29
  %t59 = getelementptr %"compiler/ast:VarDecl", ptr %t57, i32 0, i32 5
  %t60 = load i1, ptr %t59, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t62 = load ptr, ptr %l6, !tbaa !29
  %t64 = getelementptr %"compiler/ast:VarDecl", ptr %t62, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l9, !tbaa !24
  br label %bb16
bb15:
  br label %bb23
bb16:
  store %olang.scope zeroinitializer, ptr %s7
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s7)
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t79 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t79, ptr %l44, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr %"compiler/source:Span", ptr %t83, i64 %t80
  %t85 = load %"compiler/source:Span", ptr %t84
  %t87 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v1, ptr %t87, %"compiler/source:Span" %t85)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s7)
  br label %bb21
bb21:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l8, !tbaa !24
  br label %bb16
bb22:
  br label %bb23
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t95 = load i64, ptr %l3, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l3, !tbaa !24
  br label %bb5
bb27:
  %t99 = load ptr, ptr %lp1
  %t100 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t99
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i64
  %l30 = alloca i1
  %l32 = alloca i64
  %l41 = alloca i64
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb4:
  br label %bb23
bb5:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp eq i64 %t16, 64
  store i1 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 5
  %t21 = load i1, ptr %t20, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp eq i64 %t23, 64
  br i1 %t25, label %bb10, label %bb11
bb9:
  br label %bb16
bb10:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb15
bb11:
  %t27 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = icmp sge i64 %t28, 0
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t32 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l22, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = shl i64 1, %t36
  %t40 = icmp slt i64 %t33, %t37
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l20, !tbaa !21
  store i1 %t42, ptr %l17, !tbaa !21
  br label %bb15
bb15:
  %t43 = load i1, ptr %l17, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
bb16:
  %t44 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  br i1 %t47, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = icmp eq i64 %t50, 64
  br i1 %t52, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb22
bb21:
  %t54 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = load i64, ptr %l3, !tbaa !24
  store i64 %t56, ptr %l32, !tbaa !24
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = load i64, ptr %l32, !tbaa !24
  %t59 = shl i64 1, %t58
  %t62 = icmp slt i64 %t55, %t59
  store i1 %t62, ptr %l30, !tbaa !21
  br label %bb22
bb22:
  %t64 = load i1, ptr %l30, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
bb23:
  %t65 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t66 = load i1, ptr %t65, !tbaa !21
  br i1 %t66, label %bb24, label %bb25
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = icmp eq i64 %t69, 64
  br i1 %t71, label %bb27, label %bb28
bb27:
  store i1 true, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = sub i64 %t74, 1
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = shl i64 1, %t78
  store i64 %t79, ptr %l4, !tbaa !24
  %t81 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load i64, ptr %l4, !tbaa !24
  %t85 = sub i64 0, %t83
  %t88 = icmp sge i64 %t82, %t85
  br i1 %t88, label %bb30, label %bb31
bb30:
  %t90 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = load i64, ptr %l4, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  store i1 %t95, ptr %l47, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l47, !tbaa !21
  store i1 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %a0) #0 {
entry:
  %l2 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 true, i1 false, i1 false, i64 %a0, double 0x0000000000000000)
  store %"compiler/check:litv" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:litv", ptr %l2
  store %"compiler/check:litv" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2eintOnly(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 81 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 82 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 83 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0
  %t20 = trunc i64 53 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0
  %t26 = trunc i64 86 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0
  %t32 = trunc i64 87 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 7 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %rv
  br label %ret
bb6:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2elambdaOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 23
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_94831dcf6c50df99_e0fe015107062615)
  unreachable
bb11:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %rv = alloca { i1, i64 }
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 2
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = insertvalue { i1, i64 } undef, i1 false, 0
  %t9 = insertvalue { i1, i64 } %t7, i64 %t5, 1
  store { i1, i64 } %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = icmp slt i64 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t17 = load i64, ptr %t16, !tbaa !24
  %t20 = sub i64 0, %t17
  %t21 = insertvalue { i1, i64 } undef, i1 true, 0
  %t23 = insertvalue { i1, i64 } %t21, i64 %t20, 1
  store { i1, i64 } %t23, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t25 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = insertvalue { i1, i64 } undef, i1 false, 0
  %t30 = insertvalue { i1, i64 } %t28, i64 %t26, 1
  store { i1, i64 } %t30, ptr %rv
  br label %ret
ret:
  %rr = load { i1, i64 }, ptr %rv
  ret { i1, i64 } %rr
}

define dso_local i1 @compiler_2fcheck_2ementions(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i32
  %l46 = alloca { i64, ptr }
  %l51 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v1, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l19
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i1, ptr %l19, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l20, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t37 = load i32, ptr %l3
  %t39 = trunc i64 14 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t43 = load ptr, ptr @__olang_prog_scope
  %t44 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e(ptr %t43)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l29
  br label %bb18
bb18:
  %t45 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l4
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2echildren(ptr %v0, ptr %s0, ptr %t46, ptr %l4)
  br label %bb19
bb19:
  store ptr %l4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eRunFrom_3ccompiler_2fast_3aExpr_26_3e(ptr %s0, ptr %t50, i64 %t51)
  %t55 = extractvalue { i32, { i64, ptr } } %t54, 1
  %t56 = extractvalue { i32, { i64, ptr } } %t54, 0
  store i32 %t56, ptr %l37
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb22, label %ok.58
ok.58:
  store { i64, ptr } %t55, ptr %l36
  br label %bb21
bb21:
  %t59 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t59, ptr %l33, !tbaa !27
  br label %bb26
bb22:
  %t60 = load i32, ptr %l37, !tbaa !23
  %t61 = ashr i32 %t60, 16
  %t63 = icmp eq i32 %t61, 1
  br i1 %t63, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7c3afe8c472f60a6_aa2fd777f924487a)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb26:
  %t65 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t65, ptr %l7, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t78 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr ptr, ptr %t82, i64 %t79
  %t84 = load ptr, ptr %t83, !tbaa !39
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t90 = call i1 @compiler_2fcheck_2ementions(ptr %s0, ptr %v1, ptr %t84, ptr %t87)
  store i1 %t90, ptr %l51
  br label %bb31
bb31:
  %t91 = load i1, ptr %l51, !tbaa !21
  br i1 %t91, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l9, !tbaa !24
  br label %bb27
bb36:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = add i64 %t97, %t98
  store i64 %t101, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb37:
  br label %bb20
bb38:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2enameDistance(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l35 = alloca i1
  %l42 = alloca i64
  %l48 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l89 = alloca i64
  %l92 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l140 = alloca i64
  %l141 = alloca { i64, ptr }
  %l145 = alloca i8
  %l146 = alloca { i64, ptr }
  %l150 = alloca i8
  %l152 = alloca i64
  %l164 = alloca i64
  %l167 = alloca i64
  %l171 = alloca i64
  %l182 = alloca i64
  %l185 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 40
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp sgt i64 %t9, 40
  store i1 %t11, ptr %l35, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l35, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i64 99, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = add i64 %t17, 1
  store i64 %t19, ptr %l42, !tbaa !24
  %t20 = load i64, ptr %l42, !tbaa !24
  %t21 = icmp sge i64 %t20, 0
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l42, !tbaa !24
  %t24 = icmp sle i64 %t23, 1152921504606846975
  br i1 %t24, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d8a95100ae36edf8_e5bb3c27a0d25fcc)
  unreachable
bb9:
  %t26 = load i64, ptr %l42, !tbaa !24
  %t27 = mul i64 %t26, 8
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l2, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l48, !tbaa !24
  %t37 = load i64, ptr %l48, !tbaa !24
  %t38 = icmp sge i64 %t37, 0
  br i1 %t38, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d8a95100ae36edf8_e5bb3c27a0d25fcc)
  unreachable
bb11:
  %t40 = load i64, ptr %l48, !tbaa !24
  %t41 = icmp sle i64 %t40, 1152921504606846975
  br i1 %t41, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_8c57e15532896e65_ffa14d682cac12d9)
  unreachable
bb13:
  %t43 = load i64, ptr %l48, !tbaa !24
  %t44 = mul i64 %t43, 8
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8c57e15532896e65_ffa14d682cac12d9)
  unreachable
bb15:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  br i1 %t63, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb20
bb17:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l4, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sub i64 %t73, 1
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = sdiv i64 %t75, %t76
  store i64 %t79, ptr %l61, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb19
bb19:
  %t81 = load i64, ptr %l61, !tbaa !24
  store i64 %t81, ptr %l58, !tbaa !24
  br label %bb20
bb20:
  %t82 = load i64, ptr %l58, !tbaa !24
  store i64 %t82, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t91 = load i64, ptr %l4, !tbaa !24
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = mul i64 %t92, %t93
  %t99 = add i64 %t91, %t96
  store i64 %t99, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i64, ptr %t106, i64 %t101
  store i64 %t102, ptr %t107, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t108 = load i64, ptr %l8, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l8, !tbaa !24
  br label %bb21
bb26:
  store i64 1, ptr %l10, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t118 = load i64, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb27, label %bb28
bb27:
  %t124 = load i64, ptr %l12, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb32
bb29:
  %t128 = load i64, ptr %l11, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l12, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l92, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb31
bb31:
  %t144 = load i64, ptr %l92, !tbaa !24
  store i64 %t144, ptr %l89, !tbaa !24
  br label %bb32
bb32:
  %t145 = load i64, ptr %l89, !tbaa !24
  store i64 %t145, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t146 = load i64, ptr %l14, !tbaa !24
  %t147 = load i64, ptr %l13, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb73
bb35:
  br label %bb36
bb36:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t155 = load i64, ptr %l14, !tbaa !24
  %t156 = load i64, ptr %l12, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l15, !tbaa !24
  %t164 = load i64, ptr %l15, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i64, ptr %t167, i64 0
  store i64 %t164, ptr %t168, !tbaa !34
  store i64 1, ptr %l16, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t175 = load i64, ptr %l17, !tbaa !24
  %t176 = load i64, ptr %l16, !tbaa !24
  %t179 = icmp sgt i64 %t175, %t176
  br i1 %t179, label %bb37, label %bb38
bb37:
  %t181 = load i64, ptr %l18, !tbaa !24
  %t183 = icmp sgt i64 %t181, 0
  br i1 %t183, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb42
bb39:
  %t185 = load i64, ptr %l17, !tbaa !24
  %t186 = load i64, ptr %l16, !tbaa !24
  %t189 = sub i64 %t185, %t186
  %t190 = load i64, ptr %l18, !tbaa !24
  %t193 = add i64 %t189, %t190
  %t195 = sub i64 %t193, 1
  %t196 = load i64, ptr %l18, !tbaa !24
  %t199 = sdiv i64 %t195, %t196
  store i64 %t199, ptr %l120, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb41
bb41:
  %t201 = load i64, ptr %l120, !tbaa !24
  store i64 %t201, ptr %l117, !tbaa !24
  br label %bb42
bb42:
  %t202 = load i64, ptr %l117, !tbaa !24
  store i64 %t202, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t203 = load i64, ptr %l20, !tbaa !24
  %t204 = load i64, ptr %l19, !tbaa !24
  %t207 = icmp slt i64 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s8)
  br label %bb59
bb45:
  br label %bb46
bb46:
  %t211 = load i64, ptr %l16, !tbaa !24
  %t212 = load i64, ptr %l20, !tbaa !24
  %t213 = load i64, ptr %l18, !tbaa !24
  %t216 = mul i64 %t212, %t213
  %t219 = add i64 %t211, %t216
  store i64 %t219, ptr %l21, !tbaa !24
  %t221 = load i64, ptr %l21, !tbaa !24
  %t223 = sub i64 %t221, 1
  %t225 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i64, ptr %t226, i64 %t223
  %t228 = load i64, ptr %t227, !tbaa !34
  store i64 %t228, ptr %l140, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t229, ptr %l141, !tbaa !27
  %t230 = load i64, ptr %l15, !tbaa !24
  %t232 = sub i64 %t230, 1
  %t234 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i8, ptr %t235, i64 %t232
  %t237 = load i8, ptr %t236, !tbaa !32
  %t239 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t237)
  store i8 %t239, ptr %l145
  br label %bb47
bb47:
  %t240 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t240, ptr %l146, !tbaa !27
  %t241 = load i64, ptr %l21, !tbaa !24
  %t243 = sub i64 %t241, 1
  %t245 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr i8, ptr %t246, i64 %t243
  %t248 = load i8, ptr %t247, !tbaa !32
  %t250 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t248)
  store i8 %t250, ptr %l150
  br label %bb48
bb48:
  %t251 = load i8, ptr %l145, !tbaa !22
  %t252 = load i8, ptr %l150, !tbaa !22
  %t253 = icmp eq i8 %t251, %t252
  br i1 %t253, label %bb49, label %bb50
bb49:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb51
bb50:
  store i64 1, ptr %l152, !tbaa !24
  br label %bb51
bb51:
  %t255 = load i64, ptr %l140, !tbaa !24
  %t256 = load i64, ptr %l152, !tbaa !24
  %t257 = add i64 %t255, %t256
  store i64 %t257, ptr %l22, !tbaa !24
  %t259 = load i64, ptr %l21, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr i64, ptr %t262, i64 %t259
  %t264 = load i64, ptr %t263, !tbaa !34
  %t266 = add i64 %t264, 1
  store i64 %t266, ptr %l23, !tbaa !24
  %t268 = load i64, ptr %l21, !tbaa !24
  %t270 = sub i64 %t268, 1
  %t272 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i64, ptr %t273, i64 %t270
  %t275 = load i64, ptr %t274, !tbaa !34
  %t277 = add i64 %t275, 1
  store i64 %t277, ptr %l24, !tbaa !24
  %t279 = load i64, ptr %l22, !tbaa !24
  %t280 = load i64, ptr %l23, !tbaa !24
  %t283 = icmp slt i64 %t279, %t280
  br i1 %t283, label %bb52, label %bb53
bb52:
  %t285 = load i64, ptr %l22, !tbaa !24
  store i64 %t285, ptr %l164, !tbaa !24
  br label %bb54
bb53:
  %t287 = load i64, ptr %l23, !tbaa !24
  store i64 %t287, ptr %l164, !tbaa !24
  br label %bb54
bb54:
  %t289 = load i64, ptr %l164, !tbaa !24
  store i64 %t289, ptr %l25, !tbaa !24
  %t290 = load i64, ptr %l21, !tbaa !24
  store i64 %t290, ptr %l167, !tbaa !24
  %t291 = load i64, ptr %l25, !tbaa !24
  %t292 = load i64, ptr %l24, !tbaa !24
  %t295 = icmp slt i64 %t291, %t292
  br i1 %t295, label %bb55, label %bb56
bb55:
  %t297 = load i64, ptr %l25, !tbaa !24
  store i64 %t297, ptr %l171, !tbaa !24
  br label %bb57
bb56:
  %t299 = load i64, ptr %l24, !tbaa !24
  store i64 %t299, ptr %l171, !tbaa !24
  br label %bb57
bb57:
  %t301 = load i64, ptr %l171, !tbaa !24
  %t302 = load i64, ptr %l167, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr i64, ptr %t304, i64 %t302
  store i64 %t301, ptr %t305, !tbaa !34
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  %t306 = load i64, ptr %l20, !tbaa !24
  %t308 = add i64 %t306, 1
  store i64 %t308, ptr %l20, !tbaa !24
  br label %bb43
bb59:
  store i64 0, ptr %l26, !tbaa !24
  %t310 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t314 = add i64 %t312, 1
  store i64 %t314, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t316 = load i64, ptr %l27, !tbaa !24
  %t317 = load i64, ptr %l26, !tbaa !24
  %t320 = icmp sgt i64 %t316, %t317
  br i1 %t320, label %bb60, label %bb61
bb60:
  %t322 = load i64, ptr %l28, !tbaa !24
  %t324 = icmp sgt i64 %t322, 0
  br i1 %t324, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l182, !tbaa !24
  br label %bb65
bb62:
  %t326 = load i64, ptr %l27, !tbaa !24
  %t327 = load i64, ptr %l26, !tbaa !24
  %t330 = sub i64 %t326, %t327
  %t331 = load i64, ptr %l28, !tbaa !24
  %t334 = add i64 %t330, %t331
  %t336 = sub i64 %t334, 1
  %t337 = load i64, ptr %l28, !tbaa !24
  %t340 = sdiv i64 %t336, %t337
  store i64 %t340, ptr %l185, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l185, !tbaa !24
  br label %bb64
bb64:
  %t342 = load i64, ptr %l185, !tbaa !24
  store i64 %t342, ptr %l182, !tbaa !24
  br label %bb65
bb65:
  %t343 = load i64, ptr %l182, !tbaa !24
  store i64 %t343, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s11
  %t344 = load i64, ptr %l30, !tbaa !24
  %t345 = load i64, ptr %l29, !tbaa !24
  %t348 = icmp slt i64 %t344, %t345
  %t350 = xor i1 %t348, true
  br i1 %t350, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb71
bb68:
  br label %bb69
bb69:
  %t352 = load i64, ptr %l26, !tbaa !24
  %t353 = load i64, ptr %l30, !tbaa !24
  %t354 = load i64, ptr %l28, !tbaa !24
  %t357 = mul i64 %t353, %t354
  %t360 = add i64 %t352, %t357
  store i64 %t360, ptr %l31, !tbaa !24
  %t362 = load i64, ptr %l31, !tbaa !24
  %t363 = load i64, ptr %l31, !tbaa !24
  %t365 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr i64, ptr %t366, i64 %t363
  %t368 = load i64, ptr %t367, !tbaa !34
  %t371 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr i64, ptr %t372, i64 %t362
  store i64 %t368, ptr %t373, !tbaa !34
  call void @__olang_scope_close(ptr %s11)
  br label %bb70
bb70:
  %t374 = load i64, ptr %l30, !tbaa !24
  %t376 = add i64 %t374, 1
  store i64 %t376, ptr %l30, !tbaa !24
  br label %bb66
bb71:
  call void @__olang_scope_close(ptr %s6)
  br label %bb72
bb72:
  %t378 = load i64, ptr %l14, !tbaa !24
  %t380 = add i64 %t378, 1
  store i64 %t380, ptr %l14, !tbaa !24
  br label %bb33
bb73:
  %t382 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t382, 0
  %t386 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr i64, ptr %t387, i64 %t384
  %t389 = load i64, ptr %t388, !tbaa !34
  call void @__olang_scope_close(ptr %s0)
  store i64 %t389, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2esupplied(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca [15 x { i64, ptr }]
  %l18 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 0
  store { i64, ptr } { i64 4, ptr @.d35 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 1
  store { i64, ptr } { i64 11, ptr @.d36 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 2
  store { i64, ptr } { i64 12, ptr @.d37 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 3
  store { i64, ptr } { i64 11, ptr @.d38 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 4
  store { i64, ptr } { i64 11, ptr @.d39 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 5
  store { i64, ptr } { i64 10, ptr @.d40 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 6
  store { i64, ptr } { i64 11, ptr @.d41 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 7
  store { i64, ptr } { i64 9, ptr @.d42 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 8
  store { i64, ptr } { i64 10, ptr @.d43 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 9
  store { i64, ptr } { i64 17, ptr @.d44 }, ptr %t10, !tbaa !37
  %t11 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 10
  store { i64, ptr } { i64 4, ptr @.d45 }, ptr %t11, !tbaa !37
  %t12 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 11
  store { i64, ptr } { i64 2, ptr @.d46 }, ptr %t12, !tbaa !37
  %t13 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 12
  store { i64, ptr } { i64 3, ptr @.d47 }, ptr %t13, !tbaa !37
  %t14 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 13
  store { i64, ptr } { i64 3, ptr @.d48 }, ptr %t14, !tbaa !37
  %t15 = getelementptr [15 x { i64, ptr }], ptr %l5, i64 0, i64 14
  store { i64, ptr } { i64 4, ptr @.d49 }, ptr %t15, !tbaa !37
  %t16 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 240, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %l5, i64 240, i1 false)
  store ptr %t16, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t18 = load ptr, ptr %l1
  store i64 15, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l1
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = getelementptr [15 x { i64, ptr }], ptr %t29, i64 0, i64 %t30
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !37
  %t38 = load ptr, ptr @__olang_prog_scope
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t38, ptr %v0, { i64, ptr } %t34, { i64, ptr } %a0)
  store i1 %t41, ptr %l18
  br label %bb5
bb5:
  %t42 = load i1, ptr %l18, !tbaa !21
  br i1 %t42, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2eunpromoted(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_3aChecker_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca i1
  %l11 = alloca { i64, [3 x i64] }
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca i32
  %l24 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca i1
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca i32
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca { i64, ptr }
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca i64
  %l54 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l64 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l68 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l70 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i64
  %l74 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l80 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca %"compiler/source:Span"
  %l96 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l100 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l102 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l103 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l104 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l105 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l106 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l107 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l109 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l110 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l112 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l114 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l115 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l118 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l119 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l120 = alloca %"compiler/source:Span"
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca %"compiler/source:Span"
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca %"compiler/source:Span"
  %l125 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l126 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l127 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l128 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l129 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l130 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l131 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l132 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l133 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l134 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l135 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l136 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l137 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l138 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l139 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l140 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l141 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l142 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l143 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l144 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l145 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l146 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l147 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l148 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l149 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l150 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l151 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l152 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l153 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l154 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l155 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l156 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l157 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l158 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l159 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l160 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l161 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l162 = alloca %"compiler/check:Checker"
  %t3 = alloca { i64, [5 x i64] }, align 8
  %t22 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 0, i32 0)
  store %"compiler/source:Span" %t1, ptr %l90
  br label %bb1
bb1:
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [5 x i64] }, ptr %t3, i32 0, i32 0
  store i64 0, ptr %t4
  %t5 = load %"compiler/source:Span", ptr %l90
  %t6 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t5, 0
  %t8 = insertvalue { %"compiler/source:Span", i32, i64 } %t6, i32 %t2, 1
  %t9 = insertvalue { %"compiler/source:Span", i32, i64 } %t8, i64 0, 2
  %t10 = getelementptr { i64, [5 x i64] }, ptr %t3, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t9, ptr %t10
  %t11 = load { i64, [5 x i64] }, ptr %t3
  %t13 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t11, ptr %t13
  store ptr %t13, ptr %l2, !tbaa !29
  store ptr %a0, ptr %l3, !tbaa !29
  store i1 %a1, ptr %l4, !tbaa !21
  store i1 false, ptr %l5, !tbaa !21
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l7, !tbaa !21
  store i1 false, ptr %l8, !tbaa !21
  %t19 = load ptr, ptr @__olang_prog_scope
  %t20 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e(ptr %t19)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l96
  br label %bb2
bb2:
  %t21 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l9
  store i1 false, ptr %l10, !tbaa !21
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [3 x i64] }, ptr %t22
  store { i64, [3 x i64] } %t24, ptr %l11
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %t26)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l98
  br label %bb3
bb3:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l12
  %t29 = load ptr, ptr @__olang_prog_scope
  %t30 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e(ptr %t29)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l99
  br label %bb4
bb4:
  %t31 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l99
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l13
  %t32 = load ptr, ptr @__olang_prog_scope
  %t33 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3e(ptr %t32)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l100
  br label %bb5
bb5:
  %t34 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l14
  %t35 = load ptr, ptr @__olang_prog_scope
  %t36 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t35)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l101
  br label %bb6
bb6:
  %t37 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l101
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l15
  store i64 0, ptr %l16, !tbaa !24
  %t38 = load ptr, ptr @__olang_prog_scope
  %t39 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t38)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l102
  br label %bb7
bb7:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l102
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l17
  %t41 = load ptr, ptr @__olang_prog_scope
  %t42 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t41)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l103
  br label %bb8
bb8:
  %t43 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l103
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l18
  %t44 = load ptr, ptr @__olang_prog_scope
  %t45 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t44)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l104
  br label %bb9
bb9:
  %t46 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l19
  %t47 = load ptr, ptr @__olang_prog_scope
  %t48 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t47)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %l105
  br label %bb10
bb10:
  %t49 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l105
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l20
  %t50 = load ptr, ptr @__olang_prog_scope
  %t51 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %t50)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %l106
  br label %bb11
bb11:
  %t52 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l106
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l21
  %t53 = load ptr, ptr @__olang_prog_scope
  %t54 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t53)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l107
  br label %bb12
bb12:
  %t55 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l107
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l22
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t56, ptr %l23, !tbaa !23
  %t58 = load ptr, ptr @__olang_prog_scope
  %t59 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %t58)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l109
  br label %bb13
bb13:
  %t60 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l24
  %t61 = load ptr, ptr @__olang_prog_scope
  %t62 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Haba80d1d3a2c3182604ba8ef925d2ec6(ptr %t61)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l110
  br label %bb14
bb14:
  %t63 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %l25
  %t64 = load ptr, ptr @__olang_prog_scope
  %t65 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %t64)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l111
  br label %bb15
bb15:
  %t66 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %l26
  %t67 = load ptr, ptr @__olang_prog_scope
  %t68 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t67)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l112
  br label %bb16
bb16:
  %t69 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l112
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %l27
  %t70 = load ptr, ptr @__olang_prog_scope
  %t71 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t70)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l113
  br label %bb17
bb17:
  %t72 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l113
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %l28
  %t73 = load ptr, ptr @__olang_prog_scope
  %t74 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H01b6fb75b9cc96416bdc55b4e10a9a4d(ptr %t73)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %l114
  br label %bb18
bb18:
  %t75 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l114
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l29
  %t76 = load ptr, ptr @__olang_prog_scope
  %t77 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t76)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l115
  br label %bb19
bb19:
  %t78 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l115
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %l30
  %t79 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 -1, i32 -1)
  store %"compiler/source:Span" %t79, ptr %l116
  br label %bb20
bb20:
  %t80 = load %"compiler/source:Span", ptr %l116
  store %"compiler/source:Span" %t80, ptr %l31
  store i1 false, ptr %l32, !tbaa !21
  %t81 = load ptr, ptr @__olang_prog_scope
  %t82 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e(ptr %t81)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l117
  br label %bb21
bb21:
  %t83 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l117
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %l33
  %t84 = load ptr, ptr @__olang_prog_scope
  %t85 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e(ptr %t84)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l118
  br label %bb22
bb22:
  %t86 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l118
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %l34
  %t87 = load ptr, ptr @__olang_prog_scope
  %t88 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e(ptr %t87)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %l119
  br label %bb23
bb23:
  %t89 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l119
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t89, ptr %l35
  store i32 0, ptr %l36, !tbaa !23
  store i1 false, ptr %l37, !tbaa !21
  store i1 false, ptr %l38, !tbaa !21
  %t90 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 -1, i32 -1)
  store %"compiler/source:Span" %t90, ptr %l120
  br label %bb24
bb24:
  %t91 = load %"compiler/source:Span", ptr %l120
  store %"compiler/source:Span" %t91, ptr %l39
  %t92 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 -1, i32 -1)
  store %"compiler/source:Span" %t92, ptr %l121
  br label %bb25
bb25:
  %t93 = load %"compiler/source:Span", ptr %l121
  store %"compiler/source:Span" %t93, ptr %l40
  %t94 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 -1, i32 -1)
  store %"compiler/source:Span" %t94, ptr %l122
  br label %bb26
bb26:
  %t95 = load %"compiler/source:Span", ptr %l122
  store %"compiler/source:Span" %t95, ptr %l41
  %t96 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 -1, i32 -1)
  store %"compiler/source:Span" %t96, ptr %l123
  br label %bb27
bb27:
  %t97 = load %"compiler/source:Span", ptr %l123
  store %"compiler/source:Span" %t97, ptr %l42
  %t98 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 -1, i32 -1)
  store %"compiler/source:Span" %t98, ptr %l124
  br label %bb28
bb28:
  %t99 = load %"compiler/source:Span", ptr %l124
  store %"compiler/source:Span" %t99, ptr %l43
  store { i64, ptr } { i64 0, ptr @.d50 }, ptr %l44, !tbaa !27
  store i32 -1, ptr %l45, !tbaa !23
  store i32 -1, ptr %l46, !tbaa !23
  %t100 = load ptr, ptr @__olang_prog_scope
  %t101 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t100)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t101, ptr %l125
  br label %bb29
bb29:
  %t102 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l125
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %l47
  %t103 = load ptr, ptr @__olang_prog_scope
  %t104 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e(ptr %t103)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %l126
  br label %bb30
bb30:
  %t105 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l126
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l48
  %t106 = load ptr, ptr @__olang_prog_scope
  %t107 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %t106)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t107, ptr %l127
  br label %bb31
bb31:
  %t108 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l127
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %l49
  %t109 = load ptr, ptr @__olang_prog_scope
  %t110 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t109)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %l128
  br label %bb32
bb32:
  %t111 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l128
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %l50
  %t112 = load ptr, ptr @__olang_prog_scope
  %t113 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Hd821be330ef79c8e3a128d6d66efcc0a(ptr %t112)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t113, ptr %l129
  br label %bb33
bb33:
  %t114 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l129
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %l51
  %t115 = load ptr, ptr @__olang_prog_scope
  %t116 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Hd821be330ef79c8e3a128d6d66efcc0a(ptr %t115)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %l130
  br label %bb34
bb34:
  %t117 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l130
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t117, ptr %l52
  store i64 0, ptr %l53, !tbaa !24
  %t118 = load ptr, ptr @__olang_prog_scope
  %t119 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %t118)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t119, ptr %l131
  br label %bb35
bb35:
  %t120 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l131
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %l54
  %t121 = load ptr, ptr @__olang_prog_scope
  %t122 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H4c2d249ebf0ad76bb83d84436fcd6170(ptr %t121)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %l132
  br label %bb36
bb36:
  %t123 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l132
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t123, ptr %l55
  %t124 = load ptr, ptr @__olang_prog_scope
  %t125 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t124)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %l133
  br label %bb37
bb37:
  %t126 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l133
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t126, ptr %l56
  %t127 = load ptr, ptr @__olang_prog_scope
  %t128 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Ha43d098792f3cecbb26332ac737832fd(ptr %t127)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %l134
  br label %bb38
bb38:
  %t129 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l134
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t129, ptr %l57
  %t130 = load ptr, ptr @__olang_prog_scope
  %t131 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t130)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %l135
  br label %bb39
bb39:
  %t132 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l135
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %l58
  %t133 = load ptr, ptr @__olang_prog_scope
  %t134 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_Hac25a7ed8ad1358e165a391475d387fa(ptr %t133)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %l136
  br label %bb40
bb40:
  %t135 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l136
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t135, ptr %l59
  %t136 = load ptr, ptr @__olang_prog_scope
  %t137 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e(ptr %t136)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t137, ptr %l137
  br label %bb41
bb41:
  %t138 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l137
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %l60
  %t139 = load ptr, ptr @__olang_prog_scope
  %t140 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e(ptr %t139)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t140, ptr %l138
  br label %bb42
bb42:
  %t141 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l138
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t141, ptr %l61
  %t142 = load ptr, ptr @__olang_prog_scope
  %t143 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Hcab02cb43e6503e3666091e1e87383fc(ptr %t142)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, ptr %l139
  br label %bb43
bb43:
  %t144 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l139
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %l62
  %t145 = load ptr, ptr @__olang_prog_scope
  %t146 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t145)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t146, ptr %l140
  br label %bb44
bb44:
  %t147 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l140
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t147, ptr %l63
  %t148 = load ptr, ptr @__olang_prog_scope
  %t149 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e(ptr %t148)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t149, ptr %l141
  br label %bb45
bb45:
  %t150 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l141
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t150, ptr %l64
  %t151 = load ptr, ptr @__olang_prog_scope
  %t152 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e(ptr %t151)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %l142
  br label %bb46
bb46:
  %t153 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l142
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t153, ptr %l65
  %t154 = load ptr, ptr @__olang_prog_scope
  %t155 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroDeepArg_3e(ptr %t154)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t155, ptr %l143
  br label %bb47
bb47:
  %t156 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l143
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t156, ptr %l66
  %t157 = load ptr, ptr @__olang_prog_scope
  %t158 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e(ptr %t157)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, ptr %l144
  br label %bb48
bb48:
  %t159 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l144
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t159, ptr %l67
  %t160 = load ptr, ptr @__olang_prog_scope
  %t161 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t160)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t161, ptr %l145
  br label %bb49
bb49:
  %t162 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l145
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t162, ptr %l68
  %t163 = load ptr, ptr @__olang_prog_scope
  %t164 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t163)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %l146
  br label %bb50
bb50:
  %t165 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l146
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t165, ptr %l69
  %t166 = load ptr, ptr @__olang_prog_scope
  %t167 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t166)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t167, ptr %l147
  br label %bb51
bb51:
  %t168 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l147
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t168, ptr %l70
  store i1 false, ptr %l71, !tbaa !21
  store i1 false, ptr %l72, !tbaa !21
  store i64 -1, ptr %l73, !tbaa !24
  %t169 = load ptr, ptr @__olang_prog_scope
  %t170 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t169)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, ptr %l148
  br label %bb52
bb52:
  %t171 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l148
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t171, ptr %l74
  %t172 = load ptr, ptr @__olang_prog_scope
  %t173 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e(ptr %t172)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t173, ptr %l149
  br label %bb53
bb53:
  %t174 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l149
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t174, ptr %l75
  %t175 = load ptr, ptr @__olang_prog_scope
  %t176 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e(ptr %t175)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t176, ptr %l150
  br label %bb54
bb54:
  %t177 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l150
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t177, ptr %l76
  %t178 = load ptr, ptr @__olang_prog_scope
  %t179 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e(ptr %t178)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t179, ptr %l151
  br label %bb55
bb55:
  %t180 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l151
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %l77
  %t181 = load ptr, ptr @__olang_prog_scope
  %t182 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e(ptr %t181)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %l152
  br label %bb56
bb56:
  %t183 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l152
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l78
  %t184 = load ptr, ptr @__olang_prog_scope
  %t185 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t184)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t185, ptr %l153
  br label %bb57
bb57:
  %t186 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l153
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t186, ptr %l79
  %t187 = load ptr, ptr @__olang_prog_scope
  %t188 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e(ptr %t187)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t188, ptr %l154
  br label %bb58
bb58:
  %t189 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l154
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t189, ptr %l80
  %t190 = load ptr, ptr @__olang_prog_scope
  %t191 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t190)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t191, ptr %l155
  br label %bb59
bb59:
  %t192 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l155
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t192, ptr %l81
  store i1 false, ptr %l82, !tbaa !21
  store i1 false, ptr %l83, !tbaa !21
  %t193 = load ptr, ptr @__olang_prog_scope
  %t194 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t193)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t194, ptr %l156
  br label %bb60
bb60:
  %t195 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l156
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t195, ptr %l84
  %t196 = load ptr, ptr @__olang_prog_scope
  %t197 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H8627060ea6c43ea0f06e6708e5db09a4(ptr %t196)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t197, ptr %l157
  br label %bb61
bb61:
  %t198 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l157
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t198, ptr %l85
  %t199 = load ptr, ptr @__olang_prog_scope
  %t200 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t199)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t200, ptr %l158
  br label %bb62
bb62:
  %t201 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l158
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t201, ptr %l86
  %t202 = load ptr, ptr @__olang_prog_scope
  %t203 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t202)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t203, ptr %l159
  br label %bb63
bb63:
  %t204 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l159
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t204, ptr %l87
  %t205 = load ptr, ptr @__olang_prog_scope
  %t206 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t205)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %l160
  br label %bb64
bb64:
  %t207 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l160
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t207, ptr %l88
  %t208 = load ptr, ptr @__olang_prog_scope
  %t209 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t208)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t209, ptr %l161
  br label %bb65
bb65:
  %t210 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l161
  %t211 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 0
  %t212 = load ptr, ptr %l2, !tbaa !29
  store ptr %t212, ptr %t211, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 1
  %t214 = load ptr, ptr %l3, !tbaa !29
  store ptr %t214, ptr %t213, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 2
  %t216 = load i1, ptr %l4, !tbaa !21
  store i1 %t216, ptr %t215, !tbaa !21
  %t217 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 3
  %t218 = load i1, ptr %l5, !tbaa !21
  store i1 %t218, ptr %t217, !tbaa !21
  %t219 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 4
  %t220 = load i1, ptr %l6, !tbaa !21
  store i1 %t220, ptr %t219, !tbaa !21
  %t221 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 5
  %t222 = load i1, ptr %l7, !tbaa !21
  store i1 %t222, ptr %t221, !tbaa !21
  %t223 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 6
  %t224 = load i1, ptr %l8, !tbaa !21
  store i1 %t224, ptr %t223, !tbaa !21
  %t225 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 7
  %t226 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t226, ptr %t225
  %t227 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 8
  %t228 = load i1, ptr %l10, !tbaa !21
  store i1 %t228, ptr %t227, !tbaa !21
  %t229 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 9
  %t230 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t230, ptr %t229
  %t231 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 10
  %t232 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t232, ptr %t231
  %t233 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 11
  %t234 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %t233
  %t235 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 12
  %t236 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t236, ptr %t235
  %t237 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 13
  %t238 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %t237
  %t239 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 14
  %t240 = load i64, ptr %l16, !tbaa !24
  store i64 %t240, ptr %t239, !tbaa !24
  %t241 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 15
  %t242 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t242, ptr %t241
  %t243 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 16
  %t244 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t244, ptr %t243
  %t245 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 17
  %t246 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t246, ptr %t245
  %t247 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 18
  %t248 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t248, ptr %t247
  %t249 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 19
  %t250 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t250, ptr %t249
  %t251 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 20
  %t252 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t252, ptr %t251
  %t253 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 21
  %t254 = load i32, ptr %l23, !tbaa !23
  store i32 %t254, ptr %t253, !tbaa !23
  %t255 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 22
  %t256 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t256, ptr %t255
  %t257 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 23
  %t258 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t258, ptr %t257
  %t259 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 24
  %t260 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t260, ptr %t259
  %t261 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 25
  %t262 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t262, ptr %t261
  %t263 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 26
  %t264 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t264, ptr %t263
  %t265 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 27
  %t266 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t266, ptr %t265
  %t267 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 28
  %t268 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t268, ptr %t267
  %t269 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 29
  %t270 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t270, ptr %t269
  %t271 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 30
  %t272 = load i1, ptr %l32, !tbaa !21
  store i1 %t272, ptr %t271, !tbaa !21
  %t273 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 31
  %t274 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t274, ptr %t273
  %t275 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 32
  %t276 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t276, ptr %t275
  %t277 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 33
  %t278 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t278, ptr %t277
  %t279 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 34
  %t280 = load i32, ptr %l36, !tbaa !23
  store i32 %t280, ptr %t279, !tbaa !23
  %t281 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 35
  %t282 = load i1, ptr %l37, !tbaa !21
  store i1 %t282, ptr %t281, !tbaa !21
  %t283 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 36
  %t284 = load i1, ptr %l38, !tbaa !21
  store i1 %t284, ptr %t283, !tbaa !21
  %t285 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 37
  %t286 = load %"compiler/source:Span", ptr %l39
  store %"compiler/source:Span" %t286, ptr %t285
  %t287 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 38
  %t288 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t288, ptr %t287
  %t289 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 39
  %t290 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t290, ptr %t289
  %t291 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 40
  %t292 = load %"compiler/source:Span", ptr %l42
  store %"compiler/source:Span" %t292, ptr %t291
  %t293 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 41
  %t294 = load %"compiler/source:Span", ptr %l43
  store %"compiler/source:Span" %t294, ptr %t293
  %t295 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 42
  %t296 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t296, ptr %t295, !tbaa !27
  %t297 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 43
  %t298 = load i32, ptr %l45, !tbaa !23
  store i32 %t298, ptr %t297, !tbaa !23
  %t299 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 44
  %t300 = load i32, ptr %l46, !tbaa !23
  store i32 %t300, ptr %t299, !tbaa !23
  %t301 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 45
  %t302 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t302, ptr %t301
  %t303 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 46
  %t304 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t304, ptr %t303
  %t305 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 47
  %t306 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t306, ptr %t305
  %t307 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 48
  %t308 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t308, ptr %t307
  %t309 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 49
  %t310 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t310, ptr %t309
  %t311 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 50
  %t312 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t312, ptr %t311
  %t313 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 51
  %t314 = load i64, ptr %l53, !tbaa !24
  store i64 %t314, ptr %t313, !tbaa !24
  %t315 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 52
  %t316 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t316, ptr %t315
  %t317 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 53
  %t318 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t318, ptr %t317
  %t319 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 54
  %t320 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t320, ptr %t319
  %t321 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 55
  %t322 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t322, ptr %t321
  %t323 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 56
  %t324 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t324, ptr %t323
  %t325 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 57
  %t326 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t326, ptr %t325
  %t327 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 58
  %t328 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t328, ptr %t327
  %t329 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 59
  %t330 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t330, ptr %t329
  %t331 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 60
  %t332 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t332, ptr %t331
  %t333 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 61
  %t334 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t334, ptr %t333
  %t335 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 62
  %t336 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t336, ptr %t335
  %t337 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 63
  %t338 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t338, ptr %t337
  %t339 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 64
  %t340 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t340, ptr %t339
  %t341 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 65
  %t342 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l67
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t342, ptr %t341
  %t343 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 66
  %t344 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t344, ptr %t343
  %t345 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 67
  %t346 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l69
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t346, ptr %t345
  %t347 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 68
  %t348 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t348, ptr %t347
  %t349 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 69
  %t350 = load i1, ptr %l71, !tbaa !21
  store i1 %t350, ptr %t349, !tbaa !21
  %t351 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 70
  %t352 = load i1, ptr %l72, !tbaa !21
  store i1 %t352, ptr %t351, !tbaa !21
  %t353 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 71
  %t354 = load i64, ptr %l73, !tbaa !24
  store i64 %t354, ptr %t353, !tbaa !24
  %t355 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 72
  %t356 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t356, ptr %t355
  %t357 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 73
  %t358 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l75
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t358, ptr %t357
  %t359 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 74
  %t360 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t360, ptr %t359
  %t361 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 75
  %t362 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l77
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t362, ptr %t361
  %t363 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 76
  %t364 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t364, ptr %t363
  %t365 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 77
  %t366 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t366, ptr %t365
  %t367 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 78
  %t368 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t368, ptr %t367
  %t369 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 79
  %t370 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t370, ptr %t369
  %t371 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 80
  %t372 = load i1, ptr %l82, !tbaa !21
  store i1 %t372, ptr %t371, !tbaa !21
  %t373 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 81
  %t374 = load i1, ptr %l83, !tbaa !21
  store i1 %t374, ptr %t373, !tbaa !21
  %t375 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 82
  %t376 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t376, ptr %t375
  %t377 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 83
  %t378 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t378, ptr %t377
  %t379 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 84
  %t380 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t380, ptr %t379
  %t381 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 85
  %t382 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t382, ptr %t381
  %t383 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 86
  %t384 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t384, ptr %t383
  %t385 = getelementptr %"compiler/check:Checker", ptr %l162, i32 0, i32 87
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t210, ptr %t385
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l162, i64 664, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2) #0 {
entry:
  %rv = alloca %"compiler/check:nullNarrow"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:nullNarrow" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/check:nullNarrow" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/check:nullNarrow" %t10, i1 %a2, 2
  store %"compiler/check:nullNarrow" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:nullNarrow", ptr %rv
  ret %"compiler/check:nullNarrow" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
@.d0 = private constant [4 x i8] c"Bits"
@.d1 = private constant [8 x i8] c"FromBits"
@.d2 = private constant [6 x i8] c"Atomic"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d3 = private constant [4 x i8] c"Call"
@.d4 = private constant [4 x i8] c"call"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d5 = private constant [4 x i8] c"Call"
@.d6 = private constant [1 x i8] c"_"
@.d7 = private constant [0 x i8] c""
@.d8 = private constant [1 x i8] c"s"
@.d9 = private constant [7 x i8] c"Checked"
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d10 = private constant [58 x i8] c"the checker asked for the body of a frame that checks none"
declare void @__olang_check_failed_text(ptr, { i64, ptr })
@.d11 = private constant [7 x i8] c"default"
@.d12 = private constant [20 x i8] c"an else of this kind"
@.d13 = private constant [1 x i8] c"_"
@.d14 = private constant [0 x i8] c""
@.d15 = private constant [1 x i8] c"s"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d16 = private constant [31 x i8] c"a member of a type of this kind"
@.d17 = private constant [32 x i8] c"a field the checker cannot place"
@.d18 = private constant [35 x i8] c"an extern function as a value (T21)"
@.d19 = private constant [1 x i8] c"'"
@.d20 = private constant [1 x i8] c"'"
@.d21 = private constant [1 x i8] c"_"
@.d22 = private constant [0 x i8] c""
@.d23 = private constant [3 x i8] c"I64"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d24 = private constant [17 x i8] c"instantiated here"
@.d25 = private constant [7 x i8] c", with "
@.d26 = private constant [2 x i8] c", "
@.d27 = private constant [3 x i8] c" = "
@.d28 = private constant [9 x i8] c"Exhausted"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d29 = private constant [7 x i8] c"Checked"
@.d30 = private constant [2 x i8] c", "
@.d31 = private constant [3 x i8] c" ? "
@.d32 = private constant [2 x i8] c", "
@.d33 = private constant [2 x i8] c", "
@.d34 = private constant [1 x i8] c"."
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d35 = private constant [4 x i8] c"Bits"
@.d36 = private constant [11 x i8] c"F16FromBits"
@.d37 = private constant [12 x i8] c"BF16FromBits"
@.d38 = private constant [11 x i8] c"F32FromBits"
@.d39 = private constant [11 x i8] c"F64FromBits"
@.d40 = private constant [10 x i8] c"AtomicLoad"
@.d41 = private constant [11 x i8] c"AtomicStore"
@.d42 = private constant [9 x i8] c"AtomicAdd"
@.d43 = private constant [10 x i8] c"AtomicSwap"
@.d44 = private constant [17 x i8] c"AtomicCompareSwap"
@.d45 = private constant [4 x i8] c"Hash"
@.d46 = private constant [2 x i8] c"Eq"
@.d47 = private constant [3 x i8] c"Str"
@.d48 = private constant [3 x i8] c"Len"
@.d49 = private constant [4 x i8] c"Iter"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Haba80d1d3a2c3182604ba8ef925d2ec6(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H01b6fb75b9cc96416bdc55b4e10a9a4d(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d50 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Hd821be330ef79c8e3a128d6d66efcc0a(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H4c2d249ebf0ad76bb83d84436fcd6170(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Ha43d098792f3cecbb26332ac737832fd(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_Hac25a7ed8ad1358e165a391475d387fa(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H94cbbacdefacbf11591e45fa927fb1cb(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Hcab02cb43e6503e3666091e1e87383fc(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2flis_H596e3d714cead58c6bb1a410db388b73(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroDeepArg_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroDeepArg_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H8627060ea6c43ea0f06e6708e5db09a4(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6d92d89bf6179935_a746df8e6ee4ce11 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6eddca2d598ce6fb_9d8bffc2796cf667 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_f64a0f855cc2648c_4038adf1240cd248 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_c23231398495940d_3184fca2d3133de9 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
@olang_loc_dec816aeadd109e0_adcbe0bcced90c1c = external constant [0 x i8]
@olang_loc_98ffdf46f6e43303_7907d8ed59f5817f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
@olang_loc_4b3a1421aaa5396_3ffde41a88bcce4a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotCallable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_27c62905650ee804_ddef4b1ccc198ce0 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeInstNote(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorChecked(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4, i1 %a5)
@olang_loc_4aef7e9433005aa6_9cd0eb13e1392442 = external constant [0 x i8]
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5)
declare %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
@olang_loc_89a248f11218248d_cad7b116269b1029 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorContext(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_43d20343d6f566de_136f8b7be912828a = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@olang_loc_823a266be2210958_13324b84b1c75d64 = external constant [0 x i8]
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_40b38b3f39a757f8_637d931d9ca8f3a4 = external constant [0 x i8]
declare %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71 = external constant [0 x i8]
@olang_loc_c902484ee6860410_648a649019eab164 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e4324c4b30f6563f_ec149b7f01d5683b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_12a7e56ab193c888_f3ea9b5a769b449c = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2eopShapeOf(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnErrors(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i32 %a5, i32 %a6)
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
@olang_loc_78dfa72e33b60bd8_3b4814a7819e5504 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e8223b07530edea9_6c94d0d58286c0f5 = external constant [0 x i8]
@olang_loc_ad1cdf552c08c341_1b6bb8f4178aae4d = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %a0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
@olang_loc_a6850fee211a02d4_462adb773114c70 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCheckedNotSuperset(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMemberIsPrivate(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLengthsNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebound(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnNameAt(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnTooDeep(ptr %v0, ptr %a0, i64 %a1, i32 %a2, { i64, [3 x i64] } %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %a0)
declare %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roFn" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2enoLit()
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %a0, i64 %a1, i1 %a2, i64 %a3)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, ptr %a6)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %v0)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotInferable(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_2ector(ptr %v0, %"compiler/generic:Origin" %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgene_Hab8c1f447f20692126e9ac95b8c4eed1(ptr %v0, ptr %a0, %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgene_H5c18f35d323c054291b84f82e2e04ce4(ptr %v0, ptr %a0)
declare %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgene_Ha7edd413db41d676beea2becd98544e8(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1010397456489e66_cacc16b72eedbd12 = external constant [0 x i8]
@olang_loc_fb9d93c6082892c7_80b52fbeeb5e713 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullToArray(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullToNonNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_baa1666d9ed0001e_5936281468ac2d52 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrow(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i32, %"compiler/check:fixedInit" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6f2dcaa3b3ff2363ea7964270c7a6b31(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
@olang_loc_cabdf486839d2fe5_195cd685fa5544d9 = external constant [0 x i8]
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %a0)
@olang_loc_8ba315a61b976e68_980c0dda48bb0a1c = external constant [0 x i8]
@olang_loc_36514fdaa766da45_2324f4da794b0789 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ePus_H9afb0399fee55ed1ef4b4d03ad72cb66(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettle(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H89a3697e96ae7f34894afc674ffcde65(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:SiteInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eAt_Hc70ee24fb8cd4f4ed4bbdcaa906642ed(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H94cbbacdefacbf11591e45fa927fb1cb(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2flis_H596e3d714cead58c6bb1a410db388b73(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroDeepArg_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compil_H33d643ee420c12f578033f46e688097e(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %a0)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i32, %"compiler/check:roOrigin" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hfc56ff01c357e6bb827daf7012f18a86(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare ptr @compiler_2fcheck_2eunwrapped(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2escopeVarOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/check:ctSource" %a3, i32 %a4, %"compiler/source:Span" %a5)
declare %"compiler/typed:ScopeRel" @compiler_2ftyped_3aScopeRel_2ector(ptr %v0, i64 %a0, i64 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeRel_3e_2ePu_H3d39058be51439e1c4066e8dcab52826(ptr %v0, ptr %a0, %"compiler/typed:ScopeRel" %a1)
@olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_94831dcf6c50df99_e0fe015107062615 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2echildren(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eRunFrom_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7c3afe8c472f60a6_aa2fd777f924487a = external constant [0 x i8]
@olang_loc_d8a95100ae36edf8_e5bb3c27a0d25fcc = external constant [0 x i8]
@olang_loc_8c57e15532896e65_ffa14d682cac12d9 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
