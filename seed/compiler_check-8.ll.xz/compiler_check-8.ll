; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i64, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:fieldSet" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i32, i1, i1 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:laneVals" = type { i64, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32, i32 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:ownerAt" = type { i32, i1 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/check:roArg" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.b139c4f75a6545712256427180a82a06" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" }
%"compiler/check:roDeepArg" = type { i64, ptr, i64, i64 }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/names:Unread" = type { i64, %"compiler/source:Span", i32, i1 }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/check:weakPlace" = type { { i64, [3 x i64] }, { i64, ptr }, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:signMag" = type { i1, i128 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i64, i1, i64 }
%"compiler/check:seqOf" = type { i32, i64, i64, i64 }
define dso_local i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l56 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb50
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l18
  br label %bb12
bb12:
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %l6, !tbaa !21
  br label %bb50
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t44)
  store i1 %t46, ptr %l26
  br label %bb19
bb19:
  %t47 = load i1, ptr %l26, !tbaa !21
  store i1 %t47, ptr %l6, !tbaa !21
  br label %bb50
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb21, label %bb22
bb21:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 8}
  %t55 = icmp eq i64 %t53, 4
  store i1 %t55, ptr %l28, !tbaa !21
  br label %bb22
bb22:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb23, label %bb24
bb23:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Elem", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t66)
  store i1 %t68, ptr %l35
  br label %bb26
bb26:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb27, label %bb28
bb27:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Elem", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t73)
  store i1 %t75, ptr %l39
  br label %bb29
bb28:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb30
bb29:
  %t76 = load i1, ptr %l39, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb30
bb30:
  %t77 = load i1, ptr %l36, !tbaa !21
  store i1 %t77, ptr %l6, !tbaa !21
  br label %bb50
bb31:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb32, label %bb33
bb32:
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb33
bb33:
  %t86 = load i1, ptr %l41, !tbaa !21
  br i1 %t86, label %bb34, label %bb35
bb34:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Payload", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t96)
  store i1 %t98, ptr %l48
  br label %bb37
bb37:
  %t99 = load i1, ptr %l48, !tbaa !21
  store i1 %t99, ptr %l6, !tbaa !21
  br label %bb50
bb38:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb39, label %bb40
bb39:
  %t104 = load ptr, ptr %l49, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 8}
  %t107 = icmp eq i64 %t105, 6
  store i1 %t107, ptr %l50, !tbaa !21
  br label %bb40
bb40:
  %t108 = load i1, ptr %l50, !tbaa !21
  br i1 %t108, label %bb41, label %bb42
bb41:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t111, i32 0, i32 2
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t115)
  store i1 %t117, ptr %l56
  br label %bb44
bb44:
  %t118 = load i1, ptr %l56, !tbaa !21
  store i1 %t118, ptr %l6, !tbaa !21
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_3ee32a1caa2e355c_4063d0a06727bdc8)
  unreachable
bb50:
  %t119 = load i1, ptr %l6, !tbaa !21
  store i1 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca { i64, [2 x i64] }
  %l30 = alloca i32
  %l33 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %l46 = alloca %"compiler/generic:Context"
  %l48 = alloca %"compiler/generic:Context"
  %l51 = alloca ptr
  %l54 = alloca i32
  %l57 = alloca i64
  %l61 = alloca i32
  %l68 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l72 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l78 = alloca i32
  %l81 = alloca i1
  %l86 = alloca i32
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l95 = alloca i32
  %l101 = alloca ptr
  %l105 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca i32
  %l114 = alloca { i64, ptr }
  %l118 = alloca i32
  %l119 = alloca %"compiler/typed:Text"
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l132 = alloca %"compiler/typed:Block"
  %l140 = alloca i64
  %l148 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t24 = alloca { i64, [2 x i64] }, align 8
  %t74 = alloca %"compiler/generic:Context", align 8
  %t211 = alloca { i64, [4 x i64] }, align 8
  %t289 = alloca { i64, [5 x i64] }, align 8
  %t301 = alloca { i64, [2 x i64] }, align 8
  %t311 = alloca { i64, [2 x i64] }, align 8
  %t341 = alloca { i64, [5 x i64] }, align 8
  %t353 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l19
  br label %bb1
bb1:
  %t15 = load i64, ptr %l19, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t16)
  store i32 %t18, ptr %l21
  br label %bb2
bb2:
  %t19 = load i32, ptr %l21, !tbaa !23
  store i32 %t19, ptr %l6, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l22, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 0
  store i64 7, ptr %t25
  %t27 = insertvalue { i64, i32 } undef, i64 %t21, 0
  %t29 = insertvalue { i64, i32 } %t27, i32 %t23, 1
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 1
  store { i64, i32 } %t29, ptr %t30
  %t31 = load { i64, [2 x i64] }, ptr %t24
  store { i64, [2 x i64] } %t31, ptr %l25
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t37, i32 0, i32 %t38, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t41, ptr %l30
  br label %bb3
bb3:
  %t42 = load i64, ptr %l1, !tbaa !24
  %t43 = load %"compiler/source:Span", ptr %l3
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load { i64, [2 x i64] }, ptr %l25
  %t46 = load i32, ptr %l30, !tbaa !23
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t44, { i64, [2 x i64] } %t45, i32 %t46, i64 %t42, %"compiler/source:Span" %t43)
  store i64 %t49, ptr %l33
  br label %bb4
bb4:
  %t50 = load i64, ptr %l33, !tbaa !24
  store i64 %t50, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 23
  %t54 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t53, i64 %t54, i64 1)
  br label %bb5
bb5:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = load i32, ptr %l6, !tbaa !23
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t57, i64 %t58, i64 %t59, i32 %t60, i32 0)
  store ptr %t65, ptr %l41
  br label %bb6
bb6:
  %t66 = load ptr, ptr %l41, !tbaa !29
  store ptr %t66, ptr %l42, !tbaa !29
  %t68 = ptrtoint ptr %v0 to i64
  store i64 %t68, ptr %l43, !tbaa !24
  %t69 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t69, label %bb7, label %bb8
bb7:
  %t71 = call ptr @__olang_region_make(ptr %v0)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l43, !tbaa !24
  br label %bb8
bb8:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = load i64, ptr %l43
  %t76 = inttoptr i64 %t75 to ptr
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t74, ptr %t76, i64 %t73, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t74, i64 160, i1 false)
  br label %bb9
bb9:
  %t78 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t78, label %bb10, label %bb11
bb10:
  %t80 = load i64, ptr %l43
  %t81 = inttoptr i64 %t80 to ptr
  %t82 = getelementptr %"compiler/generic:Context", ptr %l46, i32 0, i32 3
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t82, i32 0, i32 2
  %t84 = load { i64, ptr }, ptr %t83
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = call ptr @__olang_region_or(ptr %t85, ptr null)
  %t87 = call ptr @__olang_region_home(ptr %t86)
  %t88 = icmp ne ptr %t87, null
  %t89 = select i1 %t88, ptr %t87, ptr null
  %t90 = getelementptr %"compiler/generic:Context", ptr %l46, i32 0, i32 3
  %t91 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t90, i32 0, i32 1
  %t92 = load { i64, ptr }, ptr %t91
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = call ptr @__olang_region_or(ptr %t93, ptr null)
  %t95 = call ptr @__olang_region_home(ptr %t94)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, ptr %t95, ptr %t89
  %t98 = getelementptr %"compiler/generic:Context", ptr %l46, i32 0, i32 3
  %t99 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t98, i32 0, i32 0
  %t100 = load { i64, ptr }, ptr %t99
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = call ptr @__olang_region_or(ptr %t101, ptr null)
  %t103 = call ptr @__olang_region_home(ptr %t102)
  %t104 = icmp ne ptr %t103, null
  %t105 = select i1 %t104, ptr %t103, ptr %t97
  %t106 = getelementptr %"compiler/generic:Context", ptr %l46, i32 0, i32 2
  %t107 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t106, i32 0, i32 2
  %t108 = load { i64, ptr }, ptr %t107
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = call ptr @__olang_region_or(ptr %t109, ptr null)
  %t111 = call ptr @__olang_region_home(ptr %t110)
  %t112 = icmp ne ptr %t111, null
  %t113 = select i1 %t112, ptr %t111, ptr %t105
  %t114 = getelementptr %"compiler/generic:Context", ptr %l46, i32 0, i32 2
  %t115 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t114, i32 0, i32 1
  %t116 = load { i64, ptr }, ptr %t115
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = call ptr @__olang_region_home(ptr %t118)
  %t120 = icmp ne ptr %t119, null
  %t121 = select i1 %t120, ptr %t119, ptr %t113
  %t122 = getelementptr %"compiler/generic:Context", ptr %l46, i32 0, i32 2
  %t123 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t122, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = call ptr @__olang_region_or(ptr %t125, ptr null)
  %t127 = call ptr @__olang_region_home(ptr %t126)
  %t128 = icmp ne ptr %t127, null
  %t129 = select i1 %t128, ptr %t127, ptr %t121
  %t130 = icmp eq ptr %t129, %t81
  call void @__olang_region_settle(ptr %t81, i1 %t130)
  br label %bb11
bb11:
  %t131 = load ptr, ptr %l42, !tbaa !29
  %t132 = getelementptr %"compiler/check:frame", ptr %t131, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t132, i64 160, i1 false)
  %t133 = load ptr, ptr %l42, !tbaa !29
  %t134 = getelementptr %"compiler/check:frame", ptr %t133, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %l46, i64 160, i1 false)
  %t135 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t135, label %bb12, label %bb13
bb12:
  %t137 = getelementptr %"compiler/generic:Context", ptr %l48, i32 0, i32 3
  %t138 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 2
  %t139 = load { i64, ptr }, ptr %t138
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = call ptr @__olang_region_or(ptr %t140, ptr null)
  %t142 = call ptr @__olang_region_home(ptr %t141)
  %t143 = icmp ne ptr %t142, null
  %t144 = select i1 %t143, ptr %t142, ptr null
  %t145 = getelementptr %"compiler/generic:Context", ptr %l48, i32 0, i32 3
  %t146 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t145, i32 0, i32 1
  %t147 = load { i64, ptr }, ptr %t146
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = call ptr @__olang_region_or(ptr %t148, ptr null)
  %t150 = call ptr @__olang_region_home(ptr %t149)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, ptr %t150, ptr %t144
  %t153 = getelementptr %"compiler/generic:Context", ptr %l48, i32 0, i32 3
  %t154 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t153, i32 0, i32 0
  %t155 = load { i64, ptr }, ptr %t154
  %t156 = extractvalue { i64, ptr } %t155, 1
  %t157 = call ptr @__olang_region_or(ptr %t156, ptr null)
  %t158 = call ptr @__olang_region_home(ptr %t157)
  %t159 = icmp ne ptr %t158, null
  %t160 = select i1 %t159, ptr %t158, ptr %t152
  %t161 = getelementptr %"compiler/generic:Context", ptr %l48, i32 0, i32 2
  %t162 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t161, i32 0, i32 2
  %t163 = load { i64, ptr }, ptr %t162
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = call ptr @__olang_region_or(ptr %t164, ptr null)
  %t166 = call ptr @__olang_region_home(ptr %t165)
  %t167 = icmp ne ptr %t166, null
  %t168 = select i1 %t167, ptr %t166, ptr %t160
  %t169 = getelementptr %"compiler/generic:Context", ptr %l48, i32 0, i32 2
  %t170 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t169, i32 0, i32 1
  %t171 = load { i64, ptr }, ptr %t170
  %t172 = extractvalue { i64, ptr } %t171, 1
  %t173 = call ptr @__olang_region_or(ptr %t172, ptr null)
  %t174 = call ptr @__olang_region_home(ptr %t173)
  %t175 = icmp ne ptr %t174, null
  %t176 = select i1 %t175, ptr %t174, ptr %t168
  %t177 = getelementptr %"compiler/generic:Context", ptr %l48, i32 0, i32 2
  %t178 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t177, i32 0, i32 0
  %t179 = load { i64, ptr }, ptr %t178
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = call ptr @__olang_region_or(ptr %t180, ptr null)
  %t182 = call ptr @__olang_region_home(ptr %t181)
  %t183 = icmp ne ptr %t182, null
  %t184 = select i1 %t183, ptr %t182, ptr %t176
  call void @__olang_region_drop(ptr %t184)
  store %"compiler/generic:Context" zeroinitializer, ptr %l48
  br label %bb13
bb13:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t185)
  store ptr %t187, ptr %l51
  br label %bb14
bb14:
  %t188 = load %"compiler/source:Span", ptr %l3
  %t189 = load ptr, ptr %l51, !tbaa !29
  %t192 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t189, i32 -1, i32 0, %"compiler/source:Span" %t188)
  store i32 %t192, ptr %l54
  br label %bb15
bb15:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 45
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t195)
  store i64 %t197, ptr %l57
  br label %bb16
bb16:
  %t198 = load i64, ptr %l57, !tbaa !24
  store i64 %t198, ptr %l9, !tbaa !24
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i64, ptr %l1, !tbaa !24
  %t201 = load i32, ptr %l2, !tbaa !23
  %t205 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t199, i64 %t200, i32 %t201)
  store i32 %t205, ptr %l61
  br label %bb17
bb17:
  %t206 = load i32, ptr %l61, !tbaa !23
  store i32 %t206, ptr %l10, !tbaa !23
  %t207 = load %"compiler/source:Span", ptr %l3
  %t208 = load i32, ptr %l10, !tbaa !23
  %t209 = load i64, ptr %l1, !tbaa !24
  %t210 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t211
  %t212 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 0
  store i64 1, ptr %t212
  %t214 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t207, 0
  %t216 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t214, i32 %t208, 1
  %t218 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t216, i64 %t209, 2
  %t220 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t218, i32 %t210, 3
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t220, ptr %t221
  %t222 = load { i64, [4 x i64] }, ptr %t211
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t222, ptr %t224
  store ptr %t224, ptr %l11, !tbaa !29
  %t226 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t226, ptr %l68
  br label %bb18
bb18:
  %t227 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l68
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t227, ptr %l12
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %s0, ptr %t228, i32 %t229, ptr %l12, i64 0)
  br label %bb19
bb19:
  %t233 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t233, ptr %l72
  br label %bb20
bb20:
  %t234 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72
  %t235 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %t235
  store ptr %t235, ptr %l13, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Program", ptr %t240, i32 0, i32 2
  %t243 = load i32, ptr %l10, !tbaa !23
  %t246 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t242, i32 %t243)
  store i32 %t246, ptr %l78
  br label %bb21
bb21:
  %t247 = load i32, ptr %l78, !range !{i32 0, i32 33}
  %t249 = trunc i64 19 to i32
  %t250 = icmp eq i32 %t247, %t249
  br i1 %t250, label %bb22, label %bb23
bb22:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = getelementptr %"compiler/generic:Program", ptr %t255, i32 0, i32 2
  %t258 = load i32, ptr %l10, !tbaa !23
  %t261 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t257, i32 %t258)
  store i32 %t261, ptr %l86
  br label %bb24
bb23:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb25
bb24:
  %t262 = load i32, ptr %l86, !tbaa !23
  %t263 = icmp ne i32 %t262, 0
  store i1 %t263, ptr %l81, !tbaa !21
  br label %bb25
bb25:
  %t265 = load i1, ptr %l81, !tbaa !21
  br i1 %t265, label %bb26, label %bb27
bb26:
  %t266 = load ptr, ptr %l13, !tbaa !29
  store ptr %t266, ptr %l88, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t267, ptr %l89
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 2
  %t274 = load i32, ptr %l10, !tbaa !23
  %t275 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t279 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t273, i32 %t274, i64 %t275)
  store i32 %t279, ptr %l95
  br label %bb28
bb27:
  %t280 = load ptr, ptr %l13, !tbaa !29
  store ptr %t280, ptr %l101, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load %"compiler/source:Span", ptr %l3
  %t283 = load ptr, ptr %l11, !tbaa !29
  %t287 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t281, %"compiler/source:Span" %t282, ptr %t283)
  store ptr %t287, ptr %l105
  br label %bb30
bb28:
  %t288 = load ptr, ptr %l11, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t289
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 0
  store i64 3, ptr %t290
  %t291 = load %"compiler/source:Span", ptr %l89
  %t292 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t291, 0
  %t293 = load i32, ptr %l95, !tbaa !23
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr } %t292, i32 %t293, 1
  %t296 = insertvalue { %"compiler/source:Span", i32, ptr } %t294, ptr %t288, 2
  %t297 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t296, ptr %t297
  %t298 = load { i64, [5 x i64] }, ptr %t289
  %t300 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t298, ptr %t300
  store { i64, [2 x i64] } zeroinitializer, ptr %t301
  %t302 = getelementptr { i64, [2 x i64] }, ptr %t301, i32 0, i32 0
  store i64 1, ptr %t302
  %t304 = insertvalue { ptr } undef, ptr %t300, 0
  %t305 = getelementptr { i64, [2 x i64] }, ptr %t301, i32 0, i32 1
  store { ptr } %t304, ptr %t305
  %t306 = load { i64, [2 x i64] }, ptr %t301
  %t308 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t306, ptr %t308
  %t309 = load ptr, ptr %l88, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0, ptr %v0, ptr %t309, ptr %t308)
  br label %bb29
bb29:
  br label %bb32
bb30:
  store { i64, [2 x i64] } zeroinitializer, ptr %t311
  %t312 = getelementptr { i64, [2 x i64] }, ptr %t311, i32 0, i32 0
  store i64 1, ptr %t312
  %t313 = load ptr, ptr %l105, !tbaa !29
  %t314 = insertvalue { ptr } undef, ptr %t313, 0
  %t315 = getelementptr { i64, [2 x i64] }, ptr %t311, i32 0, i32 1
  store { ptr } %t314, ptr %t315
  %t316 = load { i64, [2 x i64] }, ptr %t311
  %t318 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t316, ptr %t318
  %t319 = load ptr, ptr %l101, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0, ptr %v0, ptr %t319, ptr %t318)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/check:Checker", ptr %t321, i32 0, i32 45
  store ptr %t323, ptr %l109, !tbaa !29
  %t324 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t324, ptr %l110
  %t325 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t325, ptr %l111
  %t326 = load i32, ptr %l6, !tbaa !23
  store i32 %t326, ptr %l112, !tbaa !23
  %t327 = load ptr, ptr %l13, !tbaa !29
  %t329 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eToArr_H1b89f7fcc263bba924ca04e7c3aa48c7(ptr %v0, ptr %v0, ptr %t327)
  store { i64, ptr } %t329, ptr %l114
  br label %bb33
bb33:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load %"compiler/source:Span", ptr %l3
  %t335 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t330, i32 4, %"compiler/source:Span" %t331)
  store i32 %t335, ptr %l118
  br label %bb34
bb34:
  %t336 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t337 = load i32, ptr %l118, !tbaa !23
  %t338 = call %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v0, { i64, ptr } %t336, i32 %t337)
  store %"compiler/typed:Text" %t338, ptr %l119
  br label %bb35
bb35:
  %t339 = load %"compiler/typed:Text", ptr %l119
  %t340 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Text" %t339, ptr %t340
  store { i64, [5 x i64] } zeroinitializer, ptr %t341
  %t342 = getelementptr { i64, [5 x i64] }, ptr %t341, i32 0, i32 0
  store i64 16, ptr %t342
  %t343 = load %"compiler/source:Span", ptr %l111
  %t344 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t343, 0
  %t345 = load i32, ptr %l112, !tbaa !23
  %t346 = insertvalue { %"compiler/source:Span", i32, ptr } %t344, i32 %t345, 1
  %t348 = insertvalue { %"compiler/source:Span", i32, ptr } %t346, ptr %t340, 2
  %t349 = getelementptr { i64, [5 x i64] }, ptr %t341, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t348, ptr %t349
  %t350 = load { i64, [5 x i64] }, ptr %t341
  %t352 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t350, ptr %t352
  store { i64, [3 x i64] } zeroinitializer, ptr %t353
  %t354 = getelementptr { i64, [3 x i64] }, ptr %t353, i32 0, i32 0
  store i64 6, ptr %t354
  %t355 = load %"compiler/source:Span", ptr %l110
  %t356 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t355, 0
  %t358 = insertvalue { %"compiler/source:Span", ptr } %t356, ptr %t352, 1
  %t359 = getelementptr { i64, [3 x i64] }, ptr %t353, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t358, ptr %t359
  %t360 = load { i64, [3 x i64] }, ptr %t353
  %t362 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t360, ptr %t362
  %t363 = load ptr, ptr %l109, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t363, ptr %t362)
  br label %bb36
bb36:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t365)
  store ptr %t367, ptr %l126
  br label %bb37
bb37:
  %t368 = load ptr, ptr %l126, !tbaa !29
  store ptr %t368, ptr %l127, !tbaa !29
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/check:Checker", ptr %t369, i32 0, i32 45
  %t372 = load i64, ptr %l9, !tbaa !24
  %t375 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t371, i64 %t372)
  store { i64, ptr } %t375, ptr %l131
  br label %bb38
bb38:
  %t376 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t377 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t376)
  store %"compiler/typed:Block" %t377, ptr %l132
  br label %bb39
bb39:
  %t378 = load %"compiler/typed:Block", ptr %l132
  %t379 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t378, ptr %t379
  %t381 = load ptr, ptr %l127, !tbaa !29
  %t382 = getelementptr %"compiler/typed:Body", ptr %t381, i32 0, i32 11
  store ptr %t379, ptr %t382, !tbaa !29
  %t383 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t383)
  br label %bb40
bb40:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t387 = getelementptr %"compiler/check:Checker", ptr %t385, i32 0, i32 23
  %t388 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t387, i64 %t388, i64 2)
  br label %bb41
bb41:
  %t391 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t391)
  br label %bb42
bb42:
  %t393 = load ptr, ptr %l4, !tbaa !29
  %t395 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t393)
  store i64 %t395, ptr %l140
  br label %bb43
bb43:
  %t396 = load i64, ptr %l5, !tbaa !24
  %t397 = load i64, ptr %l140, !tbaa !24
  %t399 = icmp sgt i64 %t397, %t396
  br i1 %t399, label %bb44, label %bb45
bb44:
  %t401 = load ptr, ptr %l4, !tbaa !29
  %t402 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t401, i64 %t402)
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/check:Checker", ptr %t405, i32 0, i32 18
  %t408 = load i64, ptr %l7, !tbaa !24
  %t411 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t407, i64 %t408)
  store ptr %t411, ptr %l148
  br label %bb47
bb47:
  %t412 = load ptr, ptr %l148, !tbaa !29
  %t414 = getelementptr %"compiler/typed:Body", ptr %t412, i32 0, i32 11
  store ptr null, ptr %t414, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb48:
  %t416 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t416, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca i1
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2epastAway(ptr %v1, ptr %v2, ptr %a1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 3
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = call ptr @compiler_2fcheck_2ewholeTemp(ptr %v2, ptr %v2, ptr %t20)
  store ptr %t22, ptr %l16
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l16, !tbaa !29
  store ptr %t23, ptr %l8, !tbaa !29
  br label %bb20
bb8:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t25 = load ptr, ptr %l17, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 5
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l18, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Promote", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2epastAway(ptr %v2, ptr %v2, ptr %t42)
  store ptr %t44, ptr %l25
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l25, !tbaa !29
  store ptr %t45, ptr %l8, !tbaa !29
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store ptr null, ptr %l8, !tbaa !29
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_943b293e8fd49f1f_6252e979531a6d2b)
  unreachable
bb20:
  %t47 = load ptr, ptr %l8, !tbaa !29
  store ptr %t47, ptr %l5, !tbaa !29
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  br i1 %t50, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb24
bb22:
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatCallee(ptr %v0, ptr %v2, ptr %a0, ptr %t53)
  store i1 %t56, ptr %l32
  br label %bb23
bb23:
  %t57 = load i1, ptr %l32, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l29, !tbaa !21
  br label %bb24
bb24:
  %t60 = load i1, ptr %l29, !tbaa !21
  br i1 %t60, label %bb25, label %bb26
bb25:
  store ptr null, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t62 = load ptr, ptr %l5, !tbaa !29
  store ptr %t62, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebang(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %lp10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l23 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca i1
  %l35 = alloca i32
  %l38 = alloca i32
  %l43 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l57 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i32
  %l70 = alloca i1
  %l72 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l83 = alloca %"compiler/source:Span"
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l85 = alloca i64
  %l88 = alloca ptr
  %l92 = alloca %"compiler/source:Span"
  %l95 = alloca i32
  %l97 = alloca ptr
  %l101 = alloca %"compiler/typed:Try"
  %l105 = alloca ptr
  %l109 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t189 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l12, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 28
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 16
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l6, !tbaa !24
  %t16 = load ptr, ptr %l4, !tbaa !29
  store ptr %t16, ptr %l18, !tbaa !29
  %t17 = load ptr, ptr %l18, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 15
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 15
  store i64 %t21, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = call i1 @compiler_2fcheck_2eisMember(ptr %v1, ptr %t26)
  store i1 %t28, ptr %l23
  br label %bb3
bb3:
  %t29 = load i1, ptr %l23, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 12
  store i1 %t29, ptr %t31, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l24, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  store ptr %t33, ptr %l26, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l29
  br label %bb4
bb4:
  %t40 = load i1, ptr %l29, !tbaa !21
  br i1 %t40, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb8
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l35
  br label %bb7
bb7:
  %t51 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t53 = trunc i64 21 to i32
  %t54 = icmp eq i32 %t51, %t53
  store i1 %t54, ptr %l30, !tbaa !21
  br label %bb8
bb8:
  %t56 = load i1, ptr %l30, !tbaa !21
  br i1 %t56, label %bb9, label %bb10
bb9:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l43
  br label %bb11
bb10:
  %t67 = load i32, ptr %l3, !tbaa !23
  store i32 %t67, ptr %l38, !tbaa !23
  br label %bb12
bb11:
  %t69 = load i32, ptr %l43, !tbaa !23
  store i32 %t69, ptr %l38, !tbaa !23
  br label %bb12
bb12:
  %t70 = load ptr, ptr %l24, !tbaa !29
  %t71 = load ptr, ptr %l26, !tbaa !29
  %t72 = load i32, ptr %l38, !tbaa !23
  %t73 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t70, ptr %t71, i32 %t72)
  store ptr %t73, ptr %l45
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l45, !tbaa !29
  store ptr %t74, ptr %l7, !tbaa !29
  %t75 = load ptr, ptr %l4, !tbaa !29
  store ptr %t75, ptr %l46, !tbaa !29
  %t76 = load ptr, ptr %l46, !tbaa !29
  %t77 = getelementptr %"compiler/check:frame", ptr %t76, i32 0, i32 15
  %t78 = load i64, ptr %t77, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t82 = load ptr, ptr %l46, !tbaa !29
  %t83 = getelementptr %"compiler/check:frame", ptr %t82, i32 0, i32 15
  store i64 %t80, ptr %t83, !tbaa !24
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t86 = getelementptr %"compiler/check:frame", ptr %t84, i32 0, i32 16
  %t87 = load i64, ptr %t86, !tbaa !24
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = icmp ne i64 %t87, %t88
  store i1 %t91, ptr %l8, !tbaa !21
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t94 = load i64, ptr %l6, !tbaa !24
  %t97 = getelementptr %"compiler/check:frame", ptr %t93, i32 0, i32 16
  store i64 %t94, ptr %t97, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 2
  store ptr %t103, ptr %l57, !tbaa !29
  %t104 = load ptr, ptr %l7, !tbaa !29
  %t107 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t104)
  store i32 %t107, ptr %l60
  br label %bb14
bb14:
  %t108 = load ptr, ptr %l57, !tbaa !29
  %t109 = load i32, ptr %l60, !tbaa !23
  %t110 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t108, i32 %t109)
  store i1 %t110, ptr %l61
  br label %bb15
bb15:
  %t111 = load i1, ptr %l61, !tbaa !21
  store i1 %t111, ptr %l9, !tbaa !21
  %t112 = load i1, ptr %l8, !tbaa !21
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb16, label %bb17
bb16:
  %t116 = load ptr, ptr %l7, !tbaa !29
  %t119 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t116)
  store i32 %t119, ptr %l67
  br label %bb18
bb17:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb19
bb18:
  %t120 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t121 = load i32, ptr %l67, !tbaa !23
  %t123 = icmp ne i32 %t121, %t120
  store i1 %t123, ptr %l64, !tbaa !21
  br label %bb19
bb19:
  %t125 = load i1, ptr %l64, !tbaa !21
  br i1 %t125, label %bb20, label %bb21
bb20:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %t126)
  store i1 %t128, ptr %l72
  br label %bb22
bb21:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb23
bb22:
  %t129 = load i1, ptr %l72, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l70, !tbaa !21
  br label %bb23
bb23:
  %t132 = load i1, ptr %l70, !tbaa !21
  br i1 %t132, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s1
  %t133 = load i1, ptr %l9, !tbaa !21
  br i1 %t133, label %bb26, label %bb27
bb25:
  br label %bb34
bb26:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  %t137 = load ptr, ptr %l7, !tbaa !29
  %t141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %v2, ptr %v2, ptr %t135, %"compiler/source:Span" %t136, ptr %t137)
  store ptr %t141, ptr %l78
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s1)
  %t142 = load ptr, ptr %l78, !tbaa !29
  store ptr %t142, ptr %rv
  br label %ret
bb29:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l79, !tbaa !29
  %t144 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t145 = load i32, ptr %t144, !tbaa !23
  %t147 = sub i32 %t145, 1
  %t148 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t149 = load i32, ptr %t148, !tbaa !23
  %t152 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t147, i32 %t149)
  store %"compiler/source:Span" %t152, ptr %l83
  br label %bb30
bb30:
  %t153 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBangNothingFails(ptr %v0)
  store %"compiler/diagmsg:Msg" %t153, ptr %l84
  br label %bb31
bb31:
  %t154 = load ptr, ptr %l79, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l83
  %t156 = load %"compiler/diagmsg:Msg", ptr %l84
  %t157 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t154, %"compiler/source:Span" %t155, %"compiler/diagmsg:Msg" %t156)
  store i64 %t157, ptr %l85
  br label %bb32
bb32:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l1
  %t162 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t158, %"compiler/source:Span" %t159)
  store ptr %t162, ptr %l88
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s1)
  %t163 = load ptr, ptr %l88, !tbaa !29
  store ptr %t163, ptr %rv
  br label %ret
bb34:
  %t164 = load ptr, ptr %l4, !tbaa !29
  %t166 = getelementptr %"compiler/check:frame", ptr %t164, i32 0, i32 28
  %t167 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t166, i64 %t167)
  br label %bb35
bb35:
  %t170 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t170, ptr %l92
  %t171 = load ptr, ptr %l7, !tbaa !29
  %t174 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t171)
  store i32 %t174, ptr %l95
  br label %bb36
bb36:
  %t175 = load ptr, ptr %l7, !tbaa !29
  store ptr %t175, ptr %l97, !tbaa !29
  %t177 = icmp sge i64 0, 0
  br i1 %t177, label %bb37, label %bb38
bb37:
  %t179 = icmp sle i64 0, 1152921504606846975
  br i1 %t179, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_77940e7aab679ede_bd13144cbc386012)
  unreachable
bb39:
  %t181 = mul i64 0, 8
  %t182 = insertvalue { i64, ptr } undef, i64 0, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t184 = load ptr, ptr %l97, !tbaa !29
  %t186 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %t184, { i64, ptr } %t183, i1 true, i1 false, i1 true)
  store %"compiler/typed:Try" %t186, ptr %l101
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_77940e7aab679ede_bd13144cbc386012)
  unreachable
bb41:
  %t187 = load %"compiler/typed:Try", ptr %l101
  %t188 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Try" %t187, ptr %t188
  store { i64, [5 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 0
  store i64 14, ptr %t190
  %t191 = load %"compiler/source:Span", ptr %l92
  %t192 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t191, 0
  %t193 = load i32, ptr %l95, !tbaa !23
  %t194 = insertvalue { %"compiler/source:Span", i32, ptr } %t192, i32 %t193, 1
  %t196 = insertvalue { %"compiler/source:Span", i32, ptr } %t194, ptr %t188, 2
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t196, ptr %t197
  %t198 = load { i64, [5 x i64] }, ptr %t189
  %t199 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t199, ptr %lp10
  %t201 = load ptr, ptr %lp10
  store { i64, [5 x i64] } %t198, ptr %t201
  %t202 = load i1, ptr %l9, !tbaa !21
  br i1 %t202, label %bb42, label %bb43
bb42:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l1
  %t206 = load ptr, ptr %lp10
  %t210 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %v2, ptr %v2, ptr %t204, %"compiler/source:Span" %t205, ptr %t206)
  store ptr %t210, ptr %l109
  br label %bb44
bb43:
  %t211 = load ptr, ptr %lp10
  store ptr %t211, ptr %l105, !tbaa !29
  br label %bb45
bb44:
  %t213 = load ptr, ptr %l109, !tbaa !29
  store ptr %t213, ptr %l105, !tbaa !29
  br label %bb45
bb45:
  %t214 = load ptr, ptr %l105, !tbaa !29
  store ptr %t214, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindPattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, i32 %a4, ptr %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, [3 x i64] }
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca %"compiler/typed:Local"
  %l46 = alloca i1
  %l48 = alloca ptr
  %l52 = alloca %"compiler/typed:Local"
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l70 = alloca ptr
  %l77 = alloca ptr
  %l79 = alloca ptr
  %l83 = alloca %"compiler/typed:Local"
  %l86 = alloca i1
  %l88 = alloca i1
  %l100 = alloca ptr
  %l105 = alloca %"compiler/typed:Bind"
  %l110 = alloca ptr
  %rv = alloca ptr
  %t91 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l1
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v1, ptr %t2, %"compiler/source:Span" %t3, ptr %t4)
  store ptr %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load %"compiler/source:Span", ptr %l1
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load ptr, ptr %l14, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v0, ptr %t10, ptr %t11, %"compiler/source:Span" %t9, i1 false)
  store ptr %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l16, !tbaa !29
  store ptr %t14, ptr %l7, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l17, !tbaa !29
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t16)
  store i32 %t19, ptr %l20
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t21 = load i32, ptr %l20, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l25
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t29 = load i1, ptr %l25, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l7, !tbaa !29
  %t36 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t33)
  store i32 %t36, ptr %l29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t37 = load i32, ptr %l29, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t38, i32 %t39)
  store i64 %t42, ptr %l32
  br label %bb13
bb13:
  %t43 = load i64, ptr %l32, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp slt i64 %t44, 0
  br i1 %t46, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb18
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t48)
  store ptr %t50, ptr %l37
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l37, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Body", ptr %t51, i32 0, i32 7
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t53, i64 %t54)
  store %"compiler/typed:Local" %t57, ptr %l41
  br label %bb17
bb17:
  %t58 = getelementptr %"compiler/typed:Local", ptr %l41, i32 0, i32 3
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t65 = icmp ne i64 %t61, %a6
  store i1 %t65, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb23
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t68)
  store ptr %t70, ptr %l48
  br label %bb21
bb21:
  %t71 = load ptr, ptr %l48, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 7
  %t74 = load i64, ptr %l8, !tbaa !24
  %t77 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t73, i64 %t74)
  store %"compiler/typed:Local" %t77, ptr %l52
  br label %bb22
bb22:
  %t78 = getelementptr %"compiler/typed:Local", ptr %l52, i32 0, i32 4
  %t79 = load i32, ptr %t78, !range !{i32 0, i32 7}
  %t81 = trunc i64 4 to i32
  %t82 = icmp eq i32 %t79, %t81
  %t84 = xor i1 %t82, true
  store i1 %t84, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t86 = load i1, ptr %l46, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l2, !tbaa !23
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load i32, ptr %l4, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [1 x i64] }, ptr %t91, i32 0, i32 0
  store i64 4, ptr %t92
  %t93 = load { i64, [1 x i64] }, ptr %t91
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t87, i32 %t88, %"compiler/source:Span" %t89, i32 %t90, i32 4, { i64, [1 x i64] } %t93)
  store i64 %t100, ptr %l62
  br label %bb26
bb25:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l77, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t107)
  store ptr %t109, ptr %l79
  br label %bb33
bb26:
  %t110 = load i64, ptr %l62, !tbaa !24
  store i64 %t110, ptr %l8, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t115 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %t111, ptr %t112)
  store { i64, [3 x i64] } %t115, ptr %l65
  br label %bb27
bb27:
  %t116 = load { i64, [3 x i64] }, ptr %l65
  store { i64, [3 x i64] } %t116, ptr %l9
  %t117 = load { i64, [3 x i64] }, ptr %l9
  %t119 = extractvalue { i64, [3 x i64] } %t117, 0
  %t120 = icmp eq i64 %t119, 0
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb28, label %bb29
bb28:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t124)
  store ptr %t126, ptr %l70
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 3
  %t130 = load i64, ptr %l8, !tbaa !24
  %t131 = load { i64, [3 x i64] }, ptr %l9
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t129, i64 %t130, { i64, [3 x i64] } %t131)
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb43
bb33:
  %t135 = load ptr, ptr %l79, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Body", ptr %t135, i32 0, i32 7
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t137, i64 %t138)
  store %"compiler/typed:Local" %t141, ptr %l83
  br label %bb34
bb34:
  %t142 = getelementptr %"compiler/typed:Local", ptr %l83, i32 0, i32 2
  %t143 = load i32, ptr %t142, !tbaa !23
  %t144 = load i32, ptr %l4, !tbaa !23
  %t145 = load ptr, ptr %l77, !tbaa !29
  %t148 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t145, i32 %t143, i32 %t144)
  store i1 %t148, ptr %l86
  br label %bb35
bb35:
  %t149 = load i1, ptr %l86, !tbaa !21
  %t150 = xor i1 %t149, true
  br i1 %t150, label %bb36, label %bb37
bb36:
  %t152 = load i32, ptr %l4, !tbaa !23
  %t153 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t156 = icmp ne i32 %t152, %t153
  store i1 %t156, ptr %l88, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb38
bb38:
  %t158 = load i1, ptr %l88, !tbaa !21
  br i1 %t158, label %bb39, label %bb40
bb39:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load i32, ptr %l2, !tbaa !23
  %t162 = load i64, ptr %l8, !tbaa !24
  %t163 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtBinding(ptr %v0, ptr %t159, %"compiler/source:Span" %t160, i32 %t161, i64 %t162, i32 %t163)
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i64, ptr %l8, !tbaa !24
  %t171 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t169, i64 %t170, ptr %t171)
  br label %bb44
bb44:
  store ptr %a5, ptr %l100, !tbaa !29
  %t176 = load i64, ptr %l8, !tbaa !24
  %t178 = trunc i64 %t176 to i32
  %t180 = load ptr, ptr %l7, !tbaa !29
  %t183 = call %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v2, i32 %t178, ptr %t180)
  store %"compiler/typed:Bind" %t183, ptr %l105
  br label %bb45
bb45:
  %t184 = load %"compiler/typed:Bind", ptr %l105
  %t185 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store %"compiler/typed:Bind" %t184, ptr %t185
  %t186 = load ptr, ptr %l100, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v2, ptr %v2, ptr %t186, ptr %t185)
  br label %bb46
bb46:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load %"compiler/source:Span", ptr %l1
  %t190 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t194 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t188, %"compiler/source:Span" %t189, i32 %t190, i64 1)
  store ptr %t194, ptr %l110
  br label %bb47
bb47:
  %t195 = load ptr, ptr %l110, !tbaa !29
  store ptr %t195, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l47 = alloca ptr
  %l52 = alloca ptr
  %l56 = alloca i64
  %l58 = alloca i64
  %l63 = alloca i64
  %l65 = alloca ptr
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca i32
  %l75 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 44
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l10, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l8, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l10, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l10, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l28, !tbaa !24
  store i64 %t37, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l25, !tbaa !24
  store i64 %t38, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l12, !tbaa !24
  %t40 = load i64, ptr %l11, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l12, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 44
  store ptr %t59, ptr %l47, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v1, ptr %v2, ptr %v1, ptr %t60, { i64, ptr } %t61, ptr %a5, i64 %t55)
  store ptr %t68, ptr %l52
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l47, !tbaa !29
  %t70 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t71 = load i64, ptr %l12, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l12, !tbaa !24
  br label %bb8
bb15:
  store ptr %a6, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb16
bb16:
  %t77 = load i64, ptr %l15, !tbaa !24
  store i64 %t77, ptr %l56, !tbaa !24
  %t78 = load ptr, ptr %l14, !tbaa !29
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t78)
  store i64 %t80, ptr %l58
  br label %bb17
bb17:
  %t81 = load i64, ptr %l56, !tbaa !24
  %t82 = load i64, ptr %l58, !tbaa !24
  %t83 = icmp slt i64 %t81, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb18, label %bb19
bb18:
  br label %bb25
bb19:
  br label %bb20
bb20:
  %t87 = load ptr, ptr %l14, !tbaa !29
  %t88 = load i64, ptr %l15, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l63
  br label %bb21
bb21:
  %t92 = load i64, ptr %l63, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 44
  store ptr %t95, ptr %l65, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l1
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t96, %"compiler/source:Span" %t97, i64 %t92)
  store ptr %t102, ptr %l69
  br label %bb22
bb22:
  %t103 = load ptr, ptr %l65, !tbaa !29
  %t104 = load ptr, ptr %l69, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t103, ptr %t104)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t105 = load i64, ptr %l15, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l15, !tbaa !24
  br label %bb16
bb25:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l72, !tbaa !29
  %t110 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t110, ptr %l73
  store i32 %a3, ptr %l74, !tbaa !23
  store i64 %a2, ptr %l75, !tbaa !24
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 44
  %t116 = load i64, ptr %l7, !tbaa !24
  %t119 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t115, i64 %t116)
  store { i64, ptr } %t119, ptr %l79
  br label %bb26
bb26:
  %t120 = load ptr, ptr %l72, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l73
  %t122 = load i32, ptr %l74, !tbaa !23
  %t123 = load i64, ptr %l75, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v0, ptr %v4, ptr %t120, %"compiler/source:Span" %t121, i32 %t122, i64 %t123, { i64, ptr } %t124, i1 false)
  store ptr %t125, ptr %l80
  br label %bb27
bb27:
  %t126 = load ptr, ptr %l80, !tbaa !29
  store ptr %t126, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderOwnerOk(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l13 = alloca i64
  %l19 = alloca ptr
  %l26 = alloca i32
  %l32 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"compiler/diagmsg:Msg"
  %l42 = alloca i64
  %l52 = alloca i64
  %l56 = alloca i1
  %l58 = alloca i1
  %l64 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, ptr }
  %l74 = alloca %"compiler/diagmsg:Msg"
  %l75 = alloca i64
  %l81 = alloca i32
  %l86 = alloca i1
  %l90 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l98 = alloca i64
  %l100 = alloca %"compiler/diagmsg:Msg"
  %l103 = alloca { i64, ptr }
  %l105 = alloca %"compiler/diagmsg:Msg"
  %l108 = alloca { i64, ptr }
  %l110 = alloca %"compiler/diagmsg:Msg"
  %l111 = alloca i64
  %l115 = alloca i32
  %l119 = alloca i1
  %l123 = alloca i1
  %l127 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  %l135 = alloca { i64, ptr }
  %l137 = alloca %"compiler/diagmsg:Msg"
  %l138 = alloca i64
  %l141 = alloca ptr
  %l146 = alloca i32
  %l147 = alloca i64
  %l151 = alloca i1
  %l153 = alloca i1
  %l159 = alloca ptr
  %l163 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l167 = alloca { i64, ptr }
  %l169 = alloca %"compiler/diagmsg:Msg"
  %l170 = alloca i64
  %l176 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i64, ptr %l13, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 10
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l19
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l19, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 3
  %t26 = load i1, ptr %t25, !tbaa !21
  store i1 %t26, ptr %l5, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l26
  br label %bb3
bb3:
  %t38 = load i32, ptr %l26, !range !{i32 0, i32 33}
  %t40 = trunc i64 25 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderKey(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l32
  br label %bb6
bb5:
  br label %bb27
bb6:
  %t51 = load i64, ptr %l32, !tbaa !24
  store i64 %t51, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t52, 0
  br i1 %t54, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l35, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t57, ptr %l36
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t58, i32 %t59)
  store { i64, ptr } %t62, ptr %l39
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t63 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t71 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerKind(ptr %s2, ptr %v0, { i64, ptr } %t69)
  store %"compiler/diagmsg:Msg" %t71, ptr %l41
  br label %bb10
bb10:
  %t72 = load ptr, ptr %l35, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l36
  %t74 = load %"compiler/diagmsg:Msg", ptr %l41
  %t75 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t72, %"compiler/source:Span" %t73, %"compiler/diagmsg:Msg" %t74)
  store i64 %t75, ptr %l42
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb12:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i64, ptr %l6, !tbaa !24
  %t82 = shl i64 1, 40
  %t84 = sub i64 %t82, 1
  %t87 = and i64 %t81, %t84
  %t89 = trunc i64 %t87 to i32
  %t93 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t80, i32 %t89)
  store i64 %t93, ptr %l52
  br label %bb13
bb13:
  %t94 = load i64, ptr %l52, !tbaa !24
  store i64 %t94, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load i64, ptr %l4, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  br i1 %t99, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb20
bb15:
  %t101 = load i1, ptr %l5, !tbaa !21
  br i1 %t101, label %bb16, label %bb17
bb16:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 10
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t111, i64 %t112)
  store ptr %t115, ptr %l64
  br label %bb18
bb17:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb19
bb18:
  %t116 = load ptr, ptr %l64, !tbaa !29
  %t118 = getelementptr %"compiler/load:Module", ptr %t116, i32 0, i32 3
  %t119 = load i1, ptr %t118, !tbaa !21
  store i1 %t119, ptr %l58, !tbaa !21
  br label %bb19
bb19:
  %t121 = load i1, ptr %l58, !tbaa !21
  store i1 %t121, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t122 = load i1, ptr %l56, !tbaa !21
  br i1 %t122, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l68, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t125, ptr %l69
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l2, !tbaa !23
  %t130 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t126, i32 %t127)
  store { i64, ptr } %t130, ptr %l72
  br label %bb24
bb24:
  %t131 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  %t133 = extractvalue { i64, ptr } %t131, 1
  %t134 = mul i64 %t132, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  %t139 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerElsewhere(ptr %s1, ptr %v0, { i64, ptr } %t137)
  store %"compiler/diagmsg:Msg" %t139, ptr %l74
  br label %bb25
bb25:
  %t140 = load ptr, ptr %l68, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l69
  %t142 = load %"compiler/diagmsg:Msg", ptr %l74
  %t143 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t140, %"compiler/source:Span" %t141, %"compiler/diagmsg:Msg" %t142)
  store i64 %t143, ptr %l75
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb27:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l2, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l81
  br label %bb28
bb28:
  %t155 = load i32, ptr %l81, !range !{i32 0, i32 33}
  %t157 = trunc i64 18 to i32
  %t158 = icmp eq i32 %t155, %t157
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t162 = load i1, ptr %l5, !tbaa !21
  br i1 %t162, label %bb31, label %bb32
bb30:
  br label %bb47
bb31:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t168 = load i64, ptr %l1, !tbaa !24
  %t171 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderKey(ptr %v0, ptr %t167, i64 %t168)
  store i64 %t171, ptr %l90
  br label %bb33
bb32:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb34
bb33:
  %t172 = load i64, ptr %l90, !tbaa !24
  %t173 = icmp sge i64 %t172, 0
  store i1 %t173, ptr %l86, !tbaa !21
  br label %bb34
bb34:
  %t175 = load i1, ptr %l86, !tbaa !21
  br i1 %t175, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l93, !tbaa !29
  %t178 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t178, ptr %l94
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t183 = load i64, ptr %l1, !tbaa !24
  %t186 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderKey(ptr %v0, ptr %t182, i64 %t183)
  store i64 %t186, ptr %l98
  br label %bb38
bb38:
  %t187 = load i64, ptr %l98, !tbaa !24
  %t188 = icmp sge i64 %t187, 0
  br i1 %t188, label %bb39, label %bb40
bb39:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l2, !tbaa !23
  %t194 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t190, i32 %t191)
  store { i64, ptr } %t194, ptr %l103
  br label %bb41
bb40:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l2, !tbaa !23
  %t199 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t195, i32 %t196)
  store { i64, ptr } %t199, ptr %l108
  br label %bb43
bb41:
  %t200 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t208 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerElsewhere(ptr %s4, ptr %v0, { i64, ptr } %t206)
  store %"compiler/diagmsg:Msg" %t208, ptr %l105
  br label %bb42
bb42:
  %t209 = load %"compiler/diagmsg:Msg", ptr %l105
  store %"compiler/diagmsg:Msg" %t209, ptr %l100
  br label %bb45
bb43:
  %t210 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  %t218 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerKind(ptr %s4, ptr %v0, { i64, ptr } %t216)
  store %"compiler/diagmsg:Msg" %t218, ptr %l110
  br label %bb44
bb44:
  %t219 = load %"compiler/diagmsg:Msg", ptr %l110
  store %"compiler/diagmsg:Msg" %t219, ptr %l100
  br label %bb45
bb45:
  %t220 = load ptr, ptr %l93, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l94
  %t222 = load %"compiler/diagmsg:Msg", ptr %l100
  %t223 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t220, %"compiler/source:Span" %t221, %"compiler/diagmsg:Msg" %t222)
  store i64 %t223, ptr %l111
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb47:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l2, !tbaa !23
  %t229 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t225, i32 %t226)
  store i32 %t229, ptr %l115
  br label %bb48
bb48:
  %t230 = load i32, ptr %l115, !range !{i32 0, i32 6}
  store i32 %t230, ptr %l8
  %t231 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t233 = trunc i64 0 to i32
  %t234 = icmp eq i32 %t231, %t233
  %t236 = xor i1 %t234, true
  br i1 %t236, label %bb49, label %bb50
bb49:
  %t238 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t240 = trunc i64 1 to i32
  %t241 = icmp eq i32 %t238, %t240
  %t243 = xor i1 %t241, true
  store i1 %t243, ptr %l119, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb51
bb51:
  %t245 = load i1, ptr %l119, !tbaa !21
  br i1 %t245, label %bb52, label %bb53
bb52:
  %t246 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t248 = trunc i64 4 to i32
  %t249 = icmp eq i32 %t246, %t248
  %t251 = xor i1 %t249, true
  store i1 %t251, ptr %l123, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb54
bb54:
  %t253 = load i1, ptr %l123, !tbaa !21
  br i1 %t253, label %bb55, label %bb56
bb55:
  %t254 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t256 = trunc i64 5 to i32
  %t257 = icmp eq i32 %t254, %t256
  %t259 = xor i1 %t257, true
  store i1 %t259, ptr %l127, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb57
bb57:
  %t261 = load i1, ptr %l127, !tbaa !21
  br i1 %t261, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s6
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l131, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t263, ptr %l132
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i32, ptr %l2, !tbaa !23
  %t268 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t264, i32 %t265)
  store { i64, ptr } %t268, ptr %l135
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t269 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  %t271 = extractvalue { i64, ptr } %t269, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  %t277 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerKind(ptr %s6, ptr %v0, { i64, ptr } %t275)
  store %"compiler/diagmsg:Msg" %t277, ptr %l137
  br label %bb61
bb61:
  %t278 = load ptr, ptr %l131, !tbaa !29
  %t279 = load %"compiler/source:Span", ptr %l132
  %t280 = load %"compiler/diagmsg:Msg", ptr %l137
  %t281 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t278, %"compiler/source:Span" %t279, %"compiler/diagmsg:Msg" %t280)
  store i64 %t281, ptr %l138
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s6)
  store i1 false, ptr %rv
  br label %ret
bb63:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/check:Checker", ptr %t283, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !29
  store ptr %t286, ptr %l141, !tbaa !29
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/check:Checker", ptr %t287, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !29
  %t292 = getelementptr %"compiler/generic:Program", ptr %t290, i32 0, i32 2
  %t293 = load i32, ptr %l2, !tbaa !23
  %t296 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t292, i32 %t293)
  store i32 %t296, ptr %l146
  br label %bb64
bb64:
  %t297 = load ptr, ptr %l141, !tbaa !29
  %t298 = load i32, ptr %l146, !tbaa !23
  %t299 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t297, i32 %t298)
  store i64 %t299, ptr %l147
  br label %bb65
bb65:
  %t300 = load i64, ptr %l147, !tbaa !24
  store i64 %t300, ptr %l9, !tbaa !24
  %t301 = load i64, ptr %l9, !tbaa !24
  %t302 = load i64, ptr %l4, !tbaa !24
  %t305 = icmp ne i64 %t301, %t302
  br i1 %t305, label %bb66, label %bb67
bb66:
  %t307 = load i1, ptr %l5, !tbaa !21
  br i1 %t307, label %bb68, label %bb69
bb67:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb72
bb68:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/check:Checker", ptr %t309, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = getelementptr %"compiler/generic:Program", ptr %t312, i32 0, i32 0
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t317 = getelementptr %"compiler/load:Loader", ptr %t315, i32 0, i32 10
  %t318 = load i64, ptr %l9, !tbaa !24
  %t321 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t317, i64 %t318)
  store ptr %t321, ptr %l159
  br label %bb70
bb69:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb71
bb70:
  %t322 = load ptr, ptr %l159, !tbaa !29
  %t324 = getelementptr %"compiler/load:Module", ptr %t322, i32 0, i32 3
  %t325 = load i1, ptr %t324, !tbaa !21
  store i1 %t325, ptr %l153, !tbaa !21
  br label %bb71
bb71:
  %t327 = load i1, ptr %l153, !tbaa !21
  %t328 = xor i1 %t327, true
  store i1 %t328, ptr %l151, !tbaa !21
  br label %bb72
bb72:
  %t330 = load i1, ptr %l151, !tbaa !21
  br i1 %t330, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s7
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l163, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t332, ptr %l164
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l2, !tbaa !23
  %t337 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t333, i32 %t334)
  store { i64, ptr } %t337, ptr %l167
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t338 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 0
  %t340 = extractvalue { i64, ptr } %t338, 1
  %t341 = mul i64 %t339, 1
  %t342 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t341)
  call void @llvm.memcpy.p0.p0.i64(ptr %t342, ptr %t340, i64 %t341, i1 false)
  %t343 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t342, 1
  %t346 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerElsewhere(ptr %s7, ptr %v0, { i64, ptr } %t344)
  store %"compiler/diagmsg:Msg" %t346, ptr %l169
  br label %bb76
bb76:
  %t347 = load ptr, ptr %l163, !tbaa !29
  %t348 = load %"compiler/source:Span", ptr %l164
  %t349 = load %"compiler/diagmsg:Msg", ptr %l169
  %t350 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t347, %"compiler/source:Span" %t348, %"compiler/diagmsg:Msg" %t349)
  store i64 %t350, ptr %l170
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s7)
  store i1 false, ptr %rv
  br label %ret
bb78:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i64, ptr %l1, !tbaa !24
  %t354 = load i32, ptr %l2, !tbaa !23
  %t355 = load %"compiler/source:Span", ptr %l3
  %t360 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerWritten(ptr %v0, ptr %t352, i64 %t353, i32 %t354, %"compiler/source:Span" %t355)
  store i1 %t360, ptr %l176
  br label %bb79
bb79:
  %t361 = load i1, ptr %l176, !tbaa !21
  store i1 %t361, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyField(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i32, ptr }
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca i64
  %l38 = alloca { i64, ptr }
  %l44 = alloca { i32, ptr }
  %l52 = alloca ptr
  %l53 = alloca i1
  %l55 = alloca %"compiler/source:Span"
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l60 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca i1
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/diagmsg:Msg"
  %l69 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca i1
  %l87 = alloca %"compiler/source:Span"
  %l92 = alloca %"compiler/diagmsg:Msg"
  %l94 = alloca i32
  %l99 = alloca i64
  %l102 = alloca i1
  %l106 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l112 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %l117 = alloca i32
  %l121 = alloca ptr
  %l122 = alloca i1
  %l125 = alloca %"compiler/source:Span"
  %l129 = alloca ptr
  %l132 = alloca { i64, ptr }
  %l133 = alloca %"compiler/diagmsg:Msg"
  %l137 = alloca { i64, ptr }
  %l138 = alloca %"compiler/diagmsg:Msg"
  %l140 = alloca i32
  %l150 = alloca i1
  %l153 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca i64
  %l163 = alloca { i64, ptr }
  %l165 = alloca %"compiler/diagmsg:Msg"
  %l167 = alloca i32
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t10 = alloca { i64, [4 x i64] }, align 8
  %t28 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/check:fieldSet", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l21, !tbaa !24
  %t9 = load %"compiler/source:Span", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t10
  %t11 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 0
  store i64 0, ptr %t11
  %t13 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t9, 0
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  store { %"compiler/source:Span" } %t13, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %t10
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t15, ptr %t17
  store ptr %t17, ptr %l24, !tbaa !29
  %t18 = load i64, ptr %l21, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l21, !tbaa !24
  %t22 = icmp sle i64 %t21, 1152921504606846975
  br i1 %t22, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_7e33472f03e5a723_adcfc8d4e22973ef)
  unreachable
bb3:
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t25)
  %t27 = load ptr, ptr %l24, !tbaa !29
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, %t24
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr ptr, ptr %t26, i64 %t32
  store ptr %t27, ptr %t34
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t26, 1
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t38, ptr %lp6
  %t40 = load ptr, ptr %lp6
  store { i64, ptr } %t37, ptr %t40, !tbaa !27
  %t41 = load i64, ptr %l5, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_7e33472f03e5a723_adcfc8d4e22973ef)
  unreachable
bb5:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = mul i64 %t45, 1
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  store i1 false, ptr %l9, !tbaa !21
  store { i64, ptr } %a2, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l12, !tbaa !24
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d27f09f1ed434aae_8d18f82803f9a31a)
  unreachable
bb7:
  %t57 = load i64, ptr %l11, !tbaa !24
  %t58 = load i64, ptr %l12, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb8, label %bb9
bb8:
  br label %bb70
bb9:
  br label %bb10
bb10:
  %t65 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t65, ptr %l38, !tbaa !27
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr ptr, ptr %t69, i64 %t66
  %t71 = load ptr, ptr %t70, !tbaa !39
  store ptr %t71, ptr %l13, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l13, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t79 = call { i32, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eitemOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t73, ptr %t74, ptr %t75)
  store { i32, ptr } %t79, ptr %l44
  br label %bb11
bb11:
  %t80 = load { i32, ptr }, ptr %l44
  store { i32, ptr } %t80, ptr %l14
  %t81 = getelementptr { i32, ptr }, ptr %l14, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l15, !tbaa !23
  %t84 = getelementptr { i32, ptr }, ptr %l14, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l16, !tbaa !29
  %t87 = load i32, ptr %l15, !tbaa !23
  %t89 = icmp eq i32 %t87, 0
  br i1 %t89, label %bb12, label %bb13
bb12:
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/check:fieldSet", ptr %t91, i32 0, i32 1
  %t94 = load i32, ptr %t93, !tbaa !23
  %t96 = icmp sge i32 %t94, 0
  br i1 %t96, label %bb14, label %bb15
bb13:
  br label %bb33
bb14:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l52, !tbaa !29
  %t99 = load i1, ptr %l4, !tbaa !21
  store i1 %t99, ptr %l53, !tbaa !21
  %t100 = load ptr, ptr %l13, !tbaa !29
  %t102 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t100)
  store %"compiler/source:Span" %t102, ptr %l55
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t105 = getelementptr %"compiler/check:fieldSet", ptr %t103, i32 0, i32 2
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStructPatPositional(ptr %v2, ptr %v0, { i64, ptr } %t106)
  store %"compiler/diagmsg:Msg" %t108, ptr %l58
  br label %bb17
bb17:
  %t109 = load ptr, ptr %l52, !tbaa !29
  %t110 = load i1, ptr %l53, !tbaa !21
  %t111 = load %"compiler/source:Span", ptr %l55
  %t113 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t109, i1 %t110, %"compiler/source:Span" %t111, ptr %l58)
  store i32 %t113, ptr %l60
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb19, label %ok.115, !prof !99
ok.115:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t116 = load i32, ptr %l60, !tbaa !23
  %t117 = lshr i32 %t116, 16
  %t118 = and i32 %t116, 65535
  %t119 = icmp eq i32 %t117, 1
  %t120 = select i1 %t119, i32 1, i32 0
  %t121 = icmp eq i32 %t116, 0
  %t122 = shl i32 %t120, 16
  %t123 = or i32 %t122, %t118
  %t124 = select i1 %t121, i32 0, i32 %t123
  call void @__olang_scope_close(ptr %s0)
  %t126 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t124, 0
  store { i32, { i64, ptr } } %t126, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t127 = load i1, ptr %l9, !tbaa !21
  br i1 %t127, label %bb22, label %bb23
bb22:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l63, !tbaa !29
  %t130 = load i1, ptr %l4, !tbaa !21
  store i1 %t130, ptr %l64, !tbaa !21
  %t131 = load ptr, ptr %l13, !tbaa !29
  %t133 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t131)
  store %"compiler/source:Span" %t133, ptr %l66
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t134 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatPositionAfterName(ptr %v0)
  store %"compiler/diagmsg:Msg" %t134, ptr %l67
  br label %bb25
bb25:
  %t135 = load ptr, ptr %l63, !tbaa !29
  %t136 = load i1, ptr %l64, !tbaa !21
  %t137 = load %"compiler/source:Span", ptr %l66
  %t139 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t135, i1 %t136, %"compiler/source:Span" %t137, ptr %l67)
  store i32 %t139, ptr %l69
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb27, label %ok.141, !prof !99
ok.141:
  br label %bb26
bb26:
  br label %bb28
bb27:
  %t142 = load i32, ptr %l69, !tbaa !23
  %t143 = lshr i32 %t142, 16
  %t144 = and i32 %t142, 65535
  %t145 = icmp eq i32 %t143, 1
  %t146 = select i1 %t145, i32 1, i32 0
  %t147 = icmp eq i32 %t142, 0
  %t148 = shl i32 %t146, 16
  %t149 = or i32 %t148, %t144
  %t150 = select i1 %t147, i32 0, i32 %t149
  call void @__olang_scope_close(ptr %s0)
  %t152 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t150, 0
  store { i32, { i64, ptr } } %t152, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t153 = load i64, ptr %l8, !tbaa !24
  %t154 = load i64, ptr %l5, !tbaa !24
  %t157 = icmp slt i64 %t153, %t154
  br i1 %t157, label %bb30, label %bb31
bb30:
  %t159 = load i64, ptr %l8, !tbaa !24
  %t160 = load ptr, ptr %l13, !tbaa !29
  %t162 = load ptr, ptr %lp6
  %t164 = getelementptr { i64, ptr }, ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr ptr, ptr %t165, i64 %t159
  store ptr %t160, ptr %t166, !tbaa !39
  %t167 = load i64, ptr %l8, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i1, ptr %t170, i64 %t167
  store i1 true, ptr %t171, !tbaa !31
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l8, !tbaa !24
  br label %bb69
bb33:
  store i1 true, ptr %l9, !tbaa !21
  %t176 = load ptr, ptr %l3, !tbaa !29
  %t178 = getelementptr %"compiler/check:fieldSet", ptr %t176, i32 0, i32 3
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t183 = icmp sgt i64 %t181, 0
  br i1 %t183, label %bb34, label %bb35
bb34:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l83, !tbaa !29
  %t186 = load i1, ptr %l4, !tbaa !21
  store i1 %t186, ptr %l84, !tbaa !21
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l13, !tbaa !29
  %t191 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %t187, ptr %t188)
  store %"compiler/source:Span" %t191, ptr %l87
  br label %bb36
bb35:
  br label %bb41
bb36:
  %t192 = load ptr, ptr %l3, !tbaa !29
  %t194 = getelementptr %"compiler/check:fieldSet", ptr %t192, i32 0, i32 2
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  %t196 = load ptr, ptr %l3, !tbaa !29
  %t198 = getelementptr %"compiler/check:fieldSet", ptr %t196, i32 0, i32 3
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  %t202 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWholeCaseNamed(ptr %v2, ptr %v2, ptr %v0, { i64, ptr } %t195, { i64, ptr } %t199)
  store %"compiler/diagmsg:Msg" %t202, ptr %l92
  br label %bb37
bb37:
  %t203 = load ptr, ptr %l83, !tbaa !29
  %t204 = load i1, ptr %l84, !tbaa !21
  %t205 = load %"compiler/source:Span", ptr %l87
  %t207 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t203, i1 %t204, %"compiler/source:Span" %t205, ptr %l92)
  store i32 %t207, ptr %l94
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb39, label %ok.209, !prof !99
ok.209:
  br label %bb38
bb38:
  br label %bb40
bb39:
  %t210 = load i32, ptr %l94, !tbaa !23
  %t211 = lshr i32 %t210, 16
  %t212 = and i32 %t210, 65535
  %t213 = icmp eq i32 %t211, 1
  %t214 = select i1 %t213, i32 1, i32 0
  %t215 = icmp eq i32 %t210, 0
  %t216 = shl i32 %t214, 16
  %t217 = or i32 %t216, %t212
  %t218 = select i1 %t215, i32 0, i32 %t217
  call void @__olang_scope_close(ptr %s0)
  %t220 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t218, 0
  store { i32, { i64, ptr } } %t220, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t221 = load ptr, ptr %l3, !tbaa !29
  %t223 = getelementptr %"compiler/check:fieldSet", ptr %t221, i32 0, i32 0
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  %t225 = load i32, ptr %l15, !tbaa !23
  %t228 = call i64 @compiler_2fcheck_2enameIndex(ptr %v2, { i64, ptr } %t224, i32 %t225)
  store i64 %t228, ptr %l99
  br label %bb42
bb42:
  %t229 = load i64, ptr %l99, !tbaa !24
  store i64 %t229, ptr %l17, !tbaa !24
  %t230 = load i64, ptr %l17, !tbaa !24
  %t232 = icmp slt i64 %t230, 0
  br i1 %t232, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb46
bb44:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l3, !tbaa !29
  %t236 = load i32, ptr %l15, !tbaa !23
  %t240 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldReadable(ptr %v0, ptr %v2, ptr %t234, ptr %t235, i32 %t236)
  store i1 %t240, ptr %l106
  br label %bb45
bb45:
  %t241 = load i1, ptr %l106, !tbaa !21
  %t242 = xor i1 %t241, true
  store i1 %t242, ptr %l102, !tbaa !21
  br label %bb46
bb46:
  %t244 = load i1, ptr %l102, !tbaa !21
  br i1 %t244, label %bb47, label %bb48
bb47:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l108, !tbaa !29
  %t246 = load i1, ptr %l4, !tbaa !21
  store i1 %t246, ptr %l109, !tbaa !21
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l13, !tbaa !29
  %t251 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %t247, ptr %t248)
  store %"compiler/source:Span" %t251, ptr %l112
  br label %bb49
bb48:
  br label %bb54
bb49:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load ptr, ptr %l3, !tbaa !29
  %t254 = load i32, ptr %l15, !tbaa !23
  %t258 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoItemField(ptr %v0, ptr %v2, ptr %v0, ptr %t252, ptr %t253, i32 %t254)
  store ptr %t258, ptr %l116
  br label %bb50
bb50:
  %t259 = load ptr, ptr %l108, !tbaa !29
  %t260 = load i1, ptr %l109, !tbaa !21
  %t261 = load %"compiler/source:Span", ptr %l112
  %t262 = load ptr, ptr %l116, !tbaa !29
  %t263 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t259, i1 %t260, %"compiler/source:Span" %t261, ptr %t262)
  store i32 %t263, ptr %l117
  %t264 = icmp ne i32 %t263, 0
  br i1 %t264, label %bb52, label %ok.265, !prof !99
ok.265:
  br label %bb51
bb51:
  br label %bb53
bb52:
  %t266 = load i32, ptr %l117, !tbaa !23
  %t267 = lshr i32 %t266, 16
  %t268 = and i32 %t266, 65535
  %t269 = icmp eq i32 %t267, 1
  %t270 = select i1 %t269, i32 1, i32 0
  %t271 = icmp eq i32 %t266, 0
  %t272 = shl i32 %t270, 16
  %t273 = or i32 %t272, %t268
  %t274 = select i1 %t271, i32 0, i32 %t273
  call void @__olang_scope_close(ptr %s0)
  %t276 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t274, 0
  store { i32, { i64, ptr } } %t276, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t277 = load i64, ptr %l17, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr i1, ptr %t280, i64 %t277
  %t282 = load i1, ptr %t281, !tbaa !31
  br i1 %t282, label %bb55, label %bb56
bb55:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l121, !tbaa !29
  %t285 = load i1, ptr %l4, !tbaa !21
  store i1 %t285, ptr %l122, !tbaa !21
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load ptr, ptr %l13, !tbaa !29
  %t290 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %t286, ptr %t287)
  store %"compiler/source:Span" %t290, ptr %l125
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t291 = load i64, ptr %l17, !tbaa !24
  %t292 = load i64, ptr %l8, !tbaa !24
  %t295 = icmp slt i64 %t291, %t292
  br i1 %t295, label %bb58, label %bb59
bb58:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i32, ptr %l15, !tbaa !23
  %t301 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t297, i32 %t298)
  store { i64, ptr } %t301, ptr %l132
  br label %bb60
bb59:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i32, ptr %l15, !tbaa !23
  %t306 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t302, i32 %t303)
  store { i64, ptr } %t306, ptr %l137
  br label %bb62
bb60:
  %t307 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t308 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldBothWays(ptr %v0, ptr %v0, { i64, ptr } %t307)
  store %"compiler/diagmsg:Msg" %t308, ptr %l133
  br label %bb61
bb61:
  %t309 = load %"compiler/diagmsg:Msg", ptr %l133
  %t310 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/diagmsg:Msg" %t309, ptr %t310
  store ptr %t310, ptr %l129, !tbaa !29
  br label %bb64
bb62:
  %t312 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t313 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldTwice(ptr %v0, ptr %v0, { i64, ptr } %t312)
  store %"compiler/diagmsg:Msg" %t313, ptr %l138
  br label %bb63
bb63:
  %t314 = load %"compiler/diagmsg:Msg", ptr %l138
  %t315 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/diagmsg:Msg" %t314, ptr %t315
  store ptr %t315, ptr %l129, !tbaa !29
  br label %bb64
bb64:
  %t317 = load ptr, ptr %l121, !tbaa !29
  %t318 = load i1, ptr %l122, !tbaa !21
  %t319 = load %"compiler/source:Span", ptr %l125
  %t320 = load ptr, ptr %l129, !tbaa !29
  %t321 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t317, i1 %t318, %"compiler/source:Span" %t319, ptr %t320)
  store i32 %t321, ptr %l140
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb66, label %ok.323, !prof !99
ok.323:
  br label %bb65
bb65:
  br label %bb67
bb66:
  %t324 = load i32, ptr %l140, !tbaa !23
  %t325 = lshr i32 %t324, 16
  %t326 = and i32 %t324, 65535
  %t327 = icmp eq i32 %t325, 1
  %t328 = select i1 %t327, i32 1, i32 0
  %t329 = icmp eq i32 %t324, 0
  %t330 = shl i32 %t328, 16
  %t331 = or i32 %t330, %t326
  %t332 = select i1 %t329, i32 0, i32 %t331
  call void @__olang_scope_close(ptr %s0)
  %t334 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t332, 0
  store { i32, { i64, ptr } } %t334, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t335 = load i64, ptr %l17, !tbaa !24
  %t336 = load ptr, ptr %l16, !tbaa !29
  %t338 = load ptr, ptr %lp6
  %t340 = getelementptr { i64, ptr }, ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr ptr, ptr %t341, i64 %t335
  store ptr %t336, ptr %t342, !tbaa !39
  %t343 = load i64, ptr %l17, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr i1, ptr %t346, i64 %t343
  store i1 true, ptr %t347, !tbaa !31
  br label %bb69
bb69:
  %t348 = load i64, ptr %l11, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l11, !tbaa !24
  br label %bb7
bb70:
  %t352 = load i64, ptr %l8, !tbaa !24
  %t353 = load i64, ptr %l5, !tbaa !24
  %t356 = icmp sgt i64 %t352, %t353
  br i1 %t356, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb76
bb72:
  %t358 = load i1, ptr %l9, !tbaa !21
  %t360 = xor i1 %t358, true
  br i1 %t360, label %bb73, label %bb74
bb73:
  %t362 = load i64, ptr %l8, !tbaa !24
  %t363 = load i64, ptr %l5, !tbaa !24
  %t366 = icmp ne i64 %t362, %t363
  store i1 %t366, ptr %l153, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb75
bb75:
  %t368 = load i1, ptr %l153, !tbaa !21
  store i1 %t368, ptr %l150, !tbaa !21
  br label %bb76
bb76:
  %t369 = load i1, ptr %l150, !tbaa !21
  br i1 %t369, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s11
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l157, !tbaa !29
  %t371 = load i1, ptr %l4, !tbaa !21
  store i1 %t371, ptr %l158, !tbaa !21
  %t372 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t372, ptr %l159
  %t373 = load i64, ptr %l5, !tbaa !24
  store i64 %t373, ptr %l160, !tbaa !24
  %t374 = load i64, ptr %l5, !tbaa !24
  %t376 = icmp eq i64 %t374, 1
  br i1 %t376, label %bb79, label %bb80
bb78:
  br label %bb86
bb79:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l163, !tbaa !27
  br label %bb81
bb80:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l163, !tbaa !27
  br label %bb81
bb81:
  %t378 = load i64, ptr %l8, !tbaa !24
  %t379 = load i64, ptr %l160, !tbaa !24
  %t380 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t382 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s11, ptr %v0, i64 %t379, { i64, ptr } %t380, i64 %t378)
  store %"compiler/diagmsg:Msg" %t382, ptr %l165
  br label %bb82
bb82:
  %t383 = load ptr, ptr %l157, !tbaa !29
  %t384 = load i1, ptr %l158, !tbaa !21
  %t385 = load %"compiler/source:Span", ptr %l159
  %t387 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v0, ptr %t383, i1 %t384, %"compiler/source:Span" %t385, ptr %l165)
  store i32 %t387, ptr %l167
  %t388 = icmp ne i32 %t387, 0
  br i1 %t388, label %bb84, label %ok.389, !prof !99
ok.389:
  br label %bb83
bb83:
  br label %bb85
bb84:
  %t390 = load i32, ptr %l167, !tbaa !23
  %t391 = lshr i32 %t390, 16
  %t392 = and i32 %t390, 65535
  %t393 = icmp eq i32 %t391, 1
  %t394 = select i1 %t393, i32 1, i32 0
  %t395 = icmp eq i32 %t390, 0
  %t396 = shl i32 %t394, 16
  %t397 = or i32 %t396, %t392
  %t398 = select i1 %t395, i32 0, i32 %t397
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t400 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t398, 0
  store { i32, { i64, ptr } } %t400, ptr %rv
  br label %ret
bb85:
  call void @__olang_scope_close(ptr %s11)
  br label %bb86
bb86:
  %t401 = load ptr, ptr %lp6
  %t402 = load { i64, ptr }, ptr %t401, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t404 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t402, 1
  store { i32, { i64, ptr } } %t404, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l36 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espreadArgs(ptr %v0, ptr %v2, ptr %v0, ptr %t1, { i64, ptr } %t2)
  store { i64, ptr } %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 168
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 168
  store i1 false, ptr %t14, !tbaa !21
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t15, %"compiler/source:Span" %t16)
  store ptr %t19, ptr %l20
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load ptr, ptr %l20, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 49
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l5, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 50
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l6
  %t31 = load i32, ptr %l4, !tbaa !23
  %t33 = load %"compiler/source:Span", ptr %l1
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 49
  store i32 %t31, ptr %t39, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 50
  store %"compiler/source:Span" %t33, ptr %t44
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = load i32, ptr %l4, !tbaa !23
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecall1(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %t45, %"compiler/source:Span" %t46, ptr %a2, { i64, ptr } %t48, i32 %t49)
  store ptr %t55, ptr %l36
  br label %bb6
bb6:
  %t56 = load ptr, ptr %l36, !tbaa !29
  %t57 = load i32, ptr %l5, !tbaa !23
  %t59 = load %"compiler/source:Span", ptr %l6
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 49
  store i32 %t57, ptr %t65, !tbaa !23
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 50
  store %"compiler/source:Span" %t59, ptr %t70
  store ptr %t56, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i1
  %l69 = alloca i32
  %l73 = alloca i1
  %l76 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t13 = trunc i64 21 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l23
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l18, !tbaa !29
  %t35 = load i32, ptr %l23, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t34, i32 %t35)
  store { i64, ptr } %t36, ptr %l24
  br label %bb5
bb5:
  %t37 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t40 = icmp sgt i64 %t38, 0
  store i1 %t40, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t42 = load i1, ptr %l15, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l30, !tbaa !29
  %t61 = load i32, ptr %l35, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t60, i32 %t61)
  store { i64, ptr } %t62, ptr %l36
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t63, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  br label %bb30
bb14:
  br label %bb15
bb15:
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t76, ptr %l43, !tbaa !27
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i32, ptr %t80, i64 %t77
  %t82 = load i32, ptr %t81, !tbaa !33
  store i32 %t82, ptr %l5, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l5, !tbaa !23
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l48
  br label %bb16
bb16:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb25
bb18:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l5, !tbaa !23
  %t94 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l52
  br label %bb19
bb19:
  %t95 = load i1, ptr %l52, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l54, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l5, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l59
  br label %bb22
bb21:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb24
bb22:
  %t107 = load ptr, ptr %l54, !tbaa !29
  %t108 = load i32, ptr %l59, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t107, i32 %t108, i64 0)
  store i1 %t109, ptr %l60
  br label %bb23
bb23:
  %t110 = load i1, ptr %l60, !tbaa !21
  store i1 %t110, ptr %l53, !tbaa !21
  br label %bb24
bb24:
  %t111 = load i1, ptr %l53, !tbaa !21
  store i1 %t111, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t112 = load i1, ptr %l49, !tbaa !21
  %t113 = xor i1 %t112, true
  br i1 %t113, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t116 = load i64, ptr %l3, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l3, !tbaa !24
  br label %bb12
bb30:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l1, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l69
  br label %bb31
bb31:
  %t130 = load i32, ptr %l69, !tbaa !23
  store i32 %t130, ptr %l6, !tbaa !23
  %t131 = load i32, ptr %l6, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t135 = icmp eq i32 %t131, %t132
  br i1 %t135, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb35
bb33:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l6, !tbaa !23
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t137, i32 %t138)
  store i1 %t141, ptr %l76
  br label %bb34
bb34:
  %t142 = load i1, ptr %l76, !tbaa !21
  store i1 %t142, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t143 = load i1, ptr %l73, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 0
  %t4 = getelementptr %"compiler/source:Span", ptr %t3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:Catch", ptr %t6, i32 0, i32 0
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  %t12 = add i32 %t10, 5
  %t15 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t5, i32 %t12)
  store %"compiler/source:Span" %t15, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t16 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtPayload(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca %"compiler/typed:Local"
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca i32
  %l23 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l31 = alloca i32
  %l35 = alloca { i64, ptr }
  %l39 = alloca i32
  %l41 = alloca %"compiler/typed:Make"
  %l56 = alloca ptr
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l61 = alloca i32
  %l65 = alloca ptr
  %l66 = alloca ptr
  %t67 = alloca { i64, [5 x i64] }, align 8
  %t88 = alloca { i64, [4 x i64] }, align 8
  %t101 = alloca { i64, [3 x i64] }, align 8
  %t133 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %l2, !tbaa !24
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/typed:Local" %t10, ptr %l11
  br label %bb2
bb2:
  %t11 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 2
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l3, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %t14, i32 %t15, i64 0)
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 44
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l17
  br label %bb4
bb4:
  %t23 = load i64, ptr %l17, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 44
  store ptr %t26, ptr %l19, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l20, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l21
  %t29 = load i32, ptr %l3, !tbaa !23
  store i32 %t29, ptr %l22, !tbaa !23
  store i32 46, ptr %l23
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  %t32 = load i64, ptr %l2, !tbaa !24
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i64 %t32)
  store ptr %t36, ptr %l27
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l21
  %t39 = load i32, ptr %l22, !tbaa !23
  %t40 = load i32, ptr %l23, !range !{i32 0, i32 52}
  %t41 = load ptr, ptr %l27, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t37, %"compiler/source:Span" %t38, i32 %t39, i32 %t40, ptr %t41, ptr null)
  store ptr %t42, ptr %l28
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l19, !tbaa !29
  %t44 = load ptr, ptr %l28, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t43, ptr %t44)
  br label %bb7
bb7:
  %t45 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t45, ptr %l29
  %t46 = load i32, ptr %l3, !tbaa !23
  store i32 %t46, ptr %l30, !tbaa !23
  store i32 4, ptr %l31
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 44
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t49, i64 %t50)
  store { i64, ptr } %t53, ptr %l35
  br label %bb8
bb8:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t59 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t54, i32 1, %"compiler/source:Span" %t55)
  store i32 %t59, ptr %l39
  br label %bb9
bb9:
  %t60 = load i32, ptr %l31, !range !{i32 0, i32 5}
  %t61 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t62 = load i32, ptr %l39, !tbaa !23
  %t64 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t60, i64 0, { i64, ptr } %t61, ptr null, i32 %t62, i32 0, i1 false)
  store %"compiler/typed:Make" %t64, ptr %l41
  br label %bb10
bb10:
  %t65 = load %"compiler/typed:Make", ptr %l41
  %t66 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t65, ptr %t66
  store { i64, [5 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 0
  store i64 7, ptr %t68
  %t69 = load %"compiler/source:Span", ptr %l29
  %t70 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t69, 0
  %t71 = load i32, ptr %l30, !tbaa !23
  %t72 = insertvalue { %"compiler/source:Span", i32, ptr } %t70, i32 %t71, 1
  %t74 = insertvalue { %"compiler/source:Span", i32, ptr } %t72, ptr %t66, 2
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t74, ptr %t75
  %t76 = load { i64, [5 x i64] }, ptr %t67
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t77, ptr %lp5
  %t79 = load ptr, ptr %lp5
  store { i64, [5 x i64] } %t76, ptr %t79
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l1
  %t82 = load %"compiler/source:Span", ptr %l1
  %t83 = load i32, ptr %l3, !tbaa !23
  %t84 = load i64, ptr %l2, !tbaa !24
  %t86 = trunc i64 %t84 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 0
  store i64 0, ptr %t89
  %t91 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t82, 0
  %t93 = insertvalue { %"compiler/source:Span", i32, i32 } %t91, i32 %t83, 1
  %t95 = insertvalue { %"compiler/source:Span", i32, i32 } %t93, i32 %t86, 2
  %t96 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t95, ptr %t96
  %t97 = load { i64, [4 x i64] }, ptr %t88
  %t99 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t97, ptr %t99
  %t100 = load ptr, ptr %lp5
  store { i64, [3 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 0
  store i64 1, ptr %t102
  %t104 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t81, 0
  %t106 = insertvalue { %"compiler/source:Span", ptr, ptr } %t104, ptr %t99, 1
  %t108 = insertvalue { %"compiler/source:Span", ptr, ptr } %t106, ptr %t100, 2
  %t109 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t108, ptr %t109
  %t110 = load { i64, [3 x i64] }, ptr %t101
  %t112 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t110, ptr %t112
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t80, ptr %t112)
  br label %bb11
bb11:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l56, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t116, ptr %l57
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l58, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t118, ptr %l59
  %t119 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t119, ptr %l60, !tbaa !23
  store i32 47, ptr %l61
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l1
  %t122 = load i64, ptr %l2, !tbaa !24
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t120, %"compiler/source:Span" %t121, i64 %t122)
  store ptr %t126, ptr %l65
  br label %bb12
bb12:
  %t127 = load ptr, ptr %l58, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l59
  %t129 = load i32, ptr %l60, !tbaa !23
  %t130 = load i32, ptr %l61, !range !{i32 0, i32 52}
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t127, %"compiler/source:Span" %t128, i32 %t129, i32 %t130, ptr %t131, ptr null)
  store ptr %t132, ptr %l66
  br label %bb13
bb13:
  store { i64, [3 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t133, i32 0, i32 0
  store i64 2, ptr %t134
  %t135 = load %"compiler/source:Span", ptr %l57
  %t136 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t135, 0
  %t137 = load ptr, ptr %l66, !tbaa !29
  %t138 = insertvalue { %"compiler/source:Span", ptr } %t136, ptr %t137, 1
  %t139 = getelementptr { i64, [3 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t138, ptr %t139
  %t140 = load { i64, [3 x i64] }, ptr %t133
  %t142 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t140, ptr %t142
  %t143 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t143, ptr %t142)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l15 = alloca i32
  %l19 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, ptr }
  %l30 = alloca %"compiler/diagmsg:Msg"
  %l31 = alloca i64
  %l32 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t2, ptr %t3, i32 %t5)
  store ptr %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t10)
  store %"compiler/source:Span" %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l11
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v2, ptr %t13, ptr %t14, %"compiler/source:Span" %t15)
  store ptr %t16, ptr %l12
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l12, !tbaa !29
  store ptr %t17, ptr %l2, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t18)
  store i32 %t21, ptr %l15
  br label %bb4
bb4:
  %t22 = load i32, ptr %l15, !tbaa !23
  store i32 %t22, ptr %l3, !tbaa !23
  %t23 = load i32, ptr %l3, !tbaa !23
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t27 = icmp ne i32 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t33 = icmp ne i32 %t29, %t30
  store i1 %t33, ptr %l19, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t37)
  store %"compiler/source:Span" %t39, ptr %l25
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l28
  br label %bb11
bb11:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %s1, ptr %v0, { i64, ptr } %t51)
  store %"compiler/diagmsg:Msg" %t53, ptr %l30
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l23, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l25
  %t56 = load %"compiler/diagmsg:Msg", ptr %l30
  %t57 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t54, %"compiler/source:Span" %t55, %"compiler/diagmsg:Msg" %t56)
  store i64 %t57, ptr %l31
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l32, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t59)
  store %"compiler/source:Span" %t61, ptr %l34
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l34
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t62, %"compiler/source:Span" %t63)
  store ptr %t64, ptr %l35
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  %t65 = load ptr, ptr %l35, !tbaa !29
  store ptr %t65, ptr %rv
  br label %ret
bb16:
  %t66 = load ptr, ptr %l2, !tbaa !29
  store ptr %t66, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l38 = alloca { i64, ptr }
  %l44 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l61 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Cond", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t16, ptr %t20)
  store i1 %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load i1, ptr %l17, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Cond", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t25, ptr %t29)
  store i1 %t33, ptr %l23
  br label %bb9
bb9:
  %t34 = load i1, ptr %l23, !tbaa !21
  store i1 %t34, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l18, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
bb11:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t37 = load ptr, ptr %l24, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 18}
  %t43 = icmp eq i64 %t41, 13
  store i1 %t43, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb34
bb16:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Match", ptr %t51, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb18, label %bb19
bb18:
  br label %bb26
bb19:
  br label %bb20
bb20:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t68, ptr %l38, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Arm", ptr %t74, i32 0, i32 4
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t76, ptr %t80)
  store i1 %t83, ptr %l44
  br label %bb21
bb21:
  %t84 = load i1, ptr %l44, !tbaa !21
  br i1 %t84, label %bb22, label %bb23
bb22:
  store i1 true, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l5, !tbaa !24
  br label %bb17
bb26:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Match", ptr %t90, i32 0, i32 2
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = icmp eq ptr %t93, null
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb27, label %bb28
bb27:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l53, !tbaa !29
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Match", ptr %t100, i32 0, i32 2
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = icmp eq ptr %t103, null
  br i1 %t105, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb33
bb29:
  call void @__olang_check_failed(ptr @olang_loc_2ede4c4ba9909085_e989644cd371c6b1)
  unreachable
bb30:
  br label %bb31
bb31:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Match", ptr %t107, i32 0, i32 2
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Arm", ptr %t110, i32 0, i32 4
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t115 = load ptr, ptr %l53, !tbaa !29
  %t117 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t115, ptr %t114)
  store i1 %t117, ptr %l61
  br label %bb32
bb32:
  %t118 = load i1, ptr %l61, !tbaa !21
  store i1 %t118, ptr %l52, !tbaa !21
  br label %bb33
bb33:
  %t119 = load i1, ptr %l52, !tbaa !21
  store i1 %t119, ptr %rv
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %rv
  br label %ret
bb38:
  call void @__olang_check_failed(ptr @olang_loc_7d19fc126307206d_86c002714b5cfe09)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i32
  %l10 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l10
  br label %bb4
bb3:
  %t17 = load i32, ptr %l1, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  br label %bb5
bb4:
  %t19 = load i32, ptr %l10, !tbaa !23
  store i32 %t19, ptr %l5, !tbaa !23
  br label %bb5
bb5:
  %t20 = load i32, ptr %l5, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropAxes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l24 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaxisValue(ptr %v0, ptr %v1, ptr %s2, ptr %t23, ptr %t21)
  store ptr %t27, ptr %l19
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb1
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t32, %"compiler/source:Span" %a1)
  store ptr %t36, ptr %l24
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l24, !tbaa !29
  store ptr %t37, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropElse(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l22 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 5
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l6, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb20
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/ast:If", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_986dcc23e228494c_5356e2d9a8a4da00)
  unreachable
bb10:
  br label %bb11
bb11:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:If", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Branch", ptr %t30, i32 0, i32 2
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = icmp sge i64 %t34, 0
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 4
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l22, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:If", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  br i1 %t53, label %bb14, label %bb15
bb13:
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_986dcc23e228494c_5356e2d9a8a4da00)
  unreachable
bb15:
  br label %bb16
bb16:
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t57 = getelementptr %"compiler/ast:If", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Branch", ptr %t58, i32 0, i32 2
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCutOff(ptr %v0, ptr %t63, i64 %t62)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/ast:If", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropElse(ptr %v0, ptr %v1, ptr %t65, ptr %t69)
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b95c45f94d7269e2_7c3a0c34c4e08fe6)
  unreachable
bb25:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca i1
  %l55 = alloca i1
  %l56 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i1
  %l72 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l97 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
bb16:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb17, label %bb18
bb17:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb18
bb18:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb19, label %bb20
bb19:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb26
bb21:
  %t46 = load i1, ptr %l2, !tbaa !21
  br i1 %t46, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb25
bb23:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store i1 %t53, ptr %l33
  br label %bb24
bb24:
  %t54 = load i1, ptr %l33, !tbaa !21
  store i1 %t54, ptr %l29, !tbaa !21
  br label %bb25
bb25:
  %t55 = load i1, ptr %l29, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
bb26:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb27, label %bb28
bb27:
  %t60 = load ptr, ptr %l34, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 8}
  %t63 = icmp eq i64 %t61, 3
  store i1 %t63, ptr %l35, !tbaa !21
  br label %bb28
bb28:
  %t64 = load i1, ptr %l35, !tbaa !21
  br i1 %t64, label %bb29, label %bb30
bb29:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t73 = load i1, ptr %l2, !tbaa !21
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t71, ptr %t72, i1 %t73)
  store i1 %t77, ptr %l43
  br label %bb32
bb32:
  %t78 = load i1, ptr %l43, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
bb33:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t80 = load ptr, ptr %l44, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb34, label %bb35
bb34:
  %t83 = load ptr, ptr %l44, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 8}
  %t86 = icmp eq i64 %t84, 4
  store i1 %t86, ptr %l45, !tbaa !21
  br label %bb35
bb35:
  %t87 = load i1, ptr %l45, !tbaa !21
  br i1 %t87, label %bb36, label %bb37
bb36:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t90, i32 0, i32 2
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l5, !tbaa !29
  br label %bb38
bb37:
  br label %bb55
bb38:
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Elem", ptr %t94, i32 0, i32 2
  %t97 = load i32, ptr %t96, !range !{i32 0, i32 4}
  %t99 = trunc i64 1 to i32
  %t100 = icmp eq i32 %t97, %t99
  br i1 %t100, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb46
bb40:
  %t102 = load i1, ptr %l2, !tbaa !21
  br i1 %t102, label %bb41, label %bb42
bb41:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l56, !tbaa !29
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Elem", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t108)
  store i32 %t110, ptr %l59
  br label %bb43
bb42:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb45
bb43:
  %t111 = load ptr, ptr %l56, !tbaa !29
  %t112 = load i32, ptr %l59, !tbaa !23
  %t113 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t113, ptr %l60
  br label %bb44
bb44:
  %t114 = load i1, ptr %l60, !tbaa !21
  store i1 %t114, ptr %l55, !tbaa !21
  br label %bb45
bb45:
  %t115 = load i1, ptr %l55, !tbaa !21
  store i1 %t115, ptr %l53, !tbaa !21
  br label %bb46
bb46:
  %t116 = load i1, ptr %l53, !tbaa !21
  br i1 %t116, label %bb47, label %bb48
bb47:
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Elem", ptr %t119, i32 0, i32 0
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t123 = load i1, ptr %l2, !tbaa !21
  %t127 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t118, ptr %t122, i1 %t123)
  store i1 %t127, ptr %l66
  br label %bb50
bb50:
  %t128 = load i1, ptr %l66, !tbaa !21
  br i1 %t128, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb54
bb52:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l5, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Elem", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t137 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t129, ptr %t133)
  store i1 %t137, ptr %l72
  br label %bb53
bb53:
  %t138 = load i1, ptr %l72, !tbaa !21
  store i1 %t138, ptr %l67, !tbaa !21
  br label %bb54
bb54:
  %t139 = load i1, ptr %l67, !tbaa !21
  store i1 %t139, ptr %rv
  br label %ret
bb55:
  %t140 = load ptr, ptr %l1, !tbaa !29
  store ptr %t140, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t141 = load ptr, ptr %l73, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb56, label %bb57
bb56:
  %t144 = load ptr, ptr %l73, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 8}
  %t147 = icmp eq i64 %t145, 5
  store i1 %t147, ptr %l74, !tbaa !21
  br label %bb57
bb57:
  %t148 = load i1, ptr %l74, !tbaa !21
  br i1 %t148, label %bb58, label %bb59
bb58:
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr { i64, [4 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t151, i32 0, i32 2
  %t153 = load ptr, ptr %t152
  store ptr %t153, ptr %l6, !tbaa !29
  br label %bb60
bb59:
  br label %bb65
bb60:
  %t155 = load ptr, ptr %l6, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Payload", ptr %t155, i32 0, i32 2
  %t158 = load i32, ptr %t157, !range !{i32 0, i32 4}
  %t160 = trunc i64 1 to i32
  %t161 = icmp eq i32 %t158, %t160
  br i1 %t161, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb64
bb62:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l6, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Payload", ptr %t164, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t168 = load i1, ptr %l2, !tbaa !21
  %t172 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t163, ptr %t167, i1 %t168)
  store i1 %t172, ptr %l87
  br label %bb63
bb63:
  %t173 = load i1, ptr %l87, !tbaa !21
  store i1 %t173, ptr %l82, !tbaa !21
  br label %bb64
bb64:
  %t174 = load i1, ptr %l82, !tbaa !21
  store i1 %t174, ptr %rv
  br label %ret
bb65:
  %t175 = load ptr, ptr %l1, !tbaa !29
  store ptr %t175, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t176 = load ptr, ptr %l88, !tbaa !29
  %t177 = icmp ne ptr %t176, null
  br i1 %t177, label %bb66, label %bb67
bb66:
  %t179 = load ptr, ptr %l88, !tbaa !29
  %t180 = load i64, ptr %t179, !range !{i64 0, i64 8}
  %t182 = icmp eq i64 %t180, 6
  store i1 %t182, ptr %l89, !tbaa !21
  br label %bb67
bb67:
  %t183 = load i1, ptr %l89, !tbaa !21
  br i1 %t183, label %bb68, label %bb69
bb68:
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t186, i32 0, i32 2
  %t188 = load ptr, ptr %t187
  store ptr %t188, ptr %l7, !tbaa !29
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load ptr, ptr %l7, !tbaa !29
  %t195 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t190, ptr %t191)
  store i1 %t195, ptr %l97
  br label %bb71
bb71:
  %t196 = load i1, ptr %l97, !tbaa !21
  store i1 %t196, ptr %rv
  br label %ret
bb72:
  call void @__olang_check_failed(ptr @olang_loc_a395790432891bd8_5a5437b807a0153c)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i64
  %l10 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l42 = alloca i64
  %t22 = alloca { i64, [1 x i64] }, align 8
  %t46 = alloca { i64, [3 x i64] }, align 8
  %t70 = alloca { i64, [1 x i64] }, align 8
  %t94 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  store i1 %t10, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l13, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:ForIn", ptr %t14, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  store i32 %t17, ptr %l15, !tbaa !23
  %t18 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t18, ptr %l16
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t19)
  store i32 %t21, ptr %l18
  br label %bb6
bb5:
  br label %bb10
bb6:
  store { i64, [1 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [1 x i64] }, ptr %t22
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = load %"compiler/source:Span", ptr %l16
  %t28 = load i32, ptr %l18, !tbaa !23
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t25, i32 %t26, %"compiler/source:Span" %t27, i32 %t28, i32 1, { i64, [1 x i64] } %t24)
  store i64 %t31, ptr %l21
  br label %bb7
bb7:
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t34, ptr %l23
  %t37 = trunc i64 %t32 to i32
  store i32 %t37, ptr %l26, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load i64, ptr %l3, !tbaa !24
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t39, %"compiler/source:Span" %t40, i64 %t41)
  store ptr %t45, ptr %l30
  br label %bb8
bb8:
  store { i64, [3 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 0
  store i64 0, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l23
  %t49 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t48, 0
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = insertvalue { %"compiler/source:Span", i32, ptr } %t49, i32 %t50, 1
  %t52 = load ptr, ptr %l30, !tbaa !29
  %t53 = insertvalue { %"compiler/source:Span", i32, ptr } %t51, ptr %t52, 2
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t53, ptr %t54
  %t55 = load { i64, [3 x i64] }, ptr %t46
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t55, ptr %t57
  %t58 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t58, ptr %t57)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l33, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/ast:ForIn", ptr %t61, i32 0, i32 1
  %t64 = load i32, ptr %t63, !tbaa !23
  store i32 %t64, ptr %l35, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l36
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t69 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t66)
  store i32 %t69, ptr %l39
  br label %bb11
bb11:
  store { i64, [1 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [1 x i64] }, ptr %t70, i32 0, i32 0
  store i64 4, ptr %t71
  %t72 = load { i64, [1 x i64] }, ptr %t70
  %t73 = load ptr, ptr %l33, !tbaa !29
  %t74 = load i32, ptr %l35, !tbaa !23
  %t75 = load %"compiler/source:Span", ptr %l36
  %t76 = load i32, ptr %l39, !tbaa !23
  %t79 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t73, i32 %t74, %"compiler/source:Span" %t75, i32 %t76, i32 1, { i64, [1 x i64] } %t72)
  store i64 %t79, ptr %l42
  br label %bb12
bb12:
  %t80 = load i64, ptr %l42, !tbaa !24
  store i64 %t80, ptr %l6, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v2, ptr %t81, i64 %t82, ptr %t83)
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load i64, ptr %l6, !tbaa !24
  %t91 = trunc i64 %t89 to i32
  %t93 = load ptr, ptr %l4, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 0
  store i64 0, ptr %t95
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t88, 0
  %t99 = insertvalue { %"compiler/source:Span", i32, ptr } %t97, i32 %t91, 1
  %t101 = insertvalue { %"compiler/source:Span", i32, ptr } %t99, ptr %t93, 2
  %t102 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t101, ptr %t102
  %t103 = load { i64, [3 x i64] }, ptr %t94
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t103, ptr %t105
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t87, ptr %t105)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %l9, !tbaa !23
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l11
  br label %bb2
bb2:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = load i32, ptr %l11, !tbaa !23
  %t13 = icmp eq i32 %t11, %t12
  br i1 %t13, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l15, !tbaa !24
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t29, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 5
  %t34 = load i1, ptr %t33, !tbaa !21
  store i1 %t34, ptr %l3, !tbaa !21
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 5
  store i1 true, ptr %t38, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l20, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  store ptr %t45, ptr %l23, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l26
  br label %bb6
bb6:
  %t51 = load ptr, ptr %l23, !tbaa !29
  %t52 = load i32, ptr %l26, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t53, ptr %l27
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l20, !tbaa !29
  %t55 = load i32, ptr %l27, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l28
  br label %bb8
bb8:
  %t57 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t59 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t57, i64 %t58)
  %t67 = getelementptr i8, ptr %t66, i64 %t58
  call void @olang_textcopy(ptr %t67, ptr %t60, i64 %t61)
  %t68 = getelementptr i8, ptr %t67, i64 %t61
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t66, 1
  store { i64, ptr } %t70, ptr %l4, !tbaa !27
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t76, ptr %l32
  br label %bb9
bb9:
  %t77 = load i1, ptr %l32, !tbaa !21
  br i1 %t77, label %bb10, label %bb11
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l36
  br label %bb12
bb11:
  %t83 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t83, ptr %l33, !tbaa !27
  br label %bb13
bb12:
  %t85 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t93 = extractvalue { i64, ptr } %t85, 1
  %t94 = extractvalue { i64, ptr } %t85, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t87, i64 %t88)
  %t100 = getelementptr i8, ptr %t99, i64 %t88
  call void @olang_textcopy(ptr %t100, ptr %t89, i64 %t90)
  %t101 = getelementptr i8, ptr %t100, i64 %t90
  call void @olang_textcopy(ptr %t101, ptr %t93, i64 %t94)
  %t102 = getelementptr i8, ptr %t101, i64 %t94
  call void @olang_textcopy(ptr %t102, ptr %t96, i64 %t97)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t99, 1
  store { i64, ptr } %t104, ptr %l33, !tbaa !27
  br label %bb13
bb13:
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l40, !tbaa !24
  %t108 = load i64, ptr %l40, !tbaa !24
  %t109 = mul i64 %t108, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l41, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l40, !tbaa !24
  %t118 = mul i64 %t117, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t114, ptr %t116, i64 %t118, i1 false)
  %t119 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i1, ptr %l3, !tbaa !21
  %t124 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 5
  store i1 %t121, ptr %t124, !tbaa !21
  store { i64, ptr } %t119, ptr %l44, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l45, !tbaa !24
  %t128 = load i64, ptr %l45, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l46, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l45, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t139, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t140 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t140, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l8 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca %"compiler/names:Ref"
  %l43 = alloca i64
  %l46 = alloca i1
  %l49 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 20
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 28}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", ptr }, ptr %t21, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i32 %t29, ptr %l19
  br label %bb10
bb10:
  %t30 = load i32, ptr %l19, !tbaa !23
  store i32 %t30, ptr %rv
  br label %ret
bb11:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb12, label %bb13
bb12:
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 28}
  %t38 = icmp eq i64 %t36, 0
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l3
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32 }, ptr %t48, i32 0, i32 1
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l4, !tbaa !23
  br label %bb16
bb15:
  br label %bb31
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l30, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t59)
  store ptr %t61, ptr %l32
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t64 = getelementptr %"compiler/check:frame", ptr %t62, i32 0, i32 2
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t68 = load ptr, ptr %l30, !tbaa !29
  %t71 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t68, i64 %t65, i32 %t67)
  store %"compiler/names:Ref" %t71, ptr %l36
  br label %bb18
bb18:
  %t72 = getelementptr %"compiler/names:Ref", ptr %l36, i32 0, i32 0
  %t73 = load i32, ptr %t72, !range !{i32 0, i32 9}
  %t75 = trunc i64 1 to i32
  %t76 = icmp eq i32 %t73, %t75
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb19, label %bb20
bb19:
  store i32 0, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l4, !tbaa !23
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t81, i32 %t82)
  store i64 %t85, ptr %l43
  br label %bb22
bb22:
  %t86 = load i64, ptr %l43, !tbaa !24
  store i64 %t86, ptr %l5, !tbaa !24
  %t87 = load i64, ptr %l5, !tbaa !24
  %t89 = icmp slt i64 %t87, 0
  br i1 %t89, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb27
bb24:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  store ptr %t96, ptr %l49, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t97, i64 %t98)
  store i32 %t101, ptr %l52
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l49, !tbaa !29
  %t103 = load i32, ptr %l52, !tbaa !23
  %t104 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t102, i32 %t103)
  store i1 %t104, ptr %l53
  br label %bb26
bb26:
  %t105 = load i1, ptr %l53, !tbaa !21
  %t106 = xor i1 %t105, true
  store i1 %t106, ptr %l46, !tbaa !21
  br label %bb27
bb27:
  %t108 = load i1, ptr %l46, !tbaa !21
  br i1 %t108, label %bb28, label %bb29
bb28:
  store i32 0, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t110 = load i32, ptr %l4, !tbaa !23
  store i32 %t110, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i32 0, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_1281810c6c9fab58_cb57d964fb88648c)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrRecode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t8 = icmp eq i32 %t6, %t5
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a0, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t13)
  store %"compiler/source:Span" %t15, ptr %l11
  br label %bb5
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l11
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t18, %"compiler/source:Span" %t19, i32 %t16, i32 20, ptr %t17, ptr null)
  store ptr %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l15, !tbaa !29
  store ptr %t24, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordCalled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l34 = alloca %"compiler/diagmsg:Msg"
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca ptr
  %l60 = alloca ptr
  %l63 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l73 = alloca i32
  %l77 = alloca i32
  %l85 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l97 = alloca i64
  %l102 = alloca ptr
  %l107 = alloca i32
  %l108 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l123 = alloca ptr
  %l126 = alloca %"compiler/source:Span"
  %l127 = alloca i32
  %l128 = alloca i32
  %l129 = alloca i64
  %l133 = alloca { i64, ptr }
  %l135 = alloca %"compiler/typed:Make"
  %l145 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t252 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValCodes(ptr %v0, ptr %s0, ptr %t4, i32 %t5)
  store { i64, ptr } %t8, ptr %l21
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t9, ptr %l5, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = icmp sgt i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb4
bb3:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t22 = icmp sge i64 %t16, %t19
  store i1 %t22, ptr %l25, !tbaa !21
  br label %bb4
bb4:
  %t24 = load i1, ptr %l25, !tbaa !21
  br i1 %t24, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l30, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l31
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s1, ptr %v0, i64 0, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, i64 %t29)
  store %"compiler/diagmsg:Msg" %t31, ptr %l34
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l31
  %t34 = load %"compiler/diagmsg:Msg", ptr %l34
  %t35 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t32, %"compiler/source:Span" %t33, %"compiler/diagmsg:Msg" %t34)
  store i64 %t35, ptr %l35
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t36, { i64, ptr } %t37)
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t40, %"compiler/source:Span" %t41)
  store ptr %t44, ptr %l40
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load ptr, ptr %l40, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l45
  br label %bb12
bb12:
  %t56 = load i1, ptr %l45, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  %t61 = load i32, ptr %l2, !tbaa !23
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i64, ptr %t65, i64 %t62
  %t67 = load i64, ptr %t66, !tbaa !34
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t59, %"compiler/source:Span" %t60, i32 %t61, i64 %t67)
  store ptr %t72, ptr %l52
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t73 = load ptr, ptr %l52, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
bb16:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i64, ptr %t77, i64 %t74
  %t79 = load i64, ptr %t78, !tbaa !34
  store i64 %t79, ptr %l6, !tbaa !24
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = ashr i64 %t81, 16
  %t85 = sub i64 %t83, 1
  store i64 %t85, ptr %l7, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  store ptr %t92, ptr %l60, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l63, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l2, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l68
  br label %bb17
bb17:
  %t109 = load ptr, ptr %l63, !tbaa !29
  %t110 = load i32, ptr %l68, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l69
  br label %bb18
bb18:
  %t112 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t112, ptr %l70, !tbaa !27
  %t113 = load i64, ptr %l7, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t113
  %t118 = load i32, ptr %t117, !tbaa !33
  %t119 = load ptr, ptr %l60, !tbaa !29
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t119, i32 %t118)
  store i32 %t121, ptr %l73
  br label %bb19
bb19:
  %t122 = load i32, ptr %l73, !tbaa !23
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t130 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t126, i32 %t122)
  store i32 %t130, ptr %l77
  br label %bb20
bb20:
  %t131 = load i32, ptr %l77, !tbaa !23
  store i32 %t131, ptr %l9, !tbaa !23
  store ptr null, ptr %l10, !tbaa !29
  %t132 = load i32, ptr %l9, !tbaa !23
  %t133 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t136 = icmp ne i32 %t132, %t133
  br i1 %t136, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t138 = load i64, ptr %l6, !tbaa !24
  %t140 = and i64 %t138, 65535
  store i64 %t140, ptr %l11, !tbaa !24
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 2
  store ptr %t147, ptr %l85, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load i32, ptr %l9, !tbaa !23
  %t157 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t153, i32 %t154)
  store i32 %t157, ptr %l90
  br label %bb23
bb22:
  br label %bb41
bb23:
  %t158 = load ptr, ptr %l85, !tbaa !29
  %t159 = load i32, ptr %l90, !tbaa !23
  %t160 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t158, i32 %t159)
  store { i64, ptr } %t160, ptr %l91
  br label %bb24
bb24:
  %t161 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t161, ptr %l92, !tbaa !27
  %t162 = load i64, ptr %l11, !tbaa !24
  %t164 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr i32, ptr %t165, i64 %t162
  %t167 = load i32, ptr %t166, !tbaa !33
  store i32 %t167, ptr %l12, !tbaa !23
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 44
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t171)
  store i64 %t173, ptr %l97
  br label %bb25
bb25:
  %t174 = load i64, ptr %l97, !tbaa !24
  store i64 %t174, ptr %l13, !tbaa !24
  %t175 = load i32, ptr %l12, !tbaa !23
  %t177 = icmp ne i32 %t175, 0
  br i1 %t177, label %bb26, label %bb27
bb26:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  store ptr %t184, ptr %l102, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 2
  %t191 = load i32, ptr %l12, !tbaa !23
  %t194 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t190, i32 %t191)
  store i32 %t194, ptr %l107
  br label %bb28
bb27:
  br label %bb38
bb28:
  %t195 = load ptr, ptr %l102, !tbaa !29
  %t196 = load i32, ptr %l107, !tbaa !23
  %t197 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t195, i32 %t196)
  store { i64, ptr } %t197, ptr %l108
  br label %bb29
bb29:
  %t198 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t198, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t199, 0
  store i64 %t201, ptr %l16, !tbaa !24
  br label %bb30
bb30:
  %t203 = load i64, ptr %l15, !tbaa !24
  %t204 = load i64, ptr %l16, !tbaa !24
  %t207 = icmp slt i64 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb31, label %bb32
bb31:
  br label %bb37
bb32:
  br label %bb33
bb33:
  %t211 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t211, ptr %l115, !tbaa !27
  %t212 = load i64, ptr %l15, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i32, ptr %t215, i64 %t212
  %t217 = load i32, ptr %t216, !tbaa !33
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 44
  store ptr %t221, ptr %l119, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l1
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t222, %"compiler/source:Span" %t223, i32 %t217)
  store ptr %t228, ptr %l123
  br label %bb34
bb34:
  %t229 = load ptr, ptr %l119, !tbaa !29
  %t230 = load ptr, ptr %l123, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t229, ptr %t230)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t231 = load i64, ptr %l15, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l15, !tbaa !24
  br label %bb30
bb37:
  br label %bb38
bb38:
  %t235 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t235, ptr %l126
  %t236 = load i32, ptr %l9, !tbaa !23
  store i32 %t236, ptr %l127, !tbaa !23
  store i32 1, ptr %l128
  %t237 = load i64, ptr %l11, !tbaa !24
  store i64 %t237, ptr %l129, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 44
  %t241 = load i64, ptr %l13, !tbaa !24
  %t244 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t240, i64 %t241)
  store { i64, ptr } %t244, ptr %l133
  br label %bb39
bb39:
  %t245 = load i32, ptr %l128, !range !{i32 0, i32 5}
  %t246 = load i64, ptr %l129, !tbaa !24
  %t247 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t249 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v2, ptr %v2, i32 %t245, i64 %t246, { i64, ptr } %t247, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t249, ptr %l135
  br label %bb40
bb40:
  %t250 = load %"compiler/typed:Make", ptr %l135
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t250, ptr %t251
  store { i64, [5 x i64] } zeroinitializer, ptr %t252
  %t253 = getelementptr { i64, [5 x i64] }, ptr %t252, i32 0, i32 0
  store i64 7, ptr %t253
  %t254 = load %"compiler/source:Span", ptr %l126
  %t255 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t254, 0
  %t256 = load i32, ptr %l127, !tbaa !23
  %t257 = insertvalue { %"compiler/source:Span", i32, ptr } %t255, i32 %t256, 1
  %t259 = insertvalue { %"compiler/source:Span", i32, ptr } %t257, ptr %t251, 2
  %t260 = getelementptr { i64, [5 x i64] }, ptr %t252, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t259, ptr %t260
  %t261 = load { i64, [5 x i64] }, ptr %t252
  %t263 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t261, ptr %t263
  store ptr %t263, ptr %l10, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  %t267 = load i32, ptr %l2, !tbaa !23
  %t268 = load i64, ptr %l7, !tbaa !24
  %t269 = load i64, ptr %l6, !tbaa !24
  %t270 = load ptr, ptr %l10, !tbaa !29
  %t277 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValue(ptr %v0, ptr %v2, ptr %v2, ptr %t265, %"compiler/source:Span" %t266, i32 %t267, i64 %t268, i64 %t269, ptr %t270)
  store ptr %t277, ptr %l145
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t278 = load ptr, ptr %l145, !tbaa !29
  store ptr %t278, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %lp8 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i64
  %l25 = alloca ptr
  %l29 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"compiler/typed:Block"
  %l35 = alloca %"compiler/typed:Item"
  %l37 = alloca %"compiler/typed:Item"
  %l41 = alloca { i64, ptr }
  %l43 = alloca %"compiler/typed:Item"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l50 = alloca %"compiler/typed:Clause"
  %l53 = alloca %"compiler/source:Span"
  %l56 = alloca i32
  %l61 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t22 = alloca { i64, [3 x i64] }, align 8
  %t70 = alloca i64
  %t127 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d8, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i32 %t6, ptr %l11
  br label %bb1
bb1:
  %t7 = load i32, ptr %l11, !tbaa !23
  store i32 %t7, ptr %l4, !tbaa !23
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 45
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l14
  br label %bb2
bb2:
  %t13 = load i64, ptr %l14, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 45
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = trunc i64 %a3 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 5, ptr %t23
  %t25 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t17, 0
  %t27 = insertvalue { %"compiler/source:Span", i32, i32 } %t25, i32 0, 1
  %t29 = insertvalue { %"compiler/source:Span", i32, i32 } %t27, i32 %t20, 2
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t29, ptr %t30
  %t31 = load { i64, [3 x i64] }, ptr %t22
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t31, ptr %t33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t16, ptr %t33)
  br label %bb3
bb3:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t36)
  store ptr %t38, ptr %l25
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 7
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = trunc i64 %t42 to i32
  store i32 %t44, ptr %l29, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 45
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store { i64, ptr } %t52, ptr %l33
  br label %bb5
bb5:
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t55 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 %t53, { i64, ptr } %t54)
  store %"compiler/typed:Block" %t55, ptr %l34
  br label %bb6
bb6:
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store ptr %t56, ptr %lp6
  %t57 = load %"compiler/typed:Block", ptr %l34
  %t58 = load ptr, ptr %lp6
  store %"compiler/typed:Block" %t57, ptr %t58
  store %"compiler/typed:Item" zeroinitializer, ptr %l35
  %t59 = icmp sgt i64 1, 0
  br i1 %t59, label %bb7, label %bb8
bb7:
  %t61 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v2, i32 0, i64 0)
  store %"compiler/typed:Item" %t61, ptr %l37
  br label %bb9
bb8:
  %t62 = icmp sge i64 1, 0
  br i1 %t62, label %bb10, label %bb11
bb9:
  %t64 = load %"compiler/typed:Item", ptr %l37
  store %"compiler/typed:Item" %t64, ptr %l35
  br label %bb8
bb10:
  %t65 = icmp sle i64 1, 576460752303423487
  br i1 %t65, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8e26fbb1c5557eef_13e6cc5de085742b)
  unreachable
bb12:
  %t67 = mul i64 1, 16
  %t68 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t67)
  %t69 = load %"compiler/typed:Item", ptr %l35
  store i64 0, ptr %t70
  br label %fill.71
fill.71:
  %t74 = load i64, ptr %t70
  %t75 = icmp slt i64 %t74, 1
  br i1 %t75, label %fillb.72, label %filld.73
fillb.72:
  %t76 = getelementptr %"compiler/typed:Item", ptr %t68, i64 %t74
  store %"compiler/typed:Item" %t69, ptr %t76
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %t70
  br label %fill.71
filld.73:
  %t78 = insertvalue { i64, ptr } undef, i64 1, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t68, 1
  store { i64, ptr } %t79, ptr %l7, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = load i32, ptr %l4, !tbaa !23
  %t84 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s0, i32 %t82, i64 -1)
  store %"compiler/typed:Item" %t84, ptr %l43
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8e26fbb1c5557eef_13e6cc5de085742b)
  unreachable
bb14:
  %t85 = load %"compiler/typed:Item", ptr %l43
  %t86 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr %"compiler/typed:Item", ptr %t87, i64 0
  store %"compiler/typed:Item" %t85, ptr %t88
  %t89 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t89, ptr %l44
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l45, !tbaa !27
  %t91 = load ptr, ptr %lp6
  store ptr %t91, ptr %l46, !tbaa !29
  %t92 = icmp sge i64 0, 0
  br i1 %t92, label %bb15, label %bb16
bb15:
  %t94 = icmp sle i64 0, 1152921504606846975
  br i1 %t94, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_6d702b04e725ae1a_71c02c55b3dfc416)
  unreachable
bb17:
  %t96 = mul i64 0, 8
  %t97 = insertvalue { i64, ptr } undef, i64 0, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t99 = load %"compiler/source:Span", ptr %l44
  %t100 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t101 = load ptr, ptr %l46, !tbaa !29
  %t103 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, %"compiler/source:Span" %t99, { i64, ptr } %t100, i1 false, ptr %t101, { i64, ptr } %t98, i64 -1, i32 0)
  store %"compiler/typed:Clause" %t103, ptr %l50
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_6d702b04e725ae1a_71c02c55b3dfc416)
  unreachable
bb19:
  %t104 = load %"compiler/typed:Clause", ptr %l50
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store %"compiler/typed:Clause" %t104, ptr %t105
  %t107 = insertvalue [1 x ptr] undef, ptr %t105, 0
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t108, ptr %lp8
  %t110 = load ptr, ptr %lp8
  store [1 x ptr] %t107, ptr %t110
  %t111 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t111, ptr %l53
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t115 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t112)
  store i32 %t115, ptr %l56
  br label %bb20
bb20:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = load ptr, ptr %lp8
  %t120 = insertvalue { i64, ptr } undef, i64 1, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t118, 1
  %t124 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v1, ptr %v2, ptr %v2, ptr %t116, { i64, ptr } %t121, i1 false, i1 true, i1 true)
  store %"compiler/typed:Try" %t124, ptr %l61
  br label %bb21
bb21:
  %t125 = load %"compiler/typed:Try", ptr %l61
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Try" %t125, ptr %t126
  store { i64, [5 x i64] } zeroinitializer, ptr %t127
  %t128 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 0
  store i64 14, ptr %t128
  %t129 = load %"compiler/source:Span", ptr %l53
  %t130 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t129, 0
  %t131 = load i32, ptr %l56, !tbaa !23
  %t132 = insertvalue { %"compiler/source:Span", i32, ptr } %t130, i32 %t131, 1
  %t134 = insertvalue { %"compiler/source:Span", i32, ptr } %t132, ptr %t126, 2
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t134, ptr %t135
  %t136 = load { i64, [5 x i64] }, ptr %t127
  %t138 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t136, ptr %t138
  call void @__olang_scope_close(ptr %s0)
  store ptr %t138, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l8 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i1
  %l27 = alloca i32
  %l30 = alloca i1
  %l35 = alloca i32
  %l42 = alloca i32
  %l44 = alloca i1
  %l48 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr %l2, !tbaa !23
  %t12 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t6, i32 %t7, i32 %t8)
  store i1 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb10
bb8:
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l14, !tbaa !29
  %t34 = load i32, ptr %l19, !tbaa !23
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t33, i32 %t34, i32 %t32)
  store i1 %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l13, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l27
  br label %bb14
bb14:
  %t50 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t52 = trunc i64 19 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l2, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l35
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t65 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t67 = trunc i64 19 to i32
  %t68 = icmp eq i32 %t65, %t67
  store i1 %t68, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t70 = load i1, ptr %l30, !tbaa !21
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l2, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l42
  br label %bb21
bb20:
  br label %bb38
bb21:
  %t81 = load i32, ptr %l42, !tbaa !23
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l1, !tbaa !23
  %t86 = load i32, ptr %l2, !tbaa !23
  %t90 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %t84, i32 %t85, i32 %t86)
  store i1 %t90, ptr %l48
  br label %bb24
bb23:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb25
bb24:
  %t91 = load i1, ptr %l48, !tbaa !21
  %t92 = xor i1 %t91, true
  store i1 %t92, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t94 = load i1, ptr %l44, !tbaa !21
  br i1 %t94, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l53, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l58
  br label %bb29
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t118 = load i32, ptr %l2, !tbaa !23
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t117, i32 %t118)
  store i32 %t121, ptr %l63
  br label %bb30
bb30:
  %t122 = load ptr, ptr %l53, !tbaa !29
  %t123 = load i32, ptr %l58, !tbaa !23
  %t124 = load i32, ptr %l63, !tbaa !23
  %t125 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t122, i32 %t123, i32 %t124)
  store i1 %t125, ptr %l64
  br label %bb31
bb31:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb37
bb33:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l66, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %l1, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l71
  br label %bb34
bb34:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l2, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l76
  br label %bb35
bb35:
  %t148 = load ptr, ptr %l66, !tbaa !29
  %t149 = load i32, ptr %l71, !tbaa !23
  %t150 = load i32, ptr %l76, !tbaa !23
  %t151 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t148, i32 %t149, i32 %t150)
  store i1 %t151, ptr %l77
  br label %bb36
bb36:
  %t152 = load i1, ptr %l77, !tbaa !21
  store i1 %t152, ptr %l65, !tbaa !21
  br label %bb37
bb37:
  %t153 = load i1, ptr %l65, !tbaa !21
  store i1 %t153, ptr %rv
  br label %ret
bb38:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca %"compiler/check:litv"
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/check:litv"
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca %"compiler/check:litv"
  %l36 = alloca ptr
  %l37 = alloca i1
  %l44 = alloca i32
  %l48 = alloca %"compiler/check:litv"
  %l49 = alloca %"compiler/check:litv"
  %l50 = alloca ptr
  %l51 = alloca i1
  %l60 = alloca i32
  %l63 = alloca %"compiler/check:litv"
  %l66 = alloca %"compiler/check:litv"
  %l67 = alloca %"compiler/check:litv"
  %l68 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t5, ptr %l12
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load %"compiler/check:litv", ptr %l12
  store %"compiler/check:litv" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t8 = load ptr, ptr %l13, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 28}
  %t14 = icmp eq i64 %t12, 1
  store i1 %t14, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l14, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l2
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 113}
  store i32 %t26, ptr %l3
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l2
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t28, %"compiler/source:Span" %t29)
  store { i64, ptr } %t32, ptr %l23
  br label %bb10
bb10:
  %t33 = load i32, ptr %l3, !range !{i32 0, i32 113}
  %t34 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t36 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofText(ptr %v0, { i64, ptr } %t34, i32 %t33)
  store %"compiler/check:litv" %t36, ptr %l25
  br label %bb11
bb11:
  %t37 = load %"compiler/check:litv", ptr %l25
  store %"compiler/check:litv" %t37, ptr %rv
  br label %ret
bb12:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load ptr, ptr %l26, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 28}
  %t45 = icmp eq i64 %t43, 2
  store i1 %t45, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t58 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  store %"compiler/check:litv" %t58, ptr %l35
  br label %bb18
bb18:
  %t59 = load %"compiler/check:litv", ptr %l35
  store %"compiler/check:litv" %t59, ptr %rv
  br label %ret
bb19:
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb20, label %bb21
bb20:
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 28}
  %t67 = icmp eq i64 %t65, 3
  store i1 %t67, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb22, label %bb23
bb22:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 1
  %t73 = load i32, ptr %t72, !range !{i32 0, i32 113}
  store i32 %t73, ptr %l5
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l6, !tbaa !29
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t81 = load i32, ptr %l5, !range !{i32 0, i32 113}
  store i32 %t81, ptr %l44
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l6, !tbaa !29
  %t87 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  store %"compiler/check:litv" %t87, ptr %l48
  br label %bb25
bb25:
  %t88 = load i32, ptr %l44, !range !{i32 0, i32 113}
  %t89 = load %"compiler/check:litv", ptr %l48
  %t90 = call %"compiler/check:litv" @compiler_2fcheck_2efoldUnary(i32 %t88, %"compiler/check:litv" %t89)
  store %"compiler/check:litv" %t90, ptr %l49
  br label %bb26
bb26:
  %t91 = load %"compiler/check:litv", ptr %l49
  store %"compiler/check:litv" %t91, ptr %rv
  br label %ret
bb27:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t96 = load ptr, ptr %l50, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 28}
  %t99 = icmp eq i64 %t97, 5
  store i1 %t99, ptr %l51, !tbaa !21
  br label %bb29
bb29:
  %t100 = load i1, ptr %l51, !tbaa !21
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t103, i32 0, i32 1
  %t105 = load i32, ptr %t104, !range !{i32 0, i32 113}
  store i32 %t105, ptr %l7
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l8, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t115, i32 0, i32 3
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l9, !tbaa !29
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t119 = load i32, ptr %l7, !range !{i32 0, i32 113}
  store i32 %t119, ptr %l60
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l8, !tbaa !29
  %t124 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t120, ptr %t121)
  store %"compiler/check:litv" %t124, ptr %l63
  br label %bb33
bb33:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l9, !tbaa !29
  %t129 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t125, ptr %t126)
  store %"compiler/check:litv" %t129, ptr %l66
  br label %bb34
bb34:
  %t130 = load i32, ptr %l60, !range !{i32 0, i32 113}
  %t131 = load %"compiler/check:litv", ptr %l63
  %t132 = load %"compiler/check:litv", ptr %l66
  %t133 = call %"compiler/check:litv" @compiler_2fcheck_2efoldBinary(i32 %t130, %"compiler/check:litv" %t131, %"compiler/check:litv" %t132)
  store %"compiler/check:litv" %t133, ptr %l67
  br label %bb35
bb35:
  %t134 = load %"compiler/check:litv", ptr %l67
  store %"compiler/check:litv" %t134, ptr %rv
  br label %ret
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t135 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t135, ptr %l68
  br label %bb40
bb40:
  %t136 = load %"compiler/check:litv", ptr %l68
  store %"compiler/check:litv" %t136, ptr %rv
  br label %ret
bb41:
  call void @__olang_check_failed(ptr @olang_loc_18ec9fb825b0f3da_76c21f303b4292b6)
  unreachable
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l16 = alloca i64
  %l17 = alloca %"compiler/check:litv"
  %l21 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 113}
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 113}
  %t24 = trunc i64 4 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l2
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %t27, %"compiler/source:Span" %t28)
  store i64 %t31, ptr %l16
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t32)
  store %"compiler/check:litv" %t33, ptr %l17
  br label %bb9
bb9:
  %t34 = load %"compiler/check:litv", ptr %l17
  store %"compiler/check:litv" %t34, ptr %rv
  br label %ret
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2bda502508e1b1d_a3083ba563ab0481)
  unreachable
bb16:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t40 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store %"compiler/check:litv" %t40, ptr %l21
  br label %bb17
bb17:
  %t41 = load %"compiler/check:litv", ptr %l21
  store %"compiler/check:litv" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efuncNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l7, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l9, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t18)
  store ptr %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = load ptr, ptr %l9, !tbaa !29
  %t29 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t26, ptr %t23, ptr %t24)
  store i32 %t29, ptr %l16
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t31 = load i32, ptr %l16, !tbaa !23
  %t32 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclaredFunc(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t32, ptr %l17
  br label %bb8
bb8:
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = load i32, ptr %l17, !tbaa !23
  %t36 = icmp ne i32 %t34, %t33
  store i1 %t36, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9cda55992b6a58cc_f4ed715c72ea34c8)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egatherVariadic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %lp12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l27 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l48 = alloca i1
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l62 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l81 = alloca i1
  %l90 = alloca { i64, ptr }
  %l94 = alloca i1
  %l96 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca %"compiler/diagmsg:Msg"
  %l100 = alloca i64
  %l102 = alloca ptr
  %l104 = alloca ptr
  %l106 = alloca i64
  %l108 = alloca %"compiler/source:Span"
  %l111 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l117 = alloca %"compiler/source:Span"
  %l118 = alloca { i64, ptr }
  %l120 = alloca %"compiler/source:Span"
  %l121 = alloca i32
  %l122 = alloca { i64, ptr }
  %l127 = alloca %"compiler/source:Span"
  %l129 = alloca %"compiler/source:Span"
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l138 = alloca i64
  %l141 = alloca i64
  %l160 = alloca { i64, ptr }
  %l176 = alloca i64
  %l179 = alloca i64
  %l198 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t304 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t12 = add i64 %t8, %t9
  %t15 = icmp slt i64 %t7, %t12
  store i1 %t15, ptr %l27, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l27, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t28, ptr %l40, !tbaa !27
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr ptr, ptr %t32, i64 %t29
  %t34 = load ptr, ptr %t33, !tbaa !39
  %t36 = call i1 @compiler_2fast_2ecompiler_2fast_3aExpr_2eIsGathered(ptr %v1, ptr %t34)
  store i1 %t36, ptr %l43
  br label %bb9
bb8:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i1, ptr %l43, !tbaa !21
  store i1 %t37, ptr %l39, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l39, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t39, ptr %l45, !tbaa !27
  %t40 = load i64, ptr %l1, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  %t47 = call i1 @compiler_2fast_2ecompiler_2fast_3aExpr_2eIsSpread(ptr %v1, ptr %t45)
  store i1 %t47, ptr %l48
  br label %bb13
bb12:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb14
bb13:
  %t48 = load i1, ptr %l48, !tbaa !21
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l44, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t54 = load i64, ptr %l1, !tbaa !24
  store i64 %t54, ptr %l5, !tbaa !24
  br label %bb18
bb18:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = load i64, ptr %l4, !tbaa !24
  %t63 = sub i64 %t59, %t60
  %t66 = icmp slt i64 %t56, %t63
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l59, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t76 = call i1 @compiler_2fast_2ecompiler_2fast_3aExpr_2eIsNamed(ptr %v1, ptr %t74)
  store i1 %t76, ptr %l62
  br label %bb21
bb20:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb22
bb21:
  %t77 = load i1, ptr %l62, !tbaa !21
  %t78 = xor i1 %t77, true
  store i1 %t78, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l58, !tbaa !21
  %t81 = xor i1 %t80, true
  br i1 %t81, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t83 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb26
bb26:
  br label %bb18
bb27:
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t87, ptr %l67, !tbaa !27
  %t88 = load i64, ptr %l1, !tbaa !24
  store i64 %t88, ptr %l68, !tbaa !24
  %t89 = load i64, ptr %l5, !tbaa !24
  store i64 %t89, ptr %l69, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l70, !tbaa !24
  %t92 = load i64, ptr %l68, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb28, label %bb29
bb28:
  %t95 = load i64, ptr %l68, !tbaa !24
  %t96 = load i64, ptr %l69, !tbaa !24
  %t97 = icmp sle i64 %t95, %t96
  br i1 %t97, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_4a5fe817f84fef4e_4820cb4f1f993ac2)
  unreachable
bb30:
  %t99 = load i64, ptr %l69, !tbaa !24
  %t100 = load i64, ptr %l70, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  br i1 %t101, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_4a5fe817f84fef4e_4820cb4f1f993ac2)
  unreachable
bb32:
  %t103 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l68, !tbaa !24
  %t106 = load i64, ptr %l69, !tbaa !24
  %t107 = getelementptr ptr, ptr %t104, i64 %t105
  %t108 = sub i64 %t106, %t105
  %t109 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t107, 1
  store { i64, ptr } %t110, ptr %l6, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t116 = icmp eq i64 %t114, 1
  br i1 %t116, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_4a5fe817f84fef4e_4820cb4f1f993ac2)
  unreachable
bb34:
  %t118 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t118, ptr %l79, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr ptr, ptr %t120, i64 0
  %t122 = load ptr, ptr %t121, !tbaa !39
  %t124 = call i1 @compiler_2fast_2ecompiler_2fast_3aExpr_2eIsSpread(ptr %v1, ptr %t122)
  store i1 %t124, ptr %l81
  br label %bb36
bb35:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb37
bb36:
  %t125 = load i1, ptr %l81, !tbaa !21
  store i1 %t125, ptr %l78, !tbaa !21
  br label %bb37
bb37:
  %t126 = load i1, ptr %l78, !tbaa !21
  br i1 %t126, label %bb38, label %bb39
bb38:
  %t127 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t127, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t129, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l9, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t135 = load i64, ptr %l8, !tbaa !24
  %t136 = load i64, ptr %l9, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb57
bb43:
  br label %bb44
bb44:
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t143, ptr %l90, !tbaa !27
  %t144 = load i64, ptr %l8, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr ptr, ptr %t147, i64 %t144
  %t149 = load ptr, ptr %t148, !tbaa !39
  store ptr %t149, ptr %l10, !tbaa !29
  %t151 = load ptr, ptr %l10, !tbaa !29
  %t153 = call i1 @compiler_2fast_2ecompiler_2fast_3aExpr_2eIsSpread(ptr %v1, ptr %t151)
  store i1 %t153, ptr %l94
  br label %bb45
bb45:
  %t154 = load i1, ptr %l94, !tbaa !21
  %t155 = xor i1 %t154, true
  br i1 %t155, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb56
bb47:
  br label %bb48
bb48:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l96, !tbaa !29
  %t158 = load ptr, ptr %l10, !tbaa !29
  %t160 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t158)
  store %"compiler/source:Span" %t160, ptr %l98
  br label %bb49
bb49:
  %t161 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpreadAlone(ptr %v0)
  store %"compiler/diagmsg:Msg" %t161, ptr %l99
  br label %bb50
bb50:
  %t162 = load ptr, ptr %l96, !tbaa !29
  %t163 = load %"compiler/source:Span", ptr %l98
  %t164 = load %"compiler/diagmsg:Msg", ptr %l99
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t162, %"compiler/source:Span" %t163, %"compiler/diagmsg:Msg" %t164)
  store i64 %t165, ptr %l100
  br label %bb51
bb51:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 167
  store ptr %t168, ptr %l102, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t169)
  store ptr %t171, ptr %l104
  br label %bb52
bb52:
  %t172 = load ptr, ptr %l104, !tbaa !29
  %t174 = getelementptr %"compiler/check:frame", ptr %t172, i32 0, i32 2
  %t175 = load i64, ptr %t174, !tbaa !24
  store i64 %t175, ptr %l106, !tbaa !24
  %t176 = load ptr, ptr %l10, !tbaa !29
  %t178 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t176)
  store %"compiler/source:Span" %t178, ptr %l108
  br label %bb53
bb53:
  %t179 = getelementptr %"compiler/source:Span", ptr %l108, i32 0, i32 0
  %t180 = load i32, ptr %t179, !tbaa !23
  %t182 = sext i32 %t180 to i64
  %t183 = load i64, ptr %l106, !tbaa !24
  %t185 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s6, i64 %t183, i64 %t182)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t185, ptr %l111
  br label %bb54
bb54:
  %t186 = load ptr, ptr %l102, !tbaa !29
  %t187 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l111
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t186, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t187, i1 true)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s6)
  br label %bb56
bb56:
  %t188 = load i64, ptr %l8, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l8, !tbaa !24
  br label %bb41
bb57:
  %t192 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t196 = icmp sgt i64 %t194, 0
  br i1 %t196, label %bb58, label %bb59
bb58:
  %t198 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t198, ptr %l118, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr ptr, ptr %t200, i64 0
  %t202 = load ptr, ptr %t201, !tbaa !39
  %t204 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t202)
  store %"compiler/source:Span" %t204, ptr %l120
  br label %bb60
bb59:
  %t205 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t206 = load i32, ptr %t205, !tbaa !23
  %t207 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t208 = load i32, ptr %t207, !tbaa !23
  %t211 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t206, i32 %t208)
  store %"compiler/source:Span" %t211, ptr %l132
  br label %bb63
bb60:
  %t212 = getelementptr %"compiler/source:Span", ptr %l120, i32 0, i32 0
  %t213 = load i32, ptr %t212, !tbaa !23
  store i32 %t213, ptr %l121, !tbaa !23
  %t214 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t214, ptr %l122, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t219 = sub i64 %t217, 1
  %t221 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr ptr, ptr %t222, i64 %t219
  %t224 = load ptr, ptr %t223, !tbaa !39
  %t226 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t224)
  store %"compiler/source:Span" %t226, ptr %l127
  br label %bb61
bb61:
  %t227 = getelementptr %"compiler/source:Span", ptr %l127, i32 0, i32 1
  %t228 = load i32, ptr %t227, !tbaa !23
  %t229 = load i32, ptr %l121, !tbaa !23
  %t231 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t229, i32 %t228)
  store %"compiler/source:Span" %t231, ptr %l129
  br label %bb62
bb62:
  %t232 = load %"compiler/source:Span", ptr %l129
  store %"compiler/source:Span" %t232, ptr %l117
  br label %bb64
bb63:
  %t233 = load %"compiler/source:Span", ptr %l132
  store %"compiler/source:Span" %t233, ptr %l117
  br label %bb64
bb64:
  %t234 = load %"compiler/source:Span", ptr %l117
  store %"compiler/source:Span" %t234, ptr %l11
  %t235 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t235, ptr %l133
  br label %bb65
bb65:
  %t236 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t236, ptr %lp12
  %t237 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l133
  %t238 = load ptr, ptr %lp12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t237, ptr %t238
  store i64 0, ptr %l13, !tbaa !24
  %t239 = load i64, ptr %l1, !tbaa !24
  store i64 %t239, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t241 = load i64, ptr %l14, !tbaa !24
  %t242 = load i64, ptr %l13, !tbaa !24
  %t245 = icmp sgt i64 %t241, %t242
  br i1 %t245, label %bb66, label %bb67
bb66:
  %t247 = load i64, ptr %l15, !tbaa !24
  %t249 = icmp sgt i64 %t247, 0
  br i1 %t249, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb71
bb68:
  %t251 = load i64, ptr %l14, !tbaa !24
  %t252 = load i64, ptr %l13, !tbaa !24
  %t255 = sub i64 %t251, %t252
  %t256 = load i64, ptr %l15, !tbaa !24
  %t259 = add i64 %t255, %t256
  %t261 = sub i64 %t259, 1
  %t262 = load i64, ptr %l15, !tbaa !24
  %t265 = sdiv i64 %t261, %t262
  store i64 %t265, ptr %l141, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb70
bb70:
  %t267 = load i64, ptr %l141, !tbaa !24
  store i64 %t267, ptr %l138, !tbaa !24
  br label %bb71
bb71:
  %t268 = load i64, ptr %l138, !tbaa !24
  store i64 %t268, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb72
bb72:
  %t269 = load i64, ptr %l17, !tbaa !24
  %t270 = load i64, ptr %l16, !tbaa !24
  %t273 = icmp slt i64 %t269, %t270
  %t275 = xor i1 %t273, true
  br i1 %t275, label %bb73, label %bb74
bb73:
  br label %bb78
bb74:
  br label %bb75
bb75:
  %t277 = load i64, ptr %l13, !tbaa !24
  %t278 = load i64, ptr %l17, !tbaa !24
  %t279 = load i64, ptr %l15, !tbaa !24
  %t282 = mul i64 %t278, %t279
  %t285 = add i64 %t277, %t282
  %t287 = load ptr, ptr %lp12
  %t288 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t288, ptr %l160, !tbaa !27
  %t291 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr ptr, ptr %t292, i64 %t285
  %t294 = load ptr, ptr %t293, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v2, ptr %v1, ptr %t287, ptr %t294)
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t297 = load i64, ptr %l17, !tbaa !24
  %t299 = add i64 %t297, 1
  store i64 %t299, ptr %l17, !tbaa !24
  br label %bb72
bb78:
  %t301 = load ptr, ptr %lp12
  %t302 = load %"compiler/source:Span", ptr %l11
  %t303 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t304
  %t305 = getelementptr { i64, [4 x i64] }, ptr %t304, i32 0, i32 0
  store i64 27, ptr %t305
  %t307 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t302, 0
  %t309 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t307, { i64, ptr } %t303, 1
  %t310 = getelementptr { i64, [4 x i64] }, ptr %t304, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t309, ptr %t310
  %t311 = load { i64, [4 x i64] }, ptr %t304
  %t313 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t311, ptr %t313
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v2, ptr %v2, ptr %t301, ptr %t313)
  br label %bb79
bb79:
  %t316 = load i64, ptr %l5, !tbaa !24
  store i64 %t316, ptr %l19, !tbaa !24
  %t318 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t318, 0
  store i64 %t320, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t322 = load i64, ptr %l20, !tbaa !24
  %t323 = load i64, ptr %l19, !tbaa !24
  %t326 = icmp sgt i64 %t322, %t323
  br i1 %t326, label %bb80, label %bb81
bb80:
  %t328 = load i64, ptr %l21, !tbaa !24
  %t330 = icmp sgt i64 %t328, 0
  br i1 %t330, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l176, !tbaa !24
  br label %bb85
bb82:
  %t332 = load i64, ptr %l20, !tbaa !24
  %t333 = load i64, ptr %l19, !tbaa !24
  %t336 = sub i64 %t332, %t333
  %t337 = load i64, ptr %l21, !tbaa !24
  %t340 = add i64 %t336, %t337
  %t342 = sub i64 %t340, 1
  %t343 = load i64, ptr %l21, !tbaa !24
  %t346 = sdiv i64 %t342, %t343
  store i64 %t346, ptr %l179, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb84
bb84:
  %t348 = load i64, ptr %l179, !tbaa !24
  store i64 %t348, ptr %l176, !tbaa !24
  br label %bb85
bb85:
  %t349 = load i64, ptr %l176, !tbaa !24
  store i64 %t349, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb86
bb86:
  %t350 = load i64, ptr %l23, !tbaa !24
  %t351 = load i64, ptr %l22, !tbaa !24
  %t354 = icmp slt i64 %t350, %t351
  %t356 = xor i1 %t354, true
  br i1 %t356, label %bb87, label %bb88
bb87:
  br label %bb92
bb88:
  br label %bb89
bb89:
  %t358 = load i64, ptr %l19, !tbaa !24
  %t359 = load i64, ptr %l23, !tbaa !24
  %t360 = load i64, ptr %l21, !tbaa !24
  %t363 = mul i64 %t359, %t360
  %t366 = add i64 %t358, %t363
  %t368 = load ptr, ptr %lp12
  %t369 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t369, ptr %l198, !tbaa !27
  %t372 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = getelementptr ptr, ptr %t373, i64 %t366
  %t375 = load ptr, ptr %t374, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v2, ptr %v1, ptr %t368, ptr %t375)
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t378 = load i64, ptr %l23, !tbaa !24
  %t380 = add i64 %t378, 1
  store i64 %t380, ptr %l23, !tbaa !24
  br label %bb86
bb92:
  %t382 = load ptr, ptr %lp12
  %t384 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v2, ptr %v2, ptr %t382)
  store { i64, ptr } %t384, ptr %l204
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s0)
  %t385 = load { i64, ptr }, ptr %l204, !tbaa !27
  store { i64, ptr } %t385, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egrowViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l11
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb5, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l10
  br label %bb4
bb4:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t15 = load i64, ptr %l7, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = or i64 %t16, %t17
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp eq i64 %t20, %t21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %ret
bb9:
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = or i64 %t28, %t29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v1, ptr %t26, i64 %t27, i64 %t32)
  br label %bb11
bb11:
  %t38 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 87
  store i1 true, ptr %t38, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleLocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:Local"
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca %"compiler/typed:Local"
  %l20 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i1
  %l61 = alloca ptr
  %l68 = alloca ptr
  %l73 = alloca ptr
  %l77 = alloca i64
  %l81 = alloca i1
  %l82 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l97 = alloca %"compiler/typed:Local"
  %l99 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l104 = alloca i1
  %l107 = alloca i1
  %l111 = alloca { i64, ptr }
  %l121 = alloca i1
  %l123 = alloca i1
  %l125 = alloca i1
  %l126 = alloca i1
  %l128 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 7
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t3, i64 %t4)
  store %"compiler/typed:Local" %t7, ptr %l17
  br label %bb1
bb1:
  %t8 = load %"compiler/typed:Local", ptr %l17
  store %"compiler/typed:Local" %t8, ptr %l5
  %t9 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  %t12 = icmp eq i32 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t14, i32 %t16)
  store i1 %t19, ptr %l23
  br label %bb4
bb4:
  %t20 = load i1, ptr %l23, !tbaa !21
  store i1 %t20, ptr %l20, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l20, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb9
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t24 = load i32, ptr %t23, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %t22, i32 %t24, i64 0)
  store i1 %t27, ptr %l27
  br label %bb8
bb8:
  %t28 = load i1, ptr %l27, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l24, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/typed:LocalUses", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t34, i64 %t35)
  store i1 %t38, ptr %l32
  br label %bb13
bb13:
  %t39 = load i1, ptr %l32, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr %"compiler/typed:LocalUses", ptr %t40, i32 0, i32 3
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t42, i64 %t43)
  store i1 %t46, ptr %l37
  br label %bb16
bb16:
  %t47 = load i1, ptr %l37, !tbaa !21
  store i1 %t47, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t48 = load i1, ptr %l33, !tbaa !21
  br i1 %t48, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb21
bb19:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/typed:LocalUses", ptr %t49, i32 0, i32 4
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t51, i64 %t52)
  store i1 %t55, ptr %l42
  br label %bb20
bb20:
  %t56 = load i1, ptr %l42, !tbaa !21
  store i1 %t56, ptr %l38, !tbaa !21
  br label %bb21
bb21:
  %t57 = load i1, ptr %l38, !tbaa !21
  br i1 %t57, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb25
bb23:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t60 = load i64, ptr %l4, !tbaa !24
  %t64 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elentAt(ptr %v0, ptr %v2, ptr %t58, ptr %t59, i64 %t60)
  store i1 %t64, ptr %l47
  br label %bb24
bb24:
  %t65 = load i1, ptr %l47, !tbaa !21
  store i1 %t65, ptr %l43, !tbaa !21
  br label %bb25
bb25:
  %t66 = load i1, ptr %l43, !tbaa !21
  store i1 %t66, ptr %l6, !tbaa !21
  %t67 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 7}
  %t70 = trunc i64 0 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb26, label %bb27
bb26:
  %t73 = load i1, ptr %l6, !tbaa !21
  br i1 %t73, label %bb28, label %bb29
bb27:
  br label %bb32
bb28:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t77 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleLine(ptr %v0, ptr %v1, ptr %s0, ptr %s3, ptr %s3, ptr %t75, ptr %t76, ptr %l5, i64 %t77, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) })
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t82 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t83 = load i32, ptr %t82, !range !{i32 0, i32 7}
  %t85 = trunc i64 1 to i32
  %t86 = icmp eq i32 %t83, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  br label %bb35
bb35:
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t92 = getelementptr %"compiler/typed:LocalUses", ptr %t90, i32 0, i32 10
  %t93 = load i64, ptr %l4, !tbaa !24
  %t96 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v2, ptr %v2, ptr %t92, i64 %t93)
  store ptr %t96, ptr %l61
  br label %bb36
bb36:
  %t97 = load ptr, ptr %l61, !tbaa !29
  store ptr %t97, ptr %l7, !tbaa !29
  %t98 = load ptr, ptr %l7, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb38:
  br label %bb39
bb39:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load ptr, ptr %l7, !tbaa !29
  %t111 = call ptr @compiler_2ftyped_2eCopiedOf(ptr %v0, ptr %v2, ptr %v2, ptr %t107, ptr %t108)
  store ptr %t111, ptr %l68
  br label %bb40
bb40:
  %t112 = load ptr, ptr %l68, !tbaa !29
  store ptr %t112, ptr %l8, !tbaa !29
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = icmp eq ptr %t113, null
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t119 = load ptr, ptr %l8, !tbaa !29
  %t121 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v2, ptr %t119)
  store ptr %t121, ptr %l73
  br label %bb43
bb42:
  br label %bb61
bb43:
  %t122 = load ptr, ptr %l73, !tbaa !29
  store ptr %t122, ptr %l9, !tbaa !29
  %t123 = load ptr, ptr %l9, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  br i1 %t125, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  br label %bb46
bb46:
  %t127 = load ptr, ptr %l9, !tbaa !29
  %t129 = call i64 @compiler_2fcheck_2ehandleRoot(ptr %v2, ptr %t127)
  store i64 %t129, ptr %l77
  br label %bb47
bb47:
  %t130 = load i64, ptr %l77, !tbaa !24
  store i64 %t130, ptr %l10, !tbaa !24
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr %"compiler/typed:LocalUses", ptr %t131, i32 0, i32 8
  %t134 = load i64, ptr %l4, !tbaa !24
  %t137 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t133, i64 %t134)
  store i1 %t137, ptr %l81
  br label %bb48
bb48:
  %t138 = load i1, ptr %l81, !tbaa !21
  br i1 %t138, label %bb49, label %bb50
bb49:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l82, !tbaa !27
  br label %bb54
bb50:
  %t139 = load i1, ptr %l6, !tbaa !21
  br i1 %t139, label %bb51, label %bb52
bb51:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l84, !tbaa !27
  br label %bb53
bb52:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l84, !tbaa !27
  br label %bb53
bb53:
  %t141 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t141, ptr %l82, !tbaa !27
  br label %bb54
bb54:
  %t142 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l85, !tbaa !29
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l86, !tbaa !29
  store ptr %l5, ptr %l87, !tbaa !29
  %t145 = load i64, ptr %l3, !tbaa !24
  store i64 %t145, ptr %l88, !tbaa !24
  store { i64, ptr } %t142, ptr %l89, !tbaa !27
  %t147 = load i64, ptr %l10, !tbaa !24
  %t149 = icmp sge i64 %t147, 0
  br i1 %t149, label %bb55, label %bb56
bb55:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l93, !tbaa !29
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Body", ptr %t152, i32 0, i32 7
  %t155 = load i64, ptr %l10, !tbaa !24
  %t158 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t154, i64 %t155)
  store %"compiler/typed:Local" %t158, ptr %l97
  br label %bb57
bb56:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l92, !tbaa !27
  br label %bb59
bb57:
  %t159 = getelementptr %"compiler/typed:Local", ptr %l97, i32 0, i32 0
  %t160 = load i32, ptr %t159, !tbaa !23
  %t161 = load ptr, ptr %l93, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s6, ptr %t161, i32 %t160)
  store { i64, ptr } %t163, ptr %l99
  br label %bb58
bb58:
  %t164 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t164, ptr %l92, !tbaa !27
  br label %bb59
bb59:
  %t165 = load ptr, ptr @__olang_prog_scope
  %t166 = load ptr, ptr %l85, !tbaa !29
  %t167 = load ptr, ptr %l86, !tbaa !29
  %t168 = load ptr, ptr %l87, !tbaa !29
  %t169 = load i64, ptr %l88, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l92, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleLine(ptr %v0, ptr %v1, ptr %s0, ptr %t165, ptr %s6, ptr %t166, ptr %t167, ptr %t168, i64 %t169, { i64, ptr } %t170, { i64, ptr } %t171)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb61:
  %t172 = load ptr, ptr %l7, !tbaa !29
  %t174 = call ptr @compiler_2fcheck_2ehandleCall(ptr %v2, ptr %v2, ptr %t172)
  store ptr %t174, ptr %l101
  br label %bb62
bb62:
  %t175 = load ptr, ptr %l101, !tbaa !29
  store ptr %t175, ptr %l12, !tbaa !29
  %t176 = load ptr, ptr %l12, !tbaa !29
  %t178 = icmp eq ptr %t176, null
  br i1 %t178, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb66
bb64:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load ptr, ptr %l12, !tbaa !29
  %t184 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviewCallee(ptr %v0, ptr %v2, ptr %t180, ptr %t181)
  store i1 %t184, ptr %l107
  br label %bb65
bb65:
  %t185 = load i1, ptr %l107, !tbaa !21
  %t186 = xor i1 %t185, true
  store i1 %t186, ptr %l104, !tbaa !21
  br label %bb66
bb66:
  %t188 = load i1, ptr %l104, !tbaa !21
  br i1 %t188, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb68:
  br label %bb69
bb69:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l12, !tbaa !29
  %t193 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleCallee(ptr %v0, ptr %v2, ptr %s0, ptr %t189, ptr %t190)
  store { i64, ptr } %t193, ptr %l111
  br label %bb70
bb70:
  %t194 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t194, ptr %l13, !tbaa !27
  %t195 = load i1, ptr %l6, !tbaa !21
  br i1 %t195, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s9
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t199 = load i64, ptr %l3, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleLine(ptr %v0, ptr %v1, ptr %s0, ptr %s9, ptr %s0, ptr %t197, ptr %t198, ptr %l5, i64 %t199, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, { i64, ptr } %t200)
  br label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s10
  %t206 = load ptr, ptr %l2, !tbaa !29
  %t208 = getelementptr %"compiler/typed:LocalUses", ptr %t206, i32 0, i32 8
  %t209 = load i64, ptr %l4, !tbaa !24
  %t212 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t208, i64 %t209)
  store i1 %t212, ptr %l121
  br label %bb74
bb73:
  call void @__olang_scope_close(ptr %s9)
  br label %bb87
bb74:
  %t213 = load i1, ptr %l121, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb75, label %bb76
bb75:
  %t216 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t218 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s10, { i64, ptr } %t216, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t218, ptr %l125
  br label %bb77
bb76:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb82
bb77:
  %t219 = load i1, ptr %l125, !tbaa !21
  br i1 %t219, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb81
bb79:
  %t220 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s10, { i64, ptr } %t220, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t222, ptr %l128
  br label %bb80
bb80:
  %t223 = load i1, ptr %l128, !tbaa !21
  store i1 %t223, ptr %l126, !tbaa !21
  br label %bb81
bb81:
  %t224 = load i1, ptr %l126, !tbaa !21
  store i1 %t224, ptr %l123, !tbaa !21
  br label %bb82
bb82:
  %t225 = load i1, ptr %l123, !tbaa !21
  br i1 %t225, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s11
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t228 = load i64, ptr %l3, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleLine(ptr %v0, ptr %v1, ptr %s0, ptr %s11, ptr %s0, ptr %t226, ptr %t227, ptr %l5, i64 %t228, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, { i64, ptr } %t229)
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s11)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s10)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s1, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  %t36 = icmp eq i32 %t30, %a2
  br i1 %t36, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb2
bb10:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldResult(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l12 = alloca i1
  %l17 = alloca i64
  %l23 = alloca ptr
  %l28 = alloca i32
  %l33 = alloca i64
  %l36 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load i1, ptr %l10, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l17
  br label %bb5
bb5:
  %t30 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t31 = load i64, ptr %l17, !tbaa !24
  %t33 = icmp ne i64 %t31, %t30
  store i1 %t33, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t35 = load i1, ptr %l12, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t36 = load i32, ptr %l2, !tbaa !23
  store i32 %t36, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l23, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l28
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t63, ptr %l33
  br label %bb11
bb11:
  %t64 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t67 = or i64 %t65, %t64
  %t68 = load ptr, ptr %l23, !tbaa !29
  %t69 = load i32, ptr %l28, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t68, i32 %t69, i64 %t67)
  store i32 %t71, ptr %l36
  br label %bb12
bb12:
  %t72 = load i32, ptr %l36, !tbaa !23
  store i32 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l8 = alloca i64
  %rv = alloca i64
  %t4 = alloca { i64, [1 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [1 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [1 x i64] }, ptr %t4, i32 0, i32 0
  store i64 0, ptr %t5
  %t6 = load { i64, [1 x i64] }, ptr %t4
  %t12 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 0, %"compiler/source:Span" %a1, i32 %a2, i32 3, { i64, [1 x i64] } %t6)
  store i64 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i64, ptr %l8, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l21 = alloca i32
  %l27 = alloca i1
  %l32 = alloca i32
  %l35 = alloca ptr
  %l40 = alloca i32
  %l43 = alloca i1
  %l46 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca i1
  %l57 = alloca ptr
  %l62 = alloca i32
  %l66 = alloca i1
  %l74 = alloca i32
  %l77 = alloca ptr
  %l82 = alloca i32
  %l86 = alloca i1
  %l91 = alloca ptr
  %l96 = alloca i32
  %l99 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = icmp eq i32 %t13, %t14
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l21
  br label %bb10
bb10:
  %t30 = load i32, ptr %l21, !range !{i32 0, i32 33}
  store i32 %t30, ptr %l4
  %t31 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t33 = trunc i64 18 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb34
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l27
  br label %bb14
bb14:
  %t44 = load i1, ptr %l27, !tbaa !21
  %t45 = xor i1 %t44, true
  br i1 %t45, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l32
  br label %bb18
bb18:
  %t53 = load i32, ptr %l32, !range !{i32 0, i32 6}
  store i32 %t53, ptr %l5
  %t54 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t56 = trunc i64 0 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l35, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l40
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t70 = load i32, ptr %l2, !tbaa !23
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load ptr, ptr %l35, !tbaa !29
  %t73 = load i32, ptr %l40, !tbaa !23
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %t72, i32 %t73, i32 %t70, i64 %t71)
  store i1 %t76, ptr %l43
  br label %bb22
bb22:
  %t77 = load i1, ptr %l43, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
bb23:
  %t78 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t80 = trunc i64 1 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb24, label %bb25
bb24:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l46, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l1, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l51
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t94 = load i32, ptr %l2, !tbaa !23
  %t95 = load i64, ptr %l3, !tbaa !24
  %t96 = load ptr, ptr %l46, !tbaa !29
  %t97 = load i32, ptr %l51, !tbaa !23
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %t96, i32 %t97, i32 %t94, i64 %t95)
  store i1 %t100, ptr %l54
  br label %bb27
bb27:
  %t101 = load i1, ptr %l54, !tbaa !21
  store i1 %t101, ptr %rv
  br label %ret
bb28:
  %t102 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t104 = trunc i64 4 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l57, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l1, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l62
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t118 = load i32, ptr %l2, !tbaa !23
  %t119 = load i64, ptr %l3, !tbaa !24
  %t121 = add i64 %t119, 1
  %t122 = load ptr, ptr %l57, !tbaa !29
  %t123 = load i32, ptr %l62, !tbaa !23
  %t126 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t122, i32 %t123, i32 %t118, i64 %t121)
  store i1 %t126, ptr %l66
  br label %bb32
bb32:
  %t127 = load i1, ptr %l66, !tbaa !21
  store i1 %t127, ptr %rv
  br label %ret
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  %t129 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t131 = trunc i64 19 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb44
bb37:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l1, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l74
  br label %bb38
bb38:
  %t144 = load i32, ptr %l74, !tbaa !23
  %t145 = icmp eq i32 %t144, 0
  br i1 %t145, label %bb39, label %bb40
bb39:
  store i1 false, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l77, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i32, ptr %l1, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l82
  br label %bb42
bb42:
  %t159 = load i32, ptr %l2, !tbaa !23
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = add i64 %t160, 1
  %t163 = load ptr, ptr %l77, !tbaa !29
  %t164 = load i32, ptr %l82, !tbaa !23
  %t167 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t163, i32 %t164, i32 %t159, i64 %t162)
  store i1 %t167, ptr %l86
  br label %bb43
bb43:
  %t168 = load i1, ptr %l86, !tbaa !21
  store i1 %t168, ptr %rv
  br label %ret
bb44:
  %t169 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t171 = trunc i64 22 to i32
  %t172 = icmp eq i32 %t169, %t171
  br i1 %t172, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  %t174 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t176 = trunc i64 23 to i32
  %t177 = icmp eq i32 %t174, %t176
  br i1 %t177, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l91, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 2
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l96
  br label %bb50
bb50:
  %t190 = load i32, ptr %l2, !tbaa !23
  %t191 = load i64, ptr %l3, !tbaa !24
  %t192 = load ptr, ptr %l91, !tbaa !29
  %t193 = load i32, ptr %l96, !tbaa !23
  %t196 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %t192, i32 %t193, i32 %t190, i64 %t191)
  store i1 %t196, ptr %l99
  br label %bb51
bb51:
  %t197 = load i1, ptr %l99, !tbaa !21
  store i1 %t197, ptr %rv
  br label %ret
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store i1 false, ptr %rv
  br label %ret
bb56:
  call void @__olang_check_failed(ptr @olang_loc_aed268118a11ee23_4542719cec09658f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 4
  %t7 = getelementptr %"compiler/generic:Context", ptr %t6, i32 0, i32 2
  %t9 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisWildType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i1
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb14
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp eq i64 %t24, 1
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l15, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l21, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i32, ptr %t38, i64 0
  %t40 = load i32, ptr %t39, !tbaa !33
  %t43 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %a0, i32 %t40)
  store { i64, ptr } %t43, ptr %l23
  br label %bb11
bb10:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb13
bb11:
  %t44 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t44, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t45, ptr %l24
  br label %bb12
bb12:
  %t46 = load i1, ptr %l24, !tbaa !21
  store i1 %t46, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  %t47 = load i1, ptr %l19, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_dabacd8646f437fb_89d6d0c21504246f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l44 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca i32
  %l59 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l68 = alloca i64
  %l74 = alloca i32
  %l77 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i1
  %l96 = alloca i1
  %l97 = alloca i32
  %l102 = alloca ptr
  %l103 = alloca i32
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca i64
  %l107 = alloca i32
  %l118 = alloca i32
  %l123 = alloca i1
  %l124 = alloca i1
  %l127 = alloca i1
  %l132 = alloca i1
  %l133 = alloca i1
  %l137 = alloca i1
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t18 = trunc i64 44 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t23 = trunc i64 45 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l17, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t27 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t29 = trunc i64 46 to i32
  %t30 = icmp eq i32 %t27, %t29
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l20, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load i32, ptr %l2, !tbaa !23
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t37 = icmp eq i32 %t33, %t34
  br i1 %t37, label %bb15, label %bb16
bb14:
  br label %bb21
bb15:
  %t39 = load i32, ptr %l3, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t43 = icmp eq i32 %t39, %t40
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb18, label %bb19
bb18:
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t46, ptr %l30, !tbaa !23
  br label %bb20
bb19:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t48, ptr %l30, !tbaa !23
  br label %bb20
bb20:
  %t50 = load i32, ptr %l30, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
bb21:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l35
  br label %bb22
bb22:
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb23, label %bb24
bb23:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t57, i32 %t58)
  store i1 %t61, ptr %l39
  br label %bb25
bb24:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb30
bb25:
  %t62 = load i1, ptr %l39, !tbaa !21
  br i1 %t62, label %bb26, label %bb27
bb26:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t67 = load i32, ptr %l2, !tbaa !23
  %t70 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t66, i32 %t67)
  store i1 %t70, ptr %l44
  br label %bb28
bb27:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb29
bb28:
  %t71 = load i1, ptr %l44, !tbaa !21
  store i1 %t71, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t72 = load i1, ptr %l40, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l36, !tbaa !21
  br label %bb30
bb30:
  %t75 = load i1, ptr %l36, !tbaa !21
  br i1 %t75, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s3
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l46, !tbaa !29
  %t77 = load i32, ptr %l2, !tbaa !23
  store i32 %t77, ptr %l47, !tbaa !23
  %t78 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t80 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s3, i32 %t78)
  store { i64, ptr } %t80, ptr %l49
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t81 = load ptr, ptr %l46, !tbaa !29
  %t82 = load i32, ptr %l47, !tbaa !23
  %t83 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t84 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s3, ptr %t81, i32 %t82, { i64, ptr } %t83, i64 1)
  store i64 %t84, ptr %l50
  br label %bb34
bb34:
  %t85 = load i64, ptr %l50, !tbaa !24
  store i64 %t85, ptr %l4, !tbaa !24
  %t86 = load i64, ptr %l4, !tbaa !24
  %t88 = icmp sge i64 %t86, 0
  br i1 %t88, label %bb35, label %bb36
bb35:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l4, !tbaa !24
  %t92 = load i32, ptr %l2, !tbaa !23
  %t96 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %t90, i64 %t91, i32 %t92)
  store i32 %t96, ptr %l56
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s3)
  %t97 = load i32, ptr %l56, !tbaa !23
  store i32 %t97, ptr %rv
  br label %ret
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb39:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t98, i32 %t99)
  store i1 %t102, ptr %l59
  br label %bb40
bb40:
  %t103 = load i1, ptr %l59, !tbaa !21
  br i1 %t103, label %bb41, label %bb42
bb41:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l3, !tbaa !23
  %t108 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t104, i32 %t105)
  store i1 %t108, ptr %l63
  br label %bb43
bb42:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb44
bb43:
  %t109 = load i1, ptr %l63, !tbaa !21
  %t110 = xor i1 %t109, true
  store i1 %t110, ptr %l60, !tbaa !21
  br label %bb44
bb44:
  %t112 = load i1, ptr %l60, !tbaa !21
  br i1 %t112, label %bb45, label %bb46
bb45:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l3, !tbaa !23
  %t115 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t119 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %t113, i32 %t114, i32 %t115)
  store i64 %t119, ptr %l68
  br label %bb47
bb46:
  br label %bb52
bb47:
  %t120 = load i64, ptr %l68, !tbaa !24
  store i64 %t120, ptr %l5, !tbaa !24
  %t121 = load i64, ptr %l5, !tbaa !24
  %t123 = icmp sge i64 %t121, 0
  br i1 %t123, label %bb48, label %bb49
bb48:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i64, ptr %l5, !tbaa !24
  %t127 = load i32, ptr %l3, !tbaa !23
  %t131 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %t125, i64 %t126, i32 %t127)
  store i32 %t131, ptr %l74
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t132 = load i32, ptr %l74, !tbaa !23
  store i32 %t132, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l2, !tbaa !23
  %t137 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t133, i32 %t134)
  store i1 %t137, ptr %l77
  br label %bb53
bb53:
  %t138 = load i1, ptr %l77, !tbaa !21
  %t139 = xor i1 %t138, true
  br i1 %t139, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb57
bb55:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i32, ptr %l3, !tbaa !23
  %t145 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t141, i32 %t142)
  store i1 %t145, ptr %l82
  br label %bb56
bb56:
  %t146 = load i1, ptr %l82, !tbaa !21
  %t147 = xor i1 %t146, true
  store i1 %t147, ptr %l79, !tbaa !21
  br label %bb57
bb57:
  %t149 = load i1, ptr %l79, !tbaa !21
  br i1 %t149, label %bb58, label %bb59
bb58:
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t150, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t152 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t154 = trunc i64 105 to i32
  %t155 = icmp eq i32 %t152, %t154
  br i1 %t155, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb63
bb62:
  %t157 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t159 = trunc i64 106 to i32
  %t160 = icmp eq i32 %t157, %t159
  store i1 %t160, ptr %l87, !tbaa !21
  br label %bb63
bb63:
  %t162 = load i1, ptr %l87, !tbaa !21
  br i1 %t162, label %bb64, label %bb65
bb64:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l2, !tbaa !23
  %t167 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t167, ptr %l92
  br label %bb66
bb65:
  br label %bb74
bb66:
  %t168 = load i1, ptr %l92, !tbaa !21
  br i1 %t168, label %bb67, label %bb68
bb67:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l3, !tbaa !23
  %t173 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t169, i32 %t170)
  store i1 %t173, ptr %l96
  br label %bb69
bb68:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb70
bb69:
  %t174 = load i1, ptr %l96, !tbaa !21
  store i1 %t174, ptr %l93, !tbaa !21
  br label %bb70
bb70:
  %t175 = load i1, ptr %l93, !tbaa !21
  br i1 %t175, label %bb71, label %bb72
bb71:
  %t176 = load i32, ptr %l2, !tbaa !23
  store i32 %t176, ptr %l97, !tbaa !23
  br label %bb73
bb72:
  %t178 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t178, ptr %l97, !tbaa !23
  br label %bb73
bb73:
  %t180 = load i32, ptr %l97, !tbaa !23
  store i32 %t180, ptr %rv
  br label %ret
bb74:
  %t181 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t183 = trunc i64 70 to i32
  %t184 = icmp eq i32 %t181, %t183
  br i1 %t184, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s9
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l102, !tbaa !29
  %t187 = load i32, ptr %l2, !tbaa !23
  store i32 %t187, ptr %l103, !tbaa !23
  %t188 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s9, i32 -1, i32 -1)
  store %"compiler/source:Span" %t188, ptr %l104
  br label %bb77
bb76:
  br label %bb82
bb77:
  %t189 = load ptr, ptr %l102, !tbaa !29
  %t190 = load i32, ptr %l103, !tbaa !23
  %t191 = load %"compiler/source:Span", ptr %l104
  %t192 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %t189, i32 %t190, %"compiler/source:Span" %t191)
  store i64 %t192, ptr %l105
  br label %bb78
bb78:
  %t193 = load i64, ptr %l105, !tbaa !24
  %t194 = icmp sge i64 %t193, 0
  br i1 %t194, label %bb79, label %bb80
bb79:
  %t196 = load i32, ptr %l2, !tbaa !23
  store i32 %t196, ptr %l107, !tbaa !23
  br label %bb81
bb80:
  %t198 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t198, ptr %l107, !tbaa !23
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s9)
  %t200 = load i32, ptr %l107, !tbaa !23
  store i32 %t200, ptr %rv
  br label %ret
bb82:
  %t201 = load i32, ptr %l2, !tbaa !23
  store i32 %t201, ptr %l6, !tbaa !23
  %t203 = load i32, ptr %l2, !tbaa !23
  %t204 = load i32, ptr %l3, !tbaa !23
  %t207 = icmp ne i32 %t203, %t204
  br i1 %t207, label %bb83, label %bb84
bb83:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t213 = load i32, ptr %l2, !tbaa !23
  %t214 = load i32, ptr %l3, !tbaa !23
  %t218 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t212, i32 %t213, i32 %t214)
  store i32 %t218, ptr %l118
  br label %bb85
bb84:
  br label %bb86
bb85:
  %t219 = load i32, ptr %l118, !tbaa !23
  store i32 %t219, ptr %l6, !tbaa !23
  br label %bb86
bb86:
  %t220 = load i32, ptr %l6, !tbaa !23
  %t222 = icmp slt i32 %t220, 0
  br i1 %t222, label %bb87, label %bb88
bb87:
  %t224 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t224, ptr %rv
  br label %ret
bb88:
  br label %bb89
bb89:
  %t226 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t228 = call i1 @compiler_2fcheck_2eintOnly(i32 %t226)
  store i1 %t228, ptr %l123
  br label %bb90
bb90:
  %t229 = load i1, ptr %l123, !tbaa !21
  br i1 %t229, label %bb91, label %bb92
bb91:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l6, !tbaa !23
  %t234 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t230, i32 %t231)
  store i1 %t234, ptr %l127
  br label %bb93
bb92:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb94
bb93:
  %t235 = load i1, ptr %l127, !tbaa !21
  %t236 = xor i1 %t235, true
  store i1 %t236, ptr %l124, !tbaa !21
  br label %bb94
bb94:
  %t238 = load i1, ptr %l124, !tbaa !21
  br i1 %t238, label %bb95, label %bb96
bb95:
  %t239 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t239, ptr %rv
  br label %ret
bb96:
  br label %bb97
bb97:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l6, !tbaa !23
  %t245 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t241, i32 %t242)
  store i1 %t245, ptr %l132
  br label %bb98
bb98:
  %t246 = load i1, ptr %l132, !tbaa !21
  br i1 %t246, label %bb99, label %bb100
bb99:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t247, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t251 = load i32, ptr %l6, !tbaa !23
  %t254 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t250, i32 %t251)
  store i1 %t254, ptr %l137
  br label %bb101
bb100:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb102
bb101:
  %t255 = load i1, ptr %l137, !tbaa !21
  %t256 = xor i1 %t255, true
  store i1 %t256, ptr %l133, !tbaa !21
  br label %bb102
bb102:
  %t258 = load i1, ptr %l133, !tbaa !21
  br i1 %t258, label %bb103, label %bb104
bb103:
  %t259 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t259, ptr %rv
  br label %ret
bb104:
  br label %bb105
bb105:
  %t261 = load i32, ptr %l6, !tbaa !23
  store i32 %t261, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l16 = alloca { i64, ptr }
  %l22 = alloca %"compiler/check:laneNode"
  %l28 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/diagmsg:Msg"
  %l37 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 47
  %t29 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t25, i64 %t21)
  store %"compiler/check:laneNode" %t29, ptr %l22
  br label %bb5
bb5:
  %t30 = getelementptr %"compiler/check:laneNode", ptr %l22, i32 0, i32 9
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  %t33 = load i64, ptr %l8, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  br i1 %t35, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb7:
  br label %bb8
bb8:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp sge i64 %t37, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp ne i64 %t41, %t42
  store i1 %t45, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l28, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l32, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l33
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneLengths(ptr %v0, i64 %t50, i64 %t51)
  store %"compiler/diagmsg:Msg" %t54, ptr %l36
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l33
  %t57 = load %"compiler/diagmsg:Msg", ptr %l36
  %t58 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t55, %"compiler/source:Span" %t56, %"compiler/diagmsg:Msg" %t57)
  store i64 %t58, ptr %l37
  br label %bb15
bb15:
  %t59 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t59, ptr %rv
  br label %ret
bb16:
  %t61 = load i64, ptr %l8, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l5, !tbaa !24
  br label %bb1
bb18:
  %t67 = load i64, ptr %l3, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTotal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4, i32 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca %"compiler/check:laneNode"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, i64, i64, i64, i64 }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca { i64, i64, i64, i64, i64 }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %lp31 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca { i64, i64, i64, i64, i64 }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i64
  %lp47 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca %"compiler/check:laneNode"
  %l69 = alloca ptr
  %l71 = alloca i1
  %l74 = alloca i32
  %l78 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i1
  %l85 = alloca i1
  %l86 = alloca i1
  %l89 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca i32
  %l96 = alloca i32
  %l102 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l108 = alloca i32
  %l115 = alloca ptr
  %l117 = alloca i1
  %l118 = alloca i1
  %l120 = alloca i1
  %l121 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca %"compiler/source:Span"
  %l129 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l134 = alloca %"compiler/diagmsg:Msg"
  %l135 = alloca i64
  %l138 = alloca ptr
  %l141 = alloca i64
  %l145 = alloca %"compiler/check:laneVals"
  %l150 = alloca ptr
  %l152 = alloca i1
  %l156 = alloca i64
  %l157 = alloca ptr
  %l158 = alloca %"compiler/source:Span"
  %l161 = alloca i32
  %l165 = alloca ptr
  %l171 = alloca { i64, i64, i64, i64, i64 }
  %l177 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l179 = alloca %"compiler/source:Span"
  %l180 = alloca i32
  %l184 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca %"compiler/source:Span"
  %l187 = alloca i64
  %l188 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca ptr
  %l196 = alloca ptr
  %l197 = alloca ptr
  %l198 = alloca %"compiler/source:Span"
  %l205 = alloca ptr
  %l210 = alloca ptr
  %l220 = alloca %"compiler/source:Span"
  %l221 = alloca i32
  %l225 = alloca { i64, ptr }
  %l229 = alloca ptr
  %l231 = alloca %"compiler/typed:Seq"
  %l236 = alloca i1
  %l237 = alloca i1
  %l239 = alloca i1
  %l241 = alloca i1
  %l245 = alloca i64
  %l246 = alloca ptr
  %l247 = alloca %"compiler/source:Span"
  %l250 = alloca i32
  %l251 = alloca ptr
  %l252 = alloca %"compiler/source:Span"
  %l253 = alloca i32
  %l255 = alloca i64
  %l256 = alloca ptr
  %l262 = alloca { i64, i64, i64, i64, i64 }
  %l268 = alloca ptr
  %l269 = alloca %"compiler/source:Span"
  %l270 = alloca i64
  %l271 = alloca ptr
  %l275 = alloca ptr
  %l276 = alloca ptr
  %l279 = alloca i64
  %l281 = alloca ptr
  %l282 = alloca %"compiler/source:Span"
  %l289 = alloca ptr
  %l290 = alloca ptr
  %l291 = alloca %"compiler/source:Span"
  %l292 = alloca i32
  %l294 = alloca i64
  %l295 = alloca ptr
  %l308 = alloca ptr
  %l312 = alloca i32
  %l316 = alloca { i64, ptr }
  %l317 = alloca %"compiler/typed:Block"
  %l318 = alloca ptr
  %l319 = alloca %"compiler/source:Span"
  %l321 = alloca ptr
  %l326 = alloca ptr
  %l328 = alloca %"compiler/typed:If"
  %l339 = alloca %"compiler/source:Span"
  %l340 = alloca i32
  %l344 = alloca { i64, ptr }
  %l348 = alloca ptr
  %l350 = alloca %"compiler/typed:Seq"
  %l354 = alloca ptr
  %l356 = alloca i32
  %l357 = alloca { i64, ptr }
  %l359 = alloca i32
  %l360 = alloca ptr
  %l361 = alloca %"compiler/source:Span"
  %l362 = alloca %"compiler/source:Span"
  %l363 = alloca i32
  %l364 = alloca i32
  %l365 = alloca i32
  %l368 = alloca { i64, ptr }
  %l373 = alloca ptr
  %l374 = alloca %"compiler/source:Span"
  %l376 = alloca i32
  %l377 = alloca i64
  %l378 = alloca ptr
  %l379 = alloca %"compiler/source:Span"
  %l382 = alloca i32
  %l383 = alloca ptr
  %l384 = alloca %"compiler/source:Span"
  %l386 = alloca i32
  %l387 = alloca ptr
  %l394 = alloca i64
  %l395 = alloca ptr
  %l396 = alloca %"compiler/source:Span"
  %l397 = alloca i64
  %l398 = alloca ptr
  %l402 = alloca ptr
  %l403 = alloca ptr
  %l416 = alloca i64
  %l417 = alloca ptr
  %l418 = alloca %"compiler/source:Span"
  %l421 = alloca i32
  %l426 = alloca ptr
  %l429 = alloca ptr
  %l430 = alloca %"compiler/source:Span"
  %l435 = alloca ptr
  %l436 = alloca { i64, i64, i64, i64, i64 }
  %l445 = alloca i64
  %l446 = alloca ptr
  %l447 = alloca %"compiler/source:Span"
  %l450 = alloca i32
  %l451 = alloca ptr
  %l452 = alloca ptr
  %l453 = alloca %"compiler/source:Span"
  %l454 = alloca i64
  %l455 = alloca ptr
  %l459 = alloca ptr
  %l460 = alloca ptr
  %l463 = alloca ptr
  %l467 = alloca i1
  %l468 = alloca ptr
  %l469 = alloca ptr
  %l470 = alloca %"compiler/source:Span"
  %l471 = alloca %"compiler/source:Span"
  %l472 = alloca i32
  %l476 = alloca ptr
  %l480 = alloca ptr
  %l483 = alloca ptr
  %l484 = alloca ptr
  %l485 = alloca %"compiler/source:Span"
  %l486 = alloca %"compiler/source:Span"
  %l487 = alloca i32
  %l491 = alloca ptr
  %l495 = alloca ptr
  %l498 = alloca ptr
  %l501 = alloca ptr
  %l504 = alloca i32
  %l505 = alloca i1
  %l506 = alloca ptr
  %l507 = alloca %"compiler/source:Span"
  %l508 = alloca i32
  %l509 = alloca i32
  %l513 = alloca ptr
  %l517 = alloca ptr
  %l519 = alloca ptr
  %l520 = alloca %"compiler/source:Span"
  %l521 = alloca i32
  %l522 = alloca ptr
  %l526 = alloca ptr
  %l529 = alloca %"compiler/typed:Cond"
  %l535 = alloca i64
  %l537 = alloca ptr
  %l538 = alloca %"compiler/source:Span"
  %l545 = alloca ptr
  %l549 = alloca ptr
  %l553 = alloca ptr
  %l557 = alloca i32
  %l561 = alloca { i64, ptr }
  %l562 = alloca %"compiler/typed:Block"
  %l563 = alloca ptr
  %l564 = alloca %"compiler/source:Span"
  %l567 = alloca %"compiler/typed:If"
  %l578 = alloca %"compiler/source:Span"
  %l579 = alloca i32
  %l583 = alloca { i64, ptr }
  %l587 = alloca ptr
  %l589 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t253 = alloca { i64, [3 x i64] }, align 8
  %t337 = alloca { i64, [4 x i64] }, align 8
  %t358 = alloca { i64, [3 x i64] }, align 8
  %t408 = alloca { i64, [5 x i64] }, align 8
  %t458 = alloca { i64, [3 x i64] }, align 8
  %t529 = alloca { i64, [4 x i64] }, align 8
  %t551 = alloca { i64, [3 x i64] }, align 8
  %t573 = alloca { i64, [3 x i64] }, align 8
  %t630 = alloca { i64, [3 x i64] }, align 8
  %t678 = alloca { i64, [5 x i64] }, align 8
  %t719 = alloca { i64, [5 x i64] }, align 8
  %t735 = alloca { i64, [3 x i64] }, align 8
  %t772 = alloca { i64, [3 x i64] }, align 8
  %t864 = alloca { i64, [3 x i64] }, align 8
  %t948 = alloca { i64, [3 x i64] }, align 8
  %t1084 = alloca { i64, [5 x i64] }, align 8
  %t1113 = alloca { i64, [4 x i64] }, align 8
  %t1132 = alloca { i64, [3 x i64] }, align 8
  %t1178 = alloca { i64, [3 x i64] }, align 8
  %t1226 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l5, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load %"compiler/source:Span", ptr %l2
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = load i32, ptr %l5, !tbaa !23
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSumIn(ptr %v0, ptr %v2, ptr %t7, %"compiler/source:Span" %t8, %"compiler/source:Span" %t9, i64 %t10, i32 %t11, %"compiler/source:Span" %a6)
  store ptr %t19, ptr %l57
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load ptr, ptr %l57, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 47
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store %"compiler/check:laneNode" %t27, ptr %l61
  br label %bb5
bb5:
  %t28 = load %"compiler/check:laneNode", ptr %l61
  store %"compiler/check:laneNode" %t28, ptr %l7
  %t29 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 8
  %t30 = load i32, ptr %t29, !tbaa !23
  store i32 %t30, ptr %l8, !tbaa !23
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp eq i32 %t32, %t33
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSay(ptr %v0, ptr %v2, ptr %t38, %"compiler/source:Span" %t39, i64 %t40)
  store ptr %t44, ptr %l69
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load ptr, ptr %l69, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t46, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t48, ptr %l71
  br label %bb10
bb10:
  %t49 = load i1, ptr %l71, !tbaa !21
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  %t54 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantedAt(ptr %v0, ptr %t50, %"compiler/source:Span" %t51)
  store i32 %t54, ptr %l74
  br label %bb13
bb12:
  br label %bb38
bb13:
  %t55 = load i32, ptr %l74, !tbaa !23
  store i32 %t55, ptr %l9, !tbaa !23
  %t56 = load i32, ptr %l9, !tbaa !23
  %t57 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t60 = icmp eq i32 %t56, %t57
  br i1 %t60, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb17
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l9, !tbaa !23
  %t66 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l81
  br label %bb16
bb16:
  %t67 = load i1, ptr %l81, !tbaa !21
  store i1 %t67, ptr %l78, !tbaa !21
  br label %bb17
bb17:
  %t68 = load i1, ptr %l78, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb21
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l9, !tbaa !23
  %t73 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t73, ptr %l85
  br label %bb20
bb20:
  %t74 = load i1, ptr %l85, !tbaa !21
  store i1 %t74, ptr %l82, !tbaa !21
  br label %bb21
bb21:
  %t75 = load i1, ptr %l82, !tbaa !21
  br i1 %t75, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb25
bb23:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l9, !tbaa !23
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l89
  br label %bb24
bb24:
  %t81 = load i1, ptr %l89, !tbaa !21
  %t82 = xor i1 %t81, true
  store i1 %t82, ptr %l86, !tbaa !21
  br label %bb25
bb25:
  %t84 = load i1, ptr %l86, !tbaa !21
  br i1 %t84, label %bb26, label %bb27
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l92, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l8, !tbaa !23
  %t93 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l95
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t94 = load ptr, ptr %l92, !tbaa !29
  %t95 = load i32, ptr %l95, !tbaa !23
  %t96 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAccumulator(ptr %v0, ptr %t94, i32 %t95)
  store i32 %t96, ptr %l96
  br label %bb29
bb29:
  %t97 = load i32, ptr %l96, !tbaa !23
  store i32 %t97, ptr %l9, !tbaa !23
  br label %bb30
bb30:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 2
  %t104 = load i32, ptr %l9, !tbaa !23
  %t105 = load i32, ptr %l8, !tbaa !23
  %t109 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t103, i32 %t104, i32 %t105)
  store i1 %t109, ptr %l102
  br label %bb31
bb31:
  %t110 = load i1, ptr %l102, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb32, label %bb33
bb32:
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l104, !tbaa !29
  %t114 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t114, ptr %l105
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l8, !tbaa !23
  %t119 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l108
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t120 = load ptr, ptr %l104, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l105
  %t122 = load i32, ptr %l108, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etotalSite(ptr %v0, ptr %t120, %"compiler/source:Span" %t121, i32 %t122)
  br label %bb35
bb35:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t125 = load %"compiler/source:Span", ptr %l2
  %t126 = load i64, ptr %l4, !tbaa !24
  %t127 = load i32, ptr %l9, !tbaa !23
  %t128 = load %"compiler/source:Span", ptr %l2
  %t135 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSumIn(ptr %v0, ptr %v2, ptr %t123, %"compiler/source:Span" %t124, %"compiler/source:Span" %t125, i64 %t126, i32 %t127, %"compiler/source:Span" %t128)
  store ptr %t135, ptr %l115
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load ptr, ptr %l115, !tbaa !29
  store ptr %t136, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t137, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t139, ptr %l117
  br label %bb39
bb39:
  %t140 = load i1, ptr %l117, !tbaa !21
  br i1 %t140, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb43
bb41:
  %t141 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t143 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t141, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t143, ptr %l120
  br label %bb42
bb42:
  %t144 = load i1, ptr %l120, !tbaa !21
  store i1 %t144, ptr %l118, !tbaa !21
  br label %bb43
bb43:
  %t145 = load i1, ptr %l118, !tbaa !21
  br i1 %t145, label %bb44, label %bb45
bb44:
  %t146 = load i32, ptr %l8, !tbaa !23
  %t147 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t150 = icmp ne i32 %t146, %t147
  store i1 %t150, ptr %l121, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb46
bb46:
  %t152 = load i1, ptr %l121, !tbaa !21
  br i1 %t152, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s6
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l125, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t154, ptr %l126
  %t155 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t159 = extractvalue { i64, ptr } %t155, 1
  %t160 = extractvalue { i64, ptr } %t155, 0
  %t161 = add i64 %t157, %t160
  %t162 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t164 = add i64 %t161, %t163
  %t165 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t164)
  call void @olang_textcopy(ptr %t165, ptr %t156, i64 %t157)
  %t166 = getelementptr i8, ptr %t165, i64 %t157
  call void @olang_textcopy(ptr %t166, ptr %t159, i64 %t160)
  %t167 = getelementptr i8, ptr %t166, i64 %t160
  call void @olang_textcopy(ptr %t167, ptr %t162, i64 %t163)
  %t168 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t165, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = extractvalue { i64, ptr } %t169, 1
  %t173 = mul i64 %t171, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l129, !tbaa !27
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l8, !tbaa !23
  %t181 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t177, i32 %t178)
  store { i64, ptr } %t181, ptr %l132
  br label %bb49
bb48:
  br label %bb53
bb49:
  %t182 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t189 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t191 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneMaskBool(ptr %s6, ptr %s6, ptr %v0, { i64, ptr } %t189, { i64, ptr } %t188)
  store %"compiler/diagmsg:Msg" %t191, ptr %l134
  br label %bb50
bb50:
  %t192 = load ptr, ptr %l125, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l126
  %t194 = load %"compiler/diagmsg:Msg", ptr %l134
  %t195 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t192, %"compiler/source:Span" %t193, %"compiler/diagmsg:Msg" %t194)
  store i64 %t195, ptr %l135
  br label %bb51
bb51:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l1
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t196, %"compiler/source:Span" %t197)
  store ptr %t200, ptr %l138
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t201 = load ptr, ptr %l138, !tbaa !29
  store ptr %t201, ptr %rv
  br label %ret
bb53:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/check:Checker", ptr %t202, i32 0, i32 45
  %t206 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t204)
  store i64 %t206, ptr %l141
  br label %bb54
bb54:
  %t207 = load i64, ptr %l141, !tbaa !24
  store i64 %t207, ptr %l10, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l1
  %t210 = load i64, ptr %l4, !tbaa !24
  %t214 = call %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %v2, ptr %t208, %"compiler/source:Span" %t209, i64 %t210)
  store %"compiler/check:laneVals" %t214, ptr %l145
  br label %bb55
bb55:
  %t215 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 88, i64 8)
  store ptr %t215, ptr %lp11
  %t216 = load %"compiler/check:laneVals", ptr %l145
  %t217 = load ptr, ptr %lp11
  store %"compiler/check:laneVals" %t216, ptr %t217
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l1
  %t220 = load i64, ptr %l4, !tbaa !24
  %t221 = load ptr, ptr %lp11
  %t226 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v2, ptr %v2, ptr %t218, %"compiler/source:Span" %t219, i64 %t220, ptr %t221)
  store ptr %t226, ptr %l150
  br label %bb56
bb56:
  %t227 = load ptr, ptr %l150, !tbaa !29
  store ptr %t227, ptr %l12, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t230 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t228, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t230, ptr %l152
  br label %bb57
bb57:
  %t231 = load i1, ptr %l152, !tbaa !21
  br i1 %t231, label %bb58, label %bb59
bb58:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l1
  %t234 = load i32, ptr %l8, !tbaa !23
  %t238 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t232, %"compiler/source:Span" %t233, i32 %t234)
  store i64 %t238, ptr %l156
  br label %bb60
bb59:
  br label %bb74
bb60:
  %t239 = load i64, ptr %l156, !tbaa !24
  store i64 %t239, ptr %l13, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l157, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t241, ptr %l158
  %t242 = load i64, ptr %l13, !tbaa !24
  %t244 = trunc i64 %t242 to i32
  store i32 %t244, ptr %l161, !tbaa !23
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l1
  %t248 = load i32, ptr %l8, !tbaa !23
  %t252 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t246, %"compiler/source:Span" %t247, i32 %t248)
  store ptr %t252, ptr %l165
  br label %bb61
bb61:
  store { i64, [3 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [3 x i64] }, ptr %t253, i32 0, i32 0
  store i64 0, ptr %t254
  %t255 = load %"compiler/source:Span", ptr %l158
  %t256 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t255, 0
  %t257 = load i32, ptr %l161, !tbaa !23
  %t258 = insertvalue { %"compiler/source:Span", i32, ptr } %t256, i32 %t257, 1
  %t259 = load ptr, ptr %l165, !tbaa !29
  %t260 = insertvalue { %"compiler/source:Span", i32, ptr } %t258, ptr %t259, 2
  %t261 = getelementptr { i64, [3 x i64] }, ptr %t253, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t260, ptr %t261
  %t262 = load { i64, [3 x i64] }, ptr %t253
  %t264 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t262, ptr %t264
  %t265 = load ptr, ptr %l157, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t265, ptr %t264)
  br label %bb62
bb62:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l1
  %t269 = load ptr, ptr %l12, !tbaa !29
  %t273 = call { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %v2, ptr %v0, ptr %t267, %"compiler/source:Span" %t268, ptr %t269, i64 0, ptr null)
  store { i64, i64, i64, i64, i64 } %t273, ptr %l171
  br label %bb63
bb63:
  %t274 = load { i64, i64, i64, i64, i64 }, ptr %l171
  store { i64, i64, i64, i64, i64 } %t274, ptr %l14
  %t275 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l14, i32 0, i32 0
  %t276 = load i64, ptr %t275, !tbaa !24
  store i64 %t276, ptr %l15, !tbaa !24
  %t278 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l14, i32 0, i32 1
  %t279 = load i64, ptr %t278, !tbaa !24
  store i64 %t279, ptr %l16, !tbaa !24
  %t281 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l14, i32 0, i32 2
  %t282 = load i64, ptr %t281, !tbaa !24
  store i64 %t282, ptr %l17, !tbaa !24
  %t284 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l14, i32 0, i32 3
  %t285 = load i64, ptr %t284, !tbaa !24
  store i64 %t285, ptr %l18, !tbaa !24
  %t287 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l14, i32 0, i32 4
  %t288 = load i64, ptr %t287, !tbaa !24
  store i64 %t288, ptr %l19, !tbaa !24
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l177, !tbaa !29
  %t291 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t291, ptr %l178
  %t292 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t292, ptr %l179
  store i32 67, ptr %l180
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l1
  %t295 = load i64, ptr %l13, !tbaa !24
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t293, %"compiler/source:Span" %t294, i64 %t295)
  store ptr %t299, ptr %l184
  br label %bb64
bb64:
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l185, !tbaa !29
  %t301 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t301, ptr %l186
  %t302 = load i64, ptr %l4, !tbaa !24
  store i64 %t302, ptr %l187, !tbaa !24
  %t303 = load ptr, ptr %lp11
  store ptr %t303, ptr %l188, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l1
  %t306 = load i64, ptr %l15, !tbaa !24
  %t310 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t304, %"compiler/source:Span" %t305, i64 %t306)
  store ptr %t310, ptr %l192
  br label %bb65
bb65:
  %t311 = load ptr, ptr %l185, !tbaa !29
  %t312 = load %"compiler/source:Span", ptr %l186
  %t313 = load i64, ptr %l187, !tbaa !24
  %t314 = load ptr, ptr %l188, !tbaa !29
  %t315 = load ptr, ptr %l192, !tbaa !29
  %t316 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %t311, %"compiler/source:Span" %t312, i64 %t313, ptr %t314, ptr %t315)
  store ptr %t316, ptr %l193
  br label %bb66
bb66:
  %t317 = load %"compiler/source:Span", ptr %l1
  %t318 = load %"compiler/source:Span", ptr %l1
  %t319 = load ptr, ptr %l177, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l178
  %t321 = load %"compiler/source:Span", ptr %l179
  %t322 = load i32, ptr %l180, !range !{i32 0, i32 113}
  %t323 = load ptr, ptr %l184, !tbaa !29
  %t324 = load ptr, ptr %l193, !tbaa !29
  %t327 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %t319, %"compiler/source:Span" %t320, %"compiler/source:Span" %t321, i32 %t322, ptr %t323, ptr %t324, %"compiler/source:Span" %t317, %"compiler/source:Span" %t318)
  store ptr %t327, ptr %l196
  br label %bb67
bb67:
  %t328 = load ptr, ptr %l196, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  store ptr %t329, ptr %l197, !tbaa !29
  %t330 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t330, ptr %l198
  %t331 = load %"compiler/source:Span", ptr %l1
  %t332 = load i32, ptr %l8, !tbaa !23
  %t333 = load i64, ptr %l13, !tbaa !24
  %t335 = trunc i64 %t333 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t337
  %t338 = getelementptr { i64, [4 x i64] }, ptr %t337, i32 0, i32 0
  store i64 0, ptr %t338
  %t340 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t331, 0
  %t342 = insertvalue { %"compiler/source:Span", i32, i32 } %t340, i32 %t332, 1
  %t344 = insertvalue { %"compiler/source:Span", i32, i32 } %t342, i32 %t335, 2
  %t345 = getelementptr { i64, [4 x i64] }, ptr %t337, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t344, ptr %t345
  %t346 = load { i64, [4 x i64] }, ptr %t337
  %t348 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t346, ptr %t348
  store ptr %t348, ptr %l205, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = load i32, ptr %l8, !tbaa !23
  %t352 = load %"compiler/source:Span", ptr %l1
  %t357 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t349, ptr %t328, i32 %t351, %"compiler/source:Span" %t352)
  store ptr %t357, ptr %l210
  br label %bb68
bb68:
  store { i64, [3 x i64] } zeroinitializer, ptr %t358
  %t359 = getelementptr { i64, [3 x i64] }, ptr %t358, i32 0, i32 0
  store i64 1, ptr %t359
  %t360 = load %"compiler/source:Span", ptr %l198
  %t361 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t360, 0
  %t362 = load ptr, ptr %l205, !tbaa !29
  %t363 = insertvalue { %"compiler/source:Span", ptr, ptr } %t361, ptr %t362, 1
  %t364 = load ptr, ptr %l210, !tbaa !29
  %t365 = insertvalue { %"compiler/source:Span", ptr, ptr } %t363, ptr %t364, 2
  %t366 = getelementptr { i64, [3 x i64] }, ptr %t358, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t365, ptr %t366
  %t367 = load { i64, [3 x i64] }, ptr %t358
  %t369 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t367, ptr %t369
  %t370 = load ptr, ptr %l197, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t370, ptr %t369)
  br label %bb69
bb69:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load %"compiler/source:Span", ptr %l1
  %t374 = load i64, ptr %l15, !tbaa !24
  %t375 = load i64, ptr %l16, !tbaa !24
  %t376 = load i64, ptr %l17, !tbaa !24
  %t377 = load i64, ptr %l18, !tbaa !24
  %t378 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %t372, %"compiler/source:Span" %t373, i64 %t374, i64 %t375, i64 %t376, i64 %t377, i64 %t378, i64 1)
  br label %bb70
bb70:
  %t386 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t386, ptr %l220
  %t387 = load i32, ptr %l8, !tbaa !23
  store i32 %t387, ptr %l221, !tbaa !23
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 45
  %t391 = load i64, ptr %l10, !tbaa !24
  %t394 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t390, i64 %t391)
  store { i64, ptr } %t394, ptr %l225
  br label %bb71
bb71:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l1
  %t397 = load i64, ptr %l13, !tbaa !24
  %t401 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t395, %"compiler/source:Span" %t396, i64 %t397)
  store ptr %t401, ptr %l229
  br label %bb72
bb72:
  %t402 = load ptr, ptr %l229, !tbaa !29
  %t403 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t405 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t403, ptr %t402, i1 false)
  store %"compiler/typed:Seq" %t405, ptr %l231
  br label %bb73
bb73:
  %t406 = load %"compiler/typed:Seq", ptr %l231
  %t407 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t406, ptr %t407
  store { i64, [5 x i64] } zeroinitializer, ptr %t408
  %t409 = getelementptr { i64, [5 x i64] }, ptr %t408, i32 0, i32 0
  store i64 12, ptr %t409
  %t410 = load %"compiler/source:Span", ptr %l220
  %t411 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t410, 0
  %t412 = load i32, ptr %l221, !tbaa !23
  %t413 = insertvalue { %"compiler/source:Span", i32, ptr } %t411, i32 %t412, 1
  %t415 = insertvalue { %"compiler/source:Span", i32, ptr } %t413, ptr %t407, 2
  %t416 = getelementptr { i64, [5 x i64] }, ptr %t408, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t415, ptr %t416
  %t417 = load { i64, [5 x i64] }, ptr %t408
  %t419 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t417, ptr %t419
  call void @__olang_scope_close(ptr %s0)
  store ptr %t419, ptr %rv
  br label %ret
bb74:
  %t421 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t423 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t421, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t423, ptr %l236
  br label %bb75
bb75:
  %t424 = load i1, ptr %l236, !tbaa !21
  br i1 %t424, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l237, !tbaa !21
  br label %bb79
bb77:
  %t425 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t427 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t425, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t427, ptr %l239
  br label %bb78
bb78:
  %t428 = load i1, ptr %l239, !tbaa !21
  store i1 %t428, ptr %l237, !tbaa !21
  br label %bb79
bb79:
  %t429 = load i1, ptr %l237, !tbaa !21
  br i1 %t429, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s9
  %t430 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t432 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s9, { i64, ptr } %t430, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t432, ptr %l241
  br label %bb82
bb81:
  br label %bb112
bb82:
  %t433 = load i1, ptr %l241, !tbaa !21
  store i1 %t433, ptr %l21, !tbaa !21
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load %"compiler/source:Span", ptr %l1
  %t436 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t440 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t434, %"compiler/source:Span" %t435, i32 %t436)
  store i64 %t440, ptr %l245
  br label %bb83
bb83:
  %t441 = load i64, ptr %l245, !tbaa !24
  store i64 %t441, ptr %l22, !tbaa !24
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l246, !tbaa !29
  %t443 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t443, ptr %l247
  %t444 = load i64, ptr %l22, !tbaa !24
  %t446 = trunc i64 %t444 to i32
  store i32 %t446, ptr %l250, !tbaa !23
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l251, !tbaa !29
  %t449 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t449, ptr %l252
  %t450 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t450, ptr %l253, !tbaa !23
  %t451 = load i1, ptr %l21, !tbaa !21
  br i1 %t451, label %bb84, label %bb85
bb84:
  store i64 0, ptr %l255, !tbaa !24
  br label %bb86
bb85:
  store i64 1, ptr %l255, !tbaa !24
  br label %bb86
bb86:
  %t453 = load ptr, ptr %l251, !tbaa !29
  %t454 = load %"compiler/source:Span", ptr %l252
  %t455 = load i32, ptr %l253, !tbaa !23
  %t456 = load i64, ptr %l255, !tbaa !24
  %t457 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t453, %"compiler/source:Span" %t454, i32 %t455, i64 %t456)
  store ptr %t457, ptr %l256
  br label %bb87
bb87:
  store { i64, [3 x i64] } zeroinitializer, ptr %t458
  %t459 = getelementptr { i64, [3 x i64] }, ptr %t458, i32 0, i32 0
  store i64 0, ptr %t459
  %t460 = load %"compiler/source:Span", ptr %l247
  %t461 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t460, 0
  %t462 = load i32, ptr %l250, !tbaa !23
  %t463 = insertvalue { %"compiler/source:Span", i32, ptr } %t461, i32 %t462, 1
  %t464 = load ptr, ptr %l256, !tbaa !29
  %t465 = insertvalue { %"compiler/source:Span", i32, ptr } %t463, ptr %t464, 2
  %t466 = getelementptr { i64, [3 x i64] }, ptr %t458, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t465, ptr %t466
  %t467 = load { i64, [3 x i64] }, ptr %t458
  %t469 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t467, ptr %t469
  %t470 = load ptr, ptr %l246, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t470, ptr %t469)
  br label %bb88
bb88:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load %"compiler/source:Span", ptr %l1
  %t474 = load ptr, ptr %l12, !tbaa !29
  %t478 = call { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %v2, ptr %v0, ptr %t472, %"compiler/source:Span" %t473, ptr %t474, i64 0, ptr null)
  store { i64, i64, i64, i64, i64 } %t478, ptr %l262
  br label %bb89
bb89:
  %t479 = load { i64, i64, i64, i64, i64 }, ptr %l262
  store { i64, i64, i64, i64, i64 } %t479, ptr %l23
  %t480 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l23, i32 0, i32 0
  %t481 = load i64, ptr %t480, !tbaa !24
  store i64 %t481, ptr %l24, !tbaa !24
  %t483 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l23, i32 0, i32 1
  %t484 = load i64, ptr %t483, !tbaa !24
  store i64 %t484, ptr %l25, !tbaa !24
  %t486 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l23, i32 0, i32 2
  %t487 = load i64, ptr %t486, !tbaa !24
  store i64 %t487, ptr %l26, !tbaa !24
  %t489 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l23, i32 0, i32 3
  %t490 = load i64, ptr %t489, !tbaa !24
  store i64 %t490, ptr %l27, !tbaa !24
  %t492 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l23, i32 0, i32 4
  %t493 = load i64, ptr %t492, !tbaa !24
  store i64 %t493, ptr %l28, !tbaa !24
  %t495 = load ptr, ptr %l0, !tbaa !29
  store ptr %t495, ptr %l268, !tbaa !29
  %t496 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t496, ptr %l269
  %t497 = load i64, ptr %l4, !tbaa !24
  store i64 %t497, ptr %l270, !tbaa !24
  %t498 = load ptr, ptr %lp11
  store ptr %t498, ptr %l271, !tbaa !29
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t500 = load %"compiler/source:Span", ptr %l1
  %t501 = load i64, ptr %l24, !tbaa !24
  %t505 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t499, %"compiler/source:Span" %t500, i64 %t501)
  store ptr %t505, ptr %l275
  br label %bb90
bb90:
  %t506 = load ptr, ptr %l268, !tbaa !29
  %t507 = load %"compiler/source:Span", ptr %l269
  %t508 = load i64, ptr %l270, !tbaa !24
  %t509 = load ptr, ptr %l271, !tbaa !29
  %t510 = load ptr, ptr %l275, !tbaa !29
  %t511 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t506, %"compiler/source:Span" %t507, i64 %t508, ptr %t509, ptr %t510)
  store ptr %t511, ptr %l276
  br label %bb91
bb91:
  %t512 = load ptr, ptr %l276, !tbaa !29
  store ptr %t512, ptr %l29, !tbaa !29
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = getelementptr %"compiler/check:Checker", ptr %t513, i32 0, i32 45
  %t517 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t515)
  store i64 %t517, ptr %l279
  br label %bb92
bb92:
  %t518 = load i64, ptr %l279, !tbaa !24
  store i64 %t518, ptr %l30, !tbaa !24
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/check:Checker", ptr %t519, i32 0, i32 45
  store ptr %t521, ptr %l281, !tbaa !29
  %t522 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t522, ptr %l282
  %t523 = load %"compiler/source:Span", ptr %l1
  %t524 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t525 = load i64, ptr %l22, !tbaa !24
  %t527 = trunc i64 %t525 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t529
  %t530 = getelementptr { i64, [4 x i64] }, ptr %t529, i32 0, i32 0
  store i64 0, ptr %t530
  %t532 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t523, 0
  %t534 = insertvalue { %"compiler/source:Span", i32, i32 } %t532, i32 %t524, 1
  %t536 = insertvalue { %"compiler/source:Span", i32, i32 } %t534, i32 %t527, 2
  %t537 = getelementptr { i64, [4 x i64] }, ptr %t529, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t536, ptr %t537
  %t538 = load { i64, [4 x i64] }, ptr %t529
  %t540 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t538, ptr %t540
  store ptr %t540, ptr %l289, !tbaa !29
  %t541 = load ptr, ptr %l0, !tbaa !29
  store ptr %t541, ptr %l290, !tbaa !29
  %t542 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t542, ptr %l291
  %t543 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t543, ptr %l292, !tbaa !23
  %t544 = load i1, ptr %l21, !tbaa !21
  br i1 %t544, label %bb93, label %bb94
bb93:
  store i64 1, ptr %l294, !tbaa !24
  br label %bb95
bb94:
  store i64 0, ptr %l294, !tbaa !24
  br label %bb95
bb95:
  %t546 = load ptr, ptr %l290, !tbaa !29
  %t547 = load %"compiler/source:Span", ptr %l291
  %t548 = load i32, ptr %l292, !tbaa !23
  %t549 = load i64, ptr %l294, !tbaa !24
  %t550 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t546, %"compiler/source:Span" %t547, i32 %t548, i64 %t549)
  store ptr %t550, ptr %l295
  br label %bb96
bb96:
  store { i64, [3 x i64] } zeroinitializer, ptr %t551
  %t552 = getelementptr { i64, [3 x i64] }, ptr %t551, i32 0, i32 0
  store i64 1, ptr %t552
  %t553 = load %"compiler/source:Span", ptr %l282
  %t554 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t553, 0
  %t555 = load ptr, ptr %l289, !tbaa !29
  %t556 = insertvalue { %"compiler/source:Span", ptr, ptr } %t554, ptr %t555, 1
  %t557 = load ptr, ptr %l295, !tbaa !29
  %t558 = insertvalue { %"compiler/source:Span", ptr, ptr } %t556, ptr %t557, 2
  %t559 = getelementptr { i64, [3 x i64] }, ptr %t551, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t558, ptr %t559
  %t560 = load { i64, [3 x i64] }, ptr %t551
  %t562 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t560, ptr %t562
  %t563 = load ptr, ptr %l281, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t563, ptr %t562)
  br label %bb97
bb97:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t567 = getelementptr %"compiler/check:Checker", ptr %t565, i32 0, i32 45
  %t568 = load %"compiler/source:Span", ptr %l1
  %t569 = load i64, ptr %l25, !tbaa !24
  %t571 = trunc i64 %t569 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t573
  %t574 = getelementptr { i64, [3 x i64] }, ptr %t573, i32 0, i32 0
  store i64 5, ptr %t574
  %t576 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t568, 0
  %t578 = insertvalue { %"compiler/source:Span", i32, i32 } %t576, i32 0, 1
  %t580 = insertvalue { %"compiler/source:Span", i32, i32 } %t578, i32 %t571, 2
  %t581 = getelementptr { i64, [3 x i64] }, ptr %t573, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t580, ptr %t581
  %t582 = load { i64, [3 x i64] }, ptr %t573
  %t584 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t582, ptr %t584
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t567, ptr %t584)
  br label %bb98
bb98:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t589 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t587)
  store ptr %t589, ptr %l308
  br label %bb99
bb99:
  %t590 = load ptr, ptr %l308, !tbaa !29
  %t592 = getelementptr %"compiler/check:frame", ptr %t590, i32 0, i32 7
  %t593 = load i64, ptr %t592, !tbaa !24
  %t595 = trunc i64 %t593 to i32
  store i32 %t595, ptr %l312, !tbaa !23
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = getelementptr %"compiler/check:Checker", ptr %t597, i32 0, i32 45
  %t600 = load i64, ptr %l30, !tbaa !24
  %t603 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t599, i64 %t600)
  store { i64, ptr } %t603, ptr %l316
  br label %bb100
bb100:
  %t604 = load i32, ptr %l312, !tbaa !23
  %t605 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t606 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 %t604, { i64, ptr } %t605)
  store %"compiler/typed:Block" %t606, ptr %l317
  br label %bb101
bb101:
  %t607 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store ptr %t607, ptr %lp31
  %t608 = load %"compiler/typed:Block", ptr %l317
  %t609 = load ptr, ptr %lp31
  store %"compiler/typed:Block" %t608, ptr %t609
  %t610 = load ptr, ptr %l0, !tbaa !29
  store ptr %t610, ptr %l318, !tbaa !29
  %t611 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t611, ptr %l319
  %t612 = load i1, ptr %l21, !tbaa !21
  br i1 %t612, label %bb102, label %bb103
bb102:
  %t614 = load ptr, ptr %l29, !tbaa !29
  store ptr %t614, ptr %l321, !tbaa !29
  br label %bb105
bb103:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t617 = load %"compiler/source:Span", ptr %l1
  %t618 = load ptr, ptr %l29, !tbaa !29
  %t622 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v2, ptr %v2, ptr %t616, %"compiler/source:Span" %t617, ptr %t618)
  store ptr %t622, ptr %l326
  br label %bb104
bb104:
  %t623 = load ptr, ptr %l326, !tbaa !29
  store ptr %t623, ptr %l321, !tbaa !29
  br label %bb105
bb105:
  %t624 = load ptr, ptr %lp31
  %t625 = load ptr, ptr %l321, !tbaa !29
  %t627 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v2, ptr %v2, ptr %v0, ptr %v0, ptr %t625, ptr %t624, ptr null)
  store %"compiler/typed:If" %t627, ptr %l328
  br label %bb106
bb106:
  %t628 = load %"compiler/typed:If", ptr %l328
  %t629 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t628, ptr %t629
  store { i64, [3 x i64] } zeroinitializer, ptr %t630
  %t631 = getelementptr { i64, [3 x i64] }, ptr %t630, i32 0, i32 0
  store i64 3, ptr %t631
  %t632 = load %"compiler/source:Span", ptr %l319
  %t633 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t632, 0
  %t635 = insertvalue { %"compiler/source:Span", ptr } %t633, ptr %t629, 1
  %t636 = getelementptr { i64, [3 x i64] }, ptr %t630, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t635, ptr %t636
  %t637 = load { i64, [3 x i64] }, ptr %t630
  %t639 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t637, ptr %t639
  %t640 = load ptr, ptr %l318, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t640, ptr %t639)
  br label %bb107
bb107:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load %"compiler/source:Span", ptr %l1
  %t644 = load i64, ptr %l24, !tbaa !24
  %t645 = load i64, ptr %l25, !tbaa !24
  %t646 = load i64, ptr %l26, !tbaa !24
  %t647 = load i64, ptr %l27, !tbaa !24
  %t648 = load i64, ptr %l28, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %t642, %"compiler/source:Span" %t643, i64 %t644, i64 %t645, i64 %t646, i64 %t647, i64 %t648, i64 1)
  br label %bb108
bb108:
  %t656 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t656, ptr %l339
  %t657 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t657, ptr %l340, !tbaa !23
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t660 = getelementptr %"compiler/check:Checker", ptr %t658, i32 0, i32 45
  %t661 = load i64, ptr %l10, !tbaa !24
  %t664 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t660, i64 %t661)
  store { i64, ptr } %t664, ptr %l344
  br label %bb109
bb109:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t666 = load %"compiler/source:Span", ptr %l1
  %t667 = load i64, ptr %l22, !tbaa !24
  %t671 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t665, %"compiler/source:Span" %t666, i64 %t667)
  store ptr %t671, ptr %l348
  br label %bb110
bb110:
  %t672 = load ptr, ptr %l348, !tbaa !29
  %t673 = load { i64, ptr }, ptr %l344, !tbaa !27
  %t675 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t673, ptr %t672, i1 false)
  store %"compiler/typed:Seq" %t675, ptr %l350
  br label %bb111
bb111:
  %t676 = load %"compiler/typed:Seq", ptr %l350
  %t677 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t676, ptr %t677
  store { i64, [5 x i64] } zeroinitializer, ptr %t678
  %t679 = getelementptr { i64, [5 x i64] }, ptr %t678, i32 0, i32 0
  store i64 12, ptr %t679
  %t680 = load %"compiler/source:Span", ptr %l339
  %t681 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t680, 0
  %t682 = load i32, ptr %l340, !tbaa !23
  %t683 = insertvalue { %"compiler/source:Span", i32, ptr } %t681, i32 %t682, 1
  %t685 = insertvalue { %"compiler/source:Span", i32, ptr } %t683, ptr %t677, 2
  %t686 = getelementptr { i64, [5 x i64] }, ptr %t678, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t685, ptr %t686
  %t687 = load { i64, [5 x i64] }, ptr %t678
  %t689 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t687, ptr %t689
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t689, ptr %rv
  br label %ret
bb112:
  %t691 = load ptr, ptr %l0, !tbaa !29
  store ptr %t691, ptr %l354, !tbaa !29
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t694 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t692, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d30, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d31, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i32 %t694, ptr %l356
  br label %bb113
bb113:
  %t695 = mul i64 1, 4
  %t696 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t695)
  %t697 = insertvalue { i64, ptr } undef, i64 1, 0
  %t698 = insertvalue { i64, ptr } %t697, ptr %t696, 1
  store { i64, ptr } %t698, ptr %l357, !tbaa !27
  %t699 = load i32, ptr %l356, !tbaa !23
  %t700 = getelementptr { i64, ptr }, ptr %l357, i32 0, i32 1
  %t701 = load ptr, ptr %t700, !tbaa !27
  %t702 = getelementptr i32, ptr %t701, i64 0
  store i32 %t699, ptr %t702, !tbaa !33
  %t703 = load %"compiler/source:Span", ptr %l2
  %t704 = load ptr, ptr %l354, !tbaa !29
  %t705 = load { i64, ptr }, ptr %l357, !tbaa !27
  %t707 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t704, { i64, ptr } %t705, %"compiler/source:Span" %t703, i1 false)
  store i32 %t707, ptr %l359
  br label %bb114
bb114:
  %t708 = load i32, ptr %l359, !range !{i32 0, i32 4}
  %t709 = load ptr, ptr %l0, !tbaa !29
  store ptr %t709, ptr %l360, !tbaa !29
  %t710 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t710, ptr %l361
  %t711 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t711, ptr %l362
  %t712 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t712, ptr %l363, !tbaa !23
  store i32 38, ptr %l364
  store i32 %t708, ptr %l365
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t715 = load ptr, ptr %l12, !tbaa !29
  %t718 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v2, ptr %v0, ptr %t714, ptr %t715)
  store { i64, ptr } %t718, ptr %l368
  br label %bb115
bb115:
  store { i64, [5 x i64] } zeroinitializer, ptr %t719
  %t720 = getelementptr { i64, [5 x i64] }, ptr %t719, i32 0, i32 0
  store i64 9, ptr %t720
  %t721 = load %"compiler/source:Span", ptr %l362
  %t722 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t721, 0
  %t723 = load i32, ptr %l363, !tbaa !23
  %t724 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t722, i32 %t723, 1
  %t725 = load i32, ptr %l364, !range !{i32 0, i32 52}
  %t726 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t724, i32 %t725, 2
  %t727 = load i32, ptr %l365, !range !{i32 0, i32 4}
  %t728 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t726, i32 %t727, 3
  %t729 = load { i64, ptr }, ptr %l368, !tbaa !27
  %t730 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t728, { i64, ptr } %t729, 4
  %t731 = getelementptr { i64, [5 x i64] }, ptr %t719, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t730, ptr %t731
  %t732 = load { i64, [5 x i64] }, ptr %t719
  %t734 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t732, ptr %t734
  store { i64, [3 x i64] } zeroinitializer, ptr %t735
  %t736 = getelementptr { i64, [3 x i64] }, ptr %t735, i32 0, i32 0
  store i64 2, ptr %t736
  %t737 = load %"compiler/source:Span", ptr %l361
  %t738 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t737, 0
  %t740 = insertvalue { %"compiler/source:Span", ptr } %t738, ptr %t734, 1
  %t741 = getelementptr { i64, [3 x i64] }, ptr %t735, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t740, ptr %t741
  %t742 = load { i64, [3 x i64] }, ptr %t735
  %t744 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t742, ptr %t744
  %t745 = load ptr, ptr %l360, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t745, ptr %t744)
  br label %bb116
bb116:
  %t747 = load ptr, ptr %l0, !tbaa !29
  store ptr %t747, ptr %l373, !tbaa !29
  %t748 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t748, ptr %l374
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t751 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t749)
  store i32 %t751, ptr %l376
  br label %bb117
bb117:
  %t752 = load ptr, ptr %l373, !tbaa !29
  %t753 = load %"compiler/source:Span", ptr %l374
  %t754 = load i32, ptr %l376, !tbaa !23
  %t755 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t752, %"compiler/source:Span" %t753, i32 %t754)
  store i64 %t755, ptr %l377
  br label %bb118
bb118:
  %t756 = load i64, ptr %l377, !tbaa !24
  store i64 %t756, ptr %l33, !tbaa !24
  %t757 = load ptr, ptr %l0, !tbaa !29
  store ptr %t757, ptr %l378, !tbaa !29
  %t758 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t758, ptr %l379
  %t759 = load i64, ptr %l33, !tbaa !24
  %t761 = trunc i64 %t759 to i32
  store i32 %t761, ptr %l382, !tbaa !23
  %t763 = load ptr, ptr %l0, !tbaa !29
  store ptr %t763, ptr %l383, !tbaa !29
  %t764 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t764, ptr %l384
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t767 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t765)
  store i32 %t767, ptr %l386
  br label %bb119
bb119:
  %t768 = load ptr, ptr %l383, !tbaa !29
  %t769 = load %"compiler/source:Span", ptr %l384
  %t770 = load i32, ptr %l386, !tbaa !23
  %t771 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t768, %"compiler/source:Span" %t769, i32 %t770, i64 0)
  store ptr %t771, ptr %l387
  br label %bb120
bb120:
  store { i64, [3 x i64] } zeroinitializer, ptr %t772
  %t773 = getelementptr { i64, [3 x i64] }, ptr %t772, i32 0, i32 0
  store i64 0, ptr %t773
  %t774 = load %"compiler/source:Span", ptr %l379
  %t775 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t774, 0
  %t776 = load i32, ptr %l382, !tbaa !23
  %t777 = insertvalue { %"compiler/source:Span", i32, ptr } %t775, i32 %t776, 1
  %t778 = load ptr, ptr %l387, !tbaa !29
  %t779 = insertvalue { %"compiler/source:Span", i32, ptr } %t777, ptr %t778, 2
  %t780 = getelementptr { i64, [3 x i64] }, ptr %t772, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t779, ptr %t780
  %t781 = load { i64, [3 x i64] }, ptr %t772
  %t783 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t781, ptr %t783
  %t784 = load ptr, ptr %l378, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t784, ptr %t783)
  br label %bb121
bb121:
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t788 = getelementptr %"compiler/check:Checker", ptr %t786, i32 0, i32 1
  %t789 = load ptr, ptr %t788, !tbaa !29
  %t791 = getelementptr %"compiler/generic:Program", ptr %t789, i32 0, i32 0
  %t792 = load ptr, ptr %t791, !tbaa !29
  %t794 = getelementptr %"compiler/load:Loader", ptr %t792, i32 0, i32 4
  %t795 = load ptr, ptr %t794, !tbaa !29
  %t797 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t795)
  store i64 %t797, ptr %l394
  br label %bb122
bb122:
  %t798 = load i64, ptr %l394, !tbaa !24
  store i64 %t798, ptr %l34, !tbaa !24
  %t799 = load ptr, ptr %l0, !tbaa !29
  store ptr %t799, ptr %l395, !tbaa !29
  %t800 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t800, ptr %l396
  %t801 = load i64, ptr %l4, !tbaa !24
  store i64 %t801, ptr %l397, !tbaa !24
  %t802 = load ptr, ptr %lp11
  store ptr %t802, ptr %l398, !tbaa !29
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t804 = load %"compiler/source:Span", ptr %l1
  %t805 = load i64, ptr %l33, !tbaa !24
  %t809 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t803, %"compiler/source:Span" %t804, i64 %t805)
  store ptr %t809, ptr %l402
  br label %bb123
bb123:
  %t810 = load ptr, ptr %l395, !tbaa !29
  %t811 = load %"compiler/source:Span", ptr %l396
  %t812 = load i64, ptr %l397, !tbaa !24
  %t813 = load ptr, ptr %l398, !tbaa !29
  %t814 = load ptr, ptr %l402, !tbaa !29
  %t815 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t810, %"compiler/source:Span" %t811, i64 %t812, ptr %t813, ptr %t814)
  store ptr %t815, ptr %l403
  br label %bb124
bb124:
  %t816 = load ptr, ptr %l403, !tbaa !29
  store ptr %t816, ptr %l35, !tbaa !29
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t819 = getelementptr %"compiler/check:Checker", ptr %t817, i32 0, i32 1
  %t820 = load ptr, ptr %t819, !tbaa !29
  %t822 = getelementptr %"compiler/generic:Program", ptr %t820, i32 0, i32 0
  %t823 = load ptr, ptr %t822, !tbaa !29
  %t825 = getelementptr %"compiler/load:Loader", ptr %t823, i32 0, i32 4
  %t826 = load ptr, ptr %t825, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t826)
  br label %bb125
bb125:
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t830 = getelementptr %"compiler/check:Checker", ptr %t828, i32 0, i32 1
  %t831 = load ptr, ptr %t830, !tbaa !29
  %t833 = getelementptr %"compiler/generic:Program", ptr %t831, i32 0, i32 0
  %t834 = load ptr, ptr %t833, !tbaa !29
  %t836 = getelementptr %"compiler/load:Loader", ptr %t834, i32 0, i32 4
  %t837 = load ptr, ptr %t836, !tbaa !29
  %t838 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t837, i64 %t838)
  br label %bb126
bb126:
  %t841 = load ptr, ptr %l0, !tbaa !29
  %t842 = load %"compiler/source:Span", ptr %l1
  %t843 = load i32, ptr %l8, !tbaa !23
  %t847 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t841, %"compiler/source:Span" %t842, i32 %t843)
  store i64 %t847, ptr %l416
  br label %bb127
bb127:
  %t848 = load i64, ptr %l416, !tbaa !24
  store i64 %t848, ptr %l36, !tbaa !24
  %t849 = load ptr, ptr %l0, !tbaa !29
  store ptr %t849, ptr %l417, !tbaa !29
  %t850 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t850, ptr %l418
  %t851 = load i64, ptr %l36, !tbaa !24
  %t853 = trunc i64 %t851 to i32
  store i32 %t853, ptr %l421, !tbaa !23
  %t855 = load ptr, ptr %l0, !tbaa !29
  %t856 = load ptr, ptr %l35, !tbaa !29
  %t857 = load i32, ptr %l8, !tbaa !23
  %t858 = load %"compiler/source:Span", ptr %l1
  %t863 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t855, ptr %t856, i32 %t857, %"compiler/source:Span" %t858)
  store ptr %t863, ptr %l426
  br label %bb128
bb128:
  store { i64, [3 x i64] } zeroinitializer, ptr %t864
  %t865 = getelementptr { i64, [3 x i64] }, ptr %t864, i32 0, i32 0
  store i64 0, ptr %t865
  %t866 = load %"compiler/source:Span", ptr %l418
  %t867 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t866, 0
  %t868 = load i32, ptr %l421, !tbaa !23
  %t869 = insertvalue { %"compiler/source:Span", i32, ptr } %t867, i32 %t868, 1
  %t870 = load ptr, ptr %l426, !tbaa !29
  %t871 = insertvalue { %"compiler/source:Span", i32, ptr } %t869, ptr %t870, 2
  %t872 = getelementptr { i64, [3 x i64] }, ptr %t864, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t871, ptr %t872
  %t873 = load { i64, [3 x i64] }, ptr %t864
  %t875 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t873, ptr %t875
  %t876 = load ptr, ptr %l417, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t876, ptr %t875)
  br label %bb129
bb129:
  %t878 = load ptr, ptr %l0, !tbaa !29
  store ptr %t878, ptr %l429, !tbaa !29
  %t879 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t879, ptr %l430
  %t880 = load ptr, ptr %l0, !tbaa !29
  %t881 = load %"compiler/source:Span", ptr %l1
  %t882 = load i64, ptr %l4, !tbaa !24
  %t883 = load ptr, ptr %lp11
  %t888 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v2, ptr %v0, ptr %t880, %"compiler/source:Span" %t881, i64 %t882, ptr %t883)
  store ptr %t888, ptr %l435
  br label %bb130
bb130:
  %t889 = load ptr, ptr %l429, !tbaa !29
  %t890 = load %"compiler/source:Span", ptr %l430
  %t891 = load ptr, ptr %l435, !tbaa !29
  %t892 = call { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %v0, ptr %v0, ptr %t889, %"compiler/source:Span" %t890, ptr %t891, i64 1, ptr null)
  store { i64, i64, i64, i64, i64 } %t892, ptr %l436
  br label %bb131
bb131:
  %t893 = load { i64, i64, i64, i64, i64 }, ptr %l436
  store { i64, i64, i64, i64, i64 } %t893, ptr %l37
  %t894 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l37, i32 0, i32 0
  %t895 = load i64, ptr %t894, !tbaa !24
  store i64 %t895, ptr %l38, !tbaa !24
  %t897 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l37, i32 0, i32 1
  %t898 = load i64, ptr %t897, !tbaa !24
  store i64 %t898, ptr %l39, !tbaa !24
  %t900 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l37, i32 0, i32 2
  %t901 = load i64, ptr %t900, !tbaa !24
  store i64 %t901, ptr %l40, !tbaa !24
  %t903 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l37, i32 0, i32 3
  %t904 = load i64, ptr %t903, !tbaa !24
  store i64 %t904, ptr %l41, !tbaa !24
  %t906 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l37, i32 0, i32 4
  %t907 = load i64, ptr %t906, !tbaa !24
  store i64 %t907, ptr %l42, !tbaa !24
  %t909 = load ptr, ptr %l0, !tbaa !29
  %t910 = load %"compiler/source:Span", ptr %l1
  %t911 = load i32, ptr %l8, !tbaa !23
  %t915 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t909, %"compiler/source:Span" %t910, i32 %t911)
  store i64 %t915, ptr %l445
  br label %bb132
bb132:
  %t916 = load i64, ptr %l445, !tbaa !24
  store i64 %t916, ptr %l43, !tbaa !24
  %t917 = load ptr, ptr %l0, !tbaa !29
  store ptr %t917, ptr %l446, !tbaa !29
  %t918 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t918, ptr %l447
  %t919 = load i64, ptr %l43, !tbaa !24
  %t921 = trunc i64 %t919 to i32
  store i32 %t921, ptr %l450, !tbaa !23
  %t923 = load ptr, ptr %l0, !tbaa !29
  store ptr %t923, ptr %l451, !tbaa !29
  %t924 = load ptr, ptr %l0, !tbaa !29
  store ptr %t924, ptr %l452, !tbaa !29
  %t925 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t925, ptr %l453
  %t926 = load i64, ptr %l4, !tbaa !24
  store i64 %t926, ptr %l454, !tbaa !24
  %t927 = load ptr, ptr %lp11
  store ptr %t927, ptr %l455, !tbaa !29
  %t928 = load ptr, ptr %l0, !tbaa !29
  %t929 = load %"compiler/source:Span", ptr %l1
  %t930 = load i64, ptr %l38, !tbaa !24
  %t934 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t928, %"compiler/source:Span" %t929, i64 %t930)
  store ptr %t934, ptr %l459
  br label %bb133
bb133:
  %t935 = load ptr, ptr %l452, !tbaa !29
  %t936 = load %"compiler/source:Span", ptr %l453
  %t937 = load i64, ptr %l454, !tbaa !24
  %t938 = load ptr, ptr %l455, !tbaa !29
  %t939 = load ptr, ptr %l459, !tbaa !29
  %t940 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %t935, %"compiler/source:Span" %t936, i64 %t937, ptr %t938, ptr %t939)
  store ptr %t940, ptr %l460
  br label %bb134
bb134:
  %t941 = load i32, ptr %l8, !tbaa !23
  %t942 = load %"compiler/source:Span", ptr %l1
  %t943 = load ptr, ptr %l451, !tbaa !29
  %t944 = load ptr, ptr %l460, !tbaa !29
  %t947 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t943, ptr %t944, i32 %t941, %"compiler/source:Span" %t942)
  store ptr %t947, ptr %l463
  br label %bb135
bb135:
  store { i64, [3 x i64] } zeroinitializer, ptr %t948
  %t949 = getelementptr { i64, [3 x i64] }, ptr %t948, i32 0, i32 0
  store i64 0, ptr %t949
  %t950 = load %"compiler/source:Span", ptr %l447
  %t951 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t950, 0
  %t952 = load i32, ptr %l450, !tbaa !23
  %t953 = insertvalue { %"compiler/source:Span", i32, ptr } %t951, i32 %t952, 1
  %t954 = load ptr, ptr %l463, !tbaa !29
  %t955 = insertvalue { %"compiler/source:Span", i32, ptr } %t953, ptr %t954, 2
  %t956 = getelementptr { i64, [3 x i64] }, ptr %t948, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t955, ptr %t956
  %t957 = load { i64, [3 x i64] }, ptr %t948
  %t959 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t957, ptr %t959
  %t960 = load ptr, ptr %l446, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t960, ptr %t959)
  br label %bb136
bb136:
  %t962 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t964 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t962, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t964, ptr %l467
  br label %bb137
bb137:
  %t965 = load i1, ptr %l467, !tbaa !21
  br i1 %t965, label %bb138, label %bb139
bb138:
  %t966 = load ptr, ptr %l0, !tbaa !29
  store ptr %t966, ptr %l469, !tbaa !29
  %t967 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t967, ptr %l470
  %t968 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t968, ptr %l471
  store i32 96, ptr %l472
  %t969 = load ptr, ptr %l0, !tbaa !29
  %t970 = load %"compiler/source:Span", ptr %l1
  %t971 = load i64, ptr %l43, !tbaa !24
  %t975 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t969, %"compiler/source:Span" %t970, i64 %t971)
  store ptr %t975, ptr %l476
  br label %bb140
bb139:
  %t976 = load ptr, ptr %l0, !tbaa !29
  store ptr %t976, ptr %l484, !tbaa !29
  %t977 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t977, ptr %l485
  %t978 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t978, ptr %l486
  store i32 96, ptr %l487
  %t979 = load ptr, ptr %l0, !tbaa !29
  %t980 = load %"compiler/source:Span", ptr %l1
  %t981 = load i64, ptr %l36, !tbaa !24
  %t985 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t979, %"compiler/source:Span" %t980, i64 %t981)
  store ptr %t985, ptr %l491
  br label %bb143
bb140:
  %t986 = load ptr, ptr %l0, !tbaa !29
  %t987 = load %"compiler/source:Span", ptr %l1
  %t988 = load i64, ptr %l36, !tbaa !24
  %t992 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t986, %"compiler/source:Span" %t987, i64 %t988)
  store ptr %t992, ptr %l480
  br label %bb141
bb141:
  %t993 = load %"compiler/source:Span", ptr %l1
  %t994 = load %"compiler/source:Span", ptr %l1
  %t995 = load ptr, ptr %l469, !tbaa !29
  %t996 = load %"compiler/source:Span", ptr %l470
  %t997 = load %"compiler/source:Span", ptr %l471
  %t998 = load i32, ptr %l472, !range !{i32 0, i32 113}
  %t999 = load ptr, ptr %l476, !tbaa !29
  %t1000 = load ptr, ptr %l480, !tbaa !29
  %t1003 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %t995, %"compiler/source:Span" %t996, %"compiler/source:Span" %t997, i32 %t998, ptr %t999, ptr %t1000, %"compiler/source:Span" %t993, %"compiler/source:Span" %t994)
  store ptr %t1003, ptr %l483
  br label %bb142
bb142:
  %t1004 = load ptr, ptr %l483, !tbaa !29
  store ptr %t1004, ptr %l468, !tbaa !29
  br label %bb146
bb143:
  %t1005 = load ptr, ptr %l0, !tbaa !29
  %t1006 = load %"compiler/source:Span", ptr %l1
  %t1007 = load i64, ptr %l43, !tbaa !24
  %t1011 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1005, %"compiler/source:Span" %t1006, i64 %t1007)
  store ptr %t1011, ptr %l495
  br label %bb144
bb144:
  %t1012 = load %"compiler/source:Span", ptr %l1
  %t1013 = load %"compiler/source:Span", ptr %l1
  %t1014 = load ptr, ptr %l484, !tbaa !29
  %t1015 = load %"compiler/source:Span", ptr %l485
  %t1016 = load %"compiler/source:Span", ptr %l486
  %t1017 = load i32, ptr %l487, !range !{i32 0, i32 113}
  %t1018 = load ptr, ptr %l491, !tbaa !29
  %t1019 = load ptr, ptr %l495, !tbaa !29
  %t1022 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %t1014, %"compiler/source:Span" %t1015, %"compiler/source:Span" %t1016, i32 %t1017, ptr %t1018, ptr %t1019, %"compiler/source:Span" %t1012, %"compiler/source:Span" %t1013)
  store ptr %t1022, ptr %l498
  br label %bb145
bb145:
  %t1023 = load ptr, ptr %l498, !tbaa !29
  store ptr %t1023, ptr %l468, !tbaa !29
  br label %bb146
bb146:
  %t1024 = load ptr, ptr %l468, !tbaa !29
  store ptr %t1024, ptr %l44, !tbaa !29
  %t1025 = load ptr, ptr %l0, !tbaa !29
  %t1027 = getelementptr %"compiler/check:Checker", ptr %t1025, i32 0, i32 1
  %t1028 = load ptr, ptr %t1027, !tbaa !29
  %t1030 = getelementptr %"compiler/generic:Program", ptr %t1028, i32 0, i32 2
  store ptr %t1030, ptr %l501, !tbaa !29
  %t1031 = load ptr, ptr %l0, !tbaa !29
  %t1032 = load i32, ptr %l8, !tbaa !23
  %t1035 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1031, i32 %t1032)
  store i32 %t1035, ptr %l504
  br label %bb147
bb147:
  %t1036 = load ptr, ptr %l501, !tbaa !29
  %t1037 = load i32, ptr %l504, !tbaa !23
  %t1038 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t1036, i32 %t1037)
  store i1 %t1038, ptr %l505
  br label %bb148
bb148:
  %t1039 = load i1, ptr %l505, !tbaa !21
  br i1 %t1039, label %bb149, label %bb150
bb149:
  %t1040 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1040, ptr %l506, !tbaa !29
  %t1041 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1041, ptr %l507
  %t1042 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1042, ptr %l508, !tbaa !23
  store i32 14, ptr %l509
  %t1043 = load ptr, ptr %l0, !tbaa !29
  %t1044 = load %"compiler/source:Span", ptr %l1
  %t1045 = load i64, ptr %l43, !tbaa !24
  %t1049 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1043, %"compiler/source:Span" %t1044, i64 %t1045)
  store ptr %t1049, ptr %l513
  br label %bb151
bb150:
  br label %bb156
bb151:
  %t1050 = load ptr, ptr %l0, !tbaa !29
  %t1051 = load %"compiler/source:Span", ptr %l1
  %t1052 = load i64, ptr %l43, !tbaa !24
  %t1056 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1050, %"compiler/source:Span" %t1051, i64 %t1052)
  store ptr %t1056, ptr %l517
  br label %bb152
bb152:
  %t1057 = load ptr, ptr %l517, !tbaa !29
  %t1058 = load ptr, ptr %l506, !tbaa !29
  %t1059 = load %"compiler/source:Span", ptr %l507
  %t1060 = load i32, ptr %l508, !tbaa !23
  %t1061 = load i32, ptr %l509, !range !{i32 0, i32 52}
  %t1062 = load ptr, ptr %l513, !tbaa !29
  %t1064 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %t1058, %"compiler/source:Span" %t1059, i32 %t1060, i32 %t1061, ptr %t1062, ptr %t1057)
  store ptr %t1064, ptr %l519
  br label %bb153
bb153:
  %t1065 = load ptr, ptr %l519, !tbaa !29
  store ptr %t1065, ptr %l45, !tbaa !29
  %t1066 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1066, ptr %l520
  %t1067 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1067, ptr %l521, !tbaa !23
  %t1068 = load ptr, ptr %l44, !tbaa !29
  store ptr %t1068, ptr %l522, !tbaa !29
  %t1069 = load ptr, ptr %l0, !tbaa !29
  %t1070 = load %"compiler/source:Span", ptr %l1
  %t1071 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1075 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t1069, %"compiler/source:Span" %t1070, i32 %t1071, i64 1)
  store ptr %t1075, ptr %l526
  br label %bb154
bb154:
  %t1076 = load ptr, ptr %l526, !tbaa !29
  %t1077 = load ptr, ptr %l45, !tbaa !29
  %t1078 = load ptr, ptr %l522, !tbaa !29
  %t1081 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t1078, ptr %t1076, ptr %t1077)
  store %"compiler/typed:Cond" %t1081, ptr %l529
  br label %bb155
bb155:
  %t1082 = load %"compiler/typed:Cond", ptr %l529
  %t1083 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Cond" %t1082, ptr %t1083
  store { i64, [5 x i64] } zeroinitializer, ptr %t1084
  %t1085 = getelementptr { i64, [5 x i64] }, ptr %t1084, i32 0, i32 0
  store i64 11, ptr %t1085
  %t1086 = load %"compiler/source:Span", ptr %l520
  %t1087 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1086, 0
  %t1088 = load i32, ptr %l521, !tbaa !23
  %t1089 = insertvalue { %"compiler/source:Span", i32, ptr } %t1087, i32 %t1088, 1
  %t1091 = insertvalue { %"compiler/source:Span", i32, ptr } %t1089, ptr %t1083, 2
  %t1092 = getelementptr { i64, [5 x i64] }, ptr %t1084, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1091, ptr %t1092
  %t1093 = load { i64, [5 x i64] }, ptr %t1084
  %t1095 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t1093, ptr %t1095
  store ptr %t1095, ptr %l44, !tbaa !29
  br label %bb156
bb156:
  %t1097 = load ptr, ptr %l0, !tbaa !29
  %t1099 = getelementptr %"compiler/check:Checker", ptr %t1097, i32 0, i32 45
  %t1101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1099)
  store i64 %t1101, ptr %l535
  br label %bb157
bb157:
  %t1102 = load i64, ptr %l535, !tbaa !24
  store i64 %t1102, ptr %l46, !tbaa !24
  %t1103 = load ptr, ptr %l0, !tbaa !29
  %t1105 = getelementptr %"compiler/check:Checker", ptr %t1103, i32 0, i32 45
  store ptr %t1105, ptr %l537, !tbaa !29
  %t1106 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1106, ptr %l538
  %t1107 = load %"compiler/source:Span", ptr %l1
  %t1108 = load i32, ptr %l8, !tbaa !23
  %t1109 = load i64, ptr %l36, !tbaa !24
  %t1111 = trunc i64 %t1109 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t1113
  %t1114 = getelementptr { i64, [4 x i64] }, ptr %t1113, i32 0, i32 0
  store i64 0, ptr %t1114
  %t1116 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t1107, 0
  %t1118 = insertvalue { %"compiler/source:Span", i32, i32 } %t1116, i32 %t1108, 1
  %t1120 = insertvalue { %"compiler/source:Span", i32, i32 } %t1118, i32 %t1111, 2
  %t1121 = getelementptr { i64, [4 x i64] }, ptr %t1113, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t1120, ptr %t1121
  %t1122 = load { i64, [4 x i64] }, ptr %t1113
  %t1124 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1122, ptr %t1124
  store ptr %t1124, ptr %l545, !tbaa !29
  %t1125 = load ptr, ptr %l0, !tbaa !29
  %t1126 = load %"compiler/source:Span", ptr %l1
  %t1127 = load i64, ptr %l43, !tbaa !24
  %t1131 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1125, %"compiler/source:Span" %t1126, i64 %t1127)
  store ptr %t1131, ptr %l549
  br label %bb158
bb158:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1132
  %t1133 = getelementptr { i64, [3 x i64] }, ptr %t1132, i32 0, i32 0
  store i64 1, ptr %t1133
  %t1134 = load %"compiler/source:Span", ptr %l538
  %t1135 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t1134, 0
  %t1136 = load ptr, ptr %l545, !tbaa !29
  %t1137 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1135, ptr %t1136, 1
  %t1138 = load ptr, ptr %l549, !tbaa !29
  %t1139 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1137, ptr %t1138, 2
  %t1140 = getelementptr { i64, [3 x i64] }, ptr %t1132, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t1139, ptr %t1140
  %t1141 = load { i64, [3 x i64] }, ptr %t1132
  %t1143 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1141, ptr %t1143
  %t1144 = load ptr, ptr %l537, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1144, ptr %t1143)
  br label %bb159
bb159:
  %t1146 = load ptr, ptr %l0, !tbaa !29
  %t1148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1146)
  store ptr %t1148, ptr %l553
  br label %bb160
bb160:
  %t1149 = load ptr, ptr %l553, !tbaa !29
  %t1151 = getelementptr %"compiler/check:frame", ptr %t1149, i32 0, i32 7
  %t1152 = load i64, ptr %t1151, !tbaa !24
  %t1154 = trunc i64 %t1152 to i32
  store i32 %t1154, ptr %l557, !tbaa !23
  %t1156 = load ptr, ptr %l0, !tbaa !29
  %t1158 = getelementptr %"compiler/check:Checker", ptr %t1156, i32 0, i32 45
  %t1159 = load i64, ptr %l46, !tbaa !24
  %t1162 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1158, i64 %t1159)
  store { i64, ptr } %t1162, ptr %l561
  br label %bb161
bb161:
  %t1163 = load i32, ptr %l557, !tbaa !23
  %t1164 = load { i64, ptr }, ptr %l561, !tbaa !27
  %t1165 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 %t1163, { i64, ptr } %t1164)
  store %"compiler/typed:Block" %t1165, ptr %l562
  br label %bb162
bb162:
  %t1166 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store ptr %t1166, ptr %lp47
  %t1167 = load %"compiler/typed:Block", ptr %l562
  %t1168 = load ptr, ptr %lp47
  store %"compiler/typed:Block" %t1167, ptr %t1168
  %t1169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1169, ptr %l563, !tbaa !29
  %t1170 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1170, ptr %l564
  %t1171 = load ptr, ptr %l44, !tbaa !29
  %t1172 = load ptr, ptr %lp47
  %t1175 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v2, ptr %v2, ptr %v0, ptr %v0, ptr %t1171, ptr %t1172, ptr null)
  store %"compiler/typed:If" %t1175, ptr %l567
  br label %bb163
bb163:
  %t1176 = load %"compiler/typed:If", ptr %l567
  %t1177 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t1176, ptr %t1177
  store { i64, [3 x i64] } zeroinitializer, ptr %t1178
  %t1179 = getelementptr { i64, [3 x i64] }, ptr %t1178, i32 0, i32 0
  store i64 3, ptr %t1179
  %t1180 = load %"compiler/source:Span", ptr %l564
  %t1181 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1180, 0
  %t1183 = insertvalue { %"compiler/source:Span", ptr } %t1181, ptr %t1177, 1
  %t1184 = getelementptr { i64, [3 x i64] }, ptr %t1178, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1183, ptr %t1184
  %t1185 = load { i64, [3 x i64] }, ptr %t1178
  %t1187 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1185, ptr %t1187
  %t1188 = load ptr, ptr %l563, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1188, ptr %t1187)
  br label %bb164
bb164:
  %t1190 = load ptr, ptr %l0, !tbaa !29
  %t1191 = load %"compiler/source:Span", ptr %l1
  %t1192 = load i64, ptr %l38, !tbaa !24
  %t1193 = load i64, ptr %l39, !tbaa !24
  %t1194 = load i64, ptr %l40, !tbaa !24
  %t1195 = load i64, ptr %l41, !tbaa !24
  %t1196 = load i64, ptr %l42, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %t1190, %"compiler/source:Span" %t1191, i64 %t1192, i64 %t1193, i64 %t1194, i64 %t1195, i64 %t1196, i64 1)
  br label %bb165
bb165:
  %t1204 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1204, ptr %l578
  %t1205 = load i32, ptr %l8, !tbaa !23
  store i32 %t1205, ptr %l579, !tbaa !23
  %t1206 = load ptr, ptr %l0, !tbaa !29
  %t1208 = getelementptr %"compiler/check:Checker", ptr %t1206, i32 0, i32 45
  %t1209 = load i64, ptr %l10, !tbaa !24
  %t1212 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1208, i64 %t1209)
  store { i64, ptr } %t1212, ptr %l583
  br label %bb166
bb166:
  %t1213 = load ptr, ptr %l0, !tbaa !29
  %t1214 = load %"compiler/source:Span", ptr %l1
  %t1215 = load i64, ptr %l36, !tbaa !24
  %t1219 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t1213, %"compiler/source:Span" %t1214, i64 %t1215)
  store ptr %t1219, ptr %l587
  br label %bb167
bb167:
  %t1220 = load ptr, ptr %l587, !tbaa !29
  %t1221 = load { i64, ptr }, ptr %l583, !tbaa !27
  %t1223 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t1221, ptr %t1220, i1 false)
  store %"compiler/typed:Seq" %t1223, ptr %l589
  br label %bb168
bb168:
  %t1224 = load %"compiler/typed:Seq", ptr %l589
  %t1225 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t1224, ptr %t1225
  store { i64, [5 x i64] } zeroinitializer, ptr %t1226
  %t1227 = getelementptr { i64, [5 x i64] }, ptr %t1226, i32 0, i32 0
  store i64 12, ptr %t1227
  %t1228 = load %"compiler/source:Span", ptr %l578
  %t1229 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1228, 0
  %t1230 = load i32, ptr %l579, !tbaa !23
  %t1231 = insertvalue { %"compiler/source:Span", i32, ptr } %t1229, i32 %t1230, 1
  %t1233 = insertvalue { %"compiler/source:Span", i32, ptr } %t1231, ptr %t1225, 2
  %t1234 = getelementptr { i64, [5 x i64] }, ptr %t1226, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1233, ptr %t1234
  %t1235 = load { i64, [5 x i64] }, ptr %t1226
  %t1237 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t1235, ptr %t1237
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1237, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l3 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i32
  %l32 = alloca double
  %l33 = alloca i1
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 1
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l19
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 4
  %t37 = load double, ptr %t36, !tbaa !26
  %t40 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t35, double %t37)
  store i1 %t40, ptr %l23
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t41 = load i1, ptr %l23, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l20, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l29
  br label %bb14
bb14:
  %t55 = load i1, ptr %l29, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = load i32, ptr %l3, !tbaa !23
  store i32 %t56, ptr %l30, !tbaa !23
  %t57 = load %"compiler/check:litv", ptr %l1
  %t59 = call double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %t57)
  store double %t59, ptr %l32
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t60 = load i32, ptr %l30, !tbaa !23
  %t61 = load double, ptr %l32, !tbaa !26
  %t62 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t60, double %t61)
  store i1 %t62, ptr %l33
  br label %bb18
bb18:
  %t63 = load i1, ptr %l33, !tbaa !21
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %rv
  br label %ret
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load %"compiler/check:litv", ptr %l1
  %t73 = load i32, ptr %l3, !tbaa !23
  %t77 = call i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %t71, %"compiler/check:litv" %t72, i32 %t73)
  store i1 %t77, ptr %l40
  br label %bb20
bb20:
  %t78 = load i1, ptr %l40, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/generic:AnySlot"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca i64
  %l33 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca i32
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i64
  %l82 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l92 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l114 = alloca i32
  %l117 = alloca ptr
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l126 = alloca i64
  %l130 = alloca i64
  %l133 = alloca i64
  %l153 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca i32
  %l161 = alloca ptr
  %l165 = alloca i32
  %l172 = alloca i64
  %l174 = alloca i64
  %l179 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t95 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l26, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t8, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d34, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i32 %t10, ptr %l29
  br label %bb2
bb2:
  %t11 = load i32, ptr %l29, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 28
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l32
  br label %bb3
bb3:
  %t17 = load i64, ptr %l32, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t18 = load ptr, ptr %l5, !tbaa !29
  store ptr %t18, ptr %l33, !tbaa !29
  %t19 = load ptr, ptr %l33, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 15
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = add i64 %t21, 1
  %t25 = load ptr, ptr %l33, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 15
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 53
  store i32 0, ptr %t29, !tbaa !23
  store ptr null, ptr %l8, !tbaa !29
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = icmp slt i64 %t30, -1
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l41, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t40)
  store i32 %t43, ptr %l44
  br label %bb6
bb5:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l77, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t45, ptr %l78
  %t46 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t46, ptr %l79
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l80, !tbaa !24
  %t48 = load ptr, ptr %l3, !tbaa !29
  store ptr %t48, ptr %l82, !tbaa !29
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb15, label %bb16
bb6:
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t53 = load i32, ptr %l44, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l45
  br label %bb7
bb7:
  %t55 = load i32, ptr %l45, !tbaa !23
  store i32 %t55, ptr %l9, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t60 = load i32, ptr %l9, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l49
  br label %bb8
bb8:
  %t64 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t64, ptr %l50, !tbaa !27
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = sub i64 -2, %t65
  %t69 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr %"compiler/generic:AnySlot", ptr %t70, i64 %t67
  %t72 = load %"compiler/generic:AnySlot", ptr %t71
  store %"compiler/generic:AnySlot" %t72, ptr %l10
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l9, !tbaa !23
  %t76 = load i64, ptr %l2, !tbaa !24
  %t78 = sub i64 -2, %t76
  %t79 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %t74, i32 %t75, i64 %t78, %"compiler/source:Span" %t79)
  br label %bb9
bb9:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l59, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t85, ptr %l60
  %t86 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t86, ptr %l61
  %t87 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t88 = load i32, ptr %t87, !tbaa !23
  store i32 %t88, ptr %l62, !tbaa !23
  %t89 = load i32, ptr %l9, !tbaa !23
  %t90 = load i64, ptr %l2, !tbaa !24
  %t92 = sub i64 -2, %t90
  %t93 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t94 = load i32, ptr %t93, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 0
  store i64 3, ptr %t96
  %t98 = insertvalue { i32, i64, i32 } undef, i32 %t89, 0
  %t100 = insertvalue { i32, i64, i32 } %t98, i64 %t92, 1
  %t102 = insertvalue { i32, i64, i32 } %t100, i32 %t94, 2
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  store { i32, i64, i32 } %t102, ptr %t103
  %t104 = load { i64, [3 x i64] }, ptr %t95
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store { i64, [3 x i64] } %t104, ptr %t106
  store ptr %t106, ptr %l68, !tbaa !29
  %t107 = load ptr, ptr %l3, !tbaa !29
  store ptr %t107, ptr %l70, !tbaa !29
  %t109 = icmp sge i64 0, 0
  br i1 %t109, label %bb10, label %bb11
bb10:
  %t111 = icmp sle i64 0, 1152921504606846975
  br i1 %t111, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb12:
  %t113 = mul i64 0, 8
  %t114 = insertvalue { i64, ptr } undef, i64 0, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t116 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l60
  %t119 = load %"compiler/source:Span", ptr %l61
  %t120 = load i32, ptr %l62, !tbaa !23
  %t121 = load ptr, ptr %l68, !tbaa !29
  %t122 = load ptr, ptr %l70, !tbaa !29
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v3, ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %t117, %"compiler/source:Span" %t118, %"compiler/source:Span" %t119, i32 %t120, ptr %t121, i64 -1, ptr %t122, { i64, ptr } %t115, { i64, ptr } %t116)
  store ptr %t125, ptr %l75
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb14:
  %t126 = load ptr, ptr %l75, !tbaa !29
  store ptr %t126, ptr %l8, !tbaa !29
  br label %bb24
bb15:
  %t128 = icmp sle i64 0, 1152921504606846975
  br i1 %t128, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb17:
  %t130 = mul i64 0, 8
  %t131 = insertvalue { i64, ptr } undef, i64 0, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t132, ptr %l85, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t133, ptr %l86, !tbaa !27
  %t134 = icmp sge i64 0, 0
  br i1 %t134, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb19:
  %t136 = icmp sle i64 0, 2305843009213693951
  br i1 %t136, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb21:
  %t138 = mul i64 0, 4
  %t139 = insertvalue { i64, ptr } undef, i64 0, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t141 = load ptr, ptr %l77, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l78
  %t143 = load %"compiler/source:Span", ptr %l79
  %t144 = load i64, ptr %l80, !tbaa !24
  %t145 = load ptr, ptr %l82, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %v3, ptr %t141, %"compiler/source:Span" %t142, %"compiler/source:Span" %t143, i64 %t144, ptr %t145, { i64, ptr } %t146, { i64, ptr } %t147, { i64, ptr } %t140)
  store ptr %t149, ptr %l90
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb23:
  %t150 = load ptr, ptr %l90, !tbaa !29
  store ptr %t150, ptr %l8, !tbaa !29
  br label %bb24
bb24:
  %t152 = load ptr, ptr %l5, !tbaa !29
  store ptr %t152, ptr %l92, !tbaa !29
  %t153 = load ptr, ptr %l92, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t153, i32 0, i32 15
  %t155 = load i64, ptr %t154, !tbaa !24
  %t157 = sub i64 %t155, 1
  %t159 = load ptr, ptr %l92, !tbaa !29
  %t160 = getelementptr %"compiler/check:frame", ptr %t159, i32 0, i32 15
  store i64 %t157, ptr %t160, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/generic:Program", ptr %t164, i32 0, i32 2
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 53
  %t170 = load i32, ptr %t169, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t166, i32 %t170)
  store { i64, ptr } %t173, ptr %l100
  br label %bb25
bb25:
  %t174 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t174, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = load i64, ptr %l13, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t187 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t187, ptr %l107, !tbaa !27
  %t188 = load i64, ptr %l12, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i32, ptr %t191, i64 %t188
  %t193 = load i32, ptr %t192, !tbaa !33
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t200, i32 %t193)
  store i32 %t204, ptr %l114
  br label %bb30
bb30:
  %t205 = load i32, ptr %l6, !tbaa !23
  %t206 = load i32, ptr %l114, !tbaa !23
  %t208 = icmp ne i32 %t206, %t205
  br i1 %t208, label %bb31, label %bb32
bb31:
  %t210 = load ptr, ptr %l5, !tbaa !29
  store ptr %t210, ptr %l117, !tbaa !29
  %t211 = load ptr, ptr %l117, !tbaa !29
  %t212 = getelementptr %"compiler/check:frame", ptr %t211, i32 0, i32 17
  %t213 = load i64, ptr %t212, !tbaa !24
  %t215 = add i64 %t213, 1
  %t217 = load ptr, ptr %l117, !tbaa !29
  %t218 = getelementptr %"compiler/check:frame", ptr %t217, i32 0, i32 17
  store i64 %t215, ptr %t218, !tbaa !24
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t219 = load i64, ptr %l12, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l12, !tbaa !24
  br label %bb26
bb35:
  %t223 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t223, ptr %l122
  br label %bb36
bb36:
  %t224 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t224, ptr %l15
  %t225 = load i64, ptr %l7, !tbaa !24
  store i64 %t225, ptr %l16, !tbaa !24
  %t227 = load ptr, ptr %l5, !tbaa !29
  %t229 = getelementptr %"compiler/check:frame", ptr %t227, i32 0, i32 28
  %t231 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t229)
  store i64 %t231, ptr %l126
  br label %bb37
bb37:
  %t232 = load i64, ptr %l126, !tbaa !24
  store i64 %t232, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t233 = load i64, ptr %l17, !tbaa !24
  %t234 = load i64, ptr %l16, !tbaa !24
  %t237 = icmp sgt i64 %t233, %t234
  br i1 %t237, label %bb38, label %bb39
bb38:
  %t239 = load i64, ptr %l18, !tbaa !24
  %t241 = icmp sgt i64 %t239, 0
  br i1 %t241, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb43
bb40:
  %t243 = load i64, ptr %l17, !tbaa !24
  %t244 = load i64, ptr %l16, !tbaa !24
  %t247 = sub i64 %t243, %t244
  %t248 = load i64, ptr %l18, !tbaa !24
  %t251 = add i64 %t247, %t248
  %t253 = sub i64 %t251, 1
  %t254 = load i64, ptr %l18, !tbaa !24
  %t257 = sdiv i64 %t253, %t254
  store i64 %t257, ptr %l133, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb42
bb42:
  %t259 = load i64, ptr %l133, !tbaa !24
  store i64 %t259, ptr %l130, !tbaa !24
  br label %bb43
bb43:
  %t260 = load i64, ptr %l130, !tbaa !24
  store i64 %t260, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb44
bb44:
  %t261 = load i64, ptr %l20, !tbaa !24
  %t262 = load i64, ptr %l19, !tbaa !24
  %t265 = icmp slt i64 %t261, %t262
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb45, label %bb46
bb45:
  br label %bb56
bb46:
  br label %bb47
bb47:
  %t269 = load i64, ptr %l16, !tbaa !24
  %t270 = load i64, ptr %l20, !tbaa !24
  %t271 = load i64, ptr %l18, !tbaa !24
  %t274 = mul i64 %t270, %t271
  %t277 = add i64 %t269, %t274
  store i64 %t277, ptr %l21, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 2
  store ptr %t284, ptr %l153, !tbaa !29
  %t285 = load ptr, ptr %l5, !tbaa !29
  %t287 = getelementptr %"compiler/check:frame", ptr %t285, i32 0, i32 28
  %t288 = load i64, ptr %l21, !tbaa !24
  %t291 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t287, i64 %t288)
  store i32 %t291, ptr %l157
  br label %bb48
bb48:
  %t292 = load ptr, ptr %l153, !tbaa !29
  %t293 = load i32, ptr %l157, !tbaa !23
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t292, i32 %t293)
  store i32 %t294, ptr %l158
  br label %bb49
bb49:
  %t295 = load i32, ptr %l6, !tbaa !23
  %t296 = load i32, ptr %l158, !tbaa !23
  %t298 = icmp ne i32 %t296, %t295
  br i1 %t298, label %bb50, label %bb51
bb50:
  store ptr %l15, ptr %l161, !tbaa !29
  %t300 = load ptr, ptr %l5, !tbaa !29
  %t302 = getelementptr %"compiler/check:frame", ptr %t300, i32 0, i32 28
  %t303 = load i64, ptr %l21, !tbaa !24
  %t306 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t302, i64 %t303)
  store i32 %t306, ptr %l165
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t307 = load ptr, ptr %l161, !tbaa !29
  %t308 = load i32, ptr %l165, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t307, i32 %t308)
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t309 = load i64, ptr %l20, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l20, !tbaa !24
  br label %bb44
bb56:
  %t313 = load ptr, ptr %l5, !tbaa !29
  %t315 = getelementptr %"compiler/check:frame", ptr %t313, i32 0, i32 28
  %t316 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t315, i64 %t316)
  br label %bb57
bb57:
  store ptr %l15, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb58
bb58:
  %t320 = load i64, ptr %l23, !tbaa !24
  store i64 %t320, ptr %l172, !tbaa !24
  %t321 = load ptr, ptr %l22, !tbaa !29
  %t323 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t321)
  store i64 %t323, ptr %l174
  br label %bb59
bb59:
  %t324 = load i64, ptr %l172, !tbaa !24
  %t325 = load i64, ptr %l174, !tbaa !24
  %t326 = icmp slt i64 %t324, %t325
  %t328 = xor i1 %t326, true
  br i1 %t328, label %bb60, label %bb61
bb60:
  br label %bb66
bb61:
  br label %bb62
bb62:
  %t330 = load ptr, ptr %l22, !tbaa !29
  %t331 = load i64, ptr %l23, !tbaa !24
  %t334 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t330, i64 %t331)
  store i32 %t334, ptr %l179
  br label %bb63
bb63:
  %t335 = load i32, ptr %l179, !tbaa !23
  %t336 = load ptr, ptr %l5, !tbaa !29
  %t338 = getelementptr %"compiler/check:frame", ptr %t336, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t338, i32 %t335)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t342 = load i64, ptr %l23, !tbaa !24
  %t344 = add i64 %t342, 1
  store i64 %t344, ptr %l23, !tbaa !24
  br label %bb58
bb66:
  %t346 = load ptr, ptr %l8, !tbaa !29
  %t348 = icmp eq ptr %t346, null
  br i1 %t348, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3)
  unreachable
bb68:
  br label %bb69
bb69:
  %t350 = load ptr, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t350, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l22 = alloca i64
  %l26 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l47 = alloca ptr
  %l52 = alloca i64
  %l57 = alloca i64
  %l63 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l79 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l89 = alloca ptr
  %s2 = alloca %olang.scope
  %t77 = alloca { i64, [3 x i64] }, align 8
  %t157 = alloca { i64, [3 x i64] }, align 8
  %t183 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrMatch(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store i1 %t12, ptr %l14
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i1, ptr %l14, !tbaa !21
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatch(ptr %v0, ptr %v1, ptr %t15, %"compiler/source:Span" %t16, ptr %t17)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %ret
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Match", ptr %t21, i32 0, i32 2
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i64 %t30, ptr %l22
  br label %bb11
bb10:
  br label %bb23
bb11:
  %t31 = load i64, ptr %l22, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Match", ptr %t36, i32 0, i32 3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l26, !tbaa !27
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l4, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindCase(ptr %v0, ptr %s2, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l30
  br label %bb15
bb15:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l5
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Case", ptr %t51, i32 0, i32 4
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l35, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l36, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t62, ptr %l37
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Case", ptr %t64, i32 0, i32 4
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Case", ptr %t68, i32 0, i32 0
  %t71 = load %"compiler/source:Span", ptr %t70
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v0, ptr %t63, { i64, ptr } %t67, i32 1, %"compiler/source:Span" %t71)
  store ptr %t76, ptr %l44
  br label %bb18
bb17:
  br label %bb21
bb18:
  store { i64, [3 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 0
  store i64 11, ptr %t78
  %t79 = load %"compiler/source:Span", ptr %l37
  %t80 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t79, 0
  %t81 = load ptr, ptr %l44, !tbaa !29
  %t82 = insertvalue { %"compiler/source:Span", ptr } %t80, ptr %t81, 1
  %t83 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t82, ptr %t83
  %t84 = load { i64, [3 x i64] }, ptr %t77
  %t86 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t84, ptr %t86
  %t87 = load ptr, ptr %l36, !tbaa !29
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecided(ptr %v0, ptr %v0, ptr %v0, ptr %t87, ptr %t86)
  store ptr %t89, ptr %l47
  br label %bb19
bb19:
  %t90 = load ptr, ptr %l35, !tbaa !29
  %t91 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t90, ptr %t91)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunbindCase(ptr %v0, ptr %s2, ptr %t92, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb23:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMatch(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i64 %t100, ptr %l52
  br label %bb24
bb24:
  %t101 = load i64, ptr %l52, !tbaa !24
  store i64 %t101, ptr %l6, !tbaa !24
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = icmp eq i64 %t102, -2
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t110 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %t106, ptr %t107)
  store i64 %t110, ptr %l57
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t111 = load i64, ptr %l57, !tbaa !24
  store i64 %t111, ptr %l6, !tbaa !24
  br label %bb28
bb28:
  %t112 = load i64, ptr %l6, !tbaa !24
  %t114 = icmp ne i64 %t112, -2
  br i1 %t114, label %bb29, label %bb30
bb29:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb31, label %bb32
bb30:
  br label %bb40
bb31:
  br label %ret
bb32:
  br label %bb33
bb33:
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/ast:Match", ptr %t120, i32 0, i32 3
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l63, !tbaa !27
  %t124 = load i64, ptr %l6, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr ptr, ptr %t127, i64 %t124
  %t129 = load ptr, ptr %t128, !tbaa !39
  store ptr %t129, ptr %l7, !tbaa !29
  %t131 = load ptr, ptr %l7, !tbaa !29
  %t133 = getelementptr %"compiler/ast:Case", ptr %t131, i32 0, i32 4
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb34, label %bb35
bb34:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l70, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l71, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t142, ptr %l72
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l7, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 4
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t148 = load ptr, ptr %l7, !tbaa !29
  %t150 = getelementptr %"compiler/ast:Case", ptr %t148, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  %t156 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v0, ptr %t143, { i64, ptr } %t147, i32 1, %"compiler/source:Span" %t151)
  store ptr %t156, ptr %l79
  br label %bb36
bb35:
  br label %bb39
bb36:
  store { i64, [3 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [3 x i64] }, ptr %t157, i32 0, i32 0
  store i64 11, ptr %t158
  %t159 = load %"compiler/source:Span", ptr %l72
  %t160 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t159, 0
  %t161 = load ptr, ptr %l79, !tbaa !29
  %t162 = insertvalue { %"compiler/source:Span", ptr } %t160, ptr %t161, 1
  %t163 = getelementptr { i64, [3 x i64] }, ptr %t157, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t162, ptr %t163
  %t164 = load { i64, [3 x i64] }, ptr %t157
  %t166 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t164, ptr %t166
  %t167 = load ptr, ptr %l71, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecided(ptr %v0, ptr %v0, ptr %v0, ptr %t167, ptr %t166)
  store ptr %t169, ptr %l82
  br label %bb37
bb37:
  %t170 = load ptr, ptr %l70, !tbaa !29
  %t171 = load ptr, ptr %l82, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t170, ptr %t171)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %ret
bb40:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l83, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t173, ptr %l84
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l1
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t177 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t174, %"compiler/source:Span" %t175, ptr %t176, i1 false, i32 %t177)
  store ptr %t182, ptr %l89
  br label %bb41
bb41:
  store { i64, [3 x i64] } zeroinitializer, ptr %t183
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t183, i32 0, i32 0
  store i64 2, ptr %t184
  %t185 = load %"compiler/source:Span", ptr %l84
  %t186 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t185, 0
  %t187 = load ptr, ptr %l89, !tbaa !29
  %t188 = insertvalue { %"compiler/source:Span", ptr } %t186, ptr %t187, 1
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t183, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t188, ptr %t189
  %t190 = load { i64, [3 x i64] }, ptr %t183
  %t192 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t190, ptr %t192
  %t193 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t193, ptr %t192)
  br label %bb42
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodFactInst(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/check:ownerAt"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i64
  %l21 = alloca %"compiler/check:ownerAt"
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca %"compiler/check:ownerAt"
  %l36 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l48 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca i64
  %l58 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Func", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodNamed(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l16
  br label %bb4
bb4:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l16, !tbaa !24
  %t24 = icmp ne i64 %t22, %t21
  store i1 %t24, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l13, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t30 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s0, i32 %t28, i1 false)
  store %"compiler/check:ownerAt" %t30, ptr %l21
  br label %bb9
bb9:
  %t31 = load %"compiler/check:ownerAt", ptr %l21
  store %"compiler/check:ownerAt" %t31, ptr %l3
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t33 = load ptr, ptr %l22, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 28}
  %t39 = icmp eq i64 %t37, 12
  store i1 %t39, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t51 = call %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  store %"compiler/check:ownerAt" %t51, ptr %l30
  br label %bb15
bb15:
  %t52 = load %"compiler/check:ownerAt", ptr %l30
  store %"compiler/check:ownerAt" %t52, ptr %l3
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d6369796b76b374e_c5818894b62d1e82)
  unreachable
bb21:
  %t54 = getelementptr %"compiler/check:ownerAt", ptr %l3, i32 0, i32 1
  %t55 = load i1, ptr %t54, !tbaa !21
  br i1 %t55, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  store ptr %t63, ptr %l36, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:ownerAt", ptr %l3, i32 0, i32 0
  %t66 = load i32, ptr %t65, !tbaa !23
  %t69 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t64, i32 %t66)
  store i32 %t69, ptr %l39
  br label %bb25
bb25:
  %t70 = load ptr, ptr %l36, !tbaa !29
  %t71 = load i32, ptr %l39, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l40
  br label %bb26
bb26:
  %t73 = load i32, ptr %l40, !tbaa !23
  store i32 %t73, ptr %l5, !tbaa !23
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l5, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t79, i32 %t80)
  store { i64, ptr } %t83, ptr %l45
  br label %bb27
bb27:
  %t84 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l46, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  store ptr %t89, ptr %l48, !tbaa !29
  %t90 = load i64, ptr %l2, !tbaa !24
  %t92 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t90)
  store i64 %t92, ptr %l50
  br label %bb28
bb28:
  %t93 = load ptr, ptr %l48, !tbaa !29
  %t94 = load i64, ptr %l50, !tbaa !24
  %t95 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t93, i64 %t94)
  store i64 %t95, ptr %l51
  br label %bb29
bb29:
  %t96 = load i64, ptr %l46, !tbaa !24
  %t97 = load i64, ptr %l51, !tbaa !24
  %t98 = icmp ne i64 %t96, %t97
  br i1 %t98, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t105 = load i64, ptr %l2, !tbaa !24
  %t106 = load i32, ptr %l5, !tbaa !23
  %t110 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t104, i64 %t105, i32 %t106)
  store i64 %t110, ptr %l58
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i64, ptr %l58, !tbaa !24
  store i64 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ename(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca ptr
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca %"compiler/names:Ref"
  %l31 = alloca i1
  %l34 = alloca i64
  %l39 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca i1
  %l53 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i32
  %l61 = alloca %"compiler/check:fixedInit"
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l70 = alloca %"compiler/check:fixedInit"
  %l71 = alloca i32
  %l74 = alloca ptr
  %l79 = alloca ptr
  %l84 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i1
  %l94 = alloca i1
  %l96 = alloca i1
  %l100 = alloca i1
  %l103 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca i32
  %l112 = alloca i1
  %l116 = alloca i1
  %l118 = alloca ptr
  %l125 = alloca ptr
  %l132 = alloca ptr
  %l136 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca %"compiler/source:Span"
  %l144 = alloca { i64, ptr }
  %l146 = alloca %"compiler/diagmsg:Msg"
  %l147 = alloca i64
  %l150 = alloca ptr
  %l158 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l166 = alloca ptr
  %l167 = alloca ptr
  %l168 = alloca i32
  %l172 = alloca ptr
  %l179 = alloca i32
  %l183 = alloca ptr
  %l194 = alloca ptr
  %l201 = alloca ptr
  %l205 = alloca i1
  %l208 = alloca { i64, ptr }
  %l209 = alloca i1
  %l213 = alloca ptr
  %l218 = alloca ptr
  %l221 = alloca { i64, ptr }
  %l223 = alloca ptr
  %l225 = alloca ptr
  %l230 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l231 = alloca i1
  %l233 = alloca i1
  %l235 = alloca ptr
  %l237 = alloca ptr
  %l242 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l243 = alloca i1
  %l245 = alloca i1
  %l250 = alloca i1
  %l252 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l260 = alloca ptr
  %l261 = alloca %"compiler/source:Span"
  %l264 = alloca { i64, ptr }
  %l266 = alloca %"compiler/diagmsg:Msg"
  %l267 = alloca i64
  %l272 = alloca i32
  %l275 = alloca ptr
  %l276 = alloca %"compiler/source:Span"
  %l279 = alloca { i64, ptr }
  %l282 = alloca %"compiler/diagmsg:Msg"
  %l283 = alloca i64
  %l284 = alloca ptr
  %l285 = alloca %"compiler/source:Span"
  %l288 = alloca { i64, ptr }
  %l291 = alloca %"compiler/diagmsg:Msg"
  %l292 = alloca i64
  %l294 = alloca ptr
  %l296 = alloca ptr
  %l301 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l304 = alloca ptr
  %l308 = alloca ptr
  %l309 = alloca %"compiler/source:Span"
  %l312 = alloca { i64, ptr }
  %l313 = alloca %"compiler/diagmsg:Msg"
  %l314 = alloca i64
  %l317 = alloca ptr
  %l326 = alloca i32
  %l329 = alloca i1
  %l332 = alloca i1
  %l334 = alloca ptr
  %l335 = alloca %"compiler/source:Span"
  %l338 = alloca { i64, ptr }
  %l339 = alloca %"compiler/diagmsg:Msg"
  %l340 = alloca i64
  %l343 = alloca ptr
  %l347 = alloca ptr
  %l348 = alloca %"compiler/source:Span"
  %l353 = alloca i64
  %l357 = alloca ptr
  %l361 = alloca i32
  %l363 = alloca ptr
  %l367 = alloca i32
  %l368 = alloca i32
  %l373 = alloca ptr
  %l374 = alloca %"compiler/source:Span"
  %l377 = alloca { i64, ptr }
  %l378 = alloca %"compiler/diagmsg:Msg"
  %l379 = alloca i64
  %l382 = alloca ptr
  %l388 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca ptr
  %t319 = alloca i64
  %t372 = alloca { i64, [4 x i64] }, align 8
  %t662 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l18, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t8)
  store ptr %t10, ptr %l20
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l20, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l18, !tbaa !29
  %t20 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t17, i64 %t14, i32 %t16)
  store %"compiler/names:Ref" %t20, ptr %l24
  br label %bb2
bb2:
  %t21 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t21, ptr %l5
  %t22 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t23 = load i32, ptr %t22, !range !{i32 0, i32 9}
  %t25 = trunc i64 1 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %t28, i32 %t29)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t32 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t33 = load i32, ptr %t32, !range !{i32 0, i32 9}
  %t35 = trunc i64 1 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t38, i32 %t39)
  store i64 %t42, ptr %l34
  br label %bb9
bb8:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  %t43 = load i64, ptr %l34, !tbaa !24
  %t44 = icmp slt i64 %t43, 0
  store i1 %t44, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l31, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  %t49 = load i32, ptr %l2, !tbaa !23
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflName(ptr %v0, ptr %v1, ptr %t47, %"compiler/source:Span" %t48, i32 %t49)
  store ptr %t53, ptr %l39
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t54 = load ptr, ptr %l39, !tbaa !29
  store ptr %t54, ptr %l6, !tbaa !29
  %t55 = load ptr, ptr %l6, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb14, label %bb15
bb14:
  %t61 = load ptr, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t61, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t64 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t65 = load i32, ptr %t64, !range !{i32 0, i32 9}
  %t67 = trunc i64 1 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t70)
  store ptr %t72, ptr %l48
  br label %bb20
bb19:
  br label %bb93
bb20:
  %t73 = load ptr, ptr %l48, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 44
  %t76 = load i32, ptr %l2, !tbaa !23
  %t79 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t75, i32 %t76)
  store i1 %t79, ptr %l52
  br label %bb21
bb21:
  %t80 = load i1, ptr %l52, !tbaa !21
  br i1 %t80, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t81)
  store ptr %t83, ptr %l55
  br label %bb24
bb23:
  br label %bb37
bb24:
  %t84 = load ptr, ptr %l55, !tbaa !29
  %t86 = getelementptr %"compiler/check:frame", ptr %t84, i32 0, i32 44
  %t87 = load i32, ptr %l2, !tbaa !23
  %t90 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t86, i32 %t87)
  %t91 = extractvalue { i32, i64 } %t90, 1
  %t92 = extractvalue { i32, i64 } %t90, 0
  store i32 %t92, ptr %l60
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb26, label %ok.94, !prof !99
ok.94:
  store i64 %t91, ptr %l59
  br label %bb25
bb25:
  %t95 = load i64, ptr %l59, !tbaa !24
  store i64 %t95, ptr %l53, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb28
bb28:
  %t96 = load i64, ptr %l53, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 158
  store ptr %t99, ptr %l63, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t100)
  store ptr %t102, ptr %l65
  br label %bb29
bb29:
  %t103 = load ptr, ptr %l65, !tbaa !29
  %t105 = getelementptr %"compiler/check:frame", ptr %t103, i32 0, i32 45
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t106, i64 %t107)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t110, ptr %l69
  br label %bb30
bb30:
  %t111 = load ptr, ptr %l63, !tbaa !29
  %t112 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l69
  %t113 = call { i32, %"compiler/check:fixedInit" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6f2dcaa3b3ff2363ea7964270c7a6b31(ptr %v0, ptr %v1, ptr %t111, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t112)
  %t114 = extractvalue { i32, %"compiler/check:fixedInit" } %t113, 1
  %t115 = extractvalue { i32, %"compiler/check:fixedInit" } %t113, 0
  store i32 %t115, ptr %l71
  %t116 = icmp ne i32 %t115, 0
  br i1 %t116, label %bb32, label %ok.117, !prof !99
ok.117:
  store %"compiler/check:fixedInit" %t114, ptr %l70
  br label %bb31
bb31:
  %t118 = load %"compiler/check:fixedInit", ptr %l70
  store %"compiler/check:fixedInit" %t118, ptr %l61
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l1
  %t123 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t119, %"compiler/source:Span" %t120)
  store ptr %t123, ptr %l74
  br label %bb34
bb34:
  %t124 = load ptr, ptr %l74, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t124, ptr %rv
  br label %ret
bb35:
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t126, ptr %lp8
  %t127 = load %"compiler/check:fixedInit", ptr %l61
  %t128 = load ptr, ptr %lp8
  store %"compiler/check:fixedInit" %t127, ptr %t128
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %lp8
  %t131 = getelementptr %"compiler/check:fixedInit", ptr %t130, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t133 = load ptr, ptr %lp8
  %t134 = getelementptr %"compiler/check:fixedInit", ptr %t133, i32 0, i32 1
  %t135 = load i32, ptr %t134, !tbaa !23
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v1, ptr %t129, ptr %t132, i32 %t135)
  store ptr %t139, ptr %l79
  br label %bb36
bb36:
  %t140 = load ptr, ptr %l79, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t140, ptr %rv
  br label %ret
bb37:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l2, !tbaa !23
  %t144 = load %"compiler/source:Span", ptr %l1
  %t148 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %t142, i32 %t143, %"compiler/source:Span" %t144)
  store i64 %t148, ptr %l84
  br label %bb38
bb38:
  %t149 = load i64, ptr %l84, !tbaa !24
  store i64 %t149, ptr %l9, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l2, !tbaa !23
  %t154 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t150, i32 %t151)
  store i64 %t154, ptr %l87
  br label %bb39
bb39:
  %t155 = load i64, ptr %l87, !tbaa !24
  store i64 %t155, ptr %l10, !tbaa !24
  %t156 = load i64, ptr %l10, !tbaa !24
  %t158 = icmp sge i64 %t156, 0
  br i1 %t158, label %bb40, label %bb41
bb40:
  %t160 = load i64, ptr %l9, !tbaa !24
  %t161 = load i64, ptr %l10, !tbaa !24
  %t164 = icmp ne i64 %t160, %t161
  store i1 %t164, ptr %l90, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb42
bb42:
  %t166 = load i1, ptr %l90, !tbaa !21
  br i1 %t166, label %bb43, label %bb44
bb43:
  br i1 %a4, label %bb45, label %bb46
bb44:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb55
bb45:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb54
bb46:
  %t169 = load i32, ptr %l3, !tbaa !23
  %t170 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t173 = icmp ne i32 %t169, %t170
  br i1 %t173, label %bb47, label %bb48
bb47:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  store ptr %t180, ptr %l103, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l3, !tbaa !23
  %t185 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t181, i32 %t182)
  store i32 %t185, ptr %l106
  br label %bb49
bb48:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb53
bb49:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l107, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i64, ptr %l10, !tbaa !24
  %t191 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t187, i64 %t188)
  store i32 %t191, ptr %l110
  br label %bb50
bb50:
  %t192 = load ptr, ptr %l107, !tbaa !29
  %t193 = load i32, ptr %l110, !tbaa !23
  %t194 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t194, ptr %l111
  br label %bb51
bb51:
  %t195 = load ptr, ptr %l103, !tbaa !29
  %t196 = load i32, ptr %l106, !tbaa !23
  %t197 = load i32, ptr %l111, !tbaa !23
  %t198 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t195, i32 %t196, i32 %t197)
  store i1 %t198, ptr %l112
  br label %bb52
bb52:
  %t199 = load i1, ptr %l112, !tbaa !21
  store i1 %t199, ptr %l100, !tbaa !21
  br label %bb53
bb53:
  %t200 = load i1, ptr %l100, !tbaa !21
  store i1 %t200, ptr %l96, !tbaa !21
  br label %bb54
bb54:
  %t201 = load i1, ptr %l96, !tbaa !21
  store i1 %t201, ptr %l94, !tbaa !21
  br label %bb55
bb55:
  %t202 = load i1, ptr %l94, !tbaa !21
  br i1 %t202, label %bb56, label %bb57
bb56:
  %t203 = load i64, ptr %l10, !tbaa !24
  store i64 %t203, ptr %l9, !tbaa !24
  br label %bb58
bb57:
  br label %bb58
bb58:
  %t205 = load i64, ptr %l9, !tbaa !24
  %t207 = icmp slt i64 %t205, 0
  br i1 %t207, label %bb59, label %bb60
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t209)
  store ptr %t211, ptr %l118
  br label %bb61
bb60:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb62
bb61:
  %t212 = load ptr, ptr %l118, !tbaa !29
  %t214 = getelementptr %"compiler/check:frame", ptr %t212, i32 0, i32 31
  %t215 = load i64, ptr %t214, !tbaa !24
  %t217 = icmp sge i64 %t215, 0
  store i1 %t217, ptr %l116, !tbaa !21
  br label %bb62
bb62:
  %t219 = load i1, ptr %l116, !tbaa !21
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  %t222 = load i32, ptr %l2, !tbaa !23
  %t226 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %v1, ptr %t220, %"compiler/source:Span" %t221, i32 %t222)
  store ptr %t226, ptr %l125
  br label %bb65
bb64:
  br label %bb70
bb65:
  %t227 = load ptr, ptr %l125, !tbaa !29
  store ptr %t227, ptr %l11, !tbaa !29
  %t228 = load ptr, ptr %l11, !tbaa !29
  %t230 = icmp eq ptr %t228, null
  %t232 = xor i1 %t230, true
  br i1 %t232, label %bb66, label %bb67
bb66:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l1
  %t236 = load ptr, ptr %l11, !tbaa !29
  %t240 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v1, ptr %t234, %"compiler/source:Span" %t235, ptr %t236)
  store ptr %t240, ptr %l132
  br label %bb68
bb67:
  br label %bb69
bb68:
  %t241 = load ptr, ptr %l132, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t241, ptr %rv
  br label %ret
bb69:
  br label %bb70
bb70:
  %t243 = load i64, ptr %l9, !tbaa !24
  %t245 = icmp slt i64 %t243, 0
  br i1 %t245, label %bb71, label %bb72
bb71:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t247, i32 0, i32 150
  %t250 = load i64, ptr %t249, !tbaa !24
  %t252 = icmp sgt i64 %t250, 0
  store i1 %t252, ptr %l136, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb73
bb73:
  %t254 = load i1, ptr %l136, !tbaa !21
  br i1 %t254, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s10
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l140, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t256, ptr %l141
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l2, !tbaa !23
  %t261 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s10, ptr %t257, i32 %t258)
  store { i64, ptr } %t261, ptr %l144
  br label %bb76
bb75:
  br label %bb80
bb76:
  %t262 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  %t264 = extractvalue { i64, ptr } %t262, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t270 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eComptimeLocal(ptr %s10, ptr %v0, { i64, ptr } %t268)
  store %"compiler/diagmsg:Msg" %t270, ptr %l146
  br label %bb77
bb77:
  %t271 = load ptr, ptr %l140, !tbaa !29
  %t272 = load %"compiler/source:Span", ptr %l141
  %t273 = load %"compiler/diagmsg:Msg", ptr %l146
  %t274 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t271, %"compiler/source:Span" %t272, %"compiler/diagmsg:Msg" %t273)
  store i64 %t274, ptr %l147
  br label %bb78
bb78:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l1
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t275, %"compiler/source:Span" %t276)
  store ptr %t279, ptr %l150
  br label %bb79
bb79:
  %t280 = load ptr, ptr %l150, !tbaa !29
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t280, ptr %rv
  br label %ret
bb80:
  %t282 = load i64, ptr %l9, !tbaa !24
  %t284 = icmp slt i64 %t282, 0
  br i1 %t284, label %bb81, label %bb82
bb81:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t286, %"compiler/source:Span" %t287, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load %"compiler/source:Span", ptr %l1
  %t294 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t290, %"compiler/source:Span" %t291)
  store ptr %t294, ptr %l158
  br label %bb84
bb84:
  %t295 = load ptr, ptr %l158, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t295, ptr %rv
  br label %ret
bb85:
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l160, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  store ptr %t298, ptr %l161, !tbaa !29
  %t299 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t299, ptr %l162
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load %"compiler/source:Span", ptr %l1
  %t302 = load i64, ptr %l9, !tbaa !24
  %t306 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %v1, ptr %t300, %"compiler/source:Span" %t301, i64 %t302)
  store ptr %t306, ptr %l166
  br label %bb86
bb86:
  %t307 = load ptr, ptr %l161, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l162
  %t309 = load ptr, ptr %l166, !tbaa !29
  %t310 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v1, ptr %t307, %"compiler/source:Span" %t308, ptr %t309)
  store ptr %t310, ptr %l167
  br label %bb87
bb87:
  %t311 = load i32, ptr %l2, !tbaa !23
  store i32 %t311, ptr %l168, !tbaa !23
  %t312 = icmp sge i64 1, 0
  br i1 %t312, label %bb88, label %bb89
bb88:
  %t314 = icmp sle i64 1, 2305843009213693951
  br i1 %t314, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_d573417cd970c31d_c74d35b0202ac379)
  unreachable
bb90:
  %t316 = mul i64 1, 4
  %t317 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t316)
  %t318 = load i32, ptr %l168, !tbaa !23
  store i64 0, ptr %t319
  br label %fill.320
fill.320:
  %t323 = load i64, ptr %t319
  %t324 = icmp slt i64 %t323, 1
  br i1 %t324, label %fillb.321, label %filld.322
fillb.321:
  %t325 = getelementptr i32, ptr %t317, i64 %t323
  store i32 %t318, ptr %t325
  %t326 = add i64 %t323, 1
  store i64 %t326, ptr %t319
  br label %fill.320
filld.322:
  %t327 = insertvalue { i64, ptr } undef, i64 1, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t317, 1
  %t329 = load ptr, ptr %l160, !tbaa !29
  %t330 = load ptr, ptr %l167, !tbaa !29
  %t332 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNarrowed(ptr %v0, ptr %v1, ptr %s4, ptr %v1, ptr %t329, ptr %t330, { i64, ptr } %t328)
  store ptr %t332, ptr %l172
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_d573417cd970c31d_c74d35b0202ac379)
  unreachable
bb92:
  %t333 = load ptr, ptr %l172, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t333, ptr %rv
  br label %ret
bb93:
  %t335 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t336 = load i32, ptr %t335, !range !{i32 0, i32 9}
  %t338 = trunc i64 2 to i32
  %t339 = icmp eq i32 %t336, %t338
  br i1 %t339, label %bb94, label %bb95
bb94:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t343 = load i64, ptr %t342, !tbaa !24
  %t344 = load i32, ptr %l2, !tbaa !23
  %t348 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t341, i64 %t343, i32 %t344)
  store i32 %t348, ptr %l179
  br label %bb96
bb95:
  br label %bb101
bb96:
  %t349 = load i32, ptr %l179, !tbaa !23
  store i32 %t349, ptr %l12, !tbaa !23
  %t350 = load i32, ptr %l12, !tbaa !23
  %t351 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t354 = icmp eq i32 %t350, %t351
  br i1 %t354, label %bb97, label %bb98
bb97:
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l183, !tbaa !29
  %t357 = load ptr, ptr %l183, !tbaa !29
  %t358 = getelementptr %"compiler/check:Checker", ptr %t357, i32 0, i32 153
  %t359 = load i64, ptr %t358, !tbaa !24
  %t361 = add i64 %t359, 1
  %t363 = load ptr, ptr %l183, !tbaa !29
  %t364 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 153
  store i64 %t361, ptr %t364, !tbaa !24
  br label %bb99
bb98:
  br label %bb99
bb99:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l1
  %t367 = load %"compiler/source:Span", ptr %l1
  %t368 = load i32, ptr %l12, !tbaa !23
  %t369 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t370 = load i64, ptr %t369, !tbaa !24
  %t371 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t372
  %t373 = getelementptr { i64, [4 x i64] }, ptr %t372, i32 0, i32 0
  store i64 1, ptr %t373
  %t375 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t367, 0
  %t377 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t375, i32 %t368, 1
  %t379 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t377, i64 %t370, 2
  %t381 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t379, i32 %t371, 3
  %t382 = getelementptr { i64, [4 x i64] }, ptr %t372, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t381, ptr %t382
  %t383 = load { i64, [4 x i64] }, ptr %t372
  %t385 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t383, ptr %t385
  %t389 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v1, ptr %t365, %"compiler/source:Span" %t366, ptr %t385)
  store ptr %t389, ptr %l194
  br label %bb100
bb100:
  %t390 = load ptr, ptr %l194, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t390, ptr %rv
  br label %ret
bb101:
  %t392 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t393 = load i32, ptr %t392, !range !{i32 0, i32 9}
  %t395 = trunc i64 6 to i32
  %t396 = icmp eq i32 %t393, %t395
  br i1 %t396, label %bb102, label %bb103
bb102:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load %"compiler/source:Span", ptr %l1
  %t400 = load i32, ptr %l2, !tbaa !23
  %t404 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %v1, ptr %t398, %"compiler/source:Span" %t399, i32 %t400)
  store ptr %t404, ptr %l201
  br label %bb104
bb103:
  br label %bb105
bb104:
  %t405 = load ptr, ptr %l201, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t405, ptr %rv
  br label %ret
bb105:
  %t407 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t408 = load i32, ptr %t407, !range !{i32 0, i32 9}
  %t410 = trunc i64 0 to i32
  %t411 = icmp eq i32 %t408, %t410
  br i1 %t411, label %bb106, label %bb107
bb106:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load i32, ptr %l2, !tbaa !23
  %t417 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t413, i32 %t414)
  store { i64, ptr } %t417, ptr %l208
  br label %bb108
bb107:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb110
bb108:
  %t418 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t419 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t418, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t419, ptr %l209
  br label %bb109
bb109:
  %t420 = load i1, ptr %l209, !tbaa !21
  store i1 %t420, ptr %l205, !tbaa !21
  br label %bb110
bb110:
  %t421 = load i1, ptr %l205, !tbaa !21
  br i1 %t421, label %bb111, label %bb112
bb111:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load %"compiler/source:Span", ptr %l1
  %t424 = load i32, ptr %l3, !tbaa !23
  %t428 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypedHole(ptr %v0, ptr %v1, ptr %t422, %"compiler/source:Span" %t423, i32 %t424)
  store ptr %t428, ptr %l213
  br label %bb113
bb112:
  br label %bb114
bb113:
  %t429 = load ptr, ptr %l213, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t429, ptr %rv
  br label %ret
bb114:
  %t431 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t432 = load i32, ptr %t431, !range !{i32 0, i32 9}
  %t434 = trunc i64 0 to i32
  %t435 = icmp eq i32 %t432, %t434
  br i1 %t435, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s16
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/check:Checker", ptr %t437, i32 0, i32 155
  store ptr %t439, ptr %l218, !tbaa !29
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load i32, ptr %l2, !tbaa !23
  %t444 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t440, i32 %t441)
  store { i64, ptr } %t444, ptr %l221
  br label %bb117
bb116:
  br label %bb157
bb117:
  %t445 = load ptr, ptr %l218, !tbaa !29
  %t446 = load { i64, ptr }, ptr %l221, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t445, { i64, ptr } %t446)
  br label %bb118
bb118:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 105
  store ptr %t449, ptr %l223, !tbaa !29
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t450)
  store ptr %t452, ptr %l225
  br label %bb119
bb119:
  %t453 = load ptr, ptr %l225, !tbaa !29
  %t455 = getelementptr %"compiler/check:frame", ptr %t453, i32 0, i32 0
  %t456 = load i64, ptr %t455, !tbaa !24
  %t457 = load i32, ptr %l2, !tbaa !23
  %t459 = sext i32 %t457 to i64
  %t462 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s16, i64 %t456, i64 %t459)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t462, ptr %l230
  br label %bb120
bb120:
  %t463 = load ptr, ptr %l223, !tbaa !29
  %t464 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l230
  %t465 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t463, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t464)
  store i1 %t465, ptr %l231
  br label %bb121
bb121:
  %t466 = load i1, ptr %l231, !tbaa !21
  %t467 = xor i1 %t466, true
  br i1 %t467, label %bb122, label %bb123
bb122:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/check:Checker", ptr %t469, i32 0, i32 104
  store ptr %t471, ptr %l235, !tbaa !29
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t472)
  store ptr %t474, ptr %l237
  br label %bb124
bb123:
  store i1 false, ptr %l233, !tbaa !21
  br label %bb127
bb124:
  %t475 = load ptr, ptr %l237, !tbaa !29
  %t477 = getelementptr %"compiler/check:frame", ptr %t475, i32 0, i32 1
  %t478 = load i64, ptr %t477, !tbaa !24
  %t479 = load i32, ptr %l2, !tbaa !23
  %t481 = sext i32 %t479 to i64
  %t484 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s16, i64 %t478, i64 %t481)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t484, ptr %l242
  br label %bb125
bb125:
  %t485 = load ptr, ptr %l235, !tbaa !29
  %t486 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l242
  %t487 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t485, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t486)
  store i1 %t487, ptr %l243
  br label %bb126
bb126:
  %t488 = load i1, ptr %l243, !tbaa !21
  %t489 = xor i1 %t488, true
  store i1 %t489, ptr %l233, !tbaa !21
  br label %bb127
bb127:
  %t491 = load i1, ptr %l233, !tbaa !21
  br i1 %t491, label %bb128, label %bb129
bb128:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = getelementptr %"compiler/check:Checker", ptr %t492, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !29
  %t497 = getelementptr %"compiler/generic:Program", ptr %t495, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !29
  %t499 = load i32, ptr %l2, !tbaa !23
  %t502 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eImportSaid(ptr %v0, ptr %t498, i32 %t499)
  store i1 %t502, ptr %l250
  br label %bb130
bb129:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb131
bb130:
  %t503 = load i1, ptr %l250, !tbaa !21
  %t504 = xor i1 %t503, true
  store i1 %t504, ptr %l245, !tbaa !21
  br label %bb131
bb131:
  %t506 = load i1, ptr %l245, !tbaa !21
  br i1 %t506, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s17
  %t507 = load ptr, ptr %l0, !tbaa !29
  store ptr %t507, ptr %l252, !tbaa !29
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load i32, ptr %l2, !tbaa !23
  %t512 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t508, i32 %t509)
  store { i64, ptr } %t512, ptr %l255
  br label %bb134
bb133:
  br label %bb155
bb134:
  %t513 = load ptr, ptr %l252, !tbaa !29
  %t514 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t515 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v0, ptr %s17, ptr %t513, { i64, ptr } %t514, i1 true)
  store { i64, ptr } %t515, ptr %l256
  br label %bb135
bb135:
  %t516 = load { i64, ptr }, ptr %l256, !tbaa !27
  store { i64, ptr } %t516, ptr %l13, !tbaa !27
  %t517 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t519 = extractvalue { i64, ptr } %t517, 0
  %t521 = icmp eq i64 %t519, 0
  br i1 %t521, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s18
  %t523 = load ptr, ptr %l0, !tbaa !29
  store ptr %t523, ptr %l260, !tbaa !29
  %t524 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t524, ptr %l261
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load i32, ptr %l2, !tbaa !23
  %t529 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t525, i32 %t526)
  store { i64, ptr } %t529, ptr %l264
  br label %bb138
bb137:
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t532 = getelementptr %"compiler/check:Checker", ptr %t530, i32 0, i32 1
  %t533 = load ptr, ptr %t532, !tbaa !29
  %t535 = getelementptr %"compiler/generic:Program", ptr %t533, i32 0, i32 2
  %t536 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t539 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s17, ptr %t535, { i64, ptr } %t536)
  store i32 %t539, ptr %l272
  br label %bb141
bb138:
  %t540 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t540, 0
  %t542 = extractvalue { i64, ptr } %t540, 1
  %t543 = mul i64 %t541, 1
  %t544 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t543)
  call void @llvm.memcpy.p0.p0.i64(ptr %t544, ptr %t542, i64 %t543, i1 false)
  %t545 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t546 = insertvalue { i64, ptr } %t545, ptr %t544, 1
  %t548 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownName(ptr %s18, ptr %v0, { i64, ptr } %t546)
  store %"compiler/diagmsg:Msg" %t548, ptr %l266
  br label %bb139
bb139:
  %t549 = load ptr, ptr %l260, !tbaa !29
  %t550 = load %"compiler/source:Span", ptr %l261
  %t551 = load %"compiler/diagmsg:Msg", ptr %l266
  %t552 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t549, %"compiler/source:Span" %t550, %"compiler/diagmsg:Msg" %t551)
  store i64 %t552, ptr %l267
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s18)
  br label %bb151
bb141:
  %t553 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t554 = load i32, ptr %l272, !tbaa !23
  %t556 = icmp ne i32 %t554, %t553
  br i1 %t556, label %bb142, label %bb143
bb142:
  store %olang.scope zeroinitializer, ptr %s20
  %t558 = load ptr, ptr %l0, !tbaa !29
  store ptr %t558, ptr %l275, !tbaa !29
  %t559 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t559, ptr %l276
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t561 = load i32, ptr %l2, !tbaa !23
  %t564 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s20, ptr %t560, i32 %t561)
  store { i64, ptr } %t564, ptr %l279
  br label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s21
  %t565 = load ptr, ptr %l0, !tbaa !29
  store ptr %t565, ptr %l284, !tbaa !29
  %t566 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t566, ptr %l285
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load i32, ptr %l2, !tbaa !23
  %t571 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s21, ptr %t567, i32 %t568)
  store { i64, ptr } %t571, ptr %l288
  br label %bb147
bb144:
  %t572 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t573 = extractvalue { i64, ptr } %t572, 0
  %t574 = extractvalue { i64, ptr } %t572, 1
  %t575 = mul i64 %t573, 1
  %t576 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t575)
  call void @llvm.memcpy.p0.p0.i64(ptr %t576, ptr %t574, i64 %t575, i1 false)
  %t577 = insertvalue { i64, ptr } undef, i64 %t573, 0
  %t578 = insertvalue { i64, ptr } %t577, ptr %t576, 1
  %t579 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t582 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %s20, ptr %s17, ptr %v0, { i64, ptr } %t578, { i64, ptr } %t579)
  store %"compiler/diagmsg:Msg" %t582, ptr %l282
  br label %bb145
bb145:
  %t583 = load ptr, ptr %l275, !tbaa !29
  %t584 = load %"compiler/source:Span", ptr %l276
  %t585 = load %"compiler/diagmsg:Msg", ptr %l282
  %t586 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t583, %"compiler/source:Span" %t584, %"compiler/diagmsg:Msg" %t585)
  store i64 %t586, ptr %l283
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s20)
  br label %bb150
bb147:
  %t587 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t588 = extractvalue { i64, ptr } %t587, 0
  %t589 = extractvalue { i64, ptr } %t587, 1
  %t590 = mul i64 %t588, 1
  %t591 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t590)
  call void @llvm.memcpy.p0.p0.i64(ptr %t591, ptr %t589, i64 %t590, i1 false)
  %t592 = insertvalue { i64, ptr } undef, i64 %t588, 0
  %t593 = insertvalue { i64, ptr } %t592, ptr %t591, 1
  %t594 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t597 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownNameMeant(ptr %s21, ptr %s17, ptr %v0, { i64, ptr } %t593, { i64, ptr } %t594)
  store %"compiler/diagmsg:Msg" %t597, ptr %l291
  br label %bb148
bb148:
  %t598 = load ptr, ptr %l284, !tbaa !29
  %t599 = load %"compiler/source:Span", ptr %l285
  %t600 = load %"compiler/diagmsg:Msg", ptr %l291
  %t601 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t598, %"compiler/source:Span" %t599, %"compiler/diagmsg:Msg" %t600)
  store i64 %t601, ptr %l292
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s21)
  br label %bb150
bb150:
  br label %bb151
bb151:
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t604 = getelementptr %"compiler/check:Checker", ptr %t602, i32 0, i32 105
  store ptr %t604, ptr %l294, !tbaa !29
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t607 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t605)
  store ptr %t607, ptr %l296
  br label %bb152
bb152:
  %t608 = load ptr, ptr %l296, !tbaa !29
  %t610 = getelementptr %"compiler/check:frame", ptr %t608, i32 0, i32 0
  %t611 = load i64, ptr %t610, !tbaa !24
  %t612 = load i32, ptr %l2, !tbaa !23
  %t614 = sext i32 %t612 to i64
  %t617 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s17, i64 %t611, i64 %t614)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t617, ptr %l301
  br label %bb153
bb153:
  %t618 = load ptr, ptr %l294, !tbaa !29
  %t619 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l301
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t618, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t619, i1 true)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s17)
  br label %bb155
bb155:
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t621 = load %"compiler/source:Span", ptr %l1
  %t624 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t620, %"compiler/source:Span" %t621)
  store ptr %t624, ptr %l304
  br label %bb156
bb156:
  %t625 = load ptr, ptr %l304, !tbaa !29
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t625, ptr %rv
  br label %ret
bb157:
  %t627 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t628 = load i32, ptr %t627, !range !{i32 0, i32 9}
  %t630 = trunc i64 7 to i32
  %t631 = icmp eq i32 %t628, %t630
  br i1 %t631, label %bb158, label %bb159
bb158:
  %t633 = load ptr, ptr %l0, !tbaa !29
  store ptr %t633, ptr %l308, !tbaa !29
  %t634 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t634, ptr %l309
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t636 = load i32, ptr %l2, !tbaa !23
  %t639 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t635, i32 %t636)
  store { i64, ptr } %t639, ptr %l312
  br label %bb160
bb159:
  br label %bb164
bb160:
  %t640 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t641 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeNotAValue(ptr %v0, ptr %v0, { i64, ptr } %t640)
  store %"compiler/diagmsg:Msg" %t641, ptr %l313
  br label %bb161
bb161:
  %t642 = load ptr, ptr %l308, !tbaa !29
  %t643 = load %"compiler/source:Span", ptr %l309
  %t644 = load %"compiler/diagmsg:Msg", ptr %l313
  %t645 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t642, %"compiler/source:Span" %t643, %"compiler/diagmsg:Msg" %t644)
  store i64 %t645, ptr %l314
  br label %bb162
bb162:
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t647 = load %"compiler/source:Span", ptr %l1
  %t650 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t646, %"compiler/source:Span" %t647)
  store ptr %t650, ptr %l317
  br label %bb163
bb163:
  %t651 = load ptr, ptr %l317, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t651, ptr %rv
  br label %ret
bb164:
  %t653 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t654 = load i32, ptr %t653, !range !{i32 0, i32 9}
  %t656 = trunc i64 4 to i32
  %t657 = icmp eq i32 %t654, %t656
  br i1 %t657, label %bb165, label %bb166
bb165:
  store %olang.scope zeroinitializer, ptr %s23
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t660 = load %"compiler/source:Span", ptr %l1
  %t661 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t662
  %t663 = getelementptr { i64, [4 x i64] }, ptr %t662, i32 0, i32 0
  store i64 0, ptr %t663
  %t665 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t660, 0
  %t667 = insertvalue { %"compiler/source:Span", i32 } %t665, i32 %t661, 1
  %t668 = getelementptr { i64, [4 x i64] }, ptr %t662, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t667, ptr %t668
  %t669 = load { i64, [4 x i64] }, ptr %t662
  %t671 = call ptr @__olang_scope_alloc_a(ptr %s23, i64 40, i64 8)
  store { i64, [4 x i64] } %t669, ptr %t671
  %t674 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %s23, ptr %t659, ptr %t671)
  store i32 %t674, ptr %l326
  br label %bb167
bb166:
  br label %bb179
bb167:
  %t675 = load i32, ptr %l326, !tbaa !23
  store i32 %t675, ptr %l14, !tbaa !23
  %t676 = load i32, ptr %l14, !tbaa !23
  %t678 = icmp sge i32 %t676, 0
  br i1 %t678, label %bb168, label %bb169
bb168:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load i32, ptr %l14, !tbaa !23
  %t684 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t680, i32 %t681)
  store i1 %t684, ptr %l332
  br label %bb170
bb169:
  store i1 false, ptr %l329, !tbaa !21
  br label %bb171
bb170:
  %t685 = load i1, ptr %l332, !tbaa !21
  %t686 = xor i1 %t685, true
  store i1 %t686, ptr %l329, !tbaa !21
  br label %bb171
bb171:
  %t688 = load i1, ptr %l329, !tbaa !21
  br i1 %t688, label %bb172, label %bb173
bb172:
  %t689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t689, ptr %l334, !tbaa !29
  %t690 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t690, ptr %l335
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t692 = load i32, ptr %l2, !tbaa !23
  %t695 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t691, i32 %t692)
  store { i64, ptr } %t695, ptr %l338
  br label %bb174
bb173:
  br label %bb177
bb174:
  %t696 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t697 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeNotAValue(ptr %v0, ptr %v0, { i64, ptr } %t696)
  store %"compiler/diagmsg:Msg" %t697, ptr %l339
  br label %bb175
bb175:
  %t698 = load ptr, ptr %l334, !tbaa !29
  %t699 = load %"compiler/source:Span", ptr %l335
  %t700 = load %"compiler/diagmsg:Msg", ptr %l339
  %t701 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t698, %"compiler/source:Span" %t699, %"compiler/diagmsg:Msg" %t700)
  store i64 %t701, ptr %l340
  br label %bb176
bb176:
  br label %bb177
bb177:
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t703 = load %"compiler/source:Span", ptr %l1
  %t706 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t702, %"compiler/source:Span" %t703)
  store ptr %t706, ptr %l343
  br label %bb178
bb178:
  %t707 = load ptr, ptr %l343, !tbaa !29
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t707, ptr %rv
  br label %ret
bb179:
  %t709 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t710 = load i32, ptr %t709, !range !{i32 0, i32 9}
  %t712 = trunc i64 3 to i32
  %t713 = icmp eq i32 %t710, %t712
  br i1 %t713, label %bb180, label %bb181
bb180:
  %t715 = load ptr, ptr %l0, !tbaa !29
  store ptr %t715, ptr %l347, !tbaa !29
  %t716 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t716, ptr %l348
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t719 = getelementptr %"compiler/check:Checker", ptr %t717, i32 0, i32 1
  %t720 = load ptr, ptr %t719, !tbaa !29
  %t721 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t722 = load i64, ptr %t721, !tbaa !24
  %t723 = load i32, ptr %l2, !tbaa !23
  %t727 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t720, i64 %t722, i32 %t723)
  store i64 %t727, ptr %l353
  br label %bb182
bb181:
  br label %bb188
bb182:
  %t728 = icmp sge i64 0, 0
  br i1 %t728, label %bb183, label %bb184
bb183:
  %t730 = icmp sle i64 0, 2305843009213693951
  br i1 %t730, label %bb185, label %bb186
bb184:
  call void @__olang_check_failed(ptr @olang_loc_98a79ecef50a7070_a6bcf048a1872fec)
  unreachable
bb185:
  %t732 = mul i64 0, 4
  %t733 = insertvalue { i64, ptr } undef, i64 0, 0
  %t734 = insertvalue { i64, ptr } %t733, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t735 = load ptr, ptr %l347, !tbaa !29
  %t736 = load %"compiler/source:Span", ptr %l348
  %t737 = load i64, ptr %l353, !tbaa !24
  %t739 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %v1, ptr %t735, %"compiler/source:Span" %t736, i64 %t737, { i64, ptr } %t734)
  store ptr %t739, ptr %l357
  br label %bb187
bb186:
  call void @__olang_check_failed(ptr @olang_loc_98a79ecef50a7070_a6bcf048a1872fec)
  unreachable
bb187:
  %t740 = load ptr, ptr %l357, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t740, ptr %rv
  br label %ret
bb188:
  %t742 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t743 = load i32, ptr %t742, !range !{i32 0, i32 9}
  %t745 = trunc i64 8 to i32
  %t746 = icmp eq i32 %t743, %t745
  br i1 %t746, label %bb189, label %bb190
bb189:
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t750 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t748)
  store ptr %t750, ptr %l363
  br label %bb191
bb190:
  br label %bb203
bb191:
  %t751 = load ptr, ptr %l363, !tbaa !29
  %t753 = getelementptr %"compiler/check:frame", ptr %t751, i32 0, i32 4
  %t754 = getelementptr %"compiler/generic:Context", ptr %t753, i32 0, i32 2
  %t755 = load i32, ptr %l2, !tbaa !23
  %t758 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t754, i32 %t755)
  %t759 = extractvalue { i32, i32 } %t758, 1
  %t760 = extractvalue { i32, i32 } %t758, 0
  store i32 %t760, ptr %l368
  %t761 = icmp ne i32 %t760, 0
  br i1 %t761, label %bb193, label %ok.762, !prof !99
ok.762:
  store i32 %t759, ptr %l367
  br label %bb192
bb192:
  %t763 = load i32, ptr %l367, !tbaa !23
  store i32 %t763, ptr %l361, !tbaa !23
  br label %bb195
bb193:
  br label %bb194
bb194:
  %t764 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t764, ptr %l361, !tbaa !23
  br label %bb195
bb195:
  %t766 = load i32, ptr %l361, !tbaa !23
  %t768 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t771 = icmp ne i32 %t766, %t768
  br i1 %t771, label %bb196, label %bb197
bb196:
  %t773 = load ptr, ptr %l0, !tbaa !29
  store ptr %t773, ptr %l373, !tbaa !29
  %t774 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t774, ptr %l374
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t776 = load i32, ptr %l2, !tbaa !23
  %t779 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t775, i32 %t776)
  store { i64, ptr } %t779, ptr %l377
  br label %bb198
bb197:
  br label %bb202
bb198:
  %t780 = load { i64, ptr }, ptr %l377, !tbaa !27
  %t781 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeVarAsValue(ptr %v0, ptr %v0, { i64, ptr } %t780)
  store %"compiler/diagmsg:Msg" %t781, ptr %l378
  br label %bb199
bb199:
  %t782 = load ptr, ptr %l373, !tbaa !29
  %t783 = load %"compiler/source:Span", ptr %l374
  %t784 = load %"compiler/diagmsg:Msg", ptr %l378
  %t785 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t782, %"compiler/source:Span" %t783, %"compiler/diagmsg:Msg" %t784)
  store i64 %t785, ptr %l379
  br label %bb200
bb200:
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t787 = load %"compiler/source:Span", ptr %l1
  %t790 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t786, %"compiler/source:Span" %t787)
  store ptr %t790, ptr %l382
  br label %bb201
bb201:
  %t791 = load ptr, ptr %l382, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t791, ptr %rv
  br label %ret
bb202:
  br label %bb203
bb203:
  %t793 = load ptr, ptr %l0, !tbaa !29
  %t794 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t793, %"compiler/source:Span" %t794, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb204
bb204:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t798 = load %"compiler/source:Span", ptr %l1
  %t801 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t797, %"compiler/source:Span" %t798)
  store ptr %t801, ptr %l388
  br label %bb205
bb205:
  %t802 = load ptr, ptr %l388, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t802, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l8 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %t3, i32 2, ptr %a2, ptr null)
  store ptr %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l8, !tbaa !29
  store ptr %t11, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoIndex(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l12 = alloca i1
  %l17 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l31 = alloca %"compiler/diagmsg:Msg"
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"compiler/diagmsg:Msg"
  %l41 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %t1, %"compiler/source:Span" %a1)
  store %"compiler/source:Span" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t6, ptr %l5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l5
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s0, ptr %s0, ptr %t7, i32 %t8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d39, i32 0, i32 1) }, %"compiler/source:Span" %t9, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) }, i64 1, i1 true)
  store i1 %t13, ptr %l12
  br label %bb2
bb2:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = add i64 %a4, 1
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t15, i32 %t16, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) }, i64 %t19)
  store i64 %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load i64, ptr %l17, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 59
  %t31 = getelementptr %"compiler/source:Span", ptr %t30, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = icmp sge i32 %t32, 0
  br i1 %t34, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 59
  %t39 = load %"compiler/source:Span", ptr %t38
  store %"compiler/source:Span" %t39, ptr %l23
  br label %bb11
bb10:
  %t41 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t41, ptr %l23
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t47 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t43, i32 %a3)
  store { i64, ptr } %t47, ptr %l29
  br label %bb12
bb12:
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t56 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %s2, ptr %v0, { i64, ptr } %t54)
  store %"compiler/diagmsg:Msg" %t56, ptr %l31
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l19, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l23
  %t59 = load %"compiler/diagmsg:Msg", ptr %l31
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t57, %"compiler/source:Span" %t58, %"compiler/diagmsg:Msg" %t59)
  store i64 %t60, ptr %l32
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t62, ptr %l34
  %t63 = load i32, ptr %l2, !tbaa !23
  store i32 %t63, ptr %l35, !tbaa !23
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t64, i32 %t65)
  store { i64, ptr } %t68, ptr %l38
  br label %bb16
bb16:
  %t69 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s0, ptr %v0, { i64, ptr } %t75)
  store %"compiler/diagmsg:Msg" %t77, ptr %l40
  br label %bb17
bb17:
  %t78 = load ptr, ptr %l33, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l34
  %t80 = load i32, ptr %l35, !tbaa !23
  %t81 = load %"compiler/diagmsg:Msg", ptr %l40
  %t82 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s0, ptr %v0, ptr %t78, %"compiler/source:Span" %t79, i32 %t80, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d42, i32 0, i32 1) }, %"compiler/diagmsg:Msg" %t81)
  store i64 %t82, ptr %l41
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t4 = call i1 @compiler_2fcheck_2elaneTok(i32 %a1)
  store i1 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i1, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 48
  store i1 %t5, ptr %t7, !tbaa !21
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t8, ptr %a2, i32 %a3)
  store ptr %t15, ptr %l11
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l11, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsHaveEq(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l23 = alloca i32
  %l26 = alloca ptr
  %l31 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i32
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l67 = alloca i1
  %l73 = alloca i32
  %l78 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l97 = alloca i1
  %l103 = alloca i1
  %l104 = alloca ptr
  %l109 = alloca i32
  %l111 = alloca i1
  %l114 = alloca i1
  %l119 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l138 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l23
  br label %bb4
bb4:
  %t16 = load i32, ptr %l23, !range !{i32 0, i32 33}
  store i32 %t16, ptr %l3
  %t17 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t19 = trunc i64 19 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l26, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l31
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t35 = load i32, ptr %l31, !tbaa !23
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %t34, i32 %t35, i64 %t33)
  store i1 %t37, ptr %l33
  br label %bb8
bb8:
  %t38 = load i1, ptr %l33, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t41 = trunc i64 18 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l40
  br label %bb12
bb11:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb13
bb12:
  %t52 = load i1, ptr %l40, !tbaa !21
  store i1 %t52, ptr %l36, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l36, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l43
  br label %bb16
bb15:
  br label %bb54
bb16:
  %t59 = load i32, ptr %l43, !range !{i32 0, i32 6}
  %t61 = trunc i64 0 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l48, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l53
  br label %bb19
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l73
  br label %bb31
bb19:
  %t85 = load ptr, ptr %l48, !tbaa !29
  %t86 = load i32, ptr %l53, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t85, i32 %t86)
  store { i64, ptr } %t87, ptr %l54
  br label %bb20
bb20:
  %t88 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t88, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l6, !tbaa !24
  br label %bb21
bb21:
  %t93 = load i64, ptr %l5, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  br label %bb24
bb24:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l61, !tbaa !27
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i32, ptr %t105, i64 %t102
  %t107 = load i32, ptr %t106, !tbaa !33
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l2, !tbaa !24
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %t109, i32 %t107, i64 %t111)
  store i1 %t115, ptr %l67
  br label %bb25
bb25:
  %t116 = load i1, ptr %l67, !tbaa !21
  br i1 %t116, label %bb26, label %bb27
bb26:
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t118 = load i64, ptr %l5, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l5, !tbaa !24
  br label %bb21
bb30:
  br label %bb53
bb31:
  %t122 = load i32, ptr %l73, !range !{i32 0, i32 6}
  %t124 = trunc i64 1 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb32, label %bb33
bb32:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  store ptr %t132, ptr %l78, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l1, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l83
  br label %bb34
bb33:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l1, !tbaa !23
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t143, i32 %t144)
  store i1 %t147, ptr %l103
  br label %bb46
bb34:
  %t148 = load ptr, ptr %l78, !tbaa !29
  %t149 = load i32, ptr %l83, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t148, i32 %t149)
  store { i64, ptr } %t150, ptr %l84
  br label %bb35
bb35:
  %t151 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t151, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 0
  store i64 %t154, ptr %l10, !tbaa !24
  br label %bb36
bb36:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb37, label %bb38
bb37:
  br label %bb45
bb38:
  br label %bb39
bb39:
  %t164 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t164, ptr %l91, !tbaa !27
  %t165 = load i64, ptr %l9, !tbaa !24
  %t167 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr i32, ptr %t168, i64 %t165
  %t170 = load i32, ptr %t169, !tbaa !33
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l2, !tbaa !24
  %t178 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %t172, i32 %t170, i64 %t174)
  store i1 %t178, ptr %l97
  br label %bb40
bb40:
  %t179 = load i1, ptr %l97, !tbaa !21
  br i1 %t179, label %bb41, label %bb42
bb41:
  store i1 true, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t181 = load i64, ptr %l9, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l9, !tbaa !24
  br label %bb36
bb45:
  br label %bb52
bb46:
  %t185 = load i1, ptr %l103, !tbaa !21
  br i1 %t185, label %bb47, label %bb48
bb47:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l104, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 2
  %t193 = load i32, ptr %l1, !tbaa !23
  %t196 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t196, ptr %l109
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t197 = load i64, ptr %l2, !tbaa !24
  %t198 = load ptr, ptr %l104, !tbaa !29
  %t199 = load i32, ptr %l109, !tbaa !23
  %t201 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %t198, i32 %t199, i64 %t197)
  store i1 %t201, ptr %l111
  br label %bb50
bb50:
  %t202 = load i1, ptr %l111, !tbaa !21
  store i1 %t202, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t203 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t205 = trunc i64 23 to i32
  %t206 = icmp eq i32 %t203, %t205
  br i1 %t206, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb57
bb56:
  %t208 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t210 = trunc i64 22 to i32
  %t211 = icmp eq i32 %t208, %t210
  store i1 %t211, ptr %l114, !tbaa !21
  br label %bb57
bb57:
  %t213 = load i1, ptr %l114, !tbaa !21
  br i1 %t213, label %bb58, label %bb59
bb58:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = getelementptr %"compiler/generic:Program", ptr %t217, i32 0, i32 2
  store ptr %t219, ptr %l119, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = getelementptr %"compiler/generic:Program", ptr %t223, i32 0, i32 2
  %t226 = load i32, ptr %l1, !tbaa !23
  %t229 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t225, i32 %t226)
  store i32 %t229, ptr %l124
  br label %bb60
bb59:
  br label %bb72
bb60:
  %t230 = load ptr, ptr %l119, !tbaa !29
  %t231 = load i32, ptr %l124, !tbaa !23
  %t232 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t230, i32 %t231)
  store { i64, ptr } %t232, ptr %l125
  br label %bb61
bb61:
  %t233 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t233, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  store i64 %t236, ptr %l14, !tbaa !24
  br label %bb62
bb62:
  %t238 = load i64, ptr %l13, !tbaa !24
  %t239 = load i64, ptr %l14, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb63, label %bb64
bb63:
  br label %bb71
bb64:
  br label %bb65
bb65:
  %t246 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t246, ptr %l132, !tbaa !27
  %t247 = load i64, ptr %l13, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i32, ptr %t250, i64 %t247
  %t252 = load i32, ptr %t251, !tbaa !33
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l2, !tbaa !24
  %t260 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %t254, i32 %t252, i64 %t256)
  store i1 %t260, ptr %l138
  br label %bb66
bb66:
  %t261 = load i1, ptr %l138, !tbaa !21
  br i1 %t261, label %bb67, label %bb68
bb67:
  store i1 true, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t263 = load i64, ptr %l13, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l13, !tbaa !24
  br label %bb62
bb71:
  br label %bb72
bb72:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 9}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_37e2897bc2167462_b245f142cb8d96e6)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l69 = alloca %"compiler/source:Span"
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Path", ptr %t2, i32 0, i32 0
  %t5 = load %"compiler/source:Span", ptr %t4
  %t8 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %t5)
  store { i64, ptr } %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = add i64 %t14, 1
  store i64 %t16, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l26, !tbaa !24
  store i64 %t44, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  store i64 %t64, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l48, !tbaa !27
  %t71 = load i64, ptr %l11, !tbaa !24
  %t73 = sub i64 %t71, 1
  %t75 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  %t80 = icmp ne i8 %t78, 46
  store i1 %t80, ptr %l47, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb15
bb15:
  %t82 = load i1, ptr %l47, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t85 = load i64, ptr %l11, !tbaa !24
  %t87 = sub i64 %t85, 1
  store i64 %t87, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  br label %bb12
bb20:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l2, !tbaa !24
  %t93 = icmp eq i64 %t89, %t90
  br i1 %t93, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Path", ptr %t95, i32 0, i32 0
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = trunc i64 %t100 to i32
  %t105 = add i32 %t99, %t102
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Path", ptr %t106, i32 0, i32 0
  %t109 = getelementptr %"compiler/source:Span", ptr %t108, i32 0, i32 0
  %t110 = load i32, ptr %t109, !tbaa !23
  %t111 = load i64, ptr %l4, !tbaa !24
  %t113 = trunc i64 %t111 to i32
  %t116 = add i32 %t110, %t113
  %t119 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t105, i32 %t116)
  store %"compiler/source:Span" %t119, ptr %l69
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  %t120 = load %"compiler/source:Span", ptr %l69
  store %"compiler/source:Span" %t120, ptr %rv
  br label %ret
bb24:
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = sub i64 %t121, 1
  store i64 %t123, ptr %l4, !tbaa !24
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = icmp slt i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Path", ptr %t129, i32 0, i32 0
  %t132 = load %"compiler/source:Span", ptr %t131
  store %"compiler/source:Span" %t132, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t134 = load i64, ptr %l9, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l9, !tbaa !24
  br label %bb8
bb29:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/ast:Path", ptr %t138, i32 0, i32 0
  %t141 = load %"compiler/source:Span", ptr %t140
  store %"compiler/source:Span" %t141, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 31
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d43, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 31
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 31
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprovenOperand(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l22 = alloca %"compiler/check:litv"
  %l26 = alloca i1
  %l31 = alloca i1
  %l35 = alloca i1
  %l39 = alloca ptr
  %l41 = alloca i32
  %l46 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 52}
  store i32 %t20, ptr %l4
  br label %bb5
bb4:
  br label %bb30
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l16
  br label %bb6
bb6:
  %t27 = load i1, ptr %l16, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t35 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v2, ptr %t30, ptr %t31)
  store %"compiler/check:litv" %t35, ptr %l22
  br label %bb9
bb9:
  %t36 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 0
  %t37 = load i1, ptr %t36, !tbaa !21
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t40 = load i32, ptr %l4, !range !{i32 0, i32 52}
  %t42 = trunc i64 8 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb16
bb15:
  %t45 = load i32, ptr %l4, !range !{i32 0, i32 52}
  %t47 = trunc i64 9 to i32
  %t48 = icmp eq i32 %t45, %t47
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l26, !tbaa !21
  store i1 %t50, ptr %l5, !tbaa !21
  %t51 = load i1, ptr %l5, !tbaa !21
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t55 = load i32, ptr %l4, !range !{i32 0, i32 52}
  %t57 = trunc i64 6 to i32
  %t58 = icmp eq i32 %t55, %t57
  %t60 = xor i1 %t58, true
  store i1 %t60, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t62 = load i1, ptr %l31, !tbaa !21
  br i1 %t62, label %bb20, label %bb21
bb20:
  %t63 = load i32, ptr %l4, !range !{i32 0, i32 52}
  %t65 = trunc i64 7 to i32
  %t66 = icmp eq i32 %t63, %t65
  %t68 = xor i1 %t66, true
  store i1 %t68, ptr %l35, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t70 = load i1, ptr %l35, !tbaa !21
  br i1 %t70, label %bb23, label %bb24
bb23:
  br label %ret
bb24:
  br label %bb25
bb25:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  %t72 = load i1, ptr %l5, !tbaa !21
  br i1 %t72, label %bb26, label %bb27
bb26:
  store i32 105, ptr %l41
  br label %bb28
bb27:
  store i32 71, ptr %l41
  br label %bb28
bb28:
  %t76 = load i32, ptr %l3, !tbaa !23
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load i32, ptr %l41, !range !{i32 0, i32 113}
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprovenAmount(ptr %v0, ptr %v2, ptr %t78, i32 %t79, i32 %t76, ptr %t77)
  store i1 %t82, ptr %l46
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_99086173777f8bfa_1537fe52b2cd754e)
  unreachable
bb35:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l60 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l93 = alloca { i64, ptr }
  %l99 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t7 = load ptr, ptr %l15, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l15, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 28}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l16, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb24
bb7:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t22 = load ptr, ptr %l21, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l21, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 28}
  %t28 = icmp eq i64 %t26, 24
  store i1 %t28, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l22, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l2, !tbaa !29
  br label %bb24
bb11:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t37 = load ptr, ptr %l27, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l27, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 28}
  %t43 = icmp eq i64 %t41, 26
  store i1 %t43, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l2, !tbaa !29
  br label %bb24
bb15:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t52 = load ptr, ptr %l33, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l33, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 28}
  %t58 = icmp eq i64 %t56, 3
  store i1 %t58, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t59 = load i1, ptr %l34, !tbaa !21
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l2, !tbaa !29
  br label %bb24
bb19:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t67 = load ptr, ptr %l39, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load ptr, ptr %l39, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 28}
  %t73 = icmp eq i64 %t71, 12
  store i1 %t73, ptr %l40, !tbaa !21
  br label %bb21
bb21:
  %t74 = load i1, ptr %l40, !tbaa !21
  br i1 %t74, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t77, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l2, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  store i1 %t86, ptr %l48
  br label %bb25
bb25:
  %t87 = load i1, ptr %l48, !tbaa !21
  store i1 %t87, ptr %rv
  br label %ret
bb26:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t89 = load ptr, ptr %l49, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb27, label %bb28
bb27:
  %t92 = load ptr, ptr %l49, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 28}
  %t95 = icmp eq i64 %t93, 10
  store i1 %t95, ptr %l50, !tbaa !21
  br label %bb28
bb28:
  %t96 = load i1, ptr %l50, !tbaa !21
  br i1 %t96, label %bb29, label %bb30
bb29:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t99, i32 0, i32 1
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l3, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t105, i32 0, i32 2
  %t107 = load { i64, ptr }, ptr %t106
  store { i64, ptr } %t107, ptr %l4, !tbaa !27
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t111 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t115 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v1, ptr %t109, ptr %t110, { i64, ptr } %t111)
  store i64 %t115, ptr %l60
  br label %bb32
bb32:
  %t116 = load i64, ptr %l60, !tbaa !24
  %t117 = icmp sge i64 %t116, 0
  store i1 %t117, ptr %rv
  br label %ret
bb33:
  %t119 = load ptr, ptr %l1, !tbaa !29
  store ptr %t119, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t120 = load ptr, ptr %l62, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb34, label %bb35
bb34:
  %t123 = load ptr, ptr %l62, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 28}
  %t126 = icmp eq i64 %t124, 5
  store i1 %t126, ptr %l63, !tbaa !21
  br label %bb35
bb35:
  %t127 = load i1, ptr %l63, !tbaa !21
  br i1 %t127, label %bb36, label %bb37
bb36:
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t130, i32 0, i32 2
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l5, !tbaa !29
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t136, i32 0, i32 3
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb44
bb38:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l5, !tbaa !29
  %t145 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t140, ptr %t141)
  store i1 %t145, ptr %l73
  br label %bb39
bb39:
  %t146 = load i1, ptr %l73, !tbaa !21
  br i1 %t146, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb43
bb41:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l6, !tbaa !29
  %t152 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t147, ptr %t148)
  store i1 %t152, ptr %l78
  br label %bb42
bb42:
  %t153 = load i1, ptr %l78, !tbaa !21
  store i1 %t153, ptr %l74, !tbaa !21
  br label %bb43
bb43:
  %t154 = load i1, ptr %l74, !tbaa !21
  store i1 %t154, ptr %rv
  br label %ret
bb44:
  %t155 = load ptr, ptr %l1, !tbaa !29
  store ptr %t155, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t156 = load ptr, ptr %l79, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l79, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 28}
  %t162 = icmp eq i64 %t160, 7
  store i1 %t162, ptr %l80, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l80, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr }, ptr %t166, i32 0, i32 1
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l7, !tbaa !29
  br label %bb49
bb48:
  br label %bb60
bb49:
  %t170 = load ptr, ptr %l7, !tbaa !29
  %t172 = getelementptr %"compiler/ast:Chain", ptr %t170, i32 0, i32 1
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l10, !tbaa !24
  br label %bb50
bb50:
  %t179 = load i64, ptr %l9, !tbaa !24
  %t180 = load i64, ptr %l10, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb51, label %bb52
bb51:
  br label %bb59
bb52:
  br label %bb53
bb53:
  %t187 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t187, ptr %l93, !tbaa !27
  %t188 = load i64, ptr %l9, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr ptr, ptr %t191, i64 %t188
  %t193 = load ptr, ptr %t192, !tbaa !39
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t200 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t195, ptr %t193)
  store i1 %t200, ptr %l99
  br label %bb54
bb54:
  %t201 = load i1, ptr %l99, !tbaa !21
  br i1 %t201, label %bb55, label %bb56
bb55:
  store i1 true, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t203 = load i64, ptr %l9, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l9, !tbaa !24
  br label %bb50
bb59:
  store i1 false, ptr %rv
  br label %ret
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  store i1 false, ptr %rv
  br label %ret
bb64:
  call void @__olang_check_failed(ptr @olang_loc_983ca47650ebcf0f_470cb00b1bd66703)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroArgFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %l28 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i32
  %l53 = alloca i1
  %l58 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/check:roArg"
  %l74 = alloca ptr
  %l75 = alloca i1
  %l83 = alloca i64
  %l87 = alloca ptr
  %l90 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l93 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l94 = alloca %"std/pair:Pair.b139c4f75a6545712256427180a82a06"
  %l97 = alloca i1
  %l99 = alloca ptr
  %l104 = alloca %"compiler/check:roDeepArg"
  %l105 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca i1
  %l114 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i64
  %l118 = alloca i64
  %l121 = alloca { i64, [3 x i64] }
  %l122 = alloca { i64, ptr }
  %l123 = alloca i64
  %l125 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l133 = alloca ptr
  %l136 = alloca i32
  %l139 = alloca i32
  %l140 = alloca { i64, ptr }
  %l142 = alloca %"compiler/check:roArg"
  %l143 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca i64
  %l150 = alloca ptr
  %l153 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l156 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l157 = alloca %"std/pair:Pair.b139c4f75a6545712256427180a82a06"
  %l160 = alloca i1
  %l162 = alloca ptr
  %l167 = alloca %"compiler/check:roDeepArg"
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  store i1 %t7, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l17
  br label %bb7
bb7:
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l20, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t22 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t19)
  store i32 %t22, ptr %l23
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = load i32, ptr %l23, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t25, ptr %l24
  br label %bb9
bb9:
  %t26 = load i1, ptr %l24, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t27, i64 %t28, i64 %t29)
  store i1 %t33, ptr %l28
  br label %bb12
bb11:
  br label %bb59
bb12:
  %t34 = load i1, ptr %l28, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l32, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  store ptr %t48, ptr %l35, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l38, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 18
  %t58 = load i64, ptr %l1, !tbaa !24
  %t61 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store ptr %t61, ptr %l42
  br label %bb16
bb16:
  %t62 = load ptr, ptr %l42, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %t64, !tbaa !23
  %t66 = load ptr, ptr %l38, !tbaa !29
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t66, i32 %t65)
  store i32 %t68, ptr %l45
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t70 = load i32, ptr %l45, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t69, i32 %t70)
  store { i64, ptr } %t71, ptr %l46
  br label %bb18
bb18:
  %t72 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t72, ptr %l47, !tbaa !27
  %t73 = load i64, ptr %l2, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i32, ptr %t76, i64 %t73
  %t78 = load i32, ptr %t77, !tbaa !33
  %t79 = load ptr, ptr %l32, !tbaa !29
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t79, i32 %t78)
  store i32 %t81, ptr %l50
  br label %bb19
bb19:
  %t82 = load i32, ptr %l50, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l7, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l53
  br label %bb20
bb20:
  %t88 = load i1, ptr %l53, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store i1 %t96, ptr %l58
  br label %bb24
bb24:
  %t97 = load i1, ptr %l58, !tbaa !21
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 103
  store ptr %t100, ptr %l60, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  store i64 %t101, ptr %l61, !tbaa !24
  %t102 = load i64, ptr %l2, !tbaa !24
  store i64 %t102, ptr %l62, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l4
  %t107 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t103, %"compiler/source:Span" %t104)
  store { i64, [3 x i64] } %t107, ptr %l65
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t108 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t108, ptr %l66, !tbaa !27
  %t109 = ptrtoint ptr %v0 to i64
  store i64 %t109, ptr %l67, !tbaa !24
  %t110 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aroArg_2e4
  br i1 %t110, label %bb28, label %bb29
bb28:
  %t112 = call ptr @__olang_region_make(ptr %v0)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l67, !tbaa !24
  br label %bb29
bb29:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l7, !tbaa !23
  %t116 = load i64, ptr %l67
  %t117 = inttoptr i64 %t116 to ptr
  %t120 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %t117, ptr %t114, i32 %t115)
  store { i64, ptr } %t120, ptr %l71
  br label %bb30
bb30:
  %t121 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t122 = load i64, ptr %l67
  %t123 = inttoptr i64 %t122 to ptr
  %t124 = extractvalue { i64, ptr } %t121, 0
  %t125 = extractvalue { i64, ptr } %t121, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_held_alloc(ptr %t123, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load i64, ptr %l61, !tbaa !24
  %t131 = load i64, ptr %l62, !tbaa !24
  %t132 = load { i64, [3 x i64] }, ptr %l65
  %t133 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t135 = call %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, i64 %t130, i64 %t131, { i64, [3 x i64] } %t132, { i64, ptr } %t133, { i64, ptr } %t129, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store %"compiler/check:roArg" %t135, ptr %l73
  br label %bb31
bb31:
  %t136 = load ptr, ptr %l60, !tbaa !29
  %t137 = load %"compiler/check:roArg", ptr %l73
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v0, ptr %t136, %"compiler/check:roArg" %t137)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb33:
  %t138 = load ptr, ptr %l3, !tbaa !29
  store ptr %t138, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t139 = load ptr, ptr %l74, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb34, label %bb35
bb34:
  %t142 = load ptr, ptr %l74, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 18}
  %t145 = icmp eq i64 %t143, 3
  store i1 %t145, ptr %l75, !tbaa !21
  br label %bb35
bb35:
  %t146 = load i1, ptr %l75, !tbaa !21
  br i1 %t146, label %bb36, label %bb37
bb36:
  %t147 = load ptr, ptr %l3, !tbaa !29
  %t149 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t149, i32 0, i32 2
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l8, !tbaa !29
  br label %bb38
bb37:
  br label %bb47
bb38:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t153, ptr %t154)
  store i64 %t158, ptr %l83
  br label %bb39
bb39:
  %t159 = load i64, ptr %l83, !tbaa !24
  store i64 %t159, ptr %l9, !tbaa !24
  %t160 = load i64, ptr %l9, !tbaa !24
  %t162 = icmp sge i64 %t160, 0
  br i1 %t162, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 95
  store ptr %t166, ptr %l87, !tbaa !29
  %t167 = load i64, ptr %l6, !tbaa !24
  %t168 = load i64, ptr %l9, !tbaa !24
  %t171 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t167, i64 %t168)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t171, ptr %l90
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t172 = load i64, ptr %l1, !tbaa !24
  %t173 = load i64, ptr %l2, !tbaa !24
  %t176 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t172, i64 %t173)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t176, ptr %l93
  br label %bb43
bb43:
  %t177 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l90
  %t178 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l93
  %t179 = call %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s7, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t177, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t178)
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t179, ptr %l94
  br label %bb44
bb44:
  %t180 = load ptr, ptr %l87, !tbaa !29
  %t181 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l94
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %t180, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t181)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_3ba07a3e63e86523_b4e2f85113e27c0f)
  unreachable
bb52:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i64, ptr %l6, !tbaa !24
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t182, i64 %t183)
  store i1 %t186, ptr %l97
  br label %bb53
bb53:
  %t187 = load i1, ptr %l97, !tbaa !21
  br i1 %t187, label %bb54, label %bb55
bb54:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 102
  store ptr %t190, ptr %l99, !tbaa !29
  %t191 = load i64, ptr %l6, !tbaa !24
  %t192 = load ptr, ptr %l3, !tbaa !29
  %t193 = load i64, ptr %l1, !tbaa !24
  %t194 = load i64, ptr %l2, !tbaa !24
  %t199 = call %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v1, ptr %v0, i64 %t191, ptr %t192, i64 %t193, i64 %t194)
  store %"compiler/check:roDeepArg" %t199, ptr %l104
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t200 = load ptr, ptr %l99, !tbaa !29
  %t201 = load %"compiler/check:roDeepArg", ptr %l104
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v0, ptr %t200, %"compiler/check:roDeepArg" %t201)
  br label %bb57
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb59:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l105, !tbaa !29
  %t203 = load ptr, ptr %l3, !tbaa !29
  %t206 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t203)
  store i32 %t206, ptr %l108
  br label %bb60
bb60:
  %t207 = load ptr, ptr %l105, !tbaa !29
  %t208 = load i32, ptr %l108, !tbaa !23
  %t209 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t207, i32 %t208)
  store i1 %t209, ptr %l109
  br label %bb61
bb61:
  %t210 = load i1, ptr %l109, !tbaa !21
  %t211 = xor i1 %t210, true
  br i1 %t211, label %bb62, label %bb63
bb62:
  br label %ret
bb63:
  br label %bb64
bb64:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l3, !tbaa !29
  %t218 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t213, ptr %t214)
  store i1 %t218, ptr %l114
  br label %bb65
bb65:
  %t219 = load i1, ptr %l114, !tbaa !21
  br i1 %t219, label %bb66, label %bb67
bb66:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 96
  store ptr %t222, ptr %l116, !tbaa !29
  %t223 = load i64, ptr %l1, !tbaa !24
  store i64 %t223, ptr %l117, !tbaa !24
  %t224 = load i64, ptr %l2, !tbaa !24
  store i64 %t224, ptr %l118, !tbaa !24
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l4
  %t229 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t225, %"compiler/source:Span" %t226)
  store { i64, [3 x i64] } %t229, ptr %l121
  br label %bb68
bb67:
  br label %bb80
bb68:
  %t230 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t230, ptr %l122, !tbaa !27
  %t231 = ptrtoint ptr %v0 to i64
  store i64 %t231, ptr %l123, !tbaa !24
  %t232 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aroArg_2e4
  br i1 %t232, label %bb69, label %bb70
bb69:
  %t234 = call ptr @__olang_region_make(ptr %v0)
  %t235 = ptrtoint ptr %t234 to i64
  store i64 %t235, ptr %l123, !tbaa !24
  br label %bb70
bb70:
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l125, !tbaa !29
  %t237 = load ptr, ptr %l3, !tbaa !29
  %t240 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t237)
  store i32 %t240, ptr %l128
  br label %bb71
bb71:
  %t241 = load i64, ptr %l123
  %t242 = inttoptr i64 %t241 to ptr
  %t243 = load ptr, ptr %l125, !tbaa !29
  %t244 = load i32, ptr %l128, !tbaa !23
  %t245 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %t242, ptr %t243, i32 %t244)
  store { i64, ptr } %t245, ptr %l129
  br label %bb72
bb72:
  %t246 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t247 = load i64, ptr %l123
  %t248 = inttoptr i64 %t247 to ptr
  %t249 = extractvalue { i64, ptr } %t246, 0
  %t250 = extractvalue { i64, ptr } %t246, 1
  %t251 = mul i64 %t249, 1
  %t252 = call ptr @__olang_held_alloc(ptr %t248, i64 %t251)
  call void @llvm.memcpy.p0.p0.i64(ptr %t252, ptr %t250, i64 %t251, i1 false)
  %t253 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t252, 1
  store { i64, ptr } %t254, ptr %l130, !tbaa !27
  %t255 = ptrtoint ptr %v0 to i64
  store i64 %t255, ptr %l131, !tbaa !24
  %t256 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aroArg_2e5
  br i1 %t256, label %bb73, label %bb74
bb73:
  %t258 = call ptr @__olang_region_make(ptr %v0)
  %t259 = ptrtoint ptr %t258 to i64
  store i64 %t259, ptr %l131, !tbaa !24
  br label %bb74
bb74:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l133, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l3, !tbaa !29
  %t265 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t261, ptr %t262)
  store i32 %t265, ptr %l136
  br label %bb75
bb75:
  %t266 = load ptr, ptr %l3, !tbaa !29
  %t269 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t266)
  store i32 %t269, ptr %l139
  br label %bb76
bb76:
  %t270 = load i64, ptr %l131
  %t271 = inttoptr i64 %t270 to ptr
  %t272 = load ptr, ptr %l133, !tbaa !29
  %t273 = load i32, ptr %l136, !tbaa !23
  %t274 = load i32, ptr %l139, !tbaa !23
  %t275 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %t271, ptr %t272, i32 %t273, i32 %t274)
  store { i64, ptr } %t275, ptr %l140
  br label %bb77
bb77:
  %t276 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t277 = load i64, ptr %l131
  %t278 = inttoptr i64 %t277 to ptr
  %t279 = extractvalue { i64, ptr } %t276, 0
  %t280 = extractvalue { i64, ptr } %t276, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_held_alloc(ptr %t278, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  %t285 = load i64, ptr %l117, !tbaa !24
  %t286 = load i64, ptr %l118, !tbaa !24
  %t287 = load { i64, [3 x i64] }, ptr %l121
  %t288 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t289 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t291 = call %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, i64 %t285, i64 %t286, { i64, [3 x i64] } %t287, { i64, ptr } %t288, { i64, ptr } %t289, { i64, ptr } %t284)
  store %"compiler/check:roArg" %t291, ptr %l142
  br label %bb78
bb78:
  %t292 = load ptr, ptr %l116, !tbaa !29
  %t293 = load %"compiler/check:roArg", ptr %l142
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v0, ptr %t292, %"compiler/check:roArg" %t293)
  br label %bb79
bb79:
  br label %ret
bb80:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l143, !tbaa !29
  %t295 = load ptr, ptr %l3, !tbaa !29
  %t297 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t295)
  store ptr %t297, ptr %l145
  br label %bb81
bb81:
  %t298 = load ptr, ptr %l143, !tbaa !29
  %t299 = load ptr, ptr %l145, !tbaa !29
  %t300 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t298, ptr %t299)
  store i64 %t300, ptr %l146
  br label %bb82
bb82:
  %t301 = load i64, ptr %l146, !tbaa !24
  store i64 %t301, ptr %l10, !tbaa !24
  %t302 = load i64, ptr %l10, !tbaa !24
  %t304 = icmp sge i64 %t302, 0
  br i1 %t304, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s12
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/check:Checker", ptr %t306, i32 0, i32 95
  store ptr %t308, ptr %l150, !tbaa !29
  %t309 = load i64, ptr %l6, !tbaa !24
  %t310 = load i64, ptr %l10, !tbaa !24
  %t313 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t309, i64 %t310)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t313, ptr %l153
  br label %bb85
bb84:
  br label %bb89
bb85:
  %t314 = load i64, ptr %l1, !tbaa !24
  %t315 = load i64, ptr %l2, !tbaa !24
  %t318 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t314, i64 %t315)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t318, ptr %l156
  br label %bb86
bb86:
  %t319 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l153
  %t320 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l156
  %t321 = call %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s12, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t319, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t320)
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t321, ptr %l157
  br label %bb87
bb87:
  %t322 = load ptr, ptr %l150, !tbaa !29
  %t323 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l157
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %t322, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t323)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb89:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load i64, ptr %l6, !tbaa !24
  %t328 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t324, i64 %t325)
  store i1 %t328, ptr %l160
  br label %bb90
bb90:
  %t329 = load i1, ptr %l160, !tbaa !21
  br i1 %t329, label %bb91, label %bb92
bb91:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/check:Checker", ptr %t330, i32 0, i32 102
  store ptr %t332, ptr %l162, !tbaa !29
  %t333 = load i64, ptr %l6, !tbaa !24
  %t334 = load ptr, ptr %l3, !tbaa !29
  %t335 = load i64, ptr %l1, !tbaa !24
  %t336 = load i64, ptr %l2, !tbaa !24
  %t341 = call %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v1, ptr %v0, i64 %t333, ptr %t334, i64 %t335, i64 %t336)
  store %"compiler/check:roDeepArg" %t341, ptr %l167
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t342 = load ptr, ptr %l162, !tbaa !29
  %t343 = load %"compiler/check:roDeepArg", ptr %l167
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v0, ptr %t342, %"compiler/check:roDeepArg" %t343)
  br label %bb94
bb94:
  br label %bb95
bb95:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t9, ptr %l10
  br label %bb4
bb4:
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 98
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H970bb490312910b3b744570a26468c6c(ptr %v0, ptr %t13, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14)
  store i1 %t17, ptr %l14
  br label %bb5
bb5:
  %t18 = load i1, ptr %l14, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 98
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l18
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l19
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd27b567062a69be2f699d8e9ab74cf5a(ptr %v0, ptr %v0, ptr %t26, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 98
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t35 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf1792c165fec863e4f2028b41ed50f44(ptr %v0, ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  %t36 = extractvalue { i32, ptr } %t35, 1
  %t37 = extractvalue { i32, ptr } %t35, 0
  store i32 %t37, ptr %l25
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39, !prof !99
ok.39:
  store ptr %t36, ptr %l24
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l24, !tbaa !29
  store ptr %t40, ptr %l20, !tbaa !29
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t41, ptr %t43)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLend(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l15 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %t9, ptr %t10, %"compiler/source:Span" %a2)
  store %"compiler/source:Span" %t15, ptr %l11
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store i32 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t22)
  store i32 %t25, ptr %l18
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i32, ptr %l15, !tbaa !23
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %s1, ptr %t26, i32 %t27, i32 %t28)
  store { i64, ptr } %t29, ptr %l19
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %s1, ptr %v0, { i64, ptr } %t36)
  store %"compiler/diagmsg:Msg" %t38, ptr %l21
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l7, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l11
  %t41 = load %"compiler/diagmsg:Msg", ptr %l21
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t39, %"compiler/source:Span" %t40, %"compiler/diagmsg:Msg" %t41)
  store i64 %t42, ptr %l22
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRefResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 100
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l15
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, ptr %v0, i64 %t29, ptr %t30)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t33, ptr %l19
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v0, ptr %t34, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t35)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i32
  %l12 = alloca i64
  %l14 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l38 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca i64
  %l48 = alloca i32
  %l49 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca %"compiler/typed:Local"
  %l55 = alloca i1
  %l57 = alloca ptr
  %l59 = alloca i64
  %l61 = alloca ptr
  %l63 = alloca %"compiler/typed:Local"
  %l67 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l78 = alloca ptr
  %l81 = alloca i1
  %l83 = alloca ptr
  %l85 = alloca ptr
  %l88 = alloca i1
  %l89 = alloca ptr
  %l91 = alloca ptr
  %l95 = alloca ptr
  %l99 = alloca ptr
  %l102 = alloca i64
  %l104 = alloca i64
  %l109 = alloca i32
  %l110 = alloca ptr
  %l112 = alloca ptr
  %l114 = alloca %"compiler/typed:Local"
  %l123 = alloca { i64, ptr }
  %l124 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 45
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t7)
  store ptr %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l14, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 13
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  store ptr %t20, ptr %l20, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l23, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t27)
  store ptr %t29, ptr %l25
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  %t30 = load ptr, ptr %l25, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t34, i32 %t33)
  store i32 %t36, ptr %l28
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = load i32, ptr %l28, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l29
  br label %bb7
bb7:
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t43 = icmp eq i64 %t41, 0
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l17, !tbaa !21
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t50 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epuns(ptr %v0, ptr %v1, ptr %s0, ptr %t46, { i64, ptr } %t47)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t50, ptr %l35
  br label %bb11
bb10:
  %t51 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t51, ptr %l36
  br label %bb12
bb11:
  %t52 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t52, ptr %l32
  br label %bb13
bb12:
  %t53 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t53, ptr %l32
  br label %bb13
bb13:
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %l3
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t55)
  store ptr %t57, ptr %l38
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l38, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t58, i32 0, i32 5
  store ptr %t60, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb15
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  store i64 %t62, ptr %l41, !tbaa !24
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l43
  br label %bb16
bb16:
  %t66 = load i64, ptr %l41, !tbaa !24
  %t67 = load i64, ptr %l43, !tbaa !24
  %t68 = icmp slt i64 %t66, %t67
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb31
bb18:
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t72, i64 %t73)
  store i32 %t76, ptr %l48
  br label %bb20
bb20:
  %t77 = load i32, ptr %l48, !tbaa !23
  store i32 %t77, ptr %l6, !tbaa !23
  store ptr %l3, ptr %l49, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t78)
  store ptr %t80, ptr %l51
  br label %bb21
bb21:
  %t81 = load i32, ptr %l6, !tbaa !23
  %t82 = load ptr, ptr %l51, !tbaa !29
  %t84 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t82, i32 %t81)
  store %"compiler/typed:Local" %t84, ptr %l53
  br label %bb22
bb22:
  %t85 = getelementptr %"compiler/typed:Local", ptr %l53, i32 0, i32 0
  %t86 = load i32, ptr %t85, !tbaa !23
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t89 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %s0, ptr %t87, i32 %t86)
  store i1 %t89, ptr %l55
  br label %bb23
bb23:
  %t90 = load i1, ptr %l55, !tbaa !21
  %t91 = xor i1 %t90, true
  br i1 %t91, label %bb24, label %bb25
bb24:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l57, !tbaa !29
  %t94 = load i32, ptr %l6, !tbaa !23
  %t96 = sext i32 %t94 to i64
  store i64 %t96, ptr %l59, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t97)
  store ptr %t99, ptr %l61
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t100 = load i32, ptr %l6, !tbaa !23
  %t101 = load ptr, ptr %l61, !tbaa !29
  %t103 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t101, i32 %t100)
  store %"compiler/typed:Local" %t103, ptr %l63
  br label %bb27
bb27:
  %t104 = getelementptr %"compiler/typed:Local", ptr %l63, i32 0, i32 1
  %t105 = load %"compiler/source:Span", ptr %t104
  %t106 = load ptr, ptr %l57, !tbaa !29
  %t107 = load i64, ptr %l59, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %t106, i64 %t107, %"compiler/source:Span" %t105, i1 true)
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l5, !tbaa !24
  br label %bb15
bb31:
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t113, ptr %l67, !tbaa !27
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t114)
  store ptr %t116, ptr %l69
  br label %bb32
bb32:
  %t117 = load ptr, ptr %l69, !tbaa !29
  %t119 = getelementptr %"compiler/check:frame", ptr %t117, i32 0, i32 43
  %t120 = load { i64, ptr }, ptr %l67, !tbaa !27
  call void @compiler_2fcheck_2estoredIn(ptr %v1, ptr %v0, { i64, ptr } %t120, ptr %t119)
  br label %bb33
bb33:
  %t122 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb34, label %bb35
bb34:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t128, { i64, ptr } %t129)
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t132)
  store ptr %t134, ptr %l78
  br label %bb38
bb38:
  %t135 = load ptr, ptr %l78, !tbaa !29
  %t137 = getelementptr %"compiler/check:frame", ptr %t135, i32 0, i32 13
  %t138 = load i1, ptr %t137, !tbaa !21
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  store ptr %t143, ptr %l83, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t144)
  store ptr %t146, ptr %l85
  br label %bb41
bb40:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb43
bb41:
  %t147 = load ptr, ptr %l85, !tbaa !29
  %t149 = getelementptr %"compiler/check:frame", ptr %t147, i32 0, i32 14
  %t150 = load i32, ptr %t149, !tbaa !23
  %t151 = load ptr, ptr %l83, !tbaa !29
  %t153 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %t151, i32 %t150)
  store i1 %t153, ptr %l88
  br label %bb42
bb42:
  %t154 = load i1, ptr %l88, !tbaa !21
  store i1 %t154, ptr %l81, !tbaa !21
  br label %bb43
bb43:
  %t155 = load i1, ptr %l81, !tbaa !21
  br i1 %t155, label %bb44, label %bb45
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l89, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t157)
  store ptr %t159, ptr %l91
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t160 = load ptr, ptr %l91, !tbaa !29
  %t162 = getelementptr %"compiler/check:frame", ptr %t160, i32 0, i32 14
  %t163 = load i32, ptr %t162, !tbaa !23
  %t164 = load ptr, ptr %l89, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnsFields(ptr %v0, ptr %t164, i32 %t163)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t166)
  store ptr %t168, ptr %l95
  br label %bb49
bb49:
  %t169 = load ptr, ptr %l95, !tbaa !29
  %t171 = getelementptr %"compiler/check:frame", ptr %t169, i32 0, i32 13
  %t172 = load i1, ptr %t171, !tbaa !21
  br i1 %t172, label %bb50, label %bb51
bb50:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t174)
  store ptr %t176, ptr %l99
  br label %bb52
bb51:
  br label %bb64
bb52:
  %t177 = load ptr, ptr %l99, !tbaa !29
  %t179 = getelementptr %"compiler/typed:Body", ptr %t177, i32 0, i32 10
  store ptr %t179, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb53
bb53:
  %t181 = load i64, ptr %l8, !tbaa !24
  store i64 %t181, ptr %l102, !tbaa !24
  %t182 = load ptr, ptr %l7, !tbaa !29
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t182)
  store i64 %t184, ptr %l104
  br label %bb54
bb54:
  %t185 = load i64, ptr %l102, !tbaa !24
  %t186 = load i64, ptr %l104, !tbaa !24
  %t187 = icmp slt i64 %t185, %t186
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb55, label %bb56
bb55:
  br label %bb63
bb56:
  br label %bb57
bb57:
  %t191 = load ptr, ptr %l7, !tbaa !29
  %t192 = load i64, ptr %l8, !tbaa !24
  %t195 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t191, i64 %t192)
  store i32 %t195, ptr %l109
  br label %bb58
bb58:
  %t196 = load i32, ptr %l109, !tbaa !23
  store i32 %t196, ptr %l9, !tbaa !23
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l110, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t198)
  store ptr %t200, ptr %l112
  br label %bb59
bb59:
  %t201 = load i32, ptr %l9, !tbaa !23
  %t202 = load ptr, ptr %l112, !tbaa !29
  %t204 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t202, i32 %t201)
  store %"compiler/typed:Local" %t204, ptr %l114
  br label %bb60
bb60:
  %t205 = getelementptr %"compiler/typed:Local", ptr %l114, i32 0, i32 1
  %t206 = load %"compiler/source:Span", ptr %t205
  %t207 = load i32, ptr %l9, !tbaa !23
  %t209 = sext i32 %t207 to i64
  %t210 = load ptr, ptr %l110, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropsGone(ptr %v0, ptr %t210, %"compiler/source:Span" %t206, i64 %t209)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t213 = load i64, ptr %l8, !tbaa !24
  %t215 = add i64 %t213, 1
  store i64 %t215, ptr %l8, !tbaa !24
  br label %bb53
bb63:
  br label %bb64
bb64:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/check:Checker", ptr %t217, i32 0, i32 45
  %t220 = load i64, ptr %l2, !tbaa !24
  %t223 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t219, i64 %t220)
  store { i64, ptr } %t223, ptr %l123
  br label %bb65
bb65:
  %t224 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t225 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 0, { i64, ptr } %t224)
  store %"compiler/typed:Block" %t225, ptr %l124
  br label %bb66
bb66:
  %t226 = load %"compiler/typed:Block", ptr %l124
  %t227 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Block" %t226, ptr %t227
  call void @__olang_scope_close(ptr %s0)
  store ptr %t227, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i1
  %l23 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t25 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t27 = trunc i64 19 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l10, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l2, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = icmp eq i32 %t41, 0
  store i1 %t42, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t44 = load i1, ptr %l18, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i32
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i1
  %l33 = alloca i32
  %l38 = alloca i32
  %l41 = alloca i1
  %l46 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t13 = trunc i64 19 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = icmp ne i32 %t26, 0
  store i1 %t27, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l10, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = load i32, ptr %l24, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t46, i32 %t47, i32 0)
  store i32 %t48, ptr %l25
  br label %bb9
bb9:
  %t49 = load i32, ptr %l25, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l28
  br label %bb11
bb11:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l33
  br label %bb14
bb13:
  br label %bb27
bb14:
  %t66 = load i32, ptr %l33, !tbaa !23
  store i32 %t66, ptr %l2, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l38
  br label %bb15
bb15:
  %t77 = load i32, ptr %l38, !range !{i32 0, i32 33}
  %t79 = trunc i64 19 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l46
  br label %bb18
bb17:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb19
bb18:
  %t92 = load i32, ptr %l46, !tbaa !23
  %t93 = icmp ne i32 %t92, 0
  store i1 %t93, ptr %l41, !tbaa !21
  br label %bb19
bb19:
  %t95 = load i1, ptr %l41, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l50, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  store ptr %t107, ptr %l53, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l2, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l58
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t118 = load ptr, ptr %l53, !tbaa !29
  %t119 = load i32, ptr %l58, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t118, i32 %t119, i32 0)
  store i32 %t120, ptr %l59
  br label %bb23
bb23:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l1, !tbaa !23
  %t130 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t126, i32 %t127)
  store i64 %t130, ptr %l64
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l50, !tbaa !29
  %t132 = load i32, ptr %l59, !tbaa !23
  %t133 = load i64, ptr %l64, !tbaa !24
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t131, i32 %t132, i64 %t133)
  store i32 %t134, ptr %l65
  br label %bb25
bb25:
  %t135 = load i32, ptr %l65, !tbaa !23
  store i32 %t135, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t136 = load i32, ptr %l1, !tbaa !23
  store i32 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnread(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/typed:Local"
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/names:Unread"
  %l13 = alloca { i64, [3 x i64] }
  %l19 = alloca i64
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca ptr
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca %"compiler/typed:Local"
  %l54 = alloca i1
  %l65 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l69 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i32
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca %"compiler/names:Unread"
  %l113 = alloca ptr
  %l114 = alloca { i64, [3 x i64] }
  %l117 = alloca { i64, ptr }
  %l119 = alloca %"compiler/diagmsg:Msg"
  %l120 = alloca i64
  %l128 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l129 = alloca i1
  %l132 = alloca i1
  %l133 = alloca i32
  %l138 = alloca ptr
  %l139 = alloca { i64, [3 x i64] }
  %l142 = alloca { i64, ptr }
  %l144 = alloca %"compiler/diagmsg:Msg"
  %l145 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t202 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 18
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l19
  br label %bb1
bb1:
  %t12 = load i64, ptr %l19, !tbaa !24
  %t13 = icmp eq i64 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l25
  br label %bb5
bb5:
  %t27 = load i64, ptr %l25, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  br i1 %t28, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %l27
  br label %bb9
bb9:
  %t31 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l27
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t31, ptr %l1
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 18
  store ptr %t34, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb10
bb10:
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %l30, !tbaa !24
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t37)
  store i64 %t39, ptr %l32
  br label %bb11
bb11:
  %t40 = load i64, ptr %l30, !tbaa !24
  %t41 = load i64, ptr %l32, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb12, label %bb13
bb12:
  br label %bb51
bb13:
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t46, i64 %t47)
  store ptr %t50, ptr %l37
  br label %bb15
bb15:
  %t51 = load ptr, ptr %l37, !tbaa !29
  store ptr %t51, ptr %l4, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 11
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb16, label %bb17
bb16:
  br label %bb50
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Body", ptr %t59, i32 0, i32 7
  store ptr %t61, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s7
  %t63 = load i64, ptr %l6, !tbaa !24
  store i64 %t63, ptr %l43, !tbaa !24
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l45
  br label %bb20
bb20:
  %t67 = load i64, ptr %l43, !tbaa !24
  %t68 = load i64, ptr %l45, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb22:
  br label %bb23
bb23:
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t73, i64 %t74)
  store %"compiler/typed:Local" %t77, ptr %l50
  br label %bb24
bb24:
  %t78 = load %"compiler/typed:Local", ptr %l50
  store %"compiler/typed:Local" %t78, ptr %l7
  %t79 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t80 = load i32, ptr %t79, !range !{i32 0, i32 7}
  %t82 = trunc i64 1 to i32
  %t83 = icmp eq i32 %t80, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb27
bb26:
  %t87 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  %t90 = icmp eq i32 %t88, 0
  store i1 %t90, ptr %l54, !tbaa !21
  br label %bb27
bb27:
  %t92 = load i1, ptr %l54, !tbaa !21
  br i1 %t92, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb29:
  br label %bb30
bb30:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Body", ptr %t93, i32 0, i32 3
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 1
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  %t103 = shl i64 %t101, 32
  %t104 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 1
  %t105 = getelementptr %"compiler/source:Span", ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105, !tbaa !23
  %t108 = sext i32 %t106 to i64
  %t111 = or i64 %t103, %t108
  %t114 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t96, i64 %t111)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114, ptr %l65
  br label %bb31
bb31:
  %t115 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l65
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t115, ptr %l8
  %t116 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t117 = load i32, ptr %t116, !tbaa !23
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t121 = icmp ne i32 %t117, %t118
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t125 = load i32, ptr %t124, !tbaa !23
  %t128 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %t123, i32 %t125)
  store i1 %t128, ptr %l72
  br label %bb34
bb33:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb35
bb34:
  %t129 = load i1, ptr %l72, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l69, !tbaa !21
  br label %bb35
bb35:
  %t132 = load i1, ptr %l69, !tbaa !21
  store i1 %t132, ptr %l9, !tbaa !21
  %t133 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t136 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t133)
  store i1 %t136, ptr %l76
  br label %bb36
bb36:
  %t137 = load i1, ptr %l76, !tbaa !21
  br i1 %t137, label %bb37, label %bb38
bb37:
  %t138 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t141 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t138)
  %t142 = extractvalue { i32, i1 } %t141, 1
  %t143 = extractvalue { i32, i1 } %t141, 0
  store i32 %t143, ptr %l82
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb40, label %ok.145, !prof !99
ok.145:
  store i1 %t142, ptr %l81
  br label %bb39
bb38:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb43
bb39:
  %t146 = load i1, ptr %l81, !tbaa !21
  store i1 %t146, ptr %l78, !tbaa !21
  br label %bb42
bb40:
  br label %bb41
bb41:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb42
bb42:
  %t147 = load i1, ptr %l78, !tbaa !21
  %t148 = xor i1 %t147, true
  store i1 %t148, ptr %l77, !tbaa !21
  br label %bb43
bb43:
  %t150 = load i1, ptr %l77, !tbaa !21
  br i1 %t150, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb45:
  br label %bb46
bb46:
  %t151 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t152 = load i1, ptr %l9, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t151, i1 %t152)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb48:
  %t156 = load i64, ptr %l6, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l6, !tbaa !24
  br label %bb19
bb49:
  br label %bb50
bb50:
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l3, !tbaa !24
  br label %bb10
bb51:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/names:Resolver", ptr %t170, i32 0, i32 18
  store ptr %t172, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t174 = load i64, ptr %l11, !tbaa !24
  store i64 %t174, ptr %l95, !tbaa !24
  %t175 = load ptr, ptr %l10, !tbaa !29
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l97
  br label %bb53
bb53:
  %t178 = load i64, ptr %l95, !tbaa !24
  %t179 = load i64, ptr %l97, !tbaa !24
  %t180 = icmp slt i64 %t178, %t179
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s13)
  br label %bb76
bb55:
  br label %bb56
bb56:
  %t184 = load ptr, ptr %l10, !tbaa !29
  %t185 = load i64, ptr %l11, !tbaa !24
  %t188 = call %"compiler/names:Unread" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eAt_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t184, i64 %t185)
  store %"compiler/names:Unread" %t188, ptr %l102
  br label %bb57
bb57:
  %t189 = load %"compiler/names:Unread", ptr %l102
  store %"compiler/names:Unread" %t189, ptr %l12
  %t190 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 0
  %t191 = load i64, ptr %t190, !tbaa !24
  %t192 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t193 = getelementptr %"compiler/source:Span", ptr %t192, i32 0, i32 0
  %t194 = load i32, ptr %t193, !tbaa !23
  %t196 = sext i32 %t194 to i64
  %t197 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t198 = getelementptr %"compiler/source:Span", ptr %t197, i32 0, i32 1
  %t199 = load i32, ptr %t198, !tbaa !23
  %t201 = sext i32 %t199 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [3 x i64] }, ptr %t202, i32 0, i32 0
  store i64 3, ptr %t203
  %t205 = insertvalue { i64, i64, i64 } undef, i64 %t191, 0
  %t207 = insertvalue { i64, i64, i64 } %t205, i64 %t196, 1
  %t209 = insertvalue { i64, i64, i64 } %t207, i64 %t201, 2
  %t210 = getelementptr { i64, [3 x i64] }, ptr %t202, i32 0, i32 1
  store { i64, i64, i64 } %t209, ptr %t210
  %t211 = load { i64, [3 x i64] }, ptr %t202
  store { i64, [3 x i64] } %t211, ptr %l13
  %t213 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 3
  %t214 = load i1, ptr %t213, !tbaa !21
  br i1 %t214, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s14
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/load:Loader", ptr %t222, i32 0, i32 4
  %t225 = load ptr, ptr %t224, !tbaa !29
  store ptr %t225, ptr %l113, !tbaa !29
  %t226 = load { i64, [3 x i64] }, ptr %l13
  store { i64, [3 x i64] } %t226, ptr %l114
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 2
  %t229 = load i32, ptr %t228, !tbaa !23
  %t232 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s14, ptr %t227, i32 %t229)
  store { i64, ptr } %t232, ptr %l117
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t233 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 0
  %t235 = extractvalue { i64, ptr } %t233, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  %t241 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLocalUnusedBare(ptr %s14, ptr %v0, { i64, ptr } %t239)
  store %"compiler/diagmsg:Msg" %t241, ptr %l119
  br label %bb61
bb61:
  %t242 = load ptr, ptr %l113, !tbaa !29
  %t243 = load { i64, [3 x i64] }, ptr %l114
  %t244 = load %"compiler/diagmsg:Msg", ptr %l119
  %t245 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorAlone(ptr %v0, ptr %v0, ptr %t242, { i64, [3 x i64] } %t243, %"compiler/diagmsg:Msg" %t244)
  store i64 %t245, ptr %l120
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb63:
  %t246 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 0
  %t247 = load i64, ptr %t246, !tbaa !24
  %t248 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t249 = getelementptr %"compiler/source:Span", ptr %t248, i32 0, i32 0
  %t250 = load i32, ptr %t249, !tbaa !23
  %t252 = sext i32 %t250 to i64
  %t254 = shl i64 %t252, 32
  %t255 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t256 = getelementptr %"compiler/source:Span", ptr %t255, i32 0, i32 1
  %t257 = load i32, ptr %t256, !tbaa !23
  %t259 = sext i32 %t257 to i64
  %t262 = or i64 %t254, %t259
  %t265 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s13, i64 %t247, i64 %t262)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t265, ptr %l128
  br label %bb64
bb64:
  %t266 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l128
  %t270 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t266)
  %t271 = extractvalue { i32, i1 } %t270, 1
  %t272 = extractvalue { i32, i1 } %t270, 0
  store i32 %t272, ptr %l133
  %t273 = icmp ne i32 %t272, 0
  br i1 %t273, label %bb66, label %ok.274, !prof !99
ok.274:
  store i1 %t271, ptr %l132
  br label %bb65
bb65:
  %t275 = load i1, ptr %l132, !tbaa !21
  store i1 %t275, ptr %l129, !tbaa !21
  br label %bb68
bb66:
  br label %bb67
bb67:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb68
bb68:
  %t276 = load i1, ptr %l129, !tbaa !21
  %t277 = xor i1 %t276, true
  br i1 %t277, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb70:
  br label %bb71
bb71:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/load:Loader", ptr %t285, i32 0, i32 4
  %t288 = load ptr, ptr %t287, !tbaa !29
  store ptr %t288, ptr %l138, !tbaa !29
  %t289 = load { i64, [3 x i64] }, ptr %l13
  store { i64, [3 x i64] } %t289, ptr %l139
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 2
  %t292 = load i32, ptr %t291, !tbaa !23
  %t295 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s13, ptr %t290, i32 %t292)
  store { i64, ptr } %t295, ptr %l142
  br label %bb72
bb72:
  %t296 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 0
  %t298 = extractvalue { i64, ptr } %t296, 1
  %t299 = mul i64 %t297, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t299)
  call void @llvm.memcpy.p0.p0.i64(ptr %t300, ptr %t298, i64 %t299, i1 false)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  %t304 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLocalUnused(ptr %s13, ptr %v0, { i64, ptr } %t302)
  store %"compiler/diagmsg:Msg" %t304, ptr %l144
  br label %bb73
bb73:
  %t305 = load ptr, ptr %l138, !tbaa !29
  %t306 = load { i64, [3 x i64] }, ptr %l139
  %t307 = load %"compiler/diagmsg:Msg", ptr %l144
  %t308 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorAlone(ptr %v0, ptr %v0, ptr %t305, { i64, [3 x i64] } %t306, %"compiler/diagmsg:Msg" %t307)
  store i64 %t308, ptr %l145
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb75:
  %t309 = load i64, ptr %l11, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l11, !tbaa !24
  br label %bb52
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l24 = alloca i1
  %l37 = alloca { i64, ptr }
  %l43 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Param", ptr %t24, i32 0, i32 2
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  store i1 %t33, ptr %l24
  br label %bb5
bb5:
  %t34 = load i1, ptr %l24, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Sig", ptr %t42, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  br label %bb24
bb13:
  br label %bb14
bb14:
  %t59 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t59, ptr %l37, !tbaa !27
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  store ptr %t65, ptr %l9, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t72 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorResult(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  store i1 %t72, ptr %l43
  br label %bb15
bb15:
  %t73 = load i1, ptr %l43, !tbaa !21
  br i1 %t73, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb19
bb17:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l9, !tbaa !29
  %t79 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  store i1 %t79, ptr %l48
  br label %bb18
bb18:
  %t80 = load i1, ptr %l48, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l44, !tbaa !21
  br label %bb19
bb19:
  %t83 = load i1, ptr %l44, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb11
bb24:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicesByAxes(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l28 = alloca i32
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca i32
  %l64 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca i64
  %l74 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i32
  %l81 = alloca ptr
  %l84 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l16, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %t17)
  store i32 %t20, ptr %l20
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = load i32, ptr %l20, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l21
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load i32, ptr %l21, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l22
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp slt i64 %t30, 2
  br i1 %t32, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaxisType(ptr %v0, ptr %t35)
  store i32 %t37, ptr %l28
  br label %bb7
bb7:
  %t38 = load i32, ptr %l28, !tbaa !23
  store i32 %t38, ptr %l3, !tbaa !23
  store i64 1, ptr %l4, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp sgt i64 %t43, %t44
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb13
bb10:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l37, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb12
bb12:
  %t69 = load i64, ptr %l37, !tbaa !24
  store i64 %t69, ptr %l34, !tbaa !24
  br label %bb13
bb13:
  %t70 = load i64, ptr %l34, !tbaa !24
  store i64 %t70, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb15, label %bb16
bb15:
  br label %bb33
bb16:
  br label %bb17
bb17:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l9, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  %t95 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t95, ptr %l58, !tbaa !27
  %t96 = load i64, ptr %l9, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i32, ptr %t99, i64 %t96
  %t101 = load i32, ptr %t100, !tbaa !33
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnspread(ptr %v0, ptr %t94, i32 %t101)
  store i32 %t104, ptr %l61
  br label %bb18
bb18:
  %t105 = load i32, ptr %l61, !tbaa !23
  store i32 %t105, ptr %l10, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  store ptr %t111, ptr %l64, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t116 = load i64, ptr %l1, !tbaa !24
  %t119 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t115, i64 %t116)
  store i32 %t119, ptr %l68
  br label %bb19
bb19:
  %t120 = load ptr, ptr %l64, !tbaa !29
  %t121 = load i32, ptr %l68, !tbaa !23
  %t122 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSpreadAt(ptr %v0, ptr %t120, i32 %t121)
  store i64 %t122, ptr %l69
  br label %bb20
bb20:
  %t123 = load i64, ptr %l9, !tbaa !24
  %t124 = load i64, ptr %l69, !tbaa !24
  %t126 = icmp eq i64 %t124, %t123
  br i1 %t126, label %bb21, label %bb22
bb21:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  store ptr %t133, ptr %l74, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l10, !tbaa !23
  %t138 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t134, i32 %t135)
  store i32 %t138, ptr %l77
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t139 = load ptr, ptr %l74, !tbaa !29
  %t140 = load i32, ptr %l77, !tbaa !23
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t141, ptr %l78
  br label %bb24
bb24:
  %t142 = load i32, ptr %l78, !tbaa !23
  store i32 %t142, ptr %l10, !tbaa !23
  br label %bb25
bb25:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  store ptr %t148, ptr %l81, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  store ptr %t154, ptr %l84, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l10, !tbaa !23
  %t159 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l87
  br label %bb26
bb26:
  %t160 = load ptr, ptr %l84, !tbaa !29
  %t161 = load i32, ptr %l87, !tbaa !23
  %t162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t160, i32 %t161)
  store i32 %t162, ptr %l88
  br label %bb27
bb27:
  %t163 = load i32, ptr %l3, !tbaa !23
  %t164 = load ptr, ptr %l81, !tbaa !29
  %t165 = load i32, ptr %l88, !tbaa !23
  %t167 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t164, i32 %t165, i32 %t163)
  store i1 %t167, ptr %l90
  br label %bb28
bb28:
  %t168 = load i1, ptr %l90, !tbaa !21
  %t169 = xor i1 %t168, true
  br i1 %t169, label %bb29, label %bb30
bb29:
  store i1 false, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l8, !tbaa !24
  br label %bb14
bb33:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i64
  %l8 = alloca { i64, ptr }
  %l15 = alloca i64
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca { i64, [3 x i64] }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t4, i32 %t5)
  store { i64, ptr } %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  %t12 = icmp eq i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %t17, i32 %t18, i64 %a2)
  store i64 %t23, ptr %l15
  br label %bb5
bb5:
  %t24 = load i64, ptr %l15, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 173
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %t27, i64 %t28)
  store i1 %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load i1, ptr %l19, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 173
  store ptr %t37, ptr %l22, !tbaa !29
  %t38 = load i64, ptr %l4, !tbaa !24
  store i64 %t38, ptr %l23, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t39, %"compiler/source:Span" %a3)
  store { i64, [3 x i64] } %t43, ptr %l26
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = load { i64, [3 x i64] }, ptr %l26
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t44, i64 %t45, { i64, [3 x i64] } %t46)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estdTypeModule(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l36 = alloca i1
  %l37 = alloca i1
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l8, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t11)
  store i1 %t13, ptr %l10
  br label %bb3
bb3:
  %t14 = load i1, ptr %l10, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l7, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l14, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l15, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l14, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t32, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = call { i64, ptr } @compiler_2fcheck_2elowerAll(ptr %v1, ptr %s0, { i64, ptr } %t34)
  store { i64, ptr } %t36, ptr %l17
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  %t40 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = extractvalue { i64, ptr } %t47, 0
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t56 = extractvalue { i64, ptr } %t48, 1
  %t57 = extractvalue { i64, ptr } %t48, 0
  %t58 = add i64 %t54, %t57
  %t59 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t50, i64 %t51)
  %t63 = getelementptr i8, ptr %t62, i64 %t51
  call void @olang_textcopy(ptr %t63, ptr %t52, i64 %t53)
  %t64 = getelementptr i8, ptr %t63, i64 %t53
  call void @olang_textcopy(ptr %t64, ptr %t56, i64 %t57)
  %t65 = getelementptr i8, ptr %t64, i64 %t57
  call void @olang_textcopy(ptr %t65, ptr %t59, i64 %t60)
  %t66 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t62, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t74)
  %t77 = extractvalue { i32, { i64, ptr } } %t76, 1
  %t78 = extractvalue { i32, { i64, ptr } } %t76, 0
  store i32 %t78, ptr %l27
  %t79 = icmp ne i32 %t78, 0
  br i1 %t79, label %bb10, label %ok.80, !prof !99
ok.80:
  store { i64, ptr } %t77, ptr %l26
  br label %bb9
bb9:
  %t81 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t81, ptr %l18, !tbaa !27
  br label %bb14
bb10:
  %t82 = load i32, ptr %l27, !tbaa !23
  %t83 = ashr i32 %t82, 16
  %t85 = icmp eq i32 %t83, 1
  br i1 %t85, label %bb11, label %bb12
bb11:
  call void @__olang_errpay_pop()
  br label %bb12
bb12:
  br label %bb13
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l18, !tbaa !27
  br label %bb14
bb14:
  %t87 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t87, ptr %l3, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t91 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t94 = extractvalue { i64, ptr } %t90, 1
  %t95 = extractvalue { i64, ptr } %t90, 0
  %t96 = add i64 %t92, %t95
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t91, i64 %t92)
  %t101 = getelementptr i8, ptr %t100, i64 %t92
  call void @olang_textcopy(ptr %t101, ptr %t94, i64 %t95)
  %t102 = getelementptr i8, ptr %t101, i64 %t95
  call void @olang_textcopy(ptr %t102, ptr %t97, i64 %t98)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t100, 1
  %t107 = extractvalue { i64, ptr } %t104, 0
  %t108 = extractvalue { i64, ptr } %t104, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  %t115 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t88, { i64, ptr } %t112)
  store i1 %t115, ptr %l36
  br label %bb15
bb15:
  %t116 = load i1, ptr %l36, !tbaa !21
  br i1 %t116, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb19
bb17:
  %t117 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t120 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t123 = extractvalue { i64, ptr } %t119, 1
  %t124 = extractvalue { i64, ptr } %t119, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t120, i64 %t121)
  %t130 = getelementptr i8, ptr %t129, i64 %t121
  call void @olang_textcopy(ptr %t130, ptr %t123, i64 %t124)
  %t131 = getelementptr i8, ptr %t130, i64 %t124
  call void @olang_textcopy(ptr %t131, ptr %t126, i64 %t127)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t129, 1
  %t136 = extractvalue { i64, ptr } %t133, 0
  %t137 = extractvalue { i64, ptr } %t133, 1
  %t138 = mul i64 %t136, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t144 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t117, { i64, ptr } %t141)
  store i1 %t144, ptr %l44
  br label %bb18
bb18:
  %t145 = load i1, ptr %l44, !tbaa !21
  store i1 %t145, ptr %l37, !tbaa !21
  br label %bb19
bb19:
  %t146 = load i1, ptr %l37, !tbaa !21
  br i1 %t146, label %bb20, label %bb21
bb20:
  %t147 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = extractvalue { i64, ptr } %t147, 0
  %t151 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t149, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l45, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t155, ptr %l45, !tbaa !27
  br label %bb22
bb22:
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  store i64 %t158, ptr %l50, !tbaa !24
  %t159 = load i64, ptr %l50, !tbaa !24
  %t160 = mul i64 %t159, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t160)
  %t162 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, ptr } %t163, ptr %l51, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = load i64, ptr %l50, !tbaa !24
  %t169 = mul i64 %t168, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t165, ptr %t167, i64 %t169, i1 false)
  %t170 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t170, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t171 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t171, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, ptr %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, [3 x i64] }
  %l13 = alloca i32
  %l16 = alloca i64
  %l19 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca i32
  %l41 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l55 = alloca i1
  %l60 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l75 = alloca { i64, [3 x i64] }
  %l83 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i1
  %l106 = alloca ptr
  %l109 = alloca i1
  %l111 = alloca i1
  %l115 = alloca i64
  %l117 = alloca ptr
  %l119 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l123 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca %"compiler/source:Span"
  %l127 = alloca ptr
  %l131 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca ptr
  %l140 = alloca ptr
  %t180 = alloca { i64, [4 x i64] }, align 8
  %t239 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i32, ptr %l13, !tbaa !23
  store i32 %t4, ptr %l7, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 10
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load i64, ptr %l16, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l7, !tbaa !23
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l19
  br label %bb3
bb3:
  %t16 = load i1, ptr %l19, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l7, !tbaa !23
  %t28 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l26
  br label %bb6
bb5:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb7
bb6:
  %t29 = load i1, ptr %l26, !tbaa !21
  store i1 %t29, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 10
  %t34 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = load i32, ptr %l7, !tbaa !23
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t37, ptr %t38, i32 %t40)
  store ptr %t44, ptr %l34
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l34, !tbaa !29
  store ptr %t45, ptr %l9, !tbaa !29
  %t46 = load ptr, ptr %l9, !tbaa !29
  %t49 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t46)
  store i32 %t49, ptr %l37
  br label %bb13
bb13:
  %t50 = load i32, ptr %l37, !tbaa !23
  store i32 %t50, ptr %l10, !tbaa !23
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l7, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l46
  br label %bb16
bb15:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb17
bb16:
  %t67 = load i1, ptr %l46, !tbaa !21
  store i1 %t67, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t68 = load i1, ptr %l41, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t69 = load i32, ptr %l10, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  store i1 %t73, ptr %l47, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l47, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = load i32, ptr %l10, !tbaa !23
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t80 = icmp ne i32 %t76, %t77
  store i1 %t80, ptr %l51, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t82 = load i1, ptr %l51, !tbaa !21
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l10, !tbaa !23
  %t92 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t88, i32 %t89)
  store i1 %t92, ptr %l60
  br label %bb26
bb25:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb27
bb26:
  %t93 = load i1, ptr %l60, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l55, !tbaa !21
  br label %bb27
bb27:
  %t96 = load i1, ptr %l55, !tbaa !21
  br i1 %t96, label %bb28, label %bb29
bb28:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t97)
  store ptr %t99, ptr %l63
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t100 = load ptr, ptr %l63, !tbaa !29
  store ptr %t100, ptr %l64, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t105 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowPath(ptr %v0, ptr %v3, ptr %v0, ptr %t101, ptr %t102)
  store { i64, ptr } %t105, ptr %l67
  br label %bb31
bb31:
  %t106 = load ptr, ptr %l64, !tbaa !29
  %t107 = getelementptr %"compiler/check:frame", ptr %t106, i32 0, i32 48
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l68, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t110 = load ptr, ptr %l64, !tbaa !29
  %t111 = getelementptr %"compiler/check:frame", ptr %t110, i32 0, i32 48
  store { i64, ptr } %t109, ptr %t111, !tbaa !27
  %t112 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e48
  br i1 %t112, label %bb32, label %bb33
bb32:
  %t114 = load { i64, ptr }, ptr %l68
  %t115 = extractvalue { i64, ptr } %t114, 1
  call void @__olang_region_release(ptr %t115)
  store { i64, ptr } zeroinitializer, ptr %l68
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 17
  %t119 = load { i64, [3 x i64] }, ptr %t118
  store { i64, [3 x i64] } %t119, ptr %l11
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l72, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t126 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %t122, ptr %t123)
  store { i64, [3 x i64] } %t126, ptr %l75
  br label %bb35
bb35:
  %t127 = load { i64, [3 x i64] }, ptr %l75
  %t128 = load ptr, ptr %l72, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 17
  store { i64, [3 x i64] } %t127, ptr %t129
  %t130 = load i32, ptr %l7, !tbaa !23
  %t131 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t134 = icmp ne i32 %t130, %t131
  br i1 %t134, label %bb36, label %bb37
bb36:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l9, !tbaa !29
  %t138 = load i32, ptr %l7, !tbaa !23
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t136, ptr %t137, i32 %t138, %"compiler/source:Span" %a4)
  store ptr %t144, ptr %l83
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t145 = load ptr, ptr %l83, !tbaa !29
  store ptr %t145, ptr %l9, !tbaa !29
  br label %bb39
bb39:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load { i64, [3 x i64] }, ptr %l11
  %t150 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 17
  store { i64, [3 x i64] } %t147, ptr %t150
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 10
  %t154 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eTrun_Haa7c8ccc08c8123d0b87c9688e5d351e(ptr %v0, ptr %t153, i64 %t154)
  br label %bb40
bb40:
  %t157 = load i32, ptr %l7, !tbaa !23
  store i32 %t157, ptr %l89, !tbaa !23
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t158)
  store i32 %t160, ptr %l91
  br label %bb41
bb41:
  %t161 = load i32, ptr %l89, !tbaa !23
  %t162 = load i32, ptr %l91, !tbaa !23
  %t163 = icmp eq i32 %t161, %t162
  br i1 %t163, label %bb42, label %bb43
bb42:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l94, !tbaa !29
  %t166 = load ptr, ptr %l9, !tbaa !29
  %t169 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t166)
  store i32 %t169, ptr %l97
  br label %bb44
bb43:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb46
bb44:
  %t170 = load ptr, ptr %l94, !tbaa !29
  %t171 = load i32, ptr %l97, !tbaa !23
  %t172 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t172, ptr %l98
  br label %bb45
bb45:
  %t173 = load i1, ptr %l98, !tbaa !21
  store i1 %t173, ptr %l93, !tbaa !21
  br label %bb46
bb46:
  %t174 = load i1, ptr %l93, !tbaa !21
  br i1 %t174, label %bb47, label %bb48
bb47:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l1
  %t177 = load %"compiler/source:Span", ptr %l1
  %t178 = load i32, ptr %l7, !tbaa !23
  %t179 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t180
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 0
  store i64 2, ptr %t181
  %t183 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t177, 0
  %t185 = insertvalue { %"compiler/source:Span", i32, ptr } %t183, i32 %t178, 1
  %t187 = insertvalue { %"compiler/source:Span", i32, ptr } %t185, ptr %t179, 2
  %t188 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t187, ptr %t188
  %t189 = load { i64, [4 x i64] }, ptr %t180
  %t191 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t189, ptr %t191
  %t195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t175, %"compiler/source:Span" %t176, ptr %t191)
  store ptr %t195, ptr %l106
  br label %bb49
bb48:
  br label %bb50
bb49:
  %t196 = load ptr, ptr %l106, !tbaa !29
  store ptr %t196, ptr %l9, !tbaa !29
  br label %bb50
bb50:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr %l7, !tbaa !23
  %t201 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t197, i32 %t198)
  store i1 %t201, ptr %l109
  br label %bb51
bb51:
  %t202 = load i1, ptr %l109, !tbaa !21
  %t203 = xor i1 %t202, true
  br i1 %t203, label %bb52, label %bb53
bb52:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l2, !tbaa !29
  %t210 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %t205, ptr %t206)
  store i64 %t210, ptr %l115
  br label %bb54
bb53:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb55
bb54:
  %t211 = load i64, ptr %l115, !tbaa !24
  %t212 = icmp slt i64 %t211, 0
  store i1 %t212, ptr %l111, !tbaa !21
  br label %bb55
bb55:
  %t214 = load i1, ptr %l111, !tbaa !21
  br i1 %t214, label %bb56, label %bb57
bb56:
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l117, !tbaa !29
  %t216 = load ptr, ptr %l9, !tbaa !29
  store ptr %t216, ptr %l119, !tbaa !29
  %t218 = load ptr, ptr %l3, !tbaa !29
  %t220 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t218)
  store %"compiler/source:Span" %t220, ptr %l121
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t221 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t222 = load ptr, ptr %l117, !tbaa !29
  %t223 = load ptr, ptr %l119, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l121
  %t226 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t222, ptr %t223, %"compiler/source:Span" %t224, i64 %t221)
  store i1 %t226, ptr %l123
  br label %bb59
bb59:
  br label %bb60
bb60:
  br i1 %a6, label %bb61, label %bb62
bb61:
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l125, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t230, ptr %l126
  %t231 = load ptr, ptr %l2, !tbaa !29
  store ptr %t231, ptr %l127, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load ptr, ptr %l2, !tbaa !29
  %t234 = load ptr, ptr %l9, !tbaa !29
  %t238 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreCopy(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %t232, ptr %t233, ptr %t234)
  store ptr %t238, ptr %l131
  br label %bb63
bb62:
  br label %bb65
bb63:
  store { i64, [3 x i64] } zeroinitializer, ptr %t239
  %t240 = getelementptr { i64, [3 x i64] }, ptr %t239, i32 0, i32 0
  store i64 1, ptr %t240
  %t241 = load %"compiler/source:Span", ptr %l126
  %t242 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t241, 0
  %t243 = load ptr, ptr %l127, !tbaa !29
  %t244 = insertvalue { %"compiler/source:Span", ptr, ptr } %t242, ptr %t243, 1
  %t245 = load ptr, ptr %l131, !tbaa !29
  %t246 = insertvalue { %"compiler/source:Span", ptr, ptr } %t244, ptr %t245, 2
  %t247 = getelementptr { i64, [3 x i64] }, ptr %t239, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t246, ptr %t247
  %t248 = load { i64, [3 x i64] }, ptr %t239
  %t250 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t248, ptr %t250
  %t251 = load ptr, ptr %l125, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t251, ptr %t250)
  br label %bb64
bb64:
  br label %ret
bb65:
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l134, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t254, ptr %l135
  %t255 = load ptr, ptr %l2, !tbaa !29
  store ptr %t255, ptr %l136, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load ptr, ptr %l2, !tbaa !29
  %t258 = load ptr, ptr %l9, !tbaa !29
  %t262 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreCopy(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %t256, ptr %t257, ptr %t258)
  store ptr %t262, ptr %l140
  br label %bb66
bb66:
  %t263 = load ptr, ptr %l134, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l135
  %t265 = load ptr, ptr %l136, !tbaa !29
  %t266 = load ptr, ptr %l140, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreOver(ptr %v0, ptr %v1, ptr %v0, ptr %t263, %"compiler/source:Span" %t264, ptr %t265, ptr %t266)
  br label %bb67
bb67:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t4, i32 %a1)
  store ptr %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l8, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TypeDecl", ptr %t14, i32 0, i32 3
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  store i1 %t19, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store ptr null, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TypeDecl", ptr %t23, i32 0, i32 3
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 5}
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l19, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr { i64, [6 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { ptr }, ptr %t39, i32 0, i32 0
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t43 = load ptr, ptr %l4, !tbaa !29
  store ptr %t43, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store ptr null, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_feabd87b4a742d50_a08e759c84965044)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestTarget(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca %"compiler/names:Entry"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca %"compiler/names:Entry"
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca %"compiler/names:Entry"
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca %"compiler/names:Entry"
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l60 = alloca %"std/prelude/text:StringBuilder"
  %l69 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l94 = alloca i1
  %l95 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l99 = alloca { i64, ptr }
  %l101 = alloca %"compiler/diagmsg:Msg"
  %l102 = alloca i64
  %l112 = alloca ptr
  %l118 = alloca i64
  %l120 = alloca i64
  %l125 = alloca %"compiler/names:Entry"
  %l127 = alloca { i64, ptr }
  %l132 = alloca i1
  %l142 = alloca i64
  %l146 = alloca i64
  %l149 = alloca i64
  %l175 = alloca ptr
  %l178 = alloca i64
  %l180 = alloca i64
  %l185 = alloca %"compiler/names:Entry"
  %l187 = alloca { i64, ptr }
  %l190 = alloca i1
  %l193 = alloca i1
  %l196 = alloca ptr
  %l198 = alloca %"compiler/source:Span"
  %l200 = alloca %"compiler/diagmsg:Msg"
  %l201 = alloca i64
  %l214 = alloca i64
  %l218 = alloca i64
  %l221 = alloca i64
  %l242 = alloca ptr
  %l244 = alloca i1
  %l245 = alloca i1
  %l248 = alloca { i64, ptr }
  %l251 = alloca i1
  %l257 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l263 = alloca i1
  %l267 = alloca i64
  %l274 = alloca i1
  %l277 = alloca { i64, ptr }
  %l282 = alloca ptr
  %l285 = alloca ptr
  %l289 = alloca i32
  %l290 = alloca i32
  %l291 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l298 = alloca i32
  %l301 = alloca i1
  %l302 = alloca i1
  %l305 = alloca ptr
  %l310 = alloca i32
  %l311 = alloca i32
  %l312 = alloca { i64, ptr }
  %l317 = alloca i1
  %l320 = alloca i1
  %l321 = alloca i1
  %l327 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l330 = alloca { i64, ptr }
  %l332 = alloca { i64, ptr }
  %l333 = alloca i1
  %l338 = alloca i64
  %l346 = alloca i64
  %l348 = alloca i64
  %l353 = alloca %"compiler/names:Entry"
  %l355 = alloca { i64, ptr }
  %l358 = alloca i1
  %l364 = alloca ptr
  %l366 = alloca %"compiler/source:Span"
  %l368 = alloca %"compiler/diagmsg:Msg"
  %l369 = alloca i64
  %l372 = alloca %"compiler/msgs:Nearest"
  %l376 = alloca i64
  %l378 = alloca i64
  %l383 = alloca %"compiler/names:Entry"
  %l386 = alloca i1
  %l389 = alloca i1
  %l392 = alloca { i64, ptr }
  %l394 = alloca { i64, ptr }
  %l395 = alloca i1
  %l397 = alloca ptr
  %l400 = alloca { i64, ptr }
  %l407 = alloca i64
  %l411 = alloca i64
  %l414 = alloca i64
  %l435 = alloca ptr
  %l437 = alloca i1
  %l438 = alloca i1
  %l442 = alloca i64
  %l445 = alloca ptr
  %l446 = alloca i64
  %l453 = alloca { i64, ptr }
  %l457 = alloca { i64, ptr }
  %l463 = alloca i1
  %l467 = alloca i64
  %l472 = alloca ptr
  %l475 = alloca ptr
  %l479 = alloca i32
  %l480 = alloca i32
  %l481 = alloca { i64, ptr }
  %l485 = alloca ptr
  %l487 = alloca { i64, ptr }
  %l489 = alloca i32
  %l490 = alloca i1
  %l491 = alloca ptr
  %l492 = alloca i64
  %l494 = alloca ptr
  %l497 = alloca ptr
  %l500 = alloca ptr
  %l502 = alloca { i64, ptr }
  %l504 = alloca i32
  %l505 = alloca i32
  %l506 = alloca i32
  %l507 = alloca { i64, ptr }
  %l511 = alloca { i64, ptr }
  %l519 = alloca { i64, ptr }
  %l521 = alloca i1
  %l523 = alloca ptr
  %l524 = alloca i64
  %l531 = alloca { i64, ptr }
  %l535 = alloca { i64, ptr }
  %l544 = alloca ptr
  %l546 = alloca %"compiler/source:Span"
  %l550 = alloca %"compiler/diagmsg:Msg"
  %l551 = alloca i64
  %l552 = alloca ptr
  %l554 = alloca %"compiler/source:Span"
  %l556 = alloca %"compiler/diagmsg:Msg"
  %l557 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %s63 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t5, i64 -1, i64 %t6, i32 %t7, i32 0)
  store ptr %t11, ptr %l57
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Path", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l4, !tbaa !27
  %t17 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t17, ptr %l60
  br label %bb5
bb5:
  %t18 = load %"std/prelude/text:StringBuilder", ptr %l60
  store %"std/prelude/text:StringBuilder" %t18, ptr %l5
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l8, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t35, ptr %l69, !tbaa !27
  %t36 = load i64, ptr %l7, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 %t36
  %t41 = load i32, ptr %t40, !tbaa !33
  store i32 %t41, ptr %l10, !tbaa !23
  %t45 = icmp sgt i64 %t33, 0
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 46)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  store ptr %l5, ptr %l75, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l10, !tbaa !23
  %t52 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t48, i32 %t49)
  store { i64, ptr } %t52, ptr %l78
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l75, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l78, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t53, { i64, ptr } %t54)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l7, !tbaa !24
  br label %bb6
bb17:
  %t60 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t60, ptr %l82
  br label %bb18
bb18:
  %t61 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t61, ptr %l11, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t62, ptr %l83, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s0, ptr %t63, %"compiler/source:Span" %a2)
  store { i64, ptr } %t67, ptr %l86
  br label %bb19
bb19:
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t70 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = add i64 %t69, %t72
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t77 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = add i64 %t76, %t79
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t68, i64 %t69)
  %t85 = getelementptr i8, ptr %t84, i64 %t69
  call void @olang_textcopy(ptr %t85, ptr %t71, i64 %t72)
  %t86 = getelementptr i8, ptr %t85, i64 %t72
  call void @olang_textcopy(ptr %t86, ptr %t74, i64 %t75)
  %t87 = getelementptr i8, ptr %t86, i64 %t75
  call void @olang_textcopy(ptr %t87, ptr %t78, i64 %t79)
  %t88 = getelementptr i8, ptr %t87, i64 %t79
  call void @olang_textcopy(ptr %t88, ptr %t81, i64 %t82)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t84, 1
  store { i64, ptr } %t90, ptr %l12, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 169
  %t96 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t94)
  store { i64, ptr } %t96, ptr %l90
  br label %bb20
bb20:
  %t97 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t108 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t104, { i64, ptr } %t105)
  store i1 %t108, ptr %l94
  br label %bb21
bb21:
  %t109 = load i1, ptr %l94, !tbaa !21
  br i1 %t109, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l95, !tbaa !29
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/ast:Path", ptr %t111, i32 0, i32 0
  %t114 = load %"compiler/source:Span", ptr %t113
  store %"compiler/source:Span" %t114, ptr %l97
  %t115 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t117 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s7, { i64, ptr } %t115)
  store { i64, ptr } %t117, ptr %l99
  br label %bb24
bb23:
  br label %bb28
bb24:
  %t118 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTestTargetTwice(ptr %s7, ptr %v0, { i64, ptr } %t124)
  store %"compiler/diagmsg:Msg" %t126, ptr %l101
  br label %bb25
bb25:
  %t127 = load ptr, ptr %l95, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l97
  %t129 = load %"compiler/diagmsg:Msg", ptr %l101
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t127, %"compiler/source:Span" %t128, %"compiler/diagmsg:Msg" %t129)
  store i64 %t130, ptr %l102
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s7)
  %t131 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t131)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb28:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 169
  %t136 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t135, { i64, ptr } %t136)
  br label %bb29
bb29:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/names:Resolver", ptr %t145, i32 0, i32 1
  %t148 = load i64, ptr %l1, !tbaa !24
  %t151 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t147, i64 %t148)
  store ptr %t151, ptr %l112
  br label %bb30
bb30:
  %t152 = load ptr, ptr %l112, !tbaa !29
  store ptr %t152, ptr %l13, !tbaa !29
  %t153 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t157 = icmp eq i64 %t155, 1
  br i1 %t157, label %bb31, label %bb32
bb31:
  %t159 = load ptr, ptr %l13, !tbaa !29
  %t161 = getelementptr %"compiler/names:Table", ptr %t159, i32 0, i32 0
  store ptr %t161, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb33
bb32:
  %t163 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t167 = icmp eq i64 %t165, 2
  br i1 %t167, label %bb88, label %bb89
bb33:
  %t169 = load i64, ptr %l15, !tbaa !24
  store i64 %t169, ptr %l118, !tbaa !24
  %t170 = load ptr, ptr %l14, !tbaa !29
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t170)
  store i64 %t172, ptr %l120
  br label %bb34
bb34:
  %t173 = load i64, ptr %l118, !tbaa !24
  %t174 = load i64, ptr %l120, !tbaa !24
  %t175 = icmp slt i64 %t173, %t174
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb35, label %bb36
bb35:
  br label %bb50
bb36:
  br label %bb37
bb37:
  %t179 = load ptr, ptr %l14, !tbaa !29
  %t180 = load i64, ptr %l15, !tbaa !24
  %t183 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t179, i64 %t180)
  store %"compiler/names:Entry" %t183, ptr %l125
  br label %bb38
bb38:
  %t184 = load %"compiler/names:Entry", ptr %l125
  store %"compiler/names:Entry" %t184, ptr %l16
  %t185 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 0
  %t186 = load i32, ptr %t185, !tbaa !23
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t187, ptr %l127, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i32, ptr %t189, i64 0
  %t191 = load i32, ptr %t190, !tbaa !33
  %t194 = icmp ne i32 %t186, %t191
  br i1 %t194, label %bb39, label %bb40
bb39:
  br label %bb49
bb40:
  br label %bb41
bb41:
  %t196 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 2
  %t197 = load i32, ptr %t196, !range !{i32 0, i32 9}
  %t199 = trunc i64 3 to i32
  %t200 = icmp eq i32 %t197, %t199
  br i1 %t200, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l132, !tbaa !21
  br label %bb44
bb43:
  %t202 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 2
  %t203 = load i32, ptr %t202, !range !{i32 0, i32 9}
  %t205 = trunc i64 4 to i32
  %t206 = icmp eq i32 %t203, %t205
  store i1 %t206, ptr %l132, !tbaa !21
  br label %bb44
bb44:
  %t208 = load i1, ptr %l132, !tbaa !21
  br i1 %t208, label %bb45, label %bb46
bb45:
  %t209 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t209)
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb48:
  br label %bb49
bb49:
  %t211 = load i64, ptr %l15, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l15, !tbaa !24
  br label %bb33
bb50:
  store i64 0, ptr %l17, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/check:Checker", ptr %t215, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = getelementptr %"compiler/generic:Program", ptr %t218, i32 0, i32 0
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = getelementptr %"compiler/load:Loader", ptr %t221, i32 0, i32 10
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t223)
  store i64 %t225, ptr %l142
  br label %bb51
bb51:
  %t226 = load i64, ptr %l142, !tbaa !24
  store i64 %t226, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t227 = load i64, ptr %l18, !tbaa !24
  %t228 = load i64, ptr %l17, !tbaa !24
  %t231 = icmp sgt i64 %t227, %t228
  br i1 %t231, label %bb52, label %bb53
bb52:
  %t233 = load i64, ptr %l19, !tbaa !24
  %t235 = icmp sgt i64 %t233, 0
  br i1 %t235, label %bb54, label %bb55
bb53:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb57
bb54:
  %t237 = load i64, ptr %l18, !tbaa !24
  %t238 = load i64, ptr %l17, !tbaa !24
  %t241 = sub i64 %t237, %t238
  %t242 = load i64, ptr %l19, !tbaa !24
  %t245 = add i64 %t241, %t242
  %t247 = sub i64 %t245, 1
  %t248 = load i64, ptr %l19, !tbaa !24
  %t251 = sdiv i64 %t247, %t248
  store i64 %t251, ptr %l149, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb56
bb56:
  %t253 = load i64, ptr %l149, !tbaa !24
  store i64 %t253, ptr %l146, !tbaa !24
  br label %bb57
bb57:
  %t254 = load i64, ptr %l146, !tbaa !24
  store i64 %t254, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb58
bb58:
  %t255 = load i64, ptr %l21, !tbaa !24
  %t256 = load i64, ptr %l20, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb59, label %bb60
bb59:
  br label %bb87
bb60:
  br label %bb61
bb61:
  %t263 = load i64, ptr %l17, !tbaa !24
  %t264 = load i64, ptr %l21, !tbaa !24
  %t265 = load i64, ptr %l19, !tbaa !24
  %t268 = mul i64 %t264, %t265
  %t271 = add i64 %t263, %t268
  store i64 %t271, ptr %l22, !tbaa !24
  %t273 = load i64, ptr %l22, !tbaa !24
  %t274 = load i64, ptr %l1, !tbaa !24
  %t277 = icmp eq i64 %t273, %t274
  br i1 %t277, label %bb62, label %bb63
bb62:
  br label %bb86
bb63:
  br label %bb64
bb64:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/names:Resolver", ptr %t285, i32 0, i32 1
  %t288 = load i64, ptr %l22, !tbaa !24
  %t291 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t287, i64 %t288)
  store ptr %t291, ptr %l175
  br label %bb65
bb65:
  %t292 = load ptr, ptr %l175, !tbaa !29
  %t294 = getelementptr %"compiler/names:Table", ptr %t292, i32 0, i32 0
  store ptr %t294, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb66
bb66:
  %t296 = load i64, ptr %l24, !tbaa !24
  store i64 %t296, ptr %l178, !tbaa !24
  %t297 = load ptr, ptr %l23, !tbaa !29
  %t299 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t297)
  store i64 %t299, ptr %l180
  br label %bb67
bb67:
  %t300 = load i64, ptr %l178, !tbaa !24
  %t301 = load i64, ptr %l180, !tbaa !24
  %t302 = icmp slt i64 %t300, %t301
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb68, label %bb69
bb68:
  br label %bb85
bb69:
  br label %bb70
bb70:
  %t306 = load ptr, ptr %l23, !tbaa !29
  %t307 = load i64, ptr %l24, !tbaa !24
  %t310 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t306, i64 %t307)
  store %"compiler/names:Entry" %t310, ptr %l185
  br label %bb71
bb71:
  %t311 = load %"compiler/names:Entry", ptr %l185
  store %"compiler/names:Entry" %t311, ptr %l25
  %t312 = getelementptr %"compiler/names:Entry", ptr %l25, i32 0, i32 0
  %t313 = load i32, ptr %t312, !tbaa !23
  %t314 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t314, ptr %l187, !tbaa !27
  %t315 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr i32, ptr %t316, i64 0
  %t318 = load i32, ptr %t317, !tbaa !33
  %t321 = icmp eq i32 %t313, %t318
  br i1 %t321, label %bb72, label %bb73
bb72:
  %t323 = getelementptr %"compiler/names:Entry", ptr %l25, i32 0, i32 2
  %t324 = load i32, ptr %t323, !range !{i32 0, i32 9}
  %t326 = trunc i64 3 to i32
  %t327 = icmp eq i32 %t324, %t326
  br i1 %t327, label %bb74, label %bb75
bb73:
  store i1 false, ptr %l190, !tbaa !21
  br label %bb77
bb74:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb76
bb75:
  %t329 = getelementptr %"compiler/names:Entry", ptr %l25, i32 0, i32 2
  %t330 = load i32, ptr %t329, !range !{i32 0, i32 9}
  %t332 = trunc i64 4 to i32
  %t333 = icmp eq i32 %t330, %t332
  store i1 %t333, ptr %l193, !tbaa !21
  br label %bb76
bb76:
  %t335 = load i1, ptr %l193, !tbaa !21
  store i1 %t335, ptr %l190, !tbaa !21
  br label %bb77
bb77:
  %t336 = load i1, ptr %l190, !tbaa !21
  br i1 %t336, label %bb78, label %bb79
bb78:
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l196, !tbaa !29
  %t338 = load ptr, ptr %l3, !tbaa !29
  %t340 = getelementptr %"compiler/ast:Path", ptr %t338, i32 0, i32 0
  %t341 = load %"compiler/source:Span", ptr %t340
  store %"compiler/source:Span" %t341, ptr %l198
  %t342 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t344 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTestTargetElsewhere(ptr %s0, ptr %v0, { i64, ptr } %t342)
  store %"compiler/diagmsg:Msg" %t344, ptr %l200
  br label %bb80
bb79:
  br label %bb83
bb80:
  %t345 = load ptr, ptr %l196, !tbaa !29
  %t346 = load %"compiler/source:Span", ptr %l198
  %t347 = load %"compiler/diagmsg:Msg", ptr %l200
  %t348 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t345, %"compiler/source:Span" %t346, %"compiler/diagmsg:Msg" %t347)
  store i64 %t348, ptr %l201
  br label %bb81
bb81:
  %t349 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t349)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb83:
  br label %bb84
bb84:
  %t351 = load i64, ptr %l24, !tbaa !24
  %t353 = add i64 %t351, 1
  store i64 %t353, ptr %l24, !tbaa !24
  br label %bb66
bb85:
  br label %bb86
bb86:
  %t355 = load i64, ptr %l21, !tbaa !24
  %t357 = add i64 %t355, 1
  store i64 %t357, ptr %l21, !tbaa !24
  br label %bb58
bb87:
  br label %bb181
bb88:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/check:Checker", ptr %t359, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t362)
  br label %bb90
bb89:
  br label %bb180
bb90:
  store i1 false, ptr %l26, !tbaa !21
  store i64 0, ptr %l27, !tbaa !24
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/check:Checker", ptr %t364, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !29
  %t369 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t367)
  store i64 %t369, ptr %l214
  br label %bb91
bb91:
  %t370 = load i64, ptr %l214, !tbaa !24
  store i64 %t370, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t371 = load i64, ptr %l28, !tbaa !24
  %t372 = load i64, ptr %l27, !tbaa !24
  %t375 = icmp sgt i64 %t371, %t372
  br i1 %t375, label %bb92, label %bb93
bb92:
  %t377 = load i64, ptr %l29, !tbaa !24
  %t379 = icmp sgt i64 %t377, 0
  br i1 %t379, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l218, !tbaa !24
  br label %bb97
bb94:
  %t381 = load i64, ptr %l28, !tbaa !24
  %t382 = load i64, ptr %l27, !tbaa !24
  %t385 = sub i64 %t381, %t382
  %t386 = load i64, ptr %l29, !tbaa !24
  %t389 = add i64 %t385, %t386
  %t391 = sub i64 %t389, 1
  %t392 = load i64, ptr %l29, !tbaa !24
  %t395 = sdiv i64 %t391, %t392
  store i64 %t395, ptr %l221, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l221, !tbaa !24
  br label %bb96
bb96:
  %t397 = load i64, ptr %l221, !tbaa !24
  store i64 %t397, ptr %l218, !tbaa !24
  br label %bb97
bb97:
  %t398 = load i64, ptr %l218, !tbaa !24
  store i64 %t398, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s31
  %t399 = load i64, ptr %l31, !tbaa !24
  %t400 = load i64, ptr %l30, !tbaa !24
  %t403 = icmp slt i64 %t399, %t400
  %t405 = xor i1 %t403, true
  br i1 %t405, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s31)
  br label %bb159
bb100:
  br label %bb101
bb101:
  %t407 = load i64, ptr %l27, !tbaa !24
  %t408 = load i64, ptr %l31, !tbaa !24
  %t409 = load i64, ptr %l29, !tbaa !24
  %t412 = mul i64 %t408, %t409
  %t415 = add i64 %t407, %t412
  store i64 %t415, ptr %l32, !tbaa !24
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/check:Checker", ptr %t417, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t421 = load i64, ptr %l32, !tbaa !24
  %t424 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t420, i64 %t421)
  store ptr %t424, ptr %l242
  br label %bb102
bb102:
  %t425 = load ptr, ptr %l242, !tbaa !29
  store ptr %t425, ptr %l33, !tbaa !29
  %t426 = load ptr, ptr %l33, !tbaa !29
  %t428 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t426)
  store i1 %t428, ptr %l244
  br label %bb103
bb103:
  %t429 = load i1, ptr %l244, !tbaa !21
  br i1 %t429, label %bb104, label %bb105
bb104:
  %t430 = load ptr, ptr %l33, !tbaa !29
  %t432 = getelementptr %"compiler/ast:Func", ptr %t430, i32 0, i32 10
  %t433 = load i32, ptr %t432, !tbaa !23
  %t434 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t434, ptr %l248, !tbaa !27
  %t435 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr i32, ptr %t436, i64 1
  %t438 = load i32, ptr %t437, !tbaa !33
  %t441 = icmp eq i32 %t433, %t438
  store i1 %t441, ptr %l245, !tbaa !21
  br label %bb106
bb105:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb106
bb106:
  %t443 = load i1, ptr %l245, !tbaa !21
  br i1 %t443, label %bb107, label %bb108
bb107:
  %t444 = load ptr, ptr %l33, !tbaa !29
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/check:Checker", ptr %t445, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !29
  %t450 = getelementptr %"compiler/generic:Program", ptr %t448, i32 0, i32 0
  %t451 = load ptr, ptr %t450, !tbaa !29
  %t453 = getelementptr %"compiler/load:Loader", ptr %t451, i32 0, i32 3
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t457 = call { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v0, ptr %s31, ptr %t444, ptr %t454)
  store { i64, ptr } %t457, ptr %l257
  br label %bb109
bb108:
  store i1 false, ptr %l251, !tbaa !21
  br label %bb112
bb109:
  %t458 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t458, 0
  %t460 = extractvalue { i64, ptr } %t458, 1
  %t461 = mul i64 %t459, 1
  %t462 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t461)
  call void @llvm.memcpy.p0.p0.i64(ptr %t462, ptr %t460, i64 %t461, i1 false)
  %t463 = insertvalue { i64, ptr } undef, i64 %t459, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t462, 1
  store { i64, ptr } %t464, ptr %l258, !tbaa !27
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t466, ptr %l260, !tbaa !27
  %t467 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr i32, ptr %t468, i64 0
  %t470 = load i32, ptr %t469, !tbaa !33
  %t473 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t465, i32 %t470)
  store { i64, ptr } %t473, ptr %l262
  br label %bb110
bb110:
  %t474 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t475 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t476 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %v0, { i64, ptr } %t474, { i64, ptr } %t475)
  store i1 %t476, ptr %l263
  br label %bb111
bb111:
  %t477 = load i1, ptr %l263, !tbaa !21
  store i1 %t477, ptr %l251, !tbaa !21
  br label %bb112
bb112:
  %t478 = load i1, ptr %l251, !tbaa !21
  br i1 %t478, label %bb113, label %bb114
bb113:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/check:Checker", ptr %t479, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t483 = load i64, ptr %l32, !tbaa !24
  %t486 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t482, i64 %t483)
  store i64 %t486, ptr %l267
  br label %bb115
bb114:
  br label %bb120
bb115:
  %t487 = load i64, ptr %l1, !tbaa !24
  %t488 = load i64, ptr %l267, !tbaa !24
  %t490 = icmp eq i64 %t488, %t487
  br i1 %t490, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s31)
  %t492 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t492)
  br label %bb118
bb117:
  br label %bb119
bb118:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb119:
  store i1 true, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s31)
  br label %bb158
bb120:
  %t494 = load ptr, ptr %l33, !tbaa !29
  %t496 = getelementptr %"compiler/ast:Func", ptr %t494, i32 0, i32 1
  %t497 = load ptr, ptr %t496, !tbaa !29
  %t499 = icmp eq ptr %t497, null
  br i1 %t499, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l274, !tbaa !21
  br label %bb123
bb122:
  %t501 = load ptr, ptr %l33, !tbaa !29
  %t503 = getelementptr %"compiler/ast:Func", ptr %t501, i32 0, i32 2
  %t504 = load i32, ptr %t503, !tbaa !23
  %t505 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t505, ptr %l277, !tbaa !27
  %t506 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr i32, ptr %t507, i64 1
  %t509 = load i32, ptr %t508, !tbaa !33
  %t512 = icmp ne i32 %t504, %t509
  store i1 %t512, ptr %l274, !tbaa !21
  br label %bb123
bb123:
  %t514 = load i1, ptr %l274, !tbaa !21
  br i1 %t514, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s31)
  br label %bb158
bb125:
  br label %bb126
bb126:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t517 = getelementptr %"compiler/check:Checker", ptr %t515, i32 0, i32 1
  %t518 = load ptr, ptr %t517, !tbaa !29
  %t520 = getelementptr %"compiler/generic:Program", ptr %t518, i32 0, i32 2
  store ptr %t520, ptr %l282, !tbaa !29
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/check:Checker", ptr %t521, i32 0, i32 1
  %t524 = load ptr, ptr %t523, !tbaa !29
  %t526 = getelementptr %"compiler/generic:Program", ptr %t524, i32 0, i32 2
  store ptr %t526, ptr %l285, !tbaa !29
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr %"compiler/check:Checker", ptr %t527, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !29
  %t531 = load i64, ptr %l32, !tbaa !24
  %t534 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t530, i64 %t531)
  store i32 %t534, ptr %l289
  br label %bb127
bb127:
  %t535 = load ptr, ptr %l285, !tbaa !29
  %t536 = load i32, ptr %l289, !tbaa !23
  %t537 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t535, i32 %t536)
  store i32 %t537, ptr %l290
  br label %bb128
bb128:
  %t538 = load ptr, ptr %l282, !tbaa !29
  %t539 = load i32, ptr %l290, !tbaa !23
  %t540 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t538, i32 %t539)
  store { i64, ptr } %t540, ptr %l291
  br label %bb129
bb129:
  %t541 = load { i64, ptr }, ptr %l291, !tbaa !27
  store { i64, ptr } %t541, ptr %l34, !tbaa !27
  %t542 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t544 = extractvalue { i64, ptr } %t542, 0
  %t546 = icmp eq i64 %t544, 0
  br i1 %t546, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s31)
  br label %bb158
bb131:
  br label %bb132
bb132:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t549 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t549, ptr %l296, !tbaa !27
  %t550 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t551 = load ptr, ptr %t550, !tbaa !27
  %t552 = getelementptr i32, ptr %t551, i64 0
  %t553 = load i32, ptr %t552, !tbaa !33
  %t556 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t548, i32 %t553)
  store i32 %t556, ptr %l298
  br label %bb133
bb133:
  %t557 = load i32, ptr %l298, !tbaa !23
  store i32 %t557, ptr %l35, !tbaa !23
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load i32, ptr %l35, !tbaa !23
  %t562 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t558, i32 %t559)
  store i1 %t562, ptr %l301
  br label %bb134
bb134:
  %t563 = load i1, ptr %l301, !tbaa !21
  br i1 %t563, label %bb135, label %bb136
bb135:
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t566 = getelementptr %"compiler/check:Checker", ptr %t564, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !29
  %t569 = getelementptr %"compiler/generic:Program", ptr %t567, i32 0, i32 2
  store ptr %t569, ptr %l305, !tbaa !29
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t572 = getelementptr %"compiler/check:Checker", ptr %t570, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !29
  %t575 = getelementptr %"compiler/generic:Program", ptr %t573, i32 0, i32 2
  %t576 = load i32, ptr %l35, !tbaa !23
  %t579 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t575, i32 %t576)
  store i32 %t579, ptr %l310
  br label %bb137
bb136:
  store i1 false, ptr %l302, !tbaa !21
  br label %bb139
bb137:
  %t580 = load ptr, ptr %l305, !tbaa !29
  %t581 = load i32, ptr %l310, !tbaa !23
  %t582 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t580, i32 %t581)
  store i32 %t582, ptr %l311
  br label %bb138
bb138:
  %t583 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t583, ptr %l312, !tbaa !27
  %t584 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t585 = load ptr, ptr %t584, !tbaa !27
  %t586 = getelementptr i32, ptr %t585, i64 0
  %t587 = load i32, ptr %t586, !tbaa !33
  %t588 = load i32, ptr %l311, !tbaa !23
  %t590 = icmp eq i32 %t588, %t587
  store i1 %t590, ptr %l302, !tbaa !21
  br label %bb139
bb139:
  %t592 = load i1, ptr %l302, !tbaa !21
  %t595 = xor i1 %t592, true
  br i1 %t595, label %bb140, label %bb141
bb140:
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t598 = load i32, ptr %l35, !tbaa !23
  %t601 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t597, i32 %t598)
  store i1 %t601, ptr %l320
  br label %bb142
bb141:
  store i1 false, ptr %l317, !tbaa !21
  br label %bb149
bb142:
  %t602 = load i1, ptr %l320, !tbaa !21
  br i1 %t602, label %bb143, label %bb144
bb143:
  store i1 true, ptr %l321, !tbaa !21
  br label %bb148
bb144:
  %t603 = load ptr, ptr %l33, !tbaa !29
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = getelementptr %"compiler/check:Checker", ptr %t604, i32 0, i32 1
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t609 = getelementptr %"compiler/generic:Program", ptr %t607, i32 0, i32 0
  %t610 = load ptr, ptr %t609, !tbaa !29
  %t612 = getelementptr %"compiler/load:Loader", ptr %t610, i32 0, i32 3
  %t613 = load ptr, ptr %t612, !tbaa !29
  %t616 = call { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v0, ptr %s31, ptr %t603, ptr %t613)
  store { i64, ptr } %t616, ptr %l327
  br label %bb145
bb145:
  %t617 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t618 = extractvalue { i64, ptr } %t617, 0
  %t619 = extractvalue { i64, ptr } %t617, 1
  %t620 = mul i64 %t618, 1
  %t621 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t620)
  call void @llvm.memcpy.p0.p0.i64(ptr %t621, ptr %t619, i64 %t620, i1 false)
  %t622 = insertvalue { i64, ptr } undef, i64 %t618, 0
  %t623 = insertvalue { i64, ptr } %t622, ptr %t621, 1
  store { i64, ptr } %t623, ptr %l328, !tbaa !27
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t625 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t625, ptr %l330, !tbaa !27
  %t626 = getelementptr { i64, ptr }, ptr %l330, i32 0, i32 1
  %t627 = load ptr, ptr %t626, !tbaa !27
  %t628 = getelementptr i32, ptr %t627, i64 0
  %t629 = load i32, ptr %t628, !tbaa !33
  %t632 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t624, i32 %t629)
  store { i64, ptr } %t632, ptr %l332
  br label %bb146
bb146:
  %t633 = load { i64, ptr }, ptr %l328, !tbaa !27
  %t634 = load { i64, ptr }, ptr %l332, !tbaa !27
  %t635 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %v0, { i64, ptr } %t633, { i64, ptr } %t634)
  store i1 %t635, ptr %l333
  br label %bb147
bb147:
  %t636 = load i1, ptr %l333, !tbaa !21
  %t637 = xor i1 %t636, true
  store i1 %t637, ptr %l321, !tbaa !21
  br label %bb148
bb148:
  %t639 = load i1, ptr %l321, !tbaa !21
  store i1 %t639, ptr %l317, !tbaa !21
  br label %bb149
bb149:
  %t640 = load i1, ptr %l317, !tbaa !21
  br i1 %t640, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s31)
  br label %bb158
bb151:
  br label %bb152
bb152:
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t643 = getelementptr %"compiler/check:Checker", ptr %t641, i32 0, i32 1
  %t644 = load ptr, ptr %t643, !tbaa !29
  %t645 = load i64, ptr %l32, !tbaa !24
  %t648 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t644, i64 %t645)
  store i64 %t648, ptr %l338
  br label %bb153
bb153:
  %t649 = load i64, ptr %l1, !tbaa !24
  %t650 = load i64, ptr %l338, !tbaa !24
  %t652 = icmp eq i64 %t650, %t649
  br i1 %t652, label %bb154, label %bb155
bb154:
  call void @__olang_scope_close(ptr %s31)
  %t654 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t654)
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb157:
  store i1 true, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s31)
  br label %bb158
bb158:
  %t656 = load i64, ptr %l31, !tbaa !24
  %t658 = add i64 %t656, 1
  store i64 %t658, ptr %l31, !tbaa !24
  br label %bb98
bb159:
  %t660 = load ptr, ptr %l13, !tbaa !29
  %t662 = getelementptr %"compiler/names:Table", ptr %t660, i32 0, i32 0
  store ptr %t662, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb160
bb160:
  %t664 = load i64, ptr %l38, !tbaa !24
  store i64 %t664, ptr %l346, !tbaa !24
  %t665 = load ptr, ptr %l37, !tbaa !29
  %t667 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t665)
  store i64 %t667, ptr %l348
  br label %bb161
bb161:
  %t668 = load i64, ptr %l346, !tbaa !24
  %t669 = load i64, ptr %l348, !tbaa !24
  %t670 = icmp slt i64 %t668, %t669
  %t672 = xor i1 %t670, true
  br i1 %t672, label %bb162, label %bb163
bb162:
  br label %bb173
bb163:
  br label %bb164
bb164:
  %t674 = load ptr, ptr %l37, !tbaa !29
  %t675 = load i64, ptr %l38, !tbaa !24
  %t678 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t674, i64 %t675)
  store %"compiler/names:Entry" %t678, ptr %l353
  br label %bb165
bb165:
  %t679 = load %"compiler/names:Entry", ptr %l353
  store %"compiler/names:Entry" %t679, ptr %l39
  %t680 = getelementptr %"compiler/names:Entry", ptr %l39, i32 0, i32 0
  %t681 = load i32, ptr %t680, !tbaa !23
  %t682 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t682, ptr %l355, !tbaa !27
  %t683 = getelementptr { i64, ptr }, ptr %l355, i32 0, i32 1
  %t684 = load ptr, ptr %t683, !tbaa !27
  %t685 = getelementptr i32, ptr %t684, i64 0
  %t686 = load i32, ptr %t685, !tbaa !33
  %t689 = icmp eq i32 %t681, %t686
  br i1 %t689, label %bb166, label %bb167
bb166:
  %t691 = getelementptr %"compiler/names:Entry", ptr %l39, i32 0, i32 2
  %t692 = load i32, ptr %t691, !range !{i32 0, i32 9}
  %t694 = trunc i64 5 to i32
  %t695 = icmp eq i32 %t692, %t694
  store i1 %t695, ptr %l358, !tbaa !21
  br label %bb168
bb167:
  store i1 false, ptr %l358, !tbaa !21
  br label %bb168
bb168:
  %t697 = load i1, ptr %l358, !tbaa !21
  br i1 %t697, label %bb169, label %bb170
bb169:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb171
bb170:
  br label %bb171
bb171:
  br label %bb172
bb172:
  %t698 = load i64, ptr %l38, !tbaa !24
  %t700 = add i64 %t698, 1
  store i64 %t700, ptr %l38, !tbaa !24
  br label %bb160
bb173:
  %t702 = load i1, ptr %l26, !tbaa !21
  br i1 %t702, label %bb174, label %bb175
bb174:
  %t704 = load ptr, ptr %l0, !tbaa !29
  store ptr %t704, ptr %l364, !tbaa !29
  %t705 = load ptr, ptr %l3, !tbaa !29
  %t707 = getelementptr %"compiler/ast:Path", ptr %t705, i32 0, i32 0
  %t708 = load %"compiler/source:Span", ptr %t707
  store %"compiler/source:Span" %t708, ptr %l366
  %t709 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t711 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTestTargetElsewhere(ptr %s0, ptr %v0, { i64, ptr } %t709)
  store %"compiler/diagmsg:Msg" %t711, ptr %l368
  br label %bb176
bb175:
  br label %bb179
bb176:
  %t712 = load ptr, ptr %l364, !tbaa !29
  %t713 = load %"compiler/source:Span", ptr %l366
  %t714 = load %"compiler/diagmsg:Msg", ptr %l368
  %t715 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t712, %"compiler/source:Span" %t713, %"compiler/diagmsg:Msg" %t714)
  store i64 %t715, ptr %l369
  br label %bb177
bb177:
  %t716 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t716)
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb179:
  br label %bb180
bb180:
  br label %bb181
bb181:
  %t718 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t720 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %s0, ptr %s0, { i64, ptr } %t718)
  store %"compiler/msgs:Nearest" %t720, ptr %l372
  br label %bb182
bb182:
  %t721 = load %"compiler/msgs:Nearest", ptr %l372
  %t722 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t721, ptr %t722
  store ptr %t722, ptr %l40, !tbaa !29
  %t724 = load ptr, ptr %l13, !tbaa !29
  %t726 = getelementptr %"compiler/names:Table", ptr %t724, i32 0, i32 0
  store ptr %t726, ptr %l41, !tbaa !29
  store i64 0, ptr %l42, !tbaa !24
  br label %bb183
bb183:
  store %olang.scope zeroinitializer, ptr %s51
  %t728 = load i64, ptr %l42, !tbaa !24
  store i64 %t728, ptr %l376, !tbaa !24
  %t729 = load ptr, ptr %l41, !tbaa !29
  %t731 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t729)
  store i64 %t731, ptr %l378
  br label %bb184
bb184:
  %t732 = load i64, ptr %l376, !tbaa !24
  %t733 = load i64, ptr %l378, !tbaa !24
  %t734 = icmp slt i64 %t732, %t733
  %t736 = xor i1 %t734, true
  br i1 %t736, label %bb185, label %bb186
bb185:
  call void @__olang_scope_close(ptr %s51)
  br label %bb203
bb186:
  br label %bb187
bb187:
  %t738 = load ptr, ptr %l41, !tbaa !29
  %t739 = load i64, ptr %l42, !tbaa !24
  %t742 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t738, i64 %t739)
  store %"compiler/names:Entry" %t742, ptr %l383
  br label %bb188
bb188:
  %t743 = load %"compiler/names:Entry", ptr %l383
  store %"compiler/names:Entry" %t743, ptr %l43
  %t744 = getelementptr %"compiler/names:Entry", ptr %l43, i32 0, i32 2
  %t745 = load i32, ptr %t744, !range !{i32 0, i32 9}
  %t747 = trunc i64 3 to i32
  %t748 = icmp eq i32 %t745, %t747
  br i1 %t748, label %bb189, label %bb190
bb189:
  store i1 true, ptr %l386, !tbaa !21
  br label %bb191
bb190:
  %t750 = getelementptr %"compiler/names:Entry", ptr %l43, i32 0, i32 2
  %t751 = load i32, ptr %t750, !range !{i32 0, i32 9}
  %t753 = trunc i64 4 to i32
  %t754 = icmp eq i32 %t751, %t753
  store i1 %t754, ptr %l386, !tbaa !21
  br label %bb191
bb191:
  %t756 = load i1, ptr %l386, !tbaa !21
  br i1 %t756, label %bb192, label %bb193
bb192:
  %t757 = load ptr, ptr %l0, !tbaa !29
  %t758 = getelementptr %"compiler/names:Entry", ptr %l43, i32 0, i32 0
  %t759 = load i32, ptr %t758, !tbaa !23
  %t762 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s51, ptr %t757, i32 %t759)
  store { i64, ptr } %t762, ptr %l392
  br label %bb194
bb193:
  store i1 false, ptr %l389, !tbaa !21
  br label %bb196
bb194:
  %t763 = load { i64, ptr }, ptr %l392, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l394, !tbaa !27
  %t765 = load { i64, ptr }, ptr %l394, !tbaa !27
  %t766 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s51, ptr %s51, { i64, ptr } %t763, { i64, ptr } %t765)
  store i1 %t766, ptr %l395
  br label %bb195
bb195:
  %t767 = load i1, ptr %l395, !tbaa !21
  %t768 = xor i1 %t767, true
  store i1 %t768, ptr %l389, !tbaa !21
  br label %bb196
bb196:
  %t770 = load i1, ptr %l389, !tbaa !21
  br i1 %t770, label %bb197, label %bb198
bb197:
  %t771 = load ptr, ptr %l40, !tbaa !29
  store ptr %t771, ptr %l397, !tbaa !29
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t773 = getelementptr %"compiler/names:Entry", ptr %l43, i32 0, i32 0
  %t774 = load i32, ptr %t773, !tbaa !23
  %t777 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t772, i32 %t774)
  store { i64, ptr } %t777, ptr %l400
  br label %bb199
bb198:
  br label %bb201
bb199:
  %t778 = load ptr, ptr %l397, !tbaa !29
  %t779 = load { i64, ptr }, ptr %l400, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t778, { i64, ptr } %t779)
  br label %bb200
bb200:
  br label %bb201
bb201:
  call void @__olang_scope_close(ptr %s51)
  br label %bb202
bb202:
  %t780 = load i64, ptr %l42, !tbaa !24
  %t782 = add i64 %t780, 1
  store i64 %t782, ptr %l42, !tbaa !24
  br label %bb183
bb203:
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t786 = getelementptr %"compiler/check:Checker", ptr %t784, i32 0, i32 1
  %t787 = load ptr, ptr %t786, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t787)
  br label %bb204
bb204:
  store i64 0, ptr %l44, !tbaa !24
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t791 = getelementptr %"compiler/check:Checker", ptr %t789, i32 0, i32 1
  %t792 = load ptr, ptr %t791, !tbaa !29
  %t794 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t792)
  store i64 %t794, ptr %l407
  br label %bb205
bb205:
  %t795 = load i64, ptr %l407, !tbaa !24
  store i64 %t795, ptr %l45, !tbaa !24
  store i64 1, ptr %l46, !tbaa !24
  %t796 = load i64, ptr %l45, !tbaa !24
  %t797 = load i64, ptr %l44, !tbaa !24
  %t800 = icmp sgt i64 %t796, %t797
  br i1 %t800, label %bb206, label %bb207
bb206:
  %t802 = load i64, ptr %l46, !tbaa !24
  %t804 = icmp sgt i64 %t802, 0
  br i1 %t804, label %bb208, label %bb209
bb207:
  store i64 0, ptr %l411, !tbaa !24
  br label %bb211
bb208:
  %t806 = load i64, ptr %l45, !tbaa !24
  %t807 = load i64, ptr %l44, !tbaa !24
  %t810 = sub i64 %t806, %t807
  %t811 = load i64, ptr %l46, !tbaa !24
  %t814 = add i64 %t810, %t811
  %t816 = sub i64 %t814, 1
  %t817 = load i64, ptr %l46, !tbaa !24
  %t820 = sdiv i64 %t816, %t817
  store i64 %t820, ptr %l414, !tbaa !24
  br label %bb210
bb209:
  store i64 0, ptr %l414, !tbaa !24
  br label %bb210
bb210:
  %t822 = load i64, ptr %l414, !tbaa !24
  store i64 %t822, ptr %l411, !tbaa !24
  br label %bb211
bb211:
  %t823 = load i64, ptr %l411, !tbaa !24
  store i64 %t823, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  br label %bb212
bb212:
  %t824 = load i64, ptr %l48, !tbaa !24
  %t825 = load i64, ptr %l47, !tbaa !24
  %t828 = icmp slt i64 %t824, %t825
  %t830 = xor i1 %t828, true
  br i1 %t830, label %bb213, label %bb214
bb213:
  br label %bb267
bb214:
  br label %bb215
bb215:
  %t832 = load i64, ptr %l44, !tbaa !24
  %t833 = load i64, ptr %l48, !tbaa !24
  %t834 = load i64, ptr %l46, !tbaa !24
  %t837 = mul i64 %t833, %t834
  %t840 = add i64 %t832, %t837
  store i64 %t840, ptr %l49, !tbaa !24
  %t842 = load ptr, ptr %l0, !tbaa !29
  %t844 = getelementptr %"compiler/check:Checker", ptr %t842, i32 0, i32 1
  %t845 = load ptr, ptr %t844, !tbaa !29
  %t846 = load i64, ptr %l49, !tbaa !24
  %t849 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t845, i64 %t846)
  store ptr %t849, ptr %l435
  br label %bb216
bb216:
  %t850 = load ptr, ptr %l435, !tbaa !29
  store ptr %t850, ptr %l50, !tbaa !29
  %t851 = load ptr, ptr %l50, !tbaa !29
  %t853 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t851)
  store i1 %t853, ptr %l437
  br label %bb217
bb217:
  %t854 = load i1, ptr %l437, !tbaa !21
  br i1 %t854, label %bb218, label %bb219
bb218:
  %t855 = load ptr, ptr %l0, !tbaa !29
  %t857 = getelementptr %"compiler/check:Checker", ptr %t855, i32 0, i32 1
  %t858 = load ptr, ptr %t857, !tbaa !29
  %t859 = load i64, ptr %l49, !tbaa !24
  %t862 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t858, i64 %t859)
  store i64 %t862, ptr %l442
  br label %bb220
bb219:
  store i1 false, ptr %l438, !tbaa !21
  br label %bb221
bb220:
  %t863 = load i64, ptr %l1, !tbaa !24
  %t864 = load i64, ptr %l442, !tbaa !24
  %t866 = icmp eq i64 %t864, %t863
  store i1 %t866, ptr %l438, !tbaa !21
  br label %bb221
bb221:
  %t868 = load i1, ptr %l438, !tbaa !21
  br i1 %t868, label %bb222, label %bb223
bb222:
  store %olang.scope zeroinitializer, ptr %s56
  %t869 = load ptr, ptr %l40, !tbaa !29
  store ptr %t869, ptr %l445, !tbaa !29
  %t870 = ptrtoint ptr %s0 to i64
  store i64 %t870, ptr %l446, !tbaa !24
  %t871 = load i1, ptr @olang_2esole_2ecompiler_2fmsgs_3aNearest_2e1
  br i1 %t871, label %bb224, label %bb225
bb223:
  br label %bb229
bb224:
  %t873 = call ptr @__olang_region_make(ptr %s0)
  %t874 = ptrtoint ptr %t873 to i64
  store i64 %t874, ptr %l446, !tbaa !24
  br label %bb225
bb225:
  %t875 = load ptr, ptr %l50, !tbaa !29
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t878 = getelementptr %"compiler/check:Checker", ptr %t876, i32 0, i32 1
  %t879 = load ptr, ptr %t878, !tbaa !29
  %t881 = getelementptr %"compiler/generic:Program", ptr %t879, i32 0, i32 0
  %t882 = load ptr, ptr %t881, !tbaa !29
  %t884 = getelementptr %"compiler/load:Loader", ptr %t882, i32 0, i32 3
  %t885 = load ptr, ptr %t884, !tbaa !29
  %t888 = call { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v0, ptr %s56, ptr %t875, ptr %t885)
  store { i64, ptr } %t888, ptr %l453
  br label %bb226
bb226:
  %t889 = load ptr, ptr %l0, !tbaa !29
  %t890 = load ptr, ptr %l50, !tbaa !29
  %t892 = getelementptr %"compiler/ast:Func", ptr %t890, i32 0, i32 10
  %t893 = load i32, ptr %t892, !tbaa !23
  %t896 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s56, ptr %t889, i32 %t893)
  store { i64, ptr } %t896, ptr %l457
  br label %bb227
bb227:
  %t897 = load { i64, ptr }, ptr %l453, !tbaa !27
  %t898 = extractvalue { i64, ptr } %t897, 1
  %t899 = extractvalue { i64, ptr } %t897, 0
  %t900 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t901 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t902 = add i64 %t899, %t901
  %t903 = load { i64, ptr }, ptr %l457, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t903, 1
  %t905 = extractvalue { i64, ptr } %t903, 0
  %t906 = add i64 %t902, %t905
  %t907 = load i64, ptr %l446
  %t908 = inttoptr i64 %t907 to ptr
  %t909 = call ptr @__olang_held_alloc(ptr %t908, i64 %t906)
  call void @olang_textcopy(ptr %t909, ptr %t898, i64 %t899)
  %t910 = getelementptr i8, ptr %t909, i64 %t899
  call void @olang_textcopy(ptr %t910, ptr %t900, i64 %t901)
  %t911 = getelementptr i8, ptr %t910, i64 %t901
  call void @olang_textcopy(ptr %t911, ptr %t904, i64 %t905)
  %t912 = insertvalue { i64, ptr } undef, i64 %t906, 0
  %t913 = insertvalue { i64, ptr } %t912, ptr %t909, 1
  %t915 = load i64, ptr %l446
  %t916 = inttoptr i64 %t915 to ptr
  %t917 = extractvalue { i64, ptr } %t913, 0
  %t918 = extractvalue { i64, ptr } %t913, 1
  %t919 = mul i64 %t917, 1
  %t920 = call ptr @__olang_held_alloc(ptr %t916, i64 %t919)
  call void @llvm.memcpy.p0.p0.i64(ptr %t920, ptr %t918, i64 %t919, i1 false)
  %t921 = insertvalue { i64, ptr } undef, i64 %t917, 0
  %t922 = insertvalue { i64, ptr } %t921, ptr %t920, 1
  %t923 = load ptr, ptr %l445, !tbaa !29
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %s0, ptr %t923, { i64, ptr } %t922)
  br label %bb228
bb228:
  call void @__olang_scope_close(ptr %s56)
  br label %bb229
bb229:
  %t925 = load ptr, ptr %l50, !tbaa !29
  %t927 = getelementptr %"compiler/ast:Func", ptr %t925, i32 0, i32 1
  %t928 = load ptr, ptr %t927, !tbaa !29
  %t930 = icmp eq ptr %t928, null
  br i1 %t930, label %bb230, label %bb231
bb230:
  store i1 true, ptr %l463, !tbaa !21
  br label %bb233
bb231:
  %t932 = load ptr, ptr %l0, !tbaa !29
  %t934 = getelementptr %"compiler/check:Checker", ptr %t932, i32 0, i32 1
  %t935 = load ptr, ptr %t934, !tbaa !29
  %t936 = load i64, ptr %l49, !tbaa !24
  %t939 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t935, i64 %t936)
  store i64 %t939, ptr %l467
  br label %bb232
bb232:
  %t940 = load i64, ptr %l1, !tbaa !24
  %t941 = load i64, ptr %l467, !tbaa !24
  %t943 = icmp ne i64 %t941, %t940
  store i1 %t943, ptr %l463, !tbaa !21
  br label %bb233
bb233:
  %t945 = load i1, ptr %l463, !tbaa !21
  br i1 %t945, label %bb234, label %bb235
bb234:
  br label %bb266
bb235:
  br label %bb236
bb236:
  %t946 = load ptr, ptr %l0, !tbaa !29
  %t948 = getelementptr %"compiler/check:Checker", ptr %t946, i32 0, i32 1
  %t949 = load ptr, ptr %t948, !tbaa !29
  %t951 = getelementptr %"compiler/generic:Program", ptr %t949, i32 0, i32 2
  store ptr %t951, ptr %l472, !tbaa !29
  %t952 = load ptr, ptr %l0, !tbaa !29
  %t954 = getelementptr %"compiler/check:Checker", ptr %t952, i32 0, i32 1
  %t955 = load ptr, ptr %t954, !tbaa !29
  %t957 = getelementptr %"compiler/generic:Program", ptr %t955, i32 0, i32 2
  store ptr %t957, ptr %l475, !tbaa !29
  %t958 = load ptr, ptr %l0, !tbaa !29
  %t960 = getelementptr %"compiler/check:Checker", ptr %t958, i32 0, i32 1
  %t961 = load ptr, ptr %t960, !tbaa !29
  %t962 = load i64, ptr %l49, !tbaa !24
  %t965 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t961, i64 %t962)
  store i32 %t965, ptr %l479
  br label %bb237
bb237:
  %t966 = load ptr, ptr %l475, !tbaa !29
  %t967 = load i32, ptr %l479, !tbaa !23
  %t968 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t966, i32 %t967)
  store i32 %t968, ptr %l480
  br label %bb238
bb238:
  %t969 = load ptr, ptr %l472, !tbaa !29
  %t970 = load i32, ptr %l480, !tbaa !23
  %t971 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t969, i32 %t970)
  store { i64, ptr } %t971, ptr %l481
  br label %bb239
bb239:
  %t972 = load { i64, ptr }, ptr %l481, !tbaa !27
  store { i64, ptr } %t972, ptr %l51, !tbaa !27
  %t973 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t975 = extractvalue { i64, ptr } %t973, 0
  %t977 = icmp eq i64 %t975, 0
  br i1 %t977, label %bb240, label %bb241
bb240:
  br label %bb266
bb241:
  br label %bb242
bb242:
  %t979 = load ptr, ptr %l0, !tbaa !29
  store ptr %t979, ptr %l485, !tbaa !29
  %t980 = load ptr, ptr %l0, !tbaa !29
  %t981 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t981, ptr %l487, !tbaa !27
  %t982 = getelementptr { i64, ptr }, ptr %l487, i32 0, i32 1
  %t983 = load ptr, ptr %t982, !tbaa !27
  %t984 = getelementptr i32, ptr %t983, i64 0
  %t985 = load i32, ptr %t984, !tbaa !33
  %t988 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t980, i32 %t985)
  store i32 %t988, ptr %l489
  br label %bb243
bb243:
  %t989 = load ptr, ptr %l485, !tbaa !29
  %t990 = load i32, ptr %l489, !tbaa !23
  %t991 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t989, i32 %t990)
  store i1 %t991, ptr %l490
  br label %bb244
bb244:
  %t992 = load i1, ptr %l490, !tbaa !21
  br i1 %t992, label %bb245, label %bb246
bb245:
  store %olang.scope zeroinitializer, ptr %s60
  %t993 = load ptr, ptr %l40, !tbaa !29
  store ptr %t993, ptr %l491, !tbaa !29
  %t994 = ptrtoint ptr %s0 to i64
  store i64 %t994, ptr %l492, !tbaa !24
  %t995 = load i1, ptr @olang_2esole_2ecompiler_2fmsgs_3aNearest_2e1
  br i1 %t995, label %bb247, label %bb248
bb246:
  store %olang.scope zeroinitializer, ptr %s62
  %t997 = load ptr, ptr %l50, !tbaa !29
  %t998 = load ptr, ptr %l0, !tbaa !29
  %t1000 = getelementptr %"compiler/check:Checker", ptr %t998, i32 0, i32 1
  %t1001 = load ptr, ptr %t1000, !tbaa !29
  %t1003 = getelementptr %"compiler/generic:Program", ptr %t1001, i32 0, i32 0
  %t1004 = load ptr, ptr %t1003, !tbaa !29
  %t1006 = getelementptr %"compiler/load:Loader", ptr %t1004, i32 0, i32 3
  %t1007 = load ptr, ptr %t1006, !tbaa !29
  %t1010 = call { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v0, ptr %s62, ptr %t997, ptr %t1007)
  store { i64, ptr } %t1010, ptr %l519
  br label %bb255
bb247:
  %t1011 = call ptr @__olang_region_make(ptr %s0)
  %t1012 = ptrtoint ptr %t1011 to i64
  store i64 %t1012, ptr %l492, !tbaa !24
  br label %bb248
bb248:
  %t1013 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1013, ptr %l494, !tbaa !29
  %t1014 = load ptr, ptr %l0, !tbaa !29
  %t1016 = getelementptr %"compiler/check:Checker", ptr %t1014, i32 0, i32 1
  %t1017 = load ptr, ptr %t1016, !tbaa !29
  %t1019 = getelementptr %"compiler/generic:Program", ptr %t1017, i32 0, i32 2
  store ptr %t1019, ptr %l497, !tbaa !29
  %t1020 = load ptr, ptr %l0, !tbaa !29
  %t1022 = getelementptr %"compiler/check:Checker", ptr %t1020, i32 0, i32 1
  %t1023 = load ptr, ptr %t1022, !tbaa !29
  %t1025 = getelementptr %"compiler/generic:Program", ptr %t1023, i32 0, i32 2
  store ptr %t1025, ptr %l500, !tbaa !29
  %t1026 = load ptr, ptr %l0, !tbaa !29
  %t1027 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t1027, ptr %l502, !tbaa !27
  %t1028 = getelementptr { i64, ptr }, ptr %l502, i32 0, i32 1
  %t1029 = load ptr, ptr %t1028, !tbaa !27
  %t1030 = getelementptr i32, ptr %t1029, i64 0
  %t1031 = load i32, ptr %t1030, !tbaa !33
  %t1034 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1026, i32 %t1031)
  store i32 %t1034, ptr %l504
  br label %bb249
bb249:
  %t1035 = load ptr, ptr %l500, !tbaa !29
  %t1036 = load i32, ptr %l504, !tbaa !23
  %t1037 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t1035, i32 %t1036)
  store i32 %t1037, ptr %l505
  br label %bb250
bb250:
  %t1038 = load ptr, ptr %l497, !tbaa !29
  %t1039 = load i32, ptr %l505, !tbaa !23
  %t1040 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t1038, i32 %t1039)
  store i32 %t1040, ptr %l506
  br label %bb251
bb251:
  %t1041 = load ptr, ptr %l494, !tbaa !29
  %t1042 = load i32, ptr %l506, !tbaa !23
  %t1043 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s60, ptr %t1041, i32 %t1042)
  store { i64, ptr } %t1043, ptr %l507
  br label %bb252
bb252:
  %t1044 = load ptr, ptr %l0, !tbaa !29
  %t1045 = load ptr, ptr %l50, !tbaa !29
  %t1047 = getelementptr %"compiler/ast:Func", ptr %t1045, i32 0, i32 2
  %t1048 = load i32, ptr %t1047, !tbaa !23
  %t1051 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s60, ptr %t1044, i32 %t1048)
  store { i64, ptr } %t1051, ptr %l511
  br label %bb253
bb253:
  %t1052 = load { i64, ptr }, ptr %l507, !tbaa !27
  %t1053 = extractvalue { i64, ptr } %t1052, 1
  %t1054 = extractvalue { i64, ptr } %t1052, 0
  %t1055 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t1056 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t1057 = add i64 %t1054, %t1056
  %t1058 = load { i64, ptr }, ptr %l511, !tbaa !27
  %t1059 = extractvalue { i64, ptr } %t1058, 1
  %t1060 = extractvalue { i64, ptr } %t1058, 0
  %t1061 = add i64 %t1057, %t1060
  %t1062 = load i64, ptr %l492
  %t1063 = inttoptr i64 %t1062 to ptr
  %t1064 = call ptr @__olang_held_alloc(ptr %t1063, i64 %t1061)
  call void @olang_textcopy(ptr %t1064, ptr %t1053, i64 %t1054)
  %t1065 = getelementptr i8, ptr %t1064, i64 %t1054
  call void @olang_textcopy(ptr %t1065, ptr %t1055, i64 %t1056)
  %t1066 = getelementptr i8, ptr %t1065, i64 %t1056
  call void @olang_textcopy(ptr %t1066, ptr %t1059, i64 %t1060)
  %t1067 = insertvalue { i64, ptr } undef, i64 %t1061, 0
  %t1068 = insertvalue { i64, ptr } %t1067, ptr %t1064, 1
  %t1070 = load i64, ptr %l492
  %t1071 = inttoptr i64 %t1070 to ptr
  %t1072 = extractvalue { i64, ptr } %t1068, 0
  %t1073 = extractvalue { i64, ptr } %t1068, 1
  %t1074 = mul i64 %t1072, 1
  %t1075 = call ptr @__olang_held_alloc(ptr %t1071, i64 %t1074)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1075, ptr %t1073, i64 %t1074, i1 false)
  %t1076 = insertvalue { i64, ptr } undef, i64 %t1072, 0
  %t1077 = insertvalue { i64, ptr } %t1076, ptr %t1075, 1
  %t1078 = load ptr, ptr %l491, !tbaa !29
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %s0, ptr %t1078, { i64, ptr } %t1077)
  br label %bb254
bb254:
  call void @__olang_scope_close(ptr %s60)
  br label %bb265
bb255:
  %t1080 = load { i64, ptr }, ptr %l519, !tbaa !27
  %t1081 = extractvalue { i64, ptr } %t1080, 0
  %t1082 = extractvalue { i64, ptr } %t1080, 1
  %t1083 = mul i64 %t1081, 1
  %t1084 = call ptr @__olang_scope_alloc(ptr %s62, i64 %t1083)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1084, ptr %t1082, i64 %t1083, i1 false)
  %t1085 = insertvalue { i64, ptr } undef, i64 %t1081, 0
  %t1086 = insertvalue { i64, ptr } %t1085, ptr %t1084, 1
  %t1088 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s62, ptr %s62, { i64, ptr } %t1086, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t1088, ptr %l521
  br label %bb256
bb256:
  %t1089 = load i1, ptr %l521, !tbaa !21
  %t1090 = xor i1 %t1089, true
  br i1 %t1090, label %bb257, label %bb258
bb257:
  store %olang.scope zeroinitializer, ptr %s63
  %t1092 = load ptr, ptr %l40, !tbaa !29
  store ptr %t1092, ptr %l523, !tbaa !29
  %t1093 = ptrtoint ptr %s0 to i64
  store i64 %t1093, ptr %l524, !tbaa !24
  %t1094 = load i1, ptr @olang_2esole_2ecompiler_2fmsgs_3aNearest_2e1
  br i1 %t1094, label %bb259, label %bb260
bb258:
  br label %bb264
bb259:
  %t1096 = call ptr @__olang_region_make(ptr %s0)
  %t1097 = ptrtoint ptr %t1096 to i64
  store i64 %t1097, ptr %l524, !tbaa !24
  br label %bb260
bb260:
  %t1098 = load ptr, ptr %l50, !tbaa !29
  %t1099 = load ptr, ptr %l0, !tbaa !29
  %t1101 = getelementptr %"compiler/check:Checker", ptr %t1099, i32 0, i32 1
  %t1102 = load ptr, ptr %t1101, !tbaa !29
  %t1104 = getelementptr %"compiler/generic:Program", ptr %t1102, i32 0, i32 0
  %t1105 = load ptr, ptr %t1104, !tbaa !29
  %t1107 = getelementptr %"compiler/load:Loader", ptr %t1105, i32 0, i32 3
  %t1108 = load ptr, ptr %t1107, !tbaa !29
  %t1111 = call { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v0, ptr %s63, ptr %t1098, ptr %t1108)
  store { i64, ptr } %t1111, ptr %l531
  br label %bb261
bb261:
  %t1112 = load ptr, ptr %l0, !tbaa !29
  %t1113 = load ptr, ptr %l50, !tbaa !29
  %t1115 = getelementptr %"compiler/ast:Func", ptr %t1113, i32 0, i32 2
  %t1116 = load i32, ptr %t1115, !tbaa !23
  %t1119 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s63, ptr %t1112, i32 %t1116)
  store { i64, ptr } %t1119, ptr %l535
  br label %bb262
bb262:
  %t1120 = load { i64, ptr }, ptr %l531, !tbaa !27
  %t1121 = extractvalue { i64, ptr } %t1120, 1
  %t1122 = extractvalue { i64, ptr } %t1120, 0
  %t1123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t1124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t1125 = add i64 %t1122, %t1124
  %t1126 = load { i64, ptr }, ptr %l535, !tbaa !27
  %t1127 = extractvalue { i64, ptr } %t1126, 1
  %t1128 = extractvalue { i64, ptr } %t1126, 0
  %t1129 = add i64 %t1125, %t1128
  %t1130 = load i64, ptr %l524
  %t1131 = inttoptr i64 %t1130 to ptr
  %t1132 = call ptr @__olang_held_alloc(ptr %t1131, i64 %t1129)
  call void @olang_textcopy(ptr %t1132, ptr %t1121, i64 %t1122)
  %t1133 = getelementptr i8, ptr %t1132, i64 %t1122
  call void @olang_textcopy(ptr %t1133, ptr %t1123, i64 %t1124)
  %t1134 = getelementptr i8, ptr %t1133, i64 %t1124
  call void @olang_textcopy(ptr %t1134, ptr %t1127, i64 %t1128)
  %t1135 = insertvalue { i64, ptr } undef, i64 %t1129, 0
  %t1136 = insertvalue { i64, ptr } %t1135, ptr %t1132, 1
  %t1138 = load i64, ptr %l524
  %t1139 = inttoptr i64 %t1138 to ptr
  %t1140 = extractvalue { i64, ptr } %t1136, 0
  %t1141 = extractvalue { i64, ptr } %t1136, 1
  %t1142 = mul i64 %t1140, 1
  %t1143 = call ptr @__olang_held_alloc(ptr %t1139, i64 %t1142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1143, ptr %t1141, i64 %t1142, i1 false)
  %t1144 = insertvalue { i64, ptr } undef, i64 %t1140, 0
  %t1145 = insertvalue { i64, ptr } %t1144, ptr %t1143, 1
  %t1146 = load ptr, ptr %l523, !tbaa !29
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %s0, ptr %t1146, { i64, ptr } %t1145)
  br label %bb263
bb263:
  call void @__olang_scope_close(ptr %s63)
  br label %bb264
bb264:
  call void @__olang_scope_close(ptr %s62)
  br label %bb265
bb265:
  br label %bb266
bb266:
  %t1148 = load i64, ptr %l48, !tbaa !24
  %t1150 = add i64 %t1148, 1
  store i64 %t1150, ptr %l48, !tbaa !24
  br label %bb212
bb267:
  %t1152 = load ptr, ptr %l40, !tbaa !29
  %t1154 = getelementptr %"compiler/msgs:Nearest", ptr %t1152, i32 0, i32 1
  %t1155 = load { i64, ptr }, ptr %t1154, !tbaa !27
  %t1157 = extractvalue { i64, ptr } %t1155, 0
  %t1159 = icmp sgt i64 %t1157, 0
  br i1 %t1159, label %bb268, label %bb269
bb268:
  %t1161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1161, ptr %l544, !tbaa !29
  %t1162 = load ptr, ptr %l3, !tbaa !29
  %t1164 = getelementptr %"compiler/ast:Path", ptr %t1162, i32 0, i32 0
  %t1165 = load %"compiler/source:Span", ptr %t1164
  store %"compiler/source:Span" %t1165, ptr %l546
  %t1166 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t1167 = load ptr, ptr %l40, !tbaa !29
  %t1169 = getelementptr %"compiler/msgs:Nearest", ptr %t1167, i32 0, i32 1
  %t1170 = load { i64, ptr }, ptr %t1169, !tbaa !27
  %t1173 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTestTargetUnknownMeant(ptr %s0, ptr %s0, ptr %v0, { i64, ptr } %t1166, { i64, ptr } %t1170)
  store %"compiler/diagmsg:Msg" %t1173, ptr %l550
  br label %bb270
bb269:
  %t1174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1174, ptr %l552, !tbaa !29
  %t1175 = load ptr, ptr %l3, !tbaa !29
  %t1177 = getelementptr %"compiler/ast:Path", ptr %t1175, i32 0, i32 0
  %t1178 = load %"compiler/source:Span", ptr %t1177
  store %"compiler/source:Span" %t1178, ptr %l554
  %t1179 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t1181 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTestTargetUnknown(ptr %s0, ptr %v0, { i64, ptr } %t1179)
  store %"compiler/diagmsg:Msg" %t1181, ptr %l556
  br label %bb272
bb270:
  %t1182 = load ptr, ptr %l544, !tbaa !29
  %t1183 = load %"compiler/source:Span", ptr %l546
  %t1184 = load %"compiler/diagmsg:Msg", ptr %l550
  %t1185 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1182, %"compiler/source:Span" %t1183, %"compiler/diagmsg:Msg" %t1184)
  store i64 %t1185, ptr %l551
  br label %bb271
bb271:
  br label %bb274
bb272:
  %t1186 = load ptr, ptr %l552, !tbaa !29
  %t1187 = load %"compiler/source:Span", ptr %l554
  %t1188 = load %"compiler/diagmsg:Msg", ptr %l556
  %t1189 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1186, %"compiler/source:Span" %t1187, %"compiler/diagmsg:Msg" %t1188)
  store i64 %t1189, ptr %l557
  br label %bb273
bb273:
  br label %bb274
bb274:
  %t1190 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t1190)
  br label %bb275
bb275:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3, %"compiler/source:Span" %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca i1
  %l40 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca %"compiler/source:Span"
  %l64 = alloca ptr
  %l65 = alloca i64
  %l71 = alloca %"compiler/source:Span"
  %l73 = alloca i64
  %l74 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l7, !tbaa !24
  %t15 = load i64, ptr %l8, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb45
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t22, ptr %l26, !tbaa !27
  %t23 = load i64, ptr %l7, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l9, !tbaa !29
  %t30 = load ptr, ptr %l9, !tbaa !29
  store ptr %t30, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t31 = load ptr, ptr %l29, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l29, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 11}
  %t37 = icmp eq i64 %t35, 8
  store i1 %t37, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l30, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l9, !tbaa !29
  %t41 = getelementptr { i64, [8 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t41, i32 0, i32 0
  %t43 = load %"compiler/source:Span", ptr %t42
  store %"compiler/source:Span" %t43, ptr %l10
  %t45 = load ptr, ptr %l9, !tbaa !29
  %t47 = getelementptr { i64, [8 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l11, !tbaa !29
  %t51 = load ptr, ptr %l9, !tbaa !29
  %t53 = getelementptr { i64, [8 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l12, !tbaa !29
  br label %bb12
bb11:
  br label %bb23
bb12:
  br i1 %a5, label %bb13, label %bb14
bb13:
  %t59 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t61 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t65 = icmp sgt i32 %t60, %t62
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb15
bb15:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb16, label %bb17
bb16:
  %t68 = load ptr, ptr %l11, !tbaa !29
  %t70 = call i32 @compiler_2fcheck_2esetName(ptr %v1, ptr %t68)
  store i32 %t70, ptr %l46
  br label %bb18
bb17:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb19
bb18:
  %t71 = load i32, ptr %l3, !tbaa !23
  %t72 = load i32, ptr %l46, !tbaa !23
  %t74 = icmp eq i32 %t72, %t71
  store i1 %t74, ptr %l44, !tbaa !21
  br label %bb19
bb19:
  %t76 = load i1, ptr %l44, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l12, !tbaa !29
  store ptr %t77, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb43
bb23:
  %t80 = load ptr, ptr %l9, !tbaa !29
  store ptr %t80, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t81 = load ptr, ptr %l51, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l51, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 11}
  %t87 = icmp eq i64 %t85, 7
  store i1 %t87, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l52, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l9, !tbaa !29
  %t91 = getelementptr { i64, [8 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l13, !tbaa !29
  br label %bb28
bb27:
  br label %bb38
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l57, !tbaa !29
  %t96 = load i64, ptr %l1, !tbaa !24
  store i64 %t96, ptr %l58, !tbaa !24
  %t97 = load ptr, ptr %l13, !tbaa !29
  store ptr %t97, ptr %l59, !tbaa !29
  %t98 = load i32, ptr %l3, !tbaa !23
  store i32 %t98, ptr %l60, !tbaa !23
  %t99 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t99, ptr %l61
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  store ptr %t106, ptr %l64, !tbaa !29
  %t107 = load i64, ptr %l1, !tbaa !24
  store i64 %t107, ptr %l65, !tbaa !24
  %t108 = load ptr, ptr %l13, !tbaa !29
  %t110 = getelementptr %"compiler/ast:TopIf", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb29, label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_ac983f970f94ac3e_5c81cf941b3f1e2)
  unreachable
bb30:
  br label %bb31
bb31:
  %t115 = load ptr, ptr %l13, !tbaa !29
  %t117 = getelementptr %"compiler/ast:TopIf", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t118)
  store %"compiler/source:Span" %t120, ptr %l71
  br label %bb32
bb32:
  %t121 = getelementptr %"compiler/source:Span", ptr %l71, i32 0, i32 0
  %t122 = load i32, ptr %t121, !tbaa !23
  %t123 = load ptr, ptr %l64, !tbaa !29
  %t124 = load i64, ptr %l65, !tbaa !24
  %t126 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t123, i64 %t124, i32 %t122)
  store i64 %t126, ptr %l73
  br label %bb33
bb33:
  %t127 = load ptr, ptr %l57, !tbaa !29
  %t128 = load i64, ptr %l58, !tbaa !24
  %t129 = load ptr, ptr %l59, !tbaa !29
  %t130 = load i32, ptr %l60, !tbaa !23
  %t131 = load %"compiler/source:Span", ptr %l61
  %t132 = load i64, ptr %l73, !tbaa !24
  %t133 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetChain(ptr %v0, ptr %v1, ptr %v2, ptr %t127, i64 %t128, ptr %t129, i32 %t130, %"compiler/source:Span" %t131, i64 %t132, i64 0)
  store ptr %t133, ptr %l74
  br label %bb34
bb34:
  %t134 = load ptr, ptr %l74, !tbaa !29
  store ptr %t134, ptr %l14, !tbaa !29
  %t135 = load ptr, ptr %l14, !tbaa !29
  %t137 = icmp eq ptr %t135, null
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb35, label %bb36
bb35:
  %t141 = load ptr, ptr %l14, !tbaa !29
  store ptr %t141, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_5e7ac483298c689c_15fc6611344e0300)
  unreachable
bb43:
  br label %bb44
bb44:
  %t144 = load i64, ptr %l7, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l7, !tbaa !24
  br label %bb4
bb45:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryStore(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l38 = alloca ptr
  %l49 = alloca i1
  %l51 = alloca i1
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca i32
  %l60 = alloca { i64, ptr }
  %l61 = alloca %"compiler/typed:Seq"
  %l67 = alloca i64
  %l72 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l97 = alloca ptr
  %l104 = alloca i1
  %l112 = alloca i64
  %l113 = alloca ptr
  %l117 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca %"compiler/source:Span"
  %l123 = alloca i32
  %l125 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l130 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t93 = alloca { i64, [5 x i64] }, align 8
  %t237 = alloca { i64, [5 x i64] }, align 8
  %t249 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l20
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l20, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 28
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l23
  br label %bb2
bb2:
  %t10 = load i64, ptr %l23, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 45
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l26
  br label %bb3
bb3:
  %t16 = load i64, ptr %l26, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 16
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l7, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 145
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l31
  br label %bb4
bb4:
  %t27 = load i64, ptr %l31, !tbaa !24
  store i64 %t27, ptr %l8, !tbaa !24
  %t28 = load ptr, ptr %l4, !tbaa !29
  store ptr %t28, ptr %l32, !tbaa !29
  %t29 = load ptr, ptr %l32, !tbaa !29
  %t30 = getelementptr %"compiler/check:frame", ptr %t29, i32 0, i32 15
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = add i64 %t31, 1
  %t35 = load ptr, ptr %l32, !tbaa !29
  %t36 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 15
  store i64 %t33, ptr %t36, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t37, ptr %a2)
  br label %bb5
bb5:
  %t42 = load ptr, ptr %l4, !tbaa !29
  store ptr %t42, ptr %l38, !tbaa !29
  %t43 = load ptr, ptr %l38, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t43, i32 0, i32 15
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = sub i64 %t45, 1
  %t49 = load ptr, ptr %l38, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t49, i32 0, i32 15
  store i64 %t47, ptr %t50, !tbaa !24
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 16
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp ne i64 %t54, %t55
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 16
  store i64 %t61, ptr %t64, !tbaa !24
  %t67 = xor i1 %t58, true
  br i1 %t67, label %bb6, label %bb7
bb6:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %t69)
  store i1 %t71, ptr %l51
  br label %bb8
bb7:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb9
bb8:
  %t72 = load i1, ptr %l51, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l49, !tbaa !21
  br label %bb9
bb9:
  %t75 = load i1, ptr %l49, !tbaa !21
  br i1 %t75, label %bb10, label %bb11
bb10:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enothingFails(ptr %v0, ptr %t76, %"compiler/source:Span" %t77)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t80 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t80, ptr %l55
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t81, ptr %l56, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 45
  %t85 = load i64, ptr %l6, !tbaa !24
  %t88 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t84, i64 %t85)
  store { i64, ptr } %t88, ptr %l60
  br label %bb14
bb14:
  %t89 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t90 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t89, ptr null, i1 false)
  store %"compiler/typed:Seq" %t90, ptr %l61
  br label %bb15
bb15:
  %t91 = load %"compiler/typed:Seq", ptr %l61
  %t92 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Seq" %t91, ptr %t92
  store { i64, [5 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 0
  store i64 12, ptr %t94
  %t95 = load %"compiler/source:Span", ptr %l55
  %t96 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t95, 0
  %t97 = load i32, ptr %l56, !tbaa !23
  %t98 = insertvalue { %"compiler/source:Span", i32, ptr } %t96, i32 %t97, 1
  %t100 = insertvalue { %"compiler/source:Span", i32, ptr } %t98, ptr %t92, 2
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t100, ptr %t101
  %t102 = load { i64, [5 x i64] }, ptr %t93
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t102, ptr %t104
  store ptr %t104, ptr %l10, !tbaa !29
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t108 = getelementptr %"compiler/check:frame", ptr %t106, i32 0, i32 28
  %t110 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t108)
  store i64 %t110, ptr %l67
  br label %bb16
bb16:
  %t111 = load i64, ptr %l67, !tbaa !24
  store i64 %t111, ptr %l11, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t114 = load i64, ptr %l5, !tbaa !24
  %t115 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v2, ptr %t112, { i64, ptr } %t113, i64 %t114, i64 %t115)
  br label %bb17
bb17:
  %t120 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l72
  br label %bb18
bb18:
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %t122
  store ptr %t122, ptr %l12, !tbaa !29
  %t124 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i64, ptr %l5, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %s2, ptr %t130, i64 %t131, i64 %t132)
  store { i64, ptr } %t136, ptr %l80
  br label %bb21
bb20:
  br label %bb30
bb21:
  %t137 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t137, ptr %l13, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t138, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l16, !tbaa !24
  br label %bb22
bb22:
  %t144 = load i64, ptr %l15, !tbaa !24
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb23, label %bb24
bb23:
  br label %bb29
bb24:
  br label %bb25
bb25:
  %t152 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t152, ptr %l88, !tbaa !27
  %t153 = load i64, ptr %l15, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr ptr, ptr %t156, i64 %t153
  %t158 = load ptr, ptr %t157, !tbaa !39
  %t160 = load ptr, ptr %l12, !tbaa !29
  store ptr %t160, ptr %l91, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t164 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t165 = load ptr, ptr %l12, !tbaa !29
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v2, ptr %s2, ptr %v0, ptr %v0, ptr %t161, ptr %t158, i32 %t163, i1 false, { i64, ptr } %t164, ptr %t165)
  store ptr %t171, ptr %l97
  br label %bb26
bb26:
  %t172 = load ptr, ptr %l91, !tbaa !29
  %t173 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v0, ptr %t172, ptr %t173)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t174 = load i64, ptr %l15, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l15, !tbaa !24
  br label %bb22
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t180 = load ptr, ptr %l12, !tbaa !29
  %t181 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseRules(ptr %v0, ptr %v2, ptr %v0, ptr %t178, { i64, ptr } %t179, ptr %t180, i1 false, i32 %t181)
  store i1 %t186, ptr %l104
  br label %bb31
bb31:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i64, ptr %l8, !tbaa !24
  %t189 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandlesContracts(ptr %v0, ptr %v0, ptr %t187, i64 %t188, ptr %t189)
  br label %bb32
bb32:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i64, ptr %l5, !tbaa !24
  %t195 = load i64, ptr %l11, !tbaa !24
  %t196 = load ptr, ptr %l12, !tbaa !29
  %t201 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v0, ptr %t193, i64 %t194, i64 %t195, ptr %t196)
  store i64 %t201, ptr %l112
  br label %bb33
bb33:
  %t202 = load i64, ptr %l112, !tbaa !24
  store i64 %t202, ptr %l18, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l113, !tbaa !29
  %t204 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t205 = load i32, ptr %t204, !tbaa !23
  %t206 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t207 = load i32, ptr %t206, !tbaa !23
  %t209 = add i32 %t207, 3
  %t212 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t205, i32 %t209)
  store %"compiler/source:Span" %t212, ptr %l117
  br label %bb34
bb34:
  %t213 = load i64, ptr %l5, !tbaa !24
  %t214 = load i64, ptr %l18, !tbaa !24
  %t215 = load ptr, ptr %l113, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l117
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %t215, %"compiler/source:Span" %t216, i64 %t213, i64 %t214)
  br label %bb35
bb35:
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l120, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t220, ptr %l121
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l122
  %t222 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t222, ptr %l123, !tbaa !23
  %t223 = load ptr, ptr %l10, !tbaa !29
  store ptr %t223, ptr %l125, !tbaa !29
  %t225 = load ptr, ptr %l12, !tbaa !29
  %t227 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v0, ptr %t225)
  store { i64, ptr } %t227, ptr %l127
  br label %bb36
bb36:
  %t228 = load i64, ptr %l18, !tbaa !24
  %t230 = icmp sgt i64 %t228, 0
  %t231 = load ptr, ptr %l125, !tbaa !29
  %t232 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t234 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t231, { i64, ptr } %t232, i1 false, i1 false, i1 %t230)
  store %"compiler/typed:Try" %t234, ptr %l130
  br label %bb37
bb37:
  %t235 = load %"compiler/typed:Try", ptr %l130
  %t236 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t235, ptr %t236
  store { i64, [5 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 0
  store i64 14, ptr %t238
  %t239 = load %"compiler/source:Span", ptr %l122
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t239, 0
  %t241 = load i32, ptr %l123, !tbaa !23
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, i32 %t241, 1
  %t244 = insertvalue { %"compiler/source:Span", i32, ptr } %t242, ptr %t236, 2
  %t245 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t244, ptr %t245
  %t246 = load { i64, [5 x i64] }, ptr %t237
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t246, ptr %t248
  store { i64, [3 x i64] } zeroinitializer, ptr %t249
  %t250 = getelementptr { i64, [3 x i64] }, ptr %t249, i32 0, i32 0
  store i64 2, ptr %t250
  %t251 = load %"compiler/source:Span", ptr %l121
  %t252 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t251, 0
  %t254 = insertvalue { %"compiler/source:Span", ptr } %t252, ptr %t248, 1
  %t255 = getelementptr { i64, [3 x i64] }, ptr %t249, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t254, ptr %t255
  %t256 = load { i64, [3 x i64] }, ptr %t249
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t256, ptr %t258
  %t259 = load ptr, ptr %l120, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t259, ptr %t258)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i32
  %l26 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t18, i32 0, i32 3
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 3}
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l13, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l18
  br label %bb11
bb11:
  %t36 = load i1, ptr %l18, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l24
  br label %bb14
bb13:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb16
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l26
  br label %bb15
bb15:
  %t50 = load i32, ptr %l24, !tbaa !23
  %t51 = load i32, ptr %l26, !tbaa !23
  %t52 = icmp eq i32 %t50, %t51
  store i1 %t52, ptr %l19, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l19, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l30, !tbaa !24
  %t58 = load i64, ptr %l30, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l31, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l30, !tbaa !24
  %t68 = mul i64 %t67, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t64, ptr %t66, i64 %t68, i1 false)
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t69, ptr %l29, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e722c21055ee6b49_58bcebf0b772fb7d)
  unreachable
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_eca48244095fc078_aacf4c954a6e214c)
  unreachable
bb31:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l32, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t72)
  store i32 %t75, ptr %l35
  br label %bb32
bb32:
  %t76 = load ptr, ptr %l32, !tbaa !29
  %t77 = load i32, ptr %l35, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v2, ptr %t76, i32 %t77)
  store { i64, ptr } %t78, ptr %l36
  br label %bb33
bb33:
  %t79 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArgCountMet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, %"compiler/names:Ref" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/names:Ref"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i32
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l41 = alloca i1
  %l45 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/diagmsg:Msg"
  %l55 = alloca i64
  %l62 = alloca i1
  %l67 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/diagmsg:Msg"
  %l76 = alloca i64
  %l80 = alloca i1
  %l83 = alloca i1
  %l88 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i64
  %l97 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l103 = alloca %"compiler/source:Span"
  %l107 = alloca %"compiler/diagmsg:Msg"
  %l108 = alloca i64
  %l120 = alloca i64
  %l123 = alloca i64
  %l141 = alloca { i64, ptr }
  %l144 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i64
  %l151 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca { i64, [3 x i64] }
  %l157 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/names:Ref" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t6 = load i64, ptr %t5, !tbaa !24
  %t7 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t12 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t4, i64 %t6, i64 %t8)
  store i32 %t12, ptr %l19
  br label %bb1
bb1:
  %t13 = load i32, ptr %l19, !tbaa !23
  store i32 %t13, ptr %l4, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l4, !tbaa !23
  %t23 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t19, i32 %t20)
  store i64 %t23, ptr %l24
  br label %bb2
bb2:
  %t24 = load i64, ptr %l24, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t26, ptr %l26, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = sub i64 %t29, 1
  %t33 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i32, ptr %t34, i64 %t31
  %t36 = load i32, ptr %t35, !tbaa !33
  %t39 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t25, i32 %t36)
  store { i64, ptr } %t39, ptr %l31
  br label %bb3
bb3:
  %t40 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t40, ptr %l6, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb4, label %bb5
bb4:
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t49, ptr %l37, !tbaa !27
  %t50 = load i64, ptr %l7, !tbaa !24
  %t52 = sub i64 %t50, 1
  %t54 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  %t59 = call i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v2, ptr %t57)
  store i1 %t59, ptr %l41
  br label %bb6
bb5:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb7
bb6:
  %t60 = load i1, ptr %l41, !tbaa !21
  store i1 %t60, ptr %l36, !tbaa !21
  br label %bb7
bb7:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb8, label %bb9
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load i32, ptr %l4, !tbaa !23
  %t69 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasErrParam(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l45
  br label %bb10
bb9:
  br label %bb17
bb10:
  %t70 = load i1, ptr %l45, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb11, label %bb12
bb11:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l47, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t74, ptr %l48, !tbaa !27
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = sub i64 %t75, 1
  %t79 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t77
  %t82 = load ptr, ptr %t81, !tbaa !39
  %t84 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t82)
  store %"compiler/source:Span" %t84, ptr %l52
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t85 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t87 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrSetArgUnwanted(ptr %v0, ptr %v0, { i64, ptr } %t85)
  store %"compiler/diagmsg:Msg" %t87, ptr %l54
  br label %bb14
bb14:
  %t88 = load ptr, ptr %l47, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l52
  %t90 = load %"compiler/diagmsg:Msg", ptr %l54
  %t91 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t88, %"compiler/source:Span" %t89, %"compiler/diagmsg:Msg" %t90)
  store i64 %t91, ptr %l55
  br label %bb15
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = sub i64 %t93, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t101 = load i32, ptr %l4, !tbaa !23
  %t104 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasErrParam(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l62
  br label %bb18
bb18:
  %t105 = load i1, ptr %l62, !tbaa !21
  br i1 %t105, label %bb19, label %bb20
bb19:
  %t106 = load i64, ptr %l5, !tbaa !24
  %t108 = sub i64 %t106, 1
  store i64 %t108, ptr %l5, !tbaa !24
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t110 = load i64, ptr %l5, !tbaa !24
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb22, label %bb23
bb22:
  %t114 = load i64, ptr %l7, !tbaa !24
  %t116 = icmp sgt i64 %t114, 0
  store i1 %t116, ptr %l67, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t118 = load i1, ptr %l67, !tbaa !21
  br i1 %t118, label %bb25, label %bb26
bb25:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l70, !tbaa !29
  %t120 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t120, ptr %l71, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 0
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t124)
  store %"compiler/source:Span" %t126, ptr %l73
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t127 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t129 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v0, { i64, ptr } %t127)
  store %"compiler/diagmsg:Msg" %t129, ptr %l75
  br label %bb28
bb28:
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l73
  %t132 = load %"compiler/diagmsg:Msg", ptr %l75
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t130, %"compiler/source:Span" %t131, %"compiler/diagmsg:Msg" %t132)
  store i64 %t133, ptr %l76
  br label %bb29
bb29:
  store i1 false, ptr %rv
  br label %ret
bb30:
  %t135 = load i64, ptr %l5, !tbaa !24
  %t137 = icmp sgt i64 %t135, 0
  br i1 %t137, label %bb31, label %bb32
bb31:
  %t139 = load i64, ptr %l7, !tbaa !24
  %t141 = icmp sgt i64 %t139, 0
  store i1 %t141, ptr %l80, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb33
bb33:
  %t143 = load i1, ptr %l80, !tbaa !21
  br i1 %t143, label %bb34, label %bb35
bb34:
  %t144 = load i64, ptr %l5, !tbaa !24
  %t145 = load i64, ptr %l7, !tbaa !24
  %t148 = icmp ne i64 %t144, %t145
  store i1 %t148, ptr %l83, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb36
bb36:
  %t150 = load i1, ptr %l83, !tbaa !21
  %t151 = xor i1 %t150, true
  br i1 %t151, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb43
bb38:
  %t153 = load i64, ptr %l7, !tbaa !24
  %t154 = load i64, ptr %l5, !tbaa !24
  %t157 = icmp slt i64 %t153, %t154
  br i1 %t157, label %bb39, label %bb40
bb39:
  %t159 = load i64, ptr %l7, !tbaa !24
  store i64 %t159, ptr %l93, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t164 = load i32, ptr %l4, !tbaa !23
  %t167 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMinArity(ptr %v0, ptr %t163, i32 %t164)
  store i64 %t167, ptr %l97
  br label %bb41
bb40:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb42
bb41:
  %t168 = load i64, ptr %l93, !tbaa !24
  %t169 = load i64, ptr %l97, !tbaa !24
  %t170 = icmp sge i64 %t168, %t169
  store i1 %t170, ptr %l92, !tbaa !21
  br label %bb42
bb42:
  %t172 = load i1, ptr %l92, !tbaa !21
  store i1 %t172, ptr %l88, !tbaa !21
  br label %bb43
bb43:
  %t173 = load i1, ptr %l88, !tbaa !21
  br i1 %t173, label %bb44, label %bb45
bb44:
  store i1 true, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l100, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t176, ptr %l101, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr ptr, ptr %t178, i64 0
  %t180 = load ptr, ptr %t179, !tbaa !39
  %t182 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t180)
  store %"compiler/source:Span" %t182, ptr %l103
  br label %bb47
bb47:
  %t183 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t184 = load i64, ptr %l5, !tbaa !24
  %t185 = load i64, ptr %l7, !tbaa !24
  %t189 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v0, { i64, ptr } %t183, i64 %t184, i64 %t185)
  store %"compiler/diagmsg:Msg" %t189, ptr %l107
  br label %bb48
bb48:
  %t190 = load ptr, ptr %l100, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l103
  %t192 = load %"compiler/diagmsg:Msg", ptr %l107
  %t193 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t190, %"compiler/source:Span" %t191, %"compiler/diagmsg:Msg" %t192)
  store i64 %t193, ptr %l108
  br label %bb49
bb49:
  %t194 = load i64, ptr %l108, !tbaa !24
  store i64 %t194, ptr %l8, !tbaa !24
  %t195 = load i64, ptr %l5, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp sge i64 %t195, %t198
  br i1 %t201, label %bb50, label %bb51
bb50:
  store i1 false, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  store i64 0, ptr %l9, !tbaa !24
  %t204 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t208 = sub i64 %t206, 1
  store i64 %t208, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t210 = load i64, ptr %l10, !tbaa !24
  %t211 = load i64, ptr %l9, !tbaa !24
  %t214 = icmp sgt i64 %t210, %t211
  br i1 %t214, label %bb53, label %bb54
bb53:
  %t216 = load i64, ptr %l11, !tbaa !24
  %t218 = icmp sgt i64 %t216, 0
  br i1 %t218, label %bb55, label %bb56
bb54:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb58
bb55:
  %t220 = load i64, ptr %l10, !tbaa !24
  %t221 = load i64, ptr %l9, !tbaa !24
  %t224 = sub i64 %t220, %t221
  %t225 = load i64, ptr %l11, !tbaa !24
  %t228 = add i64 %t224, %t225
  %t230 = sub i64 %t228, 1
  %t231 = load i64, ptr %l11, !tbaa !24
  %t234 = sdiv i64 %t230, %t231
  store i64 %t234, ptr %l123, !tbaa !24
  br label %bb57
bb56:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb57
bb57:
  %t236 = load i64, ptr %l123, !tbaa !24
  store i64 %t236, ptr %l120, !tbaa !24
  br label %bb58
bb58:
  %t237 = load i64, ptr %l120, !tbaa !24
  store i64 %t237, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb59
bb59:
  %t238 = load i64, ptr %l13, !tbaa !24
  %t239 = load i64, ptr %l12, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb60, label %bb61
bb60:
  br label %bb72
bb61:
  br label %bb62
bb62:
  %t246 = load i64, ptr %l9, !tbaa !24
  %t247 = load i64, ptr %l13, !tbaa !24
  %t248 = load i64, ptr %l11, !tbaa !24
  %t251 = mul i64 %t247, %t248
  %t254 = add i64 %t246, %t251
  store i64 %t254, ptr %l14, !tbaa !24
  %t256 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t256, ptr %l141, !tbaa !27
  %t257 = load i64, ptr %l14, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr ptr, ptr %t260, i64 %t257
  %t262 = load ptr, ptr %t261, !tbaa !39
  %t264 = call i1 @compiler_2fcheck_2eisFuncTypeRef(ptr %v2, ptr %t262)
  store i1 %t264, ptr %l144
  br label %bb63
bb63:
  %t265 = load i1, ptr %l144, !tbaa !21
  %t266 = xor i1 %t265, true
  br i1 %t266, label %bb64, label %bb65
bb64:
  br label %bb71
bb65:
  br label %bb66
bb66:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 0
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = getelementptr %"compiler/load:Loader", ptr %t274, i32 0, i32 4
  %t277 = load ptr, ptr %t276, !tbaa !29
  store ptr %t277, ptr %l149, !tbaa !29
  %t278 = load i64, ptr %l8, !tbaa !24
  store i64 %t278, ptr %l150, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l151, !tbaa !29
  %t280 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t280, ptr %l152, !tbaa !27
  %t281 = load i64, ptr %l14, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr ptr, ptr %t284, i64 %t281
  %t286 = load ptr, ptr %t285, !tbaa !39
  %t288 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t286)
  store %"compiler/source:Span" %t288, ptr %l155
  br label %bb67
bb67:
  %t289 = load ptr, ptr %l151, !tbaa !29
  %t290 = load %"compiler/source:Span", ptr %l155
  %t291 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t289, %"compiler/source:Span" %t290)
  store { i64, [3 x i64] } %t291, ptr %l156
  br label %bb68
bb68:
  %t292 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteGroupFunctionType(ptr %v0)
  store %"compiler/diagmsg:Msg" %t292, ptr %l157
  br label %bb69
bb69:
  %t293 = load ptr, ptr %l149, !tbaa !29
  %t294 = load i64, ptr %l150, !tbaa !24
  %t295 = load { i64, [3 x i64] }, ptr %l156
  %t296 = load %"compiler/diagmsg:Msg", ptr %l157
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t293, i64 %t294, { i64, [3 x i64] } %t295, %"compiler/diagmsg:Msg" %t296)
  br label %bb70
bb70:
  br label %bb72
bb71:
  %t297 = load i64, ptr %l13, !tbaa !24
  %t299 = add i64 %t297, 1
  store i64 %t299, ptr %l13, !tbaa !24
  br label %bb59
bb72:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, ptr %a5, i32 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l19 = alloca ptr
  %l24 = alloca i32
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca ptr
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca i32
  %l69 = alloca i64
  %l73 = alloca ptr
  %l78 = alloca %"compiler/typed:Bind"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t101 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  store ptr %a5, ptr %l5
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l6, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t7, %"compiler/source:Span" %t8, i32 %t9, i64 0)
  store ptr %t13, ptr %l19
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load ptr, ptr %l19, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t17 = load i32, ptr %l6, !tbaa !23
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %t15, %"compiler/source:Span" %t16, i32 %t17, ptr %a2)
  store i32 %t23, ptr %l24
  br label %bb5
bb5:
  %t24 = load i32, ptr %l24, !tbaa !23
  store i32 %t24, ptr %l8, !tbaa !23
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp eq i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t31, %"compiler/source:Span" %t32, i32 %t33, i64 0)
  store ptr %t37, ptr %l31
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load ptr, ptr %l31, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v4, ptr %t39, %"compiler/source:Span" %t40, ptr %t41)
  store ptr %t45, ptr %l35
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l35, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l36, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l37
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t49, ptr %l38, !tbaa !23
  store i32 44, ptr %l39
  store ptr %t46, ptr %l40, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  %t53 = load i32, ptr %l8, !tbaa !23
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t51, %"compiler/source:Span" %t52, i32 %t53, i64 0)
  store ptr %t57, ptr %l44
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l44, !tbaa !29
  %t59 = load ptr, ptr %l36, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l37
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = load i32, ptr %l39, !range !{i32 0, i32 52}
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v4, ptr %v0, ptr %v4, ptr %t59, %"compiler/source:Span" %t60, i32 %t61, i32 %t62, ptr %t63, ptr %t58)
  store ptr %t65, ptr %l46
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l46, !tbaa !29
  store ptr %t66, ptr %l10, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t71, ptr %l49
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t73, ptr %l50
  br label %bb14
bb14:
  %t74 = load i1, ptr %l50, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l52, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t78, ptr %l53
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t85 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t79, %"compiler/source:Span" %t80, ptr %t81)
  store ptr %t85, ptr %l57
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l53
  %t89 = load ptr, ptr %l57, !tbaa !29
  %t92 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v2, ptr %v0, ptr %t87, %"compiler/source:Span" %t88, ptr %t89, i32 %t86, i32 0)
  store ptr %t92, ptr %l60
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l60, !tbaa !29
  store ptr %t93, ptr %l11, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l61, !tbaa !29
  %t95 = load i32, ptr %l3, !tbaa !23
  store i32 %t95, ptr %l62, !tbaa !23
  store %"compiler/source:Span" %a4, ptr %l63
  %t97 = load ptr, ptr %l11, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t97)
  store i32 %t100, ptr %l66
  br label %bb19
bb19:
  store { i64, [1 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [1 x i64] }, ptr %t101, i32 0, i32 0
  store i64 4, ptr %t102
  %t103 = load { i64, [1 x i64] }, ptr %t101
  %t104 = load ptr, ptr %l61, !tbaa !29
  %t105 = load i32, ptr %l62, !tbaa !23
  %t106 = load %"compiler/source:Span", ptr %l63
  %t107 = load i32, ptr %l66, !tbaa !23
  %t110 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t104, i32 %t105, %"compiler/source:Span" %t106, i32 %t107, i32 4, { i64, [1 x i64] } %t103)
  store i64 %t110, ptr %l69
  br label %bb20
bb20:
  %t111 = load i64, ptr %l69, !tbaa !24
  store i64 %t111, ptr %l12, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l12, !tbaa !24
  %t114 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t112, i64 %t113, ptr %t114)
  br label %bb21
bb21:
  store ptr %a7, ptr %l73, !tbaa !29
  %t119 = load i64, ptr %l12, !tbaa !24
  %t121 = trunc i64 %t119 to i32
  %t123 = load ptr, ptr %l11, !tbaa !29
  %t126 = call %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v3, i32 %t121, ptr %t123)
  store %"compiler/typed:Bind" %t126, ptr %l78
  br label %bb22
bb22:
  %t127 = load %"compiler/typed:Bind", ptr %l78
  %t128 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store %"compiler/typed:Bind" %t127, ptr %t128
  %t129 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v3, ptr %v3, ptr %t129, ptr %t128)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l10, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t131, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCycle(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca ptr
  %l50 = alloca i1
  %l58 = alloca i64
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 20
  store ptr %t5, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l19, !tbaa !24
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l21
  br label %bb3
bb3:
  %t11 = load i64, ptr %l19, !tbaa !24
  %t12 = load i64, ptr %l21, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb33
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l26
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l26, !tbaa !29
  store ptr %t22, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t25 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  %t30 = icmp eq i64 %t26, %a1
  br i1 %t30, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t32 = load i1, ptr %l3, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb13
bb12:
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = icmp slt i64 %t39, 0
  store i1 %t41, ptr %l33, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l33, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  br label %bb32
bb15:
  br label %bb16
bb16:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 18
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t49 = getelementptr %"compiler/check:frame", ptr %t47, i32 0, i32 0
  %t50 = load i64, ptr %t49, !tbaa !24
  %t53 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t46, i64 %t50)
  store ptr %t53, ptr %l41
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l41, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Body", ptr %t54, i32 0, i32 1
  %t57 = load { i64, [2 x i64] }, ptr %t56
  %t61 = extractvalue { i64, [2 x i64] } %t57, 0
  %t62 = icmp eq i64 %t61, 6
  br i1 %t62, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = getelementptr %"compiler/check:frame", ptr %t64, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  %t72 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l2, i64 %t67)
  store i1 %t72, ptr %l50
  br label %bb21
bb21:
  %t73 = load i1, ptr %l50, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb22, label %bb23
bb22:
  %t76 = load ptr, ptr %l6, !tbaa !29
  %t78 = getelementptr %"compiler/check:frame", ptr %t76, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t79)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_397e0346551c6f2f_92a3e28505cb4413)
  unreachable
bb31:
  br label %bb32
bb32:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l5, !tbaa !24
  br label %bb2
bb33:
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t87, ptr %l58
  br label %bb34
bb34:
  %t88 = load i64, ptr %l58, !tbaa !24
  %t89 = icmp eq i64 %t88, 0
  br i1 %t89, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb36:
  br label %bb37
bb37:
  %t91 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %l60
  br label %bb38
bb38:
  %t92 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t94, ptr %l62
  br label %bb39
bb39:
  %t95 = load i64, ptr %l62, !tbaa !24
  store i64 %t95, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t100 = icmp sgt i64 %t96, %t97
  br i1 %t100, label %bb40, label %bb41
bb40:
  %t102 = load i64, ptr %l12, !tbaa !24
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb45
bb42:
  %t106 = load i64, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = sub i64 %t106, %t107
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = add i64 %t110, %t111
  %t116 = sub i64 %t114, 1
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = sdiv i64 %t116, %t117
  store i64 %t120, ptr %l69, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb44
bb44:
  %t122 = load i64, ptr %l69, !tbaa !24
  store i64 %t122, ptr %l66, !tbaa !24
  br label %bb45
bb45:
  %t123 = load i64, ptr %l66, !tbaa !24
  store i64 %t123, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb46
bb46:
  %t124 = load i64, ptr %l14, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t128 = icmp slt i64 %t124, %t125
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb47, label %bb48
bb47:
  br label %bb52
bb48:
  br label %bb49
bb49:
  %t132 = load i64, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l12, !tbaa !24
  %t137 = mul i64 %t133, %t134
  %t140 = add i64 %t132, %t137
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t140)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t145 = load i64, ptr %l14, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l14, !tbaa !24
  br label %bb46
bb52:
  %t149 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %s0, ptr %s0, ptr %t149, ptr %l2, ptr %l9, i64 0)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunspreadAll(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l44 = alloca i64
  %l48 = alloca { i64, ptr }
  %l51 = alloca i32
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l14, !tbaa !24
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load i64, ptr %l14, !tbaa !24
  %t16 = icmp sle i64 %t15, 2305843009213693951
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_b692ddd8e2182d13_c763079e5a61942f)
  unreachable
bb6:
  %t18 = load i64, ptr %l14, !tbaa !24
  %t19 = mul i64 %t18, 4
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t23, ptr %lp2
  %t25 = load ptr, ptr %lp2
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b692ddd8e2182d13_c763079e5a61942f)
  unreachable
bb8:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb13
bb10:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l26, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l26, !tbaa !24
  store i64 %t56, ptr %l23, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l23, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  br label %bb20
bb16:
  br label %bb17
bb17:
  %t66 = load i64, ptr %l3, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l5, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l8, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  store i64 %t76, ptr %l44, !tbaa !24
  %t79 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t83, ptr %l48, !tbaa !27
  %t84 = load i64, ptr %l8, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i32, ptr %t87, i64 %t84
  %t89 = load i32, ptr %t88, !tbaa !33
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnspread(ptr %v0, ptr %t82, i32 %t89)
  store i32 %t92, ptr %l51
  br label %bb18
bb18:
  %t93 = load i32, ptr %l51, !tbaa !23
  %t94 = load ptr, ptr %lp2
  %t95 = load i64, ptr %l44, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t95
  store i32 %t93, ptr %t98, !tbaa !33
  br label %bb19
bb19:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l7, !tbaa !24
  br label %bb14
bb20:
  %t103 = load ptr, ptr %lp2
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eweakRow(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/check:weakPlace" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:weakPlace"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, [3 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca i1
  %l33 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/check:weakPlace" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t6 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = trunc i64 %t7 to i32
  %t13 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t5, i32 %t9)
  store i32 %t13, ptr %l15
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t14, i32 %t15)
  store { i64, ptr } %t16, ptr %l16
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 6
  %t24 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H243102d099229a8f815a09f79cb8b122(ptr %v0, ptr %s0, ptr %t23, i64 %t25)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l23
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb4, label %ok.32, !prof !99
ok.32:
  store { i64, ptr } %t29, ptr %l22
  br label %bb3
bb3:
  %t33 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l25, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t46, ptr %l17, !tbaa !27
  br label %bb6
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t47, ptr %l17, !tbaa !27
  br label %bb6
bb6:
  %t49 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l28, !tbaa !24
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l28, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t62, ptr %l3, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t63, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t65, ptr %l31
  br label %bb7
bb7:
  %t66 = load i1, ptr %l31, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb8, label %bb9
bb8:
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t73 = extractvalue { i64, ptr } %t69, 1
  %t74 = extractvalue { i64, ptr } %t69, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t70, i64 %t71)
  %t80 = getelementptr i8, ptr %t79, i64 %t71
  call void @olang_textcopy(ptr %t80, ptr %t73, i64 %t74)
  %t81 = getelementptr i8, ptr %t80, i64 %t74
  call void @olang_textcopy(ptr %t81, ptr %t76, i64 %t77)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t79, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l33, !tbaa !27
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb10
bb10:
  %t92 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t92, ptr %l4, !tbaa !27
  %t93 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 0
  %t94 = load { i64, [3 x i64] }, ptr %t93
  store { i64, [3 x i64] } %t94, ptr %l5
  %t96 = load { i64, [3 x i64] }, ptr %l5
  %t98 = extractvalue { i64, [3 x i64] } %t96, 0
  %t99 = icmp eq i64 %t98, 3
  br i1 %t99, label %bb11, label %bb12
bb11:
  %t101 = getelementptr { i64, [3 x i64] }, ptr %l5, i32 0, i32 1
  %t102 = getelementptr { i64, i64, i64 }, ptr %t101, i32 0, i32 0
  %t103 = load i64, ptr %t102
  store i64 %t103, ptr %l6, !tbaa !24
  %t105 = getelementptr { i64, [3 x i64] }, ptr %l5, i32 0, i32 1
  %t106 = getelementptr { i64, i64, i64 }, ptr %t105, i32 0, i32 1
  %t107 = load i64, ptr %t106
  store i64 %t107, ptr %l7, !tbaa !24
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 4
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i64, ptr %l6, !tbaa !24
  %t120 = load i64, ptr %l7, !tbaa !24
  %t124 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s0, ptr %t118, i64 %t119, i64 %t120)
  store { i64, ptr } %t124, ptr %l49
  br label %bb14
bb14:
  %t125 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t125, ptr %l38, !tbaa !27
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l50, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t126, ptr %l38, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e30e75934041bac1_8633653d6080ffc5)
  unreachable
bb20:
  %t128 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  store i64 %t129, ptr %l52, !tbaa !24
  %t130 = load i64, ptr %l52, !tbaa !24
  %t131 = mul i64 %t130, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t131)
  %t133 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  store { i64, ptr } %t134, ptr %l53, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = load i64, ptr %l52, !tbaa !24
  %t140 = mul i64 %t139, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t136, ptr %t138, i64 %t140, i1 false)
  %t141 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t143 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t147 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 1
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t141, 1
  %t151 = extractvalue { i64, ptr } %t141, 0
  %t152 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t154 = add i64 %t151, %t153
  %t156 = extractvalue { i64, ptr } %t144, 1
  %t157 = extractvalue { i64, ptr } %t144, 0
  %t158 = add i64 %t154, %t157
  %t159 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t163 = extractvalue { i64, ptr } %t145, 1
  %t164 = extractvalue { i64, ptr } %t145, 0
  %t165 = add i64 %t161, %t164
  %t166 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t168 = add i64 %t165, %t167
  %t170 = extractvalue { i64, ptr } %t146, 1
  %t171 = extractvalue { i64, ptr } %t146, 0
  %t172 = add i64 %t168, %t171
  %t173 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t177 = extractvalue { i64, ptr } %t148, 1
  %t178 = extractvalue { i64, ptr } %t148, 0
  %t179 = add i64 %t175, %t178
  %t180 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t182 = add i64 %t179, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t150, i64 %t151)
  %t184 = getelementptr i8, ptr %t183, i64 %t151
  call void @olang_textcopy(ptr %t184, ptr %t152, i64 %t153)
  %t185 = getelementptr i8, ptr %t184, i64 %t153
  call void @olang_textcopy(ptr %t185, ptr %t156, i64 %t157)
  %t186 = getelementptr i8, ptr %t185, i64 %t157
  call void @olang_textcopy(ptr %t186, ptr %t159, i64 %t160)
  %t187 = getelementptr i8, ptr %t186, i64 %t160
  call void @olang_textcopy(ptr %t187, ptr %t163, i64 %t164)
  %t188 = getelementptr i8, ptr %t187, i64 %t164
  call void @olang_textcopy(ptr %t188, ptr %t166, i64 %t167)
  %t189 = getelementptr i8, ptr %t188, i64 %t167
  call void @olang_textcopy(ptr %t189, ptr %t170, i64 %t171)
  %t190 = getelementptr i8, ptr %t189, i64 %t171
  call void @olang_textcopy(ptr %t190, ptr %t173, i64 %t174)
  %t191 = getelementptr i8, ptr %t190, i64 %t174
  call void @olang_textcopy(ptr %t191, ptr %t177, i64 %t178)
  %t192 = getelementptr i8, ptr %t191, i64 %t178
  call void @olang_textcopy(ptr %t192, ptr %t180, i64 %t181)
  %t193 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t183, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t194, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l47 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l81 = alloca i1
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca { i64, ptr }
  %l94 = alloca i1
  %l100 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l12, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l14
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l14, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l17
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_261e3060da575f7_c13e4a553a852783)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t46 = add i64 %t40, %t43
  %t47 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = sext i32 %t48 to i64
  %t53 = icmp sle i64 %t46, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb7, label %bb8
bb7:
  br label %bb50
bb8:
  br label %bb9
bb9:
  %t57 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t57, ptr %l35, !tbaa !27
  %t58 = load i64, ptr %l5, !tbaa !24
  store i64 %t58, ptr %l36, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t65 = add i64 %t59, %t62
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l41, !tbaa !24
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sge i64 %t68, 0
  br i1 %t69, label %bb10, label %bb11
bb10:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l40, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1591269354839ba0_3246c27539059c2c)
  unreachable
bb12:
  %t75 = load i64, ptr %l40, !tbaa !24
  %t76 = load i64, ptr %l41, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1591269354839ba0_3246c27539059c2c)
  unreachable
bb14:
  %t79 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l36, !tbaa !24
  %t82 = load i64, ptr %l40, !tbaa !24
  %t83 = getelementptr i8, ptr %t80, i64 %t81
  %t84 = sub i64 %t82, %t81
  %t85 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t86, { i64, ptr } %t87)
  store i1 %t90, ptr %l47
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1591269354839ba0_3246c27539059c2c)
  unreachable
bb16:
  %t91 = load i1, ptr %l47, !tbaa !21
  br i1 %t91, label %bb17, label %bb18
bb17:
  %t92 = load i64, ptr %l5, !tbaa !24
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb19, label %bb20
bb18:
  br label %bb48
bb19:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb29
bb20:
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t96, ptr %l51, !tbaa !27
  %t97 = load i64, ptr %l5, !tbaa !24
  %t99 = sub i64 %t97, 1
  %t101 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i8, ptr %t102, i64 %t99
  %t104 = load i8, ptr %t103, !tbaa !32
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t104)
  store i1 %t106, ptr %l55
  br label %bb21
bb21:
  %t107 = load i1, ptr %l55, !tbaa !21
  br i1 %t107, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb25
bb23:
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t108, ptr %l57, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t109, 1
  %t113 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t116)
  store i1 %t118, ptr %l61
  br label %bb24
bb24:
  %t119 = load i1, ptr %l61, !tbaa !21
  store i1 %t119, ptr %l56, !tbaa !21
  br label %bb25
bb25:
  %t120 = load i1, ptr %l56, !tbaa !21
  br i1 %t120, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb28
bb27:
  %t121 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t121, ptr %l63, !tbaa !27
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = sub i64 %t122, 1
  %t126 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = icmp eq i8 %t129, 95
  store i1 %t131, ptr %l62, !tbaa !21
  br label %bb28
bb28:
  %t133 = load i1, ptr %l62, !tbaa !21
  %t134 = xor i1 %t133, true
  store i1 %t134, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t136 = load i1, ptr %l50, !tbaa !21
  store i1 %t136, ptr %l6, !tbaa !21
  %t137 = load i64, ptr %l5, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t143 = add i64 %t137, %t140
  store i64 %t143, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l7, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t151 = icmp sge i64 %t145, %t148
  br i1 %t151, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb40
bb31:
  %t153 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t153, ptr %l78, !tbaa !27
  %t154 = load i64, ptr %l7, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i8, ptr %t157, i64 %t154
  %t159 = load i8, ptr %t158, !tbaa !32
  %t161 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t159)
  store i1 %t161, ptr %l81
  br label %bb32
bb32:
  %t162 = load i1, ptr %l81, !tbaa !21
  br i1 %t162, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb36
bb34:
  %t163 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t163, ptr %l83, !tbaa !27
  %t164 = load i64, ptr %l7, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i8, ptr %t167, i64 %t164
  %t169 = load i8, ptr %t168, !tbaa !32
  %t171 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t169)
  store i1 %t171, ptr %l86
  br label %bb35
bb35:
  %t172 = load i1, ptr %l86, !tbaa !21
  store i1 %t172, ptr %l82, !tbaa !21
  br label %bb36
bb36:
  %t173 = load i1, ptr %l82, !tbaa !21
  br i1 %t173, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb39
bb38:
  %t174 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t174, ptr %l88, !tbaa !27
  %t175 = load i64, ptr %l7, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i8, ptr %t178, i64 %t175
  %t180 = load i8, ptr %t179, !tbaa !32
  %t182 = icmp eq i8 %t180, 95
  store i1 %t182, ptr %l87, !tbaa !21
  br label %bb39
bb39:
  %t184 = load i1, ptr %l87, !tbaa !21
  %t185 = xor i1 %t184, true
  store i1 %t185, ptr %l77, !tbaa !21
  br label %bb40
bb40:
  %t187 = load i1, ptr %l77, !tbaa !21
  store i1 %t187, ptr %l8, !tbaa !21
  %t188 = load i1, ptr %l6, !tbaa !21
  br i1 %t188, label %bb41, label %bb42
bb41:
  %t190 = load i1, ptr %l8, !tbaa !21
  store i1 %t190, ptr %l94, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb43
bb43:
  %t192 = load i1, ptr %l94, !tbaa !21
  br i1 %t192, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s3
  %t193 = load i64, ptr %l5, !tbaa !24
  %t195 = trunc i64 %t193 to i32
  %t196 = load i64, ptr %l7, !tbaa !24
  %t198 = trunc i64 %t196 to i32
  %t201 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t195, i32 %t198)
  store %"compiler/source:Span" %t201, ptr %l100
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t202 = load %"compiler/source:Span", ptr %l100
  store %"compiler/source:Span" %t202, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t203 = load i64, ptr %l5, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l5, !tbaa !24
  br label %bb49
bb49:
  br label %bb6
bb50:
  %t207 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t207, ptr %l103
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t208 = load %"compiler/source:Span", ptr %l103
  store %"compiler/source:Span" %t208, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l16 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i32
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i32 %t26, ptr %l16
  br label %bb9
bb9:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l19
  br label %bb10
bb10:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l25
  br label %bb13
bb13:
  %t44 = load i32, ptr %l25, !range !{i32 0, i32 33}
  %t46 = trunc i64 25 to i32
  %t47 = icmp eq i32 %t44, %t46
  store i1 %t47, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l20, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb17
bb16:
  %t50 = load i32, ptr %l3, !tbaa !23
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t54 = icmp eq i32 %t50, %t51
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t56 = load i1, ptr %l28, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  call void @__olang_check_failed(ptr @olang_loc_712f9e4ca30bc6cb_a93275977373a857)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2efoldUnary(i32 %a0, %"compiler/check:litv" %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca %"compiler/check:signMag"
  %l3 = alloca i1
  %l4 = alloca i128
  %l5 = alloca %"compiler/check:litv"
  %l8 = alloca %"compiler/check:litv"
  %l14 = alloca %"compiler/check:litv"
  %l16 = alloca %"compiler/check:signMag"
  %l21 = alloca %"compiler/check:litv"
  %l25 = alloca %"compiler/check:litv"
  %l26 = alloca %"compiler/check:litv"
  %l29 = alloca i1
  %l32 = alloca i1
  %l37 = alloca %"compiler/check:litv"
  %l40 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store i32 %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 0
  %t2 = load i1, ptr %t1, !tbaa !21
  %t4 = xor i1 %t2, true
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t6, ptr %l8
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t7 = load %"compiler/check:litv", ptr %l8
  store %"compiler/check:litv" %t7, ptr %rv
  br label %ret
bb4:
  %t8 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t10 = trunc i64 68 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 1
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb6:
  br label %bb17
bb7:
  %t16 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 4
  %t17 = load double, ptr %t16, !tbaa !26
  %t19 = fneg double %t17
  %t21 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2efloatLit(double %t19)
  store %"compiler/check:litv" %t21, ptr %l14
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t22 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t22, ptr %rv
  br label %ret
bb10:
  %t23 = load %"compiler/check:litv", ptr %l1
  %t25 = call %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %t23)
  store %"compiler/check:signMag" %t25, ptr %l16
  br label %bb11
bb11:
  %t26 = load %"compiler/check:signMag", ptr %l16
  store %"compiler/check:signMag" %t26, ptr %l2
  %t27 = getelementptr %"compiler/check:signMag", ptr %l2, i32 0, i32 0
  %t28 = load i1, ptr %t27, !tbaa !21
  store i1 %t28, ptr %l3, !tbaa !21
  %t30 = getelementptr %"compiler/check:signMag", ptr %l2, i32 0, i32 1
  %t31 = load i128, ptr %t30
  store i128 %t31, ptr %l4
  %t33 = load i128, ptr %l4
  %t35 = icmp ne i128 %t33, 0
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = load i1, ptr %l3, !tbaa !21
  %t39 = xor i1 %t37, true
  %t40 = load i128, ptr %l4
  %t43 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 %t39, i128 %t40)
  store %"compiler/check:litv" %t43, ptr %l25
  br label %bb14
bb13:
  %t44 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 0)
  store %"compiler/check:litv" %t44, ptr %l26
  br label %bb15
bb14:
  %t45 = load %"compiler/check:litv", ptr %l25
  store %"compiler/check:litv" %t45, ptr %l21
  br label %bb16
bb15:
  %t46 = load %"compiler/check:litv", ptr %l26
  store %"compiler/check:litv" %t46, ptr %l21
  br label %bb16
bb16:
  %t47 = load %"compiler/check:litv", ptr %l21
  store %"compiler/check:litv" %t47, ptr %rv
  br label %ret
bb17:
  %t48 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t50 = trunc i64 103 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb18, label %bb19
bb18:
  %t53 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 1
  %t54 = load i1, ptr %t53, !tbaa !21
  %t56 = xor i1 %t54, true
  store i1 %t56, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l29, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  %t59 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t60 = load i1, ptr %t59, !tbaa !21
  %t62 = xor i1 %t60, true
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb23
bb23:
  %t64 = load i1, ptr %l32, !tbaa !21
  br i1 %t64, label %bb24, label %bb25
bb24:
  %t65 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t66 = load i64, ptr %t65, !tbaa !24
  %t68 = xor i64 %t66, -1
  %t70 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t68)
  store %"compiler/check:litv" %t70, ptr %l37
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t71 = load %"compiler/check:litv", ptr %l37
  store %"compiler/check:litv" %t71, ptr %l5
  %t72 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 5
  %t73 = load i1, ptr %t72, !tbaa !21
  %t75 = getelementptr %"compiler/check:litv", ptr %l5, i32 0, i32 5
  store i1 %t73, ptr %t75, !tbaa !21
  %t76 = load %"compiler/check:litv", ptr %l5
  store %"compiler/check:litv" %t76, ptr %rv
  br label %ret
bb27:
  %t78 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t78, ptr %l40
  br label %bb28
bb28:
  %t79 = load %"compiler/check:litv", ptr %l40
  store %"compiler/check:litv" %t79, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l35 = alloca i64
  %l37 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l12
  br label %bb6
bb6:
  %t19 = load i64, ptr %l12, !tbaa !24
  store i64 %t19, ptr %rv
  br label %ret
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 6
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Call", ptr %t35, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Call", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l25, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 0
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t53 = call i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l27
  br label %bb15
bb14:
  store i64 -1, ptr %l23, !tbaa !24
  br label %bb16
bb15:
  %t54 = load i64, ptr %l27, !tbaa !24
  store i64 %t54, ptr %l23, !tbaa !24
  br label %bb16
bb16:
  %t55 = load i64, ptr %l23, !tbaa !24
  store i64 %t55, ptr %rv
  br label %ret
bb17:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 18}
  %t63 = icmp eq i64 %t61, 17
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb19
bb19:
  %t64 = load i1, ptr %l29, !tbaa !21
  br i1 %t64, label %bb20, label %bb21
bb20:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = call i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l35
  br label %bb23
bb23:
  %t74 = load i64, ptr %l35, !tbaa !24
  store i64 %t74, ptr %rv
  br label %ret
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_cf73afff9a9afd3c_75ef637926e6ccb8)
  unreachable
bb29:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v0, ptr %t75)
  store ptr %t77, ptr %l37
  br label %bb30
bb30:
  %t78 = load ptr, ptr %l37, !tbaa !29
  store ptr %t78, ptr %l4, !tbaa !29
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb31, label %bb32
bb31:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = call i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l43
  br label %bb33
bb32:
  store i64 -1, ptr %l41, !tbaa !24
  br label %bb34
bb33:
  %t88 = load i64, ptr %l43, !tbaa !24
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb34
bb34:
  %t89 = load i64, ptr %l41, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ehasName(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t13, i64 %t14)
  store i32 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i32, ptr %l13, !tbaa !23
  %t23 = icmp eq i32 %t18, %a1
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t5 = trunc i64 %a1 to i32
  %t8 = sub i32 %t2, %t5
  %t9 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t13 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t8, i32 %t10)
  store %"compiler/source:Span" %t13, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2enamedFn(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 3}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_a1143936e424f416_6a846c9af99dae82)
  unreachable
bb16:
  %t25 = load i1, ptr %l9, !tbaa !21
  store i1 %t25, ptr %l2, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b0c5dfd122db8337_2ed6598a574b6003)
  unreachable
bb22:
  %t26 = load i1, ptr %l2, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2enullDefault(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l20 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb22
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l4, !tbaa !29
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Catch", ptr %t30, i32 0, i32 3
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp eq i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Catch", ptr %t39, i32 0, i32 3
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t56 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t56, ptr %l35, !tbaa !27
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  %t66 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %t62)
  store i1 %t66, ptr %l39
  br label %bb15
bb15:
  %t67 = load i1, ptr %l39, !tbaa !21
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l6, !tbaa !24
  br label %bb11
bb20:
  br label %bb21
bb21:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l2, !tbaa !24
  br label %bb4
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2eseqInner(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 12
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l1, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Seq", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l5, !tbaa !29
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l5, !tbaa !29
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4e30bf442e6db864_2dc8dbd173b7a7c8)
  unreachable
bb14:
  %t29 = load ptr, ptr %l5, !tbaa !29
  store ptr %t29, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eseqStmts(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sge i64 0, 0
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t7 = icmp sle i64 0, 1152921504606846975
  br i1 %t7, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_ad6c0f271be09e9a_4807a0185ac07486)
  unreachable
bb5:
  %t9 = mul i64 0, 8
  %t10 = insertvalue { i64, ptr } undef, i64 0, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t11, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_ad6c0f271be09e9a_4807a0185ac07486)
  unreachable
bb7:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb8, label %bb9
bb8:
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = load i64, ptr %t17, !range !{i64 0, i64 18}
  %t20 = icmp eq i64 %t18, 12
  store i1 %t20, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l1, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Seq", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l7, !tbaa !27
  br label %bb22
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb17, label %bb18
bb17:
  %t35 = icmp sle i64 0, 1152921504606846975
  br i1 %t35, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_ce22dfd3fa106f6f_943799e8713f3e1b)
  unreachable
bb19:
  %t37 = mul i64 0, 8
  %t38 = insertvalue { i64, ptr } undef, i64 0, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t39, ptr %l7, !tbaa !27
  br label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ce22dfd3fa106f6f_943799e8713f3e1b)
  unreachable
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f37d77d99c26d523_bd045c96961c9007)
  unreachable
bb22:
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t41, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t4, ptr %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Case", ptr %t8, i32 0, i32 4
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t12 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t11, ptr %t12)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Case", ptr %t15, i32 0, i32 5
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t18, ptr %t19)
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2eunchecked(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca ptr
  %t49 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l2, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 52}
  store i32 %t26, ptr %l3
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t30, i32 0, i32 3
  %t32 = load i32, ptr %t31, !range !{i32 0, i32 4}
  store i32 %t32, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t36, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t40 = load i32, ptr %l4, !range !{i32 0, i32 4}
  %t42 = trunc i64 3 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb6, label %bb7
bb6:
  %t45 = load %"compiler/source:Span", ptr %l1
  %t46 = load i32, ptr %l2, !tbaa !23
  %t47 = load i32, ptr %l3, !range !{i32 0, i32 52}
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 0
  store i64 9, ptr %t50
  %t52 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t45, 0
  %t54 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t52, i32 %t46, 1
  %t56 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t54, i32 %t47, 2
  %t58 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t56, i32 0, 3
  %t60 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t58, { i64, ptr } %t48, 4
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t60, ptr %t61
  %t62 = load { i64, [5 x i64] }, ptr %t49
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t62, ptr %t64
  store ptr %t64, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_119ba3895c46c2f1_96434e6a233c01d5)
  unreachable
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/check:nullNarrow"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:nullNarrow" undef, { i64, ptr } %a0, 0
  %t14 = insertvalue %"compiler/check:nullNarrow" %t12, i64 %a1, 1
  %t16 = insertvalue %"compiler/check:nullNarrow" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/check:nullNarrow" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/check:nullNarrow" %t18, i64 %a4, 4
  store %"compiler/check:nullNarrow" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:nullNarrow", ptr %rv
  ret %"compiler/check:nullNarrow" %rr
}

define dso_local %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:roDeepArg"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:roDeepArg" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:roDeepArg" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/check:roDeepArg" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:roDeepArg" %t14, i64 %a3, 3
  store %"compiler/check:roDeepArg" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roDeepArg", ptr %rv
  ret %"compiler/check:roDeepArg" %rr
}

define dso_local %"compiler/check:seqOf" @compiler_2fcheck_3aseqOf_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:seqOf"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:seqOf" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/check:seqOf" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:seqOf" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:seqOf" %t14, i64 %a3, 3
  store %"compiler/check:seqOf" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:seqOf", ptr %rv
  ret %"compiler/check:seqOf" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@olang_2esole_2ecompiler_2fcheck_3aframe_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle(ptr, i1)
declare void @__olang_region_drop(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_empty_array = external constant [16 x i64]
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\22" }>, align 8
@.d3 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c">(0)" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d8 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d9 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"param" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kept" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"mut" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ref" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"call" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Get" }>, align 8
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"view" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Sum" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d23 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Every" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"()'" }>, align 8
@.d26 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Sum" }>, align 8
@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d28 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Every" }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d30 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/array" }>, align 8
@.d31 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ArrayError" }>, align 8
@.d32 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Empty" }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d34 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d35 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d36 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"a local the checker has not bound" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d38 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a name of this kind as a value" }>, align 8
@.d39 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d40 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"'x[i]'" }>, align 8
@.d41 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d42 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"At ('x[i]')" }>, align 8
@.d43 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/place" }>, align 8
@.d44 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Place" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3aroArg_2e4 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3aroArg_2e5 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d48 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare void @__olang_errpay_pop()
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\0Atype " }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d52 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\0Atype " }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3aframe_2e48 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"$" }>, align 8
@olang_2esole_2ecompiler_2fmsgs_3aNearest_2e1 = weak hidden constant i1 false
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d63 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d67 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d68 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" -" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d71 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c": memory: " }>, align 8
@.d72 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" is weak: a " }>, align 8
@.d73 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" is held by its owning places" }>, align 8
@.d74 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d75 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c" reads null once none holds it\0A" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %a0)
@olang_loc_3ee32a1caa2e355c_4063d0a06727bdc8 = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eToArr_H1b89f7fcc263bba924ca04e7c3aa48c7(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2epastAway(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ewholeTemp(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_943b293e8fd49f1f_6252e979531a6d2b = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eisMember(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBangNothingFails(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_77940e7aab679ede_bd13144cbc386012 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtBinding(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, { i64, ptr } %a4, i1 %a5)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderKey(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerKind(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerElsewhere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerWritten(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_7e33472f03e5a723_adcfc8d4e22973ef = external constant [0 x i8]
@olang_loc_d27f09f1ed434aae_8d18f82803f9a31a = external constant [0 x i8]
declare { i32, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eitemOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStructPatPositional(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v1, ptr %a0, i1 %a1, %"compiler/source:Span" %a2, ptr %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatPositionAfterName(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWholeCaseNamed(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2enameIndex(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldReadable(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoItemField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldBothWays(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espreadArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecall1(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2ede4c4ba9909085_e989644cd371c6b1 = external constant [0 x i8]
@olang_loc_7d19fc126307206d_86c002714b5cfe09 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaxisValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_986dcc23e228494c_5356e2d9a8a4da00 = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCutOff(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b95c45f94d7269e2_7c3a0c34c4e08fe6 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_a395790432891bd8_5a5437b807a0153c = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1281810c6c9fab58_cb57d964fb88648c = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValCodes(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, i64 %a4, ptr %a5)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1)
@olang_loc_8e26fbb1c5557eef_13e6cc5de085742b = external constant [0 x i8]
@olang_loc_6d702b04e725ae1a_71c02c55b3dfc416 = external constant [0 x i8]
declare %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4, i64 %a5, i32 %a6)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofText(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2efoldBinary(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2)
@olang_loc_18ec9fb825b0f3da_76c21f303b4292b6 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %a0)
@olang_loc_2bda502508e1b1d_a3083ba563ab0481 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclaredFunc(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9cda55992b6a58cc_f4ed715c72ea34c8 = external constant [0 x i8]
declare i1 @compiler_2fast_2ecompiler_2fast_3aExpr_2eIsGathered(ptr %v0, ptr %a0)
declare i1 @compiler_2fast_2ecompiler_2fast_3aExpr_2eIsSpread(ptr %v0, ptr %a0)
declare i1 @compiler_2fast_2ecompiler_2fast_3aExpr_2eIsNamed(ptr %v0, ptr %a0)
@olang_loc_4a5fe817f84fef4e_4820cb4f1f993ac2 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpreadAlone(ptr %v0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elentAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleLine(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2ftyped_2eCopiedOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviewCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleCallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
@olang_loc_aed268118a11ee23_4542719cec09658f = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %a0)
@olang_loc_dabacd8646f437fb_89d6d0c21504246f = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2eintOnly(i32 %a0)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneLengths(ptr %v0, i64 %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSumIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, i32 %a4, %"compiler/source:Span" %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSay(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantedAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAccumulator(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etotalSite(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneMaskBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)
declare { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1)
declare double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %a0)
declare i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_652199a1d15cfac6_f2a0b86627c88902 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
@olang_loc_7509e56452997e5b_fb360af196d85db7 = external constant [0 x i8]
@olang_loc_ff81ff8210117a78_6f7a62fdc976c914 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatch(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindCase(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecided(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunbindCase(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3, i32 %a4)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %v0, i32 %a0, i1 %a1)
declare %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d6369796b76b374e_c5818894b62d1e82 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflName(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"compiler/check:fixedInit" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6f2dcaa3b3ff2363ea7964270c7a6b31(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eComptimeLocal(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_d573417cd970c31d_c74d35b0202ac379 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNarrowed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypedHole(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eImportSaid(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownNameMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_98a79ecef50a7070_a6bcf048a1872fec = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeVarAsValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/diagmsg:Msg" %a4)
declare i1 @compiler_2fcheck_2elaneTok(i32 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_37e2897bc2167462_b245f142cb8d96e6 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprovenAmount(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3)
@olang_loc_99086173777f8bfa_1537fe52b2cd754e = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
@olang_loc_983ca47650ebcf0f_470cb00b1bd66703 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roArg" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %a0, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %a1)
@olang_loc_3ba07a3e63e86523_b4e2f85113e27c0f = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roDeepArg" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H970bb490312910b3b744570a26468c6c(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd27b567062a69be2f699d8e9ab74cf5a(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf1792c165fec863e4f2028b41ed50f44(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epuns(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i1 %a3)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnsFields(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropsGone(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/names:Unread" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eAt_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLocalUnusedBare(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorAlone(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLocalUnused(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaxisType(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnspread(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSpreadAt(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare { i64, ptr } @compiler_2fcheck_2elowerAll(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowPath(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eTrun_Haa7c8ccc08c8123d0b87c9688e5d351e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreOver(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_feabd87b4a742d50_a08e759c84965044 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTestTargetTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTestTargetElsewhere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTestTargetUnknownMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTestTargetUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %a0)
@olang_loc_ac983f970f94ac3e_5c81cf941b3f1e2 = external constant [0 x i8]
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetChain(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, i64 %a5, i64 %a6)
@olang_loc_5e7ac483298c689c_15fc6611344e0300 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enothingFails(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i1 %a3, { i64, ptr } %a4, ptr %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandlesContracts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_e722c21055ee6b49_58bcebf0b772fb7d = external constant [0 x i8]
@olang_loc_eca48244095fc078_aacf4c954a6e214c = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasErrParam(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrSetArgUnwanted(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMinArity(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2eisFuncTypeRef(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteGroupFunctionType(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_397e0346551c6f2f_92a3e28505cb4413 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
@olang_loc_b692ddd8e2182d13_c763079e5a61942f = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H243102d099229a8f815a09f79cb8b122(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_e30e75934041bac1_8633653d6080ffc5 = external constant [0 x i8]
@olang_loc_261e3060da575f7_c13e4a553a852783 = external constant [0 x i8]
@olang_loc_1591269354839ba0_3246c27539059c2c = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_712f9e4ca30bc6cb_a93275977373a857 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2efloatLit(double %a0)
declare %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 %a0, i128 %a1)
@olang_loc_cf73afff9a9afd3c_75ef637926e6ccb8 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a1143936e424f416_6a846c9af99dae82 = external constant [0 x i8]
@olang_loc_b0c5dfd122db8337_2ed6598a574b6003 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
@olang_loc_4e30bf442e6db864_2dc8dbd173b7a7c8 = external constant [0 x i8]
@olang_loc_ad6c0f271be09e9a_4807a0185ac07486 = external constant [0 x i8]
@olang_loc_ce22dfd3fa106f6f_943799e8713f3e1b = external constant [0 x i8]
@olang_loc_f37d77d99c26d523_bd045c96961c9007 = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_119ba3895c46c2f1_96434e6a233c01d5 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
