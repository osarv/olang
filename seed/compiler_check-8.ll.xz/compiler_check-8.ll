; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/check:EmbedAsk" = type { i64, i64, i32 }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"compiler/check:unsetCand" = type { i64, i64, i64, i1, i64, %"compiler/source:Span", i32, i1 }
define dso_local %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %a0, i128 %a1, i1 %a2, i128 %a3) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca i128
  %l2 = alloca i1
  %l3 = alloca i128
  %l4 = alloca i128
  %l14 = alloca %"compiler/check:litv"
  %l17 = alloca %"compiler/check:litv"
  %l25 = alloca %"compiler/check:litv"
  %l30 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store i1 %a0, ptr %l0
  store i128 %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i128 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i1, ptr %l0, !tbaa !21
  %t2 = load i1, ptr %l2, !tbaa !21
  %t5 = icmp eq i1 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i128, ptr %l1
  %t8 = load i128, ptr %l3
  %t11 = add i128 %t7, %t8
  store i128 %t11, ptr %l4
  %t13 = load i128, ptr %l4
  %t14 = load i128, ptr %l1
  %t17 = icmp ult i128 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb2:
  br label %bb8
bb3:
  %t19 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t19, ptr %l14
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t20 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t20, ptr %rv
  br label %ret
bb6:
  %t21 = load i1, ptr %l0, !tbaa !21
  %t22 = load i128, ptr %l4
  %t25 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t21, i128 %t22)
  store %"compiler/check:litv" %t25, ptr %l17
  br label %bb7
bb7:
  %t26 = load %"compiler/check:litv", ptr %l17
  store %"compiler/check:litv" %t26, ptr %rv
  br label %ret
bb8:
  %t27 = load i128, ptr %l1
  %t28 = load i128, ptr %l3
  %t31 = icmp uge i128 %t27, %t28
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load i1, ptr %l0, !tbaa !21
  %t34 = load i128, ptr %l1
  %t35 = load i128, ptr %l3
  %t38 = sub i128 %t34, %t35
  %t41 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t33, i128 %t38)
  store %"compiler/check:litv" %t41, ptr %l25
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t42 = load %"compiler/check:litv", ptr %l25
  store %"compiler/check:litv" %t42, ptr %rv
  br label %ret
bb12:
  %t43 = load i1, ptr %l2, !tbaa !21
  %t44 = load i128, ptr %l3
  %t45 = load i128, ptr %l1
  %t48 = sub i128 %t44, %t45
  %t51 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t43, i128 %t48)
  store %"compiler/check:litv" %t51, ptr %l30
  br label %bb13
bb13:
  %t52 = load %"compiler/check:litv", ptr %l30
  store %"compiler/check:litv" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local ptr @compiler_2fcheck_2ecasePath(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_27266ce16db26f9e_9560a2a6a3954b82)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealiasModule(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca i1
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca %"compiler/names:Ref"
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca ptr
  %l36 = alloca ptr
  %l40 = alloca %"compiler/names:Ref"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportPath(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 29}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32 }, ptr %t21, i32 0, i32 0
  %t23 = load %"compiler/source:Span", ptr %t22
  store %"compiler/source:Span" %t23, ptr %l2
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l18, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t32)
  store ptr %t34, ptr %l20
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 2
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t40 = load i32, ptr %t39, !tbaa !23
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t44 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t41, i64 %t38, i32 %t40)
  store %"compiler/names:Ref" %t44, ptr %l24
  br label %bb11
bb11:
  %t45 = getelementptr %"compiler/names:Ref", ptr %l24, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  br label %bb25
bb12:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 29}
  %t55 = icmp eq i64 %t53, 15
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t59, i32 0, i32 0
  %t61 = load %"compiler/source:Span", ptr %t60
  store %"compiler/source:Span" %t61, ptr %l3
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  store ptr %t69, ptr %l34, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t70)
  store ptr %t72, ptr %l36
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l36, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 2
  %t76 = load i64, ptr %t75, !tbaa !24
  %t77 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t78 = load i32, ptr %t77, !tbaa !23
  %t79 = load ptr, ptr %l34, !tbaa !29
  %t82 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t79, i64 %t76, i32 %t78)
  store %"compiler/names:Ref" %t82, ptr %l40
  br label %bb19
bb19:
  %t83 = getelementptr %"compiler/names:Ref", ptr %l40, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l9, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b38f45ec26bed975_efda74b8eb60f0c1)
  unreachable
bb25:
  %t86 = load i64, ptr %l9, !tbaa !24
  store i64 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattempt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i64
  %l64 = alloca i1
  %l66 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca i1
  %l76 = alloca i1
  %l80 = alloca i64
  %l92 = alloca i1
  %l93 = alloca i1
  %l97 = alloca ptr
  %l103 = alloca i1
  %l107 = alloca i64
  %l116 = alloca i32
  %l120 = alloca ptr
  %l124 = alloca i1
  %l128 = alloca ptr
  %l132 = alloca ptr
  %l136 = alloca i64
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca ptr
  %l150 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l155 = alloca %"compiler/msgs:Msg"
  %l156 = alloca i64
  %l161 = alloca ptr
  %l177 = alloca ptr
  %l179 = alloca i64
  %l180 = alloca i64
  %l182 = alloca ptr
  %l186 = alloca i64
  %l187 = alloca i64
  %l194 = alloca i64
  %l198 = alloca i64
  %l201 = alloca i64
  %l221 = alloca i1
  %l233 = alloca ptr
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l16
  br label %bb1
bb1:
  %t7 = load i64, ptr %l16, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  br label %bb90
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l1, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l6, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t57, i64 %t58)
  store i1 %t61, ptr %l44
  br label %bb12
bb12:
  %t62 = load i1, ptr %l44, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 3
  %t66 = load i1, ptr %t65, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb19
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load i64, ptr %l6, !tbaa !24
  %t75 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t71, i64 %t72)
  store i64 %t75, ptr %l52
  br label %bb17
bb16:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb18
bb17:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 7
  %t85 = load i64, ptr %t84, !tbaa !24
  %t86 = load i64, ptr %l52, !tbaa !24
  %t88 = icmp ne i64 %t86, %t85
  store i1 %t88, ptr %l48, !tbaa !21
  br label %bb18
bb18:
  %t90 = load i1, ptr %l48, !tbaa !21
  %t91 = xor i1 %t90, true
  store i1 %t91, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t93 = load i1, ptr %l45, !tbaa !21
  br i1 %t93, label %bb20, label %bb21
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternRules(ptr %v0, ptr %t94, i64 %t95)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t101, i64 %t102)
  store i1 %t105, ptr %l64
  br label %bb24
bb24:
  %t106 = load i1, ptr %l64, !tbaa !21
  %t107 = xor i1 %t106, true
  br i1 %t107, label %bb25, label %bb26
bb25:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load i64, ptr %l6, !tbaa !24
  %t116 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t112, i64 %t113)
  store ptr %t116, ptr %l70
  br label %bb27
bb26:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb28
bb27:
  %t117 = load ptr, ptr %l70, !tbaa !29
  %t119 = getelementptr %"compiler/ast:Func", ptr %t117, i32 0, i32 7
  %t120 = load i1, ptr %t119, !tbaa !21
  store i1 %t120, ptr %l66, !tbaa !21
  br label %bb28
bb28:
  %t122 = load i1, ptr %l66, !tbaa !21
  br i1 %t122, label %bb29, label %bb30
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 3
  %t126 = load i1, ptr %t125, !tbaa !21
  br i1 %t126, label %bb31, label %bb32
bb30:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb35
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t135, ptr %l80
  br label %bb33
bb32:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb34
bb33:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/load:Loader", ptr %t142, i32 0, i32 7
  %t145 = load i64, ptr %t144, !tbaa !24
  %t146 = load i64, ptr %l80, !tbaa !24
  %t148 = icmp ne i64 %t146, %t145
  store i1 %t148, ptr %l76, !tbaa !21
  br label %bb34
bb34:
  %t150 = load i1, ptr %l76, !tbaa !21
  %t151 = xor i1 %t150, true
  store i1 %t151, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  %t153 = load i1, ptr %l73, !tbaa !21
  br i1 %t153, label %bb36, label %bb37
bb36:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportRules(ptr %v0, ptr %t154, i64 %t155)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load i64, ptr %l6, !tbaa !24
  %t165 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t161, i64 %t162)
  store i1 %t165, ptr %l92
  br label %bb40
bb40:
  %t166 = load i1, ptr %l92, !tbaa !21
  br i1 %t166, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb44
bb42:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t171 = load i64, ptr %l6, !tbaa !24
  %t174 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t170, i64 %t171)
  store ptr %t174, ptr %l97
  br label %bb43
bb43:
  %t175 = load ptr, ptr %l97, !tbaa !29
  %t177 = getelementptr %"compiler/ast:Func", ptr %t175, i32 0, i32 6
  %t178 = load i1, ptr %t177, !tbaa !21
  %t180 = xor i1 %t178, true
  store i1 %t180, ptr %l93, !tbaa !21
  br label %bb44
bb44:
  %t182 = load i1, ptr %l93, !tbaa !21
  br i1 %t182, label %bb45, label %bb46
bb45:
  br label %bb89
bb46:
  br label %bb47
bb47:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 3
  %t186 = load i1, ptr %t185, !tbaa !21
  br i1 %t186, label %bb48, label %bb49
bb48:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = load i64, ptr %l6, !tbaa !24
  %t195 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t191, i64 %t192)
  store i64 %t195, ptr %l107
  br label %bb50
bb49:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb51
bb50:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/load:Loader", ptr %t202, i32 0, i32 7
  %t205 = load i64, ptr %t204, !tbaa !24
  %t206 = load i64, ptr %l107, !tbaa !24
  %t208 = icmp ne i64 %t206, %t205
  store i1 %t208, ptr %l103, !tbaa !21
  br label %bb51
bb51:
  %t210 = load i1, ptr %l103, !tbaa !21
  br i1 %t210, label %bb52, label %bb53
bb52:
  br label %bb89
bb53:
  br label %bb54
bb54:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = load i64, ptr %l6, !tbaa !24
  %t218 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t214, i64 %t215)
  store i32 %t218, ptr %l116
  br label %bb55
bb55:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t223 = load i64, ptr %l6, !tbaa !24
  %t226 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t222, i64 %t223)
  store ptr %t226, ptr %l120
  br label %bb56
bb56:
  %t227 = load ptr, ptr %l120, !tbaa !29
  %t229 = getelementptr %"compiler/ast:Func", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = icmp eq ptr %t230, null
  br i1 %t232, label %bb57, label %bb58
bb57:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t238 = load i64, ptr %l6, !tbaa !24
  %t241 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t237, i64 %t238)
  store ptr %t241, ptr %l128
  br label %bb59
bb58:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb60
bb59:
  %t242 = load ptr, ptr %l128, !tbaa !29
  %t244 = getelementptr %"compiler/ast:Func", ptr %t242, i32 0, i32 3
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = getelementptr %"compiler/ast:Sig", ptr %t245, i32 0, i32 6
  %t248 = load i1, ptr %t247, !tbaa !21
  store i1 %t248, ptr %l124, !tbaa !21
  br label %bb60
bb60:
  %t250 = load i1, ptr %l124, !tbaa !21
  br i1 %t250, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s7
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l132, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l6, !tbaa !24
  %t259 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t255, i64 %t256)
  store i64 %t259, ptr %l136
  br label %bb63
bb62:
  br label %bb72
bb63:
  %t260 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t261 = load ptr, ptr %l132, !tbaa !29
  %t262 = load i64, ptr %l136, !tbaa !24
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t261, i64 -1, i64 %t262, i32 %t260, i32 0)
  store ptr %t264, ptr %l138
  br label %bb64
bb64:
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l139, !tbaa !29
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l140, !tbaa !29
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t271 = load i64, ptr %l6, !tbaa !24
  %t274 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t270, i64 %t271)
  store ptr %t274, ptr %l144
  br label %bb65
bb65:
  %t275 = load ptr, ptr %l140, !tbaa !29
  %t276 = load ptr, ptr %l144, !tbaa !29
  %t277 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t275, ptr %t276)
  store %"compiler/source:Span" %t277, ptr %l145
  br label %bb66
bb66:
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l146, !tbaa !29
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t283 = load i64, ptr %l6, !tbaa !24
  %t286 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t282, i64 %t283)
  store ptr %t286, ptr %l150
  br label %bb67
bb67:
  %t287 = load ptr, ptr %l150, !tbaa !29
  %t289 = getelementptr %"compiler/ast:Func", ptr %t287, i32 0, i32 2
  %t290 = load i32, ptr %t289, !tbaa !23
  %t291 = load ptr, ptr %l146, !tbaa !29
  %t293 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t291, i32 %t290)
  store { i64, ptr } %t293, ptr %l153
  br label %bb68
bb68:
  %t294 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t294, 0
  %t296 = extractvalue { i64, ptr } %t294, 1
  %t297 = mul i64 %t295, 1
  %t298 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t297)
  call void @llvm.memcpy.p0.p0.i64(ptr %t298, ptr %t296, i64 %t297, i1 false)
  %t299 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  %t302 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %s7, ptr %s7, { i64, ptr } %t300)
  store %"compiler/msgs:Msg" %t302, ptr %l155
  br label %bb69
bb69:
  %t303 = load ptr, ptr %l139, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l145
  %t305 = load %"compiler/msgs:Msg", ptr %l155
  %t306 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t303, %"compiler/source:Span" %t304, %"compiler/msgs:Msg" %t305)
  store i64 %t306, ptr %l156
  br label %bb70
bb70:
  %t307 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t307)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s7)
  br label %bb72
bb72:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/check:Checker", ptr %t309, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t313 = load i64, ptr %l6, !tbaa !24
  %t316 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t312, i64 %t313)
  store ptr %t316, ptr %l161
  br label %bb73
bb73:
  %t317 = load ptr, ptr %l161, !tbaa !29
  %t319 = getelementptr %"compiler/ast:Func", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = icmp eq ptr %t320, null
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb74, label %bb75
bb74:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorMethod(ptr %v0, ptr %t326, i64 %t327)
  br label %bb76
bb75:
  br label %bb80
bb76:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einheritClash(ptr %v0, ptr %t330, i64 %t331)
  br label %bb77
bb77:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverrideClash(ptr %v0, ptr %t334, i64 %t335)
  br label %bb78
bb78:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodOverlap(ptr %v0, ptr %t338, i64 %t339)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnTypeParams(ptr %v0, ptr %t342, i64 %t343)
  br label %bb81
bb81:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/check:Checker", ptr %t346, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !29
  store ptr %t349, ptr %l177, !tbaa !29
  %t350 = load i64, ptr %l6, !tbaa !24
  %t352 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t350)
  store i64 %t352, ptr %l179
  br label %bb82
bb82:
  %t353 = load ptr, ptr %l177, !tbaa !29
  %t354 = load i64, ptr %l179, !tbaa !24
  %t355 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t353, i64 %t354)
  store i64 %t355, ptr %l180
  br label %bb83
bb83:
  %t356 = load i64, ptr %l180, !tbaa !24
  %t357 = icmp sgt i64 %t356, 0
  br i1 %t357, label %bb84, label %bb85
bb84:
  br label %bb89
bb85:
  br label %bb86
bb86:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l182, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/check:Checker", ptr %t360, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !29
  %t364 = load i64, ptr %l6, !tbaa !24
  %t367 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t363, i64 %t364, i32 0)
  store i64 %t367, ptr %l186
  br label %bb87
bb87:
  %t368 = load ptr, ptr %l182, !tbaa !29
  %t369 = load i64, ptr %l186, !tbaa !24
  %t370 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t368, i64 %t369)
  store i64 %t370, ptr %l187
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t371 = load i64, ptr %l5, !tbaa !24
  %t373 = add i64 %t371, 1
  store i64 %t373, ptr %l5, !tbaa !24
  br label %bb8
bb90:
  store i64 0, ptr %l7, !tbaa !24
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/check:Checker", ptr %t375, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t380 = getelementptr %"compiler/generic:Program", ptr %t378, i32 0, i32 0
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = getelementptr %"compiler/load:Loader", ptr %t381, i32 0, i32 5
  %t385 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t383)
  store i64 %t385, ptr %l194
  br label %bb91
bb91:
  %t386 = load i64, ptr %l194, !tbaa !24
  store i64 %t386, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t387 = load i64, ptr %l8, !tbaa !24
  %t388 = load i64, ptr %l7, !tbaa !24
  %t391 = icmp sgt i64 %t387, %t388
  br i1 %t391, label %bb92, label %bb93
bb92:
  %t393 = load i64, ptr %l9, !tbaa !24
  %t395 = icmp sgt i64 %t393, 0
  br i1 %t395, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb97
bb94:
  %t397 = load i64, ptr %l8, !tbaa !24
  %t398 = load i64, ptr %l7, !tbaa !24
  %t401 = sub i64 %t397, %t398
  %t402 = load i64, ptr %l9, !tbaa !24
  %t405 = add i64 %t401, %t402
  %t407 = sub i64 %t405, 1
  %t408 = load i64, ptr %l9, !tbaa !24
  %t411 = sdiv i64 %t407, %t408
  store i64 %t411, ptr %l201, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb96
bb96:
  %t413 = load i64, ptr %l201, !tbaa !24
  store i64 %t413, ptr %l198, !tbaa !24
  br label %bb97
bb97:
  %t414 = load i64, ptr %l198, !tbaa !24
  store i64 %t414, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb98
bb98:
  %t415 = load i64, ptr %l11, !tbaa !24
  %t416 = load i64, ptr %l10, !tbaa !24
  %t419 = icmp slt i64 %t415, %t416
  %t421 = xor i1 %t419, true
  br i1 %t421, label %bb99, label %bb100
bb99:
  br label %bb118
bb100:
  br label %bb101
bb101:
  %t423 = load i64, ptr %l7, !tbaa !24
  %t424 = load i64, ptr %l11, !tbaa !24
  %t425 = load i64, ptr %l9, !tbaa !24
  %t428 = mul i64 %t424, %t425
  %t431 = add i64 %t423, %t428
  store i64 %t431, ptr %l12, !tbaa !24
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/check:Checker", ptr %t433, i32 0, i32 3
  %t436 = load i1, ptr %t435, !tbaa !21
  br i1 %t436, label %bb102, label %bb103
bb102:
  %t438 = load i64, ptr %l12, !tbaa !24
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/check:Checker", ptr %t439, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t444 = getelementptr %"compiler/generic:Program", ptr %t442, i32 0, i32 0
  %t445 = load ptr, ptr %t444, !tbaa !29
  %t447 = getelementptr %"compiler/load:Loader", ptr %t445, i32 0, i32 7
  %t448 = load i64, ptr %t447, !tbaa !24
  %t451 = icmp ne i64 %t438, %t448
  store i1 %t451, ptr %l221, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb104
bb104:
  %t453 = load i1, ptr %l221, !tbaa !21
  br i1 %t453, label %bb105, label %bb106
bb105:
  br label %bb117
bb106:
  br label %bb107
bb107:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/check:Checker", ptr %t454, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !29
  %t459 = getelementptr %"compiler/generic:Program", ptr %t457, i32 0, i32 0
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = getelementptr %"compiler/load:Loader", ptr %t460, i32 0, i32 5
  %t463 = load i64, ptr %l12, !tbaa !24
  %t466 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t462, i64 %t463)
  store ptr %t466, ptr %l233
  br label %bb108
bb108:
  %t467 = load ptr, ptr %l233, !tbaa !29
  %t469 = getelementptr %"compiler/load:Module", ptr %t467, i32 0, i32 8
  %t470 = load { i64, ptr }, ptr %t469, !tbaa !27
  store { i64, ptr } %t470, ptr %l13, !tbaa !27
  %t472 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t472, 0
  %t476 = icmp sgt i64 %t474, 0
  br i1 %t476, label %bb109, label %bb110
bb109:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load i64, ptr %l12, !tbaa !24
  %t480 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v0, ptr %t478, i64 %t479, { i64, ptr } %t480)
  br label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb112
bb112:
  %t484 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t484, 0
  %t488 = icmp sgt i64 %t486, 0
  br i1 %t488, label %bb113, label %bb114
bb113:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSets(ptr %v0, ptr %t490, i64 %t491)
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t494 = load i64, ptr %l11, !tbaa !24
  %t496 = add i64 %t494, 1
  store i64 %t496, ptr %l11, !tbaa !24
  br label %bb98
bb118:
  %t498 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t498)
  br label %bb119
bb119:
  %t500 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForms(ptr %v0, ptr %t500)
  br label %bb120
bb120:
  %t502 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etailSets(ptr %v0, ptr %t502)
  br label %bb121
bb121:
  %t504 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettle(ptr %v0, ptr %t504)
  br label %bb122
bb122:
  br label %ret
ret:
  ret void
}

define dso_local { ptr, { i64, ptr }, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrCallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Span"
  %l33 = alloca { i64, ptr }
  %l36 = alloca { ptr, { i64, ptr }, %"compiler/source:Span" }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { ptr, { i64, ptr }, %"compiler/source:Span" }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { ptr, { i64, ptr }, %"compiler/source:Span" }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t24, i32 0, i32 2
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t29 = load i32, ptr %l4, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %t29)
  store { i64, ptr } %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t34, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t36, ptr %l20
  br label %bb7
bb7:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb11
bb9:
  %t38 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t38, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t40, ptr %l23
  br label %bb10
bb10:
  %t41 = load i1, ptr %l23, !tbaa !21
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l3, !tbaa !29
  store ptr %t43, ptr %l24, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l26, !tbaa !27
  %t51 = load %"compiler/source:Span", ptr %l2
  %t52 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t57 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t51, i64 %t54)
  store %"compiler/source:Span" %t57, ptr %l30
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t58 = load ptr, ptr %l24, !tbaa !29
  %t59 = insertvalue { ptr, { i64, ptr }, %"compiler/source:Span" } undef, ptr %t58, 0
  %t60 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t61 = insertvalue { ptr, { i64, ptr }, %"compiler/source:Span" } %t59, { i64, ptr } %t60, 1
  %t62 = load %"compiler/source:Span", ptr %l30
  %t63 = insertvalue { ptr, { i64, ptr }, %"compiler/source:Span" } %t61, %"compiler/source:Span" %t62, 2
  call void @__olang_scope_close(ptr %s1)
  store { ptr, { i64, ptr }, %"compiler/source:Span" } %t63, ptr %rv
  br label %ret
bb15:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t67 = load %"compiler/source:Span", ptr %l2
  %t69 = insertvalue { ptr, { i64, ptr }, %"compiler/source:Span" } undef, ptr %t65, 0
  %t71 = insertvalue { ptr, { i64, ptr }, %"compiler/source:Span" } %t69, { i64, ptr } %t66, 1
  %t73 = insertvalue { ptr, { i64, ptr }, %"compiler/source:Span" } %t71, %"compiler/source:Span" %t67, 2
  store { ptr, { i64, ptr }, %"compiler/source:Span" } %t73, ptr %l36
  %t74 = getelementptr { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l36, i32 0, i32 1
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  store { i64, ptr } %t75, ptr %l37, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l38, !tbaa !24
  %t78 = load i64, ptr %l38, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l39, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l38, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t90 = getelementptr { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l36, i32 0, i32 1
  store { i64, ptr } %t89, ptr %t90, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t91 = load { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l36
  store { ptr, { i64, ptr }, %"compiler/source:Span" } %t91, ptr %rv
  br label %ret
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l40, !tbaa !29
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t93, ptr %l42, !tbaa !27
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t94)
  store %"compiler/source:Span" %t96, ptr %l44
  br label %bb20
bb20:
  %t97 = load ptr, ptr %l40, !tbaa !29
  %t98 = insertvalue { ptr, { i64, ptr }, %"compiler/source:Span" } undef, ptr %t97, 0
  %t99 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t100 = insertvalue { ptr, { i64, ptr }, %"compiler/source:Span" } %t98, { i64, ptr } %t99, 1
  %t101 = load %"compiler/source:Span", ptr %l44
  %t102 = insertvalue { ptr, { i64, ptr }, %"compiler/source:Span" } %t100, %"compiler/source:Span" %t101, 2
  store { ptr, { i64, ptr }, %"compiler/source:Span" } %t102, ptr %l45
  %t103 = getelementptr { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l45, i32 0, i32 1
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l46, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  store i64 %t106, ptr %l47, !tbaa !24
  %t107 = load i64, ptr %l47, !tbaa !24
  %t108 = mul i64 %t107, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l48, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l47, !tbaa !24
  %t117 = mul i64 %t116, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t113, ptr %t115, i64 %t117, i1 false)
  %t118 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t119 = getelementptr { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l45, i32 0, i32 1
  store { i64, ptr } %t118, ptr %t119, !tbaa !27
  %t120 = load { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l45
  store { ptr, { i64, ptr }, %"compiler/source:Span" } %t120, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_e8df0bdf3cd721f8_b505cb518d2727a4)
  unreachable
ret:
  %rr = load { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %rv
  ret { ptr, { i64, ptr }, %"compiler/source:Span" } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 6
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64, i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l16
  br label %bb5
bb5:
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t28, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l10, !tbaa !27
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t34, ptr %l10, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_15d8d795344f0f34_d9e3bc129d8abb98)
  unreachable
bb11:
  %t36 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l21, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t49, ptr %l10, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i32
  %l30 = alloca i1
  %l35 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l10
  br label %bb4
bb4:
  %t14 = load i32, ptr %l10, !range !{i32 0, i32 6}
  %t16 = trunc i64 4 to i32
  %t17 = icmp eq i32 %t14, %t16
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l19
  br label %bb9
bb9:
  %t33 = load i32, ptr %l19, !tbaa !23
  store i32 %t33, ptr %l2, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t38, ptr %l22
  br label %bb10
bb10:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l26
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb18
bb13:
  %t45 = load i32, ptr %l26, !range !{i32 0, i32 6}
  %t47 = trunc i64 4 to i32
  %t48 = icmp eq i32 %t45, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l35
  br label %bb16
bb16:
  %t62 = load i32, ptr %l35, !tbaa !23
  %t63 = icmp ne i32 %t62, 0
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l30, !tbaa !21
  store i1 %t65, ptr %l23, !tbaa !21
  br label %bb18
bb18:
  %t66 = load i1, ptr %l23, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l17 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l17
  br label %bb9
bb8:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb11
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t32)
  store i32 %t34, ptr %l19
  br label %bb10
bb10:
  %t35 = load i32, ptr %l17, !tbaa !23
  %t36 = load i32, ptr %l19, !tbaa !23
  %t37 = icmp eq i32 %t35, %t36
  store i1 %t37, ptr %l12, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l12, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t40)
  store i32 %t42, ptr %l22
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t43 = load i32, ptr %l22, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb15:
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_2b2e21654e3310f6_a1c2a2453bd05f02)
  unreachable
bb21:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t44)
  store i32 %t47, ptr %l25
  br label %bb22
bb22:
  %t48 = load i32, ptr %l25, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l27 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l28 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 12
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t22, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l17
  br label %bb5
bb5:
  %t25 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t25, ptr %l12
  br label %bb17
bb6:
  %t26 = load { i64, [2 x i64] }, ptr %l2
  %t28 = extractvalue { i64, [2 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 1
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t32 = getelementptr { i32, i32 }, ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l4, !tbaa !23
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t36 = getelementptr { i32, i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l5, !tbaa !23
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t39 = load i32, ptr %l4, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t43 = sub i64 -2, %t41
  %t44 = load i32, ptr %l5, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t49 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t43, i64 %t46)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t49, ptr %l27
  br label %bb10
bb10:
  %t50 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l27
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t50, ptr %l12
  br label %bb17
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t51 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t51, ptr %l28
  br label %bb15
bb15:
  %t52 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l28
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t52, ptr %l12
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f6343df54e321530_17a07bfc25de31ec)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t53, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %rv
  ret %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebothSpellings(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l14 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i64
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca i32
  %l52 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %l75 = alloca %"compiler/msgs:Msg"
  %l76 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb2:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t7, ptr %l12, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t11)
  store i1 %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load i1, ptr %l14, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v1, ptr %s0, ptr %t18, { i64, ptr } %t19)
  store { i64, ptr } %t22, ptr %l18
  br label %bb8
bb8:
  %t23 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = call i64 @compiler_2fcheck_2eprotocolArity(ptr %s0, { i64, ptr } %t29)
  store i64 %t31, ptr %l20
  br label %bb9
bb9:
  %t32 = load i64, ptr %l20, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp eq i64 %t33, -2
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = call { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v1, ptr %s0, { i64, ptr } %t37)
  store { i64, ptr } %t39, ptr %l24
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t40, ptr %l6, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  %t45 = load i32, ptr %l2, !tbaa !23
  store i32 %t45, ptr %l27, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t59 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t55, { i64, ptr } %t56)
  store i32 %t59, ptr %l33
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l26, !tbaa !29
  %t61 = load i32, ptr %l27, !tbaa !23
  %t62 = load i32, ptr %l33, !tbaa !23
  %t63 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t60, i32 %t61, i32 %t62)
  store i64 %t63, ptr %l34
  br label %bb15
bb15:
  %t64 = load i64, ptr %l34, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = icmp slt i64 %t65, 0
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb17:
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = icmp sge i64 %t69, 0
  br i1 %t71, label %bb18, label %bb19
bb18:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  store ptr %t78, ptr %l43, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  store ptr %t84, ptr %l46, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t88, i64 %t89)
  store i32 %t92, ptr %l50
  br label %bb20
bb19:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb23
bb20:
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = load i32, ptr %l50, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t95, ptr %l51
  br label %bb21
bb21:
  %t96 = load ptr, ptr %l43, !tbaa !29
  %t97 = load i32, ptr %l51, !tbaa !23
  %t98 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t96, i32 %t97)
  store { i64, ptr } %t98, ptr %l52
  br label %bb22
bb22:
  %t99 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t102 = sub i64 %t100, 1
  %t106 = icmp ne i64 %t102, %a4
  store i1 %t106, ptr %l40, !tbaa !21
  br label %bb23
bb23:
  %t108 = load i1, ptr %l40, !tbaa !21
  store i1 %t108, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t109 = load i1, ptr %l37, !tbaa !21
  br i1 %t109, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l57, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l58, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t119 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t115, i64 %a1)
  store ptr %t119, ptr %l62
  br label %bb28
bb28:
  %t120 = load ptr, ptr %l58, !tbaa !29
  %t121 = load ptr, ptr %l62, !tbaa !29
  %t122 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t120, ptr %t121)
  store %"compiler/source:Span" %t122, ptr %l63
  br label %bb29
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l64, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l2, !tbaa !23
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t133, ptr %l69
  br label %bb30
bb30:
  %t134 = load ptr, ptr %l64, !tbaa !29
  %t135 = load i32, ptr %l69, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t134, i32 %t135)
  store { i64, ptr } %t136, ptr %l70
  br label %bb31
bb31:
  %t137 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t151 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolBothSpellings(ptr %s0, ptr %v1, ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t143, { i64, ptr } %t144, { i64, ptr } %t145, { i64, ptr } %t146)
  store %"compiler/msgs:Msg" %t151, ptr %l75
  br label %bb32
bb32:
  %t152 = load ptr, ptr %l57, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l63
  %t154 = load %"compiler/msgs:Msg", ptr %l75
  %t155 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t152, %"compiler/source:Span" %t153, %"compiler/msgs:Msg" %t154)
  store i64 %t155, ptr %l76
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t17, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Branch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Branch", ptr %t29, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %t28, i32 1, %"compiler/source:Span" %t32)
  store ptr %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l18, !tbaa !29
  store ptr %t38, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Branch", ptr %t39, i32 0, i32 2
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %t54, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t55)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %s0, ptr %a1)
  store { i64, ptr } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t8 = ptrtoint ptr %t7 to i64
  %t9 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t8, i64 8)
  %t10 = getelementptr { ptr, ptr }, ptr %t9, i32 0, i32 0
  store ptr %t6, ptr %t10, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t12 = getelementptr { ptr, ptr }, ptr %t9, i32 0, i32 1
  store ptr %v0, ptr %t12, !tbaa !28
  %t13 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_5, 0
  %t14 = insertvalue { ptr, ptr } %t13, ptr %t9, 1
  %t17 = extractvalue { ptr, ptr } %t14, 0
  %t18 = extractvalue { ptr, ptr } %t14, 1
  call void @std_2fprelude_2farray_2eArray_3ccompiler_2ftypes_3aTypeId_3e_2eSort_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %s0, ptr %v0, { i64, ptr } %t5, ptr %t17, ptr %t18)
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t24, { i64, ptr } %t25)
  store i32 %t28, ptr %l12
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l12, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i32
  %l9 = alloca { i64, ptr }
  %l13 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:CaseDecl", ptr %t1, i32 0, i32 0
  %t4 = getelementptr %"compiler/source:Span", ptr %t3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:CaseDecl", ptr %t6, i32 0, i32 0
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/ast:CaseDecl", ptr %t12, i32 0, i32 1
  %t15 = load i32, ptr %t14, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %t15)
  store { i64, ptr } %t18, ptr %l9
  br label %bb1
bb1:
  %t19 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t22 = trunc i64 %t20 to i32
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = add i32 %t23, %t22
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t26, i32 %t25)
  store %"compiler/source:Span" %t28, ptr %l13
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i64
  %l26 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca { i64, [3 x i64] }
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"compiler/msgs:Msg"
  %l42 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr i8, ptr %t8, i64 0
  %t10 = load i8, ptr %t9, !tbaa !32
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t10)
  store i1 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 14
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l13
  br label %bb5
bb5:
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = icmp eq i64 %t19, 0
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb12
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %a1)
  store i32 %t38, ptr %l23
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i32, ptr %l23, !tbaa !23
  %t41 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t41, ptr %l24
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t42)
  store ptr %t44, ptr %l26
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i64, ptr %l24, !tbaa !24
  %t51 = icmp eq i64 %t49, %t48
  store i1 %t51, ptr %l15, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l15, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/load:Loader", ptr %t60, i32 0, i32 4
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t68 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t64, %"compiler/source:Span" %a3)
  store { i64, [3 x i64] } %t68, ptr %l36
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l39
  br label %bb17
bb17:
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  %t76 = extractvalue { i64, ptr } %t74, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  %t82 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsPrivate(ptr %s0, ptr %s0, { i64, ptr } %t80)
  store %"compiler/msgs:Msg" %t82, ptr %l41
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l33, !tbaa !29
  %t84 = load { i64, [3 x i64] }, ptr %l36
  %t85 = load %"compiler/msgs:Msg", ptr %l41
  %t86 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s0, ptr %t83, { i64, [3 x i64] } %t84, %"compiler/msgs:Msg" %t85)
  store i64 %t86, ptr %l42
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 0
  %t4 = getelementptr %"compiler/source:Span", ptr %t3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:Catch", ptr %t6, i32 0, i32 0
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  %t12 = add i32 %t10, 5
  %t15 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t5, i32 %t12)
  store %"compiler/source:Span" %t15, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t16 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l7 = alloca i64
  %l9 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca %"compiler/names:Ref"
  %l49 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t9)
  store ptr %t11, ptr %l11
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 54
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l14
  br label %bb5
bb5:
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = icmp eq i64 %t17, 0
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 29}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l2, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l25
  br label %bb15
bb15:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb17, label %bb18
bb17:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 29}
  %t50 = icmp eq i64 %t48, 0
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32 }, ptr %t54, i32 0, i32 0
  %t56 = load %"compiler/source:Span", ptr %t55
  store %"compiler/source:Span" %t56, ptr %l3
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32 }, ptr %t60, i32 0, i32 1
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l4, !tbaa !23
  br label %bb21
bb20:
  br label %bb28
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  store ptr %t70, ptr %l36, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t71)
  store ptr %t73, ptr %l38
  br label %bb22
bb22:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t76 = getelementptr %"compiler/check:frame", ptr %t74, i32 0, i32 2
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t79 = load i32, ptr %t78, !tbaa !23
  %t80 = load ptr, ptr %l36, !tbaa !29
  %t83 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t80, i64 %t77, i32 %t79)
  store %"compiler/names:Ref" %t83, ptr %l42
  br label %bb23
bb23:
  %t84 = getelementptr %"compiler/names:Ref", ptr %l42, i32 0, i32 0
  %t85 = load i32, ptr %t84, !range !{i32 0, i32 9}
  %t87 = trunc i64 1 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb24, label %bb25
bb24:
  store i64 -1, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l4, !tbaa !23
  %t97 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %t93, i32 %t94)
  store i64 %t97, ptr %l49
  br label %bb27
bb27:
  %t98 = load i64, ptr %l49, !tbaa !24
  store i64 %t98, ptr %rv
  br label %ret
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i64 -1, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_f18babf7f50c335e_33607163d02cbb5a)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %lp26 = alloca ptr
  %lp27 = alloca ptr
  %l30 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/msgs:Msg"
  %l57 = alloca i64
  %l61 = alloca i32
  %l68 = alloca i32
  %l70 = alloca ptr
  %l73 = alloca i64
  %l86 = alloca i64
  %l95 = alloca ptr
  %l103 = alloca ptr
  %l107 = alloca i32
  %l109 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l117 = alloca i64
  %l127 = alloca { i64, ptr }
  %l138 = alloca i1
  %l143 = alloca ptr
  %l145 = alloca %"compiler/source:Span"
  %l148 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l159 = alloca i32
  %l162 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca { i64, ptr }
  %l181 = alloca ptr
  %l183 = alloca %"compiler/source:Span"
  %l189 = alloca %"compiler/msgs:Msg"
  %l190 = alloca i64
  %l193 = alloca i64
  %l199 = alloca i64
  %l202 = alloca i64
  %l221 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l230 = alloca ptr
  %l236 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l239 = alloca %"compiler/source:Span"
  %l241 = alloca %"compiler/source:Span"
  %l242 = alloca i32
  %l246 = alloca %"compiler/typed:Make"
  %l255 = alloca { i64, ptr }
  %l256 = alloca %"compiler/typed:Block"
  %l258 = alloca ptr
  %l263 = alloca i1
  %l266 = alloca i1
  %l268 = alloca ptr
  %l272 = alloca i1
  %l274 = alloca i1
  %l276 = alloca ptr
  %l278 = alloca %"compiler/source:Span"
  %l279 = alloca %"compiler/msgs:Msg"
  %l280 = alloca i64
  %l282 = alloca ptr
  %l285 = alloca { i64, ptr }
  %l291 = alloca %"compiler/source:Span"
  %l292 = alloca i32
  %l295 = alloca i32
  %l296 = alloca { i64, ptr }
  %l301 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca ptr
  %t99 = alloca { i64, [2 x i64] }, align 8
  %t275 = alloca { i64, [3 x i64] }, align 8
  %t467 = alloca { i64, [5 x i64] }, align 8
  %t479 = alloca { i64, [3 x i64] }, align 8
  %t587 = alloca { i64, [4 x i64] }, align 8
  %t599 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:Catch", ptr %t6, i32 0, i32 2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l30, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l30, !tbaa !21
  store i1 %t15, ptr %l4, !tbaa !21
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Catch", ptr %t16, i32 0, i32 3
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 0
  store i1 %t23, ptr %l5, !tbaa !21
  %t25 = load i1, ptr %l4, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i1, ptr %l5, !tbaa !21
  %t31 = xor i1 %t29, true
  store i1 %t31, ptr %l41, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l41, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp eq i64 %t34, 0
  store i1 %t36, ptr %l44, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l44, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load i1, ptr %l5, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp eq i64 %t42, 0
  store i1 %t44, ptr %l49, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l49, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l52, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t52 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store %"compiler/source:Span" %t52, ptr %l55
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t53 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %s2)
  store %"compiler/msgs:Msg" %t53, ptr %l56
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l52, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l55
  %t56 = load %"compiler/msgs:Msg", ptr %l56
  %t57 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t54, %"compiler/source:Span" %t55, %"compiler/msgs:Msg" %t56)
  store i64 %t57, ptr %l57
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb21:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load i32, ptr %l2, !tbaa !23
  store i32 %t63, ptr %l61, !tbaa !23
  br label %bb24
bb23:
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t65, ptr %l61, !tbaa !23
  br label %bb24
bb24:
  %t67 = load i32, ptr %l61, !tbaa !23
  store i32 %t67, ptr %l6, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l6, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 0, i32 %t74, i32 0, i32 0, i64 0)
  store i32 %t77, ptr %l68
  br label %bb25
bb25:
  %t78 = load i32, ptr %l68, !tbaa !23
  store i32 %t78, ptr %l7, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t79)
  store ptr %t81, ptr %l70
  br label %bb26
bb26:
  %t82 = load ptr, ptr %l70, !tbaa !29
  store ptr %t82, ptr %l8, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 14
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l73
  br label %bb27
bb27:
  %t88 = load i64, ptr %l73, !tbaa !24
  %t89 = sub i64 %t88, 1
  store i64 %t89, ptr %l9, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 0
  store i64 4, ptr %t100
  %t102 = insertvalue { i32 } undef, i32 %t97, 0
  %t103 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 1
  store { i32 } %t102, ptr %t103
  %t104 = load { i64, [2 x i64] }, ptr %t99
  %t105 = load i32, ptr %l7, !tbaa !23
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = getelementptr %"compiler/check:frame", ptr %t106, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Catch", ptr %t110, i32 0, i32 0
  %t113 = load %"compiler/source:Span", ptr %t112
  %t119 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t91, { i64, [2 x i64] } %t104, i32 %t105, i64 %t109, %"compiler/source:Span" %t113)
  store i64 %t119, ptr %l86
  br label %bb28
bb28:
  %t120 = load i64, ptr %l86, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 17
  %t124 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t123, i64 %t124, i64 1)
  br label %bb29
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load ptr, ptr %l8, !tbaa !29
  %t131 = getelementptr %"compiler/check:frame", ptr %t129, i32 0, i32 1
  %t132 = load i64, ptr %t131, !tbaa !24
  %t133 = load i32, ptr %l6, !tbaa !23
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t127, i64 %t128, i64 %t132, i32 %t133, i32 0)
  store ptr %t138, ptr %l95
  br label %bb30
bb30:
  %t139 = load ptr, ptr %l95, !tbaa !29
  store ptr %t139, ptr %l11, !tbaa !29
  %t140 = load ptr, ptr %l11, !tbaa !29
  %t141 = load ptr, ptr %l8, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t141, i32 0, i32 4
  %t144 = load %"compiler/generic:Context", ptr %t143
  %t147 = getelementptr %"compiler/check:frame", ptr %t140, i32 0, i32 4
  store %"compiler/generic:Context" %t144, ptr %t147
  %t148 = load ptr, ptr %l11, !tbaa !29
  %t149 = load i64, ptr %l9, !tbaa !24
  %t152 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 19
  store i64 %t149, ptr %t152, !tbaa !24
  %t153 = load ptr, ptr %l11, !tbaa !29
  %t155 = getelementptr %"compiler/check:frame", ptr %t153, i32 0, i32 30
  store i1 true, ptr %t155, !tbaa !21
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t156)
  store ptr %t158, ptr %l103
  br label %bb31
bb31:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Catch", ptr %t159, i32 0, i32 0
  %t162 = load %"compiler/source:Span", ptr %t161
  %t163 = load ptr, ptr %l103, !tbaa !29
  %t166 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t163, i32 -1, i32 0, %"compiler/source:Span" %t162)
  store i32 %t166, ptr %l107
  br label %bb32
bb32:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t167)
  store ptr %t169, ptr %l109
  br label %bb33
bb33:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t174 = load i32, ptr %l7, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t173, i32 %t174)
  store { i64, ptr } %t177, ptr %l113
  br label %bb34
bb34:
  %t178 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 8
  %t182 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load ptr, ptr %l109, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t185, { i64, ptr } %t184)
  br label %bb35
bb35:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 37
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t189)
  store i64 %t191, ptr %l117
  br label %bb36
bb36:
  %t192 = load i64, ptr %l117, !tbaa !24
  store i64 %t192, ptr %l12, !tbaa !24
  %t193 = load i1, ptr %l4, !tbaa !21
  br i1 %t193, label %bb37, label %bb38
bb37:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/ast:Catch", ptr %t195, i32 0, i32 2
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  store { i64, ptr } %t198, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  store i64 %t202, ptr %l15, !tbaa !24
  br label %bb39
bb38:
  br label %bb46
bb39:
  %t204 = load i64, ptr %l14, !tbaa !24
  %t205 = load i64, ptr %l15, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb40, label %bb41
bb40:
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t212 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t212, ptr %l127, !tbaa !27
  %t213 = load i64, ptr %l14, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr ptr, ptr %t216, i64 %t213
  %t218 = load ptr, ptr %t217, !tbaa !39
  %t220 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t220, ptr %t218)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t225 = load i64, ptr %l14, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l14, !tbaa !24
  br label %bb39
bb45:
  br label %bb46
bb46:
  %t229 = load i1, ptr %l5, !tbaa !21
  br i1 %t229, label %bb47, label %bb48
bb47:
  %t231 = load i64, ptr %l3, !tbaa !24
  %t233 = icmp eq i64 %t231, 1
  br i1 %t233, label %bb49, label %bb50
bb48:
  br label %bb90
bb49:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb51
bb50:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr %"compiler/ast:Catch", ptr %t235, i32 0, i32 3
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t242 = icmp eq i64 %t240, 1
  store i1 %t242, ptr %l138, !tbaa !21
  br label %bb51
bb51:
  %t244 = load i1, ptr %l138, !tbaa !21
  br i1 %t244, label %bb52, label %bb53
bb52:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l143, !tbaa !29
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr %"compiler/ast:Catch", ptr %t246, i32 0, i32 0
  %t249 = load %"compiler/source:Span", ptr %t248
  store %"compiler/source:Span" %t249, ptr %l145
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr %"compiler/ast:Catch", ptr %t251, i32 0, i32 3
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  store { i64, ptr } %t254, ptr %l148, !tbaa !27
  %t255 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr ptr, ptr %t256, i64 0
  %t258 = load ptr, ptr %t257, !tbaa !39
  %t259 = load i32, ptr %l2, !tbaa !23
  %t263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %t250, ptr %t258, i32 %t259)
  store ptr %t263, ptr %l151
  br label %bb54
bb53:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 2
  %t270 = load i32, ptr %l2, !tbaa !23
  %t273 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t269, i32 %t270)
  store i32 %t273, ptr %l159
  br label %bb56
bb54:
  %t274 = load ptr, ptr %l151, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t275
  %t276 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 0
  store i64 6, ptr %t276
  %t277 = load %"compiler/source:Span", ptr %l145
  %t278 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t277, 0
  %t280 = insertvalue { %"compiler/source:Span", ptr } %t278, ptr %t274, 1
  %t281 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t280, ptr %t281
  %t282 = load { i64, [3 x i64] }, ptr %t275
  %t284 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t282, ptr %t284
  %t285 = load ptr, ptr %l143, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t285, ptr %t284)
  br label %bb55
bb55:
  br label %bb89
bb56:
  %t287 = load i32, ptr %l159, !range !{i32 0, i32 33}
  %t289 = trunc i64 22 to i32
  %t290 = icmp eq i32 %t287, %t289
  br i1 %t290, label %bb57, label %bb58
bb57:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/generic:Program", ptr %t295, i32 0, i32 2
  store ptr %t297, ptr %l165, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/generic:Program", ptr %t301, i32 0, i32 2
  %t304 = load i32, ptr %l2, !tbaa !23
  %t307 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t303, i32 %t304)
  store i32 %t307, ptr %l170
  br label %bb59
bb58:
  %t308 = icmp sge i64 0, 0
  br i1 %t308, label %bb61, label %bb62
bb59:
  %t310 = load ptr, ptr %l165, !tbaa !29
  %t311 = load i32, ptr %l170, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t310, i32 %t311)
  store { i64, ptr } %t312, ptr %l171
  br label %bb60
bb60:
  %t313 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t313, ptr %l162, !tbaa !27
  br label %bb65
bb61:
  %t314 = icmp sle i64 0, 2305843009213693951
  br i1 %t314, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb63:
  %t316 = mul i64 0, 4
  %t317 = insertvalue { i64, ptr } undef, i64 0, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t318, ptr %l162, !tbaa !27
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb65:
  %t320 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t320, ptr %l17, !tbaa !27
  %t321 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr %"compiler/ast:Catch", ptr %t324, i32 0, i32 3
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t332 = icmp ne i64 %t323, %t329
  br i1 %t332, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s10
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l181, !tbaa !29
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr %"compiler/ast:Catch", ptr %t335, i32 0, i32 0
  %t338 = load %"compiler/source:Span", ptr %t337
  store %"compiler/source:Span" %t338, ptr %l183
  %t339 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t339, 0
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t344 = getelementptr %"compiler/ast:Catch", ptr %t342, i32 0, i32 3
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t345, 0
  %t350 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %s10, i64 %t341, i64 %t347)
  store %"compiler/msgs:Msg" %t350, ptr %l189
  br label %bb68
bb67:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 36
  %t355 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t353)
  store i64 %t355, ptr %l193
  br label %bb70
bb68:
  %t356 = load ptr, ptr %l181, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l183
  %t358 = load %"compiler/msgs:Msg", ptr %l189
  %t359 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t356, %"compiler/source:Span" %t357, %"compiler/msgs:Msg" %t358)
  store i64 %t359, ptr %l190
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s10)
  br label %bb88
bb70:
  %t360 = load i64, ptr %l193, !tbaa !24
  store i64 %t360, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t361 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t361, 0
  store i64 %t363, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t365 = load i64, ptr %l20, !tbaa !24
  %t366 = load i64, ptr %l19, !tbaa !24
  %t369 = icmp sgt i64 %t365, %t366
  br i1 %t369, label %bb71, label %bb72
bb71:
  %t371 = load i64, ptr %l21, !tbaa !24
  %t373 = icmp sgt i64 %t371, 0
  br i1 %t373, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb76
bb73:
  %t375 = load i64, ptr %l20, !tbaa !24
  %t376 = load i64, ptr %l19, !tbaa !24
  %t379 = sub i64 %t375, %t376
  %t380 = load i64, ptr %l21, !tbaa !24
  %t383 = add i64 %t379, %t380
  %t385 = sub i64 %t383, 1
  %t386 = load i64, ptr %l21, !tbaa !24
  %t389 = sdiv i64 %t385, %t386
  store i64 %t389, ptr %l202, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb75
bb75:
  %t391 = load i64, ptr %l202, !tbaa !24
  store i64 %t391, ptr %l199, !tbaa !24
  br label %bb76
bb76:
  %t392 = load i64, ptr %l199, !tbaa !24
  store i64 %t392, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb77
bb77:
  %t393 = load i64, ptr %l23, !tbaa !24
  %t394 = load i64, ptr %l22, !tbaa !24
  %t397 = icmp slt i64 %t393, %t394
  %t399 = xor i1 %t397, true
  br i1 %t399, label %bb78, label %bb79
bb78:
  br label %bb84
bb79:
  br label %bb80
bb80:
  %t401 = load i64, ptr %l19, !tbaa !24
  %t402 = load i64, ptr %l23, !tbaa !24
  %t403 = load i64, ptr %l21, !tbaa !24
  %t406 = mul i64 %t402, %t403
  %t409 = add i64 %t401, %t406
  store i64 %t409, ptr %l24, !tbaa !24
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/check:Checker", ptr %t411, i32 0, i32 36
  store ptr %t413, ptr %l221, !tbaa !29
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t417 = getelementptr %"compiler/ast:Catch", ptr %t415, i32 0, i32 3
  %t418 = load { i64, ptr }, ptr %t417, !tbaa !27
  store { i64, ptr } %t418, ptr %l224, !tbaa !27
  %t419 = load i64, ptr %l24, !tbaa !24
  %t421 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr ptr, ptr %t422, i64 %t419
  %t424 = load ptr, ptr %t423, !tbaa !39
  %t425 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t425, ptr %l227, !tbaa !27
  %t426 = load i64, ptr %l24, !tbaa !24
  %t428 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr i32, ptr %t429, i64 %t426
  %t431 = load i32, ptr %t430, !tbaa !33
  %t435 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %t414, ptr %t424, i32 %t431)
  store ptr %t435, ptr %l230
  br label %bb81
bb81:
  %t436 = load ptr, ptr %l221, !tbaa !29
  %t437 = load ptr, ptr %l230, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t436, ptr %t437)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t438 = load i64, ptr %l23, !tbaa !24
  %t440 = add i64 %t438, 1
  store i64 %t440, ptr %l23, !tbaa !24
  br label %bb77
bb84:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/check:Checker", ptr %t442, i32 0, i32 36
  %t445 = load i64, ptr %l18, !tbaa !24
  %t448 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t444, i64 %t445)
  store { i64, ptr } %t448, ptr %l236
  br label %bb85
bb85:
  %t449 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t450 = load ptr, ptr %l0, !tbaa !29
  store ptr %t450, ptr %l237, !tbaa !29
  %t451 = load ptr, ptr %l1, !tbaa !29
  %t453 = getelementptr %"compiler/ast:Catch", ptr %t451, i32 0, i32 0
  %t454 = load %"compiler/source:Span", ptr %t453
  store %"compiler/source:Span" %t454, ptr %l239
  %t455 = load ptr, ptr %l1, !tbaa !29
  %t457 = getelementptr %"compiler/ast:Catch", ptr %t455, i32 0, i32 0
  %t458 = load %"compiler/source:Span", ptr %t457
  store %"compiler/source:Span" %t458, ptr %l241
  %t459 = load i32, ptr %l2, !tbaa !23
  store i32 %t459, ptr %l242, !tbaa !23
  %t464 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t449, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t464, ptr %l246
  br label %bb86
bb86:
  %t465 = load %"compiler/typed:Make", ptr %l246
  %t466 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t465, ptr %t466
  store { i64, [5 x i64] } zeroinitializer, ptr %t467
  %t468 = getelementptr { i64, [5 x i64] }, ptr %t467, i32 0, i32 0
  store i64 7, ptr %t468
  %t469 = load %"compiler/source:Span", ptr %l241
  %t470 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t469, 0
  %t471 = load i32, ptr %l242, !tbaa !23
  %t472 = insertvalue { %"compiler/source:Span", i32, ptr } %t470, i32 %t471, 1
  %t474 = insertvalue { %"compiler/source:Span", i32, ptr } %t472, ptr %t466, 2
  %t475 = getelementptr { i64, [5 x i64] }, ptr %t467, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t474, ptr %t475
  %t476 = load { i64, [5 x i64] }, ptr %t467
  %t478 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t476, ptr %t478
  store { i64, [3 x i64] } zeroinitializer, ptr %t479
  %t480 = getelementptr { i64, [3 x i64] }, ptr %t479, i32 0, i32 0
  store i64 6, ptr %t480
  %t481 = load %"compiler/source:Span", ptr %l239
  %t482 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t481, 0
  %t484 = insertvalue { %"compiler/source:Span", ptr } %t482, ptr %t478, 1
  %t485 = getelementptr { i64, [3 x i64] }, ptr %t479, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t484, ptr %t485
  %t486 = load { i64, [3 x i64] }, ptr %t479
  %t488 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t486, ptr %t488
  %t489 = load ptr, ptr %l237, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t489, ptr %t488)
  br label %bb87
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/check:Checker", ptr %t491, i32 0, i32 37
  %t494 = load i64, ptr %l12, !tbaa !24
  %t497 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t493, i64 %t494)
  store { i64, ptr } %t497, ptr %l255
  br label %bb91
bb91:
  %t498 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t499 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t498)
  store %"compiler/typed:Block" %t499, ptr %l256
  br label %bb92
bb92:
  %t500 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t500, ptr %lp26
  %t501 = load %"compiler/typed:Block", ptr %l256
  %t502 = load ptr, ptr %lp26
  store %"compiler/typed:Block" %t501, ptr %t502
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t503)
  store ptr %t505, ptr %l258
  br label %bb93
bb93:
  %t506 = load ptr, ptr %l258, !tbaa !29
  %t507 = load ptr, ptr %lp26
  %t510 = getelementptr %"compiler/typed:Body", ptr %t506, i32 0, i32 11
  store ptr %t507, ptr %t510, !tbaa !29
  %t511 = load i64, ptr %l3, !tbaa !24
  %t513 = icmp sgt i64 %t511, 0
  br i1 %t513, label %bb94, label %bb95
bb94:
  %t515 = load i1, ptr %l5, !tbaa !21
  %t517 = xor i1 %t515, true
  store i1 %t517, ptr %l263, !tbaa !21
  br label %bb96
bb95:
  store i1 false, ptr %l263, !tbaa !21
  br label %bb96
bb96:
  %t519 = load i1, ptr %l263, !tbaa !21
  br i1 %t519, label %bb97, label %bb98
bb97:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t522 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t520)
  store ptr %t522, ptr %l268
  br label %bb99
bb98:
  store i1 false, ptr %l266, !tbaa !21
  br label %bb100
bb99:
  %t523 = load ptr, ptr %l268, !tbaa !29
  %t525 = getelementptr %"compiler/check:frame", ptr %t523, i32 0, i32 18
  %t526 = load i1, ptr %t525, !tbaa !21
  %t528 = xor i1 %t526, true
  store i1 %t528, ptr %l266, !tbaa !21
  br label %bb100
bb100:
  %t530 = load i1, ptr %l266, !tbaa !21
  br i1 %t530, label %bb101, label %bb102
bb101:
  %t531 = load ptr, ptr %lp26
  %t533 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t531)
  store i1 %t533, ptr %l274
  br label %bb103
bb102:
  store i1 false, ptr %l272, !tbaa !21
  br label %bb104
bb103:
  %t534 = load i1, ptr %l274, !tbaa !21
  %t535 = xor i1 %t534, true
  store i1 %t535, ptr %l272, !tbaa !21
  br label %bb104
bb104:
  %t537 = load i1, ptr %l272, !tbaa !21
  br i1 %t537, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s15
  %t538 = load ptr, ptr %l0, !tbaa !29
  store ptr %t538, ptr %l276, !tbaa !29
  %t539 = load ptr, ptr %l1, !tbaa !29
  %t541 = getelementptr %"compiler/ast:Catch", ptr %t539, i32 0, i32 0
  %t542 = load %"compiler/source:Span", ptr %t541
  store %"compiler/source:Span" %t542, ptr %l278
  %t543 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %s15)
  store %"compiler/msgs:Msg" %t543, ptr %l279
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t544 = load ptr, ptr %l276, !tbaa !29
  %t545 = load %"compiler/source:Span", ptr %l278
  %t546 = load %"compiler/msgs:Msg", ptr %l279
  %t547 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t544, %"compiler/source:Span" %t545, %"compiler/msgs:Msg" %t546)
  store i64 %t547, ptr %l280
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s15)
  br label %bb109
bb109:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t548)
  store ptr %t550, ptr %l282
  br label %bb110
bb110:
  %t551 = load ptr, ptr %l282, !tbaa !29
  %t553 = getelementptr %"compiler/check:frame", ptr %t551, i32 0, i32 28
  %t555 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eToA_H65e94094dadf75016f6073f244c91f3b(ptr %v0, ptr %v0, ptr %t553)
  store { i64, ptr } %t555, ptr %l285
  br label %bb111
bb111:
  %t556 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t556, ptr %lp27
  %t557 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t558 = load ptr, ptr %lp27
  store { i64, ptr } %t557, ptr %t558, !tbaa !27
  %t559 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t559)
  br label %bb112
bb112:
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t563 = getelementptr %"compiler/check:Checker", ptr %t561, i32 0, i32 17
  %t564 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t563, i64 %t564, i64 2)
  br label %bb113
bb113:
  %t567 = load ptr, ptr %l1, !tbaa !29
  %t569 = getelementptr %"compiler/ast:Catch", ptr %t567, i32 0, i32 0
  %t570 = load %"compiler/source:Span", ptr %t569
  store %"compiler/source:Span" %t570, ptr %l291
  %t571 = load i32, ptr %l7, !tbaa !23
  store i32 %t571, ptr %l292, !tbaa !23
  %t572 = load i64, ptr %l10, !tbaa !24
  %t574 = trunc i64 %t572 to i32
  store i32 %t574, ptr %l295, !tbaa !23
  %t576 = load ptr, ptr %lp27
  %t577 = load { i64, ptr }, ptr %t576, !tbaa !27
  store { i64, ptr } %t577, ptr %l296, !tbaa !27
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load ptr, ptr %l1, !tbaa !29
  %t581 = getelementptr %"compiler/ast:Catch", ptr %t579, i32 0, i32 0
  %t582 = load %"compiler/source:Span", ptr %t581
  %t586 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t578, i32 5, %"compiler/source:Span" %t582)
  store i32 %t586, ptr %l301
  br label %bb114
bb114:
  store { i64, [4 x i64] } zeroinitializer, ptr %t587
  %t588 = getelementptr { i64, [4 x i64] }, ptr %t587, i32 0, i32 0
  store i64 1, ptr %t588
  %t589 = load i32, ptr %l295, !tbaa !23
  %t590 = insertvalue { i32, { i64, ptr }, i32 } undef, i32 %t589, 0
  %t591 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t592 = insertvalue { i32, { i64, ptr }, i32 } %t590, { i64, ptr } %t591, 1
  %t593 = load i32, ptr %l301, !tbaa !23
  %t594 = insertvalue { i32, { i64, ptr }, i32 } %t592, i32 %t593, 2
  %t595 = getelementptr { i64, [4 x i64] }, ptr %t587, i32 0, i32 1
  store { i32, { i64, ptr }, i32 } %t594, ptr %t595
  %t596 = load { i64, [4 x i64] }, ptr %t587
  %t598 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t596, ptr %t598
  store { i64, [5 x i64] } zeroinitializer, ptr %t599
  %t600 = getelementptr { i64, [5 x i64] }, ptr %t599, i32 0, i32 0
  store i64 15, ptr %t600
  %t601 = load %"compiler/source:Span", ptr %l291
  %t602 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t601, 0
  %t603 = load i32, ptr %l292, !tbaa !23
  %t604 = insertvalue { %"compiler/source:Span", i32, ptr } %t602, i32 %t603, 1
  %t606 = insertvalue { %"compiler/source:Span", i32, ptr } %t604, ptr %t598, 2
  %t607 = getelementptr { i64, [5 x i64] }, ptr %t599, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t606, ptr %t607
  %t608 = load { i64, [5 x i64] }, ptr %t599
  %t610 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t608, ptr %t610
  call void @__olang_scope_close(ptr %s0)
  store ptr %t610, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommutedCall(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l19 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l66 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca i64
  %l76 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l92 = alloca i64
  %l95 = alloca %"compiler/source:Span"
  %l98 = alloca i32
  %l102 = alloca { i64, ptr }
  %l105 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t198 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t2)
  store i32 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = load i32, ptr %l14, !tbaa !23
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l15
  br label %bb2
bb2:
  %t9 = load i32, ptr %l15, !tbaa !23
  store i32 %t9, ptr %l6, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t16 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %t10, i32 %t11, i32 %t12)
  store i64 %t16, ptr %l19
  br label %bb3
bb3:
  %t17 = load i64, ptr %l19, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp slt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load i64, ptr %l7, !tbaa !24
  store i64 %t24, ptr %l24, !tbaa !24
  %t25 = load i32, ptr %l6, !tbaa !23
  store i32 %t25, ptr %l25, !tbaa !23
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t28 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t26)
  store { i64, ptr } %t28, ptr %l27
  br label %bb7
bb7:
  %t29 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t29, ptr %l28
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t32 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t30)
  store { i64, ptr } %t32, ptr %l30
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t34 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s0, { i64, ptr } %t33)
  store { i64, ptr } %t34, ptr %l31
  br label %bb9
bb9:
  %t35 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = load ptr, ptr %l23, !tbaa !29
  %t43 = load i64, ptr %l24, !tbaa !24
  %t44 = load i32, ptr %l25, !tbaa !23
  %t45 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t46 = load %"compiler/source:Span", ptr %l28
  %t48 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %s0, ptr %s0, ptr %t42, i64 %t43, i32 %t44, { i64, ptr } %t45, %"compiler/source:Span" %t46, { i64, ptr } %t41)
  store i1 %t48, ptr %l33
  br label %bb10
bb10:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l34, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l35, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t54, i64 %t55)
  store ptr %t58, ptr %l39
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l39, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t65 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t63, i32 %t62)
  store { i64, ptr } %t65, ptr %l42
  br label %bb12
bb12:
  %t66 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t67 = load ptr, ptr %l34, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 49
  store { i64, ptr } %t66, ptr %t68, !tbaa !27
  %t69 = load ptr, ptr %l4, !tbaa !29
  store ptr %t69, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb13, label %bb14
bb13:
  %t73 = load ptr, ptr %l43, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 18}
  %t76 = icmp eq i64 %t74, 0
  store i1 %t76, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t77 = load i1, ptr %l44, !tbaa !21
  br i1 %t77, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb28
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l47, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t79, ptr %l48
  %t80 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t80, ptr %l49
  %t81 = load i64, ptr %l7, !tbaa !24
  store i64 %t81, ptr %l50, !tbaa !24
  %t82 = load ptr, ptr %l5, !tbaa !29
  store ptr %t82, ptr %l52, !tbaa !29
  %t84 = icmp sge i64 0, 0
  br i1 %t84, label %bb18, label %bb19
bb18:
  %t86 = icmp sle i64 0, 1152921504606846975
  br i1 %t86, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f9674bcb1008789c_bed0ff146db7b878)
  unreachable
bb20:
  %t88 = mul i64 0, 8
  %t89 = insertvalue { i64, ptr } undef, i64 0, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t90, ptr %l55, !tbaa !27
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t95 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t91, ptr %t92)
  store { i64, ptr } %t95, ptr %l58
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f9674bcb1008789c_bed0ff146db7b878)
  unreachable
bb22:
  %t96 = icmp sge i64 0, 0
  br i1 %t96, label %bb23, label %bb24
bb23:
  %t98 = icmp sle i64 0, 2305843009213693951
  br i1 %t98, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb25:
  %t100 = mul i64 0, 4
  %t101 = insertvalue { i64, ptr } undef, i64 0, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t103 = load ptr, ptr %l47, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l48
  %t105 = load %"compiler/source:Span", ptr %l49
  %t106 = load i64, ptr %l50, !tbaa !24
  %t107 = load ptr, ptr %l52, !tbaa !29
  %t108 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s2, ptr %t103, %"compiler/source:Span" %t104, %"compiler/source:Span" %t105, i64 %t106, ptr %t107, { i64, ptr } %t108, { i64, ptr } %t109, { i64, ptr } %t102)
  store ptr %t111, ptr %l62
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb27:
  %t112 = load ptr, ptr %l62, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t112, ptr %rv
  br label %ret
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_fe55a007e1b3e29_3c78fea0979d4bfd)
  unreachable
bb33:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 37
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t116)
  store i64 %t118, ptr %l66
  br label %bb34
bb34:
  %t119 = load i64, ptr %l66, !tbaa !24
  store i64 %t119, ptr %l8, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l1
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %t120, %"compiler/source:Span" %t121, ptr %t122)
  store ptr %t126, ptr %l70
  br label %bb35
bb35:
  %t127 = load ptr, ptr %l70, !tbaa !29
  store ptr %t127, ptr %l9, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l71, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t129, ptr %l72
  %t130 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t130, ptr %l73
  %t131 = load i64, ptr %l7, !tbaa !24
  store i64 %t131, ptr %l74, !tbaa !24
  %t132 = load ptr, ptr %l5, !tbaa !29
  store ptr %t132, ptr %l76, !tbaa !29
  %t134 = icmp sge i64 0, 0
  br i1 %t134, label %bb36, label %bb37
bb36:
  %t136 = icmp sle i64 0, 1152921504606846975
  br i1 %t136, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_c4a343fb9b24edff_3458e4f6b03fbc5b)
  unreachable
bb38:
  %t138 = mul i64 0, 8
  %t139 = insertvalue { i64, ptr } undef, i64 0, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t140, ptr %l79, !tbaa !27
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l80, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l1
  %t144 = load ptr, ptr %l9, !tbaa !29
  %t148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t142, %"compiler/source:Span" %t143, ptr %t144)
  store ptr %t148, ptr %l84
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_c4a343fb9b24edff_3458e4f6b03fbc5b)
  unreachable
bb40:
  %t149 = load ptr, ptr %l80, !tbaa !29
  %t150 = load ptr, ptr %l84, !tbaa !29
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t149, ptr %t150)
  store { i64, ptr } %t151, ptr %l85
  br label %bb41
bb41:
  %t152 = icmp sge i64 0, 0
  br i1 %t152, label %bb42, label %bb43
bb42:
  %t154 = icmp sle i64 0, 2305843009213693951
  br i1 %t154, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb44:
  %t156 = mul i64 0, 4
  %t157 = insertvalue { i64, ptr } undef, i64 0, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t159 = load ptr, ptr %l71, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l72
  %t161 = load %"compiler/source:Span", ptr %l73
  %t162 = load i64, ptr %l74, !tbaa !24
  %t163 = load ptr, ptr %l76, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t159, %"compiler/source:Span" %t160, %"compiler/source:Span" %t161, i64 %t162, ptr %t163, { i64, ptr } %t164, { i64, ptr } %t165, { i64, ptr } %t158)
  store ptr %t167, ptr %l89
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb46:
  %t168 = load ptr, ptr %l89, !tbaa !29
  store ptr %t168, ptr %l10, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 37
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t171)
  store i64 %t173, ptr %l92
  br label %bb47
bb47:
  %t174 = load i64, ptr %l8, !tbaa !24
  %t175 = load i64, ptr %l92, !tbaa !24
  %t177 = icmp sgt i64 %t175, %t174
  br i1 %t177, label %bb48, label %bb49
bb48:
  %t179 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t179, ptr %l95
  %t180 = load ptr, ptr %l10, !tbaa !29
  %t183 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t180)
  store i32 %t183, ptr %l98
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 37
  %t187 = load i64, ptr %l8, !tbaa !24
  %t190 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t186, i64 %t187)
  store { i64, ptr } %t190, ptr %l102
  br label %bb51
bb51:
  %t191 = load ptr, ptr %l10, !tbaa !29
  %t193 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t195 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t193, ptr %t191)
  store %"compiler/typed:Seq" %t195, ptr %l105
  br label %bb52
bb52:
  %t196 = load %"compiler/typed:Seq", ptr %l105
  %t197 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t196, ptr %t197
  store { i64, [5 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t198, i32 0, i32 0
  store i64 12, ptr %t199
  %t200 = load %"compiler/source:Span", ptr %l95
  %t201 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t200, 0
  %t202 = load i32, ptr %l98, !tbaa !23
  %t203 = insertvalue { %"compiler/source:Span", i32, ptr } %t201, i32 %t202, 1
  %t205 = insertvalue { %"compiler/source:Span", i32, ptr } %t203, ptr %t197, 2
  %t206 = getelementptr { i64, [5 x i64] }, ptr %t198, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t205, ptr %t206
  %t207 = load { i64, [5 x i64] }, ptr %t198
  %t209 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t207, ptr %t209
  call void @__olang_scope_close(ptr %s0)
  store ptr %t209, ptr %rv
  br label %ret
bb53:
  %t211 = load ptr, ptr %l10, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t211, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeCtx(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l3 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l4 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l5 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca ptr
  %l11 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l12 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l14 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l15 = alloca i32
  %l17 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l35 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l36 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l38 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l39 = alloca i32
  %l41 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t3)
  store ptr %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t8 = getelementptr %"compiler/check:frame", ptr %t6, i32 0, i32 4
  %t9 = getelementptr %"compiler/generic:Context", ptr %t8, i32 0, i32 2
  %t11 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t9)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t11, ptr %l11
  br label %bb3
bb3:
  %t12 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l11
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t12, ptr %l2
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l2)
  %t15 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t14, 1
  %t16 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t14, 0
  store i32 %t16, ptr %l15
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb6, label %ok.18, !prof !99
ok.18:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t15, ptr %l14
  br label %bb5
bb5:
  %t19 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l14
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t19, ptr %l12
  br label %bb8
bb6:
  %t20 = load i32, ptr %l15, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb8:
  %t24 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l12
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t24, ptr %l3
  store ptr %l1, ptr %l18, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l3, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t25, i32 %t27)
  store { i64, ptr } %t30, ptr %l21
  br label %bb9
bb9:
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t33 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t34, i64 %t35)
  %t42 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t40, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t52 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t52, { i64, ptr } %t51)
  br label %bb10
bb10:
  store ptr %l1, ptr %l24, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l3, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t59, i32 %t61)
  store { i64, ptr } %t64, ptr %l29
  br label %bb11
bb11:
  %t65 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t72 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t72, { i64, ptr } %t71)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  br label %bb4
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t74)
  store ptr %t76, ptr %l32
  br label %bb15
bb15:
  %t77 = load ptr, ptr %l32, !tbaa !29
  %t79 = getelementptr %"compiler/check:frame", ptr %t77, i32 0, i32 4
  %t80 = getelementptr %"compiler/generic:Context", ptr %t79, i32 0, i32 3
  %t82 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t80)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t82, ptr %l35
  br label %bb16
bb16:
  %t83 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l35
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t83, ptr %l4
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t85 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l4)
  %t86 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t85, 1
  %t87 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t85, 0
  store i32 %t87, ptr %l39
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb19, label %ok.89, !prof !99
ok.89:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t86, ptr %l38
  br label %bb18
bb18:
  %t90 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l38
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t90, ptr %l36
  br label %bb21
bb19:
  %t91 = load i32, ptr %l39, !tbaa !23
  %t92 = ashr i32 %t91, 16
  %t94 = icmp eq i32 %t92, 1
  store i1 %t94, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb21:
  %t95 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l36
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t95, ptr %l5
  store ptr %l1, ptr %l42, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l5, i32 0, i32 0
  %t98 = load i32, ptr %t97, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t96, i32 %t98)
  store { i64, ptr } %t101, ptr %l45
  br label %bb22
bb22:
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t104 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = add i64 %t103, %t106
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t110 = add i64 %t107, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t102, i64 %t103)
  %t112 = getelementptr i8, ptr %t111, i64 %t103
  call void @olang_textcopy(ptr %t112, ptr %t105, i64 %t106)
  %t113 = getelementptr i8, ptr %t112, i64 %t106
  call void @olang_textcopy(ptr %t113, ptr %t108, i64 %t109)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t111, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } %t115, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  %t123 = load ptr, ptr %l42, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t123, { i64, ptr } %t122)
  br label %bb23
bb23:
  store ptr %l1, ptr %l48, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 2
  %t131 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l5, i32 0, i32 1
  %t132 = load i32, ptr %t131, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s5, ptr %t130, i32 %t132)
  store { i64, ptr } %t135, ptr %l53
  br label %bb24
bb24:
  %t136 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t138 = extractvalue { i64, ptr } %t136, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t143 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t143, { i64, ptr } %t142)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  br label %bb17
bb27:
  %t146 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t146, ptr %l56
  br label %bb28
bb28:
  %t147 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t147, ptr %l57, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  store i64 %t149, ptr %l58, !tbaa !24
  %t150 = load i64, ptr %l58, !tbaa !24
  %t151 = mul i64 %t150, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t151)
  %t153 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  store { i64, ptr } %t154, ptr %l59, !tbaa !27
  %t155 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l58, !tbaa !24
  %t160 = mul i64 %t159, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t156, ptr %t158, i64 %t160, i1 false)
  %t161 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t161, ptr %l57, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t162 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t162, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i64
  %l14 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l25 = alloca i32
  %l30 = alloca i32
  %l39 = alloca i64
  %l41 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load i64, ptr %l7, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l2, !tbaa !24
  store i64 %t12, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store i1 %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load i1, ptr %l14, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t28)
  store ptr %t30, ptr %l20
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t33 = getelementptr %"compiler/check:frame", ptr %t31, i32 0, i32 4
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t40 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t36, ptr %t33, ptr %t34, i32 %t35)
  store i32 %t40, ptr %l25
  br label %bb10
bb10:
  %t41 = load i32, ptr %l25, !tbaa !23
  store i32 %t41, ptr %l3, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb11
bb11:
  %t52 = load i32, ptr %l30, !range !{i32 0, i32 33}
  %t54 = trunc i64 26 to i32
  %t55 = icmp eq i32 %t52, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  store i64 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l39
  br label %bb15
bb15:
  %t70 = load i64, ptr %l39, !tbaa !24
  %t71 = icmp ne i64 %t70, 0
  br i1 %t71, label %bb16, label %bb17
bb16:
  store i64 1, ptr %l41, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t73 = load i64, ptr %l41, !tbaa !24
  store i64 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca ptr
  %l8 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb6
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t5)
  store ptr %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"compiler/check:frame", ptr %t8, i32 0, i32 4
  %t11 = getelementptr %"compiler/generic:Context", ptr %t10, i32 0, i32 3
  %t13 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l8
  br label %bb5
bb5:
  %t14 = load i64, ptr %l8, !tbaa !24
  %t15 = icmp sgt i64 %t14, 0
  store i1 %t15, ptr %l3, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l3, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l42 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l60 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca i64
  %l98 = alloca { i64, ptr }
  %l100 = alloca %"compiler/msgs:Msg"
  %l101 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/msgs:Msg"
  %l109 = alloca i64
  %l112 = alloca ptr
  %l115 = alloca ptr
  %l120 = alloca i32
  %l121 = alloca i64
  %l123 = alloca ptr
  %l127 = alloca ptr
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l138 = alloca %"compiler/generic:Context"
  %l142 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l153 = alloca ptr
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  %t300 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 23
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp ne i32 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l29, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l4, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l34
  br label %bb3
bb2:
  store ptr null, ptr %l27, !tbaa !29
  br label %bb5
bb3:
  %t26 = load ptr, ptr %l29, !tbaa !29
  %t27 = load i32, ptr %l34, !tbaa !23
  %t28 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t26, i32 %t27)
  store ptr %t28, ptr %l35
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l35, !tbaa !29
  store ptr %t29, ptr %l27, !tbaa !29
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l27, !tbaa !29
  store ptr %t30, ptr %l5, !tbaa !29
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = icmp sle i64 0, 1152921504606846975
  br i1 %t33, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_bc2b949bbef92b23_ac5d28fb0edf1ff)
  unreachable
bb8:
  %t35 = mul i64 0, 8
  %t36 = insertvalue { i64, ptr } undef, i64 0, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_bc2b949bbef92b23_ac5d28fb0edf1ff)
  unreachable
bb10:
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = getelementptr %"compiler/ast:TypeDecl", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  %t52 = xor i1 %t50, true
  store i1 %t52, ptr %l42, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l42, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:TypeDecl", ptr %t55, i32 0, i32 3
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l7, !tbaa !29
  %t60 = load ptr, ptr %l7, !tbaa !29
  store ptr %t60, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t61 = load ptr, ptr %l49, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb15, label %bb16
bb14:
  br label %bb26
bb15:
  %t64 = load ptr, ptr %l49, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 5}
  %t67 = icmp eq i64 %t65, 0
  store i1 %t67, ptr %l50, !tbaa !21
  br label %bb16
bb16:
  %t68 = load i1, ptr %l50, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t71 = getelementptr { i64, [6 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { ptr }, ptr %t71, i32 0, i32 0
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l8, !tbaa !29
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t75 = load ptr, ptr %l8, !tbaa !29
  %t77 = getelementptr %"compiler/ast:StructBody", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l6, !tbaa !27
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_fc391d98a693d1b5_39c844f8cb4c6229)
  unreachable
bb25:
  br label %bb26
bb26:
  %t80 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = icmp eq i64 %t82, 0
  br i1 %t84, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb29
bb28:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t92 = icmp sge i64 %t86, %t89
  store i1 %t92, ptr %l60, !tbaa !21
  br label %bb29
bb29:
  %t94 = load i1, ptr %l60, !tbaa !21
  br i1 %t94, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb32
bb31:
  %t95 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t95, ptr %l66, !tbaa !27
  %t96 = load i64, ptr %l2, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 %t96
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = getelementptr %"compiler/ast:Param", ptr %t101, i32 0, i32 3
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  store i1 %t106, ptr %l65, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l65, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  store i64 0, ptr %l9, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t109, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l12, !tbaa !24
  br label %bb35
bb34:
  br label %bb55
bb35:
  %t115 = load i64, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb36, label %bb37
bb36:
  br label %bb43
bb37:
  br label %bb38
bb38:
  %t123 = load i64, ptr %l11, !tbaa !24
  store i64 %t123, ptr %l13, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t125, ptr %l79, !tbaa !27
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr ptr, ptr %t129, i64 %t126
  %t131 = load ptr, ptr %t130, !tbaa !39
  %t135 = getelementptr %"compiler/ast:Param", ptr %t131, i32 0, i32 3
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = icmp eq ptr %t136, null
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t140 = load i64, ptr %l13, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l9, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t144 = load i64, ptr %l11, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l11, !tbaa !24
  br label %bb35
bb43:
  %t148 = load i64, ptr %l9, !tbaa !24
  %t149 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t154 = icmp eq i64 %t148, %t151
  br i1 %t154, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l93, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l94
  %t158 = load i64, ptr %l9, !tbaa !24
  store i64 %t158, ptr %l95, !tbaa !24
  %t159 = load i64, ptr %l9, !tbaa !24
  %t161 = icmp eq i64 %t159, 1
  br i1 %t161, label %bb46, label %bb47
bb45:
  store %olang.scope zeroinitializer, ptr %s10
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l102, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t164, ptr %l103
  %t165 = load i64, ptr %l9, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = load i64, ptr %l2, !tbaa !24
  %t173 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCountRange(ptr %s10, i64 %t165, i64 %t168, i64 %t169)
  store %"compiler/msgs:Msg" %t173, ptr %l108
  br label %bb51
bb46:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l98, !tbaa !27
  br label %bb48
bb47:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l98, !tbaa !27
  br label %bb48
bb48:
  %t174 = load i64, ptr %l2, !tbaa !24
  %t175 = load i64, ptr %l95, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t178 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s9, ptr %s9, i64 %t175, { i64, ptr } %t176, i64 %t174)
  store %"compiler/msgs:Msg" %t178, ptr %l100
  br label %bb49
bb49:
  %t179 = load ptr, ptr %l93, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l94
  %t181 = load %"compiler/msgs:Msg", ptr %l100
  %t182 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t179, %"compiler/source:Span" %t180, %"compiler/msgs:Msg" %t181)
  store i64 %t182, ptr %l101
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb51:
  %t183 = load ptr, ptr %l102, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l103
  %t185 = load %"compiler/msgs:Msg", ptr %l108
  %t186 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t183, %"compiler/source:Span" %t184, %"compiler/msgs:Msg" %t185)
  store i64 %t186, ptr %l109
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s10)
  br label %bb53
bb53:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l1
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t187, %"compiler/source:Span" %t188)
  store ptr %t191, ptr %l112
  br label %bb54
bb54:
  %t192 = load ptr, ptr %l112, !tbaa !29
  store ptr %t192, ptr %rv
  br label %ret
bb55:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = getelementptr %"compiler/generic:Program", ptr %t196, i32 0, i32 2
  store ptr %t198, ptr %l115, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  %t205 = load i32, ptr %l4, !tbaa !23
  %t208 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t204, i32 %t205)
  store i32 %t208, ptr %l120
  br label %bb56
bb56:
  %t209 = load ptr, ptr %l115, !tbaa !29
  %t210 = load i32, ptr %l120, !tbaa !23
  %t211 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t209, i32 %t210)
  store i64 %t211, ptr %l121
  br label %bb57
bb57:
  %t212 = load i64, ptr %l121, !tbaa !24
  store i64 %t212, ptr %l15, !tbaa !24
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t213)
  store ptr %t215, ptr %l123
  br label %bb58
bb58:
  %t216 = load ptr, ptr %l123, !tbaa !29
  %t218 = getelementptr %"compiler/check:frame", ptr %t216, i32 0, i32 2
  %t219 = load i64, ptr %t218, !tbaa !24
  store i64 %t219, ptr %l16, !tbaa !24
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t221)
  store ptr %t223, ptr %l127
  br label %bb59
bb59:
  %t224 = load ptr, ptr %l127, !tbaa !29
  store ptr %t224, ptr %l17, !tbaa !29
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l17, !tbaa !29
  %t228 = getelementptr %"compiler/check:frame", ptr %t226, i32 0, i32 0
  %t229 = load i64, ptr %t228, !tbaa !24
  %t230 = load i64, ptr %l15, !tbaa !24
  %t231 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t225, i64 %t229, i64 %t230, i32 %t231, i32 0)
  store ptr %t236, ptr %l133
  br label %bb60
bb60:
  %t237 = load ptr, ptr %l133, !tbaa !29
  store ptr %t237, ptr %l18, !tbaa !29
  %t238 = load ptr, ptr %l18, !tbaa !29
  store ptr %t238, ptr %l134, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t243 = load i32, ptr %l4, !tbaa !23
  %t246 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %v0, ptr %v0, ptr %t242, i32 %t243)
  store %"compiler/generic:Context" %t246, ptr %l138
  br label %bb61
bb61:
  %t247 = load %"compiler/generic:Context", ptr %l138
  %t248 = load ptr, ptr %l134, !tbaa !29
  %t249 = getelementptr %"compiler/check:frame", ptr %t248, i32 0, i32 4
  store %"compiler/generic:Context" %t247, ptr %t249
  %t250 = load ptr, ptr %l18, !tbaa !29
  %t251 = load ptr, ptr %l17, !tbaa !29
  %t253 = getelementptr %"compiler/check:frame", ptr %t251, i32 0, i32 7
  %t254 = load i64, ptr %t253, !tbaa !24
  %t257 = getelementptr %"compiler/check:frame", ptr %t250, i32 0, i32 7
  store i64 %t254, ptr %t257, !tbaa !24
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l142, !tbaa !29
  %t259 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t259, ptr %l143, !tbaa !27
  %t260 = load i64, ptr %l2, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr ptr, ptr %t263, i64 %t260
  %t265 = load ptr, ptr %t264, !tbaa !39
  %t267 = getelementptr %"compiler/ast:Param", ptr %t265, i32 0, i32 3
  %t268 = load ptr, ptr %t267, !tbaa !29
  store ptr %t268, ptr %l19, !tbaa !29
  %t270 = load ptr, ptr %l19, !tbaa !29
  %t272 = icmp eq ptr %t270, null
  br i1 %t272, label %bb62, label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_ff2084232290eae7_203579eb66e705cb)
  unreachable
bb63:
  br label %bb64
bb64:
  %t274 = load ptr, ptr %l19, !tbaa !29
  %t276 = load ptr, ptr %l142, !tbaa !29
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v0, ptr %t276, ptr %t274, i32 %a3)
  store ptr %t279, ptr %l151
  br label %bb65
bb65:
  %t280 = load ptr, ptr %l151, !tbaa !29
  store ptr %t280, ptr %l20, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t281)
  store ptr %t283, ptr %l153
  br label %bb66
bb66:
  %t284 = load ptr, ptr %l153, !tbaa !29
  %t286 = getelementptr %"compiler/check:frame", ptr %t284, i32 0, i32 2
  %t287 = load i64, ptr %t286, !tbaa !24
  store i64 %t287, ptr %l21, !tbaa !24
  %t289 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t289)
  br label %bb67
bb67:
  %t291 = load i64, ptr %l21, !tbaa !24
  %t292 = load i64, ptr %l16, !tbaa !24
  %t295 = icmp ne i64 %t291, %t292
  br i1 %t295, label %bb68, label %bb69
bb68:
  %t297 = load %"compiler/source:Span", ptr %l1
  %t298 = load i64, ptr %l21, !tbaa !24
  %t299 = load ptr, ptr %l20, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t300
  %t301 = getelementptr { i64, [5 x i64] }, ptr %t300, i32 0, i32 0
  store i64 17, ptr %t301
  %t303 = insertvalue { %"compiler/source:Span", i64, ptr } undef, %"compiler/source:Span" %t297, 0
  %t305 = insertvalue { %"compiler/source:Span", i64, ptr } %t303, i64 %t298, 1
  %t307 = insertvalue { %"compiler/source:Span", i64, ptr } %t305, ptr %t299, 2
  %t308 = getelementptr { i64, [5 x i64] }, ptr %t300, i32 0, i32 1
  store { %"compiler/source:Span", i64, ptr } %t307, ptr %t308
  %t309 = load { i64, [5 x i64] }, ptr %t300
  %t311 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t309, ptr %t311
  store ptr %t311, ptr %rv
  br label %ret
bb69:
  br label %bb70
bb70:
  %t313 = load ptr, ptr %l20, !tbaa !29
  store ptr %t313, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i1
  %l13 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @compiler_2fcheck_2ehasNamed(ptr %v1, { i64, ptr } %t1)
  store i1 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i1, ptr %l7, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t12, i32 %t13)
  store ptr %t16, ptr %l13
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l13, !tbaa !29
  store ptr %t17, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/ast:TypeDecl", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  %t31 = xor i1 %t29, true
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeDecl", ptr %t34, i32 0, i32 3
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l4, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb11, label %bb12
bb10:
  br label %bb25
bb11:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 5}
  %t46 = icmp eq i64 %t44, 0
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l25, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr { i64, [6 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { ptr }, ptr %t50, i32 0, i32 0
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l30, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:StructBody", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l32, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t59, ptr %l33, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l34, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %l1, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l39
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l34, !tbaa !29
  %t72 = load i32, ptr %l39, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t71, i32 %t72)
  store { i64, ptr } %t73, ptr %l40
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l30, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t78 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v0, ptr %v1, ptr %v0, ptr %t74, { i64, ptr } %t75, { i64, ptr } %t76, { i64, ptr } %t77)
  store { i64, ptr } %t78, ptr %l41
  br label %bb18
bb18:
  %t79 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_7f8223142f689eb4_f934e4a817092f38)
  unreachable
bb24:
  br label %bb25
bb25:
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca i1
  %l55 = alloca i1
  %l56 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i1
  %l72 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l97 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
bb16:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb17, label %bb18
bb17:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb18
bb18:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb19, label %bb20
bb19:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb26
bb21:
  %t46 = load i1, ptr %l2, !tbaa !21
  br i1 %t46, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb25
bb23:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store i1 %t53, ptr %l33
  br label %bb24
bb24:
  %t54 = load i1, ptr %l33, !tbaa !21
  store i1 %t54, ptr %l29, !tbaa !21
  br label %bb25
bb25:
  %t55 = load i1, ptr %l29, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
bb26:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb27, label %bb28
bb27:
  %t60 = load ptr, ptr %l34, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 8}
  %t63 = icmp eq i64 %t61, 3
  store i1 %t63, ptr %l35, !tbaa !21
  br label %bb28
bb28:
  %t64 = load i1, ptr %l35, !tbaa !21
  br i1 %t64, label %bb29, label %bb30
bb29:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t73 = load i1, ptr %l2, !tbaa !21
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t71, ptr %t72, i1 %t73)
  store i1 %t77, ptr %l43
  br label %bb32
bb32:
  %t78 = load i1, ptr %l43, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
bb33:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t80 = load ptr, ptr %l44, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb34, label %bb35
bb34:
  %t83 = load ptr, ptr %l44, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 8}
  %t86 = icmp eq i64 %t84, 4
  store i1 %t86, ptr %l45, !tbaa !21
  br label %bb35
bb35:
  %t87 = load i1, ptr %l45, !tbaa !21
  br i1 %t87, label %bb36, label %bb37
bb36:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t90, i32 0, i32 2
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l5, !tbaa !29
  br label %bb38
bb37:
  br label %bb55
bb38:
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Elem", ptr %t94, i32 0, i32 2
  %t97 = load i32, ptr %t96, !range !{i32 0, i32 3}
  %t99 = trunc i64 1 to i32
  %t100 = icmp eq i32 %t97, %t99
  br i1 %t100, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb46
bb40:
  %t102 = load i1, ptr %l2, !tbaa !21
  br i1 %t102, label %bb41, label %bb42
bb41:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l56, !tbaa !29
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Elem", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t108)
  store i32 %t110, ptr %l59
  br label %bb43
bb42:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb45
bb43:
  %t111 = load ptr, ptr %l56, !tbaa !29
  %t112 = load i32, ptr %l59, !tbaa !23
  %t113 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t113, ptr %l60
  br label %bb44
bb44:
  %t114 = load i1, ptr %l60, !tbaa !21
  store i1 %t114, ptr %l55, !tbaa !21
  br label %bb45
bb45:
  %t115 = load i1, ptr %l55, !tbaa !21
  store i1 %t115, ptr %l53, !tbaa !21
  br label %bb46
bb46:
  %t116 = load i1, ptr %l53, !tbaa !21
  br i1 %t116, label %bb47, label %bb48
bb47:
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Elem", ptr %t119, i32 0, i32 0
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t123 = load i1, ptr %l2, !tbaa !21
  %t127 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t118, ptr %t122, i1 %t123)
  store i1 %t127, ptr %l66
  br label %bb50
bb50:
  %t128 = load i1, ptr %l66, !tbaa !21
  br i1 %t128, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb54
bb52:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l5, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Elem", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t137 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t129, ptr %t133)
  store i1 %t137, ptr %l72
  br label %bb53
bb53:
  %t138 = load i1, ptr %l72, !tbaa !21
  store i1 %t138, ptr %l67, !tbaa !21
  br label %bb54
bb54:
  %t139 = load i1, ptr %l67, !tbaa !21
  store i1 %t139, ptr %rv
  br label %ret
bb55:
  %t140 = load ptr, ptr %l1, !tbaa !29
  store ptr %t140, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t141 = load ptr, ptr %l73, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb56, label %bb57
bb56:
  %t144 = load ptr, ptr %l73, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 8}
  %t147 = icmp eq i64 %t145, 5
  store i1 %t147, ptr %l74, !tbaa !21
  br label %bb57
bb57:
  %t148 = load i1, ptr %l74, !tbaa !21
  br i1 %t148, label %bb58, label %bb59
bb58:
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr { i64, [4 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t151, i32 0, i32 2
  %t153 = load ptr, ptr %t152
  store ptr %t153, ptr %l6, !tbaa !29
  br label %bb60
bb59:
  br label %bb65
bb60:
  %t155 = load ptr, ptr %l6, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Payload", ptr %t155, i32 0, i32 2
  %t158 = load i32, ptr %t157, !range !{i32 0, i32 3}
  %t160 = trunc i64 1 to i32
  %t161 = icmp eq i32 %t158, %t160
  br i1 %t161, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb64
bb62:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l6, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Payload", ptr %t164, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t168 = load i1, ptr %l2, !tbaa !21
  %t172 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t163, ptr %t167, i1 %t168)
  store i1 %t172, ptr %l87
  br label %bb63
bb63:
  %t173 = load i1, ptr %l87, !tbaa !21
  store i1 %t173, ptr %l82, !tbaa !21
  br label %bb64
bb64:
  %t174 = load i1, ptr %l82, !tbaa !21
  store i1 %t174, ptr %rv
  br label %ret
bb65:
  %t175 = load ptr, ptr %l1, !tbaa !29
  store ptr %t175, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t176 = load ptr, ptr %l88, !tbaa !29
  %t177 = icmp ne ptr %t176, null
  br i1 %t177, label %bb66, label %bb67
bb66:
  %t179 = load ptr, ptr %l88, !tbaa !29
  %t180 = load i64, ptr %t179, !range !{i64 0, i64 8}
  %t182 = icmp eq i64 %t180, 6
  store i1 %t182, ptr %l89, !tbaa !21
  br label %bb67
bb67:
  %t183 = load i1, ptr %l89, !tbaa !21
  br i1 %t183, label %bb68, label %bb69
bb68:
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t186, i32 0, i32 2
  %t188 = load ptr, ptr %t187
  store ptr %t188, ptr %l7, !tbaa !29
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load ptr, ptr %l7, !tbaa !29
  %t195 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t190, ptr %t191)
  store i1 %t195, ptr %l97
  br label %bb71
bb71:
  %t196 = load i1, ptr %l97, !tbaa !21
  store i1 %t196, ptr %rv
  br label %ret
bb72:
  call void @__olang_check_failed(ptr @olang_loc_a395790432891bd8_5a5437b807a0153c)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, [3 x i64] }
  %l42 = alloca ptr
  %l46 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i32
  %l57 = alloca ptr
  %l62 = alloca i32
  %l64 = alloca i64
  %l67 = alloca i1
  %l71 = alloca i1
  %l75 = alloca i1
  %l76 = alloca i1
  %l78 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca %"compiler/msgs:Nearest"
  %l93 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca ptr
  %l120 = alloca ptr
  %l125 = alloca i32
  %l126 = alloca i32
  %l127 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l135 = alloca %"compiler/msgs:Msg"
  %l136 = alloca i64
  %l141 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l146 = alloca i32
  %l149 = alloca ptr
  %l154 = alloca i32
  %l155 = alloca { i64, ptr }
  %l161 = alloca i64
  %l164 = alloca i64
  %l185 = alloca { i64, ptr }
  %l188 = alloca i32
  %l202 = alloca ptr
  %l203 = alloca ptr
  %l204 = alloca %"compiler/source:Span"
  %l207 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l212 = alloca %"compiler/msgs:Msg"
  %l213 = alloca i64
  %l218 = alloca ptr
  %l223 = alloca { i64, ptr }
  %l232 = alloca i64
  %l235 = alloca i64
  %l253 = alloca { i64, ptr }
  %l263 = alloca ptr
  %l264 = alloca %"compiler/source:Span"
  %l268 = alloca %"compiler/msgs:Msg"
  %l269 = alloca i64
  %l272 = alloca ptr
  %l281 = alloca i32
  %l284 = alloca ptr
  %l289 = alloca i32
  %l290 = alloca { i64, ptr }
  %l300 = alloca ptr
  %l301 = alloca %"compiler/source:Span"
  %l303 = alloca i64
  %l307 = alloca { i64, ptr }
  %l309 = alloca %"compiler/msgs:Msg"
  %l310 = alloca i64
  %l313 = alloca ptr
  %l316 = alloca i64
  %l318 = alloca ptr
  %l323 = alloca i32
  %l324 = alloca ptr
  %l326 = alloca ptr
  %l331 = alloca i64
  %l334 = alloca i64
  %l357 = alloca i1
  %l362 = alloca i1
  %l368 = alloca ptr
  %l369 = alloca ptr
  %l371 = alloca ptr
  %l376 = alloca i32
  %l377 = alloca i64
  %l379 = alloca { i64, ptr }
  %l383 = alloca { i64, [3 x i64] }
  %l388 = alloca i1
  %l389 = alloca { i64, ptr }
  %l396 = alloca ptr
  %l397 = alloca ptr
  %l398 = alloca { i64, ptr }
  %l400 = alloca ptr
  %l401 = alloca { i64, ptr }
  %l403 = alloca i32
  %l405 = alloca { i64, ptr }
  %l408 = alloca %"compiler/source:Span"
  %l409 = alloca ptr
  %l411 = alloca { i64, ptr }
  %l414 = alloca { i64, ptr }
  %l417 = alloca ptr
  %l421 = alloca { i64, ptr }
  %l424 = alloca i1
  %l426 = alloca ptr
  %l428 = alloca ptr
  %l429 = alloca { i64, ptr }
  %l432 = alloca %"compiler/source:Span"
  %l434 = alloca i1
  %l443 = alloca { i64, ptr }
  %l444 = alloca %"compiler/source:Span"
  %l445 = alloca i32
  %l450 = alloca %"compiler/typed:Make"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t864 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l46
  br label %bb1
bb1:
  %t6 = load i1, ptr %l46, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l50
  br label %bb4
bb3:
  br label %bb76
bb4:
  %t14 = load i1, ptr %l50, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l54
  br label %bb7
bb6:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb8
bb7:
  %t20 = load i32, ptr %l54, !range !{i32 0, i32 6}
  %t22 = trunc i64 2 to i32
  %t23 = icmp eq i32 %t20, %t22
  store i1 %t23, ptr %l51, !tbaa !21
  br label %bb8
bb8:
  %t25 = load i1, ptr %l51, !tbaa !21
  br i1 %t25, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l57, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l62
  br label %bb11
bb10:
  br label %bb69
bb11:
  %t37 = load i32, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l57, !tbaa !29
  %t39 = load i32, ptr %l62, !tbaa !23
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %t38, i32 %t39, i32 %t37)
  store i64 %t41, ptr %l64
  br label %bb12
bb12:
  %t42 = load i64, ptr %l64, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t43, 0
  br i1 %t45, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb15
bb14:
  %t47 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp sgt i64 %t49, 0
  store i1 %t51, ptr %l67, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l67, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb24
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t58 = load i32, ptr %l3, !tbaa !23
  %t61 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %t57, i32 %t58)
  store i1 %t61, ptr %l75
  br label %bb18
bb18:
  %t62 = load i1, ptr %l75, !tbaa !21
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l78, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l3, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l83
  br label %bb21
bb20:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb23
bb21:
  %t77 = load ptr, ptr %l78, !tbaa !29
  %t78 = load i32, ptr %l83, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t77, i32 %t78)
  store { i64, ptr } %t79, ptr %l84
  br label %bb22
bb22:
  %t80 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  store i1 %t83, ptr %l76, !tbaa !21
  br label %bb23
bb23:
  %t85 = load i1, ptr %l76, !tbaa !21
  store i1 %t85, ptr %l71, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l71, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l4, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t87, i32 %t88)
  store { i64, ptr } %t91, ptr %l89
  br label %bb27
bb26:
  br label %bb48
bb27:
  %t92 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t93 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s3, { i64, ptr } %t92)
  store %"compiler/msgs:Nearest" %t93, ptr %l90
  br label %bb28
bb28:
  %t94 = load %"compiler/msgs:Nearest", ptr %l90
  %t95 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t94, ptr %t95
  store ptr %t95, ptr %l8, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  store ptr %t100, ptr %l93, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %l3, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l98
  br label %bb29
bb29:
  %t111 = load ptr, ptr %l93, !tbaa !29
  %t112 = load i32, ptr %l98, !tbaa !23
  %t113 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t111, i32 %t112)
  store { i64, ptr } %t113, ptr %l99
  br label %bb30
bb30:
  %t114 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t114, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l11, !tbaa !24
  br label %bb31
bb31:
  %t119 = load i64, ptr %l10, !tbaa !24
  %t120 = load i64, ptr %l11, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb32, label %bb33
bb32:
  br label %bb38
bb33:
  br label %bb34
bb34:
  %t127 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t127, ptr %l106, !tbaa !27
  %t128 = load i64, ptr %l10, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i32, ptr %t131, i64 %t128
  %t133 = load i32, ptr %t132, !tbaa !33
  %t135 = load ptr, ptr %l8, !tbaa !29
  store ptr %t135, ptr %l109, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t140 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t136, i32 %t133)
  store { i64, ptr } %t140, ptr %l112
  br label %bb35
bb35:
  %t141 = load ptr, ptr %l109, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l112, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s3, ptr %v0, ptr %t141, { i64, ptr } %t142)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t143 = load i64, ptr %l10, !tbaa !24
  %t145 = add i64 %t143, 1
  store i64 %t145, ptr %l10, !tbaa !24
  br label %bb31
bb38:
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l115, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t148, ptr %l116
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l117, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  store ptr %t155, ptr %l120, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  %t162 = load i32, ptr %l3, !tbaa !23
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t161, i32 %t162)
  store i32 %t165, ptr %l125
  br label %bb39
bb39:
  %t166 = load ptr, ptr %l120, !tbaa !29
  %t167 = load i32, ptr %l125, !tbaa !23
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t166, i32 %t167)
  store i32 %t168, ptr %l126
  br label %bb40
bb40:
  %t169 = load ptr, ptr %l117, !tbaa !29
  %t170 = load i32, ptr %l126, !tbaa !23
  %t171 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t169, i32 %t170)
  store { i64, ptr } %t171, ptr %l127
  br label %bb41
bb41:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l4, !tbaa !23
  %t176 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t172, i32 %t173)
  store { i64, ptr } %t176, ptr %l130
  br label %bb42
bb42:
  %t177 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = extractvalue { i64, ptr } %t177, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  store { i64, ptr } %t183, ptr %l131, !tbaa !27
  %t184 = load ptr, ptr %l8, !tbaa !29
  %t186 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s3, ptr %s3, ptr %t184)
  store { i64, ptr } %t186, ptr %l133
  br label %bb43
bb43:
  %t187 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t189 = extractvalue { i64, ptr } %t187, 1
  %t190 = mul i64 %t188, 1
  %t191 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t190)
  call void @llvm.memcpy.p0.p0.i64(ptr %t191, ptr %t189, i64 %t190, i1 false)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  %t194 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t197 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchErrorWord(ptr %v0, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t194, { i64, ptr } %t195, { i64, ptr } %t193)
  store %"compiler/msgs:Msg" %t197, ptr %l135
  br label %bb44
bb44:
  %t198 = load ptr, ptr %l115, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l116
  %t200 = load %"compiler/msgs:Msg", ptr %l135
  %t201 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t198, %"compiler/source:Span" %t199, %"compiler/msgs:Msg" %t200)
  store i64 %t201, ptr %l136
  br label %bb45
bb45:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t202, { i64, ptr } %t203)
  br label %bb46
bb46:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l1
  %t210 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t206, %"compiler/source:Span" %t207)
  store ptr %t210, ptr %l141
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t211 = load ptr, ptr %l141, !tbaa !29
  store ptr %t211, ptr %rv
  br label %ret
bb48:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t216 = load i32, ptr %l3, !tbaa !23
  %t217 = mul i64 1, 4
  %t218 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t217)
  %t219 = insertvalue { i64, ptr } undef, i64 1, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  store { i64, ptr } %t220, ptr %l145, !tbaa !27
  %t222 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i32, ptr %t223, i64 0
  store i32 %t216, ptr %t224, !tbaa !33
  %t226 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t227 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %s2, ptr %t215, { i64, ptr } %t226)
  store i32 %t227, ptr %l146
  br label %bb49
bb49:
  %t228 = load i32, ptr %l146, !tbaa !23
  store i32 %t228, ptr %l13, !tbaa !23
  store i64 0, ptr %l14, !tbaa !24
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/check:Checker", ptr %t229, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t234 = getelementptr %"compiler/generic:Program", ptr %t232, i32 0, i32 2
  store ptr %t234, ptr %l149, !tbaa !29
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/generic:Program", ptr %t238, i32 0, i32 2
  %t241 = load i32, ptr %l13, !tbaa !23
  %t244 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t240, i32 %t241)
  store i32 %t244, ptr %l154
  br label %bb50
bb50:
  %t245 = load ptr, ptr %l149, !tbaa !29
  %t246 = load i32, ptr %l154, !tbaa !23
  %t247 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t245, i32 %t246)
  store { i64, ptr } %t247, ptr %l155
  br label %bb51
bb51:
  %t248 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t248, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t249 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t249, 0
  store i64 %t251, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t253 = load i64, ptr %l17, !tbaa !24
  %t254 = load i64, ptr %l16, !tbaa !24
  %t257 = icmp sgt i64 %t253, %t254
  br i1 %t257, label %bb52, label %bb53
bb52:
  %t259 = load i64, ptr %l18, !tbaa !24
  %t261 = icmp sgt i64 %t259, 0
  br i1 %t261, label %bb54, label %bb55
bb53:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb57
bb54:
  %t263 = load i64, ptr %l17, !tbaa !24
  %t264 = load i64, ptr %l16, !tbaa !24
  %t267 = sub i64 %t263, %t264
  %t268 = load i64, ptr %l18, !tbaa !24
  %t271 = add i64 %t267, %t268
  %t273 = sub i64 %t271, 1
  %t274 = load i64, ptr %l18, !tbaa !24
  %t277 = sdiv i64 %t273, %t274
  store i64 %t277, ptr %l164, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb56
bb56:
  %t279 = load i64, ptr %l164, !tbaa !24
  store i64 %t279, ptr %l161, !tbaa !24
  br label %bb57
bb57:
  %t280 = load i64, ptr %l161, !tbaa !24
  store i64 %t280, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb58
bb58:
  %t281 = load i64, ptr %l20, !tbaa !24
  %t282 = load i64, ptr %l19, !tbaa !24
  %t285 = icmp slt i64 %t281, %t282
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb59, label %bb60
bb59:
  br label %bb67
bb60:
  br label %bb61
bb61:
  %t289 = load i64, ptr %l16, !tbaa !24
  %t290 = load i64, ptr %l20, !tbaa !24
  %t291 = load i64, ptr %l18, !tbaa !24
  %t294 = mul i64 %t290, %t291
  %t297 = add i64 %t289, %t294
  store i64 %t297, ptr %l21, !tbaa !24
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = getelementptr %"compiler/generic:Program", ptr %t302, i32 0, i32 2
  %t305 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t305, ptr %l185, !tbaa !27
  %t306 = load i64, ptr %l21, !tbaa !24
  %t308 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr i32, ptr %t309, i64 %t306
  %t311 = load i32, ptr %t310, !tbaa !33
  %t314 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t304, i32 %t311)
  store i32 %t314, ptr %l188
  br label %bb62
bb62:
  %t315 = load i32, ptr %l3, !tbaa !23
  %t316 = load i32, ptr %l188, !tbaa !23
  %t318 = icmp eq i32 %t316, %t315
  br i1 %t318, label %bb63, label %bb64
bb63:
  %t320 = load i64, ptr %l21, !tbaa !24
  store i64 %t320, ptr %l14, !tbaa !24
  br label %bb65
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t322 = load i64, ptr %l20, !tbaa !24
  %t324 = add i64 %t322, 1
  store i64 %t324, ptr %l20, !tbaa !24
  br label %bb58
bb67:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l1
  %t328 = load i32, ptr %l13, !tbaa !23
  %t329 = load i64, ptr %l14, !tbaa !24
  %t331 = add i64 %t329, 1
  %t333 = shl i64 %t331, 16
  %t334 = load i64, ptr %l7, !tbaa !24
  %t337 = or i64 %t333, %t334
  %t342 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t326, %"compiler/source:Span" %t327, i32 %t328, i64 %t337)
  store ptr %t342, ptr %l202
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t343 = load ptr, ptr %l202, !tbaa !29
  store ptr %t343, ptr %rv
  br label %ret
bb69:
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l203, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t345, ptr %l204
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i32, ptr %l3, !tbaa !23
  %t350 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t346, i32 %t347)
  store { i64, ptr } %t350, ptr %l207
  br label %bb70
bb70:
  %t351 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t351, 0
  %t353 = extractvalue { i64, ptr } %t351, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  store { i64, ptr } %t357, ptr %l208, !tbaa !27
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i32, ptr %l4, !tbaa !23
  %t362 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t358, i32 %t359)
  store { i64, ptr } %t362, ptr %l211
  br label %bb71
bb71:
  %t363 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t365 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %s1, ptr %v0, ptr %s1, { i64, ptr } %t363, { i64, ptr } %t364)
  store %"compiler/msgs:Msg" %t365, ptr %l212
  br label %bb72
bb72:
  %t366 = load ptr, ptr %l203, !tbaa !29
  %t367 = load %"compiler/source:Span", ptr %l204
  %t368 = load %"compiler/msgs:Msg", ptr %l212
  %t369 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t366, %"compiler/source:Span" %t367, %"compiler/msgs:Msg" %t368)
  store i64 %t369, ptr %l213
  br label %bb73
bb73:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t370, { i64, ptr } %t371)
  br label %bb74
bb74:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load %"compiler/source:Span", ptr %l1
  %t378 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t374, %"compiler/source:Span" %t375)
  store ptr %t378, ptr %l218
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s1)
  %t379 = load ptr, ptr %l218, !tbaa !29
  store ptr %t379, ptr %rv
  br label %ret
bb76:
  store i64 -1, ptr %l22, !tbaa !24
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t385 = getelementptr %"compiler/generic:Program", ptr %t383, i32 0, i32 2
  %t386 = load i32, ptr %l3, !tbaa !23
  %t389 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t385, i32 %t386)
  store { i64, ptr } %t389, ptr %l223
  br label %bb77
bb77:
  %t390 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t390, ptr %l23, !tbaa !27
  %t391 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t391, 0
  %t395 = icmp sgt i64 %t393, 0
  br i1 %t395, label %bb78, label %bb79
bb78:
  store i64 0, ptr %l24, !tbaa !24
  %t397 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t399 = extractvalue { i64, ptr } %t397, 0
  store i64 %t399, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t401 = load i64, ptr %l25, !tbaa !24
  %t402 = load i64, ptr %l24, !tbaa !24
  %t405 = icmp sgt i64 %t401, %t402
  br i1 %t405, label %bb80, label %bb81
bb79:
  br label %bb95
bb80:
  %t407 = load i64, ptr %l26, !tbaa !24
  %t409 = icmp sgt i64 %t407, 0
  br i1 %t409, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l232, !tbaa !24
  br label %bb85
bb82:
  %t411 = load i64, ptr %l25, !tbaa !24
  %t412 = load i64, ptr %l24, !tbaa !24
  %t415 = sub i64 %t411, %t412
  %t416 = load i64, ptr %l26, !tbaa !24
  %t419 = add i64 %t415, %t416
  %t421 = sub i64 %t419, 1
  %t422 = load i64, ptr %l26, !tbaa !24
  %t425 = sdiv i64 %t421, %t422
  store i64 %t425, ptr %l235, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l235, !tbaa !24
  br label %bb84
bb84:
  %t427 = load i64, ptr %l235, !tbaa !24
  store i64 %t427, ptr %l232, !tbaa !24
  br label %bb85
bb85:
  %t428 = load i64, ptr %l232, !tbaa !24
  store i64 %t428, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb86
bb86:
  %t429 = load i64, ptr %l28, !tbaa !24
  %t430 = load i64, ptr %l27, !tbaa !24
  %t433 = icmp slt i64 %t429, %t430
  %t435 = xor i1 %t433, true
  br i1 %t435, label %bb87, label %bb88
bb87:
  br label %bb94
bb88:
  br label %bb89
bb89:
  %t437 = load i64, ptr %l24, !tbaa !24
  %t438 = load i64, ptr %l28, !tbaa !24
  %t439 = load i64, ptr %l26, !tbaa !24
  %t442 = mul i64 %t438, %t439
  %t445 = add i64 %t437, %t442
  store i64 %t445, ptr %l29, !tbaa !24
  %t447 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t447, ptr %l253, !tbaa !27
  %t448 = load i64, ptr %l29, !tbaa !24
  %t450 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t451 = load ptr, ptr %t450, !tbaa !27
  %t452 = getelementptr i32, ptr %t451, i64 %t448
  %t453 = load i32, ptr %t452, !tbaa !33
  %t454 = load i32, ptr %l4, !tbaa !23
  %t457 = icmp eq i32 %t453, %t454
  br i1 %t457, label %bb90, label %bb91
bb90:
  %t459 = load i64, ptr %l29, !tbaa !24
  store i64 %t459, ptr %l22, !tbaa !24
  br label %bb92
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t461 = load i64, ptr %l28, !tbaa !24
  %t463 = add i64 %t461, 1
  store i64 %t463, ptr %l28, !tbaa !24
  br label %bb86
bb94:
  br label %bb95
bb95:
  %t465 = load i64, ptr %l22, !tbaa !24
  %t467 = icmp slt i64 %t465, 0
  br i1 %t467, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s16
  %t469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t469, ptr %l263, !tbaa !29
  %t470 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t470, ptr %l264
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load i32, ptr %l3, !tbaa !23
  %t473 = load i32, ptr %l4, !tbaa !23
  %t477 = call %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %s16, ptr %t471, i32 %t472, i32 %t473)
  store %"compiler/msgs:Msg" %t477, ptr %l268
  br label %bb98
bb97:
  br label %bb101
bb98:
  %t478 = load ptr, ptr %l263, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l264
  %t480 = load %"compiler/msgs:Msg", ptr %l268
  %t481 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t478, %"compiler/source:Span" %t479, %"compiler/msgs:Msg" %t480)
  store i64 %t481, ptr %l269
  br label %bb99
bb99:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load %"compiler/source:Span", ptr %l1
  %t486 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t482, %"compiler/source:Span" %t483)
  store ptr %t486, ptr %l272
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s16)
  %t487 = load ptr, ptr %l272, !tbaa !29
  store ptr %t487, ptr %rv
  br label %ret
bb101:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load i32, ptr %l3, !tbaa !23
  %t490 = load i32, ptr %l4, !tbaa !23
  %t491 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %t488, i32 %t489, i32 %t490, %"compiler/source:Span" %t491)
  br label %bb102
bb102:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/check:Checker", ptr %t496, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !29
  %t500 = load i32, ptr %l3, !tbaa !23
  %t501 = load i64, ptr %l22, !tbaa !24
  %t505 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t499, i32 %t500, i64 %t501)
  store i32 %t505, ptr %l281
  br label %bb103
bb103:
  %t506 = load i32, ptr %l281, !tbaa !23
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/check:Checker", ptr %t507, i32 0, i32 1
  %t510 = load ptr, ptr %t509, !tbaa !29
  %t512 = getelementptr %"compiler/generic:Program", ptr %t510, i32 0, i32 2
  store ptr %t512, ptr %l284, !tbaa !29
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = getelementptr %"compiler/check:Checker", ptr %t513, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !29
  %t518 = getelementptr %"compiler/generic:Program", ptr %t516, i32 0, i32 2
  %t522 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t518, i32 %t506)
  store i32 %t522, ptr %l289
  br label %bb104
bb104:
  %t523 = load ptr, ptr %l284, !tbaa !29
  %t524 = load i32, ptr %l289, !tbaa !23
  %t525 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t523, i32 %t524)
  store { i64, ptr } %t525, ptr %l290
  br label %bb105
bb105:
  %t526 = load { i64, ptr }, ptr %l290, !tbaa !27
  store { i64, ptr } %t526, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t527 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t527, 0
  %t531 = icmp sgt i64 %t529, 0
  br i1 %t531, label %bb106, label %bb107
bb106:
  %t533 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t535 = extractvalue { i64, ptr } %t533, 0
  store i64 %t535, ptr %l32, !tbaa !24
  br label %bb108
bb107:
  br label %bb108
bb108:
  %t537 = load i64, ptr %l32, !tbaa !24
  %t538 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t538, 0
  %t543 = icmp ne i64 %t537, %t540
  br i1 %t543, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s18
  %t545 = load ptr, ptr %l0, !tbaa !29
  store ptr %t545, ptr %l300, !tbaa !29
  %t546 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t546, ptr %l301
  %t547 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t547, 0
  store i64 %t549, ptr %l303, !tbaa !24
  %t550 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t550, 0
  %t554 = icmp eq i64 %t552, 1
  br i1 %t554, label %bb111, label %bb112
bb110:
  br label %bb117
bb111:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l307, !tbaa !27
  br label %bb113
bb112:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l307, !tbaa !27
  br label %bb113
bb113:
  %t556 = load i64, ptr %l32, !tbaa !24
  %t557 = load i64, ptr %l303, !tbaa !24
  %t558 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t560 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s18, ptr %s18, i64 %t557, { i64, ptr } %t558, i64 %t556)
  store %"compiler/msgs:Msg" %t560, ptr %l309
  br label %bb114
bb114:
  %t561 = load ptr, ptr %l300, !tbaa !29
  %t562 = load %"compiler/source:Span", ptr %l301
  %t563 = load %"compiler/msgs:Msg", ptr %l309
  %t564 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t561, %"compiler/source:Span" %t562, %"compiler/msgs:Msg" %t563)
  store i64 %t564, ptr %l310
  br label %bb115
bb115:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load %"compiler/source:Span", ptr %l1
  %t569 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t565, %"compiler/source:Span" %t566)
  store ptr %t569, ptr %l313
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s18)
  %t570 = load ptr, ptr %l313, !tbaa !29
  store ptr %t570, ptr %rv
  br label %ret
bb117:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = getelementptr %"compiler/check:Checker", ptr %t571, i32 0, i32 36
  %t575 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t573)
  store i64 %t575, ptr %l316
  br label %bb118
bb118:
  %t576 = load i64, ptr %l316, !tbaa !24
  store i64 %t576, ptr %l33, !tbaa !24
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t579 = getelementptr %"compiler/check:Checker", ptr %t577, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !29
  store ptr %t580, ptr %l318, !tbaa !29
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = getelementptr %"compiler/check:Checker", ptr %t581, i32 0, i32 1
  %t584 = load ptr, ptr %t583, !tbaa !29
  %t586 = getelementptr %"compiler/generic:Program", ptr %t584, i32 0, i32 2
  %t587 = load i32, ptr %l3, !tbaa !23
  %t590 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t586, i32 %t587)
  store i32 %t590, ptr %l323
  br label %bb119
bb119:
  %t591 = load ptr, ptr %l318, !tbaa !29
  %t592 = load i32, ptr %l323, !tbaa !23
  %t593 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t591, i32 %t592)
  store ptr %t593, ptr %l324
  br label %bb120
bb120:
  %t594 = load i64, ptr %l22, !tbaa !24
  %t595 = load ptr, ptr %l324, !tbaa !29
  %t597 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %t595, i64 %t594)
  store ptr %t597, ptr %l326
  br label %bb121
bb121:
  %t598 = load ptr, ptr %l326, !tbaa !29
  store ptr %t598, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  %t599 = load i64, ptr %l32, !tbaa !24
  store i64 %t599, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t601 = load i64, ptr %l36, !tbaa !24
  %t602 = load i64, ptr %l35, !tbaa !24
  %t605 = icmp sgt i64 %t601, %t602
  br i1 %t605, label %bb122, label %bb123
bb122:
  %t607 = load i64, ptr %l37, !tbaa !24
  %t609 = icmp sgt i64 %t607, 0
  br i1 %t609, label %bb124, label %bb125
bb123:
  store i64 0, ptr %l331, !tbaa !24
  br label %bb127
bb124:
  %t611 = load i64, ptr %l36, !tbaa !24
  %t612 = load i64, ptr %l35, !tbaa !24
  %t615 = sub i64 %t611, %t612
  %t616 = load i64, ptr %l37, !tbaa !24
  %t619 = add i64 %t615, %t616
  %t621 = sub i64 %t619, 1
  %t622 = load i64, ptr %l37, !tbaa !24
  %t625 = sdiv i64 %t621, %t622
  store i64 %t625, ptr %l334, !tbaa !24
  br label %bb126
bb125:
  store i64 0, ptr %l334, !tbaa !24
  br label %bb126
bb126:
  %t627 = load i64, ptr %l334, !tbaa !24
  store i64 %t627, ptr %l331, !tbaa !24
  br label %bb127
bb127:
  %t628 = load i64, ptr %l331, !tbaa !24
  store i64 %t628, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb128
bb128:
  %t629 = load i64, ptr %l39, !tbaa !24
  %t630 = load i64, ptr %l38, !tbaa !24
  %t633 = icmp slt i64 %t629, %t630
  %t635 = xor i1 %t633, true
  br i1 %t635, label %bb129, label %bb130
bb129:
  br label %bb161
bb130:
  br label %bb131
bb131:
  %t637 = load i64, ptr %l35, !tbaa !24
  %t638 = load i64, ptr %l39, !tbaa !24
  %t639 = load i64, ptr %l37, !tbaa !24
  %t642 = mul i64 %t638, %t639
  %t645 = add i64 %t637, %t642
  store i64 %t645, ptr %l40, !tbaa !24
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"compiler/check:Checker", ptr %t647, i32 0, i32 11
  %t650 = load { i64, [3 x i64] }, ptr %t649
  store { i64, [3 x i64] } %t650, ptr %l41
  %t652 = load ptr, ptr %l34, !tbaa !29
  %t654 = icmp eq ptr %t652, null
  %t656 = xor i1 %t654, true
  br i1 %t656, label %bb132, label %bb133
bb132:
  %t658 = load ptr, ptr %l34, !tbaa !29
  %t660 = getelementptr %"compiler/ast:CaseDecl", ptr %t658, i32 0, i32 2
  %t661 = load { i64, ptr }, ptr %t660, !tbaa !27
  %t663 = extractvalue { i64, ptr } %t661, 0
  %t665 = icmp sgt i64 %t663, 0
  store i1 %t665, ptr %l357, !tbaa !21
  br label %bb134
bb133:
  store i1 false, ptr %l357, !tbaa !21
  br label %bb134
bb134:
  %t667 = load i1, ptr %l357, !tbaa !21
  br i1 %t667, label %bb135, label %bb136
bb135:
  %t668 = load i64, ptr %l40, !tbaa !24
  %t669 = load ptr, ptr %l34, !tbaa !29
  %t671 = getelementptr %"compiler/ast:CaseDecl", ptr %t669, i32 0, i32 2
  %t672 = load { i64, ptr }, ptr %t671, !tbaa !27
  %t674 = extractvalue { i64, ptr } %t672, 0
  %t677 = icmp slt i64 %t668, %t674
  store i1 %t677, ptr %l362, !tbaa !21
  br label %bb137
bb136:
  store i1 false, ptr %l362, !tbaa !21
  br label %bb137
bb137:
  %t679 = load i1, ptr %l362, !tbaa !21
  br i1 %t679, label %bb138, label %bb139
bb138:
  %t680 = load ptr, ptr %l0, !tbaa !29
  store ptr %t680, ptr %l368, !tbaa !29
  %t681 = load ptr, ptr %l0, !tbaa !29
  store ptr %t681, ptr %l369, !tbaa !29
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t684 = getelementptr %"compiler/check:Checker", ptr %t682, i32 0, i32 1
  %t685 = load ptr, ptr %t684, !tbaa !29
  store ptr %t685, ptr %l371, !tbaa !29
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/check:Checker", ptr %t686, i32 0, i32 1
  %t689 = load ptr, ptr %t688, !tbaa !29
  %t691 = getelementptr %"compiler/generic:Program", ptr %t689, i32 0, i32 2
  %t692 = load i32, ptr %l3, !tbaa !23
  %t695 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t691, i32 %t692)
  store i32 %t695, ptr %l376
  br label %bb140
bb139:
  br label %bb143
bb140:
  %t696 = load ptr, ptr %l371, !tbaa !29
  %t697 = load i32, ptr %l376, !tbaa !23
  %t698 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t696, i32 %t697)
  store i64 %t698, ptr %l377
  br label %bb141
bb141:
  %t699 = load ptr, ptr %l34, !tbaa !29
  %t701 = getelementptr %"compiler/ast:CaseDecl", ptr %t699, i32 0, i32 2
  %t702 = load { i64, ptr }, ptr %t701, !tbaa !27
  store { i64, ptr } %t702, ptr %l379, !tbaa !27
  %t703 = load i64, ptr %l40, !tbaa !24
  %t705 = getelementptr { i64, ptr }, ptr %l379, i32 0, i32 1
  %t706 = load ptr, ptr %t705, !tbaa !27
  %t707 = getelementptr ptr, ptr %t706, i64 %t703
  %t708 = load ptr, ptr %t707, !tbaa !39
  %t710 = getelementptr %"compiler/ast:Param", ptr %t708, i32 0, i32 2
  %t711 = load ptr, ptr %t710, !tbaa !29
  %t712 = load ptr, ptr %l369, !tbaa !29
  %t713 = load i64, ptr %l377, !tbaa !24
  %t715 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t712, i64 %t713, ptr %t711)
  store { i64, [3 x i64] } %t715, ptr %l383
  br label %bb142
bb142:
  %t716 = load { i64, [3 x i64] }, ptr %l383
  %t717 = load ptr, ptr %l368, !tbaa !29
  %t718 = getelementptr %"compiler/check:Checker", ptr %t717, i32 0, i32 11
  store { i64, [3 x i64] } %t716, ptr %t718
  br label %bb143
bb143:
  %t719 = load i64, ptr %l40, !tbaa !24
  %t720 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t722 = extractvalue { i64, ptr } %t720, 0
  %t725 = icmp slt i64 %t719, %t722
  br i1 %t725, label %bb144, label %bb145
bb144:
  %t727 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t727, ptr %l389, !tbaa !27
  %t728 = load i64, ptr %l40, !tbaa !24
  %t730 = getelementptr { i64, ptr }, ptr %l389, i32 0, i32 1
  %t731 = load ptr, ptr %t730, !tbaa !27
  %t732 = getelementptr ptr, ptr %t731, i64 %t728
  %t733 = load ptr, ptr %t732, !tbaa !39
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t736 = getelementptr %"compiler/check:Checker", ptr %t734, i32 0, i32 0
  %t737 = load ptr, ptr %t736, !tbaa !29
  %t740 = icmp eq ptr %t733, %t737
  %t742 = xor i1 %t740, true
  store i1 %t742, ptr %l388, !tbaa !21
  br label %bb146
bb145:
  store i1 false, ptr %l388, !tbaa !21
  br label %bb146
bb146:
  %t744 = load i1, ptr %l388, !tbaa !21
  br i1 %t744, label %bb147, label %bb148
bb147:
  %t745 = load ptr, ptr %l0, !tbaa !29
  store ptr %t745, ptr %l397, !tbaa !29
  %t746 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t746, ptr %l398, !tbaa !27
  %t747 = load i64, ptr %l40, !tbaa !24
  %t749 = getelementptr { i64, ptr }, ptr %l398, i32 0, i32 1
  %t750 = load ptr, ptr %t749, !tbaa !27
  %t751 = getelementptr ptr, ptr %t750, i64 %t747
  %t752 = load ptr, ptr %t751, !tbaa !39
  store ptr %t752, ptr %l400, !tbaa !29
  %t753 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t753, ptr %l401, !tbaa !27
  %t754 = load i64, ptr %l40, !tbaa !24
  %t756 = getelementptr { i64, ptr }, ptr %l401, i32 0, i32 1
  %t757 = load ptr, ptr %t756, !tbaa !27
  %t758 = getelementptr i32, ptr %t757, i64 %t754
  %t759 = load i32, ptr %t758, !tbaa !33
  store i32 %t759, ptr %l403, !tbaa !23
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t761 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t761, ptr %l405, !tbaa !27
  %t762 = load i64, ptr %l40, !tbaa !24
  %t764 = getelementptr { i64, ptr }, ptr %l405, i32 0, i32 1
  %t765 = load ptr, ptr %t764, !tbaa !27
  %t766 = getelementptr ptr, ptr %t765, i64 %t762
  %t767 = load ptr, ptr %t766, !tbaa !39
  %t770 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t760, ptr %t767)
  store %"compiler/source:Span" %t770, ptr %l408
  br label %bb149
bb148:
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t772 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t772, ptr %l411, !tbaa !27
  %t773 = load i64, ptr %l40, !tbaa !24
  %t775 = getelementptr { i64, ptr }, ptr %l411, i32 0, i32 1
  %t776 = load ptr, ptr %t775, !tbaa !27
  %t777 = getelementptr ptr, ptr %t776, i64 %t773
  %t778 = load ptr, ptr %t777, !tbaa !39
  %t779 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t779, ptr %l414, !tbaa !27
  %t780 = load i64, ptr %l40, !tbaa !24
  %t782 = getelementptr { i64, ptr }, ptr %l414, i32 0, i32 1
  %t783 = load ptr, ptr %t782, !tbaa !27
  %t784 = getelementptr i32, ptr %t783, i64 %t780
  %t785 = load i32, ptr %t784, !tbaa !33
  %t789 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t771, ptr %t778, i32 %t785)
  store ptr %t789, ptr %l417
  br label %bb151
bb149:
  %t790 = load ptr, ptr %l397, !tbaa !29
  %t791 = load ptr, ptr %l400, !tbaa !29
  %t792 = load i32, ptr %l403, !tbaa !23
  %t793 = load %"compiler/source:Span", ptr %l408
  %t794 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t790, ptr %t791, i32 %t792, %"compiler/source:Span" %t793)
  store ptr %t794, ptr %l409
  br label %bb150
bb150:
  %t795 = load ptr, ptr %l409, !tbaa !29
  store ptr %t795, ptr %l396, !tbaa !29
  br label %bb152
bb151:
  %t796 = load ptr, ptr %l417, !tbaa !29
  store ptr %t796, ptr %l396, !tbaa !29
  br label %bb152
bb152:
  %t797 = load ptr, ptr %l396, !tbaa !29
  store ptr %t797, ptr %l42, !tbaa !29
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t799 = load { i64, [3 x i64] }, ptr %l41
  %t802 = getelementptr %"compiler/check:Checker", ptr %t798, i32 0, i32 11
  store { i64, [3 x i64] } %t799, ptr %t802
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t804 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t804, ptr %l421, !tbaa !27
  %t805 = load i64, ptr %l40, !tbaa !24
  %t807 = getelementptr { i64, ptr }, ptr %l421, i32 0, i32 1
  %t808 = load ptr, ptr %t807, !tbaa !27
  %t809 = getelementptr i32, ptr %t808, i64 %t805
  %t810 = load i32, ptr %t809, !tbaa !33
  %t813 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t803, i32 %t810)
  store i1 %t813, ptr %l424
  br label %bb153
bb153:
  %t814 = load i1, ptr %l424, !tbaa !21
  %t815 = xor i1 %t814, true
  br i1 %t815, label %bb154, label %bb155
bb154:
  %t817 = load ptr, ptr %l0, !tbaa !29
  store ptr %t817, ptr %l426, !tbaa !29
  %t818 = load ptr, ptr %l42, !tbaa !29
  store ptr %t818, ptr %l428, !tbaa !29
  %t820 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t820, ptr %l429, !tbaa !27
  %t821 = load i64, ptr %l40, !tbaa !24
  %t823 = getelementptr { i64, ptr }, ptr %l429, i32 0, i32 1
  %t824 = load ptr, ptr %t823, !tbaa !27
  %t825 = getelementptr ptr, ptr %t824, i64 %t821
  %t826 = load ptr, ptr %t825, !tbaa !39
  %t828 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t826)
  store %"compiler/source:Span" %t828, ptr %l432
  br label %bb156
bb155:
  br label %bb158
bb156:
  %t829 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t830 = load ptr, ptr %l426, !tbaa !29
  %t831 = load ptr, ptr %l428, !tbaa !29
  %t832 = load %"compiler/source:Span", ptr %l432
  %t834 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t830, ptr %t831, %"compiler/source:Span" %t832, i64 %t829)
  store i1 %t834, ptr %l434
  br label %bb157
bb157:
  br label %bb158
bb158:
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t837 = getelementptr %"compiler/check:Checker", ptr %t835, i32 0, i32 36
  %t838 = load ptr, ptr %l42, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t837, ptr %t838)
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t841 = load i64, ptr %l39, !tbaa !24
  %t843 = add i64 %t841, 1
  store i64 %t843, ptr %l39, !tbaa !24
  br label %bb128
bb161:
  %t845 = load ptr, ptr %l0, !tbaa !29
  %t847 = getelementptr %"compiler/check:Checker", ptr %t845, i32 0, i32 36
  %t848 = load i64, ptr %l33, !tbaa !24
  %t851 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t847, i64 %t848)
  store { i64, ptr } %t851, ptr %l443
  br label %bb162
bb162:
  %t852 = load { i64, ptr }, ptr %l443, !tbaa !27
  %t853 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t853, ptr %l444
  %t854 = load i32, ptr %l3, !tbaa !23
  store i32 %t854, ptr %l445, !tbaa !23
  %t855 = load i64, ptr %l22, !tbaa !24
  %t861 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 1, i64 %t855, { i64, ptr } %t852, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t861, ptr %l450
  br label %bb163
bb163:
  %t862 = load %"compiler/typed:Make", ptr %l450
  %t863 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t862, ptr %t863
  store { i64, [5 x i64] } zeroinitializer, ptr %t864
  %t865 = getelementptr { i64, [5 x i64] }, ptr %t864, i32 0, i32 0
  store i64 7, ptr %t865
  %t866 = load %"compiler/source:Span", ptr %l444
  %t867 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t866, 0
  %t868 = load i32, ptr %l445, !tbaa !23
  %t869 = insertvalue { %"compiler/source:Span", i32, ptr } %t867, i32 %t868, 1
  %t871 = insertvalue { %"compiler/source:Span", i32, ptr } %t869, ptr %t863, 2
  %t872 = getelementptr { i64, [5 x i64] }, ptr %t864, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t871, ptr %t872
  %t873 = load { i64, [5 x i64] }, ptr %t864
  %t875 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t873, ptr %t875
  store ptr %t875, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrHeld(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l27 = alloca i32
  %l28 = alloca i64
  %l41 = alloca ptr
  %rv = alloca ptr
  %t62 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fde34f6ad3d04e85_8bb8dc064f471149)
  unreachable
bb16:
  br label %bb28
bb17:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb18, label %bb19
bb18:
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb19
bb19:
  %t35 = load i1, ptr %l17, !tbaa !21
  br i1 %t35, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_7e2870e38111b7d4_913a9c3a02b86678)
  unreachable
bb28:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t38)
  store %"compiler/source:Span" %t40, ptr %l22
  br label %bb29
bb29:
  %t41 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t41, ptr %l3
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l23, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t43, ptr %l24
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t44)
  store i32 %t47, ptr %l27
  br label %bb30
bb30:
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l24
  %t50 = load i32, ptr %l27, !tbaa !23
  %t51 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t48, %"compiler/source:Span" %t49, i32 %t50)
  store i64 %t51, ptr %l28
  br label %bb31
bb31:
  %t52 = load i64, ptr %l28, !tbaa !24
  store i64 %t52, ptr %l4, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 37
  %t56 = load %"compiler/source:Span", ptr %l3
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = trunc i64 %t57 to i32
  %t61 = load ptr, ptr %l1, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t65 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t56, 0
  %t67 = insertvalue { %"compiler/source:Span", i32, ptr } %t65, i32 %t59, 1
  %t69 = insertvalue { %"compiler/source:Span", i32, ptr } %t67, ptr %t61, 2
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t69, ptr %t70
  %t71 = load { i64, [3 x i64] }, ptr %t62
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t71, ptr %t73
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t55, ptr %t73)
  br label %bb32
bb32:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l3
  %t78 = load i64, ptr %l4, !tbaa !24
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t76, %"compiler/source:Span" %t77, i64 %t78)
  store ptr %t82, ptr %l41
  br label %bb33
bb33:
  %t83 = load ptr, ptr %l41, !tbaa !29
  store ptr %t83, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldOffset(ptr %v0, ptr %a0, %"compiler/generic:Desc" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/generic:Desc"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l10 = alloca i32
  %l14 = alloca i1
  %l19 = alloca i1
  %l24 = alloca { i64, ptr }
  %l29 = alloca i64
  %l34 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l57 = alloca i1
  %l64 = alloca { i64, ptr }
  %l69 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/generic:Desc" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %t4, i32 %t6)
  store i32 %t9, ptr %l10
  br label %bb1
bb1:
  %t10 = load i32, ptr %l10, !tbaa !23
  store i32 %t10, ptr %l2, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l14
  br label %bb2
bb2:
  %t19 = load i1, ptr %l14, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l2, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %s2, ptr %t34, i32 %t35)
  store { i64, ptr } %t38, ptr %l24
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t39 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t39, ptr %l3, !tbaa !27
  %t40 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t47 = icmp slt i64 %t41, %t44
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t50 = load i64, ptr %t49, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i64, ptr %t53, i64 %t50
  %t55 = load i64, ptr %t54, !tbaa !34
  store i64 %t55, ptr %l29, !tbaa !24
  br label %bb12
bb11:
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i64, ptr %l29, !tbaa !24
  store i64 %t57, ptr %rv
  br label %ret
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  store ptr %t63, ptr %l34, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l39
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l34, !tbaa !29
  %t75 = load i32, ptr %l39, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t74, i32 %t75)
  store { i64, ptr } %t76, ptr %l40
  br label %bb15
bb15:
  %t77 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t77, ptr %l4, !tbaa !27
  %t78 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 2
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t85 = icmp sge i64 %t79, %t82
  br i1 %t85, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb18
bb17:
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t87, ptr %l46, !tbaa !27
  %t88 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 2
  %t89 = load i64, ptr %t88, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i32, ptr %t92, i64 %t89
  %t94 = load i32, ptr %t93, !tbaa !33
  %t96 = icmp eq i32 %t94, 0
  store i1 %t96, ptr %l45, !tbaa !21
  br label %bb18
bb18:
  %t98 = load i1, ptr %l45, !tbaa !21
  br i1 %t98, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t100, ptr %l51, !tbaa !27
  %t101 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 2
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i32, ptr %t105, i64 %t102
  %t107 = load i32, ptr %t106, !tbaa !33
  store i32 %t107, ptr %l5, !tbaa !23
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load i32, ptr %l5, !tbaa !23
  %t116 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t112, i32 %t113)
  store i1 %t116, ptr %l57
  br label %bb22
bb22:
  %t117 = load i1, ptr %l57, !tbaa !21
  %t118 = xor i1 %t117, true
  br i1 %t118, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l5, !tbaa !23
  %t130 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %s0, ptr %t126, i32 %t127)
  store { i64, ptr } %t130, ptr %l64
  br label %bb26
bb26:
  %t131 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t131, ptr %l6, !tbaa !27
  %t132 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t139 = icmp slt i64 %t133, %t136
  br i1 %t139, label %bb27, label %bb28
bb27:
  %t141 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t142 = load i64, ptr %t141, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i64, ptr %t145, i64 %t142
  %t147 = load i64, ptr %t146, !tbaa !34
  %t149 = add i64 8, %t147
  store i64 %t149, ptr %l69, !tbaa !24
  br label %bb29
bb28:
  store i64 -1, ptr %l69, !tbaa !24
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t151 = load i64, ptr %l69, !tbaa !24
  store i64 %t151, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstValueType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l31 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i1
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i1
  %l51 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %a2)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i32, ptr %l7, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l4, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t14 = call i1 @compiler_2fcheck_2enullValue(ptr %v1, ptr %a1)
  store i1 %t14, ptr %l13
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t15 = load i1, ptr %l13, !tbaa !21
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l4, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l18
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t27 = load i32, ptr %l18, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l4, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l23
  br label %bb11
bb11:
  %t38 = load i32, ptr %l23, !range !{i32 0, i32 33}
  %t40 = trunc i64 19 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l4, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l31
  br label %bb14
bb13:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb15
bb14:
  %t53 = load i32, ptr %l31, !tbaa !23
  %t54 = icmp ne i32 %t53, 0
  store i1 %t54, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l26, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v3, ptr %t57, ptr %a3)
  store i1 %t61, ptr %l36
  br label %bb18
bb17:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb19
bb18:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l39, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l4, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l44
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t80 = load ptr, ptr %l39, !tbaa !29
  %t81 = load i32, ptr %l44, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t80, i32 %t81, i32 0)
  store i32 %t82, ptr %l45
  br label %bb23
bb23:
  %t83 = load i32, ptr %l45, !tbaa !23
  store i32 %t83, ptr %l4, !tbaa !23
  br label %bb24
bb24:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l48
  br label %bb25
bb25:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l4, !tbaa !23
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l51
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t95 = load i32, ptr %l51, !tbaa !23
  store i32 %t95, ptr %l4, !tbaa !23
  br label %bb29
bb29:
  %t96 = load i32, ptr %l4, !tbaa !23
  store i32 %t96, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efuncFits(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l37 = alloca i1
  %l43 = alloca i1
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l81 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca i1
  %l89 = alloca { i64, ptr }
  %l92 = alloca i1
  %l93 = alloca i1
  %l96 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l101 = alloca i32
  %l103 = alloca { i64, ptr }
  %l106 = alloca i32
  %l107 = alloca i1
  %l113 = alloca { i64, ptr }
  %l116 = alloca i64
  %l120 = alloca i1
  %l124 = alloca { i64, ptr }
  %l127 = alloca i64
  %l138 = alloca i32
  %l143 = alloca i32
  %l147 = alloca i1
  %l151 = alloca i1
  %l154 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca { i64, ptr }
  %l169 = alloca i1
  %l173 = alloca i1
  %l174 = alloca i1
  %l177 = alloca i1
  %l178 = alloca i1
  %l181 = alloca ptr
  %l184 = alloca i32
  %l187 = alloca i32
  %l188 = alloca i1
  %l195 = alloca i64
  %l199 = alloca i1
  %l204 = alloca i64
  %l213 = alloca i32
  %l218 = alloca i32
  %l222 = alloca i1
  %l223 = alloca ptr
  %l228 = alloca i32
  %l233 = alloca i32
  %l234 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l16, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l21
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = load i32, ptr %l21, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l25, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l30
  br label %bb3
bb3:
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = load i32, ptr %l30, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l31
  br label %bb4
bb4:
  %t40 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t49 = icmp ne i64 %t43, %t46
  br i1 %t49, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb8
bb6:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load i32, ptr %l1, !tbaa !23
  %t58 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t56, i32 %t57, i32 %t58)
  store i1 %t62, ptr %l43
  br label %bb7
bb7:
  %t63 = load i1, ptr %l43, !tbaa !21
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %l37, !tbaa !21
  br label %bb8
bb8:
  %t66 = load i1, ptr %l37, !tbaa !21
  br i1 %t66, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  store i64 0, ptr %l6, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb12, label %bb13
bb12:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb17
bb14:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l54, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb16
bb16:
  %t98 = load i64, ptr %l54, !tbaa !24
  store i64 %t98, ptr %l51, !tbaa !24
  br label %bb17
bb17:
  %t99 = load i64, ptr %l51, !tbaa !24
  store i64 %t99, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb18
bb18:
  %t100 = load i64, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l9, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb19, label %bb20
bb19:
  br label %bb49
bb20:
  br label %bb21
bb21:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t109 = load i64, ptr %l10, !tbaa !24
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l11, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t124, ptr %l75, !tbaa !27
  %t125 = load i64, ptr %l11, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i32, ptr %t128, i64 %t125
  %t130 = load i32, ptr %t129, !tbaa !33
  %t131 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t131, ptr %l78, !tbaa !27
  %t132 = load i64, ptr %l11, !tbaa !24
  %t134 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i32, ptr %t135, i64 %t132
  %t137 = load i32, ptr %t136, !tbaa !33
  %t141 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t123, i32 %t130, i32 %t137)
  store i1 %t141, ptr %l81
  br label %bb22
bb22:
  %t142 = load i1, ptr %l81, !tbaa !21
  br i1 %t142, label %bb23, label %bb24
bb23:
  br label %bb48
bb24:
  br label %bb25
bb25:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t144, ptr %l83, !tbaa !27
  %t145 = load i64, ptr %l11, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i32, ptr %t148, i64 %t145
  %t150 = load i32, ptr %t149, !tbaa !33
  %t153 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t143, i32 %t150)
  store i1 %t153, ptr %l86
  br label %bb26
bb26:
  %t154 = load i1, ptr %l86, !tbaa !21
  br i1 %t154, label %bb27, label %bb28
bb27:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t156, ptr %l89, !tbaa !27
  %t157 = load i64, ptr %l11, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  %t165 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t155, i32 %t162)
  store i1 %t165, ptr %l92
  br label %bb29
bb28:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb30
bb29:
  %t166 = load i1, ptr %l92, !tbaa !21
  store i1 %t166, ptr %l87, !tbaa !21
  br label %bb30
bb30:
  %t167 = load i1, ptr %l87, !tbaa !21
  br i1 %t167, label %bb31, label %bb32
bb31:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  store ptr %t173, ptr %l96, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t175, ptr %l98, !tbaa !27
  %t176 = load i64, ptr %l11, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i32, ptr %t179, i64 %t176
  %t181 = load i32, ptr %t180, !tbaa !33
  %t184 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t174, i32 %t181)
  store i32 %t184, ptr %l101
  br label %bb33
bb32:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb36
bb33:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t186, ptr %l103, !tbaa !27
  %t187 = load i64, ptr %l11, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i32, ptr %t190, i64 %t187
  %t192 = load i32, ptr %t191, !tbaa !33
  %t195 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t185, i32 %t192)
  store i32 %t195, ptr %l106
  br label %bb34
bb34:
  %t196 = load ptr, ptr %l96, !tbaa !29
  %t197 = load i32, ptr %l101, !tbaa !23
  %t198 = load i32, ptr %l106, !tbaa !23
  %t199 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t196, i32 %t197, i32 %t198)
  store i1 %t199, ptr %l107
  br label %bb35
bb35:
  %t200 = load i1, ptr %l107, !tbaa !21
  store i1 %t200, ptr %l93, !tbaa !21
  br label %bb36
bb36:
  %t201 = load i1, ptr %l93, !tbaa !21
  %t202 = xor i1 %t201, true
  br i1 %t202, label %bb37, label %bb38
bb37:
  store i1 false, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 2
  %t211 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t211, ptr %l113, !tbaa !27
  %t212 = load i64, ptr %l11, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i32, ptr %t215, i64 %t212
  %t217 = load i32, ptr %t216, !tbaa !33
  %t220 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t210, i32 %t217)
  store i64 %t220, ptr %l116
  br label %bb40
bb40:
  %t221 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t222 = load i64, ptr %l116, !tbaa !24
  %t224 = and i64 %t222, %t221
  %t226 = icmp ne i64 %t224, 0
  br i1 %t226, label %bb41, label %bb42
bb41:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t234, ptr %l124, !tbaa !27
  %t235 = load i64, ptr %l11, !tbaa !24
  %t237 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr i32, ptr %t238, i64 %t235
  %t240 = load i32, ptr %t239, !tbaa !33
  %t243 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t233, i32 %t240)
  store i64 %t243, ptr %l127
  br label %bb43
bb42:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb44
bb43:
  %t244 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t245 = load i64, ptr %l127, !tbaa !24
  %t247 = and i64 %t245, %t244
  %t249 = icmp eq i64 %t247, 0
  store i1 %t249, ptr %l120, !tbaa !21
  br label %bb44
bb44:
  %t251 = load i1, ptr %l120, !tbaa !21
  br i1 %t251, label %bb45, label %bb46
bb45:
  store i1 false, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t253 = load i64, ptr %l10, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l10, !tbaa !24
  br label %bb18
bb49:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/generic:Program", ptr %t260, i32 0, i32 2
  %t263 = load i32, ptr %l1, !tbaa !23
  %t266 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t262, i32 %t263)
  store i32 %t266, ptr %l138
  br label %bb50
bb50:
  %t267 = load i32, ptr %l138, !tbaa !23
  store i32 %t267, ptr %l12, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 2
  %t274 = load i32, ptr %l2, !tbaa !23
  %t277 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t273, i32 %t274)
  store i32 %t277, ptr %l143
  br label %bb51
bb51:
  %t278 = load i32, ptr %l143, !tbaa !23
  store i32 %t278, ptr %l13, !tbaa !23
  %t279 = load i32, ptr %l12, !tbaa !23
  %t280 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t283 = icmp eq i32 %t279, %t280
  br i1 %t283, label %bb52, label %bb53
bb52:
  %t285 = load i32, ptr %l13, !tbaa !23
  %t286 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t289 = icmp eq i32 %t285, %t286
  store i1 %t289, ptr %l147, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb54
bb54:
  %t291 = load i1, ptr %l147, !tbaa !21
  br i1 %t291, label %bb55, label %bb56
bb55:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/generic:Program", ptr %t295, i32 0, i32 2
  store ptr %t297, ptr %l154, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/generic:Program", ptr %t301, i32 0, i32 2
  %t304 = load i32, ptr %l2, !tbaa !23
  %t307 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t303, i32 %t304)
  store i32 %t307, ptr %l159
  br label %bb57
bb56:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb59
bb57:
  %t308 = load ptr, ptr %l154, !tbaa !29
  %t309 = load i32, ptr %l159, !tbaa !23
  %t310 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t308, i32 %t309)
  store { i64, ptr } %t310, ptr %l160
  br label %bb58
bb58:
  %t311 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  %t314 = icmp eq i64 %t312, 0
  store i1 %t314, ptr %l151, !tbaa !21
  br label %bb59
bb59:
  %t316 = load i1, ptr %l151, !tbaa !21
  br i1 %t316, label %bb60, label %bb61
bb60:
  store i1 true, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/check:Checker", ptr %t318, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = getelementptr %"compiler/generic:Program", ptr %t321, i32 0, i32 2
  %t324 = load i32, ptr %l12, !tbaa !23
  %t325 = load i32, ptr %l13, !tbaa !23
  %t329 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t323, i32 %t324, i32 %t325)
  store i1 %t329, ptr %l169
  br label %bb63
bb63:
  %t330 = load i1, ptr %l169, !tbaa !21
  %t331 = xor i1 %t330, true
  br i1 %t331, label %bb64, label %bb65
bb64:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l12, !tbaa !23
  %t337 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t333, i32 %t334)
  store i1 %t337, ptr %l173
  br label %bb66
bb65:
  br label %bb88
bb66:
  %t338 = load i1, ptr %l173, !tbaa !21
  br i1 %t338, label %bb67, label %bb68
bb67:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i32, ptr %l13, !tbaa !23
  %t343 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t339, i32 %t340)
  store i1 %t343, ptr %l177
  br label %bb69
bb68:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb70
bb69:
  %t344 = load i1, ptr %l177, !tbaa !21
  store i1 %t344, ptr %l174, !tbaa !21
  br label %bb70
bb70:
  %t345 = load i1, ptr %l174, !tbaa !21
  br i1 %t345, label %bb71, label %bb72
bb71:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/check:Checker", ptr %t346, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t351 = getelementptr %"compiler/generic:Program", ptr %t349, i32 0, i32 2
  store ptr %t351, ptr %l181, !tbaa !29
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i32, ptr %l12, !tbaa !23
  %t356 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t352, i32 %t353)
  store i32 %t356, ptr %l184
  br label %bb73
bb72:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb76
bb73:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i32, ptr %l13, !tbaa !23
  %t361 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t357, i32 %t358)
  store i32 %t361, ptr %l187
  br label %bb74
bb74:
  %t362 = load ptr, ptr %l181, !tbaa !29
  %t363 = load i32, ptr %l184, !tbaa !23
  %t364 = load i32, ptr %l187, !tbaa !23
  %t365 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t362, i32 %t363, i32 %t364)
  store i1 %t365, ptr %l188
  br label %bb75
bb75:
  %t366 = load i1, ptr %l188, !tbaa !21
  store i1 %t366, ptr %l178, !tbaa !21
  br label %bb76
bb76:
  %t367 = load i1, ptr %l178, !tbaa !21
  %t368 = xor i1 %t367, true
  br i1 %t368, label %bb77, label %bb78
bb77:
  store i1 false, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/check:Checker", ptr %t371, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t376 = getelementptr %"compiler/generic:Program", ptr %t374, i32 0, i32 2
  %t377 = load i32, ptr %l13, !tbaa !23
  %t380 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t376, i32 %t377)
  store i64 %t380, ptr %l195
  br label %bb80
bb80:
  %t381 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t382 = load i64, ptr %l195, !tbaa !24
  %t384 = and i64 %t382, %t381
  %t386 = icmp ne i64 %t384, 0
  br i1 %t386, label %bb81, label %bb82
bb81:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !29
  %t393 = getelementptr %"compiler/generic:Program", ptr %t391, i32 0, i32 2
  %t394 = load i32, ptr %l12, !tbaa !23
  %t397 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t393, i32 %t394)
  store i64 %t397, ptr %l204
  br label %bb83
bb82:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb84
bb83:
  %t398 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t399 = load i64, ptr %l204, !tbaa !24
  %t401 = and i64 %t399, %t398
  %t403 = icmp eq i64 %t401, 0
  store i1 %t403, ptr %l199, !tbaa !21
  br label %bb84
bb84:
  %t405 = load i1, ptr %l199, !tbaa !21
  br i1 %t405, label %bb85, label %bb86
bb85:
  store i1 false, ptr %rv
  br label %ret
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/check:Checker", ptr %t407, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !29
  %t412 = getelementptr %"compiler/generic:Program", ptr %t410, i32 0, i32 2
  %t413 = load i32, ptr %l1, !tbaa !23
  %t416 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t412, i32 %t413)
  store i32 %t416, ptr %l213
  br label %bb89
bb89:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/check:Checker", ptr %t417, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t422 = getelementptr %"compiler/generic:Program", ptr %t420, i32 0, i32 2
  %t423 = load i32, ptr %l2, !tbaa !23
  %t426 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t422, i32 %t423)
  store i32 %t426, ptr %l218
  br label %bb90
bb90:
  %t427 = load i32, ptr %l213, !tbaa !23
  %t428 = load i32, ptr %l218, !tbaa !23
  %t429 = icmp eq i32 %t427, %t428
  br i1 %t429, label %bb91, label %bb92
bb91:
  store i1 true, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  br i1 %a3, label %bb94, label %bb95
bb94:
  %t434 = load ptr, ptr %l0, !tbaa !29
  store ptr %t434, ptr %l223, !tbaa !29
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/check:Checker", ptr %t435, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !29
  %t440 = getelementptr %"compiler/generic:Program", ptr %t438, i32 0, i32 2
  %t441 = load i32, ptr %l2, !tbaa !23
  %t444 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t440, i32 %t441)
  store i32 %t444, ptr %l228
  br label %bb96
bb95:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb99
bb96:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/check:Checker", ptr %t445, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !29
  %t450 = getelementptr %"compiler/generic:Program", ptr %t448, i32 0, i32 2
  %t451 = load i32, ptr %l1, !tbaa !23
  %t454 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t450, i32 %t451)
  store i32 %t454, ptr %l233
  br label %bb97
bb97:
  %t455 = load ptr, ptr %l223, !tbaa !29
  %t456 = load i32, ptr %l228, !tbaa !23
  %t457 = load i32, ptr %l233, !tbaa !23
  %t458 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsCover(ptr %v0, ptr %t455, i32 %t456, i32 %t457)
  store i1 %t458, ptr %l234
  br label %bb98
bb98:
  %t459 = load i1, ptr %l234, !tbaa !21
  store i1 %t459, ptr %l222, !tbaa !21
  br label %bb99
bb99:
  %t460 = load i1, ptr %l222, !tbaa !21
  store i1 %t460, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenElemMet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l18 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/msgs:Msg"
  %l51 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/msgs:Msg"
  %l56 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i32
  %l71 = alloca %"compiler/source:Span"
  %l85 = alloca %"compiler/source:Span"
  %l90 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l94 = alloca { i64, ptr }
  %l96 = alloca %"compiler/msgs:Msg"
  %l97 = alloca i64
  %l102 = alloca ptr
  %l105 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca i32
  %l111 = alloca { i64, ptr }
  %l116 = alloca i1
  %l118 = alloca { i64, ptr }
  %l121 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca %"compiler/source:Span"
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l137 = alloca %"compiler/msgs:Msg"
  %l138 = alloca i64
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenElem(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l18
  br label %bb1
bb1:
  %t9 = load i64, ptr %l18, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenPerTurn, !tbaa !24
  %t14 = icmp eq i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t18 = load ptr, ptr %l4, !tbaa !29
  store ptr %t18, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t19 = load ptr, ptr %l23, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l23, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 7}
  %t25 = icmp eq i64 %t23, 4
  store i1 %t25, ptr %l24, !tbaa !21
  br label %bb6
bb6:
  %t26 = load i1, ptr %l24, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t29, i32 0, i32 1
  %t31 = load ptr, ptr %t30
  store ptr %t31, ptr %l6, !tbaa !29
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t35, i32 0, i32 2
  %t37 = load i1, ptr %t36
  store i1 %t37, ptr %l7, !tbaa !21
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t39 = load i1, ptr %l7, !tbaa !21
  store i1 %t39, ptr %l5, !tbaa !21
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l6, !tbaa !29
  store ptr %t47, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_d7ab675994707360_a9a9e17072f91bbc)
  unreachable
bb18:
  %t49 = load ptr, ptr %l4, !tbaa !29
  store ptr %t49, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t50 = load ptr, ptr %l36, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb19, label %bb20
bb19:
  %t53 = load ptr, ptr %l36, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 7}
  %t56 = icmp eq i64 %t54, 3
  store i1 %t56, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t57 = load i1, ptr %l37, !tbaa !21
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t60, i32 0, i32 0
  %t62 = load %"compiler/source:Span", ptr %t61
  store %"compiler/source:Span" %t62, ptr %l8
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t66, i32 0, i32 2
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l9, !tbaa !23
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t72, i32 0, i32 3
  %t74 = load i1, ptr %t73
  store i1 %t74, ptr %l10, !tbaa !21
  br label %bb23
bb22:
  br label %bb68
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t76 = load i1, ptr %l5, !tbaa !21
  br i1 %t76, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l47, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t79)
  store %"compiler/source:Span" %t81, ptr %l49
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t82 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenElemWritable(ptr %s6)
  store %"compiler/msgs:Msg" %t82, ptr %l50
  br label %bb27
bb27:
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l49
  %t85 = load %"compiler/msgs:Msg", ptr %l50
  %t86 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t83, %"compiler/source:Span" %t84, %"compiler/msgs:Msg" %t85)
  store i64 %t86, ptr %l51
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t87 = load i1, ptr %l10, !tbaa !21
  br i1 %t87, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l53, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t90, ptr %l54
  %t91 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenElemNullable(ptr %s7)
  store %"compiler/msgs:Msg" %t91, ptr %l55
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t92 = load ptr, ptr %l53, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l54
  %t94 = load %"compiler/msgs:Msg", ptr %l55
  %t95 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t92, %"compiler/source:Span" %t93, %"compiler/msgs:Msg" %t94)
  store i64 %t95, ptr %l56
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb34:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l9, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t96, i32 %t97)
  store { i64, ptr } %t100, ptr %l59
  br label %bb35
bb35:
  %t101 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t101, ptr %l11, !tbaa !27
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l8
  %t106 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t102, %"compiler/source:Span" %t103)
  store { i64, ptr } %t106, ptr %l63
  br label %bb36
bb36:
  %t107 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t111 = extractvalue { i64, ptr } %t107, 1
  %t112 = extractvalue { i64, ptr } %t107, 0
  %t113 = add i64 %t109, %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t108, i64 %t109)
  %t115 = getelementptr i8, ptr %t114, i64 %t109
  call void @olang_textcopy(ptr %t115, ptr %t111, i64 %t112)
  %t116 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t114, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = extractvalue { i64, ptr } %t117, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t125 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t127 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s5, { i64, ptr } %t125, { i64, ptr } %t124)
  %t128 = extractvalue { i32, i64 } %t127, 1
  %t129 = extractvalue { i32, i64 } %t127, 0
  store i32 %t129, ptr %l68
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb38, label %ok.131, !prof !99
ok.131:
  store i64 %t128, ptr %l67
  br label %bb37
bb37:
  %t132 = load i64, ptr %l67, !tbaa !24
  store i64 %t132, ptr %l60, !tbaa !24
  br label %bb40
bb38:
  br label %bb39
bb39:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l60, !tbaa !24
  br label %bb40
bb40:
  %t133 = load i64, ptr %l60, !tbaa !24
  store i64 %t133, ptr %l12, !tbaa !24
  %t134 = load i64, ptr %l12, !tbaa !24
  %t136 = icmp sge i64 %t134, 0
  br i1 %t136, label %bb41, label %bb42
bb41:
  %t138 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t139 = load i32, ptr %t138, !tbaa !23
  %t140 = load i64, ptr %l12, !tbaa !24
  %t142 = add i64 %t140, 1
  %t144 = trunc i64 %t142 to i32
  %t147 = add i32 %t139, %t144
  %t148 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t149 = load i32, ptr %t148, !tbaa !23
  %t150 = load i64, ptr %l12, !tbaa !24
  %t152 = add i64 %t150, 1
  %t153 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t158 = add i64 %t152, %t155
  %t160 = trunc i64 %t158 to i32
  %t163 = add i32 %t149, %t160
  %t166 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 %t147, i32 %t163)
  store %"compiler/source:Span" %t166, ptr %l85
  br label %bb43
bb42:
  %t167 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t167, ptr %l71
  br label %bb44
bb43:
  %t169 = load %"compiler/source:Span", ptr %l85
  store %"compiler/source:Span" %t169, ptr %l71
  br label %bb44
bb44:
  %t170 = load %"compiler/source:Span", ptr %l71
  store %"compiler/source:Span" %t170, ptr %l13
  %t171 = load i64, ptr %l3, !tbaa !24
  %t172 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenBadScope, !tbaa !24
  %t175 = icmp eq i64 %t171, %t172
  br i1 %t175, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l90, !tbaa !29
  %t178 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t178, ptr %l91
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l9, !tbaa !23
  %t183 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t179, i32 %t180)
  store { i64, ptr } %t183, ptr %l94
  br label %bb47
bb46:
  %t184 = load i64, ptr %l3, !tbaa !24
  %t186 = icmp sge i64 %t184, 0
  br i1 %t186, label %bb50, label %bb51
bb47:
  %t188 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = extractvalue { i64, ptr } %t188, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  %t196 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenElemScopeUnknown(ptr %s9, ptr %s9, { i64, ptr } %t194)
  store %"compiler/msgs:Msg" %t196, ptr %l96
  br label %bb48
bb48:
  %t197 = load ptr, ptr %l90, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l91
  %t199 = load %"compiler/msgs:Msg", ptr %l96
  %t200 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t197, %"compiler/source:Span" %t198, %"compiler/msgs:Msg" %t199)
  store i64 %t200, ptr %l97
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb67
bb50:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/check:Checker", ptr %t201, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 2
  store ptr %t206, ptr %l102, !tbaa !29
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = getelementptr %"compiler/generic:Program", ptr %t210, i32 0, i32 2
  store ptr %t212, ptr %l105, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t217 = load i64, ptr %l1, !tbaa !24
  %t220 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t216, i64 %t217)
  store i32 %t220, ptr %l109
  br label %bb52
bb51:
  br label %bb66
bb52:
  %t221 = load ptr, ptr %l105, !tbaa !29
  %t222 = load i32, ptr %l109, !tbaa !23
  %t223 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t223, ptr %l110
  br label %bb53
bb53:
  %t224 = load ptr, ptr %l102, !tbaa !29
  %t225 = load i32, ptr %l110, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t224, i32 %t225)
  store { i64, ptr } %t226, ptr %l111
  br label %bb54
bb54:
  %t227 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t227, ptr %l14, !tbaa !27
  %t228 = load i64, ptr %l3, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t234 = icmp slt i64 %t228, %t231
  br i1 %t234, label %bb55, label %bb56
bb55:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t237, ptr %l118, !tbaa !27
  %t238 = load i64, ptr %l3, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr i32, ptr %t241, i64 %t238
  %t243 = load i32, ptr %t242, !tbaa !33
  %t246 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t236, i32 %t243)
  store i1 %t246, ptr %l121
  br label %bb57
bb56:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb58
bb57:
  %t247 = load i1, ptr %l121, !tbaa !21
  %t248 = xor i1 %t247, true
  store i1 %t248, ptr %l116, !tbaa !21
  br label %bb58
bb58:
  %t250 = load i1, ptr %l116, !tbaa !21
  br i1 %t250, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s12
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l123, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t252, ptr %l124
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load i32, ptr %l9, !tbaa !23
  %t257 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s12, ptr %t253, i32 %t254)
  store { i64, ptr } %t257, ptr %l127
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t258 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 0
  %t260 = extractvalue { i64, ptr } %t258, 1
  %t261 = mul i64 %t259, 1
  %t262 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t261)
  call void @llvm.memcpy.p0.p0.i64(ptr %t262, ptr %t260, i64 %t261, i1 false)
  %t263 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  store { i64, ptr } %t264, ptr %l128, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t265, ptr %l129, !tbaa !27
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t267, ptr %l131, !tbaa !27
  %t268 = load i64, ptr %l3, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr i32, ptr %t271, i64 %t268
  %t273 = load i32, ptr %t272, !tbaa !33
  %t276 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t266, i32 %t273)
  store { i64, ptr } %t276, ptr %l134
  br label %bb62
bb62:
  %t277 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t282 = add i64 %t279, %t281
  %t283 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 1
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t286 = add i64 %t282, %t285
  %t287 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t289 = add i64 %t286, %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t278, i64 %t279)
  %t291 = getelementptr i8, ptr %t290, i64 %t279
  call void @olang_textcopy(ptr %t291, ptr %t280, i64 %t281)
  %t292 = getelementptr i8, ptr %t291, i64 %t281
  call void @olang_textcopy(ptr %t292, ptr %t284, i64 %t285)
  %t293 = getelementptr i8, ptr %t292, i64 %t285
  call void @olang_textcopy(ptr %t293, ptr %t287, i64 %t288)
  %t294 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t290, 1
  %t297 = extractvalue { i64, ptr } %t295, 0
  %t298 = extractvalue { i64, ptr } %t295, 1
  %t299 = mul i64 %t297, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t299)
  call void @llvm.memcpy.p0.p0.i64(ptr %t300, ptr %t298, i64 %t299, i1 false)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  %t303 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t305 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenElemByValue(ptr %s12, ptr %s12, ptr %s12, { i64, ptr } %t303, { i64, ptr } %t302)
  store %"compiler/msgs:Msg" %t305, ptr %l137
  br label %bb63
bb63:
  %t306 = load ptr, ptr %l123, !tbaa !29
  %t307 = load %"compiler/source:Span", ptr %l124
  %t308 = load %"compiler/msgs:Msg", ptr %l137
  %t309 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t306, %"compiler/source:Span" %t307, %"compiler/msgs:Msg" %t308)
  store i64 %t309, ptr %l138
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s12)
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s5)
  br label %bb73
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_dacfb485414cf771_d273518bcacb276d)
  unreachable
bb73:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenResultMet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l24 = alloca { i64, ptr }
  %l28 = alloca i1
  %l33 = alloca i1
  %l38 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 7}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t36, ptr %l24, !tbaa !27
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 %t37
  %t42 = load ptr, ptr %t41, !tbaa !39
  store ptr %t42, ptr %l7, !tbaa !29
  %t44 = load ptr, ptr %l7, !tbaa !29
  %t46 = call i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v1, ptr %t44)
  store i1 %t46, ptr %l28
  br label %bb13
bb13:
  %t47 = load i1, ptr %l28, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t55 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t50, ptr %t51)
  store i1 %t55, ptr %l33
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb9
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t62, ptr %l38, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr ptr, ptr %t64, i64 0
  %t66 = load ptr, ptr %t65, !tbaa !39
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenElemMet(ptr %v0, ptr %v1, ptr %t60, i64 %a1, ptr %t66)
  br label %bb20
bb20:
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_48c434cc052a730a_3ea1b318a5aaa0d6)
  unreachable
bb26:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eidentity(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, [3 x i64] }
  %l14 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/source:Span"
  %l34 = alloca i1
  %l37 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca { i64, ptr }
  %l52 = alloca %"compiler/msgs:Msg"
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/msgs:Msg"
  %l58 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/msgs:Msg"
  %l68 = alloca i64
  %l72 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca i32
  %l86 = alloca ptr
  %l91 = alloca i1
  %l95 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca { i64, ptr }
  %l104 = alloca %"compiler/msgs:Msg"
  %l105 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca i32
  %l110 = alloca i64
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca ptr
  %l120 = alloca ptr
  %l122 = alloca ptr
  %l124 = alloca ptr
  %l128 = alloca ptr
  %l132 = alloca i1
  %l134 = alloca i1
  %l139 = alloca i32
  %l143 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l147 = alloca { i64, ptr }
  %l149 = alloca %"compiler/msgs:Msg"
  %l150 = alloca i64
  %l154 = alloca ptr
  %l159 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l165 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca %"compiler/msgs:Msg"
  %l169 = alloca i64
  %l170 = alloca ptr
  %l171 = alloca %"compiler/source:Span"
  %l172 = alloca i32
  %l174 = alloca i64
  %l175 = alloca ptr
  %l178 = alloca i1
  %l179 = alloca i1
  %l184 = alloca i1
  %l186 = alloca ptr
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca ptr
  %l190 = alloca %"compiler/source:Span"
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l198 = alloca %"compiler/msgs:Msg"
  %l199 = alloca i64
  %l201 = alloca ptr
  %l205 = alloca { i64, [3 x i64] }
  %l208 = alloca { i64, [3 x i64] }
  %l211 = alloca { i64, [3 x i64] }
  %l218 = alloca ptr
  %l219 = alloca i64
  %l220 = alloca { i64, [3 x i64] }
  %l221 = alloca %"compiler/msgs:Msg"
  %l222 = alloca ptr
  %l223 = alloca %"compiler/source:Span"
  %l224 = alloca i32
  %l226 = alloca i64
  %l227 = alloca ptr
  %l228 = alloca ptr
  %l233 = alloca ptr
  %l234 = alloca i32
  %l236 = alloca %"compiler/source:Span"
  %l237 = alloca ptr
  %l245 = alloca ptr
  %l247 = alloca ptr
  %l251 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i1, ptr %l16, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v2, ptr %t5)
  store i1 %t7, ptr %l19
  br label %bb4
bb3:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb5
bb4:
  %t8 = load i1, ptr %l19, !tbaa !21
  %t9 = xor i1 %t8, true
  store i1 %t9, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l17, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i1, ptr %l4, !tbaa !21
  %t22 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eidentity(ptr %v0, ptr %v2, ptr %v1, ptr %t12, %"compiler/source:Span" %t13, ptr %t14, ptr %t15, i1 %t16)
  store ptr %t22, ptr %l26
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t23 = load ptr, ptr %l26, !tbaa !29
  store ptr %t23, ptr %rv
  br label %ret
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l27, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t25)
  store %"compiler/source:Span" %t27, ptr %l29
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t28)
  store %"compiler/source:Span" %t30, ptr %l31
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l29
  %t33 = load %"compiler/source:Span", ptr %l31
  %t34 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t31, %"compiler/source:Span" %t32, %"compiler/source:Span" %t33, i64 2)
  store %"compiler/source:Span" %t34, ptr %l32
  br label %bb12
bb12:
  %t35 = load %"compiler/source:Span", ptr %l32
  store %"compiler/source:Span" %t35, ptr %l5
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v2, ptr %t36)
  store i1 %t38, ptr %l34
  br label %bb13
bb13:
  %t39 = load i1, ptr %l34, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load i1, ptr %l4, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb15:
  br label %bb32
bb16:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb18
bb17:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb18
bb18:
  %t44 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t44, ptr %l6, !tbaa !27
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v2, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l40
  br label %bb19
bb19:
  %t50 = load i1, ptr %l40, !tbaa !21
  br i1 %t50, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l41, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t52, ptr %l42
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t53, ptr %l43, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l44, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t57 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t55)
  store %"compiler/source:Span" %t57, ptr %l46
  br label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l54, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t59, ptr %l55
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t61 = load ptr, ptr @__olang_prog_scope
  %t63 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsOnlyNull(ptr %t61, ptr %s4, { i64, ptr } %t60)
  store %"compiler/msgs:Msg" %t63, ptr %l57
  br label %bb28
bb22:
  %t64 = load ptr, ptr %l44, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l46
  %t66 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t64, %"compiler/source:Span" %t65)
  store { i64, ptr } %t66, ptr %l47
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l48, !tbaa !29
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t68)
  store %"compiler/source:Span" %t70, ptr %l50
  br label %bb24
bb24:
  %t71 = load ptr, ptr %l48, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l50
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t71, %"compiler/source:Span" %t72)
  store { i64, ptr } %t73, ptr %l51
  br label %bb25
bb25:
  %t74 = load ptr, ptr @__olang_prog_scope
  %t75 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t78 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsCaseWritten(ptr %t74, ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t75, { i64, ptr } %t76, { i64, ptr } %t77)
  store %"compiler/msgs:Msg" %t78, ptr %l52
  br label %bb26
bb26:
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l42
  %t81 = load %"compiler/msgs:Msg", ptr %l52
  %t82 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t79, %"compiler/source:Span" %t80, %"compiler/msgs:Msg" %t81)
  store i64 %t82, ptr %l53
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb28:
  %t83 = load ptr, ptr %l54, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l55
  %t85 = load %"compiler/msgs:Msg", ptr %l57
  %t86 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t83, %"compiler/source:Span" %t84, %"compiler/msgs:Msg" %t85)
  store i64 %t86, ptr %l58
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, i32 %t89, i64 0)
  store ptr %t93, ptr %l62
  br label %bb31
bb31:
  %t94 = load ptr, ptr %l62, !tbaa !29
  store ptr %t94, ptr %rv
  br label %ret
bb32:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t95)
  store i1 %t97, ptr %l64
  br label %bb33
bb33:
  %t98 = load i1, ptr %l64, !tbaa !21
  br i1 %t98, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l65, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t100, ptr %l66
  %t101 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNullOfNull(ptr %s5)
  store %"compiler/msgs:Msg" %t101, ptr %l67
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t102 = load ptr, ptr %l65, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l66
  %t104 = load %"compiler/msgs:Msg", ptr %l67
  %t105 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t102, %"compiler/source:Span" %t103, %"compiler/msgs:Msg" %t104)
  store i64 %t105, ptr %l68
  br label %bb37
bb37:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load %"compiler/source:Span", ptr %l1
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t106, %"compiler/source:Span" %t107, i32 %t108, i64 0)
  store ptr %t112, ptr %l72
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  %t113 = load ptr, ptr %l72, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb39:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t114, ptr %t115, i32 %t117)
  store ptr %t121, ptr %l77
  br label %bb40
bb40:
  %t122 = load ptr, ptr %l77, !tbaa !29
  store ptr %t122, ptr %l7, !tbaa !29
  %t123 = load ptr, ptr %l7, !tbaa !29
  %t126 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t123)
  store i32 %t126, ptr %l80
  br label %bb41
bb41:
  %t127 = load i32, ptr %l80, !tbaa !23
  store i32 %t127, ptr %l8, !tbaa !23
  %t128 = load i32, ptr %l8, !tbaa !23
  %t129 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t132 = icmp eq i32 %t128, %t129
  br i1 %t132, label %bb42, label %bb43
bb42:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t134, %"compiler/source:Span" %t135)
  store ptr %t138, ptr %l86
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t139 = load ptr, ptr %l86, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb45:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %l8, !tbaa !23
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t145, i32 %t146)
  store i1 %t149, ptr %l91
  br label %bb46
bb46:
  %t150 = load i1, ptr %l91, !tbaa !21
  br i1 %t150, label %bb47, label %bb48
bb47:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t153 = load ptr, ptr %l7, !tbaa !29
  %t157 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNonNull(ptr %v0, ptr %v1, ptr %v0, ptr %t151, ptr %t152, ptr %t153)
  store i1 %t157, ptr %l95
  br label %bb49
bb48:
  br label %bb67
bb49:
  %t158 = load i1, ptr %l95, !tbaa !21
  br i1 %t158, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s8
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l96, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t160, ptr %l97
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l98, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t164 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t162)
  store %"compiler/source:Span" %t164, ptr %l100
  br label %bb52
bb51:
  br label %bb60
bb52:
  %t165 = load ptr, ptr %l98, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l100
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t165, %"compiler/source:Span" %t166)
  store { i64, ptr } %t167, ptr %l101
  br label %bb53
bb53:
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t170 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t168, i64 %t169)
  %t178 = getelementptr i8, ptr %t177, i64 %t169
  call void @olang_textcopy(ptr %t178, ptr %t171, i64 %t172)
  %t179 = getelementptr i8, ptr %t178, i64 %t172
  call void @olang_textcopy(ptr %t179, ptr %t174, i64 %t175)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t177, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t190 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %s8, ptr %s8, { i64, ptr } %t188)
  store %"compiler/msgs:Msg" %t190, ptr %l104
  br label %bb54
bb54:
  %t191 = load ptr, ptr %l96, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l97
  %t193 = load %"compiler/msgs:Msg", ptr %l104
  %t194 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t191, %"compiler/source:Span" %t192, %"compiler/msgs:Msg" %t193)
  store i64 %t194, ptr %l105
  br label %bb55
bb55:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l106, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t196, ptr %l107
  %t197 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t197, ptr %l108, !tbaa !23
  %t198 = load i1, ptr %l4, !tbaa !21
  br i1 %t198, label %bb56, label %bb57
bb56:
  store i64 1, ptr %l110, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb58
bb58:
  %t200 = load ptr, ptr %l106, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l107
  %t202 = load i32, ptr %l108, !tbaa !23
  %t203 = load i64, ptr %l110, !tbaa !24
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t200, %"compiler/source:Span" %t201, i32 %t202, i64 %t203)
  store ptr %t204, ptr %l111
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s8)
  %t205 = load ptr, ptr %l111, !tbaa !29
  store ptr %t205, ptr %rv
  br label %ret
bb60:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l112, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t207, ptr %l113
  %t208 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t208, ptr %l114, !tbaa !23
  store i32 13, ptr %l115
  %t209 = load ptr, ptr %l7, !tbaa !29
  store ptr %t209, ptr %l116, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  %t212 = load i32, ptr %l8, !tbaa !23
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t210, %"compiler/source:Span" %t211, i32 %t212, i64 0)
  store ptr %t216, ptr %l120
  br label %bb61
bb61:
  %t217 = load ptr, ptr %l120, !tbaa !29
  %t218 = load ptr, ptr %l112, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l113
  %t220 = load i32, ptr %l114, !tbaa !23
  %t221 = load i32, ptr %l115, !range !{i32 0, i32 43}
  %t222 = load ptr, ptr %l116, !tbaa !29
  %t224 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t218, %"compiler/source:Span" %t219, i32 %t220, i32 %t221, ptr %t222, ptr %t217)
  store ptr %t224, ptr %l122
  br label %bb62
bb62:
  %t225 = load ptr, ptr %l122, !tbaa !29
  store ptr %t225, ptr %l9, !tbaa !29
  %t226 = load i1, ptr %l4, !tbaa !21
  br i1 %t226, label %bb63, label %bb64
bb63:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l1
  %t230 = load ptr, ptr %l9, !tbaa !29
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t228, %"compiler/source:Span" %t229, ptr %t230)
  store ptr %t234, ptr %l128
  br label %bb65
bb64:
  %t235 = load ptr, ptr %l9, !tbaa !29
  store ptr %t235, ptr %l124, !tbaa !29
  br label %bb66
bb65:
  %t237 = load ptr, ptr %l128, !tbaa !29
  store ptr %t237, ptr %l124, !tbaa !29
  br label %bb66
bb66:
  %t238 = load ptr, ptr %l124, !tbaa !29
  store ptr %t238, ptr %rv
  br label %ret
bb67:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l8, !tbaa !23
  %t243 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t239, i32 %t240)
  store i1 %t243, ptr %l132
  br label %bb68
bb68:
  %t244 = load i1, ptr %l132, !tbaa !21
  %t245 = xor i1 %t244, true
  br i1 %t245, label %bb69, label %bb70
bb69:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t247, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = getelementptr %"compiler/generic:Program", ptr %t250, i32 0, i32 2
  %t253 = load i32, ptr %l8, !tbaa !23
  %t256 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t252, i32 %t253)
  store i32 %t256, ptr %l139
  br label %bb71
bb70:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb72
bb71:
  %t257 = load i32, ptr %l139, !range !{i32 0, i32 33}
  %t259 = trunc i64 21 to i32
  %t260 = icmp eq i32 %t257, %t259
  %t262 = xor i1 %t260, true
  store i1 %t262, ptr %l134, !tbaa !21
  br label %bb72
bb72:
  %t264 = load i1, ptr %l134, !tbaa !21
  br i1 %t264, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s10
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l143, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t266, ptr %l144
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l8, !tbaa !23
  %t271 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t267, i32 %t268)
  store { i64, ptr } %t271, ptr %l147
  br label %bb75
bb74:
  br label %bb79
bb75:
  %t272 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  %t274 = extractvalue { i64, ptr } %t272, 1
  %t275 = mul i64 %t273, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t276, ptr %t274, i64 %t275, i1 false)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  %t280 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNullOfValue(ptr %s10, ptr %s10, { i64, ptr } %t278)
  store %"compiler/msgs:Msg" %t280, ptr %l149
  br label %bb76
bb76:
  %t281 = load ptr, ptr %l143, !tbaa !29
  %t282 = load %"compiler/source:Span", ptr %l144
  %t283 = load %"compiler/msgs:Msg", ptr %l149
  %t284 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t281, %"compiler/source:Span" %t282, %"compiler/msgs:Msg" %t283)
  store i64 %t284, ptr %l150
  br label %bb77
bb77:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load %"compiler/source:Span", ptr %l1
  %t287 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t291 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t285, %"compiler/source:Span" %t286, i32 %t287, i64 0)
  store ptr %t291, ptr %l154
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s10)
  %t292 = load ptr, ptr %l154, !tbaa !29
  store ptr %t292, ptr %rv
  br label %ret
bb79:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/generic:Program", ptr %t296, i32 0, i32 2
  %t299 = load i32, ptr %l8, !tbaa !23
  %t302 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t298, i32 %t299)
  store i1 %t302, ptr %l159
  br label %bb80
bb80:
  %t303 = load i1, ptr %l159, !tbaa !21
  br i1 %t303, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s11
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l160, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t305, ptr %l161
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l162, !tbaa !29
  %t307 = load ptr, ptr %l2, !tbaa !29
  %t309 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t307)
  store %"compiler/source:Span" %t309, ptr %l164
  br label %bb83
bb82:
  br label %bb94
bb83:
  %t310 = load ptr, ptr %l162, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l164
  %t312 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t310, %"compiler/source:Span" %t311)
  store { i64, ptr } %t312, ptr %l165
  br label %bb84
bb84:
  %t313 = load i1, ptr %l4, !tbaa !21
  br i1 %t313, label %bb85, label %bb86
bb85:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l167, !tbaa !27
  br label %bb87
bb86:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l167, !tbaa !27
  br label %bb87
bb87:
  %t315 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t317 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayIsNull(ptr %v0, ptr %s11, ptr %s11, { i64, ptr } %t315, { i64, ptr } %t316)
  store %"compiler/msgs:Msg" %t317, ptr %l168
  br label %bb88
bb88:
  %t318 = load ptr, ptr %l160, !tbaa !29
  %t319 = load %"compiler/source:Span", ptr %l161
  %t320 = load %"compiler/msgs:Msg", ptr %l168
  %t321 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t318, %"compiler/source:Span" %t319, %"compiler/msgs:Msg" %t320)
  store i64 %t321, ptr %l169
  br label %bb89
bb89:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l170, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t323, ptr %l171
  %t324 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t324, ptr %l172, !tbaa !23
  %t325 = load i1, ptr %l4, !tbaa !21
  br i1 %t325, label %bb90, label %bb91
bb90:
  store i64 1, ptr %l174, !tbaa !24
  br label %bb92
bb91:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb92
bb92:
  %t327 = load ptr, ptr %l170, !tbaa !29
  %t328 = load %"compiler/source:Span", ptr %l171
  %t329 = load i32, ptr %l172, !tbaa !23
  %t330 = load i64, ptr %l174, !tbaa !24
  %t331 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t327, %"compiler/source:Span" %t328, i32 %t329, i64 %t330)
  store ptr %t331, ptr %l175
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s11)
  %t332 = load ptr, ptr %l175, !tbaa !29
  store ptr %t332, ptr %rv
  br label %ret
bb94:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l8, !tbaa !23
  %t337 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t333, i32 %t334)
  store i1 %t337, ptr %l178
  br label %bb95
bb95:
  %t338 = load i1, ptr %l178, !tbaa !21
  br i1 %t338, label %bb96, label %bb97
bb96:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/check:Checker", ptr %t339, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !29
  %t344 = getelementptr %"compiler/generic:Program", ptr %t342, i32 0, i32 2
  %t345 = load i32, ptr %l8, !tbaa !23
  %t348 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t344, i32 %t345)
  store i1 %t348, ptr %l184
  br label %bb98
bb97:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb99
bb98:
  %t349 = load i1, ptr %l184, !tbaa !21
  %t350 = xor i1 %t349, true
  store i1 %t350, ptr %l179, !tbaa !21
  br label %bb99
bb99:
  %t352 = load i1, ptr %l179, !tbaa !21
  br i1 %t352, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s12
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l186, !tbaa !29
  %t354 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t354, ptr %l187
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l188, !tbaa !29
  %t356 = load ptr, ptr %l2, !tbaa !29
  %t358 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t356)
  store %"compiler/source:Span" %t358, ptr %l190
  br label %bb102
bb101:
  br label %bb125
bb102:
  %t359 = load ptr, ptr %l188, !tbaa !29
  %t360 = load %"compiler/source:Span", ptr %l190
  %t361 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t359, %"compiler/source:Span" %t360)
  store { i64, ptr } %t361, ptr %l191
  br label %bb103
bb103:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load i32, ptr %l8, !tbaa !23
  %t366 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t362, i32 %t363)
  store { i64, ptr } %t366, ptr %l194
  br label %bb104
bb104:
  %t367 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t367, 0
  %t369 = extractvalue { i64, ptr } %t367, 1
  %t370 = mul i64 %t368, 1
  %t371 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t370)
  call void @llvm.memcpy.p0.p0.i64(ptr %t371, ptr %t369, i64 %t370, i1 false)
  %t372 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t373 = insertvalue { i64, ptr } %t372, ptr %t371, 1
  store { i64, ptr } %t373, ptr %l195, !tbaa !27
  %t374 = load i1, ptr %l4, !tbaa !21
  br i1 %t374, label %bb105, label %bb106
bb105:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l197, !tbaa !27
  br label %bb107
bb106:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l197, !tbaa !27
  br label %bb107
bb107:
  %t376 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t377 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t378 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t379 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeverNull(ptr %v0, ptr %s12, ptr %s12, ptr %s12, { i64, ptr } %t376, { i64, ptr } %t377, { i64, ptr } %t378)
  store %"compiler/msgs:Msg" %t379, ptr %l198
  br label %bb108
bb108:
  %t380 = load ptr, ptr %l186, !tbaa !29
  %t381 = load %"compiler/source:Span", ptr %l187
  %t382 = load %"compiler/msgs:Msg", ptr %l198
  %t383 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t380, %"compiler/source:Span" %t381, %"compiler/msgs:Msg" %t382)
  store i64 %t383, ptr %l199
  br label %bb109
bb109:
  %t384 = load i64, ptr %l199, !tbaa !24
  store i64 %t384, ptr %l10, !tbaa !24
  %t385 = load ptr, ptr %l7, !tbaa !29
  %t387 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t385)
  store ptr %t387, ptr %l201
  br label %bb110
bb110:
  %t388 = load ptr, ptr %l201, !tbaa !29
  store ptr %t388, ptr %l11, !tbaa !29
  %t389 = load ptr, ptr %l11, !tbaa !29
  %t391 = icmp eq ptr %t389, null
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb111, label %bb112
bb111:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l11, !tbaa !29
  %t399 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v0, ptr %t395, ptr %t396)
  store { i64, [3 x i64] } %t399, ptr %l208
  br label %bb113
bb112:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load ptr, ptr %l7, !tbaa !29
  %t404 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledAt(ptr %v0, ptr %v0, ptr %t400, ptr %t401)
  store { i64, [3 x i64] } %t404, ptr %l211
  br label %bb114
bb113:
  %t405 = load { i64, [3 x i64] }, ptr %l208
  store { i64, [3 x i64] } %t405, ptr %l205
  br label %bb115
bb114:
  %t406 = load { i64, [3 x i64] }, ptr %l211
  store { i64, [3 x i64] } %t406, ptr %l205
  br label %bb115
bb115:
  %t407 = load { i64, [3 x i64] }, ptr %l205
  store { i64, [3 x i64] } %t407, ptr %l12
  %t408 = load { i64, [3 x i64] }, ptr %l12
  %t410 = extractvalue { i64, [3 x i64] } %t408, 0
  %t411 = icmp eq i64 %t410, 0
  %t413 = xor i1 %t411, true
  br i1 %t413, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s13
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/check:Checker", ptr %t415, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t420 = getelementptr %"compiler/generic:Program", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/load:Loader", ptr %t421, i32 0, i32 4
  %t424 = load ptr, ptr %t423, !tbaa !29
  store ptr %t424, ptr %l218, !tbaa !29
  %t425 = load i64, ptr %l10, !tbaa !24
  store i64 %t425, ptr %l219, !tbaa !24
  %t426 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t426, ptr %l220
  %t427 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %s13)
  store %"compiler/msgs:Msg" %t427, ptr %l221
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t428 = load ptr, ptr %l218, !tbaa !29
  %t429 = load i64, ptr %l219, !tbaa !24
  %t430 = load { i64, [3 x i64] }, ptr %l220
  %t431 = load %"compiler/msgs:Msg", ptr %l221
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s13, ptr %t428, i64 %t429, { i64, [3 x i64] } %t430, %"compiler/msgs:Msg" %t431)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s13)
  br label %bb120
bb120:
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l222, !tbaa !29
  %t433 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t433, ptr %l223
  %t434 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t434, ptr %l224, !tbaa !23
  %t435 = load i1, ptr %l4, !tbaa !21
  br i1 %t435, label %bb121, label %bb122
bb121:
  store i64 1, ptr %l226, !tbaa !24
  br label %bb123
bb122:
  store i64 0, ptr %l226, !tbaa !24
  br label %bb123
bb123:
  %t437 = load ptr, ptr %l222, !tbaa !29
  %t438 = load %"compiler/source:Span", ptr %l223
  %t439 = load i32, ptr %l224, !tbaa !23
  %t440 = load i64, ptr %l226, !tbaa !24
  %t441 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t437, %"compiler/source:Span" %t438, i32 %t439, i64 %t440)
  store ptr %t441, ptr %l227
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s12)
  %t442 = load ptr, ptr %l227, !tbaa !29
  store ptr %t442, ptr %rv
  br label %ret
bb125:
  %t443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t443, ptr %l228, !tbaa !29
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l3, !tbaa !29
  %t447 = load i32, ptr %l8, !tbaa !23
  %t451 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t444, ptr %t445, i32 %t447)
  store ptr %t451, ptr %l233
  br label %bb126
bb126:
  %t452 = load i32, ptr %l8, !tbaa !23
  store i32 %t452, ptr %l234, !tbaa !23
  %t453 = load ptr, ptr %l3, !tbaa !29
  %t455 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t453)
  store %"compiler/source:Span" %t455, ptr %l236
  br label %bb127
bb127:
  %t456 = load ptr, ptr %l228, !tbaa !29
  %t457 = load ptr, ptr %l233, !tbaa !29
  %t458 = load i32, ptr %l234, !tbaa !23
  %t459 = load %"compiler/source:Span", ptr %l236
  %t460 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t456, ptr %t457, i32 %t458, %"compiler/source:Span" %t459)
  store ptr %t460, ptr %l237
  br label %bb128
bb128:
  %t461 = load ptr, ptr %l237, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load %"compiler/source:Span", ptr %l1
  %t464 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t465 = load ptr, ptr %l7, !tbaa !29
  %t474 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t462, %"compiler/source:Span" %t463, i32 %t464, i32 19, ptr %t465, ptr %t461)
  store ptr %t474, ptr %l245
  br label %bb129
bb129:
  %t475 = load ptr, ptr %l245, !tbaa !29
  store ptr %t475, ptr %l14, !tbaa !29
  %t476 = load i1, ptr %l4, !tbaa !21
  br i1 %t476, label %bb130, label %bb131
bb130:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l1
  %t480 = load ptr, ptr %l14, !tbaa !29
  %t484 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t478, %"compiler/source:Span" %t479, ptr %t480)
  store ptr %t484, ptr %l251
  br label %bb132
bb131:
  %t485 = load ptr, ptr %l14, !tbaa !29
  store ptr %t485, ptr %l247, !tbaa !29
  br label %bb133
bb132:
  %t487 = load ptr, ptr %l251, !tbaa !29
  store ptr %t487, ptr %l247, !tbaa !29
  br label %bb133
bb133:
  %t488 = load ptr, ptr %l247, !tbaa !29
  store ptr %t488, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l18 = alloca %"compiler/names:Ref"
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca %"compiler/names:Ref"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t23)
  store ptr %t25, ptr %l14
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 2
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load ptr, ptr %l12, !tbaa !29
  %t35 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t32, i64 %t29, i32 %t31)
  store %"compiler/names:Ref" %t35, ptr %l18
  br label %bb7
bb7:
  %t36 = getelementptr %"compiler/names:Ref", ptr %l18, i32 0, i32 0
  %t37 = load i32, ptr %t36, !range !{i32 0, i32 9}
  %t39 = trunc i64 5 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %rv
  br label %ret
bb8:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 29}
  %t49 = icmp eq i64 %t47, 15
  store i1 %t49, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l22, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load %"compiler/source:Span", ptr %t54
  store %"compiler/source:Span" %t55, ptr %l3
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t64)
  store ptr %t66, ptr %l31
  br label %bb14
bb14:
  %t67 = load ptr, ptr %l31, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t72 = load i32, ptr %t71, !tbaa !23
  %t73 = load ptr, ptr %l29, !tbaa !29
  %t76 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t73, i64 %t70, i32 %t72)
  store %"compiler/names:Ref" %t76, ptr %l35
  br label %bb15
bb15:
  %t77 = getelementptr %"compiler/names:Ref", ptr %l35, i32 0, i32 0
  %t78 = load i32, ptr %t77, !range !{i32 0, i32 9}
  %t80 = trunc i64 5 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %rv
  br label %ret
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_6c69e074d5382e65_c76aefb5b106fb41)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l8
  br label %bb2
bb2:
  %t15 = load i1, ptr %l8, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSay(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l7 = alloca i64
  %l11 = alloca %"compiler/check:laneVals"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l27 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load i64, ptr %l2, !tbaa !24
  %t13 = call %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %v0, ptr %t7, %"compiler/source:Span" %t8, i64 %t9)
  store %"compiler/check:laneVals" %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t14, ptr %lp4
  %t15 = load %"compiler/check:laneVals", ptr %l11
  %t16 = load ptr, ptr %lp4
  store %"compiler/check:laneVals" %t15, ptr %t16
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t18, ptr %l13
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l14, !tbaa !24
  %t20 = load ptr, ptr %lp4
  store ptr %t20, ptr %l15, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l16, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t22, ptr %l17
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t23)
  store i32 %t25, ptr %l19
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l17
  %t28 = load i32, ptr %l19, !tbaa !23
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t26, %"compiler/source:Span" %t27, i32 %t28, i64 0)
  store ptr %t29, ptr %l20
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l12, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l13
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = load ptr, ptr %l15, !tbaa !29
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i64 %t32, ptr %t33, ptr %t34)
  store ptr %t35, ptr %l21
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 37
  %t39 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eTrunca_Hc8531d0d5535cc9766a27157f9c0b07c(ptr %v0, ptr %t38, i64 %t39)
  br label %bb6
bb6:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t42, %"compiler/source:Span" %t43)
  store ptr %t46, ptr %l27
  br label %bb7
bb7:
  %t47 = load ptr, ptr %l27, !tbaa !29
  store ptr %t47, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneType(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/check:laneNode"
  %l6 = alloca %"compiler/check:laneNode"
  %l13 = alloca ptr
  %l14 = alloca i32
  %l17 = alloca i32
  %l20 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 39
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/check:laneNode" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"compiler/check:laneNode", ptr %l6
  store %"compiler/check:laneNode" %t8, ptr %l2
  %t9 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 10
  %t10 = load i32, ptr %t9, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp ne i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 10
  %t17 = load i32, ptr %t16, !tbaa !23
  store i32 %t17, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  store ptr %t24, ptr %l13, !tbaa !29
  %t25 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 8
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l14, !tbaa !23
  %t27 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 9
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = icmp sge i64 %t28, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  store ptr %t37, ptr %l20, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l22
  br label %bb7
bb6:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb9
bb7:
  %t41 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 9
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = load i32, ptr %l22, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t43, i32 %t44, i64 %t42)
  store i32 %t46, ptr %l24
  br label %bb8
bb8:
  %t47 = load i32, ptr %l24, !tbaa !23
  store i32 %t47, ptr %l17, !tbaa !23
  br label %bb9
bb9:
  %t48 = load ptr, ptr %l13, !tbaa !29
  %t49 = load i32, ptr %l14, !tbaa !23
  %t50 = load i32, ptr %l17, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t48, i32 %t49, i32 %t50)
  store i32 %t51, ptr %l25
  br label %bb10
bb10:
  %t52 = load i32, ptr %l25, !tbaa !23
  store i32 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca [1 x i64]
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca %"compiler/check:laneNode"
  %l17 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca i64
  %l28 = alloca i32
  %l32 = alloca %"compiler/check:laneNode"
  %l33 = alloca i64
  %l38 = alloca i32
  %l39 = alloca %"compiler/check:laneNode"
  %l40 = alloca i64
  %l41 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %t1, ptr %a3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l10, !tbaa !29
  %t8 = load i32, ptr %l2, !range !{i32 0, i32 96}
  store i32 %t8, ptr %l11
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 39
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t11, i64 %t12)
  store %"compiler/check:laneNode" %t15, ptr %l15
  br label %bb2
bb2:
  %t16 = getelementptr %"compiler/check:laneNode", ptr %l15, i32 0, i32 8
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l10, !tbaa !29
  %t19 = load i32, ptr %l11, !range !{i32 0, i32 96}
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %t18, i32 %t19, i32 %t17)
  store i32 %t21, ptr %l17
  br label %bb3
bb3:
  %t22 = load i32, ptr %l17, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = insertvalue [1 x i64] undef, i64 %t23, 0
  store [1 x i64] %t25, ptr %l6
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l20, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneUn, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load i32, ptr %l2, !range !{i32 0, i32 96}
  store i32 %t31, ptr %l24
  %t32 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t32, ptr %l25
  %t33 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t33, ptr %l26
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l27, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  store i32 %t35, ptr %l28, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 39
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t38, i64 %t39)
  store %"compiler/check:laneNode" %t42, ptr %l32
  br label %bb4
bb4:
  %t43 = getelementptr %"compiler/check:laneNode", ptr %l32, i32 0, i32 9
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l33, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = insertvalue { i64, ptr } undef, i64 1, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %l6, 1
  %t49 = load i32, ptr %l5, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %s0, ptr %t45, { i64, ptr } %t48, i32 %t49)
  store i32 %t53, ptr %l38
  br label %bb5
bb5:
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = load i32, ptr %l24, !range !{i32 0, i32 96}
  %t56 = load %"compiler/source:Span", ptr %l25
  %t57 = load %"compiler/source:Span", ptr %l26
  %t58 = load i64, ptr %l27, !tbaa !24
  %t59 = load i32, ptr %l28, !tbaa !23
  %t60 = load i64, ptr %l33, !tbaa !24
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t54, i32 %t55, %"compiler/source:Span" %t56, %"compiler/source:Span" %t57, i64 %t58, i64 -1, i64 -1, ptr null, i32 %t59, i64 %t60, i32 %t61)
  store %"compiler/check:laneNode" %t62, ptr %l39
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l22, !tbaa !29
  %t64 = load %"compiler/check:laneNode", ptr %l39
  %t65 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t63, %"compiler/check:laneNode" %t64)
  store i64 %t65, ptr %l40
  br label %bb7
bb7:
  %t66 = load ptr, ptr %l20, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l21
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %t66, %"compiler/source:Span" %t67, i64 %t68)
  store ptr %t69, ptr %l41
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t70 = load ptr, ptr %l41, !tbaa !29
  store ptr %t70, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i1
  %l21 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca %"compiler/names:Ref"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 7}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t23, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 2
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp ne i64 %t35, 1
  br i1 %t37, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp sgt i64 %t41, 0
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l28, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t54)
  store ptr %t56, ptr %l30
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 2
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load ptr, ptr %l28, !tbaa !29
  %t66 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t63, i64 %t60, i32 %t62)
  store %"compiler/names:Ref" %t66, ptr %l34
  br label %bb16
bb16:
  %t67 = getelementptr %"compiler/names:Ref", ptr %l34, i32 0, i32 0
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 9}
  %t70 = trunc i64 8 to i32
  %t71 = icmp eq i32 %t68, %t70
  store i1 %t71, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_968ede9ca4457b20_d4cd8e7344b6f50c)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 29}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowLocal(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l21
  br label %bb13
bb13:
  %t42 = load i64, ptr %l21, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -1, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_77892b47b9a99b47_46cd468a4d441f7b)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoValueCase(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l13 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t4, i32 %a1, i64 %a2)
  store i32 %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load i32, ptr %l13, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  store ptr %t24, ptr %l20, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  %t31 = load i32, ptr %l3, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l25
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t36 = load i32, ptr %l25, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t35, i32 %t36)
  store { i64, ptr } %t37, ptr %l26
  br label %bb6
bb6:
  %t38 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t38, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  br label %bb26
bb9:
  br label %bb10
bb10:
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 %t52
  %t57 = load i32, ptr %t56, !tbaa !33
  store i32 %t57, ptr %l7, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l7, !tbaa !23
  %t68 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l40
  br label %bb11
bb11:
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb12, label %bb13
bb12:
  br label %bb25
bb13:
  br label %bb14
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l7, !tbaa !23
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l43
  br label %bb15
bb15:
  %t75 = load i32, ptr %l43, !tbaa !23
  store i32 %t75, ptr %l8, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l8, !tbaa !23
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l46
  br label %bb16
bb16:
  %t81 = load i1, ptr %l46, !tbaa !21
  br i1 %t81, label %bb17, label %bb18
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  store ptr %t87, ptr %l50, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l8, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l55
  br label %bb19
bb18:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb21
bb19:
  %t98 = load ptr, ptr %l50, !tbaa !29
  %t99 = load i32, ptr %l55, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t98, i32 %t99)
  store { i64, ptr } %t100, ptr %l56
  br label %bb20
bb20:
  %t101 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t104 = icmp eq i64 %t102, 0
  store i1 %t104, ptr %l47, !tbaa !21
  br label %bb21
bb21:
  %t106 = load i1, ptr %l47, !tbaa !21
  br i1 %t106, label %bb22, label %bb23
bb22:
  store i1 true, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t108 = load i64, ptr %l5, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l5, !tbaa !24
  br label %bb7
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i32
  %l17 = alloca ptr
  %l22 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i32
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb16
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l16
  br label %bb7
bb7:
  %t22 = load i32, ptr %l16, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l5, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l22
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l5, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l27
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l17, !tbaa !29
  %t45 = load i32, ptr %l22, !tbaa !23
  %t46 = load i64, ptr %l27, !tbaa !65
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t44, i32 %t45, i64 %t46)
  store i32 %t47, ptr %l28
  br label %bb10
bb10:
  %t48 = load i32, ptr %l28, !tbaa !23
  store i32 %t48, ptr %l6, !tbaa !23
  %t49 = load i32, ptr %l6, !tbaa !23
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t53 = icmp ne i32 %t49, %t50
  br i1 %t53, label %bb11, label %bb12
bb11:
  %t55 = load ptr, ptr %lp2
  %t56 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t55, i32 %t56)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l4, !tbaa !24
  br label %bb2
bb16:
  %t63 = load ptr, ptr %lp2
  %t64 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t63
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enothingFails(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/msgs:Msg"
  %l8 = alloca i64
  %s0 = alloca %olang.scope
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l2, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = add i32 %t5, 3
  %t10 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t3, i32 %t7)
  store %"compiler/source:Span" %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNothingFails(ptr %s0, ptr %s0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l6
  %t14 = load %"compiler/msgs:Msg", ptr %l7
  %t15 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t12, %"compiler/source:Span" %t13, %"compiler/msgs:Msg" %t14)
  store i64 %t15, ptr %l8
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t4 = call i1 @compiler_2fcheck_2elaneTok(i32 %a1)
  store i1 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i1, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 40
  store i1 %t5, ptr %t7, !tbaa !21
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t8, ptr %a2, i32 %a3)
  store ptr %t15, ptr %l11
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l11, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderGlobals(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l54 = alloca ptr
  %l74 = alloca i64
  %l78 = alloca i64
  %l81 = alloca i64
  %l109 = alloca i64
  %l111 = alloca i64
  %l116 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l1
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l19
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 5
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l24
  br label %bb3
bb3:
  %t16 = load i64, ptr %l24, !tbaa !24
  store i64 %t16, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb6:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l31, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l31, !tbaa !24
  store i64 %t43, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l28, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb11, label %bb12
bb11:
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l8, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/load:Loader", ptr %t69, i32 0, i32 5
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l54
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l54, !tbaa !29
  %t78 = getelementptr %"compiler/load:Module", ptr %t76, i32 0, i32 3
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb15, label %bb16
bb15:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %s0, ptr %s0, ptr %t81, i64 %t82, ptr %l1, ptr %l2)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb10
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/load:Loader", ptr %t98, i32 0, i32 7
  %t101 = load i64, ptr %t100, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %s0, ptr %s0, ptr %t91, i64 %t101, ptr %l1, ptr %l2)
  br label %bb21
bb21:
  store i64 0, ptr %l9, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/load:Loader", ptr %t112, i32 0, i32 5
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t114)
  store i64 %t116, ptr %l74
  br label %bb22
bb22:
  %t117 = load i64, ptr %l74, !tbaa !24
  store i64 %t117, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb23, label %bb24
bb23:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb28
bb25:
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l9, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l81, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb27
bb27:
  %t144 = load i64, ptr %l81, !tbaa !24
  store i64 %t144, ptr %l78, !tbaa !24
  br label %bb28
bb28:
  %t145 = load i64, ptr %l78, !tbaa !24
  store i64 %t145, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  %t146 = load i64, ptr %l13, !tbaa !24
  %t147 = load i64, ptr %l12, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb30, label %bb31
bb30:
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t154 = load i64, ptr %l9, !tbaa !24
  %t155 = load i64, ptr %l13, !tbaa !24
  %t156 = load i64, ptr %l11, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  %t164 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %s0, ptr %s0, ptr %t164, i64 %t162, ptr %l1, ptr %l2)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l13, !tbaa !24
  br label %bb29
bb35:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 46
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t179)
  br label %bb36
bb36:
  store ptr %l2, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  %t182 = load i64, ptr %l16, !tbaa !24
  store i64 %t182, ptr %l109, !tbaa !24
  %t183 = load ptr, ptr %l15, !tbaa !29
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t183)
  store i64 %t185, ptr %l111
  br label %bb38
bb38:
  %t186 = load i64, ptr %l109, !tbaa !24
  %t187 = load i64, ptr %l111, !tbaa !24
  %t188 = icmp slt i64 %t186, %t187
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  br label %bb41
bb41:
  %t192 = load ptr, ptr %l15, !tbaa !29
  %t193 = load i64, ptr %l16, !tbaa !24
  %t196 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t192, i64 %t193)
  store i64 %t196, ptr %l116
  br label %bb42
bb42:
  %t197 = load i64, ptr %l116, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/generic:Program", ptr %t203, i32 0, i32 46
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderModule(ptr %v0, ptr %v0, ptr %t198, i64 %t197, ptr %t205)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t209 = load i64, ptr %l16, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l16, !tbaa !24
  br label %bb37
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoutOfRange(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d25, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d26, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainScalar(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb4:
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t13 = load i32, ptr %l8, !tbaa !23
  %t15 = icmp eq i32 %t13, %t12
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l14
  br label %bb9
bb9:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l23
  br label %bb12
bb11:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb14
bb12:
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t42 = load i32, ptr %l23, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t43, ptr %l24
  br label %bb13
bb13:
  %t44 = load i1, ptr %l24, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l15, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l15, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i32
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l66 = alloca i64
  %l68 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %t4, { i64, ptr } %a1, { i64, ptr } %a2)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load i32, ptr %l16, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load i32, ptr %l4, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i32, ptr %l4, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l22, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l4, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l27
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i32, ptr %l27, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t34, i32 %t35)
  store { i64, ptr } %t36, ptr %l28
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l37, !tbaa !24
  store i64 %t68, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t69 = load i64, ptr %l34, !tbaa !24
  store i64 %t69, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t70 = load i64, ptr %l10, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  store i64 %t86, ptr %l11, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t89, ptr %l56, !tbaa !27
  %t90 = load i64, ptr %l11, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t98 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t88, i32 %t95)
  store { i64, ptr } %t98, ptr %l59
  br label %bb17
bb17:
  %t100 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v3, { i64, ptr } %t100, { i64, ptr } %a3)
  store i1 %t102, ptr %l61
  br label %bb18
bb18:
  %t103 = load i1, ptr %l61, !tbaa !21
  br i1 %t103, label %bb19, label %bb20
bb19:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l4, !tbaa !23
  %t111 = load i64, ptr %l11, !tbaa !24
  store i64 %t111, ptr %l66, !tbaa !24
  %t112 = load i64, ptr %l66, !tbaa !24
  %t113 = load i64, ptr %l66, !tbaa !24
  %t114 = shl i64 1, %t113
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t109, i32 %t110, i64 %t114)
  store i32 %t118, ptr %l68
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t119 = load i32, ptr %l68, !tbaa !23
  store i32 %t119, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l10, !tbaa !24
  br label %bb13
bb24:
  %t124 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t124, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l8 = alloca i32
  %l13 = alloca i1
  %l14 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l23 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 52
  %t15 = load i32, ptr %l2, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t20 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fcheck_3arawTable_2_H63c69eede5e7cc65b54d8ce1ed292a98(ptr %v0, ptr %t14, i64 %t17)
  store i1 %t20, ptr %l13
  br label %bb2
bb2:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 52
  %t25 = load i32, ptr %l2, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t30 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fcheck_3arawTable_2_Hc06038cfd2a883d900a989353ba26a88(ptr %v0, ptr %v0, ptr %t24, i64 %t27)
  %t31 = extractvalue { i32, ptr } %t30, 1
  %t32 = extractvalue { i32, ptr } %t30, 0
  store i32 %t32, ptr %l20
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb6, label %ok.34, !prof !99
ok.34:
  store ptr %t31, ptr %l19
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t35 = load ptr, ptr %l19, !tbaa !29
  store ptr %t35, ptr %l14, !tbaa !29
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_4c4a12b05c2c1d31_444cdf7465594545)
  unreachable
bb8:
  %t36 = load ptr, ptr %l14, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawTable(ptr %v0, ptr %t37, i32 %t38, i1 false)
  store ptr %t41, ptr %l23
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l23, !tbaa !29
  store ptr %t42, ptr %l3, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 52
  %t46 = load i32, ptr %l2, !tbaa !23
  %t48 = sext i32 %t46 to i64
  %t49 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fcheck_3arawTable_2_Hfe32448d245bb62a962210add151a121(ptr %v0, ptr %v0, ptr %t45, i64 %t48, ptr %t49)
  br label %bb11
bb11:
  %t53 = load ptr, ptr %l3, !tbaa !29
  store ptr %t53, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMember(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/check:reflList"
  %l7 = alloca i32
  %lp8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/generic:Desc"
  %lp11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l18 = alloca { i64, ptr }
  %l25 = alloca %"compiler/check:reflList"
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l34 = alloca %"compiler/msgs:Msg"
  %l35 = alloca i64
  %l38 = alloca ptr
  %l42 = alloca i32
  %l50 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, ptr }
  %l75 = alloca %"compiler/msgs:Msg"
  %l76 = alloca i64
  %l79 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca i1
  %l85 = alloca i1
  %l86 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l94 = alloca i1
  %l98 = alloca %"compiler/check:reflVal"
  %l103 = alloca ptr
  %l106 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l111 = alloca { i64, ptr }
  %l113 = alloca %"compiler/msgs:Msg"
  %l114 = alloca i64
  %l116 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l123 = alloca %"compiler/msgs:Msg"
  %l124 = alloca i64
  %l126 = alloca i1
  %l127 = alloca i1
  %l129 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l134 = alloca { i64, ptr }
  %l137 = alloca %"compiler/msgs:Msg"
  %l138 = alloca i64
  %l141 = alloca ptr
  %l145 = alloca i1
  %l146 = alloca i1
  %l148 = alloca i1
  %l152 = alloca i1
  %l156 = alloca i1
  %l157 = alloca i1
  %l160 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l168 = alloca { i64, ptr }
  %l171 = alloca %"compiler/msgs:Msg"
  %l172 = alloca i64
  %l175 = alloca ptr
  %l179 = alloca i32
  %l188 = alloca ptr
  %l193 = alloca %"compiler/generic:Desc"
  %l195 = alloca i1
  %l196 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca %"compiler/source:Span"
  %l204 = alloca { i64, ptr }
  %l207 = alloca %"compiler/msgs:Msg"
  %l208 = alloca i64
  %l211 = alloca ptr
  %l214 = alloca i1
  %l215 = alloca i1
  %l222 = alloca ptr
  %l227 = alloca %"compiler/check:reflVal"
  %l232 = alloca ptr
  %l235 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l262 = alloca ptr
  %l263 = alloca %"compiler/source:Span"
  %l267 = alloca %"compiler/msgs:Msg"
  %l268 = alloca i64
  %l271 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t11 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l4, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i32, ptr %l4, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 0
  store i64 15, ptr %t12
  %t14 = insertvalue { %"compiler/source:Span", ptr, i32 } undef, %"compiler/source:Span" %t8, 0
  %t16 = insertvalue { %"compiler/source:Span", ptr, i32 } %t14, ptr %t9, 1
  %t18 = insertvalue { %"compiler/source:Span", ptr, i32 } %t16, i32 %t10, 2
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32 } %t18, ptr %t19
  %t20 = load { i64, [5 x i64] }, ptr %t11
  %t22 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 48, i64 8)
  store { i64, [5 x i64] } %t20, ptr %t22
  %t25 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %s0, ptr %t7, ptr %t22)
  store %"compiler/check:reflList" %t25, ptr %l25
  br label %bb2
bb2:
  %t26 = load %"compiler/check:reflList", ptr %l25
  store %"compiler/check:reflList" %t26, ptr %l6
  %t27 = getelementptr %"compiler/check:reflList", ptr %l6, i32 0, i32 0
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l27, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t31, ptr %l28
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  %t36 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t32, %"compiler/source:Span" %t33)
  store { i64, ptr } %t36, ptr %l31
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t37 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflListValue(ptr %s1, ptr %s1, { i64, ptr } %t49)
  store %"compiler/msgs:Msg" %t51, ptr %l34
  br label %bb6
bb6:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l28
  %t54 = load %"compiler/msgs:Msg", ptr %l34
  %t55 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t52, %"compiler/source:Span" %t53, %"compiler/msgs:Msg" %t54)
  store i64 %t55, ptr %l35
  br label %bb7
bb7:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l1
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t56, %"compiler/source:Span" %t57)
  store ptr %t60, ptr %l38
  br label %bb8
bb8:
  %t61 = load ptr, ptr %l38, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t61, ptr %rv
  br label %ret
bb9:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t63, ptr %t64)
  store i32 %t67, ptr %l42
  br label %bb10
bb10:
  %t68 = load i32, ptr %l42, !tbaa !23
  store i32 %t68, ptr %l7, !tbaa !23
  %t69 = load i32, ptr %l7, !tbaa !23
  %t71 = icmp sge i32 %t69, 0
  br i1 %t71, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load i32, ptr %l7, !tbaa !23
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t77 = icmp eq i32 %t73, %t74
  br i1 %t77, label %bb13, label %bb14
bb12:
  br label %bb112
bb13:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  %t83 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t79, %"compiler/source:Span" %t80)
  store ptr %t83, ptr %l50
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t84 = load ptr, ptr %l50, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t84, ptr %rv
  br label %ret
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l7, !tbaa !23
  %t90 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t90, ptr %l54
  br label %bb17
bb17:
  %t91 = load i1, ptr %l54, !tbaa !21
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store i1 %t96, ptr %l58
  br label %bb20
bb19:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb21
bb20:
  %t97 = load i1, ptr %l58, !tbaa !21
  %t98 = xor i1 %t97, true
  store i1 %t98, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t100 = load i1, ptr %l55, !tbaa !21
  br i1 %t100, label %bb22, label %bb23
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l7, !tbaa !23
  %t103 = load i32, ptr %l4, !tbaa !23
  %t107 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t101, i32 %t102, i32 %t103)
  store i1 %t107, ptr %l64
  br label %bb24
bb23:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb25
bb24:
  %t108 = load i1, ptr %l64, !tbaa !21
  store i1 %t108, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t109 = load i1, ptr %l60, !tbaa !21
  br i1 %t109, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t113 = call i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %t111)
  store i1 %t113, ptr %l67
  br label %bb29
bb29:
  %t114 = load i1, ptr %l67, !tbaa !21
  br i1 %t114, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l68, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t116, ptr %l69
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l1
  %t121 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t117, %"compiler/source:Span" %t118)
  store { i64, ptr } %t121, ptr %l72
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t122 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t123, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = extractvalue { i64, ptr } %t127, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %s6, ptr %s6, { i64, ptr } %t134)
  store %"compiler/msgs:Msg" %t136, ptr %l75
  br label %bb33
bb33:
  %t137 = load ptr, ptr %l68, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l69
  %t139 = load %"compiler/msgs:Msg", ptr %l75
  %t140 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t137, %"compiler/source:Span" %t138, %"compiler/msgs:Msg" %t139)
  store i64 %t140, ptr %l76
  br label %bb34
bb34:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l1
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t141, %"compiler/source:Span" %t142)
  store ptr %t145, ptr %l79
  br label %bb35
bb35:
  %t146 = load ptr, ptr %l79, !tbaa !29
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t146, ptr %rv
  br label %ret
bb36:
  %t148 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t150 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t148, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t150, ptr %l82
  br label %bb37
bb37:
  %t151 = load i1, ptr %l82, !tbaa !21
  br i1 %t151, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb41
bb39:
  %t152 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t152, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t154, ptr %l85
  br label %bb40
bb40:
  %t155 = load i1, ptr %l85, !tbaa !21
  store i1 %t155, ptr %l83, !tbaa !21
  br label %bb41
bb41:
  %t156 = load i1, ptr %l83, !tbaa !21
  br i1 %t156, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb45
bb43:
  %t157 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t159 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t157, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t159, ptr %l88
  br label %bb44
bb44:
  %t160 = load i1, ptr %l88, !tbaa !21
  store i1 %t160, ptr %l86, !tbaa !21
  br label %bb45
bb45:
  %t161 = load i1, ptr %l86, !tbaa !21
  br i1 %t161, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb49
bb47:
  %t162 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t164 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t162, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t164, ptr %l91
  br label %bb48
bb48:
  %t165 = load i1, ptr %l91, !tbaa !21
  store i1 %t165, ptr %l89, !tbaa !21
  br label %bb49
bb49:
  %t166 = load i1, ptr %l89, !tbaa !21
  br i1 %t166, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb53
bb51:
  %t167 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t169 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t167, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t169, ptr %l94
  br label %bb52
bb52:
  %t170 = load i1, ptr %l94, !tbaa !21
  store i1 %t170, ptr %l92, !tbaa !21
  br label %bb53
bb53:
  %t171 = load i1, ptr %l92, !tbaa !21
  br i1 %t171, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s8
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t174 = load i32, ptr %l4, !tbaa !23
  %t178 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v0, ptr %t172, ptr %t173, i32 %t174)
  store %"compiler/check:reflVal" %t178, ptr %l98
  br label %bb56
bb55:
  br label %bb87
bb56:
  %t179 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t179, ptr %lp8
  %t180 = load %"compiler/check:reflVal", ptr %l98
  %t181 = load ptr, ptr %lp8
  store %"compiler/check:reflVal" %t180, ptr %t181
  %t182 = load ptr, ptr %lp8
  %t183 = getelementptr %"compiler/check:reflVal", ptr %t182, i32 0, i32 0
  %t184 = load i1, ptr %t183, !tbaa !21
  br i1 %t184, label %bb57, label %bb58
bb57:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  %t188 = load ptr, ptr %lp8
  %t189 = load %"compiler/check:reflVal", ptr %t188
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v0, ptr %t186, %"compiler/source:Span" %t187, %"compiler/check:reflVal" %t189)
  store ptr %t193, ptr %l103
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t194 = load ptr, ptr %l103, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t194, ptr %rv
  br label %ret
bb60:
  %t196 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t198 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t196, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t198, ptr %l106
  br label %bb61
bb61:
  %t199 = load i1, ptr %l106, !tbaa !21
  br i1 %t199, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l107, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t201, ptr %l108
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l7, !tbaa !23
  %t206 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t202, i32 %t203)
  store { i64, ptr } %t206, ptr %l111
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t207 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = extractvalue { i64, ptr } %t207, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t215 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoKind(ptr %s10, ptr %s10, { i64, ptr } %t213)
  store %"compiler/msgs:Msg" %t215, ptr %l113
  br label %bb65
bb65:
  %t216 = load ptr, ptr %l107, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l108
  %t218 = load %"compiler/msgs:Msg", ptr %l113
  %t219 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t216, %"compiler/source:Span" %t217, %"compiler/msgs:Msg" %t218)
  store i64 %t219, ptr %l114
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s10)
  br label %bb67
bb67:
  %t220 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t220, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t222, ptr %l116
  br label %bb68
bb68:
  %t223 = load i1, ptr %l116, !tbaa !21
  br i1 %t223, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s11
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l117, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t225, ptr %l118
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i32, ptr %l7, !tbaa !23
  %t230 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t226, i32 %t227)
  store { i64, ptr } %t230, ptr %l121
  br label %bb71
bb70:
  br label %bb74
bb71:
  %t231 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  %t233 = extractvalue { i64, ptr } %t231, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  %t239 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoLength(ptr %s11, ptr %s11, { i64, ptr } %t237)
  store %"compiler/msgs:Msg" %t239, ptr %l123
  br label %bb72
bb72:
  %t240 = load ptr, ptr %l117, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l118
  %t242 = load %"compiler/msgs:Msg", ptr %l123
  %t243 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t240, %"compiler/source:Span" %t241, %"compiler/msgs:Msg" %t242)
  store i64 %t243, ptr %l124
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb74:
  %t244 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t246 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t244, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t246, ptr %l126
  br label %bb75
bb75:
  %t247 = load i1, ptr %l126, !tbaa !21
  br i1 %t247, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb79
bb77:
  %t248 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t250 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t248, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t250, ptr %l129
  br label %bb78
bb78:
  %t251 = load i1, ptr %l129, !tbaa !21
  store i1 %t251, ptr %l127, !tbaa !21
  br label %bb79
bb79:
  %t252 = load i1, ptr %l127, !tbaa !21
  br i1 %t252, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l130, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t254, ptr %l131
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i32, ptr %l7, !tbaa !23
  %t259 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t255, i32 %t256)
  store { i64, ptr } %t259, ptr %l134
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t260 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 0
  %t262 = extractvalue { i64, ptr } %t260, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t267 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t270 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoLayout(ptr %s12, ptr %v0, ptr %s12, { i64, ptr } %t266, { i64, ptr } %t267)
  store %"compiler/msgs:Msg" %t270, ptr %l137
  br label %bb83
bb83:
  %t271 = load ptr, ptr %l130, !tbaa !29
  %t272 = load %"compiler/source:Span", ptr %l131
  %t273 = load %"compiler/msgs:Msg", ptr %l137
  %t274 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t271, %"compiler/source:Span" %t272, %"compiler/msgs:Msg" %t273)
  store i64 %t274, ptr %l138
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s12)
  br label %bb85
bb85:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l1
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t275, %"compiler/source:Span" %t276)
  store ptr %t279, ptr %l141
  br label %bb86
bb86:
  %t280 = load ptr, ptr %l141, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t280, ptr %rv
  br label %ret
bb87:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr %l7, !tbaa !23
  %t286 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t282, i32 %t283)
  store i1 %t286, ptr %l145
  br label %bb88
bb88:
  %t287 = load i1, ptr %l145, !tbaa !21
  br i1 %t287, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l146, !tbaa !21
  br label %bb92
bb90:
  %t288 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t290 = call i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %t288)
  store i1 %t290, ptr %l148
  br label %bb91
bb91:
  %t291 = load i1, ptr %l148, !tbaa !21
  store i1 %t291, ptr %l146, !tbaa !21
  br label %bb92
bb92:
  %t292 = load i1, ptr %l146, !tbaa !21
  br i1 %t292, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb94:
  br label %bb95
bb95:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i32, ptr %l7, !tbaa !23
  %t298 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t294, i32 %t295)
  store i1 %t298, ptr %l152
  br label %bb96
bb96:
  %t299 = load i1, ptr %l152, !tbaa !21
  br i1 %t299, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i32, ptr %l7, !tbaa !23
  %t305 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t301, i32 %t302)
  store i1 %t305, ptr %l156
  br label %bb100
bb100:
  %t306 = load i1, ptr %l156, !tbaa !21
  br i1 %t306, label %bb101, label %bb102
bb101:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i32, ptr %l7, !tbaa !23
  %t311 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t307, i32 %t308)
  store i32 %t311, ptr %l160
  br label %bb103
bb102:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb104
bb103:
  %t312 = load i32, ptr %l160, !range !{i32 0, i32 6}
  %t314 = trunc i64 2 to i32
  %t315 = icmp eq i32 %t312, %t314
  store i1 %t315, ptr %l157, !tbaa !21
  br label %bb104
bb104:
  %t317 = load i1, ptr %l157, !tbaa !21
  br i1 %t317, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l164, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t320, ptr %l165
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load i32, ptr %l7, !tbaa !23
  %t325 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t321, i32 %t322)
  store { i64, ptr } %t325, ptr %l168
  br label %bb108
bb108:
  %t326 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 0
  %t328 = extractvalue { i64, ptr } %t326, 1
  %t329 = mul i64 %t327, 1
  %t330 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t329)
  call void @llvm.memcpy.p0.p0.i64(ptr %t330, ptr %t328, i64 %t329, i1 false)
  %t331 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t330, 1
  %t333 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t336 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %s3, ptr %v0, ptr %s3, { i64, ptr } %t332, { i64, ptr } %t333)
  store %"compiler/msgs:Msg" %t336, ptr %l171
  br label %bb109
bb109:
  %t337 = load ptr, ptr %l164, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l165
  %t339 = load %"compiler/msgs:Msg", ptr %l171
  %t340 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t337, %"compiler/source:Span" %t338, %"compiler/msgs:Msg" %t339)
  store i64 %t340, ptr %l172
  br label %bb110
bb110:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l1
  %t345 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t341, %"compiler/source:Span" %t342)
  store ptr %t345, ptr %l175
  br label %bb111
bb111:
  %t346 = load ptr, ptr %l175, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t346, ptr %rv
  br label %ret
bb112:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l3, !tbaa !29
  %t352 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t348, ptr %t349)
  store i32 %t352, ptr %l179
  br label %bb113
bb113:
  %t353 = load i32, ptr %l179, !tbaa !23
  store i32 %t353, ptr %l9, !tbaa !23
  %t354 = load i32, ptr %l9, !tbaa !23
  %t356 = icmp slt i32 %t354, 0
  br i1 %t356, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb115:
  br label %bb116
bb116:
  %t359 = load i32, ptr %l9, !tbaa !23
  %t360 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t363 = icmp eq i32 %t359, %t360
  br i1 %t363, label %bb117, label %bb118
bb117:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l1
  %t369 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t365, %"compiler/source:Span" %t366)
  store ptr %t369, ptr %l188
  br label %bb119
bb118:
  br label %bb120
bb119:
  %t370 = load ptr, ptr %l188, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t370, ptr %rv
  br label %ret
bb120:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t376 = load i32, ptr %l9, !tbaa !23
  %t379 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t375, i32 %t376)
  store %"compiler/generic:Desc" %t379, ptr %l193
  br label %bb121
bb121:
  %t380 = load %"compiler/generic:Desc", ptr %l193
  store %"compiler/generic:Desc" %t380, ptr %l10
  %t381 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t383 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t381, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t383, ptr %l195
  br label %bb122
bb122:
  %t384 = load i1, ptr %l195, !tbaa !21
  br i1 %t384, label %bb123, label %bb124
bb123:
  %t385 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t386 = load i64, ptr %t385, !tbaa !24
  %t387 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t390 = icmp ne i64 %t386, %t387
  store i1 %t390, ptr %l196, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb125
bb125:
  %t392 = load i1, ptr %l196, !tbaa !21
  br i1 %t392, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s18
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l200, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t394, ptr %l201
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l1
  %t399 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t395, %"compiler/source:Span" %t396)
  store { i64, ptr } %t399, ptr %l204
  br label %bb128
bb127:
  br label %bb132
bb128:
  %t400 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t400, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t401, i64 %t402)
  %t404 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  %t407 = extractvalue { i64, ptr } %t405, 0
  %t408 = extractvalue { i64, ptr } %t405, 1
  %t409 = mul i64 %t407, 1
  %t410 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t409)
  call void @llvm.memcpy.p0.p0.i64(ptr %t410, ptr %t408, i64 %t409, i1 false)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  %t414 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %s18, ptr %s18, { i64, ptr } %t412)
  store %"compiler/msgs:Msg" %t414, ptr %l207
  br label %bb129
bb129:
  %t415 = load ptr, ptr %l200, !tbaa !29
  %t416 = load %"compiler/source:Span", ptr %l201
  %t417 = load %"compiler/msgs:Msg", ptr %l207
  %t418 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t415, %"compiler/source:Span" %t416, %"compiler/msgs:Msg" %t417)
  store i64 %t418, ptr %l208
  br label %bb130
bb130:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load %"compiler/source:Span", ptr %l1
  %t423 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t419, %"compiler/source:Span" %t420)
  store ptr %t423, ptr %l211
  br label %bb131
bb131:
  %t424 = load ptr, ptr %l211, !tbaa !29
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t424, ptr %rv
  br label %ret
bb132:
  %t426 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t428 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t426, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t428, ptr %l214
  br label %bb133
bb133:
  %t429 = load i1, ptr %l214, !tbaa !21
  br i1 %t429, label %bb134, label %bb135
bb134:
  %t430 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t431 = load i64, ptr %t430, !tbaa !24
  %t432 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t435 = icmp eq i64 %t431, %t432
  store i1 %t435, ptr %l215, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb136
bb136:
  %t437 = load i1, ptr %l215, !tbaa !21
  br i1 %t437, label %bb137, label %bb138
bb137:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load %"compiler/source:Span", ptr %l1
  %t440 = load %"compiler/generic:Desc", ptr %l10
  %t444 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDefault(ptr %v0, ptr %t438, %"compiler/source:Span" %t439, %"compiler/generic:Desc" %t440)
  store ptr %t444, ptr %l222
  br label %bb139
bb138:
  br label %bb140
bb139:
  %t445 = load ptr, ptr %l222, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t445, ptr %rv
  br label %ret
bb140:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load ptr, ptr %l3, !tbaa !29
  %t449 = load i32, ptr %l4, !tbaa !23
  %t453 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v0, ptr %t447, ptr %t448, i32 %t449)
  store %"compiler/check:reflVal" %t453, ptr %l227
  br label %bb141
bb141:
  %t454 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t454, ptr %lp11
  %t455 = load %"compiler/check:reflVal", ptr %l227
  %t456 = load ptr, ptr %lp11
  store %"compiler/check:reflVal" %t455, ptr %t456
  %t457 = load ptr, ptr %lp11
  %t458 = getelementptr %"compiler/check:reflVal", ptr %t457, i32 0, i32 0
  %t459 = load i1, ptr %t458, !tbaa !21
  br i1 %t459, label %bb142, label %bb143
bb142:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load %"compiler/source:Span", ptr %l1
  %t463 = load ptr, ptr %lp11
  %t464 = load %"compiler/check:reflVal", ptr %t463
  %t468 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v0, ptr %t461, %"compiler/source:Span" %t462, %"compiler/check:reflVal" %t464)
  store ptr %t468, ptr %l232
  br label %bb144
bb143:
  br label %bb145
bb144:
  %t469 = load ptr, ptr %l232, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t469, ptr %rv
  br label %ret
bb145:
  %t471 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t472 = load i64, ptr %t471, !tbaa !24
  store i64 %t472, ptr %l12, !tbaa !24
  %t474 = load i64, ptr %l12, !tbaa !24
  %t475 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t478 = icmp eq i64 %t474, %t475
  br i1 %t478, label %bb146, label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb149
bb148:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb149:
  %t480 = load i64, ptr %l12, !tbaa !24
  %t481 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t484 = icmp eq i64 %t480, %t481
  br i1 %t484, label %bb150, label %bb151
bb150:
  br label %bb152
bb151:
  br label %bb153
bb152:
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb153:
  %t486 = load i64, ptr %l12, !tbaa !24
  %t487 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t490 = icmp eq i64 %t486, %t487
  br i1 %t490, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb157
bb156:
  store { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb157:
  %t492 = load i64, ptr %l12, !tbaa !24
  %t493 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t496 = icmp eq i64 %t492, %t493
  br i1 %t496, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  store { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb161:
  br i1 true, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_6fa12bf18c08968_7f63ef0109416d3c)
  unreachable
bb166:
  %t498 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t498, ptr %l13, !tbaa !27
  %t499 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t500 = load i64, ptr %t499, !tbaa !24
  store i64 %t500, ptr %l14, !tbaa !24
  %t502 = load i64, ptr %l14, !tbaa !24
  %t503 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t506 = icmp eq i64 %t502, %t503
  br i1 %t506, label %bb167, label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb170
bb169:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb170:
  %t508 = load i64, ptr %l14, !tbaa !24
  %t509 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t512 = icmp eq i64 %t508, %t509
  br i1 %t512, label %bb171, label %bb172
bb171:
  br label %bb173
bb172:
  br label %bb174
bb173:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb174:
  %t514 = load i64, ptr %l14, !tbaa !24
  %t515 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t518 = icmp eq i64 %t514, %t515
  br i1 %t518, label %bb175, label %bb176
bb175:
  br label %bb177
bb176:
  br label %bb178
bb177:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb178:
  %t520 = load i64, ptr %l14, !tbaa !24
  %t521 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t524 = icmp eq i64 %t520, %t521
  br i1 %t524, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  br label %bb182
bb181:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb182:
  br i1 true, label %bb183, label %bb184
bb183:
  br label %bb185
bb184:
  br label %bb186
bb185:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb186:
  call void @__olang_check_failed(ptr @olang_loc_366830190f407939_a82d5f1c611378ed)
  unreachable
bb187:
  %t526 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t527 = load ptr, ptr %l0, !tbaa !29
  store ptr %t527, ptr %l262, !tbaa !29
  %t528 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t528, ptr %l263
  %t530 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t531 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t532 = load ptr, ptr @__olang_prog_scope
  %t533 = load ptr, ptr @__olang_prog_scope
  %t537 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %t532, ptr %v0, ptr %t533, ptr %s0, { i64, ptr } %t526, { i64, ptr } %t530, { i64, ptr } %t531)
  store %"compiler/msgs:Msg" %t537, ptr %l267
  br label %bb188
bb188:
  %t538 = load ptr, ptr %l262, !tbaa !29
  %t539 = load %"compiler/source:Span", ptr %l263
  %t540 = load %"compiler/msgs:Msg", ptr %l267
  %t541 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t538, %"compiler/source:Span" %t539, %"compiler/msgs:Msg" %t540)
  store i64 %t541, ptr %l268
  br label %bb189
bb189:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load %"compiler/source:Span", ptr %l1
  %t546 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t542, %"compiler/source:Span" %t543)
  store ptr %t546, ptr %l271
  br label %bb190
bb190:
  %t547 = load ptr, ptr %l271, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t547, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca i64
  %l17 = alloca i64
  %l23 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca ptr
  %l43 = alloca i1
  %l49 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, [3 x i64] }
  %rv = alloca { i64, [3 x i64] }
  %t24 = alloca { i64, [3 x i64] }, align 8
  %t89 = alloca { i64, [3 x i64] }, align 8
  %t115 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l14, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 12
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l17
  br label %bb4
bb4:
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = load i64, ptr %l17, !tbaa !24
  %t21 = icmp sge i64 %t19, %t20
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store { i64, [3 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 0
  store i64 0, ptr %t25
  %t26 = load { i64, [3 x i64] }, ptr %t24
  store { i64, [3 x i64] } %t26, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 12
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l23
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l23, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 1
  %t38 = load { i64, [2 x i64] }, ptr %t37
  store { i64, [2 x i64] } %t38, ptr %l3
  %t40 = load { i64, [2 x i64] }, ptr %l3
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 0
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t45 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t46 = getelementptr { i64 }, ptr %t45, i32 0, i32 0
  %t47 = load i64, ptr %t46
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb23
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l32
  br label %bb13
bb13:
  %t57 = load i64, ptr %l32, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l36
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Func", ptr %t66, i32 0, i32 3
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Sig", ptr %t69, i32 0, i32 1
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l6, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t78 = icmp eq i64 %t76, 0
  br i1 %t78, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb17
bb16:
  %t80 = load i64, ptr %l1, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t86 = icmp sge i64 %t80, %t83
  store i1 %t86, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t88 = load i1, ptr %l43, !tbaa !21
  br i1 %t88, label %bb18, label %bb19
bb18:
  store { i64, [3 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 0
  store i64 0, ptr %t90
  %t91 = load { i64, [3 x i64] }, ptr %t89
  store { i64, [3 x i64] } %t91, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l49, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t97, i64 %t98)
  store i64 %t101, ptr %l53
  br label %bb21
bb21:
  %t102 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t102, ptr %l54, !tbaa !27
  %t103 = load i64, ptr %l1, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 %t103
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t110 = load ptr, ptr %l49, !tbaa !29
  %t111 = load i64, ptr %l53, !tbaa !24
  %t113 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t110, i64 %t111, ptr %t108)
  store { i64, [3 x i64] } %t113, ptr %l58
  br label %bb22
bb22:
  %t114 = load { i64, [3 x i64] }, ptr %l58
  store { i64, [3 x i64] } %t114, ptr %rv
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store { i64, [3 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [3 x i64] }, ptr %t115, i32 0, i32 0
  store i64 0, ptr %t116
  %t117 = load { i64, [3 x i64] }, ptr %t115
  store { i64, [3 x i64] } %t117, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @olang_loc_6b233227628ca57_40576c0d91c202cb)
  unreachable
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t9, ptr %l10
  br label %bb4
bb4:
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 68
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H970bb490312910b3b744570a26468c6c(ptr %v0, ptr %t13, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14)
  store i1 %t17, ptr %l14
  br label %bb5
bb5:
  %t18 = load i1, ptr %l14, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 68
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l18
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l19
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd27b567062a69be2f699d8e9ab74cf5a(ptr %v0, ptr %v0, ptr %t26, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 68
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t35 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hca9d4f63e6a0ec4764c25705e3ecdd1f(ptr %v0, ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  %t36 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 1
  %t37 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 0
  store i32 %t37, ptr %l25
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39, !prof !99
ok.39:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l24
  br label %bb11
bb11:
  %t40 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l20
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t41 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l5
  %t42 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %l5, ptr %t42)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca %"compiler/typed:Local"
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l102 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t7 = load ptr, ptr %l15, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l15, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l16, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l2, !tbaa !23
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb19
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %t27, i64 %t30)
  store i1 %t33, ptr %l26
  br label %bb9
bb9:
  %t34 = load i1, ptr %l26, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb18
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t35)
  store ptr %t37, ptr %l29
  br label %bb12
bb12:
  %t38 = load i32, ptr %l3, !tbaa !23
  %t39 = load ptr, ptr %l29, !tbaa !29
  %t41 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t39, i32 %t38)
  store %"compiler/typed:Local" %t41, ptr %l31
  br label %bb13
bb13:
  %t42 = getelementptr %"compiler/typed:Local", ptr %l31, i32 0, i32 4
  %t43 = load i32, ptr %t42, !range !{i32 0, i32 7}
  %t45 = trunc i64 5 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l2, !tbaa !23
  %t52 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l37
  br label %bb16
bb15:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb17
bb16:
  %t53 = load i1, ptr %l37, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t56 = load i1, ptr %l34, !tbaa !21
  store i1 %t56, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t57 = load i1, ptr %l27, !tbaa !21
  store i1 %t57, ptr %l14, !tbaa !21
  br label %bb66
bb19:
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t59 = load ptr, ptr %l39, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l39, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 8}
  %t65 = icmp eq i64 %t63, 1
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l40, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t69, i32 0, i32 2
  %t71 = load i64, ptr %t70
  store i64 %t71, ptr %l4, !tbaa !24
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t75, i32 0, i32 3
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l5, !tbaa !23
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i64, ptr %l4, !tbaa !24
  %t81 = load i32, ptr %l5, !tbaa !23
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimmutableGlobal(ptr %v0, ptr %t79, i64 %t80, i32 %t81)
  store i1 %t85, ptr %l50
  br label %bb25
bb25:
  %t86 = load i1, ptr %l50, !tbaa !21
  store i1 %t86, ptr %l14, !tbaa !21
  br label %bb66
bb26:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t88 = load ptr, ptr %l51, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb27, label %bb28
bb27:
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 8}
  %t94 = icmp eq i64 %t92, 2
  store i1 %t94, ptr %l52, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l52, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t98, i32 0, i32 2
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l6, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t107 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t107, ptr %l60
  br label %bb32
bb32:
  %t108 = load i1, ptr %l60, !tbaa !21
  store i1 %t108, ptr %l14, !tbaa !21
  br label %bb66
bb33:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t110 = load ptr, ptr %l61, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb34, label %bb35
bb34:
  %t113 = load ptr, ptr %l61, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 8}
  %t116 = icmp eq i64 %t114, 3
  store i1 %t116, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t117 = load i1, ptr %l62, !tbaa !21
  br i1 %t117, label %bb36, label %bb37
bb36:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l7, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l7, !tbaa !29
  %t129 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  store i1 %t129, ptr %l70
  br label %bb39
bb39:
  %t130 = load i1, ptr %l70, !tbaa !21
  store i1 %t130, ptr %l14, !tbaa !21
  br label %bb66
bb40:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t132 = load ptr, ptr %l71, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb41, label %bb42
bb41:
  %t135 = load ptr, ptr %l71, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 8}
  %t138 = icmp eq i64 %t136, 4
  store i1 %t138, ptr %l72, !tbaa !21
  br label %bb42
bb42:
  %t139 = load i1, ptr %l72, !tbaa !21
  br i1 %t139, label %bb43, label %bb44
bb43:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t142, i32 0, i32 2
  %t144 = load ptr, ptr %t143
  store ptr %t144, ptr %l8, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l8, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Elem", ptr %t147, i32 0, i32 0
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t154 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t146, ptr %t150)
  store i1 %t154, ptr %l81
  br label %bb46
bb46:
  %t155 = load i1, ptr %l81, !tbaa !21
  store i1 %t155, ptr %l14, !tbaa !21
  br label %bb66
bb47:
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t157 = load ptr, ptr %l82, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb48, label %bb49
bb48:
  %t160 = load ptr, ptr %l82, !tbaa !29
  %t161 = load i64, ptr %t160, !range !{i64 0, i64 8}
  %t163 = icmp eq i64 %t161, 5
  store i1 %t163, ptr %l83, !tbaa !21
  br label %bb49
bb49:
  %t164 = load i1, ptr %l83, !tbaa !21
  br i1 %t164, label %bb50, label %bb51
bb50:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t167, i32 0, i32 2
  %t169 = load ptr, ptr %t168
  store ptr %t169, ptr %l9, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l9, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Payload", ptr %t172, i32 0, i32 0
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t179 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t171, ptr %t175)
  store i1 %t179, ptr %l92
  br label %bb53
bb53:
  %t180 = load i1, ptr %l92, !tbaa !21
  store i1 %t180, ptr %l14, !tbaa !21
  br label %bb66
bb54:
  %t181 = load ptr, ptr %l1, !tbaa !29
  store ptr %t181, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t182 = load ptr, ptr %l93, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb55, label %bb56
bb55:
  %t185 = load ptr, ptr %l93, !tbaa !29
  %t186 = load i64, ptr %t185, !range !{i64 0, i64 8}
  %t188 = icmp eq i64 %t186, 6
  store i1 %t188, ptr %l94, !tbaa !21
  br label %bb56
bb56:
  %t189 = load i1, ptr %l94, !tbaa !21
  br i1 %t189, label %bb57, label %bb58
bb57:
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t192, i32 0, i32 2
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l10, !tbaa !29
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l10, !tbaa !29
  %t201 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t196, ptr %t197)
  store i1 %t201, ptr %l102
  br label %bb60
bb60:
  %t202 = load i1, ptr %l102, !tbaa !21
  store i1 %t202, ptr %l14, !tbaa !21
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_29e885d4e6352517_4af5f3c2b7cab7a3)
  unreachable
bb66:
  %t203 = load i1, ptr %l14, !tbaa !21
  store i1 %t203, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i1
  %l85 = alloca i1
  %l87 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  store ptr %t11, ptr %l13, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t12)
  store i32 %t15, ptr %l16
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = load i32, ptr %l16, !tbaa !23
  %t18 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t20 = load i64, ptr %l17, !tbaa !24
  %t22 = and i64 %t20, %t19
  %t24 = icmp ne i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l21, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t27)
  store ptr %t29, ptr %l23
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = load ptr, ptr %l23, !tbaa !29
  %t32 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  store i64 %t32, ptr %l24
  br label %bb9
bb9:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb14
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l27, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t37)
  store ptr %t39, ptr %l29
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l27, !tbaa !29
  %t41 = load ptr, ptr %l29, !tbaa !29
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t40, ptr %t41)
  store i1 %t42, ptr %l30
  br label %bb13
bb13:
  %t43 = load i1, ptr %l30, !tbaa !21
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l26, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb15:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t46 = load ptr, ptr %l32, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 18}
  %t52 = icmp eq i64 %t50, 2
  store i1 %t52, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l33, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l2, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t64 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRead(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store i1 %t64, ptr %l40
  br label %bb21
bb21:
  %t65 = load i1, ptr %l40, !tbaa !21
  store i1 %t65, ptr %l31, !tbaa !21
  br label %bb76
bb22:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t67 = load ptr, ptr %l41, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb23, label %bb24
bb23:
  %t70 = load ptr, ptr %l41, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 18}
  %t73 = icmp eq i64 %t71, 3
  store i1 %t73, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb25, label %bb26
bb25:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l3, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  store i1 %t86, ptr %l50
  br label %bb28
bb28:
  %t87 = load i1, ptr %l50, !tbaa !21
  store i1 %t87, ptr %l31, !tbaa !21
  br label %bb76
bb29:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb30, label %bb31
bb30:
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 10
  store i1 %t95, ptr %l52, !tbaa !21
  br label %bb31
bb31:
  %t96 = load i1, ptr %l52, !tbaa !21
  br i1 %t96, label %bb32, label %bb33
bb32:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l4, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l4, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Slice", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t111 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t103, ptr %t107)
  store i1 %t111, ptr %l61
  br label %bb35
bb35:
  %t112 = load i1, ptr %l61, !tbaa !21
  store i1 %t112, ptr %l31, !tbaa !21
  br label %bb76
bb36:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb37, label %bb38
bb37:
  %t117 = load ptr, ptr %l62, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 18}
  %t120 = icmp eq i64 %t118, 6
  store i1 %t120, ptr %l63, !tbaa !21
  br label %bb38
bb38:
  %t121 = load i1, ptr %l63, !tbaa !21
  br i1 %t121, label %bb39, label %bb40
bb39:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l5, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l5, !tbaa !29
  %t132 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %t128, ptr %t129)
  store i1 %t132, ptr %l70
  br label %bb42
bb42:
  %t133 = load i1, ptr %l70, !tbaa !21
  store i1 %t133, ptr %l31, !tbaa !21
  br label %bb76
bb43:
  %t134 = load ptr, ptr %l1, !tbaa !29
  store ptr %t134, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t135 = load ptr, ptr %l71, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb44, label %bb45
bb44:
  %t138 = load ptr, ptr %l71, !tbaa !29
  %t139 = load i64, ptr %t138, !range !{i64 0, i64 18}
  %t141 = icmp eq i64 %t139, 9
  store i1 %t141, ptr %l72, !tbaa !21
  br label %bb45
bb45:
  %t142 = load i1, ptr %l72, !tbaa !21
  br i1 %t142, label %bb46, label %bb47
bb46:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t145, i32 0, i32 2
  %t147 = load i32, ptr %t146, !range !{i32 0, i32 43}
  store i32 %t147, ptr %l6
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 4
  %t153 = load { i64, ptr }, ptr %t152
  store { i64, ptr } %t153, ptr %l7, !tbaa !27
  br label %bb48
bb47:
  br label %bb57
bb48:
  %t155 = load i32, ptr %l6, !range !{i32 0, i32 43}
  %t157 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t155)
  store i1 %t157, ptr %l80
  br label %bb49
bb49:
  %t158 = load i1, ptr %l80, !tbaa !21
  br i1 %t158, label %bb50, label %bb51
bb50:
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t163 = icmp sgt i64 %t161, 0
  store i1 %t163, ptr %l81, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb52
bb52:
  %t165 = load i1, ptr %l81, !tbaa !21
  br i1 %t165, label %bb53, label %bb54
bb53:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t167, ptr %l87, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr ptr, ptr %t169, i64 0
  %t171 = load ptr, ptr %t170, !tbaa !39
  %t175 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t166, ptr %t171)
  store i1 %t175, ptr %l90
  br label %bb55
bb54:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb56
bb55:
  %t176 = load i1, ptr %l90, !tbaa !21
  store i1 %t176, ptr %l85, !tbaa !21
  br label %bb56
bb56:
  %t177 = load i1, ptr %l85, !tbaa !21
  store i1 %t177, ptr %l31, !tbaa !21
  br label %bb76
bb57:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t179 = load ptr, ptr %l91, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb58, label %bb59
bb58:
  %t182 = load ptr, ptr %l91, !tbaa !29
  %t183 = load i64, ptr %t182, !range !{i64 0, i64 18}
  %t185 = icmp eq i64 %t183, 5
  store i1 %t185, ptr %l92, !tbaa !21
  br label %bb59
bb59:
  %t186 = load i1, ptr %l92, !tbaa !21
  br i1 %t186, label %bb60, label %bb61
bb60:
  br label %bb70
bb61:
  %t187 = load ptr, ptr %l1, !tbaa !29
  store ptr %t187, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t188 = load ptr, ptr %l95, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb62, label %bb63
bb62:
  %t191 = load ptr, ptr %l95, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 18}
  %t194 = icmp eq i64 %t192, 1
  store i1 %t194, ptr %l96, !tbaa !21
  br label %bb63
bb63:
  %t195 = load i1, ptr %l96, !tbaa !21
  br i1 %t195, label %bb64, label %bb65
bb64:
  br label %bb70
bb65:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t197 = load ptr, ptr %l99, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb66, label %bb67
bb66:
  %t200 = load ptr, ptr %l99, !tbaa !29
  %t201 = load i64, ptr %t200, !range !{i64 0, i64 18}
  %t203 = icmp eq i64 %t201, 0
  store i1 %t203, ptr %l100, !tbaa !21
  br label %bb67
bb67:
  %t204 = load i1, ptr %l100, !tbaa !21
  br i1 %t204, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb76
bb71:
  br i1 true, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_62c5ac3e914a4019_8e197c98e172d865)
  unreachable
bb76:
  %t205 = load i1, ptr %l31, !tbaa !21
  store i1 %t205, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i1
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t21)
  store i32 %t24, ptr %l16
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l16, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t27, ptr %l17
  br label %bb9
bb9:
  %t28 = load i1, ptr %l17, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l12, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 70
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t35)
  store ptr %t37, ptr %l22
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t45 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, ptr %v0, i64 %t41, ptr %t42)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t45, ptr %l26
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v0, ptr %t46, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t47)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 3
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t26, ptr %l19
  br label %bb9
bb9:
  %t27 = load i1, ptr %l19, !tbaa !21
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb36
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 4
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Elem", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t43, ptr %t47)
  store i1 %t51, ptr %l30
  br label %bb16
bb16:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %l9, !tbaa !21
  br label %bb36
bb17:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 8}
  %t60 = icmp eq i64 %t58, 5
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l32, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Payload", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t68, ptr %t72)
  store i1 %t76, ptr %l41
  br label %bb23
bb23:
  %t77 = load i1, ptr %l41, !tbaa !21
  store i1 %t77, ptr %l9, !tbaa !21
  br label %bb36
bb24:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t79 = load ptr, ptr %l42, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb25, label %bb26
bb25:
  %t82 = load ptr, ptr %l42, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 6
  store i1 %t85, ptr %l43, !tbaa !21
  br label %bb26
bb26:
  %t86 = load i1, ptr %l43, !tbaa !21
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t98 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  store i1 %t98, ptr %l51
  br label %bb30
bb30:
  %t99 = load i1, ptr %l51, !tbaa !21
  store i1 %t99, ptr %l9, !tbaa !21
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_19fb235390dd08bf_74b3a6d5c5264653)
  unreachable
bb36:
  %t100 = load i1, ptr %l9, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/typed:Block"
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryChecks(ptr %v0, ptr %t7)
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l9
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 41
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fcheck_2estoredIn(ptr %v1, ptr %v0, { i64, ptr } %t16, ptr %t15)
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %t25)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 37
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t30, i64 %t31)
  store { i64, ptr } %t34, ptr %l20
  br label %bb9
bb9:
  %t35 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t36 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t35)
  store %"compiler/typed:Block" %t36, ptr %l21
  br label %bb10
bb10:
  %t37 = load %"compiler/typed:Block", ptr %l21
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t37, ptr %t38
  store ptr %t38, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/msgs:Msg"
  %l28 = alloca i64
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l18
  br label %bb5
bb5:
  %t26 = load i1, ptr %l18, !tbaa !21
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t33 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v0, ptr %t28, ptr %t29)
  store %"compiler/source:Span" %t33, ptr %l22
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t34 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t34, ptr %l4
  %t35 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = icmp sge i32 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t41, ptr %l26
  %t42 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultExisting(ptr %s2)
  store %"compiler/msgs:Msg" %t42, ptr %l27
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l26
  %t45 = load %"compiler/msgs:Msg", ptr %l27
  %t46 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t43, %"compiler/source:Span" %t44, %"compiler/msgs:Msg" %t45)
  store i64 %t46, ptr %l28
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t48)
  store %"compiler/source:Span" %t50, ptr %l31
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l31
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t51, %"compiler/source:Span" %t52)
  store ptr %t53, ptr %l32
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  %t54 = load ptr, ptr %l32, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l33, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  store ptr %t56, ptr %l34, !tbaa !29
  %t57 = load i32, ptr %l2, !tbaa !23
  store i32 %t57, ptr %l35, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  store %"compiler/source:Span" %t62, ptr %l38
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t65 = load i32, ptr %l35, !tbaa !23
  %t66 = load %"compiler/source:Span", ptr %l38
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t63, ptr %t64, i32 %t65, %"compiler/source:Span" %t66)
  store ptr %t67, ptr %l39
  br label %bb19
bb19:
  %t68 = load ptr, ptr %l39, !tbaa !29
  store ptr %t68, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestTarget(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca %"compiler/names:Entry"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca %"compiler/names:Entry"
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca %"compiler/names:Entry"
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca %"compiler/names:Entry"
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l60 = alloca %"std/prelude/text:StringBuilder"
  %l69 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l93 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l100 = alloca %"compiler/msgs:Msg"
  %l101 = alloca i64
  %l111 = alloca ptr
  %l117 = alloca i64
  %l119 = alloca i64
  %l124 = alloca %"compiler/names:Entry"
  %l126 = alloca { i64, ptr }
  %l131 = alloca i1
  %l141 = alloca i64
  %l145 = alloca i64
  %l148 = alloca i64
  %l174 = alloca ptr
  %l177 = alloca i64
  %l179 = alloca i64
  %l184 = alloca %"compiler/names:Entry"
  %l186 = alloca { i64, ptr }
  %l189 = alloca i1
  %l192 = alloca i1
  %l195 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l199 = alloca %"compiler/msgs:Msg"
  %l200 = alloca i64
  %l213 = alloca i64
  %l217 = alloca i64
  %l220 = alloca i64
  %l241 = alloca ptr
  %l245 = alloca i1
  %l248 = alloca { i64, ptr }
  %l253 = alloca ptr
  %l256 = alloca ptr
  %l260 = alloca i32
  %l261 = alloca i32
  %l262 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l269 = alloca i32
  %l272 = alloca i1
  %l273 = alloca i1
  %l276 = alloca ptr
  %l281 = alloca i32
  %l282 = alloca i32
  %l283 = alloca { i64, ptr }
  %l288 = alloca i1
  %l291 = alloca i1
  %l292 = alloca i1
  %l298 = alloca { i64, ptr }
  %l299 = alloca { i64, ptr }
  %l301 = alloca { i64, ptr }
  %l303 = alloca { i64, ptr }
  %l304 = alloca i1
  %l309 = alloca i64
  %l317 = alloca i64
  %l319 = alloca i64
  %l324 = alloca %"compiler/names:Entry"
  %l326 = alloca { i64, ptr }
  %l329 = alloca i1
  %l335 = alloca ptr
  %l337 = alloca %"compiler/source:Span"
  %l339 = alloca %"compiler/msgs:Msg"
  %l340 = alloca i64
  %l343 = alloca %"compiler/msgs:Nearest"
  %l347 = alloca i64
  %l349 = alloca i64
  %l354 = alloca %"compiler/names:Entry"
  %l357 = alloca i1
  %l360 = alloca ptr
  %l363 = alloca { i64, ptr }
  %l370 = alloca i64
  %l374 = alloca i64
  %l377 = alloca i64
  %l398 = alloca ptr
  %l402 = alloca i1
  %l406 = alloca i64
  %l411 = alloca ptr
  %l414 = alloca ptr
  %l418 = alloca i32
  %l419 = alloca i32
  %l420 = alloca { i64, ptr }
  %l424 = alloca ptr
  %l426 = alloca { i64, ptr }
  %l428 = alloca i32
  %l429 = alloca i1
  %l430 = alloca ptr
  %l431 = alloca ptr
  %l434 = alloca ptr
  %l437 = alloca ptr
  %l439 = alloca { i64, ptr }
  %l441 = alloca i32
  %l442 = alloca i32
  %l443 = alloca i32
  %l444 = alloca { i64, ptr }
  %l448 = alloca { i64, ptr }
  %l456 = alloca { i64, ptr }
  %l458 = alloca i1
  %l460 = alloca ptr
  %l466 = alloca { i64, ptr }
  %l470 = alloca { i64, ptr }
  %l479 = alloca ptr
  %l481 = alloca %"compiler/source:Span"
  %l485 = alloca %"compiler/msgs:Msg"
  %l486 = alloca i64
  %l487 = alloca ptr
  %l489 = alloca %"compiler/source:Span"
  %l491 = alloca %"compiler/msgs:Msg"
  %l492 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s61 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t5, i64 -1, i64 %t6, i32 %t7, i32 0)
  store ptr %t11, ptr %l57
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Path", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l4, !tbaa !27
  %t17 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t17, ptr %l60
  br label %bb5
bb5:
  %t18 = load %"std/prelude/text:StringBuilder", ptr %l60
  store %"std/prelude/text:StringBuilder" %t18, ptr %l5
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l8, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t35, ptr %l69, !tbaa !27
  %t36 = load i64, ptr %l7, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 %t36
  %t41 = load i32, ptr %t40, !tbaa !33
  store i32 %t41, ptr %l10, !tbaa !23
  %t45 = icmp sgt i64 %t33, 0
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 46)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  store ptr %l5, ptr %l75, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l10, !tbaa !23
  %t52 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t48, i32 %t49)
  store { i64, ptr } %t52, ptr %l78
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l75, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l78, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t53, { i64, ptr } %t54)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l7, !tbaa !24
  br label %bb6
bb17:
  %t60 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t60, ptr %l82
  br label %bb18
bb18:
  %t61 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t61, ptr %l11, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t62, ptr %l83, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t63, %"compiler/source:Span" %a2)
  store { i64, ptr } %t67, ptr %l86
  br label %bb19
bb19:
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t70 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = add i64 %t69, %t72
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t77 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = add i64 %t76, %t79
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t68, i64 %t69)
  %t85 = getelementptr i8, ptr %t84, i64 %t69
  call void @olang_textcopy(ptr %t85, ptr %t71, i64 %t72)
  %t86 = getelementptr i8, ptr %t85, i64 %t72
  call void @olang_textcopy(ptr %t86, ptr %t74, i64 %t75)
  %t87 = getelementptr i8, ptr %t86, i64 %t75
  call void @olang_textcopy(ptr %t87, ptr %t78, i64 %t79)
  %t88 = getelementptr i8, ptr %t87, i64 %t79
  call void @olang_textcopy(ptr %t88, ptr %t81, i64 %t82)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t84, 1
  store { i64, ptr } %t90, ptr %l12, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 123
  %t96 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t94)
  store { i64, ptr } %t96, ptr %l90
  br label %bb20
bb20:
  %t97 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t101 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t97, { i64, ptr } %t98)
  store i1 %t101, ptr %l93
  br label %bb21
bb21:
  %t102 = load i1, ptr %l93, !tbaa !21
  br i1 %t102, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l94, !tbaa !29
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t106 = getelementptr %"compiler/ast:Path", ptr %t104, i32 0, i32 0
  %t107 = load %"compiler/source:Span", ptr %t106
  store %"compiler/source:Span" %t107, ptr %l96
  %t108 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t110 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s7, { i64, ptr } %t108)
  store { i64, ptr } %t110, ptr %l98
  br label %bb24
bb23:
  br label %bb28
bb24:
  %t111 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t119 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTestTargetTwice(ptr %s7, ptr %s7, { i64, ptr } %t117)
  store %"compiler/msgs:Msg" %t119, ptr %l100
  br label %bb25
bb25:
  %t120 = load ptr, ptr %l94, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l96
  %t122 = load %"compiler/msgs:Msg", ptr %l100
  %t123 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t120, %"compiler/source:Span" %t121, %"compiler/msgs:Msg" %t122)
  store i64 %t123, ptr %l101
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s7)
  %t124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t124)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb28:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 123
  %t129 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t128, { i64, ptr } %t129)
  br label %bb29
bb29:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/names:Resolver", ptr %t138, i32 0, i32 1
  %t141 = load i64, ptr %l1, !tbaa !24
  %t144 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store ptr %t144, ptr %l111
  br label %bb30
bb30:
  %t145 = load ptr, ptr %l111, !tbaa !29
  store ptr %t145, ptr %l13, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t150 = icmp eq i64 %t148, 1
  br i1 %t150, label %bb31, label %bb32
bb31:
  %t152 = load ptr, ptr %l13, !tbaa !29
  %t154 = getelementptr %"compiler/names:Table", ptr %t152, i32 0, i32 0
  store ptr %t154, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb33
bb32:
  %t156 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t160 = icmp eq i64 %t158, 2
  br i1 %t160, label %bb88, label %bb89
bb33:
  %t162 = load i64, ptr %l15, !tbaa !24
  store i64 %t162, ptr %l117, !tbaa !24
  %t163 = load ptr, ptr %l14, !tbaa !29
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t163)
  store i64 %t165, ptr %l119
  br label %bb34
bb34:
  %t166 = load i64, ptr %l117, !tbaa !24
  %t167 = load i64, ptr %l119, !tbaa !24
  %t168 = icmp slt i64 %t166, %t167
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb35, label %bb36
bb35:
  br label %bb50
bb36:
  br label %bb37
bb37:
  %t172 = load ptr, ptr %l14, !tbaa !29
  %t173 = load i64, ptr %l15, !tbaa !24
  %t176 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t172, i64 %t173)
  store %"compiler/names:Entry" %t176, ptr %l124
  br label %bb38
bb38:
  %t177 = load %"compiler/names:Entry", ptr %l124
  store %"compiler/names:Entry" %t177, ptr %l16
  %t178 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 0
  %t179 = load i32, ptr %t178, !tbaa !23
  %t180 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t180, ptr %l126, !tbaa !27
  %t181 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr i32, ptr %t182, i64 0
  %t184 = load i32, ptr %t183, !tbaa !33
  %t187 = icmp ne i32 %t179, %t184
  br i1 %t187, label %bb39, label %bb40
bb39:
  br label %bb49
bb40:
  br label %bb41
bb41:
  %t189 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 2
  %t190 = load i32, ptr %t189, !range !{i32 0, i32 9}
  %t192 = trunc i64 3 to i32
  %t193 = icmp eq i32 %t190, %t192
  br i1 %t193, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb44
bb43:
  %t195 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 2
  %t196 = load i32, ptr %t195, !range !{i32 0, i32 9}
  %t198 = trunc i64 4 to i32
  %t199 = icmp eq i32 %t196, %t198
  store i1 %t199, ptr %l131, !tbaa !21
  br label %bb44
bb44:
  %t201 = load i1, ptr %l131, !tbaa !21
  br i1 %t201, label %bb45, label %bb46
bb45:
  %t202 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t202)
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb48:
  br label %bb49
bb49:
  %t204 = load i64, ptr %l15, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l15, !tbaa !24
  br label %bb33
bb50:
  store i64 0, ptr %l17, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/load:Loader", ptr %t214, i32 0, i32 5
  %t218 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t216)
  store i64 %t218, ptr %l141
  br label %bb51
bb51:
  %t219 = load i64, ptr %l141, !tbaa !24
  store i64 %t219, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t220 = load i64, ptr %l18, !tbaa !24
  %t221 = load i64, ptr %l17, !tbaa !24
  %t224 = icmp sgt i64 %t220, %t221
  br i1 %t224, label %bb52, label %bb53
bb52:
  %t226 = load i64, ptr %l19, !tbaa !24
  %t228 = icmp sgt i64 %t226, 0
  br i1 %t228, label %bb54, label %bb55
bb53:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb57
bb54:
  %t230 = load i64, ptr %l18, !tbaa !24
  %t231 = load i64, ptr %l17, !tbaa !24
  %t234 = sub i64 %t230, %t231
  %t235 = load i64, ptr %l19, !tbaa !24
  %t238 = add i64 %t234, %t235
  %t240 = sub i64 %t238, 1
  %t241 = load i64, ptr %l19, !tbaa !24
  %t244 = sdiv i64 %t240, %t241
  store i64 %t244, ptr %l148, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb56
bb56:
  %t246 = load i64, ptr %l148, !tbaa !24
  store i64 %t246, ptr %l145, !tbaa !24
  br label %bb57
bb57:
  %t247 = load i64, ptr %l145, !tbaa !24
  store i64 %t247, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb58
bb58:
  %t248 = load i64, ptr %l21, !tbaa !24
  %t249 = load i64, ptr %l20, !tbaa !24
  %t252 = icmp slt i64 %t248, %t249
  %t254 = xor i1 %t252, true
  br i1 %t254, label %bb59, label %bb60
bb59:
  br label %bb87
bb60:
  br label %bb61
bb61:
  %t256 = load i64, ptr %l17, !tbaa !24
  %t257 = load i64, ptr %l21, !tbaa !24
  %t258 = load i64, ptr %l19, !tbaa !24
  %t261 = mul i64 %t257, %t258
  %t264 = add i64 %t256, %t261
  store i64 %t264, ptr %l22, !tbaa !24
  %t266 = load i64, ptr %l22, !tbaa !24
  %t267 = load i64, ptr %l1, !tbaa !24
  %t270 = icmp eq i64 %t266, %t267
  br i1 %t270, label %bb62, label %bb63
bb62:
  br label %bb86
bb63:
  br label %bb64
bb64:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t272, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !29
  %t277 = getelementptr %"compiler/generic:Program", ptr %t275, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t280 = getelementptr %"compiler/names:Resolver", ptr %t278, i32 0, i32 1
  %t281 = load i64, ptr %l22, !tbaa !24
  %t284 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t280, i64 %t281)
  store ptr %t284, ptr %l174
  br label %bb65
bb65:
  %t285 = load ptr, ptr %l174, !tbaa !29
  %t287 = getelementptr %"compiler/names:Table", ptr %t285, i32 0, i32 0
  store ptr %t287, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb66
bb66:
  %t289 = load i64, ptr %l24, !tbaa !24
  store i64 %t289, ptr %l177, !tbaa !24
  %t290 = load ptr, ptr %l23, !tbaa !29
  %t292 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t290)
  store i64 %t292, ptr %l179
  br label %bb67
bb67:
  %t293 = load i64, ptr %l177, !tbaa !24
  %t294 = load i64, ptr %l179, !tbaa !24
  %t295 = icmp slt i64 %t293, %t294
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb68, label %bb69
bb68:
  br label %bb85
bb69:
  br label %bb70
bb70:
  %t299 = load ptr, ptr %l23, !tbaa !29
  %t300 = load i64, ptr %l24, !tbaa !24
  %t303 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t299, i64 %t300)
  store %"compiler/names:Entry" %t303, ptr %l184
  br label %bb71
bb71:
  %t304 = load %"compiler/names:Entry", ptr %l184
  store %"compiler/names:Entry" %t304, ptr %l25
  %t305 = getelementptr %"compiler/names:Entry", ptr %l25, i32 0, i32 0
  %t306 = load i32, ptr %t305, !tbaa !23
  %t307 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t307, ptr %l186, !tbaa !27
  %t308 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr i32, ptr %t309, i64 0
  %t311 = load i32, ptr %t310, !tbaa !33
  %t314 = icmp eq i32 %t306, %t311
  br i1 %t314, label %bb72, label %bb73
bb72:
  %t316 = getelementptr %"compiler/names:Entry", ptr %l25, i32 0, i32 2
  %t317 = load i32, ptr %t316, !range !{i32 0, i32 9}
  %t319 = trunc i64 3 to i32
  %t320 = icmp eq i32 %t317, %t319
  br i1 %t320, label %bb74, label %bb75
bb73:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb77
bb74:
  store i1 true, ptr %l192, !tbaa !21
  br label %bb76
bb75:
  %t322 = getelementptr %"compiler/names:Entry", ptr %l25, i32 0, i32 2
  %t323 = load i32, ptr %t322, !range !{i32 0, i32 9}
  %t325 = trunc i64 4 to i32
  %t326 = icmp eq i32 %t323, %t325
  store i1 %t326, ptr %l192, !tbaa !21
  br label %bb76
bb76:
  %t328 = load i1, ptr %l192, !tbaa !21
  store i1 %t328, ptr %l189, !tbaa !21
  br label %bb77
bb77:
  %t329 = load i1, ptr %l189, !tbaa !21
  br i1 %t329, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s23
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l195, !tbaa !29
  %t331 = load ptr, ptr %l3, !tbaa !29
  %t333 = getelementptr %"compiler/ast:Path", ptr %t331, i32 0, i32 0
  %t334 = load %"compiler/source:Span", ptr %t333
  store %"compiler/source:Span" %t334, ptr %l197
  %t335 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t337 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTestTargetElsewhere(ptr %s0, ptr %s23, { i64, ptr } %t335)
  store %"compiler/msgs:Msg" %t337, ptr %l199
  br label %bb80
bb79:
  br label %bb83
bb80:
  %t338 = load ptr, ptr %l195, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l197
  %t340 = load %"compiler/msgs:Msg", ptr %l199
  %t341 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s23, ptr %t338, %"compiler/source:Span" %t339, %"compiler/msgs:Msg" %t340)
  store i64 %t341, ptr %l200
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s23)
  %t342 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t342)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb83:
  br label %bb84
bb84:
  %t344 = load i64, ptr %l24, !tbaa !24
  %t346 = add i64 %t344, 1
  store i64 %t346, ptr %l24, !tbaa !24
  br label %bb66
bb85:
  br label %bb86
bb86:
  %t348 = load i64, ptr %l21, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l21, !tbaa !24
  br label %bb58
bb87:
  br label %bb163
bb88:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/check:Checker", ptr %t352, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t355)
  br label %bb90
bb89:
  br label %bb162
bb90:
  store i1 false, ptr %l26, !tbaa !21
  store i64 0, ptr %l27, !tbaa !24
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/check:Checker", ptr %t357, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t360)
  store i64 %t362, ptr %l213
  br label %bb91
bb91:
  %t363 = load i64, ptr %l213, !tbaa !24
  store i64 %t363, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t364 = load i64, ptr %l28, !tbaa !24
  %t365 = load i64, ptr %l27, !tbaa !24
  %t368 = icmp sgt i64 %t364, %t365
  br i1 %t368, label %bb92, label %bb93
bb92:
  %t370 = load i64, ptr %l29, !tbaa !24
  %t372 = icmp sgt i64 %t370, 0
  br i1 %t372, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l217, !tbaa !24
  br label %bb97
bb94:
  %t374 = load i64, ptr %l28, !tbaa !24
  %t375 = load i64, ptr %l27, !tbaa !24
  %t378 = sub i64 %t374, %t375
  %t379 = load i64, ptr %l29, !tbaa !24
  %t382 = add i64 %t378, %t379
  %t384 = sub i64 %t382, 1
  %t385 = load i64, ptr %l29, !tbaa !24
  %t388 = sdiv i64 %t384, %t385
  store i64 %t388, ptr %l220, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l220, !tbaa !24
  br label %bb96
bb96:
  %t390 = load i64, ptr %l220, !tbaa !24
  store i64 %t390, ptr %l217, !tbaa !24
  br label %bb97
bb97:
  %t391 = load i64, ptr %l217, !tbaa !24
  store i64 %t391, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s31
  %t392 = load i64, ptr %l31, !tbaa !24
  %t393 = load i64, ptr %l30, !tbaa !24
  %t396 = icmp slt i64 %t392, %t393
  %t398 = xor i1 %t396, true
  br i1 %t398, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s31)
  br label %bb141
bb100:
  br label %bb101
bb101:
  %t400 = load i64, ptr %l27, !tbaa !24
  %t401 = load i64, ptr %l31, !tbaa !24
  %t402 = load i64, ptr %l29, !tbaa !24
  %t405 = mul i64 %t401, %t402
  %t408 = add i64 %t400, %t405
  store i64 %t408, ptr %l32, !tbaa !24
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/check:Checker", ptr %t410, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t414 = load i64, ptr %l32, !tbaa !24
  %t417 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t413, i64 %t414)
  store ptr %t417, ptr %l241
  br label %bb102
bb102:
  %t418 = load ptr, ptr %l241, !tbaa !29
  store ptr %t418, ptr %l33, !tbaa !29
  %t419 = load ptr, ptr %l33, !tbaa !29
  %t421 = getelementptr %"compiler/ast:Func", ptr %t419, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !29
  %t424 = icmp eq ptr %t422, null
  br i1 %t424, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l245, !tbaa !21
  br label %bb105
bb104:
  %t426 = load ptr, ptr %l33, !tbaa !29
  %t428 = getelementptr %"compiler/ast:Func", ptr %t426, i32 0, i32 2
  %t429 = load i32, ptr %t428, !tbaa !23
  %t430 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t430, ptr %l248, !tbaa !27
  %t431 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = getelementptr i32, ptr %t432, i64 1
  %t434 = load i32, ptr %t433, !tbaa !33
  %t437 = icmp ne i32 %t429, %t434
  store i1 %t437, ptr %l245, !tbaa !21
  br label %bb105
bb105:
  %t439 = load i1, ptr %l245, !tbaa !21
  br i1 %t439, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s31)
  br label %bb140
bb107:
  br label %bb108
bb108:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = getelementptr %"compiler/check:Checker", ptr %t440, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !29
  %t445 = getelementptr %"compiler/generic:Program", ptr %t443, i32 0, i32 2
  store ptr %t445, ptr %l253, !tbaa !29
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/check:Checker", ptr %t446, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t451 = getelementptr %"compiler/generic:Program", ptr %t449, i32 0, i32 2
  store ptr %t451, ptr %l256, !tbaa !29
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t454 = getelementptr %"compiler/check:Checker", ptr %t452, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t456 = load i64, ptr %l32, !tbaa !24
  %t459 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t455, i64 %t456)
  store i32 %t459, ptr %l260
  br label %bb109
bb109:
  %t460 = load ptr, ptr %l256, !tbaa !29
  %t461 = load i32, ptr %l260, !tbaa !23
  %t462 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t460, i32 %t461)
  store i32 %t462, ptr %l261
  br label %bb110
bb110:
  %t463 = load ptr, ptr %l253, !tbaa !29
  %t464 = load i32, ptr %l261, !tbaa !23
  %t465 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t463, i32 %t464)
  store { i64, ptr } %t465, ptr %l262
  br label %bb111
bb111:
  %t466 = load { i64, ptr }, ptr %l262, !tbaa !27
  store { i64, ptr } %t466, ptr %l34, !tbaa !27
  %t467 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t467, 0
  %t471 = icmp eq i64 %t469, 0
  br i1 %t471, label %bb112, label %bb113
bb112:
  call void @__olang_scope_close(ptr %s31)
  br label %bb140
bb113:
  br label %bb114
bb114:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t474, ptr %l267, !tbaa !27
  %t475 = getelementptr { i64, ptr }, ptr %l267, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !27
  %t477 = getelementptr i32, ptr %t476, i64 0
  %t478 = load i32, ptr %t477, !tbaa !33
  %t481 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t473, i32 %t478)
  store i32 %t481, ptr %l269
  br label %bb115
bb115:
  %t482 = load i32, ptr %l269, !tbaa !23
  store i32 %t482, ptr %l35, !tbaa !23
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load i32, ptr %l35, !tbaa !23
  %t487 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t483, i32 %t484)
  store i1 %t487, ptr %l272
  br label %bb116
bb116:
  %t488 = load i1, ptr %l272, !tbaa !21
  br i1 %t488, label %bb117, label %bb118
bb117:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/check:Checker", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = getelementptr %"compiler/generic:Program", ptr %t492, i32 0, i32 2
  store ptr %t494, ptr %l276, !tbaa !29
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/check:Checker", ptr %t495, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !29
  %t500 = getelementptr %"compiler/generic:Program", ptr %t498, i32 0, i32 2
  %t501 = load i32, ptr %l35, !tbaa !23
  %t504 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t500, i32 %t501)
  store i32 %t504, ptr %l281
  br label %bb119
bb118:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb121
bb119:
  %t505 = load ptr, ptr %l276, !tbaa !29
  %t506 = load i32, ptr %l281, !tbaa !23
  %t507 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t505, i32 %t506)
  store i32 %t507, ptr %l282
  br label %bb120
bb120:
  %t508 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t508, ptr %l283, !tbaa !27
  %t509 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t510 = load ptr, ptr %t509, !tbaa !27
  %t511 = getelementptr i32, ptr %t510, i64 0
  %t512 = load i32, ptr %t511, !tbaa !33
  %t513 = load i32, ptr %l282, !tbaa !23
  %t515 = icmp eq i32 %t513, %t512
  store i1 %t515, ptr %l273, !tbaa !21
  br label %bb121
bb121:
  %t517 = load i1, ptr %l273, !tbaa !21
  %t520 = xor i1 %t517, true
  br i1 %t520, label %bb122, label %bb123
bb122:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load i32, ptr %l35, !tbaa !23
  %t526 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t522, i32 %t523)
  store i1 %t526, ptr %l291
  br label %bb124
bb123:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb131
bb124:
  %t527 = load i1, ptr %l291, !tbaa !21
  br i1 %t527, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l292, !tbaa !21
  br label %bb130
bb126:
  %t528 = load ptr, ptr %l33, !tbaa !29
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = getelementptr %"compiler/check:Checker", ptr %t529, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !29
  %t534 = getelementptr %"compiler/generic:Program", ptr %t532, i32 0, i32 0
  %t535 = load ptr, ptr %t534, !tbaa !29
  %t537 = getelementptr %"compiler/load:Loader", ptr %t535, i32 0, i32 3
  %t538 = load ptr, ptr %t537, !tbaa !29
  %t541 = call { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v0, ptr %s31, ptr %t528, ptr %t538)
  store { i64, ptr } %t541, ptr %l298
  br label %bb127
bb127:
  %t542 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t543 = extractvalue { i64, ptr } %t542, 0
  %t544 = extractvalue { i64, ptr } %t542, 1
  %t545 = mul i64 %t543, 1
  %t546 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t545)
  call void @llvm.memcpy.p0.p0.i64(ptr %t546, ptr %t544, i64 %t545, i1 false)
  %t547 = insertvalue { i64, ptr } undef, i64 %t543, 0
  %t548 = insertvalue { i64, ptr } %t547, ptr %t546, 1
  store { i64, ptr } %t548, ptr %l299, !tbaa !27
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t550 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t550, ptr %l301, !tbaa !27
  %t551 = getelementptr { i64, ptr }, ptr %l301, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !27
  %t553 = getelementptr i32, ptr %t552, i64 0
  %t554 = load i32, ptr %t553, !tbaa !33
  %t557 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t549, i32 %t554)
  store { i64, ptr } %t557, ptr %l303
  br label %bb128
bb128:
  %t558 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t559 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t560 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %v0, { i64, ptr } %t558, { i64, ptr } %t559)
  store i1 %t560, ptr %l304
  br label %bb129
bb129:
  %t561 = load i1, ptr %l304, !tbaa !21
  %t562 = xor i1 %t561, true
  store i1 %t562, ptr %l292, !tbaa !21
  br label %bb130
bb130:
  %t564 = load i1, ptr %l292, !tbaa !21
  store i1 %t564, ptr %l288, !tbaa !21
  br label %bb131
bb131:
  %t565 = load i1, ptr %l288, !tbaa !21
  br i1 %t565, label %bb132, label %bb133
bb132:
  call void @__olang_scope_close(ptr %s31)
  br label %bb140
bb133:
  br label %bb134
bb134:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = getelementptr %"compiler/check:Checker", ptr %t566, i32 0, i32 1
  %t569 = load ptr, ptr %t568, !tbaa !29
  %t570 = load i64, ptr %l32, !tbaa !24
  %t573 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t569, i64 %t570)
  store i64 %t573, ptr %l309
  br label %bb135
bb135:
  %t574 = load i64, ptr %l1, !tbaa !24
  %t575 = load i64, ptr %l309, !tbaa !24
  %t577 = icmp eq i64 %t575, %t574
  br i1 %t577, label %bb136, label %bb137
bb136:
  call void @__olang_scope_close(ptr %s31)
  %t579 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t579)
  br label %bb138
bb137:
  br label %bb139
bb138:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb139:
  store i1 true, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s31)
  br label %bb140
bb140:
  %t581 = load i64, ptr %l31, !tbaa !24
  %t583 = add i64 %t581, 1
  store i64 %t583, ptr %l31, !tbaa !24
  br label %bb98
bb141:
  %t585 = load ptr, ptr %l13, !tbaa !29
  %t587 = getelementptr %"compiler/names:Table", ptr %t585, i32 0, i32 0
  store ptr %t587, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb142
bb142:
  %t589 = load i64, ptr %l38, !tbaa !24
  store i64 %t589, ptr %l317, !tbaa !24
  %t590 = load ptr, ptr %l37, !tbaa !29
  %t592 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t590)
  store i64 %t592, ptr %l319
  br label %bb143
bb143:
  %t593 = load i64, ptr %l317, !tbaa !24
  %t594 = load i64, ptr %l319, !tbaa !24
  %t595 = icmp slt i64 %t593, %t594
  %t597 = xor i1 %t595, true
  br i1 %t597, label %bb144, label %bb145
bb144:
  br label %bb155
bb145:
  br label %bb146
bb146:
  %t599 = load ptr, ptr %l37, !tbaa !29
  %t600 = load i64, ptr %l38, !tbaa !24
  %t603 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t599, i64 %t600)
  store %"compiler/names:Entry" %t603, ptr %l324
  br label %bb147
bb147:
  %t604 = load %"compiler/names:Entry", ptr %l324
  store %"compiler/names:Entry" %t604, ptr %l39
  %t605 = getelementptr %"compiler/names:Entry", ptr %l39, i32 0, i32 0
  %t606 = load i32, ptr %t605, !tbaa !23
  %t607 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t607, ptr %l326, !tbaa !27
  %t608 = getelementptr { i64, ptr }, ptr %l326, i32 0, i32 1
  %t609 = load ptr, ptr %t608, !tbaa !27
  %t610 = getelementptr i32, ptr %t609, i64 0
  %t611 = load i32, ptr %t610, !tbaa !33
  %t614 = icmp eq i32 %t606, %t611
  br i1 %t614, label %bb148, label %bb149
bb148:
  %t616 = getelementptr %"compiler/names:Entry", ptr %l39, i32 0, i32 2
  %t617 = load i32, ptr %t616, !range !{i32 0, i32 9}
  %t619 = trunc i64 5 to i32
  %t620 = icmp eq i32 %t617, %t619
  store i1 %t620, ptr %l329, !tbaa !21
  br label %bb150
bb149:
  store i1 false, ptr %l329, !tbaa !21
  br label %bb150
bb150:
  %t622 = load i1, ptr %l329, !tbaa !21
  br i1 %t622, label %bb151, label %bb152
bb151:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb153
bb152:
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t623 = load i64, ptr %l38, !tbaa !24
  %t625 = add i64 %t623, 1
  store i64 %t625, ptr %l38, !tbaa !24
  br label %bb142
bb155:
  %t627 = load i1, ptr %l26, !tbaa !21
  br i1 %t627, label %bb156, label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s43
  %t629 = load ptr, ptr %l0, !tbaa !29
  store ptr %t629, ptr %l335, !tbaa !29
  %t630 = load ptr, ptr %l3, !tbaa !29
  %t632 = getelementptr %"compiler/ast:Path", ptr %t630, i32 0, i32 0
  %t633 = load %"compiler/source:Span", ptr %t632
  store %"compiler/source:Span" %t633, ptr %l337
  %t634 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t636 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTestTargetElsewhere(ptr %s0, ptr %s43, { i64, ptr } %t634)
  store %"compiler/msgs:Msg" %t636, ptr %l339
  br label %bb158
bb157:
  br label %bb161
bb158:
  %t637 = load ptr, ptr %l335, !tbaa !29
  %t638 = load %"compiler/source:Span", ptr %l337
  %t639 = load %"compiler/msgs:Msg", ptr %l339
  %t640 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s43, ptr %t637, %"compiler/source:Span" %t638, %"compiler/msgs:Msg" %t639)
  store i64 %t640, ptr %l340
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s43)
  %t641 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t641)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb161:
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t643 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t645 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %s0, ptr %s0, { i64, ptr } %t643)
  store %"compiler/msgs:Nearest" %t645, ptr %l343
  br label %bb164
bb164:
  %t646 = load %"compiler/msgs:Nearest", ptr %l343
  %t647 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t646, ptr %t647
  store ptr %t647, ptr %l40, !tbaa !29
  %t649 = load ptr, ptr %l13, !tbaa !29
  %t651 = getelementptr %"compiler/names:Table", ptr %t649, i32 0, i32 0
  store ptr %t651, ptr %l41, !tbaa !29
  store i64 0, ptr %l42, !tbaa !24
  br label %bb165
bb165:
  %t653 = load i64, ptr %l42, !tbaa !24
  store i64 %t653, ptr %l347, !tbaa !24
  %t654 = load ptr, ptr %l41, !tbaa !29
  %t656 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t654)
  store i64 %t656, ptr %l349
  br label %bb166
bb166:
  %t657 = load i64, ptr %l347, !tbaa !24
  %t658 = load i64, ptr %l349, !tbaa !24
  %t659 = icmp slt i64 %t657, %t658
  %t661 = xor i1 %t659, true
  br i1 %t661, label %bb167, label %bb168
bb167:
  br label %bb180
bb168:
  br label %bb169
bb169:
  %t663 = load ptr, ptr %l41, !tbaa !29
  %t664 = load i64, ptr %l42, !tbaa !24
  %t667 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t663, i64 %t664)
  store %"compiler/names:Entry" %t667, ptr %l354
  br label %bb170
bb170:
  %t668 = load %"compiler/names:Entry", ptr %l354
  store %"compiler/names:Entry" %t668, ptr %l43
  %t669 = getelementptr %"compiler/names:Entry", ptr %l43, i32 0, i32 2
  %t670 = load i32, ptr %t669, !range !{i32 0, i32 9}
  %t672 = trunc i64 3 to i32
  %t673 = icmp eq i32 %t670, %t672
  br i1 %t673, label %bb171, label %bb172
bb171:
  store i1 true, ptr %l357, !tbaa !21
  br label %bb173
bb172:
  %t675 = getelementptr %"compiler/names:Entry", ptr %l43, i32 0, i32 2
  %t676 = load i32, ptr %t675, !range !{i32 0, i32 9}
  %t678 = trunc i64 4 to i32
  %t679 = icmp eq i32 %t676, %t678
  store i1 %t679, ptr %l357, !tbaa !21
  br label %bb173
bb173:
  %t681 = load i1, ptr %l357, !tbaa !21
  br i1 %t681, label %bb174, label %bb175
bb174:
  %t682 = load ptr, ptr %l40, !tbaa !29
  store ptr %t682, ptr %l360, !tbaa !29
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t684 = getelementptr %"compiler/names:Entry", ptr %l43, i32 0, i32 0
  %t685 = load i32, ptr %t684, !tbaa !23
  %t688 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t683, i32 %t685)
  store { i64, ptr } %t688, ptr %l363
  br label %bb176
bb175:
  br label %bb178
bb176:
  %t689 = load ptr, ptr %l360, !tbaa !29
  %t690 = load { i64, ptr }, ptr %l363, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t689, { i64, ptr } %t690)
  br label %bb177
bb177:
  br label %bb178
bb178:
  br label %bb179
bb179:
  %t691 = load i64, ptr %l42, !tbaa !24
  %t693 = add i64 %t691, 1
  store i64 %t693, ptr %l42, !tbaa !24
  br label %bb165
bb180:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t697 = getelementptr %"compiler/check:Checker", ptr %t695, i32 0, i32 1
  %t698 = load ptr, ptr %t697, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t698)
  br label %bb181
bb181:
  store i64 0, ptr %l44, !tbaa !24
  %t700 = load ptr, ptr %l0, !tbaa !29
  %t702 = getelementptr %"compiler/check:Checker", ptr %t700, i32 0, i32 1
  %t703 = load ptr, ptr %t702, !tbaa !29
  %t705 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t703)
  store i64 %t705, ptr %l370
  br label %bb182
bb182:
  %t706 = load i64, ptr %l370, !tbaa !24
  store i64 %t706, ptr %l45, !tbaa !24
  store i64 1, ptr %l46, !tbaa !24
  %t707 = load i64, ptr %l45, !tbaa !24
  %t708 = load i64, ptr %l44, !tbaa !24
  %t711 = icmp sgt i64 %t707, %t708
  br i1 %t711, label %bb183, label %bb184
bb183:
  %t713 = load i64, ptr %l46, !tbaa !24
  %t715 = icmp sgt i64 %t713, 0
  br i1 %t715, label %bb185, label %bb186
bb184:
  store i64 0, ptr %l374, !tbaa !24
  br label %bb188
bb185:
  %t717 = load i64, ptr %l45, !tbaa !24
  %t718 = load i64, ptr %l44, !tbaa !24
  %t721 = sub i64 %t717, %t718
  %t722 = load i64, ptr %l46, !tbaa !24
  %t725 = add i64 %t721, %t722
  %t727 = sub i64 %t725, 1
  %t728 = load i64, ptr %l46, !tbaa !24
  %t731 = sdiv i64 %t727, %t728
  store i64 %t731, ptr %l377, !tbaa !24
  br label %bb187
bb186:
  store i64 0, ptr %l377, !tbaa !24
  br label %bb187
bb187:
  %t733 = load i64, ptr %l377, !tbaa !24
  store i64 %t733, ptr %l374, !tbaa !24
  br label %bb188
bb188:
  %t734 = load i64, ptr %l374, !tbaa !24
  store i64 %t734, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  br label %bb189
bb189:
  %t735 = load i64, ptr %l48, !tbaa !24
  %t736 = load i64, ptr %l47, !tbaa !24
  %t739 = icmp slt i64 %t735, %t736
  %t741 = xor i1 %t739, true
  br i1 %t741, label %bb190, label %bb191
bb190:
  br label %bb227
bb191:
  br label %bb192
bb192:
  %t743 = load i64, ptr %l44, !tbaa !24
  %t744 = load i64, ptr %l48, !tbaa !24
  %t745 = load i64, ptr %l46, !tbaa !24
  %t748 = mul i64 %t744, %t745
  %t751 = add i64 %t743, %t748
  store i64 %t751, ptr %l49, !tbaa !24
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t755 = getelementptr %"compiler/check:Checker", ptr %t753, i32 0, i32 1
  %t756 = load ptr, ptr %t755, !tbaa !29
  %t757 = load i64, ptr %l49, !tbaa !24
  %t760 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t756, i64 %t757)
  store ptr %t760, ptr %l398
  br label %bb193
bb193:
  %t761 = load ptr, ptr %l398, !tbaa !29
  store ptr %t761, ptr %l50, !tbaa !29
  %t762 = load ptr, ptr %l50, !tbaa !29
  %t764 = getelementptr %"compiler/ast:Func", ptr %t762, i32 0, i32 1
  %t765 = load ptr, ptr %t764, !tbaa !29
  %t767 = icmp eq ptr %t765, null
  br i1 %t767, label %bb194, label %bb195
bb194:
  store i1 true, ptr %l402, !tbaa !21
  br label %bb197
bb195:
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t771 = getelementptr %"compiler/check:Checker", ptr %t769, i32 0, i32 1
  %t772 = load ptr, ptr %t771, !tbaa !29
  %t773 = load i64, ptr %l49, !tbaa !24
  %t776 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t772, i64 %t773)
  store i64 %t776, ptr %l406
  br label %bb196
bb196:
  %t777 = load i64, ptr %l1, !tbaa !24
  %t778 = load i64, ptr %l406, !tbaa !24
  %t780 = icmp ne i64 %t778, %t777
  store i1 %t780, ptr %l402, !tbaa !21
  br label %bb197
bb197:
  %t782 = load i1, ptr %l402, !tbaa !21
  br i1 %t782, label %bb198, label %bb199
bb198:
  br label %bb226
bb199:
  br label %bb200
bb200:
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t785 = getelementptr %"compiler/check:Checker", ptr %t783, i32 0, i32 1
  %t786 = load ptr, ptr %t785, !tbaa !29
  %t788 = getelementptr %"compiler/generic:Program", ptr %t786, i32 0, i32 2
  store ptr %t788, ptr %l411, !tbaa !29
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t791 = getelementptr %"compiler/check:Checker", ptr %t789, i32 0, i32 1
  %t792 = load ptr, ptr %t791, !tbaa !29
  %t794 = getelementptr %"compiler/generic:Program", ptr %t792, i32 0, i32 2
  store ptr %t794, ptr %l414, !tbaa !29
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t797 = getelementptr %"compiler/check:Checker", ptr %t795, i32 0, i32 1
  %t798 = load ptr, ptr %t797, !tbaa !29
  %t799 = load i64, ptr %l49, !tbaa !24
  %t802 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t798, i64 %t799)
  store i32 %t802, ptr %l418
  br label %bb201
bb201:
  %t803 = load ptr, ptr %l414, !tbaa !29
  %t804 = load i32, ptr %l418, !tbaa !23
  %t805 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t803, i32 %t804)
  store i32 %t805, ptr %l419
  br label %bb202
bb202:
  %t806 = load ptr, ptr %l411, !tbaa !29
  %t807 = load i32, ptr %l419, !tbaa !23
  %t808 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t806, i32 %t807)
  store { i64, ptr } %t808, ptr %l420
  br label %bb203
bb203:
  %t809 = load { i64, ptr }, ptr %l420, !tbaa !27
  store { i64, ptr } %t809, ptr %l51, !tbaa !27
  %t810 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t812 = extractvalue { i64, ptr } %t810, 0
  %t814 = icmp eq i64 %t812, 0
  br i1 %t814, label %bb204, label %bb205
bb204:
  br label %bb226
bb205:
  br label %bb206
bb206:
  %t816 = load ptr, ptr %l0, !tbaa !29
  store ptr %t816, ptr %l424, !tbaa !29
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t818 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t818, ptr %l426, !tbaa !27
  %t819 = getelementptr { i64, ptr }, ptr %l426, i32 0, i32 1
  %t820 = load ptr, ptr %t819, !tbaa !27
  %t821 = getelementptr i32, ptr %t820, i64 0
  %t822 = load i32, ptr %t821, !tbaa !33
  %t825 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t817, i32 %t822)
  store i32 %t825, ptr %l428
  br label %bb207
bb207:
  %t826 = load ptr, ptr %l424, !tbaa !29
  %t827 = load i32, ptr %l428, !tbaa !23
  %t828 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t826, i32 %t827)
  store i1 %t828, ptr %l429
  br label %bb208
bb208:
  %t829 = load i1, ptr %l429, !tbaa !21
  br i1 %t829, label %bb209, label %bb210
bb209:
  store %olang.scope zeroinitializer, ptr %s54
  %t830 = load ptr, ptr %l40, !tbaa !29
  store ptr %t830, ptr %l430, !tbaa !29
  %t831 = load ptr, ptr %l0, !tbaa !29
  store ptr %t831, ptr %l431, !tbaa !29
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t834 = getelementptr %"compiler/check:Checker", ptr %t832, i32 0, i32 1
  %t835 = load ptr, ptr %t834, !tbaa !29
  %t837 = getelementptr %"compiler/generic:Program", ptr %t835, i32 0, i32 2
  store ptr %t837, ptr %l434, !tbaa !29
  %t838 = load ptr, ptr %l0, !tbaa !29
  %t840 = getelementptr %"compiler/check:Checker", ptr %t838, i32 0, i32 1
  %t841 = load ptr, ptr %t840, !tbaa !29
  %t843 = getelementptr %"compiler/generic:Program", ptr %t841, i32 0, i32 2
  store ptr %t843, ptr %l437, !tbaa !29
  %t844 = load ptr, ptr %l0, !tbaa !29
  %t845 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t845, ptr %l439, !tbaa !27
  %t846 = getelementptr { i64, ptr }, ptr %l439, i32 0, i32 1
  %t847 = load ptr, ptr %t846, !tbaa !27
  %t848 = getelementptr i32, ptr %t847, i64 0
  %t849 = load i32, ptr %t848, !tbaa !33
  %t852 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t844, i32 %t849)
  store i32 %t852, ptr %l441
  br label %bb211
bb210:
  store %olang.scope zeroinitializer, ptr %s56
  %t853 = load ptr, ptr %l50, !tbaa !29
  %t854 = load ptr, ptr %l0, !tbaa !29
  %t856 = getelementptr %"compiler/check:Checker", ptr %t854, i32 0, i32 1
  %t857 = load ptr, ptr %t856, !tbaa !29
  %t859 = getelementptr %"compiler/generic:Program", ptr %t857, i32 0, i32 0
  %t860 = load ptr, ptr %t859, !tbaa !29
  %t862 = getelementptr %"compiler/load:Loader", ptr %t860, i32 0, i32 3
  %t863 = load ptr, ptr %t862, !tbaa !29
  %t866 = call { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v0, ptr %s56, ptr %t853, ptr %t863)
  store { i64, ptr } %t866, ptr %l456
  br label %bb217
bb211:
  %t867 = load ptr, ptr %l437, !tbaa !29
  %t868 = load i32, ptr %l441, !tbaa !23
  %t869 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t867, i32 %t868)
  store i32 %t869, ptr %l442
  br label %bb212
bb212:
  %t870 = load ptr, ptr %l434, !tbaa !29
  %t871 = load i32, ptr %l442, !tbaa !23
  %t872 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t870, i32 %t871)
  store i32 %t872, ptr %l443
  br label %bb213
bb213:
  %t873 = load ptr, ptr %l431, !tbaa !29
  %t874 = load i32, ptr %l443, !tbaa !23
  %t875 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t873, i32 %t874)
  store { i64, ptr } %t875, ptr %l444
  br label %bb214
bb214:
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t877 = load ptr, ptr %l50, !tbaa !29
  %t879 = getelementptr %"compiler/ast:Func", ptr %t877, i32 0, i32 2
  %t880 = load i32, ptr %t879, !tbaa !23
  %t883 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t876, i32 %t880)
  store { i64, ptr } %t883, ptr %l448
  br label %bb215
bb215:
  %t884 = load { i64, ptr }, ptr %l444, !tbaa !27
  %t885 = extractvalue { i64, ptr } %t884, 1
  %t886 = extractvalue { i64, ptr } %t884, 0
  %t887 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t888 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t889 = add i64 %t886, %t888
  %t890 = load { i64, ptr }, ptr %l448, !tbaa !27
  %t891 = extractvalue { i64, ptr } %t890, 1
  %t892 = extractvalue { i64, ptr } %t890, 0
  %t893 = add i64 %t889, %t892
  %t894 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t893)
  call void @olang_textcopy(ptr %t894, ptr %t885, i64 %t886)
  %t895 = getelementptr i8, ptr %t894, i64 %t886
  call void @olang_textcopy(ptr %t895, ptr %t887, i64 %t888)
  %t896 = getelementptr i8, ptr %t895, i64 %t888
  call void @olang_textcopy(ptr %t896, ptr %t891, i64 %t892)
  %t897 = insertvalue { i64, ptr } undef, i64 %t893, 0
  %t898 = insertvalue { i64, ptr } %t897, ptr %t894, 1
  %t900 = extractvalue { i64, ptr } %t898, 0
  %t901 = extractvalue { i64, ptr } %t898, 1
  %t902 = mul i64 %t900, 1
  %t903 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t902)
  call void @llvm.memcpy.p0.p0.i64(ptr %t903, ptr %t901, i64 %t902, i1 false)
  %t904 = insertvalue { i64, ptr } undef, i64 %t900, 0
  %t905 = insertvalue { i64, ptr } %t904, ptr %t903, 1
  %t906 = load ptr, ptr %l430, !tbaa !29
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %s54, ptr %t906, { i64, ptr } %t905)
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s54)
  br label %bb225
bb217:
  %t908 = load { i64, ptr }, ptr %l456, !tbaa !27
  %t909 = extractvalue { i64, ptr } %t908, 0
  %t910 = extractvalue { i64, ptr } %t908, 1
  %t911 = mul i64 %t909, 1
  %t912 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t911)
  call void @llvm.memcpy.p0.p0.i64(ptr %t912, ptr %t910, i64 %t911, i1 false)
  %t913 = insertvalue { i64, ptr } undef, i64 %t909, 0
  %t914 = insertvalue { i64, ptr } %t913, ptr %t912, 1
  %t916 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s56, ptr %s56, { i64, ptr } %t914, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t916, ptr %l458
  br label %bb218
bb218:
  %t917 = load i1, ptr %l458, !tbaa !21
  %t918 = xor i1 %t917, true
  br i1 %t918, label %bb219, label %bb220
bb219:
  store %olang.scope zeroinitializer, ptr %s57
  %t920 = load ptr, ptr %l40, !tbaa !29
  store ptr %t920, ptr %l460, !tbaa !29
  %t921 = load ptr, ptr %l50, !tbaa !29
  %t922 = load ptr, ptr %l0, !tbaa !29
  %t924 = getelementptr %"compiler/check:Checker", ptr %t922, i32 0, i32 1
  %t925 = load ptr, ptr %t924, !tbaa !29
  %t927 = getelementptr %"compiler/generic:Program", ptr %t925, i32 0, i32 0
  %t928 = load ptr, ptr %t927, !tbaa !29
  %t930 = getelementptr %"compiler/load:Loader", ptr %t928, i32 0, i32 3
  %t931 = load ptr, ptr %t930, !tbaa !29
  %t934 = call { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v0, ptr %s57, ptr %t921, ptr %t931)
  store { i64, ptr } %t934, ptr %l466
  br label %bb221
bb220:
  br label %bb224
bb221:
  %t935 = load ptr, ptr %l0, !tbaa !29
  %t936 = load ptr, ptr %l50, !tbaa !29
  %t938 = getelementptr %"compiler/ast:Func", ptr %t936, i32 0, i32 2
  %t939 = load i32, ptr %t938, !tbaa !23
  %t942 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t935, i32 %t939)
  store { i64, ptr } %t942, ptr %l470
  br label %bb222
bb222:
  %t943 = load { i64, ptr }, ptr %l466, !tbaa !27
  %t944 = extractvalue { i64, ptr } %t943, 1
  %t945 = extractvalue { i64, ptr } %t943, 0
  %t946 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t947 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t948 = add i64 %t945, %t947
  %t949 = load { i64, ptr }, ptr %l470, !tbaa !27
  %t950 = extractvalue { i64, ptr } %t949, 1
  %t951 = extractvalue { i64, ptr } %t949, 0
  %t952 = add i64 %t948, %t951
  %t953 = call ptr @__olang_scope_alloc(ptr %s57, i64 %t952)
  call void @olang_textcopy(ptr %t953, ptr %t944, i64 %t945)
  %t954 = getelementptr i8, ptr %t953, i64 %t945
  call void @olang_textcopy(ptr %t954, ptr %t946, i64 %t947)
  %t955 = getelementptr i8, ptr %t954, i64 %t947
  call void @olang_textcopy(ptr %t955, ptr %t950, i64 %t951)
  %t956 = insertvalue { i64, ptr } undef, i64 %t952, 0
  %t957 = insertvalue { i64, ptr } %t956, ptr %t953, 1
  %t959 = extractvalue { i64, ptr } %t957, 0
  %t960 = extractvalue { i64, ptr } %t957, 1
  %t961 = mul i64 %t959, 1
  %t962 = call ptr @__olang_scope_alloc(ptr %s57, i64 %t961)
  call void @llvm.memcpy.p0.p0.i64(ptr %t962, ptr %t960, i64 %t961, i1 false)
  %t963 = insertvalue { i64, ptr } undef, i64 %t959, 0
  %t964 = insertvalue { i64, ptr } %t963, ptr %t962, 1
  %t965 = load ptr, ptr %l460, !tbaa !29
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %s57, ptr %t965, { i64, ptr } %t964)
  br label %bb223
bb223:
  call void @__olang_scope_close(ptr %s57)
  br label %bb224
bb224:
  call void @__olang_scope_close(ptr %s56)
  br label %bb225
bb225:
  br label %bb226
bb226:
  %t967 = load i64, ptr %l48, !tbaa !24
  %t969 = add i64 %t967, 1
  store i64 %t969, ptr %l48, !tbaa !24
  br label %bb189
bb227:
  %t971 = load ptr, ptr %l40, !tbaa !29
  %t973 = getelementptr %"compiler/msgs:Nearest", ptr %t971, i32 0, i32 1
  %t974 = load { i64, ptr }, ptr %t973, !tbaa !27
  %t976 = extractvalue { i64, ptr } %t974, 0
  %t978 = icmp sgt i64 %t976, 0
  br i1 %t978, label %bb228, label %bb229
bb228:
  store %olang.scope zeroinitializer, ptr %s60
  %t980 = load ptr, ptr %l0, !tbaa !29
  store ptr %t980, ptr %l479, !tbaa !29
  %t981 = load ptr, ptr %l3, !tbaa !29
  %t983 = getelementptr %"compiler/ast:Path", ptr %t981, i32 0, i32 0
  %t984 = load %"compiler/source:Span", ptr %t983
  store %"compiler/source:Span" %t984, ptr %l481
  %t985 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t986 = load ptr, ptr %l40, !tbaa !29
  %t988 = getelementptr %"compiler/msgs:Nearest", ptr %t986, i32 0, i32 1
  %t989 = load { i64, ptr }, ptr %t988, !tbaa !27
  %t992 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTestTargetUnknownMeant(ptr %s0, ptr %s0, ptr %s60, { i64, ptr } %t985, { i64, ptr } %t989)
  store %"compiler/msgs:Msg" %t992, ptr %l485
  br label %bb230
bb229:
  store %olang.scope zeroinitializer, ptr %s61
  %t993 = load ptr, ptr %l0, !tbaa !29
  store ptr %t993, ptr %l487, !tbaa !29
  %t994 = load ptr, ptr %l3, !tbaa !29
  %t996 = getelementptr %"compiler/ast:Path", ptr %t994, i32 0, i32 0
  %t997 = load %"compiler/source:Span", ptr %t996
  store %"compiler/source:Span" %t997, ptr %l489
  %t998 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t1000 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTestTargetUnknown(ptr %s0, ptr %s61, { i64, ptr } %t998)
  store %"compiler/msgs:Msg" %t1000, ptr %l491
  br label %bb232
bb230:
  %t1001 = load ptr, ptr %l479, !tbaa !29
  %t1002 = load %"compiler/source:Span", ptr %l481
  %t1003 = load %"compiler/msgs:Msg", ptr %l485
  %t1004 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s60, ptr %t1001, %"compiler/source:Span" %t1002, %"compiler/msgs:Msg" %t1003)
  store i64 %t1004, ptr %l486
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s60)
  br label %bb234
bb232:
  %t1005 = load ptr, ptr %l487, !tbaa !29
  %t1006 = load %"compiler/source:Span", ptr %l489
  %t1007 = load %"compiler/msgs:Msg", ptr %l491
  %t1008 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s61, ptr %t1005, %"compiler/source:Span" %t1006, %"compiler/msgs:Msg" %t1007)
  store i64 %t1008, ptr %l492
  br label %bb233
bb233:
  call void @__olang_scope_close(ptr %s61)
  br label %bb234
bb234:
  %t1009 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t1009)
  br label %bb235
bb235:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etoAny(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %lp12 = alloca ptr
  %l16 = alloca i32
  %l21 = alloca i32
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca i32
  %l48 = alloca i1
  %l57 = alloca i32
  %l60 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i1
  %l81 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca %"compiler/msgs:Msg"
  %l95 = alloca i64
  %l101 = alloca i1
  %l105 = alloca ptr
  %l110 = alloca i64
  %l115 = alloca ptr
  %l120 = alloca i64
  %l127 = alloca i1
  %l132 = alloca ptr
  %l136 = alloca i32
  %l142 = alloca i64
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca i32
  %l148 = alloca i32
  %l152 = alloca { i64, ptr }
  %l154 = alloca %"compiler/typed:Make"
  %l158 = alloca %"compiler/source:Span"
  %l166 = alloca i32
  %l167 = alloca ptr
  %l171 = alloca i32
  %l172 = alloca %"compiler/typed:Promote"
  %l175 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca i32
  %l178 = alloca i32
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca %"compiler/source:Span"
  %l183 = alloca i32
  %l185 = alloca ptr
  %l187 = alloca ptr
  %l188 = alloca ptr
  %l189 = alloca ptr
  %l195 = alloca i32
  %l197 = alloca ptr
  %l198 = alloca ptr
  %l199 = alloca %"compiler/source:Span"
  %l200 = alloca i32
  %l201 = alloca i32
  %l202 = alloca ptr
  %l203 = alloca ptr
  %l204 = alloca %"compiler/source:Span"
  %l206 = alloca i32
  %l208 = alloca ptr
  %l210 = alloca ptr
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t299 = alloca { i64, [5 x i64] }, align 8
  %t341 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l16
  br label %bb1
bb1:
  %t5 = load i32, ptr %l16, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l21
  br label %bb2
bb2:
  %t16 = load i32, ptr %l21, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l4, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l26
  br label %bb3
bb3:
  %t27 = load i1, ptr %l26, !tbaa !21
  br i1 %t27, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l27, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t29, ptr %l28
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l4, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t30, i32 %t31)
  store { i64, ptr } %t34, ptr %l31
  br label %bb6
bb5:
  br label %bb11
bb6:
  %t35 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l32, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t42, i32 %t43)
  store { i64, ptr } %t46, ptr %l35
  br label %bb7
bb7:
  %t47 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  %t54 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t56 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotConverted(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t54, { i64, ptr } %t53)
  store %"compiler/msgs:Msg" %t56, ptr %l37
  br label %bb8
bb8:
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l28
  %t59 = load %"compiler/msgs:Msg", ptr %l37
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t57, %"compiler/source:Span" %t58, %"compiler/msgs:Msg" %t59)
  store i64 %t60, ptr %l38
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l3
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t61, %"compiler/source:Span" %t62)
  store ptr %t65, ptr %l41
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  %t66 = load ptr, ptr %l41, !tbaa !29
  store ptr %t66, ptr %rv
  br label %ret
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l44
  br label %bb12
bb12:
  %t72 = load i32, ptr %l44, !tbaa !23
  store i32 %t72, ptr %l6, !tbaa !23
  %t73 = load i32, ptr %l6, !tbaa !23
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t77 = icmp eq i32 %t73, %t74
  br i1 %t77, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb15
bb14:
  %t79 = load i32, ptr %l5, !tbaa !23
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t83 = icmp eq i32 %t79, %t80
  store i1 %t83, ptr %l48, !tbaa !21
  br label %bb15
bb15:
  %t85 = load i1, ptr %l48, !tbaa !21
  br i1 %t85, label %bb16, label %bb17
bb16:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l6, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l57
  br label %bb19
bb19:
  %t98 = load i32, ptr %l57, !range !{i32 0, i32 33}
  %t100 = trunc i64 29 to i32
  %t101 = icmp eq i32 %t98, %t100
  br i1 %t101, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb23
bb21:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load i32, ptr %l6, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l65
  br label %bb22
bb22:
  %t113 = load i32, ptr %l65, !range !{i32 0, i32 33}
  %t115 = trunc i64 21 to i32
  %t116 = icmp eq i32 %t113, %t115
  store i1 %t116, ptr %l60, !tbaa !21
  br label %bb23
bb23:
  %t118 = load i1, ptr %l60, !tbaa !21
  br i1 %t118, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb26
bb25:
  %t119 = load i32, ptr %l6, !tbaa !23
  %t120 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t123 = icmp eq i32 %t119, %t120
  store i1 %t123, ptr %l68, !tbaa !21
  br label %bb26
bb26:
  %t125 = load i1, ptr %l68, !tbaa !21
  br i1 %t125, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb29
bb28:
  %t126 = load i32, ptr %l6, !tbaa !23
  %t127 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t130 = icmp eq i32 %t126, %t127
  store i1 %t130, ptr %l72, !tbaa !21
  br label %bb29
bb29:
  %t132 = load i1, ptr %l72, !tbaa !21
  br i1 %t132, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb33
bb31:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l6, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l81
  br label %bb32
bb32:
  %t143 = load i32, ptr %l81, !range !{i32 0, i32 33}
  %t145 = trunc i64 22 to i32
  %t146 = icmp eq i32 %t143, %t145
  store i1 %t146, ptr %l76, !tbaa !21
  br label %bb33
bb33:
  %t148 = load i1, ptr %l76, !tbaa !21
  br i1 %t148, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s3
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l84, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t150, ptr %l85
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i32, ptr %l2, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t151, i32 %t152)
  store { i64, ptr } %t155, ptr %l88
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t156 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  store { i64, ptr } %t162, ptr %l89, !tbaa !27
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v0, ptr %s3, ptr %t163, ptr %t164)
  store { i64, ptr } %t167, ptr %l92
  br label %bb37
bb37:
  %t168 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = extractvalue { i64, ptr } %t168, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t175 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t177 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t175, { i64, ptr } %t174)
  store %"compiler/msgs:Msg" %t177, ptr %l94
  br label %bb38
bb38:
  %t178 = load ptr, ptr %l84, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l85
  %t180 = load %"compiler/msgs:Msg", ptr %l94
  %t181 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t178, %"compiler/source:Span" %t179, %"compiler/msgs:Msg" %t180)
  store i64 %t181, ptr %l95
  br label %bb39
bb39:
  %t182 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  store ptr %t182, ptr %rv
  br label %ret
bb40:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i32, ptr %l6, !tbaa !23
  %t186 = load i32, ptr %l5, !tbaa !23
  %t187 = load %"compiler/source:Span", ptr %l3
  %t192 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyMeets(ptr %v0, ptr %t184, i32 %t185, i32 %t186, %"compiler/source:Span" %t187)
  store i1 %t192, ptr %l101
  br label %bb41
bb41:
  %t193 = load i1, ptr %l101, !tbaa !21
  %t194 = xor i1 %t193, true
  br i1 %t194, label %bb42, label %bb43
bb42:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l3
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t196, %"compiler/source:Span" %t197)
  store ptr %t200, ptr %l105
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t201 = load ptr, ptr %l105, !tbaa !29
  store ptr %t201, ptr %rv
  br label %ret
bb45:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l6, !tbaa !23
  %t204 = load i32, ptr %l5, !tbaa !23
  %t205 = load %"compiler/source:Span", ptr %l3
  %t210 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyTable(ptr %v0, ptr %t202, i32 %t203, i32 %t204, %"compiler/source:Span" %t205)
  store i64 %t210, ptr %l110
  br label %bb46
bb46:
  %t211 = load i64, ptr %l110, !tbaa !24
  store i64 %t211, ptr %l7, !tbaa !24
  %t212 = load i64, ptr %l7, !tbaa !24
  %t214 = icmp slt i64 %t212, 0
  br i1 %t214, label %bb47, label %bb48
bb47:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l3
  %t220 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t216, %"compiler/source:Span" %t217)
  store ptr %t220, ptr %l115
  br label %bb49
bb48:
  br label %bb50
bb49:
  %t221 = load ptr, ptr %l115, !tbaa !29
  store ptr %t221, ptr %rv
  br label %ret
bb50:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  %t228 = load i32, ptr %l2, !tbaa !23
  %t231 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t227, i32 %t228)
  store i64 %t231, ptr %l120
  br label %bb51
bb51:
  %t232 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t233 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t236 = or i64 %t232, %t233
  %t237 = load i64, ptr %l120, !tbaa !24
  %t239 = and i64 %t237, %t236
  store i64 %t239, ptr %l8, !tbaa !24
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l6, !tbaa !23
  %t245 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCopies(ptr %v0, ptr %t241, i32 %t242)
  store i1 %t245, ptr %l127
  br label %bb52
bb52:
  %t246 = load i1, ptr %l127, !tbaa !21
  br i1 %t246, label %bb53, label %bb54
bb53:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t249 = load i32, ptr %l6, !tbaa !23
  %t250 = load %"compiler/source:Span", ptr %l3
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t247, ptr %t248, i32 %t249, %"compiler/source:Span" %t250)
  store ptr %t255, ptr %l132
  br label %bb55
bb54:
  br label %bb70
bb55:
  %t256 = load ptr, ptr %l132, !tbaa !29
  store ptr %t256, ptr %l9, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t261 = load i32, ptr %l6, !tbaa !23
  %t264 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t264, ptr %l136
  br label %bb56
bb56:
  %t265 = load i32, ptr %l136, !tbaa !23
  store i32 %t265, ptr %l10, !tbaa !23
  %t266 = load i32, ptr %l10, !tbaa !23
  %t267 = load i32, ptr %l6, !tbaa !23
  %t270 = icmp ne i32 %t266, %t267
  br i1 %t270, label %bb57, label %bb58
bb57:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t272, i32 0, i32 36
  %t276 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t274)
  store i64 %t276, ptr %l142
  br label %bb59
bb58:
  br label %bb63
bb59:
  %t277 = load i64, ptr %l142, !tbaa !24
  store i64 %t277, ptr %l11, !tbaa !24
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 36
  %t281 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t280, ptr %t281)
  br label %bb60
bb60:
  %t284 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t284, ptr %l146
  %t285 = load i32, ptr %l10, !tbaa !23
  store i32 %t285, ptr %l147, !tbaa !23
  store i32 0, ptr %l148
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/check:Checker", ptr %t286, i32 0, i32 36
  %t289 = load i64, ptr %l11, !tbaa !24
  %t292 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t288, i64 %t289)
  store { i64, ptr } %t292, ptr %l152
  br label %bb61
bb61:
  %t293 = load i32, ptr %l148, !range !{i32 0, i32 4}
  %t294 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t296 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t293, i64 0, { i64, ptr } %t294, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t296, ptr %l154
  br label %bb62
bb62:
  %t297 = load %"compiler/typed:Make", ptr %l154
  %t298 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t297, ptr %t298
  store { i64, [5 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [5 x i64] }, ptr %t299, i32 0, i32 0
  store i64 7, ptr %t300
  %t301 = load %"compiler/source:Span", ptr %l146
  %t302 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t301, 0
  %t303 = load i32, ptr %l147, !tbaa !23
  %t304 = insertvalue { %"compiler/source:Span", i32, ptr } %t302, i32 %t303, 1
  %t306 = insertvalue { %"compiler/source:Span", i32, ptr } %t304, ptr %t298, 2
  %t307 = getelementptr { i64, [5 x i64] }, ptr %t299, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t306, ptr %t307
  %t308 = load { i64, [5 x i64] }, ptr %t299
  %t310 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t308, ptr %t310
  store ptr %t310, ptr %l9, !tbaa !29
  br label %bb63
bb63:
  %t312 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t312, ptr %l158
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/check:Checker", ptr %t313, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t318 = getelementptr %"compiler/generic:Program", ptr %t316, i32 0, i32 2
  %t319 = load i32, ptr %l10, !tbaa !23
  %t320 = load i64, ptr %l8, !tbaa !24
  %t321 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t324 = and i64 %t320, %t321
  %t328 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t318, i32 %t319, i64 %t324)
  store i32 %t328, ptr %l166
  br label %bb64
bb64:
  %t329 = load ptr, ptr %l9, !tbaa !29
  store ptr %t329, ptr %l167, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load %"compiler/source:Span", ptr %l3
  %t335 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t330, i32 2, %"compiler/source:Span" %t331)
  store i32 %t335, ptr %l171
  br label %bb65
bb65:
  %t336 = load ptr, ptr %l167, !tbaa !29
  %t337 = load i32, ptr %l171, !tbaa !23
  %t338 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v0, ptr %t336, i32 %t337)
  store %"compiler/typed:Promote" %t338, ptr %l172
  br label %bb66
bb66:
  %t339 = load %"compiler/typed:Promote", ptr %l172
  %t340 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Promote" %t339, ptr %t340
  store { i64, [5 x i64] } zeroinitializer, ptr %t341
  %t342 = getelementptr { i64, [5 x i64] }, ptr %t341, i32 0, i32 0
  store i64 5, ptr %t342
  %t343 = load %"compiler/source:Span", ptr %l158
  %t344 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t343, 0
  %t345 = load i32, ptr %l166, !tbaa !23
  %t346 = insertvalue { %"compiler/source:Span", i32, ptr } %t344, i32 %t345, 1
  %t348 = insertvalue { %"compiler/source:Span", i32, ptr } %t346, ptr %t340, 2
  %t349 = getelementptr { i64, [5 x i64] }, ptr %t341, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t348, ptr %t349
  %t350 = load { i64, [5 x i64] }, ptr %t341
  %t351 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t351, ptr %lp12
  %t353 = load ptr, ptr %lp12
  store { i64, [5 x i64] } %t350, ptr %t353
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l175, !tbaa !29
  %t355 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t355, ptr %l176
  %t356 = load i32, ptr %l2, !tbaa !23
  store i32 %t356, ptr %l177, !tbaa !23
  store i32 40, ptr %l178
  %t357 = load ptr, ptr %lp12
  store ptr %t357, ptr %l179, !tbaa !29
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l180, !tbaa !29
  %t359 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t359, ptr %l181
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t360)
  store i32 %t362, ptr %l183
  br label %bb67
bb67:
  %t363 = load i64, ptr %l7, !tbaa !24
  %t364 = load ptr, ptr %l180, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l181
  %t366 = load i32, ptr %l183, !tbaa !23
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t364, %"compiler/source:Span" %t365, i32 %t366, i64 %t363)
  store ptr %t368, ptr %l185
  br label %bb68
bb68:
  %t369 = load ptr, ptr %l185, !tbaa !29
  %t370 = load ptr, ptr %l175, !tbaa !29
  %t371 = load %"compiler/source:Span", ptr %l176
  %t372 = load i32, ptr %l177, !tbaa !23
  %t373 = load i32, ptr %l178, !range !{i32 0, i32 43}
  %t374 = load ptr, ptr %l179, !tbaa !29
  %t376 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t370, %"compiler/source:Span" %t371, i32 %t372, i32 %t373, ptr %t374, ptr %t369)
  store ptr %t376, ptr %l187
  br label %bb69
bb69:
  %t377 = load ptr, ptr %l187, !tbaa !29
  store ptr %t377, ptr %rv
  br label %ret
bb70:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l188, !tbaa !29
  %t379 = load ptr, ptr %l1, !tbaa !29
  store ptr %t379, ptr %l189, !tbaa !29
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t385 = getelementptr %"compiler/generic:Program", ptr %t383, i32 0, i32 2
  %t386 = load i32, ptr %l6, !tbaa !23
  %t387 = load i64, ptr %l8, !tbaa !24
  %t391 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t385, i32 %t386, i64 %t387)
  store i32 %t391, ptr %l195
  br label %bb71
bb71:
  %t392 = load %"compiler/source:Span", ptr %l3
  %t393 = load ptr, ptr %l188, !tbaa !29
  %t394 = load ptr, ptr %l189, !tbaa !29
  %t395 = load i32, ptr %l195, !tbaa !23
  %t397 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t393, ptr %t394, i32 %t395, %"compiler/source:Span" %t392)
  store ptr %t397, ptr %l197
  br label %bb72
bb72:
  %t398 = load ptr, ptr %l197, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l198, !tbaa !29
  %t400 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t400, ptr %l199
  %t401 = load i32, ptr %l2, !tbaa !23
  store i32 %t401, ptr %l200, !tbaa !23
  store i32 40, ptr %l201
  store ptr %t398, ptr %l202, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l203, !tbaa !29
  %t404 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t404, ptr %l204
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t405)
  store i32 %t407, ptr %l206
  br label %bb73
bb73:
  %t408 = load i64, ptr %l7, !tbaa !24
  %t409 = load ptr, ptr %l203, !tbaa !29
  %t410 = load %"compiler/source:Span", ptr %l204
  %t411 = load i32, ptr %l206, !tbaa !23
  %t413 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t409, %"compiler/source:Span" %t410, i32 %t411, i64 %t408)
  store ptr %t413, ptr %l208
  br label %bb74
bb74:
  %t414 = load ptr, ptr %l208, !tbaa !29
  %t415 = load ptr, ptr %l198, !tbaa !29
  %t416 = load %"compiler/source:Span", ptr %l199
  %t417 = load i32, ptr %l200, !tbaa !23
  %t418 = load i32, ptr %l201, !range !{i32 0, i32 43}
  %t419 = load ptr, ptr %l202, !tbaa !29
  %t421 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t415, %"compiler/source:Span" %t416, i32 %t417, i32 %t418, ptr %t419, ptr %t414)
  store ptr %t421, ptr %l210
  br label %bb75
bb75:
  %t422 = load ptr, ptr %l210, !tbaa !29
  store ptr %t422, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinCall(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/generic:Binding"
  %lp12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"compiler/check:litv"
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i64
  %l32 = alloca i32
  %l37 = alloca i32
  %l43 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca { i64, ptr }
  %l83 = alloca %"compiler/generic:Binding"
  %l84 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca i64
  %l93 = alloca i64
  %l112 = alloca { i64, ptr }
  %l116 = alloca %"compiler/check:litv"
  %l118 = alloca i1
  %l120 = alloca { i64, ptr }
  %l123 = alloca i1
  %l125 = alloca i1
  %l128 = alloca { i64, ptr }
  %l131 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l139 = alloca i32
  %l141 = alloca i32
  %l145 = alloca i32
  %l147 = alloca i32
  %l149 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l153 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca i1
  %l161 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l171 = alloca i1
  %l176 = alloca i1
  %l179 = alloca i32
  %l182 = alloca i1
  %l185 = alloca i32
  %l188 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l191 = alloca i32
  %l194 = alloca i32
  %l212 = alloca i64
  %l215 = alloca i64
  %l233 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l239 = alloca %"compiler/source:Span"
  %l242 = alloca { i64, ptr }
  %l244 = alloca %"compiler/msgs:Msg"
  %l245 = alloca i64
  %l248 = alloca ptr
  %l255 = alloca i32
  %l260 = alloca i32
  %l266 = alloca ptr
  %l270 = alloca i64
  %l277 = alloca ptr
  %l278 = alloca %"compiler/source:Span"
  %l279 = alloca %"compiler/source:Span"
  %l280 = alloca i32
  %l285 = alloca ptr
  %l286 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l289 = alloca ptr
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca ptr
  %t520 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l37
  br label %bb1
bb1:
  %t9 = load i32, ptr %l37, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t16, %"compiler/source:Span" %t17)
  store ptr %t20, ptr %l43
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load ptr, ptr %l43, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l48
  br label %bb6
bb6:
  %t32 = load i32, ptr %l48, !tbaa !23
  store i32 %t32, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t39 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %t33, i32 %t34, { i64, ptr } %t35)
  store { i64, ptr } %t39, ptr %l52
  br label %bb7
bb7:
  %t40 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t40, ptr %l4, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 124
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 124
  store i1 false, ptr %t48, !tbaa !21
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t49, { i64, ptr } %t50)
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l1
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t53, %"compiler/source:Span" %t54)
  store ptr %t57, ptr %l60
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load ptr, ptr %l60, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 125
  %t63 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %s0, ptr %t61)
  store { i64, ptr } %t63, ptr %l63
  br label %bb13
bb13:
  %t64 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t64, ptr %l7, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 125
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t67)
  br label %bb14
bb14:
  %t69 = load i32, ptr %l6, !tbaa !23
  %t71 = call i64 @compiler_2fgeneric_2eCtorOwner(i32 %t69)
  store i64 %t71, ptr %l67
  br label %bb15
bb15:
  %t72 = load i64, ptr %l67, !tbaa !24
  store i64 %t72, ptr %l8, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load i32, ptr %l6, !tbaa !23
  %t80 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %t76, i32 %t77)
  store i64 %t80, ptr %l71
  br label %bb16
bb16:
  %t81 = load i64, ptr %l71, !tbaa !24
  store i64 %t81, ptr %l9, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  store ptr %t87, ptr %l74, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l5, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l79
  br label %bb17
bb17:
  %t98 = load ptr, ptr %l74, !tbaa !29
  %t99 = load i32, ptr %l79, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t98, i32 %t99)
  store { i64, ptr } %t100, ptr %l80
  br label %bb18
bb18:
  %t101 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t101, ptr %l10, !tbaa !27
  %t102 = load i64, ptr %l8, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t102, i64 %t103)
  store %"compiler/generic:Binding" %t106, ptr %l83
  br label %bb19
bb19:
  %t107 = load %"compiler/generic:Binding", ptr %l83
  store %"compiler/generic:Binding" %t107, ptr %l11
  %t108 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %l84
  br label %bb20
bb20:
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t109, ptr %lp12
  %t110 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  %t111 = load ptr, ptr %lp12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %t111
  store i64 0, ptr %l13, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = icmp sgt i64 %t116, %t117
  br i1 %t120, label %bb21, label %bb22
bb21:
  %t122 = load i64, ptr %l15, !tbaa !24
  %t124 = icmp sgt i64 %t122, 0
  br i1 %t124, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb26
bb23:
  %t126 = load i64, ptr %l14, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t130 = sub i64 %t126, %t127
  %t131 = load i64, ptr %l15, !tbaa !24
  %t134 = add i64 %t130, %t131
  %t136 = sub i64 %t134, 1
  %t137 = load i64, ptr %l15, !tbaa !24
  %t140 = sdiv i64 %t136, %t137
  store i64 %t140, ptr %l93, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb25
bb25:
  %t142 = load i64, ptr %l93, !tbaa !24
  store i64 %t142, ptr %l90, !tbaa !24
  br label %bb26
bb26:
  %t143 = load i64, ptr %l90, !tbaa !24
  store i64 %t143, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb27
bb27:
  %t144 = load i64, ptr %l17, !tbaa !24
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb28, label %bb29
bb28:
  br label %bb90
bb29:
  br label %bb30
bb30:
  %t152 = load i64, ptr %l13, !tbaa !24
  %t153 = load i64, ptr %l17, !tbaa !24
  %t154 = load i64, ptr %l15, !tbaa !24
  %t157 = mul i64 %t153, %t154
  %t160 = add i64 %t152, %t157
  store i64 %t160, ptr %l18, !tbaa !24
  store ptr null, ptr %l19, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t163, ptr %l112, !tbaa !27
  %t164 = load i64, ptr %l18, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr ptr, ptr %t167, i64 %t164
  %t169 = load ptr, ptr %t168, !tbaa !39
  %t173 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t162, ptr %t169)
  store %"compiler/check:litv" %t173, ptr %l116
  br label %bb31
bb31:
  %t174 = load %"compiler/check:litv", ptr %l116
  store %"compiler/check:litv" %t174, ptr %l20
  %t175 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 0
  %t176 = load i1, ptr %t175, !tbaa !21
  br i1 %t176, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb35
bb33:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t179, ptr %l120, !tbaa !27
  %t180 = load i64, ptr %l18, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr ptr, ptr %t183, i64 %t180
  %t185 = load ptr, ptr %t184, !tbaa !39
  %t188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t178, ptr %t185)
  store i1 %t188, ptr %l123
  br label %bb34
bb34:
  %t189 = load i1, ptr %l123, !tbaa !21
  store i1 %t189, ptr %l118, !tbaa !21
  br label %bb35
bb35:
  %t190 = load i1, ptr %l118, !tbaa !21
  br i1 %t190, label %bb36, label %bb37
bb36:
  %t191 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 0
  %t192 = load i1, ptr %t191, !tbaa !21
  br i1 %t192, label %bb38, label %bb39
bb37:
  %t194 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t194, ptr %l149, !tbaa !27
  %t195 = load i64, ptr %l18, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 %t195
  %t200 = load ptr, ptr %t199, !tbaa !39
  store ptr %t200, ptr %l22, !tbaa !29
  %t202 = load ptr, ptr %l22, !tbaa !29
  store ptr %t202, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t203 = load ptr, ptr %l152, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb51, label %bb52
bb38:
  %t206 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 1
  %t207 = load i1, ptr %t206, !tbaa !21
  store i1 %t207, ptr %l125, !tbaa !21
  br label %bb41
bb39:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t210, ptr %l128, !tbaa !27
  %t211 = load i64, ptr %l18, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr ptr, ptr %t214, i64 %t211
  %t216 = load ptr, ptr %t215, !tbaa !39
  %t219 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %t209, ptr %t216)
  store i1 %t219, ptr %l131
  br label %bb40
bb40:
  %t220 = load i1, ptr %l131, !tbaa !21
  store i1 %t220, ptr %l125, !tbaa !21
  br label %bb41
bb41:
  %t221 = load i1, ptr %l125, !tbaa !21
  store i1 %t221, ptr %l21, !tbaa !21
  %t222 = load i64, ptr %l18, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t223, 0
  %t228 = icmp slt i64 %t222, %t225
  br i1 %t228, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l136, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t231, ptr %l137, !tbaa !27
  %t232 = load i64, ptr %l18, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  store i32 %t237, ptr %l139, !tbaa !23
  %t238 = load i1, ptr %l21, !tbaa !21
  br i1 %t238, label %bb44, label %bb45
bb43:
  br label %bb50
bb44:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/generic:Program", ptr %t243, i32 0, i32 2
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s6, ptr %t245, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i32 %t247, ptr %l145
  br label %bb46
bb45:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t248)
  store i32 %t250, ptr %l147
  br label %bb47
bb46:
  %t251 = load i32, ptr %l145, !tbaa !23
  store i32 %t251, ptr %l141, !tbaa !23
  br label %bb48
bb47:
  %t252 = load i32, ptr %l147, !tbaa !23
  store i32 %t252, ptr %l141, !tbaa !23
  br label %bb48
bb48:
  %t253 = load ptr, ptr %l136, !tbaa !29
  %t254 = load i32, ptr %l139, !tbaa !23
  %t255 = load i32, ptr %l141, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t253, i32 %t254, i32 %t255, ptr %l11, i1 true, i1 false)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  br label %bb67
bb51:
  %t257 = load ptr, ptr %l152, !tbaa !29
  %t258 = load i64, ptr %t257, !range !{i64 0, i64 29}
  %t260 = icmp eq i64 %t258, 23
  store i1 %t260, ptr %l153, !tbaa !21
  br label %bb52
bb52:
  %t261 = load i1, ptr %l153, !tbaa !21
  br i1 %t261, label %bb53, label %bb54
bb53:
  br label %bb59
bb54:
  %t262 = load ptr, ptr %l22, !tbaa !29
  store ptr %t262, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t263 = load ptr, ptr %l156, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb55, label %bb56
bb55:
  %t266 = load ptr, ptr %l156, !tbaa !29
  %t267 = load i64, ptr %t266, !range !{i64 0, i64 29}
  %t269 = icmp eq i64 %t267, 26
  store i1 %t269, ptr %l157, !tbaa !21
  br label %bb56
bb56:
  %t270 = load i1, ptr %l157, !tbaa !21
  br i1 %t270, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb66
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t272, ptr %l161, !tbaa !27
  %t273 = load i64, ptr %l18, !tbaa !24
  %t275 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr ptr, ptr %t276, i64 %t273
  %t278 = load ptr, ptr %t277, !tbaa !39
  %t280 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t284 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t271, ptr %t278, i32 %t280)
  store ptr %t284, ptr %l166
  br label %bb64
bb64:
  %t285 = load ptr, ptr %l166, !tbaa !29
  store ptr %t285, ptr %l19, !tbaa !29
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_86f2d648d7a819c5_fc1d6e84e063e4d9)
  unreachable
bb66:
  br label %bb67
bb67:
  %t287 = load ptr, ptr %l19, !tbaa !29
  %t289 = icmp eq ptr %t287, null
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb68, label %bb69
bb68:
  %t293 = load i64, ptr %l18, !tbaa !24
  %t294 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t299 = icmp slt i64 %t293, %t296
  store i1 %t299, ptr %l171, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb70
bb70:
  %t301 = load i1, ptr %l171, !tbaa !21
  br i1 %t301, label %bb71, label %bb72
bb71:
  %t302 = load ptr, ptr %l19, !tbaa !29
  %t305 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t302)
  store i32 %t305, ptr %l179
  br label %bb73
bb72:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb74
bb73:
  %t306 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t307 = load i32, ptr %l179, !tbaa !23
  %t309 = icmp ne i32 %t307, %t306
  store i1 %t309, ptr %l176, !tbaa !21
  br label %bb74
bb74:
  %t311 = load i1, ptr %l176, !tbaa !21
  br i1 %t311, label %bb75, label %bb76
bb75:
  %t312 = load ptr, ptr %l19, !tbaa !29
  %t315 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t312)
  store i32 %t315, ptr %l185
  br label %bb77
bb76:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb78
bb77:
  %t316 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t317 = load i32, ptr %l185, !tbaa !23
  %t319 = icmp ne i32 %t317, %t316
  store i1 %t319, ptr %l182, !tbaa !21
  br label %bb78
bb78:
  %t321 = load i1, ptr %l182, !tbaa !21
  br i1 %t321, label %bb79, label %bb80
bb79:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l188, !tbaa !29
  %t323 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t323, ptr %l189, !tbaa !27
  %t324 = load i64, ptr %l18, !tbaa !24
  %t326 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr i32, ptr %t327, i64 %t324
  %t329 = load i32, ptr %t328, !tbaa !33
  store i32 %t329, ptr %l191, !tbaa !23
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l19, !tbaa !29
  %t334 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v0, ptr %t330, ptr %t331)
  store i32 %t334, ptr %l194
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t335 = load ptr, ptr %l188, !tbaa !29
  %t336 = load i32, ptr %l191, !tbaa !23
  %t337 = load i32, ptr %l194, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t335, i32 %t336, i32 %t337, ptr %l11, i1 false, i1 false)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t339 = load ptr, ptr %l19, !tbaa !29
  %t341 = icmp eq ptr %t339, null
  br i1 %t341, label %bb84, label %bb85
bb84:
  %t343 = load ptr, ptr %lp12
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/check:Checker", ptr %t344, i32 0, i32 0
  %t347 = load ptr, ptr %t346, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t343, ptr %t347)
  br label %bb86
bb85:
  %t350 = load ptr, ptr %lp12
  %t351 = load ptr, ptr %l19, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t350, ptr %t351)
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t354 = load i64, ptr %l17, !tbaa !24
  %t356 = add i64 %t354, 1
  store i64 %t356, ptr %l17, !tbaa !24
  br label %bb27
bb90:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/check:Checker", ptr %t358, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t361, ptr %l11)
  br label %bb91
bb91:
  store i64 0, ptr %l23, !tbaa !24
  %t364 = load i64, ptr %l9, !tbaa !24
  store i64 %t364, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t366 = load i64, ptr %l24, !tbaa !24
  %t367 = load i64, ptr %l23, !tbaa !24
  %t370 = icmp sgt i64 %t366, %t367
  br i1 %t370, label %bb92, label %bb93
bb92:
  %t372 = load i64, ptr %l25, !tbaa !24
  %t374 = icmp sgt i64 %t372, 0
  br i1 %t374, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l212, !tbaa !24
  br label %bb97
bb94:
  %t376 = load i64, ptr %l24, !tbaa !24
  %t377 = load i64, ptr %l23, !tbaa !24
  %t380 = sub i64 %t376, %t377
  %t381 = load i64, ptr %l25, !tbaa !24
  %t384 = add i64 %t380, %t381
  %t386 = sub i64 %t384, 1
  %t387 = load i64, ptr %l25, !tbaa !24
  %t390 = sdiv i64 %t386, %t387
  store i64 %t390, ptr %l215, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l215, !tbaa !24
  br label %bb96
bb96:
  %t392 = load i64, ptr %l215, !tbaa !24
  store i64 %t392, ptr %l212, !tbaa !24
  br label %bb97
bb97:
  %t393 = load i64, ptr %l212, !tbaa !24
  store i64 %t393, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb98
bb98:
  %t394 = load i64, ptr %l27, !tbaa !24
  %t395 = load i64, ptr %l26, !tbaa !24
  %t398 = icmp slt i64 %t394, %t395
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb99, label %bb100
bb99:
  br label %bb110
bb100:
  br label %bb101
bb101:
  %t402 = load i64, ptr %l23, !tbaa !24
  %t403 = load i64, ptr %l27, !tbaa !24
  %t404 = load i64, ptr %l25, !tbaa !24
  %t407 = mul i64 %t403, %t404
  %t410 = add i64 %t402, %t407
  %t412 = getelementptr %"compiler/generic:Binding", ptr %l11, i32 0, i32 2
  %t413 = load { i64, ptr }, ptr %t412, !tbaa !27
  store { i64, ptr } %t413, ptr %l233, !tbaa !27
  %t416 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !27
  %t418 = getelementptr i32, ptr %t417, i64 %t410
  %t419 = load i32, ptr %t418, !tbaa !33
  %t420 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t423 = icmp eq i32 %t419, %t420
  br i1 %t423, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s16
  %t425 = load ptr, ptr %l0, !tbaa !29
  store ptr %t425, ptr %l238, !tbaa !29
  %t426 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t426, ptr %l239
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load i32, ptr %l3, !tbaa !23
  %t431 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t427, i32 %t428)
  store { i64, ptr } %t431, ptr %l242
  br label %bb104
bb103:
  br label %bb108
bb104:
  %t432 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t432, 0
  %t434 = extractvalue { i64, ptr } %t432, 1
  %t435 = mul i64 %t433, 1
  %t436 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t435)
  call void @llvm.memcpy.p0.p0.i64(ptr %t436, ptr %t434, i64 %t435, i1 false)
  %t437 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t436, 1
  %t440 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarsNotInferable(ptr %s16, ptr %s16, { i64, ptr } %t438)
  store %"compiler/msgs:Msg" %t440, ptr %l244
  br label %bb105
bb105:
  %t441 = load ptr, ptr %l238, !tbaa !29
  %t442 = load %"compiler/source:Span", ptr %l239
  %t443 = load %"compiler/msgs:Msg", ptr %l244
  %t444 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t441, %"compiler/source:Span" %t442, %"compiler/msgs:Msg" %t443)
  store i64 %t444, ptr %l245
  br label %bb106
bb106:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l1
  %t449 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t445, %"compiler/source:Span" %t446)
  store ptr %t449, ptr %l248
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t450 = load ptr, ptr %l248, !tbaa !29
  store ptr %t450, ptr %rv
  br label %ret
bb108:
  br label %bb109
bb109:
  %t451 = load i64, ptr %l27, !tbaa !24
  %t453 = add i64 %t451, 1
  store i64 %t453, ptr %l27, !tbaa !24
  br label %bb98
bb110:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/check:Checker", ptr %t455, i32 0, i32 1
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t460 = getelementptr %"compiler/generic:Program", ptr %t458, i32 0, i32 2
  %t461 = getelementptr %"compiler/generic:Binding", ptr %l11, i32 0, i32 2
  %t462 = load { i64, ptr }, ptr %t461, !tbaa !27
  %t465 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t460, { i64, ptr } %t462)
  store i32 %t465, ptr %l255
  br label %bb111
bb111:
  %t466 = load i32, ptr %l255, !tbaa !23
  store i32 %t466, ptr %l29, !tbaa !23
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t469 = getelementptr %"compiler/check:Checker", ptr %t467, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !29
  %t471 = load i32, ptr %l3, !tbaa !23
  %t472 = load i32, ptr %l29, !tbaa !23
  %t476 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %t470, i32 %t471, i32 %t472)
  store i32 %t476, ptr %l260
  br label %bb112
bb112:
  %t477 = load i32, ptr %l260, !tbaa !23
  store i32 %t477, ptr %l30, !tbaa !23
  %t478 = load i32, ptr %l30, !tbaa !23
  %t479 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t482 = icmp eq i32 %t478, %t479
  br i1 %t482, label %bb113, label %bb114
bb113:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load %"compiler/source:Span", ptr %l1
  %t488 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t484, %"compiler/source:Span" %t485)
  store ptr %t488, ptr %l266
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s0)
  %t489 = load ptr, ptr %l266, !tbaa !29
  store ptr %t489, ptr %rv
  br label %ret
bb116:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load i32, ptr %l3, !tbaa !23
  %t492 = load i32, ptr %l29, !tbaa !23
  %t496 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %t490, i32 %t491, i32 %t492)
  store i64 %t496, ptr %l270
  br label %bb117
bb117:
  %t497 = load i64, ptr %l270, !tbaa !24
  store i64 %t497, ptr %l31, !tbaa !24
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/check:Checker", ptr %t498, i32 0, i32 23
  %t501 = load i32, ptr %t500, !tbaa !23
  store i32 %t501, ptr %l32, !tbaa !23
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load i32, ptr %l3, !tbaa !23
  %t507 = getelementptr %"compiler/check:Checker", ptr %t503, i32 0, i32 23
  store i32 %t504, ptr %t507, !tbaa !23
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %s0, ptr %t508, { i64, ptr } %t509)
  br label %bb118
bb118:
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l277, !tbaa !29
  %t513 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t513, ptr %l278
  %t514 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t514, ptr %l279
  %t515 = load i32, ptr %l30, !tbaa !23
  store i32 %t515, ptr %l280, !tbaa !23
  %t516 = load i64, ptr %l31, !tbaa !24
  %t518 = trunc i64 %t516 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t520
  %t521 = getelementptr { i64, [3 x i64] }, ptr %t520, i32 0, i32 0
  store i64 0, ptr %t521
  %t523 = insertvalue { i32 } undef, i32 %t518, 0
  %t524 = getelementptr { i64, [3 x i64] }, ptr %t520, i32 0, i32 1
  store { i32 } %t523, ptr %t524
  %t525 = load { i64, [3 x i64] }, ptr %t520
  %t527 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t525, ptr %t527
  store ptr %t527, ptr %l285, !tbaa !29
  %t528 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t528, ptr %l286, !tbaa !27
  %t529 = load ptr, ptr %lp12
  %t531 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v0, ptr %t529)
  store { i64, ptr } %t531, ptr %l288
  br label %bb119
bb119:
  %t532 = load ptr, ptr %l277, !tbaa !29
  %t533 = load %"compiler/source:Span", ptr %l278
  %t534 = load %"compiler/source:Span", ptr %l279
  %t535 = load i32, ptr %l280, !tbaa !23
  %t536 = load ptr, ptr %l285, !tbaa !29
  %t537 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t538 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t539 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %t532, %"compiler/source:Span" %t533, %"compiler/source:Span" %t534, i32 %t535, ptr %t536, i64 -1, ptr null, { i64, ptr } %t537, { i64, ptr } %t538)
  store ptr %t539, ptr %l289
  br label %bb120
bb120:
  %t540 = load ptr, ptr %l289, !tbaa !29
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load i32, ptr %l32, !tbaa !23
  %t545 = getelementptr %"compiler/check:Checker", ptr %t541, i32 0, i32 23
  store i32 %t542, ptr %t545, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t540, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i32
  %l26 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t18, i32 0, i32 3
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 3}
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l13, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l18
  br label %bb11
bb11:
  %t36 = load i1, ptr %l18, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l24
  br label %bb14
bb13:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb16
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l26
  br label %bb15
bb15:
  %t50 = load i32, ptr %l24, !tbaa !23
  %t51 = load i32, ptr %l26, !tbaa !23
  %t52 = icmp eq i32 %t50, %t51
  store i1 %t52, ptr %l19, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l19, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l30, !tbaa !24
  %t58 = load i64, ptr %l30, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l31, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l30, !tbaa !24
  %t68 = mul i64 %t67, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t64, ptr %t66, i64 %t68, i1 false)
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t69, ptr %l29, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e722c21055ee6b49_58bcebf0b772fb7d)
  unreachable
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_eca48244095fc078_aacf4c954a6e214c)
  unreachable
bb31:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l32, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t72)
  store i32 %t75, ptr %l35
  br label %bb32
bb32:
  %t76 = load ptr, ptr %l32, !tbaa !29
  %t77 = load i32, ptr %l35, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v2, ptr %t76, i32 %t77)
  store { i64, ptr } %t78, ptr %l36
  br label %bb33
bb33:
  %t79 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeRules(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l44 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i32
  %l63 = alloca i1
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca i64
  %l75 = alloca i1
  %l84 = alloca i64
  %l91 = alloca i32
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l100 = alloca %"compiler/generic:Context"
  %l113 = alloca { i64, ptr }
  %l120 = alloca i1
  %l121 = alloca ptr
  %l123 = alloca i32
  %l125 = alloca i32
  %l129 = alloca { i64, ptr }
  %l133 = alloca %"compiler/source:Span"
  %l137 = alloca { i64, ptr }
  %l139 = alloca %"compiler/msgs:Msg"
  %l140 = alloca i64
  %l155 = alloca { i64, ptr }
  %l162 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i64
  %l170 = alloca i1
  %l172 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l179 = alloca ptr
  %l185 = alloca %"compiler/source:Span"
  %l186 = alloca { i64, ptr }
  %l187 = alloca %"compiler/msgs:Msg"
  %l188 = alloca i64
  %l197 = alloca { i64, ptr }
  %l203 = alloca i1
  %l205 = alloca ptr
  %l207 = alloca %"compiler/source:Span"
  %l208 = alloca ptr
  %l210 = alloca %"compiler/source:Span"
  %l211 = alloca { i64, ptr }
  %l212 = alloca %"compiler/msgs:Msg"
  %l213 = alloca i64
  %l224 = alloca ptr
  %l225 = alloca i1
  %l228 = alloca ptr
  %l230 = alloca { i64, ptr }
  %l232 = alloca %"compiler/source:Span"
  %l233 = alloca %"compiler/msgs:Msg"
  %l234 = alloca i64
  %l237 = alloca ptr
  %l238 = alloca i1
  %l246 = alloca ptr
  %l247 = alloca i1
  %l259 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l280 = alloca i1
  %l286 = alloca ptr
  %l288 = alloca i64
  %l291 = alloca ptr
  %l294 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l299 = alloca i64
  %l302 = alloca i64
  %l303 = alloca i32
  %l315 = alloca %"compiler/source:Span"
  %l318 = alloca ptr
  %l319 = alloca i1
  %l330 = alloca i32
  %l333 = alloca i1
  %l336 = alloca i32
  %l340 = alloca i1
  %l345 = alloca i32
  %l347 = alloca ptr
  %l349 = alloca %"compiler/source:Span"
  %l352 = alloca { i64, ptr }
  %l354 = alloca %"compiler/msgs:Msg"
  %l355 = alloca i64
  %l360 = alloca i32
  %l363 = alloca i1
  %l367 = alloca i1
  %l368 = alloca ptr
  %l369 = alloca %"compiler/source:Span"
  %l370 = alloca { i64, ptr }
  %l371 = alloca { i64, ptr }
  %l374 = alloca { i64, ptr }
  %l376 = alloca %"compiler/msgs:Msg"
  %l377 = alloca i64
  %l382 = alloca i32
  %l385 = alloca i1
  %l386 = alloca ptr
  %l391 = alloca i32
  %l392 = alloca i1
  %l393 = alloca ptr
  %l395 = alloca %"compiler/source:Span"
  %l396 = alloca ptr
  %l401 = alloca i32
  %l402 = alloca { i64, ptr }
  %l404 = alloca %"compiler/msgs:Msg"
  %l405 = alloca i64
  %l408 = alloca ptr
  %l409 = alloca i1
  %l417 = alloca i32
  %l420 = alloca ptr
  %l425 = alloca i32
  %l426 = alloca { i64, ptr }
  %l429 = alloca i1
  %l433 = alloca i1
  %l436 = alloca ptr
  %l441 = alloca i32
  %l442 = alloca { i64, ptr }
  %l444 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l450 = alloca i64
  %l453 = alloca i64
  %l471 = alloca i64
  %l473 = alloca i64
  %l475 = alloca i1
  %l477 = alloca { i64, ptr }
  %l481 = alloca i1
  %l482 = alloca ptr
  %l485 = alloca %"compiler/source:Span"
  %l488 = alloca { i64, ptr }
  %l490 = alloca %"compiler/msgs:Msg"
  %l491 = alloca i64
  %l494 = alloca ptr
  %l495 = alloca i1
  %l503 = alloca i32
  %l511 = alloca { i64, ptr }
  %l526 = alloca { i64, ptr }
  %l538 = alloca i32
  %l541 = alloca i1
  %l543 = alloca i1
  %l546 = alloca i1
  %l548 = alloca i32
  %l550 = alloca i32
  %l554 = alloca { i64, ptr }
  %l558 = alloca %"compiler/source:Span"
  %l559 = alloca ptr
  %l560 = alloca %"compiler/source:Span"
  %l564 = alloca { i64, ptr }
  %l565 = alloca { i64, ptr }
  %l566 = alloca ptr
  %l572 = alloca %"compiler/source:Span"
  %l573 = alloca { i64, ptr }
  %l574 = alloca %"compiler/msgs:Msg"
  %l575 = alloca i64
  %l587 = alloca { i64, ptr }
  %l591 = alloca i1
  %l604 = alloca { i64, ptr }
  %l607 = alloca ptr
  %l614 = alloca i32
  %l616 = alloca i1
  %l617 = alloca ptr
  %l619 = alloca i32
  %l621 = alloca i32
  %l625 = alloca { i64, ptr }
  %l629 = alloca %"compiler/source:Span"
  %l632 = alloca { i64, ptr }
  %l634 = alloca %"compiler/msgs:Msg"
  %l635 = alloca i64
  %l642 = alloca i1
  %l645 = alloca i64
  %l647 = alloca i64
  %l648 = alloca i32
  %l650 = alloca ptr
  %l660 = alloca %"compiler/source:Span"
  %l661 = alloca %"compiler/msgs:Msg"
  %l662 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s59 = alloca %olang.scope
  %s63 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l75, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l75, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TypeDecl", ptr %t18, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  %t25 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t16, i64 %t17, i32 %t21)
  store i64 %t25, ptr %l84
  br label %bb7
bb7:
  %t26 = load i64, ptr %l84, !tbaa !24
  store i64 %t26, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t40 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t34, i64 %t35, i64 %t36)
  store i32 %t40, ptr %l91
  br label %bb11
bb11:
  %t41 = load i32, ptr %l91, !tbaa !23
  store i32 %t41, ptr %l5, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t42, i64 -1, i64 %t43, i32 %t44, i32 0)
  store ptr %t48, ptr %l95
  br label %bb12
bb12:
  %t49 = load ptr, ptr %l95, !tbaa !29
  store ptr %t49, ptr %l6, !tbaa !29
  %t50 = load ptr, ptr %l6, !tbaa !29
  store ptr %t50, ptr %l96, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load i32, ptr %l5, !tbaa !23
  %t58 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %v0, ptr %v0, ptr %t54, i32 %t55)
  store %"compiler/generic:Context" %t58, ptr %l100
  br label %bb13
bb13:
  %t59 = load %"compiler/generic:Context", ptr %l100
  %t60 = load ptr, ptr %l96, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 4
  store %"compiler/generic:Context" %t59, ptr %t61
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr %"compiler/ast:TypeDecl", ptr %t62, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb14, label %bb15
bb14:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = getelementptr %"compiler/ast:TypeDecl", ptr %t71, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  store i64 %t78, ptr %l9, !tbaa !24
  br label %bb16
bb15:
  br label %bb31
bb16:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb17, label %bb18
bb17:
  br label %bb30
bb18:
  br label %bb19
bb19:
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t88, ptr %l113, !tbaa !27
  %t89 = load i64, ptr %l8, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr ptr, ptr %t92, i64 %t89
  %t94 = load ptr, ptr %t93, !tbaa !39
  store ptr %t94, ptr %l10, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i64, ptr %l1, !tbaa !24
  %t98 = load ptr, ptr %l10, !tbaa !29
  %t100 = getelementptr %"compiler/ast:TypeParam", ptr %t98, i32 0, i32 1
  %t101 = load i32, ptr %t100, !tbaa !23
  %t105 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesType(ptr %v0, ptr %t96, i64 %t97, i32 %t101)
  store i1 %t105, ptr %l120
  br label %bb20
bb20:
  %t106 = load i1, ptr %l120, !tbaa !21
  br i1 %t106, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l121, !tbaa !29
  %t108 = load ptr, ptr %l10, !tbaa !29
  %t110 = getelementptr %"compiler/ast:TypeParam", ptr %t108, i32 0, i32 0
  %t111 = getelementptr %"compiler/source:Span", ptr %t110, i32 0, i32 0
  %t112 = load i32, ptr %t111, !tbaa !23
  store i32 %t112, ptr %l123, !tbaa !23
  %t113 = load ptr, ptr %l10, !tbaa !29
  %t115 = getelementptr %"compiler/ast:TypeParam", ptr %t113, i32 0, i32 0
  %t116 = getelementptr %"compiler/source:Span", ptr %t115, i32 0, i32 0
  %t117 = load i32, ptr %t116, !tbaa !23
  store i32 %t117, ptr %l125, !tbaa !23
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l10, !tbaa !29
  %t121 = getelementptr %"compiler/ast:TypeParam", ptr %t119, i32 0, i32 1
  %t122 = load i32, ptr %t121, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t118, i32 %t122)
  store { i64, ptr } %t125, ptr %l129
  br label %bb23
bb22:
  br label %bb28
bb23:
  %t126 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  %t129 = trunc i64 %t127 to i32
  %t130 = load i32, ptr %l125, !tbaa !23
  %t132 = add i32 %t130, %t129
  %t133 = load i32, ptr %l123, !tbaa !23
  %t135 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t133, i32 %t132)
  store %"compiler/source:Span" %t135, ptr %l133
  br label %bb24
bb24:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t139 = getelementptr %"compiler/ast:TypeParam", ptr %t137, i32 0, i32 1
  %t140 = load i32, ptr %t139, !tbaa !23
  %t143 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t136, i32 %t140)
  store { i64, ptr } %t143, ptr %l137
  br label %bb25
bb25:
  %t144 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  %t146 = extractvalue { i64, ptr } %t144, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  %t152 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarNamesType(ptr %s6, ptr %s6, { i64, ptr } %t150)
  store %"compiler/msgs:Msg" %t152, ptr %l139
  br label %bb26
bb26:
  %t153 = load ptr, ptr %l121, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l133
  %t155 = load %"compiler/msgs:Msg", ptr %l139
  %t156 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t153, %"compiler/source:Span" %t154, %"compiler/msgs:Msg" %t155)
  store i64 %t156, ptr %l140
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t157 = load i64, ptr %l8, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l8, !tbaa !24
  br label %bb16
bb30:
  br label %bb31
bb31:
  %t161 = load ptr, ptr %l3, !tbaa !29
  %t163 = getelementptr %"compiler/ast:TypeDecl", ptr %t161, i32 0, i32 1
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t168 = icmp sgt i64 %t166, 0
  br i1 %t168, label %bb32, label %bb33
bb32:
  %t170 = load ptr, ptr %l3, !tbaa !29
  %t172 = getelementptr %"compiler/ast:TypeDecl", ptr %t170, i32 0, i32 1
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l13, !tbaa !24
  br label %bb34
bb33:
  br label %bb76
bb34:
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = load i64, ptr %l13, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb35, label %bb36
bb35:
  br label %bb75
bb36:
  br label %bb37
bb37:
  %t187 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t187, ptr %l155, !tbaa !27
  %t188 = load i64, ptr %l12, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr ptr, ptr %t191, i64 %t188
  %t193 = load ptr, ptr %t192, !tbaa !39
  store ptr %t193, ptr %l14, !tbaa !29
  %t195 = load ptr, ptr %l14, !tbaa !29
  %t197 = getelementptr %"compiler/ast:TypeParam", ptr %t195, i32 0, i32 2
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = icmp eq ptr %t198, null
  %t202 = xor i1 %t200, true
  br i1 %t202, label %bb38, label %bb39
bb38:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l163, !tbaa !29
  %t205 = load i64, ptr %l1, !tbaa !24
  store i64 %t205, ptr %l164, !tbaa !24
  %t206 = load ptr, ptr %l14, !tbaa !29
  %t208 = getelementptr %"compiler/ast:TypeParam", ptr %t206, i32 0, i32 2
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = icmp eq ptr %t209, null
  br i1 %t211, label %bb40, label %bb41
bb39:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb44
bb40:
  call void @__olang_check_failed(ptr @olang_loc_42d76eb8aa19d24d_a6d8d644d4fa1309)
  unreachable
bb41:
  br label %bb42
bb42:
  %t213 = load ptr, ptr %l14, !tbaa !29
  %t215 = getelementptr %"compiler/ast:TypeParam", ptr %t213, i32 0, i32 2
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t217 = load ptr, ptr %l163, !tbaa !29
  %t218 = load i64, ptr %l164, !tbaa !24
  %t220 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t217, i64 %t218, ptr %t216)
  store i1 %t220, ptr %l170
  br label %bb43
bb43:
  %t221 = load i1, ptr %l170, !tbaa !21
  %t222 = xor i1 %t221, true
  store i1 %t222, ptr %l162, !tbaa !21
  br label %bb44
bb44:
  %t224 = load i1, ptr %l162, !tbaa !21
  br i1 %t224, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s11
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l172, !tbaa !29
  %t226 = load ptr, ptr %l14, !tbaa !29
  %t228 = getelementptr %"compiler/ast:TypeParam", ptr %t226, i32 0, i32 2
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t231 = icmp eq ptr %t229, null
  br i1 %t231, label %bb47, label %bb48
bb46:
  br label %bb58
bb47:
  call void @__olang_check_failed(ptr @olang_loc_42d76eb8aa19d24d_a6d8d644d4fa1309)
  unreachable
bb48:
  br label %bb49
bb49:
  %t233 = load ptr, ptr %l14, !tbaa !29
  %t235 = getelementptr %"compiler/ast:TypeParam", ptr %t233, i32 0, i32 2
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t236)
  store %"compiler/source:Span" %t238, ptr %l178
  br label %bb50
bb50:
  %t239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t239, ptr %l179, !tbaa !29
  %t240 = load ptr, ptr %l14, !tbaa !29
  %t242 = getelementptr %"compiler/ast:TypeParam", ptr %t240, i32 0, i32 2
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = icmp eq ptr %t243, null
  br i1 %t245, label %bb51, label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_42d76eb8aa19d24d_a6d8d644d4fa1309)
  unreachable
bb52:
  br label %bb53
bb53:
  %t247 = load ptr, ptr %l14, !tbaa !29
  %t249 = getelementptr %"compiler/ast:TypeParam", ptr %t247, i32 0, i32 2
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t250)
  store %"compiler/source:Span" %t252, ptr %l185
  br label %bb54
bb54:
  %t253 = load ptr, ptr %l179, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l185
  %t255 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t253, %"compiler/source:Span" %t254)
  store { i64, ptr } %t255, ptr %l186
  br label %bb55
bb55:
  %t256 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t257 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %s11, { i64, ptr } %t256)
  store %"compiler/msgs:Msg" %t257, ptr %l187
  br label %bb56
bb56:
  %t258 = load ptr, ptr %l172, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l178
  %t260 = load %"compiler/msgs:Msg", ptr %l187
  %t261 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t258, %"compiler/source:Span" %t259, %"compiler/msgs:Msg" %t260)
  store i64 %t261, ptr %l188
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb58
bb58:
  %t262 = load ptr, ptr %l14, !tbaa !29
  %t264 = getelementptr %"compiler/ast:TypeParam", ptr %t262, i32 0, i32 3
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  store { i64, ptr } %t265, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t267 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t267, 0
  store i64 %t269, ptr %l17, !tbaa !24
  br label %bb59
bb59:
  %t271 = load i64, ptr %l16, !tbaa !24
  %t272 = load i64, ptr %l17, !tbaa !24
  %t275 = icmp slt i64 %t271, %t272
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb60, label %bb61
bb60:
  br label %bb73
bb61:
  br label %bb62
bb62:
  %t279 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t279, ptr %l197, !tbaa !27
  %t280 = load i64, ptr %l16, !tbaa !24
  %t282 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr ptr, ptr %t283, i64 %t280
  %t285 = load ptr, ptr %t284, !tbaa !39
  store ptr %t285, ptr %l18, !tbaa !29
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load i64, ptr %l1, !tbaa !24
  %t289 = load ptr, ptr %l18, !tbaa !29
  %t293 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t287, i64 %t288, ptr %t289)
  store i1 %t293, ptr %l203
  br label %bb63
bb63:
  %t294 = load i1, ptr %l203, !tbaa !21
  %t295 = xor i1 %t294, true
  br i1 %t295, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s14
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l205, !tbaa !29
  %t298 = load ptr, ptr %l18, !tbaa !29
  %t300 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t298)
  store %"compiler/source:Span" %t300, ptr %l207
  br label %bb66
bb65:
  br label %bb71
bb66:
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l208, !tbaa !29
  %t302 = load ptr, ptr %l18, !tbaa !29
  %t304 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t302)
  store %"compiler/source:Span" %t304, ptr %l210
  br label %bb67
bb67:
  %t305 = load ptr, ptr %l208, !tbaa !29
  %t306 = load %"compiler/source:Span", ptr %l210
  %t307 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t305, %"compiler/source:Span" %t306)
  store { i64, ptr } %t307, ptr %l211
  br label %bb68
bb68:
  %t308 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t309 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %s14, { i64, ptr } %t308)
  store %"compiler/msgs:Msg" %t309, ptr %l212
  br label %bb69
bb69:
  %t310 = load ptr, ptr %l205, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l207
  %t312 = load %"compiler/msgs:Msg", ptr %l212
  %t313 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t310, %"compiler/source:Span" %t311, %"compiler/msgs:Msg" %t312)
  store i64 %t313, ptr %l213
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s14)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t314 = load i64, ptr %l16, !tbaa !24
  %t316 = add i64 %t314, 1
  store i64 %t316, ptr %l16, !tbaa !24
  br label %bb59
bb73:
  br label %bb74
bb74:
  %t318 = load i64, ptr %l12, !tbaa !24
  %t320 = add i64 %t318, 1
  store i64 %t320, ptr %l12, !tbaa !24
  br label %bb34
bb75:
  br label %bb76
bb76:
  %t322 = load ptr, ptr %l3, !tbaa !29
  %t324 = getelementptr %"compiler/ast:TypeDecl", ptr %t322, i32 0, i32 1
  %t325 = load { i64, ptr }, ptr %t324, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t325, 0
  %t329 = icmp sgt i64 %t327, 0
  br i1 %t329, label %bb77, label %bb78
bb77:
  %t331 = load ptr, ptr %l3, !tbaa !29
  %t333 = getelementptr %"compiler/ast:TypeDecl", ptr %t331, i32 0, i32 3
  %t334 = load ptr, ptr %t333, !tbaa !29
  store ptr %t334, ptr %l224, !tbaa !29
  store i1 false, ptr %l225, !tbaa !21
  %t337 = load ptr, ptr %l224, !tbaa !29
  %t338 = icmp ne ptr %t337, null
  br i1 %t338, label %bb79, label %bb80
bb78:
  br label %bb92
bb79:
  %t340 = load ptr, ptr %l224, !tbaa !29
  %t341 = load i64, ptr %t340, !range !{i64 0, i64 5}
  %t343 = icmp eq i64 %t341, 3
  store i1 %t343, ptr %l225, !tbaa !21
  br label %bb80
bb80:
  %t344 = load i1, ptr %l225, !tbaa !21
  br i1 %t344, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb86
bb83:
  store %olang.scope zeroinitializer, ptr %s18
  %t345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t345, ptr %l228, !tbaa !29
  %t346 = load ptr, ptr %l3, !tbaa !29
  %t348 = getelementptr %"compiler/ast:TypeDecl", ptr %t346, i32 0, i32 1
  %t349 = load { i64, ptr }, ptr %t348, !tbaa !27
  store { i64, ptr } %t349, ptr %l230, !tbaa !27
  %t350 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr ptr, ptr %t351, i64 0
  %t353 = load ptr, ptr %t352, !tbaa !39
  %t355 = getelementptr %"compiler/ast:TypeParam", ptr %t353, i32 0, i32 0
  %t356 = load %"compiler/source:Span", ptr %t355
  store %"compiler/source:Span" %t356, ptr %l232
  %t357 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotStruct(ptr %s18)
  store %"compiler/msgs:Msg" %t357, ptr %l233
  br label %bb84
bb84:
  %t358 = load ptr, ptr %l228, !tbaa !29
  %t359 = load %"compiler/source:Span", ptr %l232
  %t360 = load %"compiler/msgs:Msg", ptr %l233
  %t361 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t358, %"compiler/source:Span" %t359, %"compiler/msgs:Msg" %t360)
  store i64 %t361, ptr %l234
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s18)
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_e4a3554ab68c2525_45e0e0bdd3564951)
  unreachable
bb91:
  br label %bb92
bb92:
  %t362 = load ptr, ptr %l3, !tbaa !29
  %t364 = getelementptr %"compiler/ast:TypeDecl", ptr %t362, i32 0, i32 3
  %t365 = load ptr, ptr %t364, !tbaa !29
  store ptr %t365, ptr %l20, !tbaa !29
  %t367 = load ptr, ptr %l20, !tbaa !29
  store ptr %t367, ptr %l237, !tbaa !29
  store i1 false, ptr %l238, !tbaa !21
  %t368 = load ptr, ptr %l237, !tbaa !29
  %t369 = icmp ne ptr %t368, null
  br i1 %t369, label %bb93, label %bb94
bb93:
  %t371 = load ptr, ptr %l237, !tbaa !29
  %t372 = load i64, ptr %t371, !range !{i64 0, i64 5}
  %t374 = icmp eq i64 %t372, 0
  store i1 %t374, ptr %l238, !tbaa !21
  br label %bb94
bb94:
  %t375 = load i1, ptr %l238, !tbaa !21
  br i1 %t375, label %bb95, label %bb96
bb95:
  %t376 = load ptr, ptr %l20, !tbaa !29
  %t378 = getelementptr { i64, [6 x i64] }, ptr %t376, i32 0, i32 1
  %t379 = getelementptr { ptr }, ptr %t378, i32 0, i32 0
  %t380 = load ptr, ptr %t379
  store ptr %t380, ptr %l21, !tbaa !29
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load ptr, ptr %l3, !tbaa !29
  %t384 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorVarRules(ptr %v0, ptr %v1, ptr %v1, ptr %t382, ptr %t383, ptr %t384)
  br label %bb98
bb98:
  br label %bb128
bb99:
  %t388 = load ptr, ptr %l20, !tbaa !29
  store ptr %t388, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t389 = load ptr, ptr %l246, !tbaa !29
  %t390 = icmp ne ptr %t389, null
  br i1 %t390, label %bb100, label %bb101
bb100:
  %t392 = load ptr, ptr %l246, !tbaa !29
  %t393 = load i64, ptr %t392, !range !{i64 0, i64 5}
  %t395 = icmp eq i64 %t393, 1
  store i1 %t395, ptr %l247, !tbaa !21
  br label %bb101
bb101:
  %t396 = load i1, ptr %l247, !tbaa !21
  br i1 %t396, label %bb102, label %bb103
bb102:
  %t397 = load ptr, ptr %l20, !tbaa !29
  %t399 = getelementptr { i64, [6 x i64] }, ptr %t397, i32 0, i32 1
  %t400 = getelementptr { { i64, ptr }, ptr }, ptr %t399, i32 0, i32 0
  %t401 = load { i64, ptr }, ptr %t400
  store { i64, ptr } %t401, ptr %l22, !tbaa !27
  br label %bb104
bb103:
  br label %bb123
bb104:
  %t403 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t403, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t405 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t405, 0
  store i64 %t407, ptr %l25, !tbaa !24
  br label %bb105
bb105:
  %t409 = load i64, ptr %l24, !tbaa !24
  %t410 = load i64, ptr %l25, !tbaa !24
  %t413 = icmp slt i64 %t409, %t410
  %t415 = xor i1 %t413, true
  br i1 %t415, label %bb106, label %bb107
bb106:
  br label %bb120
bb107:
  br label %bb108
bb108:
  %t417 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t417, ptr %l259, !tbaa !27
  %t418 = load i64, ptr %l24, !tbaa !24
  %t420 = getelementptr { i64, ptr }, ptr %l259, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr ptr, ptr %t421, i64 %t418
  %t423 = load ptr, ptr %t422, !tbaa !39
  store ptr %t423, ptr %l26, !tbaa !29
  %t425 = load ptr, ptr %l26, !tbaa !29
  %t427 = getelementptr %"compiler/ast:CaseDecl", ptr %t425, i32 0, i32 2
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t428, 0
  %t432 = icmp eq i64 %t430, 0
  br i1 %t432, label %bb109, label %bb110
bb109:
  br label %bb119
bb110:
  br label %bb111
bb111:
  %t434 = load ptr, ptr %l26, !tbaa !29
  %t436 = getelementptr %"compiler/ast:CaseDecl", ptr %t434, i32 0, i32 2
  %t437 = load { i64, ptr }, ptr %t436, !tbaa !27
  store { i64, ptr } %t437, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t439 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t439, 0
  store i64 %t441, ptr %l29, !tbaa !24
  br label %bb112
bb112:
  %t443 = load i64, ptr %l28, !tbaa !24
  %t444 = load i64, ptr %l29, !tbaa !24
  %t447 = icmp slt i64 %t443, %t444
  %t449 = xor i1 %t447, true
  br i1 %t449, label %bb113, label %bb114
bb113:
  br label %bb118
bb114:
  br label %bb115
bb115:
  %t451 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t451, ptr %l274, !tbaa !27
  %t452 = load i64, ptr %l28, !tbaa !24
  %t454 = getelementptr { i64, ptr }, ptr %l274, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = getelementptr ptr, ptr %t455, i64 %t452
  %t457 = load ptr, ptr %t456, !tbaa !39
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/ast:Param", ptr %t457, i32 0, i32 2
  %t463 = load ptr, ptr %t462, !tbaa !29
  %t466 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t459, ptr %t463)
  store i1 %t466, ptr %l280
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t467 = load i64, ptr %l28, !tbaa !24
  %t469 = add i64 %t467, 1
  store i64 %t469, ptr %l28, !tbaa !24
  br label %bb112
bb118:
  br label %bb119
bb119:
  %t471 = load i64, ptr %l24, !tbaa !24
  %t473 = add i64 %t471, 1
  store i64 %t473, ptr %l24, !tbaa !24
  br label %bb105
bb120:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/check:Checker", ptr %t475, i32 0, i32 52
  store ptr %t477, ptr %l286, !tbaa !29
  %t478 = load i32, ptr %l5, !tbaa !23
  %t480 = sext i32 %t478 to i64
  store i64 %t480, ptr %l288, !tbaa !24
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load i32, ptr %l5, !tbaa !23
  %t485 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawTable(ptr %v0, ptr %t481, i32 %t482, i1 true)
  store ptr %t485, ptr %l291
  br label %bb121
bb121:
  %t486 = load ptr, ptr %l286, !tbaa !29
  %t487 = load i64, ptr %l288, !tbaa !24
  %t488 = load ptr, ptr %l291, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fcheck_3arawTable_2_Hfe32448d245bb62a962210add151a121(ptr %v0, ptr %v0, ptr %t486, i64 %t487, ptr %t488)
  br label %bb122
bb122:
  br label %bb128
bb123:
  br i1 true, label %bb124, label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_ae3b040bf00e496e_c2dc96e6bf91aeba)
  unreachable
bb128:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load %"compiler/source:Span", ptr %l2
  %t493 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t489, %"compiler/source:Span" %t490)
  store { i64, ptr } %t493, ptr %l294
  br label %bb129
bb129:
  %t494 = load { i64, ptr }, ptr %l294, !tbaa !27
  store { i64, ptr } %t494, ptr %l31, !tbaa !27
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t496 = load ptr, ptr %l3, !tbaa !29
  %t498 = getelementptr %"compiler/ast:TypeDecl", ptr %t496, i32 0, i32 0
  %t499 = load i32, ptr %t498, !tbaa !23
  %t502 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t495, i32 %t499)
  store { i64, ptr } %t502, ptr %l298
  br label %bb130
bb130:
  %t503 = load { i64, ptr }, ptr %l298, !tbaa !27
  store { i64, ptr } %t503, ptr %l32, !tbaa !27
  %t504 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t505 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t508 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t504, { i64, ptr } %t505)
  %t509 = extractvalue { i32, i64 } %t508, 1
  %t510 = extractvalue { i32, i64 } %t508, 0
  store i32 %t510, ptr %l303
  %t511 = icmp ne i32 %t510, 0
  br i1 %t511, label %bb132, label %ok.512, !prof !99
ok.512:
  store i64 %t509, ptr %l302
  br label %bb131
bb131:
  %t513 = load i64, ptr %l302, !tbaa !24
  store i64 %t513, ptr %l299, !tbaa !24
  br label %bb134
bb132:
  br label %bb133
bb133:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l299, !tbaa !24
  br label %bb134
bb134:
  %t514 = load i64, ptr %l299, !tbaa !24
  store i64 %t514, ptr %l33, !tbaa !24
  %t515 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t516 = load i32, ptr %t515, !tbaa !23
  %t517 = load i64, ptr %l33, !tbaa !24
  %t519 = trunc i64 %t517 to i32
  %t522 = add i32 %t516, %t519
  %t523 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t524 = load i32, ptr %t523, !tbaa !23
  %t525 = load i64, ptr %l33, !tbaa !24
  %t526 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t526, 0
  %t531 = add i64 %t525, %t528
  %t533 = trunc i64 %t531 to i32
  %t536 = add i32 %t524, %t533
  %t539 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t522, i32 %t536)
  store %"compiler/source:Span" %t539, ptr %l315
  br label %bb135
bb135:
  %t540 = load %"compiler/source:Span", ptr %l315
  store %"compiler/source:Span" %t540, ptr %l34
  store i1 false, ptr %l35, !tbaa !21
  %t541 = load ptr, ptr %l3, !tbaa !29
  %t543 = getelementptr %"compiler/ast:TypeDecl", ptr %t541, i32 0, i32 3
  %t544 = load ptr, ptr %t543, !tbaa !29
  store ptr %t544, ptr %l36, !tbaa !29
  %t546 = load ptr, ptr %l36, !tbaa !29
  store ptr %t546, ptr %l318, !tbaa !29
  store i1 false, ptr %l319, !tbaa !21
  %t547 = load ptr, ptr %l318, !tbaa !29
  %t548 = icmp ne ptr %t547, null
  br i1 %t548, label %bb136, label %bb137
bb136:
  %t550 = load ptr, ptr %l318, !tbaa !29
  %t551 = load i64, ptr %t550, !range !{i64 0, i64 5}
  %t553 = icmp eq i64 %t551, 3
  store i1 %t553, ptr %l319, !tbaa !21
  br label %bb137
bb137:
  %t554 = load i1, ptr %l319, !tbaa !21
  br i1 %t554, label %bb138, label %bb139
bb138:
  %t555 = load ptr, ptr %l36, !tbaa !29
  %t557 = getelementptr { i64, [6 x i64] }, ptr %t555, i32 0, i32 1
  %t558 = getelementptr { ptr, ptr }, ptr %t557, i32 0, i32 0
  %t559 = load ptr, ptr %t558
  store ptr %t559, ptr %l37, !tbaa !29
  br label %bb140
bb139:
  br label %bb183
bb140:
  store i1 true, ptr %l35, !tbaa !21
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t563 = getelementptr %"compiler/check:Checker", ptr %t561, i32 0, i32 1
  %t564 = load ptr, ptr %t563, !tbaa !29
  %t565 = load ptr, ptr %l6, !tbaa !29
  %t567 = getelementptr %"compiler/check:frame", ptr %t565, i32 0, i32 4
  %t568 = load ptr, ptr %l37, !tbaa !29
  %t573 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t564, ptr %t567, ptr %t568)
  store i32 %t573, ptr %l330
  br label %bb141
bb141:
  %t574 = load i32, ptr %l330, !tbaa !23
  store i32 %t574, ptr %l38, !tbaa !23
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t576 = load i32, ptr %l38, !tbaa !23
  %t579 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t575, i32 %t576)
  store i1 %t579, ptr %l333
  br label %bb142
bb142:
  %t580 = load i1, ptr %l333, !tbaa !21
  br i1 %t580, label %bb143, label %bb144
bb143:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load i32, ptr %l38, !tbaa !23
  %t585 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t581, i32 %t582)
  store i32 %t585, ptr %l336
  br label %bb145
bb144:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t588 = getelementptr %"compiler/check:Checker", ptr %t586, i32 0, i32 1
  %t589 = load ptr, ptr %t588, !tbaa !29
  %t591 = getelementptr %"compiler/generic:Program", ptr %t589, i32 0, i32 2
  %t592 = load i32, ptr %l38, !tbaa !23
  %t595 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t591, i32 %t592)
  store i32 %t595, ptr %l360
  br label %bb157
bb145:
  %t596 = load i32, ptr %l336, !range !{i32 0, i32 6}
  %t599 = trunc i64 4 to i32
  %t600 = icmp eq i32 %t596, %t599
  %t602 = xor i1 %t600, true
  br i1 %t602, label %bb146, label %bb147
bb146:
  store i1 true, ptr %l340, !tbaa !21
  br label %bb149
bb147:
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = getelementptr %"compiler/check:Checker", ptr %t604, i32 0, i32 1
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t609 = getelementptr %"compiler/generic:Program", ptr %t607, i32 0, i32 2
  %t610 = load i32, ptr %l38, !tbaa !23
  %t613 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t609, i32 %t610)
  store i32 %t613, ptr %l345
  br label %bb148
bb148:
  %t614 = load i32, ptr %l345, !tbaa !23
  %t615 = icmp ne i32 %t614, 0
  store i1 %t615, ptr %l340, !tbaa !21
  br label %bb149
bb149:
  %t617 = load i1, ptr %l340, !tbaa !21
  br i1 %t617, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s32
  %t618 = load ptr, ptr %l0, !tbaa !29
  store ptr %t618, ptr %l347, !tbaa !29
  %t619 = load ptr, ptr %l37, !tbaa !29
  %t621 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t619)
  store %"compiler/source:Span" %t621, ptr %l349
  br label %bb152
bb151:
  br label %bb156
bb152:
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t623 = load i32, ptr %l38, !tbaa !23
  %t626 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s32, ptr %t622, i32 %t623)
  store { i64, ptr } %t626, ptr %l352
  br label %bb153
bb153:
  %t627 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t628 = extractvalue { i64, ptr } %t627, 0
  %t629 = extractvalue { i64, ptr } %t627, 1
  %t630 = mul i64 %t628, 1
  %t631 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t630)
  call void @llvm.memcpy.p0.p0.i64(ptr %t631, ptr %t629, i64 %t630, i1 false)
  %t632 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t633 = insertvalue { i64, ptr } %t632, ptr %t631, 1
  %t635 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredOverAggregate(ptr %s32, ptr %s32, { i64, ptr } %t633)
  store %"compiler/msgs:Msg" %t635, ptr %l354
  br label %bb154
bb154:
  %t636 = load ptr, ptr %l347, !tbaa !29
  %t637 = load %"compiler/source:Span", ptr %l349
  %t638 = load %"compiler/msgs:Msg", ptr %l354
  %t639 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s32, ptr %t636, %"compiler/source:Span" %t637, %"compiler/msgs:Msg" %t638)
  store i64 %t639, ptr %l355
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s32)
  br label %bb156
bb156:
  br label %bb182
bb157:
  %t640 = load i32, ptr %l360, !range !{i32 0, i32 33}
  %t642 = trunc i64 19 to i32
  %t643 = icmp eq i32 %t640, %t642
  br i1 %t643, label %bb158, label %bb159
bb158:
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t646 = load i32, ptr %l5, !tbaa !23
  %t647 = load i32, ptr %l38, !tbaa !23
  %t651 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsSelf(ptr %v0, ptr %t645, i32 %t646, i32 %t647)
  store i1 %t651, ptr %l367
  br label %bb160
bb159:
  store i1 false, ptr %l363, !tbaa !21
  br label %bb161
bb160:
  %t652 = load i1, ptr %l367, !tbaa !21
  store i1 %t652, ptr %l363, !tbaa !21
  br label %bb161
bb161:
  %t653 = load i1, ptr %l363, !tbaa !21
  br i1 %t653, label %bb162, label %bb163
bb162:
  store %olang.scope zeroinitializer, ptr %s34
  %t654 = load ptr, ptr %l0, !tbaa !29
  store ptr %t654, ptr %l368, !tbaa !29
  %t655 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t655, ptr %l369
  %t656 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t656, ptr %l370, !tbaa !27
  %t657 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t657, ptr %l371, !tbaa !27
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t659 = load i32, ptr %l38, !tbaa !23
  %t662 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s34, ptr %t658, i32 %t659)
  store { i64, ptr } %t662, ptr %l374
  br label %bb164
bb163:
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t665 = getelementptr %"compiler/check:Checker", ptr %t663, i32 0, i32 1
  %t666 = load ptr, ptr %t665, !tbaa !29
  %t668 = getelementptr %"compiler/generic:Program", ptr %t666, i32 0, i32 2
  %t669 = load i32, ptr %l38, !tbaa !23
  %t672 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t668, i32 %t669)
  store i32 %t672, ptr %l382
  br label %bb167
bb164:
  %t673 = load { i64, ptr }, ptr %l374, !tbaa !27
  %t674 = extractvalue { i64, ptr } %t673, 0
  %t675 = extractvalue { i64, ptr } %t673, 1
  %t676 = mul i64 %t674, 1
  %t677 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t676)
  call void @llvm.memcpy.p0.p0.i64(ptr %t677, ptr %t675, i64 %t676, i1 false)
  %t678 = insertvalue { i64, ptr } undef, i64 %t674, 0
  %t679 = insertvalue { i64, ptr } %t678, ptr %t677, 1
  %t680 = load { i64, ptr }, ptr %l370, !tbaa !27
  %t681 = load { i64, ptr }, ptr %l371, !tbaa !27
  %t683 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayTypeHoldsItself(ptr %v0, ptr %v0, ptr %s34, ptr %s34, { i64, ptr } %t680, { i64, ptr } %t681, { i64, ptr } %t679)
  store %"compiler/msgs:Msg" %t683, ptr %l376
  br label %bb165
bb165:
  %t684 = load ptr, ptr %l368, !tbaa !29
  %t685 = load %"compiler/source:Span", ptr %l369
  %t686 = load %"compiler/msgs:Msg", ptr %l376
  %t687 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s34, ptr %t684, %"compiler/source:Span" %t685, %"compiler/msgs:Msg" %t686)
  store i64 %t687, ptr %l377
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s34)
  br label %bb181
bb167:
  %t688 = load i32, ptr %l382, !range !{i32 0, i32 33}
  %t690 = trunc i64 19 to i32
  %t691 = icmp eq i32 %t688, %t690
  br i1 %t691, label %bb168, label %bb169
bb168:
  %t693 = load ptr, ptr %l0, !tbaa !29
  store ptr %t693, ptr %l386, !tbaa !29
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t696 = getelementptr %"compiler/check:Checker", ptr %t694, i32 0, i32 1
  %t697 = load ptr, ptr %t696, !tbaa !29
  %t699 = getelementptr %"compiler/generic:Program", ptr %t697, i32 0, i32 2
  %t700 = load i32, ptr %l38, !tbaa !23
  %t703 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t699, i32 %t700)
  store i32 %t703, ptr %l391
  br label %bb170
bb169:
  store i1 false, ptr %l385, !tbaa !21
  br label %bb172
bb170:
  %t704 = load ptr, ptr %l386, !tbaa !29
  %t705 = load i32, ptr %l391, !tbaa !23
  %t706 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t704, i32 %t705)
  store i1 %t706, ptr %l392
  br label %bb171
bb171:
  %t707 = load i1, ptr %l392, !tbaa !21
  store i1 %t707, ptr %l385, !tbaa !21
  br label %bb172
bb172:
  %t708 = load i1, ptr %l385, !tbaa !21
  br i1 %t708, label %bb173, label %bb174
bb173:
  store %olang.scope zeroinitializer, ptr %s36
  %t709 = load ptr, ptr %l0, !tbaa !29
  store ptr %t709, ptr %l393, !tbaa !29
  %t710 = load ptr, ptr %l37, !tbaa !29
  %t712 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t710)
  store %"compiler/source:Span" %t712, ptr %l395
  br label %bb175
bb174:
  br label %bb180
bb175:
  %t713 = load ptr, ptr %l0, !tbaa !29
  store ptr %t713, ptr %l396, !tbaa !29
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t716 = getelementptr %"compiler/check:Checker", ptr %t714, i32 0, i32 1
  %t717 = load ptr, ptr %t716, !tbaa !29
  %t719 = getelementptr %"compiler/generic:Program", ptr %t717, i32 0, i32 2
  %t720 = load i32, ptr %l38, !tbaa !23
  %t723 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t719, i32 %t720)
  store i32 %t723, ptr %l401
  br label %bb176
bb176:
  %t724 = load ptr, ptr %l396, !tbaa !29
  %t725 = load i32, ptr %l401, !tbaa !23
  %t726 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s36, ptr %t724, i32 %t725)
  store { i64, ptr } %t726, ptr %l402
  br label %bb177
bb177:
  %t727 = load { i64, ptr }, ptr %l402, !tbaa !27
  %t728 = extractvalue { i64, ptr } %t727, 0
  %t729 = extractvalue { i64, ptr } %t727, 1
  %t730 = mul i64 %t728, 1
  %t731 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t730)
  call void @llvm.memcpy.p0.p0.i64(ptr %t731, ptr %t729, i64 %t730, i1 false)
  %t732 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t731, 1
  %t735 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %s36, ptr %s36, { i64, ptr } %t733)
  store %"compiler/msgs:Msg" %t735, ptr %l404
  br label %bb178
bb178:
  %t736 = load ptr, ptr %l393, !tbaa !29
  %t737 = load %"compiler/source:Span", ptr %l395
  %t738 = load %"compiler/msgs:Msg", ptr %l404
  %t739 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s36, ptr %t736, %"compiler/source:Span" %t737, %"compiler/msgs:Msg" %t738)
  store i64 %t739, ptr %l405
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s36)
  br label %bb180
bb180:
  br label %bb181
bb181:
  br label %bb182
bb182:
  br label %bb188
bb183:
  br i1 true, label %bb184, label %bb185
bb184:
  br label %bb186
bb185:
  br label %bb187
bb186:
  br label %bb188
bb187:
  call void @__olang_check_failed(ptr @olang_loc_23ed2e0ac54fea2f_24addeed96b3b3b)
  unreachable
bb188:
  %t740 = load ptr, ptr %l3, !tbaa !29
  %t742 = getelementptr %"compiler/ast:TypeDecl", ptr %t740, i32 0, i32 3
  %t743 = load ptr, ptr %t742, !tbaa !29
  store ptr %t743, ptr %l40, !tbaa !29
  %t745 = load ptr, ptr %l40, !tbaa !29
  store ptr %t745, ptr %l408, !tbaa !29
  store i1 false, ptr %l409, !tbaa !21
  %t746 = load ptr, ptr %l408, !tbaa !29
  %t747 = icmp ne ptr %t746, null
  br i1 %t747, label %bb189, label %bb190
bb189:
  %t749 = load ptr, ptr %l408, !tbaa !29
  %t750 = load i64, ptr %t749, !range !{i64 0, i64 5}
  %t752 = icmp eq i64 %t750, 0
  store i1 %t752, ptr %l409, !tbaa !21
  br label %bb190
bb190:
  %t753 = load i1, ptr %l409, !tbaa !21
  br i1 %t753, label %bb191, label %bb192
bb191:
  %t754 = load ptr, ptr %l40, !tbaa !29
  %t756 = getelementptr { i64, [6 x i64] }, ptr %t754, i32 0, i32 1
  %t757 = getelementptr { ptr }, ptr %t756, i32 0, i32 0
  %t758 = load ptr, ptr %t757
  store ptr %t758, ptr %l41, !tbaa !29
  br label %bb193
bb192:
  br label %bb231
bb193:
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t762 = getelementptr %"compiler/check:Checker", ptr %t760, i32 0, i32 1
  %t763 = load ptr, ptr %t762, !tbaa !29
  %t764 = load i32, ptr %l5, !tbaa !23
  %t767 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t763, i32 %t764)
  store i32 %t767, ptr %l417
  br label %bb194
bb194:
  %t768 = load i32, ptr %l417, !tbaa !23
  store i32 %t768, ptr %l42, !tbaa !23
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t771 = getelementptr %"compiler/check:Checker", ptr %t769, i32 0, i32 1
  %t772 = load ptr, ptr %t771, !tbaa !29
  %t774 = getelementptr %"compiler/generic:Program", ptr %t772, i32 0, i32 2
  store ptr %t774, ptr %l420, !tbaa !29
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t777 = getelementptr %"compiler/check:Checker", ptr %t775, i32 0, i32 1
  %t778 = load ptr, ptr %t777, !tbaa !29
  %t780 = getelementptr %"compiler/generic:Program", ptr %t778, i32 0, i32 2
  %t781 = load i32, ptr %l42, !tbaa !23
  %t784 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t780, i32 %t781)
  store i32 %t784, ptr %l425
  br label %bb195
bb195:
  %t785 = load ptr, ptr %l420, !tbaa !29
  %t786 = load i32, ptr %l425, !tbaa !23
  %t787 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t785, i32 %t786)
  store { i64, ptr } %t787, ptr %l426
  br label %bb196
bb196:
  %t788 = load { i64, ptr }, ptr %l426, !tbaa !27
  %t789 = extractvalue { i64, ptr } %t788, 0
  %t791 = icmp eq i64 %t789, 0
  br i1 %t791, label %bb197, label %bb198
bb197:
  %t793 = load ptr, ptr %l0, !tbaa !29
  %t795 = getelementptr %"compiler/check:Checker", ptr %t793, i32 0, i32 1
  %t796 = load ptr, ptr %t795, !tbaa !29
  %t797 = load i32, ptr %l42, !tbaa !23
  %t800 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t796, i32 %t797)
  store i1 %t800, ptr %l433
  br label %bb199
bb198:
  store i1 false, ptr %l429, !tbaa !21
  br label %bb200
bb199:
  %t801 = load i1, ptr %l433, !tbaa !21
  store i1 %t801, ptr %l429, !tbaa !21
  br label %bb200
bb200:
  %t802 = load i1, ptr %l429, !tbaa !21
  br i1 %t802, label %bb201, label %bb202
bb201:
  store %olang.scope zeroinitializer, ptr %s39
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t805 = getelementptr %"compiler/check:Checker", ptr %t803, i32 0, i32 1
  %t806 = load ptr, ptr %t805, !tbaa !29
  %t808 = getelementptr %"compiler/generic:Program", ptr %t806, i32 0, i32 2
  store ptr %t808, ptr %l436, !tbaa !29
  %t809 = load ptr, ptr %l0, !tbaa !29
  %t811 = getelementptr %"compiler/check:Checker", ptr %t809, i32 0, i32 1
  %t812 = load ptr, ptr %t811, !tbaa !29
  %t814 = getelementptr %"compiler/generic:Program", ptr %t812, i32 0, i32 2
  %t815 = load i32, ptr %l42, !tbaa !23
  %t818 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t814, i32 %t815)
  store i32 %t818, ptr %l441
  br label %bb203
bb202:
  br label %bb230
bb203:
  %t819 = load ptr, ptr %l436, !tbaa !29
  %t820 = load i32, ptr %l441, !tbaa !23
  %t821 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t819, i32 %t820)
  store { i64, ptr } %t821, ptr %l442
  br label %bb204
bb204:
  %t822 = load { i64, ptr }, ptr %l442, !tbaa !27
  store { i64, ptr } %t822, ptr %l43, !tbaa !27
  %t823 = load ptr, ptr %l41, !tbaa !29
  %t825 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2efieldSpans(ptr %v1, ptr %s39, ptr %t823)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t825, ptr %l444
  br label %bb205
bb205:
  %t826 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l444
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t826, ptr %l44
  store i64 0, ptr %l45, !tbaa !24
  %t827 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t829 = extractvalue { i64, ptr } %t827, 0
  store i64 %t829, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t831 = load i64, ptr %l46, !tbaa !24
  %t832 = load i64, ptr %l45, !tbaa !24
  %t835 = icmp sgt i64 %t831, %t832
  br i1 %t835, label %bb206, label %bb207
bb206:
  %t837 = load i64, ptr %l47, !tbaa !24
  %t839 = icmp sgt i64 %t837, 0
  br i1 %t839, label %bb208, label %bb209
bb207:
  store i64 0, ptr %l450, !tbaa !24
  br label %bb211
bb208:
  %t841 = load i64, ptr %l46, !tbaa !24
  %t842 = load i64, ptr %l45, !tbaa !24
  %t845 = sub i64 %t841, %t842
  %t846 = load i64, ptr %l47, !tbaa !24
  %t849 = add i64 %t845, %t846
  %t851 = sub i64 %t849, 1
  %t852 = load i64, ptr %l47, !tbaa !24
  %t855 = sdiv i64 %t851, %t852
  store i64 %t855, ptr %l453, !tbaa !24
  br label %bb210
bb209:
  store i64 0, ptr %l453, !tbaa !24
  br label %bb210
bb210:
  %t857 = load i64, ptr %l453, !tbaa !24
  store i64 %t857, ptr %l450, !tbaa !24
  br label %bb211
bb211:
  %t858 = load i64, ptr %l450, !tbaa !24
  store i64 %t858, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb212
bb212:
  %t859 = load i64, ptr %l49, !tbaa !24
  %t860 = load i64, ptr %l48, !tbaa !24
  %t863 = icmp slt i64 %t859, %t860
  %t865 = xor i1 %t863, true
  br i1 %t865, label %bb213, label %bb214
bb213:
  br label %bb229
bb214:
  br label %bb215
bb215:
  %t867 = load i64, ptr %l45, !tbaa !24
  %t868 = load i64, ptr %l49, !tbaa !24
  %t869 = load i64, ptr %l47, !tbaa !24
  %t872 = mul i64 %t868, %t869
  %t875 = add i64 %t867, %t872
  store i64 %t875, ptr %l50, !tbaa !24
  %t877 = load i64, ptr %l50, !tbaa !24
  store i64 %t877, ptr %l471, !tbaa !24
  %t879 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %s39, ptr %l44)
  store i64 %t879, ptr %l473
  br label %bb216
bb216:
  %t880 = load i64, ptr %l471, !tbaa !24
  %t881 = load i64, ptr %l473, !tbaa !24
  %t882 = icmp slt i64 %t880, %t881
  br i1 %t882, label %bb217, label %bb218
bb217:
  %t884 = load ptr, ptr %l0, !tbaa !29
  %t885 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t885, ptr %l477, !tbaa !27
  %t886 = load i64, ptr %l50, !tbaa !24
  %t888 = getelementptr { i64, ptr }, ptr %l477, i32 0, i32 1
  %t889 = load ptr, ptr %t888, !tbaa !27
  %t890 = getelementptr i32, ptr %t889, i64 %t886
  %t891 = load i32, ptr %t890, !tbaa !33
  %t892 = load i32, ptr %l5, !tbaa !23
  %t896 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t884, i32 %t891, i32 %t892, i64 0)
  store i1 %t896, ptr %l481
  br label %bb219
bb218:
  store i1 false, ptr %l475, !tbaa !21
  br label %bb220
bb219:
  %t897 = load i1, ptr %l481, !tbaa !21
  store i1 %t897, ptr %l475, !tbaa !21
  br label %bb220
bb220:
  %t898 = load i1, ptr %l475, !tbaa !21
  br i1 %t898, label %bb221, label %bb222
bb221:
  store %olang.scope zeroinitializer, ptr %s42
  %t899 = load ptr, ptr %l0, !tbaa !29
  store ptr %t899, ptr %l482, !tbaa !29
  %t900 = load i64, ptr %l50, !tbaa !24
  %t903 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s39, ptr %l44, i64 %t900)
  store %"compiler/source:Span" %t903, ptr %l485
  br label %bb223
bb222:
  br label %bb227
bb223:
  %t904 = load ptr, ptr %l0, !tbaa !29
  %t905 = load i32, ptr %l42, !tbaa !23
  %t908 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s42, ptr %t904, i32 %t905)
  store { i64, ptr } %t908, ptr %l488
  br label %bb224
bb224:
  %t909 = load { i64, ptr }, ptr %l488, !tbaa !27
  %t910 = extractvalue { i64, ptr } %t909, 0
  %t911 = extractvalue { i64, ptr } %t909, 1
  %t912 = mul i64 %t910, 1
  %t913 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t912)
  call void @llvm.memcpy.p0.p0.i64(ptr %t913, ptr %t911, i64 %t912, i1 false)
  %t914 = insertvalue { i64, ptr } undef, i64 %t910, 0
  %t915 = insertvalue { i64, ptr } %t914, ptr %t913, 1
  %t917 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %s42, ptr %s42, { i64, ptr } %t915)
  store %"compiler/msgs:Msg" %t917, ptr %l490
  br label %bb225
bb225:
  %t918 = load ptr, ptr %l482, !tbaa !29
  %t919 = load %"compiler/source:Span", ptr %l485
  %t920 = load %"compiler/msgs:Msg", ptr %l490
  %t921 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s42, ptr %t918, %"compiler/source:Span" %t919, %"compiler/msgs:Msg" %t920)
  store i64 %t921, ptr %l491
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s42)
  br label %bb229
bb227:
  br label %bb228
bb228:
  %t922 = load i64, ptr %l49, !tbaa !24
  %t924 = add i64 %t922, 1
  store i64 %t924, ptr %l49, !tbaa !24
  br label %bb212
bb229:
  call void @__olang_scope_close(ptr %s39)
  br label %bb230
bb230:
  br label %bb308
bb231:
  %t926 = load ptr, ptr %l40, !tbaa !29
  store ptr %t926, ptr %l494, !tbaa !29
  store i1 false, ptr %l495, !tbaa !21
  %t927 = load ptr, ptr %l494, !tbaa !29
  %t928 = icmp ne ptr %t927, null
  br i1 %t928, label %bb232, label %bb233
bb232:
  %t930 = load ptr, ptr %l494, !tbaa !29
  %t931 = load i64, ptr %t930, !range !{i64 0, i64 5}
  %t933 = icmp eq i64 %t931, 1
  store i1 %t933, ptr %l495, !tbaa !21
  br label %bb233
bb233:
  %t934 = load i1, ptr %l495, !tbaa !21
  br i1 %t934, label %bb234, label %bb235
bb234:
  %t935 = load ptr, ptr %l40, !tbaa !29
  %t937 = getelementptr { i64, [6 x i64] }, ptr %t935, i32 0, i32 1
  %t938 = getelementptr { { i64, ptr }, ptr }, ptr %t937, i32 0, i32 0
  %t939 = load { i64, ptr }, ptr %t938
  store { i64, ptr } %t939, ptr %l51, !tbaa !27
  br label %bb236
bb235:
  br label %bb303
bb236:
  %t941 = load ptr, ptr %l0, !tbaa !29
  %t943 = getelementptr %"compiler/check:Checker", ptr %t941, i32 0, i32 1
  %t944 = load ptr, ptr %t943, !tbaa !29
  %t945 = load i32, ptr %l5, !tbaa !23
  %t948 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t944, i32 %t945)
  store i32 %t948, ptr %l503
  br label %bb237
bb237:
  %t949 = load i32, ptr %l503, !tbaa !23
  store i32 %t949, ptr %l52, !tbaa !23
  %t950 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t950, ptr %l53, !tbaa !27
  store i64 0, ptr %l54, !tbaa !24
  %t952 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t954 = extractvalue { i64, ptr } %t952, 0
  store i64 %t954, ptr %l55, !tbaa !24
  br label %bb238
bb238:
  %t956 = load i64, ptr %l54, !tbaa !24
  %t957 = load i64, ptr %l55, !tbaa !24
  %t960 = icmp slt i64 %t956, %t957
  %t962 = xor i1 %t960, true
  br i1 %t962, label %bb239, label %bb240
bb239:
  br label %bb274
bb240:
  br label %bb241
bb241:
  %t964 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t964, ptr %l511, !tbaa !27
  %t965 = load i64, ptr %l54, !tbaa !24
  %t967 = getelementptr { i64, ptr }, ptr %l511, i32 0, i32 1
  %t968 = load ptr, ptr %t967, !tbaa !27
  %t969 = getelementptr ptr, ptr %t968, i64 %t965
  %t970 = load ptr, ptr %t969, !tbaa !39
  store ptr %t970, ptr %l56, !tbaa !29
  %t972 = load ptr, ptr %l56, !tbaa !29
  %t974 = getelementptr %"compiler/ast:CaseDecl", ptr %t972, i32 0, i32 2
  %t975 = load { i64, ptr }, ptr %t974, !tbaa !27
  %t977 = extractvalue { i64, ptr } %t975, 0
  %t979 = icmp eq i64 %t977, 0
  br i1 %t979, label %bb242, label %bb243
bb242:
  br label %bb273
bb243:
  br label %bb244
bb244:
  %t981 = load ptr, ptr %l56, !tbaa !29
  %t983 = getelementptr %"compiler/ast:CaseDecl", ptr %t981, i32 0, i32 2
  %t984 = load { i64, ptr }, ptr %t983, !tbaa !27
  store { i64, ptr } %t984, ptr %l57, !tbaa !27
  store i64 0, ptr %l58, !tbaa !24
  %t986 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t988 = extractvalue { i64, ptr } %t986, 0
  store i64 %t988, ptr %l59, !tbaa !24
  br label %bb245
bb245:
  %t990 = load i64, ptr %l58, !tbaa !24
  %t991 = load i64, ptr %l59, !tbaa !24
  %t994 = icmp slt i64 %t990, %t991
  %t996 = xor i1 %t994, true
  br i1 %t996, label %bb246, label %bb247
bb246:
  br label %bb272
bb247:
  br label %bb248
bb248:
  %t998 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t998, ptr %l526, !tbaa !27
  %t999 = load i64, ptr %l58, !tbaa !24
  %t1001 = getelementptr { i64, ptr }, ptr %l526, i32 0, i32 1
  %t1002 = load ptr, ptr %t1001, !tbaa !27
  %t1003 = getelementptr ptr, ptr %t1002, i64 %t999
  %t1004 = load ptr, ptr %t1003, !tbaa !39
  store ptr %t1004, ptr %l60, !tbaa !29
  %t1006 = load ptr, ptr %l60, !tbaa !29
  %t1008 = getelementptr %"compiler/ast:Param", ptr %t1006, i32 0, i32 2
  %t1009 = load ptr, ptr %t1008, !tbaa !29
  %t1011 = icmp eq ptr %t1009, null
  br i1 %t1011, label %bb249, label %bb250
bb249:
  br label %bb271
bb250:
  br label %bb251
bb251:
  %t1013 = load ptr, ptr %l0, !tbaa !29
  %t1015 = getelementptr %"compiler/check:Checker", ptr %t1013, i32 0, i32 1
  %t1016 = load ptr, ptr %t1015, !tbaa !29
  %t1017 = load ptr, ptr %l6, !tbaa !29
  %t1019 = getelementptr %"compiler/check:frame", ptr %t1017, i32 0, i32 4
  %t1020 = load ptr, ptr %l60, !tbaa !29
  %t1022 = getelementptr %"compiler/ast:Param", ptr %t1020, i32 0, i32 2
  %t1023 = load ptr, ptr %t1022, !tbaa !29
  %t1027 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t1016, ptr %t1019, ptr %t1023)
  store i32 %t1027, ptr %l538
  br label %bb252
bb252:
  %t1028 = load i32, ptr %l538, !tbaa !23
  store i32 %t1028, ptr %l61, !tbaa !23
  %t1029 = load ptr, ptr %l0, !tbaa !29
  %t1030 = load i32, ptr %l61, !tbaa !23
  %t1033 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1029, i32 %t1030)
  store i1 %t1033, ptr %l541
  br label %bb253
bb253:
  %t1034 = load i1, ptr %l541, !tbaa !21
  %t1035 = xor i1 %t1034, true
  br i1 %t1035, label %bb254, label %bb255
bb254:
  %t1037 = load ptr, ptr %l0, !tbaa !29
  %t1038 = load i32, ptr %l61, !tbaa !23
  %t1041 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t1037, i32 %t1038)
  store i1 %t1041, ptr %l546
  br label %bb256
bb255:
  store i1 false, ptr %l543, !tbaa !21
  br label %bb257
bb256:
  %t1042 = load i1, ptr %l546, !tbaa !21
  store i1 %t1042, ptr %l543, !tbaa !21
  br label %bb257
bb257:
  %t1043 = load i1, ptr %l543, !tbaa !21
  br i1 %t1043, label %bb258, label %bb259
bb258:
  store %olang.scope zeroinitializer, ptr %s51
  %t1044 = load ptr, ptr %l60, !tbaa !29
  %t1046 = getelementptr %"compiler/ast:Param", ptr %t1044, i32 0, i32 0
  %t1047 = getelementptr %"compiler/source:Span", ptr %t1046, i32 0, i32 0
  %t1048 = load i32, ptr %t1047, !tbaa !23
  store i32 %t1048, ptr %l548, !tbaa !23
  %t1049 = load ptr, ptr %l60, !tbaa !29
  %t1051 = getelementptr %"compiler/ast:Param", ptr %t1049, i32 0, i32 0
  %t1052 = getelementptr %"compiler/source:Span", ptr %t1051, i32 0, i32 0
  %t1053 = load i32, ptr %t1052, !tbaa !23
  store i32 %t1053, ptr %l550, !tbaa !23
  %t1054 = load ptr, ptr %l0, !tbaa !29
  %t1055 = load ptr, ptr %l60, !tbaa !29
  %t1057 = getelementptr %"compiler/ast:Param", ptr %t1055, i32 0, i32 1
  %t1058 = load i32, ptr %t1057, !tbaa !23
  %t1061 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1054, i32 %t1058)
  store { i64, ptr } %t1061, ptr %l554
  br label %bb260
bb259:
  br label %bb270
bb260:
  %t1062 = load { i64, ptr }, ptr %l554, !tbaa !27
  %t1063 = extractvalue { i64, ptr } %t1062, 0
  %t1065 = trunc i64 %t1063 to i32
  %t1066 = load i32, ptr %l550, !tbaa !23
  %t1068 = add i32 %t1066, %t1065
  %t1069 = load i32, ptr %l548, !tbaa !23
  %t1071 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s51, i32 %t1069, i32 %t1068)
  store %"compiler/source:Span" %t1071, ptr %l558
  br label %bb261
bb261:
  %t1072 = load %"compiler/source:Span", ptr %l558
  %t1073 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1073, ptr %l559, !tbaa !29
  store %"compiler/source:Span" %t1072, ptr %l560
  %t1075 = load ptr, ptr %l0, !tbaa !29
  %t1076 = load ptr, ptr %l60, !tbaa !29
  %t1078 = getelementptr %"compiler/ast:Param", ptr %t1076, i32 0, i32 1
  %t1079 = load i32, ptr %t1078, !tbaa !23
  %t1082 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s51, ptr %t1075, i32 %t1079)
  store { i64, ptr } %t1082, ptr %l564
  br label %bb262
bb262:
  %t1083 = load { i64, ptr }, ptr %l564, !tbaa !27
  %t1084 = extractvalue { i64, ptr } %t1083, 0
  %t1085 = extractvalue { i64, ptr } %t1083, 1
  %t1086 = mul i64 %t1084, 1
  %t1087 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1086)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1087, ptr %t1085, i64 %t1086, i1 false)
  %t1088 = insertvalue { i64, ptr } undef, i64 %t1084, 0
  %t1089 = insertvalue { i64, ptr } %t1088, ptr %t1087, 1
  store { i64, ptr } %t1089, ptr %l565, !tbaa !27
  %t1090 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1090, ptr %l566, !tbaa !29
  %t1091 = load ptr, ptr %l60, !tbaa !29
  %t1093 = getelementptr %"compiler/ast:Param", ptr %t1091, i32 0, i32 2
  %t1094 = load ptr, ptr %t1093, !tbaa !29
  %t1096 = icmp eq ptr %t1094, null
  br i1 %t1096, label %bb263, label %bb264
bb263:
  call void @__olang_check_failed(ptr @olang_loc_ce02ed0312eba71_989ffc88692334e5)
  unreachable
bb264:
  br label %bb265
bb265:
  %t1098 = load ptr, ptr %l60, !tbaa !29
  %t1100 = getelementptr %"compiler/ast:Param", ptr %t1098, i32 0, i32 2
  %t1101 = load ptr, ptr %t1100, !tbaa !29
  %t1103 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t1101)
  store %"compiler/source:Span" %t1103, ptr %l572
  br label %bb266
bb266:
  %t1104 = load ptr, ptr %l566, !tbaa !29
  %t1105 = load %"compiler/source:Span", ptr %l572
  %t1106 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t1104, %"compiler/source:Span" %t1105)
  store { i64, ptr } %t1106, ptr %l573
  br label %bb267
bb267:
  %t1107 = load { i64, ptr }, ptr %l565, !tbaa !27
  %t1108 = load { i64, ptr }, ptr %l573, !tbaa !27
  %t1109 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %s51, ptr %v0, ptr %s51, { i64, ptr } %t1107, { i64, ptr } %t1108)
  store %"compiler/msgs:Msg" %t1109, ptr %l574
  br label %bb268
bb268:
  %t1110 = load ptr, ptr %l559, !tbaa !29
  %t1111 = load %"compiler/source:Span", ptr %l560
  %t1112 = load %"compiler/msgs:Msg", ptr %l574
  %t1113 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s51, ptr %t1110, %"compiler/source:Span" %t1111, %"compiler/msgs:Msg" %t1112)
  store i64 %t1113, ptr %l575
  br label %bb269
bb269:
  call void @__olang_scope_close(ptr %s51)
  br label %bb270
bb270:
  br label %bb271
bb271:
  %t1114 = load i64, ptr %l58, !tbaa !24
  %t1116 = add i64 %t1114, 1
  store i64 %t1116, ptr %l58, !tbaa !24
  br label %bb245
bb272:
  br label %bb273
bb273:
  %t1118 = load i64, ptr %l54, !tbaa !24
  %t1120 = add i64 %t1118, 1
  store i64 %t1120, ptr %l54, !tbaa !24
  br label %bb238
bb274:
  store i1 false, ptr %l63, !tbaa !21
  %t1122 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t1122, ptr %l64, !tbaa !27
  store i64 0, ptr %l65, !tbaa !24
  %t1124 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t1126 = extractvalue { i64, ptr } %t1124, 0
  store i64 %t1126, ptr %l66, !tbaa !24
  br label %bb275
bb275:
  %t1128 = load i64, ptr %l65, !tbaa !24
  %t1129 = load i64, ptr %l66, !tbaa !24
  %t1132 = icmp slt i64 %t1128, %t1129
  %t1134 = xor i1 %t1132, true
  br i1 %t1134, label %bb276, label %bb277
bb276:
  br label %bb302
bb277:
  br label %bb278
bb278:
  %t1136 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t1136, ptr %l587, !tbaa !27
  %t1137 = load i64, ptr %l65, !tbaa !24
  %t1139 = getelementptr { i64, ptr }, ptr %l587, i32 0, i32 1
  %t1140 = load ptr, ptr %t1139, !tbaa !27
  %t1141 = getelementptr ptr, ptr %t1140, i64 %t1137
  %t1142 = load ptr, ptr %t1141, !tbaa !39
  store ptr %t1142, ptr %l67, !tbaa !29
  %t1144 = load i1, ptr %l63, !tbaa !21
  br i1 %t1144, label %bb279, label %bb280
bb279:
  store i1 true, ptr %l591, !tbaa !21
  br label %bb281
bb280:
  %t1146 = load ptr, ptr %l67, !tbaa !29
  %t1148 = getelementptr %"compiler/ast:CaseDecl", ptr %t1146, i32 0, i32 2
  %t1149 = load { i64, ptr }, ptr %t1148, !tbaa !27
  %t1151 = extractvalue { i64, ptr } %t1149, 0
  %t1153 = icmp eq i64 %t1151, 0
  store i1 %t1153, ptr %l591, !tbaa !21
  br label %bb281
bb281:
  %t1155 = load i1, ptr %l591, !tbaa !21
  br i1 %t1155, label %bb282, label %bb283
bb282:
  br label %bb301
bb283:
  br label %bb284
bb284:
  %t1156 = load ptr, ptr %l67, !tbaa !29
  %t1158 = getelementptr %"compiler/ast:CaseDecl", ptr %t1156, i32 0, i32 2
  %t1159 = load { i64, ptr }, ptr %t1158, !tbaa !27
  store { i64, ptr } %t1159, ptr %l68, !tbaa !27
  store i64 0, ptr %l69, !tbaa !24
  %t1161 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t1163 = extractvalue { i64, ptr } %t1161, 0
  store i64 %t1163, ptr %l70, !tbaa !24
  br label %bb285
bb285:
  %t1165 = load i64, ptr %l69, !tbaa !24
  %t1166 = load i64, ptr %l70, !tbaa !24
  %t1169 = icmp slt i64 %t1165, %t1166
  %t1171 = xor i1 %t1169, true
  br i1 %t1171, label %bb286, label %bb287
bb286:
  br label %bb300
bb287:
  br label %bb288
bb288:
  %t1173 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t1173, ptr %l604, !tbaa !27
  %t1174 = load i64, ptr %l69, !tbaa !24
  %t1176 = getelementptr { i64, ptr }, ptr %l604, i32 0, i32 1
  %t1177 = load ptr, ptr %t1176, !tbaa !27
  %t1178 = getelementptr ptr, ptr %t1177, i64 %t1174
  %t1179 = load ptr, ptr %t1178, !tbaa !39
  store ptr %t1179, ptr %l71, !tbaa !29
  %t1181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1181, ptr %l607, !tbaa !29
  %t1182 = load ptr, ptr %l0, !tbaa !29
  %t1184 = getelementptr %"compiler/check:Checker", ptr %t1182, i32 0, i32 1
  %t1185 = load ptr, ptr %t1184, !tbaa !29
  %t1186 = load ptr, ptr %l6, !tbaa !29
  %t1188 = getelementptr %"compiler/check:frame", ptr %t1186, i32 0, i32 4
  %t1189 = load ptr, ptr %l71, !tbaa !29
  %t1191 = getelementptr %"compiler/ast:Param", ptr %t1189, i32 0, i32 2
  %t1192 = load ptr, ptr %t1191, !tbaa !29
  %t1196 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t1185, ptr %t1188, ptr %t1192)
  store i32 %t1196, ptr %l614
  br label %bb289
bb289:
  %t1197 = load i32, ptr %l5, !tbaa !23
  %t1198 = load ptr, ptr %l607, !tbaa !29
  %t1199 = load i32, ptr %l614, !tbaa !23
  %t1201 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t1198, i32 %t1199, i32 %t1197, i64 0)
  store i1 %t1201, ptr %l616
  br label %bb290
bb290:
  %t1202 = load i1, ptr %l616, !tbaa !21
  br i1 %t1202, label %bb291, label %bb292
bb291:
  store %olang.scope zeroinitializer, ptr %s59
  %t1203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1203, ptr %l617, !tbaa !29
  %t1204 = load ptr, ptr %l71, !tbaa !29
  %t1206 = getelementptr %"compiler/ast:Param", ptr %t1204, i32 0, i32 0
  %t1207 = getelementptr %"compiler/source:Span", ptr %t1206, i32 0, i32 0
  %t1208 = load i32, ptr %t1207, !tbaa !23
  store i32 %t1208, ptr %l619, !tbaa !23
  %t1209 = load ptr, ptr %l71, !tbaa !29
  %t1211 = getelementptr %"compiler/ast:Param", ptr %t1209, i32 0, i32 0
  %t1212 = getelementptr %"compiler/source:Span", ptr %t1211, i32 0, i32 0
  %t1213 = load i32, ptr %t1212, !tbaa !23
  store i32 %t1213, ptr %l621, !tbaa !23
  %t1214 = load ptr, ptr %l0, !tbaa !29
  %t1215 = load ptr, ptr %l71, !tbaa !29
  %t1217 = getelementptr %"compiler/ast:Param", ptr %t1215, i32 0, i32 1
  %t1218 = load i32, ptr %t1217, !tbaa !23
  %t1221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1214, i32 %t1218)
  store { i64, ptr } %t1221, ptr %l625
  br label %bb293
bb292:
  br label %bb298
bb293:
  %t1222 = load { i64, ptr }, ptr %l625, !tbaa !27
  %t1223 = extractvalue { i64, ptr } %t1222, 0
  %t1225 = trunc i64 %t1223 to i32
  %t1226 = load i32, ptr %l621, !tbaa !23
  %t1228 = add i32 %t1226, %t1225
  %t1229 = load i32, ptr %l619, !tbaa !23
  %t1231 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s59, i32 %t1229, i32 %t1228)
  store %"compiler/source:Span" %t1231, ptr %l629
  br label %bb294
bb294:
  %t1232 = load ptr, ptr %l0, !tbaa !29
  %t1233 = load i32, ptr %l52, !tbaa !23
  %t1236 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s59, ptr %t1232, i32 %t1233)
  store { i64, ptr } %t1236, ptr %l632
  br label %bb295
bb295:
  %t1237 = load { i64, ptr }, ptr %l632, !tbaa !27
  %t1238 = extractvalue { i64, ptr } %t1237, 0
  %t1239 = extractvalue { i64, ptr } %t1237, 1
  %t1240 = mul i64 %t1238, 1
  %t1241 = call ptr @__olang_scope_alloc(ptr %s59, i64 %t1240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1241, ptr %t1239, i64 %t1240, i1 false)
  %t1242 = insertvalue { i64, ptr } undef, i64 %t1238, 0
  %t1243 = insertvalue { i64, ptr } %t1242, ptr %t1241, 1
  %t1245 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %s59, ptr %s59, { i64, ptr } %t1243)
  store %"compiler/msgs:Msg" %t1245, ptr %l634
  br label %bb296
bb296:
  %t1246 = load ptr, ptr %l617, !tbaa !29
  %t1247 = load %"compiler/source:Span", ptr %l629
  %t1248 = load %"compiler/msgs:Msg", ptr %l634
  %t1249 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s59, ptr %t1246, %"compiler/source:Span" %t1247, %"compiler/msgs:Msg" %t1248)
  store i64 %t1249, ptr %l635
  br label %bb297
bb297:
  store i1 true, ptr %l63, !tbaa !21
  call void @__olang_scope_close(ptr %s59)
  br label %bb300
bb298:
  br label %bb299
bb299:
  %t1250 = load i64, ptr %l69, !tbaa !24
  %t1252 = add i64 %t1250, 1
  store i64 %t1252, ptr %l69, !tbaa !24
  br label %bb285
bb300:
  br label %bb301
bb301:
  %t1254 = load i64, ptr %l65, !tbaa !24
  %t1256 = add i64 %t1254, 1
  store i64 %t1256, ptr %l65, !tbaa !24
  br label %bb275
bb302:
  br label %bb308
bb303:
  br i1 true, label %bb304, label %bb305
bb304:
  br label %bb306
bb305:
  br label %bb307
bb306:
  br label %bb308
bb307:
  call void @__olang_check_failed(ptr @olang_loc_7c3b8624efb20ec9_1268f42db05aedcd)
  unreachable
bb308:
  %t1258 = load ptr, ptr %l3, !tbaa !29
  %t1260 = getelementptr %"compiler/ast:TypeDecl", ptr %t1258, i32 0, i32 2
  %t1261 = load i1, ptr %t1260, !tbaa !21
  br i1 %t1261, label %bb309, label %bb310
bb309:
  %t1263 = load i1, ptr %l35, !tbaa !21
  %t1265 = xor i1 %t1263, true
  store i1 %t1265, ptr %l642, !tbaa !21
  br label %bb311
bb310:
  store i1 false, ptr %l642, !tbaa !21
  br label %bb311
bb311:
  %t1267 = load i1, ptr %l642, !tbaa !21
  br i1 %t1267, label %bb312, label %bb313
bb312:
  store %olang.scope zeroinitializer, ptr %s63
  %t1268 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1270 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s63, { i64, ptr } %t1268, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d57, i32 0, i32 1) })
  %t1271 = extractvalue { i32, i64 } %t1270, 1
  %t1272 = extractvalue { i32, i64 } %t1270, 0
  store i32 %t1272, ptr %l648
  %t1273 = icmp ne i32 %t1272, 0
  br i1 %t1273, label %bb315, label %ok.1274, !prof !99
ok.1274:
  store i64 %t1271, ptr %l647
  br label %bb314
bb313:
  br label %bb321
bb314:
  %t1275 = load i64, ptr %l647, !tbaa !24
  store i64 %t1275, ptr %l645, !tbaa !24
  br label %bb317
bb315:
  br label %bb316
bb316:
  call void @__olang_ert_req_clear()
  %t1276 = load i64, ptr %l33, !tbaa !24
  store i64 %t1276, ptr %l645, !tbaa !24
  br label %bb317
bb317:
  %t1278 = load i64, ptr %l645, !tbaa !24
  store i64 %t1278, ptr %l72, !tbaa !24
  %t1279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1279, ptr %l650, !tbaa !29
  %t1280 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t1281 = load i32, ptr %t1280, !tbaa !23
  %t1282 = load i64, ptr %l72, !tbaa !24
  %t1284 = trunc i64 %t1282 to i32
  %t1287 = add i32 %t1281, %t1284
  %t1288 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t1289 = load i32, ptr %t1288, !tbaa !23
  %t1290 = load i64, ptr %l72, !tbaa !24
  %t1292 = add i64 %t1290, 7
  %t1294 = trunc i64 %t1292 to i32
  %t1297 = add i32 %t1289, %t1294
  %t1300 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s63, i32 %t1287, i32 %t1297)
  store %"compiler/source:Span" %t1300, ptr %l660
  br label %bb318
bb318:
  %t1301 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExtendsNotBase(ptr %s63)
  store %"compiler/msgs:Msg" %t1301, ptr %l661
  br label %bb319
bb319:
  %t1302 = load ptr, ptr %l650, !tbaa !29
  %t1303 = load %"compiler/source:Span", ptr %l660
  %t1304 = load %"compiler/msgs:Msg", ptr %l661
  %t1305 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s63, ptr %t1302, %"compiler/source:Span" %t1303, %"compiler/msgs:Msg" %t1304)
  store i64 %t1305, ptr %l662
  br label %bb320
bb320:
  call void @__olang_scope_close(ptr %s63)
  br label %bb321
bb321:
  %t1306 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t1306)
  br label %bb322
bb322:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolled(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:reflList"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, i64, i64 }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca { i64, i64, i64 }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l35 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/msgs:Msg"
  %l41 = alloca i64
  %l42 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l54 = alloca { i64, i64, i64 }
  %l59 = alloca ptr
  %l68 = alloca i64
  %l71 = alloca i64
  %l91 = alloca i64
  %l95 = alloca { i64, i64, i64 }
  %l100 = alloca ptr
  %l104 = alloca ptr
  %l106 = alloca i32
  %l111 = alloca i32
  %l112 = alloca i32
  %l113 = alloca ptr
  %l115 = alloca i32
  %l118 = alloca ptr
  %l120 = alloca i32
  %l122 = alloca i32
  %l123 = alloca i32
  %l147 = alloca i64
  %l149 = alloca ptr
  %l152 = alloca i64
  %l153 = alloca i32
  %l159 = alloca ptr
  %l162 = alloca i64
  %l166 = alloca { i64, i64, i64 }
  %l183 = alloca ptr
  %l201 = alloca i64
  %l203 = alloca ptr
  %l206 = alloca i64
  %l207 = alloca i32
  %l213 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t234 = alloca { i64, [3 x i64] }, align 8
  %t301 = alloca { i64, [3 x i64] }, align 8
  %t332 = alloca { i64, [3 x i64] }, align 8
  %t356 = alloca { i64, [3 x i64] }, align 8
  %t398 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/check:reflList" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t3 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = add i32 %t4, 3
  %t9 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t2, i32 %t6)
  store %"compiler/source:Span" %t9, ptr %l35
  br label %bb1
bb1:
  %t10 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t10, ptr %l4
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:ForIn", ptr %t11, i32 0, i32 3
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l38, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t17, ptr %l39
  %t18 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflTryList(ptr %s1)
  store %"compiler/msgs:Msg" %t18, ptr %l40
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t19 = load ptr, ptr %l38, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l39
  %t21 = load %"compiler/msgs:Msg", ptr %l40
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t19, %"compiler/source:Span" %t20, %"compiler/msgs:Msg" %t21)
  store i64 %t22, ptr %l41
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l42, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:ForIn", ptr %t24, i32 0, i32 2
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t27)
  store %"compiler/source:Span" %t29, ptr %l45
  br label %bb7
bb7:
  %t30 = load %"compiler/check:reflList", ptr %l3
  %t31 = load ptr, ptr %l42, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l45
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %s0, ptr %t31, %"compiler/source:Span" %t32, %"compiler/check:reflList" %t30)
  store { i64, ptr } %t34, ptr %l47
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 37
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l50
  br label %bb9
bb9:
  %t41 = load i64, ptr %l50, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  %t47 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t42, i32 2, %"compiler/source:Span" %t43)
  store { i64, i64, i64 } %t47, ptr %l54
  br label %bb10
bb10:
  %t48 = load { i64, i64, i64 }, ptr %l54
  store { i64, i64, i64 } %t48, ptr %l7
  %t49 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t50 = load i64, ptr %t49, !tbaa !24
  store i64 %t50, ptr %l8, !tbaa !24
  %t52 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t58)
  store ptr %t60, ptr %l59
  br label %bb11
bb11:
  %t61 = load ptr, ptr %l59, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 11
  %t64 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  br label %bb12
bb12:
  store i64 0, ptr %l11, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t71 = load i64, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb13, label %bb14
bb13:
  %t77 = load i64, ptr %l13, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb18
bb15:
  %t81 = load i64, ptr %l12, !tbaa !24
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = sub i64 %t81, %t82
  %t86 = load i64, ptr %l13, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = sub i64 %t89, 1
  %t92 = load i64, ptr %l13, !tbaa !24
  %t95 = sdiv i64 %t91, %t92
  store i64 %t95, ptr %l71, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb17
bb17:
  %t97 = load i64, ptr %l71, !tbaa !24
  store i64 %t97, ptr %l68, !tbaa !24
  br label %bb18
bb18:
  %t98 = load i64, ptr %l68, !tbaa !24
  store i64 %t98, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb19
bb19:
  %t99 = load i64, ptr %l15, !tbaa !24
  %t100 = load i64, ptr %l14, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb20, label %bb21
bb20:
  br label %bb51
bb21:
  br label %bb22
bb22:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l15, !tbaa !24
  %t109 = load i64, ptr %l13, !tbaa !24
  %t112 = mul i64 %t108, %t109
  %t115 = add i64 %t107, %t112
  store i64 %t115, ptr %l16, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 37
  %t121 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t119)
  store i64 %t121, ptr %l91
  br label %bb23
bb23:
  %t122 = load i64, ptr %l91, !tbaa !24
  store i64 %t122, ptr %l17, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t128 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t123, i32 2, %"compiler/source:Span" %t124)
  store { i64, i64, i64 } %t128, ptr %l95
  br label %bb24
bb24:
  %t129 = load { i64, i64, i64 }, ptr %l95
  store { i64, i64, i64 } %t129, ptr %l18
  %t130 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 0
  %t131 = load i64, ptr %t130, !tbaa !24
  store i64 %t131, ptr %l19, !tbaa !24
  %t133 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 1
  %t134 = load i64, ptr %t133, !tbaa !24
  store i64 %t134, ptr %l20, !tbaa !24
  %t136 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 2
  %t137 = load i64, ptr %t136, !tbaa !24
  store i64 %t137, ptr %l21, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t139)
  store ptr %t141, ptr %l100
  br label %bb25
bb25:
  %t142 = load ptr, ptr %l100, !tbaa !29
  %t144 = getelementptr %"compiler/check:frame", ptr %t142, i32 0, i32 10
  %t145 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t144, i64 %t145)
  br label %bb26
bb26:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l104, !tbaa !29
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t151 = getelementptr %"compiler/ast:ForIn", ptr %t149, i32 0, i32 1
  %t152 = load i32, ptr %t151, !tbaa !23
  store i32 %t152, ptr %l106, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load %"compiler/check:reflList", ptr %l3
  %t155 = load i64, ptr %l16, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i64, ptr %t158, i64 %t155
  %t160 = load i64, ptr %t159, !tbaa !34
  %t164 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t153, %"compiler/check:reflList" %t154, i64 %t160)
  store i32 %t164, ptr %l111
  br label %bb27
bb27:
  %t165 = load ptr, ptr %l104, !tbaa !29
  %t166 = load i32, ptr %l106, !tbaa !23
  %t167 = load i32, ptr %l111, !tbaa !23
  %t168 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t165, i32 %t166, i32 %t167)
  store i32 %t168, ptr %l112
  br label %bb28
bb28:
  %t169 = load i32, ptr %l112, !tbaa !23
  store i32 %t169, ptr %l22, !tbaa !23
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l113, !tbaa !29
  %t171 = load ptr, ptr %l2, !tbaa !29
  %t173 = getelementptr %"compiler/ast:ForIn", ptr %t171, i32 0, i32 0
  %t174 = load i32, ptr %t173, !tbaa !23
  store i32 %t174, ptr %l115, !tbaa !23
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  store ptr %t180, ptr %l118, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t181)
  store i32 %t183, ptr %l120
  br label %bb29
bb29:
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load ptr, ptr %l118, !tbaa !29
  %t186 = load i32, ptr %l120, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t185, i32 %t186, i64 %t184)
  store i32 %t188, ptr %l122
  br label %bb30
bb30:
  %t189 = load ptr, ptr %l113, !tbaa !29
  %t190 = load i32, ptr %l115, !tbaa !23
  %t191 = load i32, ptr %l122, !tbaa !23
  %t192 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t189, i32 %t190, i32 %t191)
  store i32 %t192, ptr %l123
  br label %bb31
bb31:
  %t193 = load i32, ptr %l123, !tbaa !23
  store i32 %t193, ptr %l23, !tbaa !23
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t196 = getelementptr %"compiler/ast:ForIn", ptr %t194, i32 0, i32 4
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t201 = icmp sgt i64 %t199, 0
  br i1 %t201, label %bb32, label %bb33
bb32:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t206 = getelementptr %"compiler/ast:ForIn", ptr %t204, i32 0, i32 4
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t203, { i64, ptr } %t207)
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load ptr, ptr %l2, !tbaa !29
  %t213 = getelementptr %"compiler/ast:ForIn", ptr %t211, i32 0, i32 0
  %t214 = load i32, ptr %t213, !tbaa !23
  %t215 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t210, i32 %t214, i32 %t215)
  br label %bb36
bb36:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l2, !tbaa !29
  %t222 = getelementptr %"compiler/ast:ForIn", ptr %t220, i32 0, i32 1
  %t223 = load i32, ptr %t222, !tbaa !23
  %t224 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t219, i32 %t223, i32 %t224)
  br label %bb37
bb37:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l1
  %t230 = load i64, ptr %l19, !tbaa !24
  %t232 = trunc i64 %t230 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t234
  %t235 = getelementptr { i64, [3 x i64] }, ptr %t234, i32 0, i32 0
  store i64 5, ptr %t235
  %t237 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t229, 0
  %t239 = insertvalue { %"compiler/source:Span", i32, i32 } %t237, i32 0, 1
  %t241 = insertvalue { %"compiler/source:Span", i32, i32 } %t239, i32 %t232, 2
  %t242 = getelementptr { i64, [3 x i64] }, ptr %t234, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t241, ptr %t242
  %t243 = load { i64, [3 x i64] }, ptr %t234
  %t245 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t243, ptr %t245
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t228, ptr %t245)
  br label %bb38
bb38:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t248)
  store ptr %t250, ptr %l149
  br label %bb39
bb39:
  %t251 = load ptr, ptr %l149, !tbaa !29
  %t253 = getelementptr %"compiler/check:frame", ptr %t251, i32 0, i32 10
  %t255 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t253)
  %t256 = extractvalue { i32, i64 } %t255, 1
  %t257 = extractvalue { i32, i64 } %t255, 0
  store i32 %t257, ptr %l153
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb41, label %ok.259, !prof !99
ok.259:
  store i64 %t256, ptr %l152
  br label %bb40
bb40:
  %t260 = load i64, ptr %l152, !tbaa !24
  store i64 %t260, ptr %l147, !tbaa !24
  br label %bb43
bb41:
  br label %bb42
bb42:
  call void @__olang_ert_req_clear()
  br label %bb43
bb43:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i64, ptr %l19, !tbaa !24
  %t263 = load i64, ptr %l20, !tbaa !24
  %t264 = load i64, ptr %l21, !tbaa !24
  %t265 = load i64, ptr %l17, !tbaa !24
  %t271 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t261, i64 %t262, i64 %t263, i64 %t264, i64 %t265)
  store ptr %t271, ptr %l159
  br label %bb44
bb44:
  %t272 = load ptr, ptr %l159, !tbaa !29
  store ptr %t272, ptr %l24, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 37
  %t277 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t275)
  store i64 %t277, ptr %l162
  br label %bb45
bb45:
  %t278 = load i64, ptr %l162, !tbaa !24
  store i64 %t278, ptr %l25, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  %t284 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t279, i32 3, %"compiler/source:Span" %t280)
  store { i64, i64, i64 } %t284, ptr %l166
  br label %bb46
bb46:
  %t285 = load { i64, i64, i64 }, ptr %l166
  store { i64, i64, i64 } %t285, ptr %l26
  %t286 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 0
  %t287 = load i64, ptr %t286, !tbaa !24
  store i64 %t287, ptr %l27, !tbaa !24
  %t289 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 1
  %t290 = load i64, ptr %t289, !tbaa !24
  store i64 %t290, ptr %l28, !tbaa !24
  %t292 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 2
  %t293 = load i64, ptr %t292, !tbaa !24
  store i64 %t293, ptr %l29, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l1
  %t297 = load i64, ptr %l19, !tbaa !24
  %t299 = trunc i64 %t297 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t301
  %t302 = getelementptr { i64, [3 x i64] }, ptr %t301, i32 0, i32 0
  store i64 5, ptr %t302
  %t304 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t296, 0
  %t306 = insertvalue { %"compiler/source:Span", i32, i32 } %t304, i32 0, 1
  %t308 = insertvalue { %"compiler/source:Span", i32, i32 } %t306, i32 %t299, 2
  %t309 = getelementptr { i64, [3 x i64] }, ptr %t301, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t308, ptr %t309
  %t310 = load { i64, [3 x i64] }, ptr %t301
  %t312 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t310, ptr %t312
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t295, ptr %t312)
  br label %bb47
bb47:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load i64, ptr %l27, !tbaa !24
  %t317 = load i64, ptr %l28, !tbaa !24
  %t318 = load i64, ptr %l29, !tbaa !24
  %t319 = load i64, ptr %l25, !tbaa !24
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t315, i64 %t316, i64 %t317, i64 %t318, i64 %t319)
  store ptr %t325, ptr %l183
  br label %bb48
bb48:
  %t326 = load ptr, ptr %l183, !tbaa !29
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load %"compiler/source:Span", ptr %l1
  %t329 = load ptr, ptr %l24, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t332
  %t333 = getelementptr { i64, [3 x i64] }, ptr %t332, i32 0, i32 0
  store i64 4, ptr %t333
  %t335 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t328, 0
  %t337 = insertvalue { %"compiler/source:Span", ptr, ptr } %t335, ptr %t329, 1
  %t339 = insertvalue { %"compiler/source:Span", ptr, ptr } %t337, ptr %t326, 2
  %t340 = getelementptr { i64, [3 x i64] }, ptr %t332, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t339, ptr %t340
  %t341 = load { i64, [3 x i64] }, ptr %t332
  %t343 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t341, ptr %t343
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t327, ptr %t343)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t346 = load i64, ptr %l15, !tbaa !24
  %t348 = add i64 %t346, 1
  store i64 %t348, ptr %l15, !tbaa !24
  br label %bb19
bb51:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load %"compiler/source:Span", ptr %l1
  %t352 = load i64, ptr %l8, !tbaa !24
  %t354 = trunc i64 %t352 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t356
  %t357 = getelementptr { i64, [3 x i64] }, ptr %t356, i32 0, i32 0
  store i64 5, ptr %t357
  %t359 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t351, 0
  %t361 = insertvalue { %"compiler/source:Span", i32, i32 } %t359, i32 0, 1
  %t363 = insertvalue { %"compiler/source:Span", i32, i32 } %t361, i32 %t354, 2
  %t364 = getelementptr { i64, [3 x i64] }, ptr %t356, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t363, ptr %t364
  %t365 = load { i64, [3 x i64] }, ptr %t356
  %t367 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t365, ptr %t367
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t350, ptr %t367)
  br label %bb52
bb52:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t370)
  store ptr %t372, ptr %l203
  br label %bb53
bb53:
  %t373 = load ptr, ptr %l203, !tbaa !29
  %t375 = getelementptr %"compiler/check:frame", ptr %t373, i32 0, i32 11
  %t377 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t375)
  %t378 = extractvalue { i32, i64 } %t377, 1
  %t379 = extractvalue { i32, i64 } %t377, 0
  store i32 %t379, ptr %l207
  %t380 = icmp ne i32 %t379, 0
  br i1 %t380, label %bb55, label %ok.381, !prof !99
ok.381:
  store i64 %t378, ptr %l206
  br label %bb54
bb54:
  %t382 = load i64, ptr %l206, !tbaa !24
  store i64 %t382, ptr %l201, !tbaa !24
  br label %bb57
bb55:
  br label %bb56
bb56:
  call void @__olang_ert_req_clear()
  br label %bb57
bb57:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load i64, ptr %l8, !tbaa !24
  %t385 = load i64, ptr %l9, !tbaa !24
  %t386 = load i64, ptr %l10, !tbaa !24
  %t387 = load i64, ptr %l6, !tbaa !24
  %t393 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t383, i64 %t384, i64 %t385, i64 %t386, i64 %t387)
  store ptr %t393, ptr %l213
  br label %bb58
bb58:
  %t394 = load ptr, ptr %l213, !tbaa !29
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t398
  %t399 = getelementptr { i64, [3 x i64] }, ptr %t398, i32 0, i32 0
  store i64 4, ptr %t399
  %t401 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t396, 0
  %t403 = insertvalue { %"compiler/source:Span", ptr, ptr } %t401, ptr %t394, 1
  %t404 = insertvalue { %"compiler/source:Span", ptr, ptr } %t403, ptr null, 2
  %t405 = getelementptr { i64, [3 x i64] }, ptr %t398, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t404, ptr %t405
  %t406 = load { i64, [3 x i64] }, ptr %t398
  %t408 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t406, ptr %t408
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t395, ptr %t408)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %lp15 = alloca ptr
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca i64
  %l56 = alloca ptr
  %l60 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca %"compiler/typed:Block"
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca %"compiler/typed:If"
  %l75 = alloca %"compiler/source:Span"
  %l80 = alloca i32
  %l84 = alloca { i64, ptr }
  %l85 = alloca %"compiler/source:Span"
  %l90 = alloca i32
  %l95 = alloca %"compiler/typed:Seq"
  %l101 = alloca i64
  %l107 = alloca i64
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca i32
  %l123 = alloca i32
  %l127 = alloca ptr
  %l131 = alloca ptr
  %l133 = alloca ptr
  %l136 = alloca i64
  %l144 = alloca ptr
  %l148 = alloca i32
  %l152 = alloca { i64, ptr }
  %l153 = alloca %"compiler/typed:Block"
  %l155 = alloca ptr
  %l156 = alloca %"compiler/source:Span"
  %l159 = alloca %"compiler/typed:If"
  %l163 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l165 = alloca %"compiler/source:Span"
  %l170 = alloca i32
  %l176 = alloca ptr
  %l177 = alloca %"compiler/source:Span"
  %l182 = alloca i32
  %l186 = alloca { i64, ptr }
  %l189 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t73 = alloca { i64, [3 x i64] }, align 8
  %t120 = alloca { i64, [3 x i64] }, align 8
  %t163 = alloca { i64, [5 x i64] }, align 8
  %t182 = alloca { i64, [5 x i64] }, align 8
  %t204 = alloca { i64, [2 x i64] }, align 8
  %t229 = alloca { i64, [3 x i64] }, align 8
  %t279 = alloca { i64, [3 x i64] }, align 8
  %t326 = alloca { i64, [3 x i64] }, align 8
  %t355 = alloca { i64, [4 x i64] }, align 8
  %t397 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l19
  br label %bb1
bb1:
  %t5 = load i32, ptr %l19, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l4
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l5, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t29, i32 0, i32 3
  %t31 = load i32, ptr %t30
  store i32 %t31, ptr %l6, !tbaa !23
  br label %bb6
bb5:
  br label %bb25
bb6:
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = call i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %t33)
  store i1 %t35, ptr %l31
  br label %bb7
bb7:
  %t36 = load i1, ptr %l31, !tbaa !21
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 37
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l34
  br label %bb10
bb9:
  br label %bb24
bb10:
  %t42 = load i64, ptr %l34, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l35, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t44, ptr %l36
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t45, ptr %l37, !tbaa !23
  store i32 19, ptr %l38
  %t46 = load ptr, ptr %l2, !tbaa !29
  store ptr %t46, ptr %l39, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  %t49 = load i32, ptr %l3, !tbaa !23
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t47, %"compiler/source:Span" %t48, i32 %t49, i64 0)
  store ptr %t53, ptr %l43
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l43, !tbaa !29
  %t55 = load ptr, ptr %l35, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l36
  %t57 = load i32, ptr %l37, !tbaa !23
  %t58 = load i32, ptr %l38, !range !{i32 0, i32 43}
  %t59 = load ptr, ptr %l39, !tbaa !29
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t55, %"compiler/source:Span" %t56, i32 %t57, i32 %t58, ptr %t59, ptr %t54)
  store ptr %t61, ptr %l45
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l45, !tbaa !29
  store ptr %t62, ptr %l8, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 37
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t65)
  store i64 %t67, ptr %l48
  br label %bb13
bb13:
  %t68 = load i64, ptr %l48, !tbaa !24
  store i64 %t68, ptr %l9, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 37
  %t72 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 0
  store i64 9, ptr %t74
  %t76 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t72, 0
  %t78 = insertvalue { %"compiler/source:Span", i32, ptr } %t76, i32 1, 1
  %t79 = insertvalue { %"compiler/source:Span", i32, ptr } %t78, ptr null, 2
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t79, ptr %t80
  %t81 = load { i64, [3 x i64] }, ptr %t73
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t81, ptr %t83
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t71, ptr %t83)
  br label %bb14
bb14:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t86)
  store ptr %t88, ptr %l56
  br label %bb15
bb15:
  %t89 = load ptr, ptr %l56, !tbaa !29
  %t91 = getelementptr %"compiler/check:frame", ptr %t89, i32 0, i32 7
  %t92 = load i64, ptr %t91, !tbaa !24
  %t94 = trunc i64 %t92 to i32
  store i32 %t94, ptr %l60, !tbaa !23
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 37
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t98, i64 %t99)
  store { i64, ptr } %t102, ptr %l64
  br label %bb16
bb16:
  %t103 = load i32, ptr %l60, !tbaa !23
  %t104 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t105 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t103, { i64, ptr } %t104)
  store %"compiler/typed:Block" %t105, ptr %l65
  br label %bb17
bb17:
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t106, ptr %lp10
  %t107 = load %"compiler/typed:Block", ptr %l65
  %t108 = load ptr, ptr %lp10
  store %"compiler/typed:Block" %t107, ptr %t108
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 37
  store ptr %t111, ptr %l67, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t112, ptr %l68
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t114 = load ptr, ptr %lp10
  %t117 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t113, ptr %t114, ptr null)
  store %"compiler/typed:If" %t117, ptr %l71
  br label %bb18
bb18:
  %t118 = load %"compiler/typed:If", ptr %l71
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t118, ptr %t119
  store { i64, [3 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [3 x i64] }, ptr %t120, i32 0, i32 0
  store i64 3, ptr %t121
  %t122 = load %"compiler/source:Span", ptr %l68
  %t123 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t122, 0
  %t125 = insertvalue { %"compiler/source:Span", ptr } %t123, ptr %t119, 1
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t120, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t125, ptr %t126
  %t127 = load { i64, [3 x i64] }, ptr %t120
  %t129 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t127, ptr %t129
  %t130 = load ptr, ptr %l67, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t130, ptr %t129)
  br label %bb19
bb19:
  %t132 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t132, ptr %l75
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l3, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l80
  br label %bb20
bb20:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 37
  %t146 = load i64, ptr %l7, !tbaa !24
  %t149 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t145, i64 %t146)
  store { i64, ptr } %t149, ptr %l84
  br label %bb21
bb21:
  %t150 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t150, ptr %l85
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  %t157 = load i32, ptr %l3, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l90
  br label %bb22
bb22:
  %t161 = load ptr, ptr %l5, !tbaa !29
  %t162 = load i32, ptr %l6, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [5 x i64] }, ptr %t163, i32 0, i32 0
  store i64 2, ptr %t164
  %t165 = load %"compiler/source:Span", ptr %l85
  %t166 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t165, 0
  %t167 = load i32, ptr %l90, !tbaa !23
  %t168 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t166, i32 %t167, 1
  %t170 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t168, ptr %t161, 2
  %t172 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t170, i32 %t162, 3
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t163, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t172, ptr %t173
  %t174 = load { i64, [5 x i64] }, ptr %t163
  %t176 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t174, ptr %t176
  %t177 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t179 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t177, ptr %t176)
  store %"compiler/typed:Seq" %t179, ptr %l95
  br label %bb23
bb23:
  %t180 = load %"compiler/typed:Seq", ptr %l95
  %t181 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t180, ptr %t181
  store { i64, [5 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 0
  store i64 12, ptr %t183
  %t184 = load %"compiler/source:Span", ptr %l75
  %t185 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t184, 0
  %t186 = load i32, ptr %l80, !tbaa !23
  %t187 = insertvalue { %"compiler/source:Span", i32, ptr } %t185, i32 %t186, 1
  %t189 = insertvalue { %"compiler/source:Span", i32, ptr } %t187, ptr %t181, 2
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t189, ptr %t190
  %t191 = load { i64, [5 x i64] }, ptr %t182
  %t193 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t191, ptr %t193
  store ptr %t193, ptr %rv
  br label %ret
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_8302d182975d1c39_f0b10209f7a6052d)
  unreachable
bb30:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 37
  %t199 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t197)
  store i64 %t199, ptr %l101
  br label %bb31
bb31:
  %t200 = load i64, ptr %l101, !tbaa !24
  store i64 %t200, ptr %l11, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  %t203 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [2 x i64] }, ptr %t204, i32 0, i32 0
  store i64 5, ptr %t205
  %t206 = load { i64, [2 x i64] }, ptr %t204
  %t212 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t201, i32 0, %"compiler/source:Span" %t202, i32 %t203, i32 1, { i64, [2 x i64] } %t206)
  store i64 %t212, ptr %l107
  br label %bb32
bb32:
  %t213 = load i64, ptr %l107, !tbaa !24
  store i64 %t213, ptr %l12, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i64, ptr %l12, !tbaa !24
  %t216 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t214, i64 %t215, ptr %t216)
  br label %bb33
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 37
  %t223 = load %"compiler/source:Span", ptr %l1
  %t224 = load i64, ptr %l12, !tbaa !24
  %t226 = trunc i64 %t224 to i32
  %t228 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 0
  store i64 0, ptr %t230
  %t232 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t223, 0
  %t234 = insertvalue { %"compiler/source:Span", i32, ptr } %t232, i32 %t226, 1
  %t236 = insertvalue { %"compiler/source:Span", i32, ptr } %t234, ptr %t228, 2
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t236, ptr %t237
  %t238 = load { i64, [3 x i64] }, ptr %t229
  %t240 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t238, ptr %t240
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t222, ptr %t240)
  br label %bb34
bb34:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l120, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t244, ptr %l121
  %t245 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t245, ptr %l122, !tbaa !23
  store i32 19, ptr %l123
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l1
  %t248 = load i64, ptr %l12, !tbaa !24
  %t252 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t246, %"compiler/source:Span" %t247, i64 %t248)
  store ptr %t252, ptr %l127
  br label %bb35
bb35:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l1
  %t255 = load i32, ptr %l3, !tbaa !23
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t253, %"compiler/source:Span" %t254, i32 %t255, i64 0)
  store ptr %t259, ptr %l131
  br label %bb36
bb36:
  %t260 = load ptr, ptr %l131, !tbaa !29
  %t261 = load ptr, ptr %l120, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l121
  %t263 = load i32, ptr %l122, !tbaa !23
  %t264 = load i32, ptr %l123, !range !{i32 0, i32 43}
  %t265 = load ptr, ptr %l127, !tbaa !29
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t261, %"compiler/source:Span" %t262, i32 %t263, i32 %t264, ptr %t265, ptr %t260)
  store ptr %t267, ptr %l133
  br label %bb37
bb37:
  %t268 = load ptr, ptr %l133, !tbaa !29
  store ptr %t268, ptr %l13, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t269, i32 0, i32 37
  %t273 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t271)
  store i64 %t273, ptr %l136
  br label %bb38
bb38:
  %t274 = load i64, ptr %l136, !tbaa !24
  store i64 %t274, ptr %l14, !tbaa !24
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 37
  %t278 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 0
  store i64 9, ptr %t280
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t278, 0
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, i32 1, 1
  %t285 = insertvalue { %"compiler/source:Span", i32, ptr } %t284, ptr null, 2
  %t286 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t285, ptr %t286
  %t287 = load { i64, [3 x i64] }, ptr %t279
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t287, ptr %t289
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t277, ptr %t289)
  br label %bb39
bb39:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t292)
  store ptr %t294, ptr %l144
  br label %bb40
bb40:
  %t295 = load ptr, ptr %l144, !tbaa !29
  %t297 = getelementptr %"compiler/check:frame", ptr %t295, i32 0, i32 7
  %t298 = load i64, ptr %t297, !tbaa !24
  %t300 = trunc i64 %t298 to i32
  store i32 %t300, ptr %l148, !tbaa !23
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/check:Checker", ptr %t302, i32 0, i32 37
  %t305 = load i64, ptr %l14, !tbaa !24
  %t308 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t304, i64 %t305)
  store { i64, ptr } %t308, ptr %l152
  br label %bb41
bb41:
  %t309 = load i32, ptr %l148, !tbaa !23
  %t310 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t311 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t309, { i64, ptr } %t310)
  store %"compiler/typed:Block" %t311, ptr %l153
  br label %bb42
bb42:
  %t312 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t312, ptr %lp15
  %t313 = load %"compiler/typed:Block", ptr %l153
  %t314 = load ptr, ptr %lp15
  store %"compiler/typed:Block" %t313, ptr %t314
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 37
  store ptr %t317, ptr %l155, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t318, ptr %l156
  %t319 = load ptr, ptr %l13, !tbaa !29
  %t320 = load ptr, ptr %lp15
  %t323 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t319, ptr %t320, ptr null)
  store %"compiler/typed:If" %t323, ptr %l159
  br label %bb43
bb43:
  %t324 = load %"compiler/typed:If", ptr %l159
  %t325 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t324, ptr %t325
  store { i64, [3 x i64] } zeroinitializer, ptr %t326
  %t327 = getelementptr { i64, [3 x i64] }, ptr %t326, i32 0, i32 0
  store i64 3, ptr %t327
  %t328 = load %"compiler/source:Span", ptr %l156
  %t329 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t328, 0
  %t331 = insertvalue { %"compiler/source:Span", ptr } %t329, ptr %t325, 1
  %t332 = getelementptr { i64, [3 x i64] }, ptr %t326, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t331, ptr %t332
  %t333 = load { i64, [3 x i64] }, ptr %t326
  %t335 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t333, ptr %t335
  %t336 = load ptr, ptr %l155, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t336, ptr %t335)
  br label %bb44
bb44:
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l163, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t339, ptr %l164
  %t340 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t340, ptr %l165
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = getelementptr %"compiler/generic:Program", ptr %t344, i32 0, i32 2
  %t347 = load i32, ptr %l3, !tbaa !23
  %t350 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t346, i32 %t347)
  store i32 %t350, ptr %l170
  br label %bb45
bb45:
  %t351 = load i64, ptr %l12, !tbaa !24
  %t353 = trunc i64 %t351 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 0
  store i64 0, ptr %t356
  %t357 = load %"compiler/source:Span", ptr %l165
  %t358 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t357, 0
  %t359 = load i32, ptr %l170, !tbaa !23
  %t360 = insertvalue { %"compiler/source:Span", i32, i32 } %t358, i32 %t359, 1
  %t362 = insertvalue { %"compiler/source:Span", i32, i32 } %t360, i32 %t353, 2
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t362, ptr %t363
  %t364 = load { i64, [4 x i64] }, ptr %t355
  %t366 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t364, ptr %t366
  %t367 = load ptr, ptr %l163, !tbaa !29
  %t368 = load %"compiler/source:Span", ptr %l164
  %t370 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t367, %"compiler/source:Span" %t368, ptr %t366)
  store ptr %t370, ptr %l176
  br label %bb46
bb46:
  %t371 = load ptr, ptr %l176, !tbaa !29
  store ptr %t371, ptr %l16, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t372, ptr %l177
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/check:Checker", ptr %t373, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t378 = getelementptr %"compiler/generic:Program", ptr %t376, i32 0, i32 2
  %t379 = load i32, ptr %l3, !tbaa !23
  %t382 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l182
  br label %bb47
bb47:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/check:Checker", ptr %t383, i32 0, i32 37
  %t386 = load i64, ptr %l11, !tbaa !24
  %t389 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t385, i64 %t386)
  store { i64, ptr } %t389, ptr %l186
  br label %bb48
bb48:
  %t390 = load ptr, ptr %l16, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t394 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t392, ptr %t390)
  store %"compiler/typed:Seq" %t394, ptr %l189
  br label %bb49
bb49:
  %t395 = load %"compiler/typed:Seq", ptr %l189
  %t396 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t395, ptr %t396
  store { i64, [5 x i64] } zeroinitializer, ptr %t397
  %t398 = getelementptr { i64, [5 x i64] }, ptr %t397, i32 0, i32 0
  store i64 12, ptr %t398
  %t399 = load %"compiler/source:Span", ptr %l177
  %t400 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t399, 0
  %t401 = load i32, ptr %l182, !tbaa !23
  %t402 = insertvalue { %"compiler/source:Span", i32, ptr } %t400, i32 %t401, 1
  %t404 = insertvalue { %"compiler/source:Span", i32, ptr } %t402, ptr %t396, 2
  %t405 = getelementptr { i64, [5 x i64] }, ptr %t397, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t404, ptr %t405
  %t406 = load { i64, [5 x i64] }, ptr %t397
  %t408 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t406, ptr %t408
  store ptr %t408, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca i32
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca i32
  %l51 = alloca ptr
  %l55 = alloca ptr
  %l57 = alloca %"compiler/typed:Elem"
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca ptr
  %l68 = alloca ptr
  %l79 = alloca ptr
  %l85 = alloca ptr
  %l88 = alloca i64
  %l96 = alloca ptr
  %l100 = alloca i32
  %l104 = alloca { i64, ptr }
  %l105 = alloca %"compiler/typed:Block"
  %l107 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l116 = alloca %"compiler/typed:If"
  %t75 = alloca { i64, [4 x i64] }, align 8
  %t100 = alloca { i64, [4 x i64] }, align 8
  %t125 = alloca { i64, [3 x i64] }, align 8
  %t149 = alloca { i64, [3 x i64] }, align 8
  %t188 = alloca { i64, [3 x i64] }, align 8
  %t244 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:ForIn", ptr %t5, i32 0, i32 4
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:ForIn", ptr %t15, i32 0, i32 4
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t14, { i64, ptr } %t18)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  br label %ret
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Compr", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t24)
  store %"compiler/source:Span" %t26, ptr %l24
  br label %bb8
bb8:
  %t27 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t27, ptr %l4
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 96
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 97
  %t36 = load i64, ptr %t35, !tbaa !24
  store i64 %t36, ptr %l6, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Compr", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %t38, ptr %t42, i32 %t43)
  store ptr %t47, ptr %l33
  br label %bb9
bb9:
  %t48 = load ptr, ptr %l33, !tbaa !29
  store ptr %t48, ptr %l7, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Compr", ptr %t49, i32 0, i32 5
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  br i1 %t54, label %bb10, label %bb11
bb10:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp sge i64 %t56, 0
  store i1 %t58, ptr %l37, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t60 = load i1, ptr %l37, !tbaa !21
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t61, i64 %t62)
  store i32 %t65, ptr %l42
  br label %bb15
bb14:
  br label %bb20
bb15:
  %t66 = load i32, ptr %l42, !tbaa !23
  %t67 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t67, ptr %l43
  %t68 = load i32, ptr %l3, !tbaa !23
  store i32 %t68, ptr %l44, !tbaa !23
  %t69 = load %"compiler/source:Span", ptr %l4
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = trunc i64 %t71 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 0
  store i64 0, ptr %t76
  %t78 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t69, 0
  %t80 = insertvalue { %"compiler/source:Span", i32, i32 } %t78, i32 %t66, 1
  %t82 = insertvalue { %"compiler/source:Span", i32, i32 } %t80, i32 %t73, 2
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t82, ptr %t83
  %t84 = load { i64, [4 x i64] }, ptr %t75
  %t86 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t84, ptr %t86
  store ptr %t86, ptr %l51, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l4
  %t89 = load i64, ptr %l6, !tbaa !24
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, i64 %t89)
  store ptr %t93, ptr %l55
  br label %bb16
bb16:
  %t94 = load ptr, ptr %l51, !tbaa !29
  %t95 = load ptr, ptr %l55, !tbaa !29
  %t97 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t94, ptr %t95, i32 0)
  store %"compiler/typed:Elem" %t97, ptr %l57
  br label %bb17
bb17:
  %t98 = load %"compiler/typed:Elem", ptr %l57
  %t99 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t98, ptr %t99
  store { i64, [4 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 0
  store i64 4, ptr %t101
  %t102 = load %"compiler/source:Span", ptr %l43
  %t103 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t102, 0
  %t104 = load i32, ptr %l44, !tbaa !23
  %t105 = insertvalue { %"compiler/source:Span", i32, ptr } %t103, i32 %t104, 1
  %t107 = insertvalue { %"compiler/source:Span", i32, ptr } %t105, ptr %t99, 2
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t107, ptr %t108
  %t109 = load { i64, [4 x i64] }, ptr %t100
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t109, ptr %t111
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l61, !tbaa !29
  %t114 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t114, ptr %l62
  store ptr %t111, ptr %l63, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l7, !tbaa !29
  %t118 = load i32, ptr %l3, !tbaa !23
  %t119 = load %"compiler/source:Span", ptr %l4
  %t124 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t116, ptr %t117, i32 %t118, %"compiler/source:Span" %t119)
  store ptr %t124, ptr %l68
  br label %bb18
bb18:
  store { i64, [3 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t125, i32 0, i32 0
  store i64 1, ptr %t126
  %t127 = load %"compiler/source:Span", ptr %l62
  %t128 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t127, 0
  %t129 = load ptr, ptr %l63, !tbaa !29
  %t130 = insertvalue { %"compiler/source:Span", ptr, ptr } %t128, ptr %t129, 1
  %t131 = load ptr, ptr %l68, !tbaa !29
  %t132 = insertvalue { %"compiler/source:Span", ptr, ptr } %t130, ptr %t131, 2
  %t133 = getelementptr { i64, [3 x i64] }, ptr %t125, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t132, ptr %t133
  %t134 = load { i64, [3 x i64] }, ptr %t125
  %t136 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t134, ptr %t136
  %t137 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t137, ptr %t136)
  br label %bb19
bb19:
  br label %ret
bb20:
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t141 = getelementptr %"compiler/ast:Compr", ptr %t139, i32 0, i32 5
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = icmp eq ptr %t142, null
  br i1 %t144, label %bb21, label %bb22
bb21:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l4
  %t148 = load ptr, ptr %l7, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t149
  %t150 = getelementptr { i64, [3 x i64] }, ptr %t149, i32 0, i32 0
  store i64 15, ptr %t150
  %t152 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t147, 0
  %t154 = insertvalue { %"compiler/source:Span", ptr } %t152, ptr %t148, 1
  %t155 = getelementptr { i64, [3 x i64] }, ptr %t149, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t154, ptr %t155
  %t156 = load { i64, [3 x i64] }, ptr %t149
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t156, ptr %t158
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t146, ptr %t158)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %ret
bb24:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l79, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t164 = getelementptr %"compiler/ast:Compr", ptr %t162, i32 0, i32 5
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = icmp eq ptr %t165, null
  br i1 %t167, label %bb25, label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_61f61c7eea085c49_e2109341212ff245)
  unreachable
bb26:
  br label %bb27
bb27:
  %t169 = load ptr, ptr %l2, !tbaa !29
  %t171 = getelementptr %"compiler/ast:Compr", ptr %t169, i32 0, i32 5
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load ptr, ptr %l79, !tbaa !29
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v2, ptr %t173, ptr %t172)
  store ptr %t175, ptr %l85
  br label %bb28
bb28:
  %t176 = load ptr, ptr %l85, !tbaa !29
  store ptr %t176, ptr %l10, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 37
  %t181 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t179)
  store i64 %t181, ptr %l88
  br label %bb29
bb29:
  %t182 = load i64, ptr %l88, !tbaa !24
  store i64 %t182, ptr %l11, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 37
  %t186 = load %"compiler/source:Span", ptr %l4
  %t187 = load ptr, ptr %l7, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 0
  store i64 15, ptr %t189
  %t191 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t186, 0
  %t193 = insertvalue { %"compiler/source:Span", ptr } %t191, ptr %t187, 1
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t193, ptr %t194
  %t195 = load { i64, [3 x i64] }, ptr %t188
  %t197 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t195, ptr %t197
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t185, ptr %t197)
  br label %bb30
bb30:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t200)
  store ptr %t202, ptr %l96
  br label %bb31
bb31:
  %t203 = load ptr, ptr %l96, !tbaa !29
  %t205 = getelementptr %"compiler/check:frame", ptr %t203, i32 0, i32 7
  %t206 = load i64, ptr %t205, !tbaa !24
  %t208 = trunc i64 %t206 to i32
  store i32 %t208, ptr %l100, !tbaa !23
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 37
  %t213 = load i64, ptr %l11, !tbaa !24
  %t216 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t212, i64 %t213)
  store { i64, ptr } %t216, ptr %l104
  br label %bb32
bb32:
  %t217 = load i32, ptr %l100, !tbaa !23
  %t218 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t219 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t217, { i64, ptr } %t218)
  store %"compiler/typed:Block" %t219, ptr %l105
  br label %bb33
bb33:
  %t220 = load %"compiler/typed:Block", ptr %l105
  %t221 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t220, ptr %t221
  store ptr %t221, ptr %l12, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l107, !tbaa !29
  %t224 = load ptr, ptr %l2, !tbaa !29
  %t226 = getelementptr %"compiler/ast:Compr", ptr %t224, i32 0, i32 5
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  br i1 %t229, label %bb34, label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_5688429828d7ebe2_8ea9fe01fea3ad9e)
  unreachable
bb35:
  br label %bb36
bb36:
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t233 = getelementptr %"compiler/ast:Compr", ptr %t231, i32 0, i32 5
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t234)
  store %"compiler/source:Span" %t236, ptr %l113
  br label %bb37
bb37:
  %t237 = load ptr, ptr %l10, !tbaa !29
  %t238 = load ptr, ptr %l12, !tbaa !29
  %t241 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t237, ptr %t238, ptr null)
  store %"compiler/typed:If" %t241, ptr %l116
  br label %bb38
bb38:
  %t242 = load %"compiler/typed:If", ptr %l116
  %t243 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t242, ptr %t243
  store { i64, [3 x i64] } zeroinitializer, ptr %t244
  %t245 = getelementptr { i64, [3 x i64] }, ptr %t244, i32 0, i32 0
  store i64 3, ptr %t245
  %t246 = load %"compiler/source:Span", ptr %l113
  %t247 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t246, 0
  %t249 = insertvalue { %"compiler/source:Span", ptr } %t247, ptr %t243, 1
  %t250 = getelementptr { i64, [3 x i64] }, ptr %t244, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t249, ptr %t250
  %t251 = load { i64, [3 x i64] }, ptr %t244
  %t253 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t251, ptr %t253
  %t254 = load ptr, ptr %l107, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t254, ptr %t253)
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d58, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2eintFloatBits(i32 %a0, %"compiler/check:litv" %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca i128
  %l3 = alloca i64
  %l9 = alloca float
  %l20 = alloca bfloat
  %l31 = alloca half
  %l40 = alloca double
  %rv = alloca i64
  store i32 %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 6
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 8
  %t5 = load i128, ptr %t4
  store i128 %t5, ptr %l2
  %t7 = load i32, ptr %l0, !tbaa !23
  %t9 = icmp eq i32 %t7, 13
  br i1 %t9, label %bb3, label %bb4
bb2:
  br label %bb24
bb3:
  %t11 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 7
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb4:
  br label %bb8
bb5:
  %t14 = load i128, ptr %l2
  %t16 = uitofp i128 %t14 to float
  %t18 = fneg float %t16
  store float %t18, ptr %l9, !tbaa !25
  br label %bb7
bb6:
  %t20 = load i128, ptr %l2
  %t22 = uitofp i128 %t20 to float
  store float %t22, ptr %l9, !tbaa !25
  br label %bb7
bb7:
  %t24 = load float, ptr %l9, !tbaa !25
  %t25 = bitcast float %t24 to i32
  %t27 = zext i32 %t25 to i64
  store i64 %t27, ptr %rv
  br label %ret
bb8:
  %t29 = load i32, ptr %l0, !tbaa !23
  %t31 = icmp eq i32 %t29, 12
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 7
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb10:
  br label %bb14
bb11:
  %t36 = load i128, ptr %l2
  %t38 = or i128 %t36, 1
  %t39 = call i128 @llvm.ctlz.i128(i128 %t38, i1 true)
  %t40 = sub i128 65, %t39
  %t41 = icmp sgt i128 %t40, 0
  %t42 = select i1 %t41, i128 %t40, i128 0
  %t43 = shl i128 1, %t42
  %t44 = sub i128 %t43, 1
  %t45 = and i128 %t36, %t44
  %t46 = icmp ne i128 %t45, 0
  %t47 = lshr i128 %t36, %t42
  %t48 = trunc i128 %t47 to i64
  %t49 = zext i1 %t46 to i64
  %t50 = or i64 %t48, %t49
  %t51 = call bfloat @__olang_int_bf16(i64 %t50, i1 false)
  %t52 = trunc i128 %t42 to i32
  %t53 = add i32 %t52, 127
  %t54 = shl i32 %t53, 23
  %t55 = bitcast i32 %t54 to float
  %t56 = bitcast bfloat %t51 to i16
  %t57 = zext i16 %t56 to i32
  %t58 = shl i32 %t57, 16
  %t59 = bitcast i32 %t58 to float
  %t60 = fmul float %t59, %t55
  %t61 = bitcast float %t60 to i32
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t62, 1
  %t64 = add i32 %t63, 32767
  %t65 = add i32 %t61, %t64
  %t66 = lshr i32 %t65, 16
  %t67 = or i32 %t62, 64
  %t68 = and i32 %t61, 2147483647
  %t69 = icmp ugt i32 %t68, 2139095040
  %t70 = select i1 %t69, i32 %t67, i32 %t66
  %t71 = trunc i32 %t70 to i16
  %t72 = bitcast i16 %t71 to bfloat
  %t74 = bitcast bfloat %t72 to i16
  %t75 = xor i16 %t74, -32768
  %t76 = bitcast i16 %t75 to bfloat
  store bfloat %t76, ptr %l20, !tbaa !67
  br label %bb13
bb12:
  %t78 = load i128, ptr %l2
  %t80 = or i128 %t78, 1
  %t81 = call i128 @llvm.ctlz.i128(i128 %t80, i1 true)
  %t82 = sub i128 65, %t81
  %t83 = icmp sgt i128 %t82, 0
  %t84 = select i1 %t83, i128 %t82, i128 0
  %t85 = shl i128 1, %t84
  %t86 = sub i128 %t85, 1
  %t87 = and i128 %t78, %t86
  %t88 = icmp ne i128 %t87, 0
  %t89 = lshr i128 %t78, %t84
  %t90 = trunc i128 %t89 to i64
  %t91 = zext i1 %t88 to i64
  %t92 = or i64 %t90, %t91
  %t93 = call bfloat @__olang_int_bf16(i64 %t92, i1 false)
  %t94 = trunc i128 %t84 to i32
  %t95 = add i32 %t94, 127
  %t96 = shl i32 %t95, 23
  %t97 = bitcast i32 %t96 to float
  %t98 = bitcast bfloat %t93 to i16
  %t99 = zext i16 %t98 to i32
  %t100 = shl i32 %t99, 16
  %t101 = bitcast i32 %t100 to float
  %t102 = fmul float %t101, %t97
  %t103 = bitcast float %t102 to i32
  %t104 = lshr i32 %t103, 16
  %t105 = and i32 %t104, 1
  %t106 = add i32 %t105, 32767
  %t107 = add i32 %t103, %t106
  %t108 = lshr i32 %t107, 16
  %t109 = or i32 %t104, 64
  %t110 = and i32 %t103, 2147483647
  %t111 = icmp ugt i32 %t110, 2139095040
  %t112 = select i1 %t111, i32 %t109, i32 %t108
  %t113 = trunc i32 %t112 to i16
  %t114 = bitcast i16 %t113 to bfloat
  store bfloat %t114, ptr %l20, !tbaa !67
  br label %bb13
bb13:
  %t116 = load bfloat, ptr %l20, !tbaa !67
  %t117 = bitcast bfloat %t116 to i16
  %t118 = call i16 asm "", "=r,0"(i16 %t117)
  %t120 = zext i16 %t118 to i64
  store i64 %t120, ptr %rv
  br label %ret
bb14:
  %t122 = load i32, ptr %l0, !tbaa !23
  %t124 = icmp eq i32 %t122, 11
  br i1 %t124, label %bb15, label %bb16
bb15:
  %t126 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 7
  %t127 = load i1, ptr %t126, !tbaa !21
  br i1 %t127, label %bb17, label %bb18
bb16:
  br label %bb20
bb17:
  %t129 = load i128, ptr %l2
  %t131 = uitofp i128 %t129 to double
  %t132 = call double @llvm.arithmetic.fence.f64(double %t131)
  %t133 = fptrunc double %t132 to half
  %t135 = fneg half %t133
  store half %t135, ptr %l31, !tbaa !66
  br label %bb19
bb18:
  %t137 = load i128, ptr %l2
  %t139 = uitofp i128 %t137 to double
  %t140 = call double @llvm.arithmetic.fence.f64(double %t139)
  %t141 = fptrunc double %t140 to half
  store half %t141, ptr %l31, !tbaa !66
  br label %bb19
bb19:
  %t143 = load half, ptr %l31, !tbaa !66
  %t144 = bitcast half %t143 to i16
  %t145 = call i16 asm "", "=r,0"(i16 %t144)
  %t147 = zext i16 %t145 to i64
  store i64 %t147, ptr %rv
  br label %ret
bb20:
  %t149 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 7
  %t150 = load i1, ptr %t149, !tbaa !21
  br i1 %t150, label %bb21, label %bb22
bb21:
  %t152 = load i128, ptr %l2
  %t154 = uitofp i128 %t152 to double
  %t156 = fneg double %t154
  store double %t156, ptr %l40, !tbaa !26
  br label %bb23
bb22:
  %t158 = load i128, ptr %l2
  %t160 = uitofp i128 %t158 to double
  store double %t160, ptr %l40, !tbaa !26
  br label %bb23
bb23:
  %t162 = load double, ptr %l40, !tbaa !26
  %t163 = bitcast double %t162 to i64
  store i64 %t163, ptr %rv
  br label %ret
bb24:
  %t166 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t167 = load i1, ptr %t166, !tbaa !21
  br i1 %t167, label %bb25, label %bb26
bb25:
  %t169 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t170 = load i64, ptr %t169, !tbaa !24
  store i64 %t170, ptr %l3, !tbaa !65
  %t173 = load i32, ptr %l0, !tbaa !23
  %t175 = icmp eq i32 %t173, 13
  br i1 %t175, label %bb27, label %bb28
bb26:
  br label %bb36
bb27:
  %t177 = load i64, ptr %l3, !tbaa !65
  %t179 = uitofp i64 %t177 to float
  %t181 = bitcast float %t179 to i32
  %t183 = zext i32 %t181 to i64
  store i64 %t183, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t185 = load i32, ptr %l0, !tbaa !23
  %t187 = icmp eq i32 %t185, 12
  br i1 %t187, label %bb30, label %bb31
bb30:
  %t189 = load i64, ptr %l3, !tbaa !65
  %t191 = call bfloat @__olang_int_bf16(i64 %t189, i1 false)
  %t193 = bitcast bfloat %t191 to i16
  %t194 = call i16 asm "", "=r,0"(i16 %t193)
  %t196 = zext i16 %t194 to i64
  store i64 %t196, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t198 = load i32, ptr %l0, !tbaa !23
  %t200 = icmp eq i32 %t198, 11
  br i1 %t200, label %bb33, label %bb34
bb33:
  %t202 = load i64, ptr %l3, !tbaa !65
  %t204 = uitofp i64 %t202 to double
  %t205 = call double @llvm.arithmetic.fence.f64(double %t204)
  %t206 = fptrunc double %t205 to half
  %t208 = bitcast half %t206 to i16
  %t209 = call i16 asm "", "=r,0"(i16 %t208)
  %t211 = zext i16 %t209 to i64
  store i64 %t211, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t213 = load i64, ptr %l3, !tbaa !65
  %t215 = uitofp i64 %t213 to double
  %t217 = bitcast double %t215 to i64
  store i64 %t217, ptr %rv
  br label %ret
bb36:
  %t220 = load i32, ptr %l0, !tbaa !23
  %t222 = icmp eq i32 %t220, 13
  br i1 %t222, label %bb37, label %bb38
bb37:
  %t224 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t225 = load i64, ptr %t224, !tbaa !24
  %t227 = sitofp i64 %t225 to float
  %t229 = bitcast float %t227 to i32
  %t231 = zext i32 %t229 to i64
  store i64 %t231, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t233 = load i32, ptr %l0, !tbaa !23
  %t235 = icmp eq i32 %t233, 12
  br i1 %t235, label %bb40, label %bb41
bb40:
  %t237 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t238 = load i64, ptr %t237, !tbaa !24
  %t240 = icmp slt i64 %t238, 0
  %t241 = sub i64 0, %t238
  %t242 = select i1 %t240, i64 %t241, i64 %t238
  %t243 = call bfloat @__olang_int_bf16(i64 %t242, i1 %t240)
  %t245 = bitcast bfloat %t243 to i16
  %t246 = call i16 asm "", "=r,0"(i16 %t245)
  %t248 = zext i16 %t246 to i64
  store i64 %t248, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t250 = load i32, ptr %l0, !tbaa !23
  %t252 = icmp eq i32 %t250, 11
  br i1 %t252, label %bb43, label %bb44
bb43:
  %t254 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t255 = load i64, ptr %t254, !tbaa !24
  %t257 = sitofp i64 %t255 to double
  %t258 = call double @llvm.arithmetic.fence.f64(double %t257)
  %t259 = fptrunc double %t258 to half
  %t261 = bitcast half %t259 to i16
  %t262 = call i16 asm "", "=r,0"(i16 %t261)
  %t264 = zext i16 %t262 to i64
  store i64 %t264, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t266 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t267 = load i64, ptr %t266, !tbaa !24
  %t269 = sitofp i64 %t267 to double
  %t271 = bitcast double %t269 to i64
  store i64 %t271, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2eisCharLit(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 96}
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 96}
  %t18 = trunc i64 4 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_83df14ccfb59caa2_79e7c0956b45666e)
  unreachable
bb11:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2elambdaOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 23
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_94831dcf6c50df99_e0fe015107062615)
  unreachable
bb11:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2elaneTok(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t3 = trunc i64 52 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t8 = trunc i64 53 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t14 = trunc i64 54 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t20 = trunc i64 55 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t26 = trunc i64 56 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t32 = trunc i64 83 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t38 = trunc i64 84 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t42 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t44 = trunc i64 85 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb24
bb23:
  %t48 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t50 = trunc i64 88 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l24, !tbaa !21
  br label %bb24
bb24:
  %t53 = load i1, ptr %l24, !tbaa !21
  br i1 %t53, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb27
bb26:
  %t54 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t56 = trunc i64 89 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb27
bb27:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb30
bb29:
  %t60 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t62 = trunc i64 47 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb30
bb30:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb33
bb32:
  %t66 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t68 = trunc i64 45 to i32
  %t69 = icmp eq i32 %t66, %t68
  store i1 %t69, ptr %l33, !tbaa !21
  br label %bb33
bb33:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb36
bb35:
  %t72 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t74 = trunc i64 46 to i32
  %t75 = icmp eq i32 %t72, %t74
  store i1 %t75, ptr %l36, !tbaa !21
  br label %bb36
bb36:
  %t77 = load i1, ptr %l36, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t1)
  store i1 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i1, ptr %l7, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb21
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 %t25
  %t30 = load ptr, ptr %t29, !tbaa !39
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 17}
  %t39 = icmp eq i64 %t37, 5
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f65b5445e0db363a_c2ab951bd73e6226)
  unreachable
bb19:
  br label %bb20
bb20:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb5
bb21:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2elitText(ptr %v0, %"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l3 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 6
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 7
  %t5 = load i1, ptr %t4, !tbaa !21
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb6
bb3:
  %t7 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 8
  %t8 = load i128, ptr %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t12 = call i64 @__olang_fmt_u128(ptr null, i128 %t8)
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = getelementptr i8, ptr %t14, i64 %t10
  %t16 = call i64 @__olang_fmt_u128(ptr %t15, i128 %t8)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t14, 1
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  %t20 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 8
  %t21 = load i128, ptr %t20
  %t23 = call i64 @__olang_fmt_u128(ptr null, i128 %t21)
  %t24 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t23)
  %t25 = call i64 @__olang_fmt_u128(ptr %t24, i128 %t21)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t24, 1
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb6:
  %t30 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 2
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t34 = load i64, ptr %t33, !tbaa !24
  %t37 = call i64 @__olang_fmt_u64(ptr null, i64 %t34)
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  %t39 = call i64 @__olang_fmt_u64(ptr %t38, i64 %t34)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  store { i64, ptr } %t41, ptr %l9, !tbaa !27
  br label %bb9
bb8:
  %t43 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t44 = load i64, ptr %t43, !tbaa !24
  %t46 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t47 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t46)
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l9, !tbaa !27
  br label %bb9
bb9:
  %t52 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load i1, ptr %l10, !tbaa !21
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_327c34393f585585_f16c5fd873651789)
  unreachable
bb12:
  %t20 = load i1, ptr %l2, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l97 = alloca { i64, ptr }
  %l102 = alloca i1
  %l103 = alloca i1
  %l107 = alloca i1
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l139 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l154 = alloca i1
  %l155 = alloca ptr
  %l156 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l174 = alloca i1
  %l175 = alloca i1
  %l178 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l189 = alloca i1
  %l190 = alloca i1
  %l194 = alloca i1
  %l195 = alloca i1
  %l200 = alloca i1
  %l201 = alloca i1
  %l205 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca i1
  %l216 = alloca i1
  %l217 = alloca i1
  %l221 = alloca i1
  %l222 = alloca i1
  %l226 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l235 = alloca i1
  %l236 = alloca ptr
  %l237 = alloca i1
  %l244 = alloca i1
  %l245 = alloca ptr
  %l246 = alloca i1
  %l254 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca i1
  %l263 = alloca i1
  %l264 = alloca ptr
  %l265 = alloca i1
  %l275 = alloca i1
  %l276 = alloca i1
  %l279 = alloca i1
  %l280 = alloca ptr
  %l281 = alloca i1
  %l285 = alloca ptr
  %l286 = alloca i1
  %l294 = alloca i1
  %l295 = alloca i1
  %l299 = alloca i1
  %l300 = alloca ptr
  %l301 = alloca i1
  %l309 = alloca i1
  %l310 = alloca ptr
  %l311 = alloca i1
  %l325 = alloca { i64, ptr }
  %l330 = alloca i1
  %l331 = alloca i1
  %l335 = alloca i1
  %l342 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t7 = load ptr, ptr %l36, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l36, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 22}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l37, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l37, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb12
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t22 = load ptr, ptr %l42, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l42, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 22}
  %t28 = icmp eq i64 %t26, 21
  store i1 %t28, ptr %l43, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l43, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", ptr }, ptr %t32, i32 0, i32 1
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t36, { i64, ptr } %t38)
  store i1 %t41, ptr %l51
  br label %bb13
bb13:
  %t42 = load i1, ptr %l51, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t44 = load ptr, ptr %l52, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l52, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 22}
  %t50 = icmp eq i64 %t48, 1
  store i1 %t50, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l53, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l3, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/ast:VarDecl", ptr %t58, i32 0, i32 3
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t65 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t61, { i64, ptr } %t62)
  store i1 %t65, ptr %l61
  br label %bb20
bb20:
  %t66 = load i1, ptr %l61, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
bb21:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t68 = load ptr, ptr %l62, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l62, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 22}
  %t74 = icmp eq i64 %t72, 3
  store i1 %t74, ptr %l63, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l63, !tbaa !21
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l4, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t84, i32 0, i32 3
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb36
bb26:
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t92 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t88, { i64, ptr } %t89)
  store i1 %t92, ptr %l72
  br label %bb27
bb27:
  %t93 = load i1, ptr %l72, !tbaa !21
  br i1 %t93, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb31
bb29:
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t99 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t94, { i64, ptr } %t96)
  store i1 %t99, ptr %l77
  br label %bb30
bb30:
  %t100 = load i1, ptr %l77, !tbaa !21
  store i1 %t100, ptr %l73, !tbaa !21
  br label %bb31
bb31:
  %t101 = load i1, ptr %l73, !tbaa !21
  br i1 %t101, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb35
bb33:
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t102, { i64, ptr } %t104)
  store i1 %t107, ptr %l82
  br label %bb34
bb34:
  %t108 = load i1, ptr %l82, !tbaa !21
  store i1 %t108, ptr %l78, !tbaa !21
  br label %bb35
bb35:
  %t109 = load i1, ptr %l78, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t111 = load ptr, ptr %l83, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l83, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 22}
  %t117 = icmp eq i64 %t115, 2
  store i1 %t117, ptr %l84, !tbaa !21
  br label %bb38
bb38:
  %t118 = load i1, ptr %l84, !tbaa !21
  br i1 %t118, label %bb39, label %bb40
bb39:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", ptr }, ptr %t121, i32 0, i32 1
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l6, !tbaa !29
  br label %bb41
bb40:
  br label %bb57
bb41:
  %t125 = load ptr, ptr %l6, !tbaa !29
  %t127 = getelementptr %"compiler/ast:Multi", ptr %t125, i32 0, i32 0
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l9, !tbaa !24
  br label %bb42
bb42:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l9, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb43, label %bb44
bb43:
  br label %bb55
bb44:
  br label %bb45
bb45:
  %t142 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t142, ptr %l97, !tbaa !27
  %t143 = load i64, ptr %l8, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr ptr, ptr %t146, i64 %t143
  %t148 = load ptr, ptr %t147, !tbaa !39
  store ptr %t148, ptr %l10, !tbaa !29
  %t150 = load ptr, ptr %l10, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t154 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t150, { i64, ptr } %t151)
  store i1 %t154, ptr %l102
  br label %bb46
bb46:
  %t155 = load i1, ptr %l102, !tbaa !21
  br i1 %t155, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb50
bb48:
  %t156 = load ptr, ptr %l10, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t161 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t156, { i64, ptr } %t158)
  store i1 %t161, ptr %l107
  br label %bb49
bb49:
  %t162 = load i1, ptr %l107, !tbaa !21
  store i1 %t162, ptr %l103, !tbaa !21
  br label %bb50
bb50:
  %t163 = load i1, ptr %l103, !tbaa !21
  br i1 %t163, label %bb51, label %bb52
bb51:
  store i1 true, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t165 = load i64, ptr %l8, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l8, !tbaa !24
  br label %bb42
bb55:
  %t169 = load ptr, ptr %l6, !tbaa !29
  %t171 = getelementptr %"compiler/ast:Multi", ptr %t169, i32 0, i32 2
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t176 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t172, { i64, ptr } %t173)
  store i1 %t176, ptr %l114
  br label %bb56
bb56:
  %t177 = load i1, ptr %l114, !tbaa !21
  store i1 %t177, ptr %rv
  br label %ret
bb57:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t179 = load ptr, ptr %l115, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb58, label %bb59
bb58:
  %t182 = load ptr, ptr %l115, !tbaa !29
  %t183 = load i64, ptr %t182, !range !{i64 0, i64 22}
  %t185 = icmp eq i64 %t183, 4
  store i1 %t185, ptr %l116, !tbaa !21
  br label %bb59
bb59:
  %t186 = load i1, ptr %l116, !tbaa !21
  br i1 %t186, label %bb60, label %bb61
bb60:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr { i64, [4 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t189, i32 0, i32 1
  %t191 = load ptr, ptr %t190
  store ptr %t191, ptr %l11, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t195, i32 0, i32 2
  %t197 = load { i64, ptr }, ptr %t196
  store { i64, ptr } %t197, ptr %l12, !tbaa !27
  br label %bb62
bb61:
  br label %bb68
bb62:
  %t199 = load ptr, ptr %l11, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t204 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t199, { i64, ptr } %t201)
  store i1 %t204, ptr %l126
  br label %bb63
bb63:
  %t205 = load i1, ptr %l126, !tbaa !21
  br i1 %t205, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb67
bb65:
  %t206 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t210 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t206, { i64, ptr } %t207)
  store i1 %t210, ptr %l130
  br label %bb66
bb66:
  %t211 = load i1, ptr %l130, !tbaa !21
  store i1 %t211, ptr %l127, !tbaa !21
  br label %bb67
bb67:
  %t212 = load i1, ptr %l127, !tbaa !21
  store i1 %t212, ptr %rv
  br label %ret
bb68:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t214 = load ptr, ptr %l131, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb69, label %bb70
bb69:
  %t217 = load ptr, ptr %l131, !tbaa !29
  %t218 = load i64, ptr %t217, !range !{i64 0, i64 22}
  %t220 = icmp eq i64 %t218, 5
  store i1 %t220, ptr %l132, !tbaa !21
  br label %bb70
bb70:
  %t221 = load i1, ptr %l132, !tbaa !21
  br i1 %t221, label %bb71, label %bb72
bb71:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", ptr }, ptr %t224, i32 0, i32 1
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l13, !tbaa !29
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t228 = load ptr, ptr %l13, !tbaa !29
  %t229 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t232 = call i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %t228, { i64, ptr } %t229)
  store i1 %t232, ptr %l139
  br label %bb74
bb74:
  %t233 = load i1, ptr %l139, !tbaa !21
  store i1 %t233, ptr %rv
  br label %ret
bb75:
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t235 = load ptr, ptr %l140, !tbaa !29
  %t236 = icmp ne ptr %t235, null
  br i1 %t236, label %bb76, label %bb77
bb76:
  %t238 = load ptr, ptr %l140, !tbaa !29
  %t239 = load i64, ptr %t238, !range !{i64 0, i64 22}
  %t241 = icmp eq i64 %t239, 6
  store i1 %t241, ptr %l141, !tbaa !21
  br label %bb77
bb77:
  %t242 = load i1, ptr %l141, !tbaa !21
  br i1 %t242, label %bb78, label %bb79
bb78:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t243, i32 0, i32 1
  %t246 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t245, i32 0, i32 1
  %t247 = load { i64, ptr }, ptr %t246
  store { i64, ptr } %t247, ptr %l14, !tbaa !27
  br label %bb84
bb79:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t250 = load ptr, ptr %l146, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb80, label %bb81
bb80:
  %t253 = load ptr, ptr %l146, !tbaa !29
  %t254 = load i64, ptr %t253, !range !{i64 0, i64 22}
  %t256 = icmp eq i64 %t254, 20
  store i1 %t256, ptr %l147, !tbaa !21
  br label %bb81
bb81:
  %t257 = load i1, ptr %l147, !tbaa !21
  br i1 %t257, label %bb82, label %bb83
bb82:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t260, i32 0, i32 1
  %t262 = load { i64, ptr }, ptr %t261
  store { i64, ptr } %t262, ptr %l14, !tbaa !27
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t264 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t268 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t264, { i64, ptr } %t265)
  store i1 %t268, ptr %l154
  br label %bb85
bb85:
  %t269 = load i1, ptr %l154, !tbaa !21
  store i1 %t269, ptr %rv
  br label %ret
bb86:
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t271 = load ptr, ptr %l155, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb87, label %bb88
bb87:
  %t274 = load ptr, ptr %l155, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 22}
  %t277 = icmp eq i64 %t275, 7
  store i1 %t277, ptr %l156, !tbaa !21
  br label %bb88
bb88:
  %t278 = load i1, ptr %l156, !tbaa !21
  br i1 %t278, label %bb89, label %bb90
bb89:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t281, i32 0, i32 1
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l15, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t287, i32 0, i32 2
  %t289 = load { i64, ptr }, ptr %t288
  store { i64, ptr } %t289, ptr %l16, !tbaa !27
  br label %bb95
bb90:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t292 = load ptr, ptr %l163, !tbaa !29
  %t293 = icmp ne ptr %t292, null
  br i1 %t293, label %bb91, label %bb92
bb91:
  %t295 = load ptr, ptr %l163, !tbaa !29
  %t296 = load i64, ptr %t295, !range !{i64 0, i64 22}
  %t298 = icmp eq i64 %t296, 10
  store i1 %t298, ptr %l164, !tbaa !21
  br label %bb92
bb92:
  %t299 = load i1, ptr %l164, !tbaa !21
  br i1 %t299, label %bb93, label %bb94
bb93:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr { i64, [4 x i64] }, ptr %t300, i32 0, i32 1
  %t303 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t302, i32 0, i32 1
  %t304 = load { i64, ptr }, ptr %t303
  store { i64, ptr } %t304, ptr %l16, !tbaa !27
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr { i64, [4 x i64] }, ptr %t306, i32 0, i32 1
  %t309 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t308, i32 0, i32 2
  %t310 = load ptr, ptr %t309
  store ptr %t310, ptr %l15, !tbaa !29
  br label %bb95
bb94:
  br label %bb101
bb95:
  %t312 = load ptr, ptr %l15, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t317 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t312, { i64, ptr } %t314)
  store i1 %t317, ptr %l174
  br label %bb96
bb96:
  %t318 = load i1, ptr %l174, !tbaa !21
  br i1 %t318, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l175, !tbaa !21
  br label %bb100
bb98:
  %t319 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t323 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t319, { i64, ptr } %t320)
  store i1 %t323, ptr %l178
  br label %bb99
bb99:
  %t324 = load i1, ptr %l178, !tbaa !21
  store i1 %t324, ptr %l175, !tbaa !21
  br label %bb100
bb100:
  %t325 = load i1, ptr %l175, !tbaa !21
  store i1 %t325, ptr %rv
  br label %ret
bb101:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t327 = load ptr, ptr %l179, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb102, label %bb103
bb102:
  %t330 = load ptr, ptr %l179, !tbaa !29
  %t331 = load i64, ptr %t330, !range !{i64 0, i64 22}
  %t333 = icmp eq i64 %t331, 8
  store i1 %t333, ptr %l180, !tbaa !21
  br label %bb103
bb103:
  %t334 = load i1, ptr %l180, !tbaa !21
  br i1 %t334, label %bb104, label %bb105
bb104:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr { i64, [4 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", ptr }, ptr %t337, i32 0, i32 1
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l17, !tbaa !29
  br label %bb106
bb105:
  br label %bb120
bb106:
  %t341 = load ptr, ptr %l17, !tbaa !29
  %t343 = getelementptr %"compiler/ast:For3", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t349 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t344, { i64, ptr } %t346)
  store i1 %t349, ptr %l189
  br label %bb107
bb107:
  %t350 = load i1, ptr %l189, !tbaa !21
  br i1 %t350, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb111
bb109:
  %t351 = load ptr, ptr %l17, !tbaa !29
  %t353 = getelementptr %"compiler/ast:For3", ptr %t351, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t355 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t358 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t354, { i64, ptr } %t355)
  store i1 %t358, ptr %l194
  br label %bb110
bb110:
  %t359 = load i1, ptr %l194, !tbaa !21
  store i1 %t359, ptr %l190, !tbaa !21
  br label %bb111
bb111:
  %t360 = load i1, ptr %l190, !tbaa !21
  br i1 %t360, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l195, !tbaa !21
  br label %bb115
bb113:
  %t361 = load ptr, ptr %l17, !tbaa !29
  %t363 = getelementptr %"compiler/ast:For3", ptr %t361, i32 0, i32 2
  %t364 = load ptr, ptr %t363, !tbaa !29
  %t366 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t369 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t364, { i64, ptr } %t366)
  store i1 %t369, ptr %l200
  br label %bb114
bb114:
  %t370 = load i1, ptr %l200, !tbaa !21
  store i1 %t370, ptr %l195, !tbaa !21
  br label %bb115
bb115:
  %t371 = load i1, ptr %l195, !tbaa !21
  br i1 %t371, label %bb116, label %bb117
bb116:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb119
bb117:
  %t372 = load ptr, ptr %l17, !tbaa !29
  %t374 = getelementptr %"compiler/ast:For3", ptr %t372, i32 0, i32 3
  %t375 = load { i64, ptr }, ptr %t374, !tbaa !27
  %t376 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t379 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t375, { i64, ptr } %t376)
  store i1 %t379, ptr %l205
  br label %bb118
bb118:
  %t380 = load i1, ptr %l205, !tbaa !21
  store i1 %t380, ptr %l201, !tbaa !21
  br label %bb119
bb119:
  %t381 = load i1, ptr %l201, !tbaa !21
  store i1 %t381, ptr %rv
  br label %ret
bb120:
  %t382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t382, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t383 = load ptr, ptr %l206, !tbaa !29
  %t384 = icmp ne ptr %t383, null
  br i1 %t384, label %bb121, label %bb122
bb121:
  %t386 = load ptr, ptr %l206, !tbaa !29
  %t387 = load i64, ptr %t386, !range !{i64 0, i64 22}
  %t389 = icmp eq i64 %t387, 9
  store i1 %t389, ptr %l207, !tbaa !21
  br label %bb122
bb122:
  %t390 = load i1, ptr %l207, !tbaa !21
  br i1 %t390, label %bb123, label %bb124
bb123:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr { i64, [4 x i64] }, ptr %t391, i32 0, i32 1
  %t394 = getelementptr { %"compiler/source:Span", ptr }, ptr %t393, i32 0, i32 1
  %t395 = load ptr, ptr %t394
  store ptr %t395, ptr %l18, !tbaa !29
  br label %bb125
bb124:
  br label %bb135
bb125:
  %t397 = load ptr, ptr %l18, !tbaa !29
  %t399 = getelementptr %"compiler/ast:ForIn", ptr %t397, i32 0, i32 2
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t402 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t405 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t400, { i64, ptr } %t402)
  store i1 %t405, ptr %l216
  br label %bb126
bb126:
  %t406 = load i1, ptr %l216, !tbaa !21
  br i1 %t406, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb130
bb128:
  %t407 = load ptr, ptr %l18, !tbaa !29
  %t409 = getelementptr %"compiler/ast:ForIn", ptr %t407, i32 0, i32 4
  %t410 = load { i64, ptr }, ptr %t409, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t414 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t410, { i64, ptr } %t411)
  store i1 %t414, ptr %l221
  br label %bb129
bb129:
  %t415 = load i1, ptr %l221, !tbaa !21
  store i1 %t415, ptr %l217, !tbaa !21
  br label %bb130
bb130:
  %t416 = load i1, ptr %l217, !tbaa !21
  br i1 %t416, label %bb131, label %bb132
bb131:
  store i1 true, ptr %l222, !tbaa !21
  br label %bb134
bb132:
  %t417 = load ptr, ptr %l18, !tbaa !29
  %t419 = getelementptr %"compiler/ast:ForIn", ptr %t417, i32 0, i32 5
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t424 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t420, { i64, ptr } %t421)
  store i1 %t424, ptr %l226
  br label %bb133
bb133:
  %t425 = load i1, ptr %l226, !tbaa !21
  store i1 %t425, ptr %l222, !tbaa !21
  br label %bb134
bb134:
  %t426 = load i1, ptr %l222, !tbaa !21
  store i1 %t426, ptr %rv
  br label %ret
bb135:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t428 = load ptr, ptr %l227, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb136, label %bb137
bb136:
  %t431 = load ptr, ptr %l227, !tbaa !29
  %t432 = load i64, ptr %t431, !range !{i64 0, i64 22}
  %t434 = icmp eq i64 %t432, 11
  store i1 %t434, ptr %l228, !tbaa !21
  br label %bb137
bb137:
  %t435 = load i1, ptr %l228, !tbaa !21
  br i1 %t435, label %bb138, label %bb139
bb138:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", ptr }, ptr %t438, i32 0, i32 1
  %t440 = load ptr, ptr %t439
  store ptr %t440, ptr %l19, !tbaa !29
  br label %bb140
bb139:
  br label %bb142
bb140:
  %t442 = load ptr, ptr %l19, !tbaa !29
  %t443 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t446 = call i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %t442, { i64, ptr } %t443)
  store i1 %t446, ptr %l235
  br label %bb141
bb141:
  %t447 = load i1, ptr %l235, !tbaa !21
  store i1 %t447, ptr %rv
  br label %ret
bb142:
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t449 = load ptr, ptr %l236, !tbaa !29
  %t450 = icmp ne ptr %t449, null
  br i1 %t450, label %bb143, label %bb144
bb143:
  %t452 = load ptr, ptr %l236, !tbaa !29
  %t453 = load i64, ptr %t452, !range !{i64 0, i64 22}
  %t455 = icmp eq i64 %t453, 12
  store i1 %t455, ptr %l237, !tbaa !21
  br label %bb144
bb144:
  %t456 = load i1, ptr %l237, !tbaa !21
  br i1 %t456, label %bb145, label %bb146
bb145:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr { i64, [4 x i64] }, ptr %t457, i32 0, i32 1
  %t460 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t459, i32 0, i32 1
  %t461 = load { i64, ptr }, ptr %t460
  store { i64, ptr } %t461, ptr %l20, !tbaa !27
  br label %bb147
bb146:
  br label %bb149
bb147:
  %t463 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t464 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t467 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t463, { i64, ptr } %t464)
  store i1 %t467, ptr %l244
  br label %bb148
bb148:
  %t468 = load i1, ptr %l244, !tbaa !21
  store i1 %t468, ptr %rv
  br label %ret
bb149:
  %t469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t469, ptr %l245, !tbaa !29
  store i1 false, ptr %l246, !tbaa !21
  %t470 = load ptr, ptr %l245, !tbaa !29
  %t471 = icmp ne ptr %t470, null
  br i1 %t471, label %bb150, label %bb151
bb150:
  %t473 = load ptr, ptr %l245, !tbaa !29
  %t474 = load i64, ptr %t473, !range !{i64 0, i64 22}
  %t476 = icmp eq i64 %t474, 15
  store i1 %t476, ptr %l246, !tbaa !21
  br label %bb151
bb151:
  %t477 = load i1, ptr %l246, !tbaa !21
  br i1 %t477, label %bb152, label %bb153
bb152:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr { i64, [4 x i64] }, ptr %t478, i32 0, i32 1
  %t481 = getelementptr { %"compiler/source:Span", ptr }, ptr %t480, i32 0, i32 1
  %t482 = load ptr, ptr %t481
  store ptr %t482, ptr %l21, !tbaa !29
  br label %bb154
bb153:
  br label %bb156
bb154:
  %t484 = load ptr, ptr %l21, !tbaa !29
  %t486 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t489 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t484, { i64, ptr } %t486)
  store i1 %t489, ptr %l254
  br label %bb155
bb155:
  %t490 = load i1, ptr %l254, !tbaa !21
  store i1 %t490, ptr %rv
  br label %ret
bb156:
  %t491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t491, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t492 = load ptr, ptr %l255, !tbaa !29
  %t493 = icmp ne ptr %t492, null
  br i1 %t493, label %bb157, label %bb158
bb157:
  %t495 = load ptr, ptr %l255, !tbaa !29
  %t496 = load i64, ptr %t495, !range !{i64 0, i64 22}
  %t498 = icmp eq i64 %t496, 13
  store i1 %t498, ptr %l256, !tbaa !21
  br label %bb158
bb158:
  %t499 = load i1, ptr %l256, !tbaa !21
  br i1 %t499, label %bb159, label %bb160
bb159:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t500, i32 0, i32 1
  %t503 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t502, i32 0, i32 2
  %t504 = load ptr, ptr %t503
  store ptr %t504, ptr %l22, !tbaa !29
  br label %bb161
bb160:
  br label %bb163
bb161:
  %t506 = load ptr, ptr %l22, !tbaa !29
  %t507 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t510 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t506, { i64, ptr } %t507)
  store i1 %t510, ptr %l263
  br label %bb162
bb162:
  %t511 = load i1, ptr %l263, !tbaa !21
  store i1 %t511, ptr %rv
  br label %ret
bb163:
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t513 = load ptr, ptr %l264, !tbaa !29
  %t514 = icmp ne ptr %t513, null
  br i1 %t514, label %bb164, label %bb165
bb164:
  %t516 = load ptr, ptr %l264, !tbaa !29
  %t517 = load i64, ptr %t516, !range !{i64 0, i64 22}
  %t519 = icmp eq i64 %t517, 14
  store i1 %t519, ptr %l265, !tbaa !21
  br label %bb165
bb165:
  %t520 = load i1, ptr %l265, !tbaa !21
  br i1 %t520, label %bb166, label %bb167
bb166:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr { i64, [4 x i64] }, ptr %t521, i32 0, i32 1
  %t524 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t523, i32 0, i32 1
  %t525 = load ptr, ptr %t524
  store ptr %t525, ptr %l23, !tbaa !29
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr { i64, [4 x i64] }, ptr %t527, i32 0, i32 1
  %t530 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t529, i32 0, i32 2
  %t531 = load ptr, ptr %t530
  store ptr %t531, ptr %l24, !tbaa !29
  br label %bb168
bb167:
  br label %bb174
bb168:
  %t533 = load ptr, ptr %l23, !tbaa !29
  %t535 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t538 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t533, { i64, ptr } %t535)
  store i1 %t538, ptr %l275
  br label %bb169
bb169:
  %t539 = load i1, ptr %l275, !tbaa !21
  br i1 %t539, label %bb170, label %bb171
bb170:
  store i1 true, ptr %l276, !tbaa !21
  br label %bb173
bb171:
  %t540 = load ptr, ptr %l24, !tbaa !29
  %t541 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t544 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t540, { i64, ptr } %t541)
  store i1 %t544, ptr %l279
  br label %bb172
bb172:
  %t545 = load i1, ptr %l279, !tbaa !21
  store i1 %t545, ptr %l276, !tbaa !21
  br label %bb173
bb173:
  %t546 = load i1, ptr %l276, !tbaa !21
  store i1 %t546, ptr %rv
  br label %ret
bb174:
  %t547 = load ptr, ptr %l0, !tbaa !29
  store ptr %t547, ptr %l280, !tbaa !29
  store i1 false, ptr %l281, !tbaa !21
  %t548 = load ptr, ptr %l280, !tbaa !29
  %t549 = icmp ne ptr %t548, null
  br i1 %t549, label %bb175, label %bb176
bb175:
  %t551 = load ptr, ptr %l280, !tbaa !29
  %t552 = load i64, ptr %t551, !range !{i64 0, i64 22}
  %t554 = icmp eq i64 %t552, 16
  store i1 %t554, ptr %l281, !tbaa !21
  br label %bb176
bb176:
  %t555 = load i1, ptr %l281, !tbaa !21
  br i1 %t555, label %bb177, label %bb178
bb177:
  br label %bb179
bb178:
  br label %bb180
bb179:
  store i1 false, ptr %rv
  br label %ret
bb180:
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l285, !tbaa !29
  store i1 false, ptr %l286, !tbaa !21
  %t558 = load ptr, ptr %l285, !tbaa !29
  %t559 = icmp ne ptr %t558, null
  br i1 %t559, label %bb181, label %bb182
bb181:
  %t561 = load ptr, ptr %l285, !tbaa !29
  %t562 = load i64, ptr %t561, !range !{i64 0, i64 22}
  %t564 = icmp eq i64 %t562, 18
  store i1 %t564, ptr %l286, !tbaa !21
  br label %bb182
bb182:
  %t565 = load i1, ptr %l286, !tbaa !21
  br i1 %t565, label %bb183, label %bb184
bb183:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = getelementptr { i64, [4 x i64] }, ptr %t566, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", ptr }, ptr %t568, i32 0, i32 1
  %t570 = load ptr, ptr %t569
  store ptr %t570, ptr %l25, !tbaa !29
  br label %bb185
bb184:
  br label %bb191
bb185:
  %t572 = load ptr, ptr %l25, !tbaa !29
  %t574 = getelementptr %"compiler/ast:JoinS", ptr %t572, i32 0, i32 1
  %t575 = load { i64, ptr }, ptr %t574, !tbaa !27
  %t576 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t579 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t575, { i64, ptr } %t576)
  store i1 %t579, ptr %l294
  br label %bb186
bb186:
  %t580 = load i1, ptr %l294, !tbaa !21
  br i1 %t580, label %bb187, label %bb188
bb187:
  store i1 true, ptr %l295, !tbaa !21
  br label %bb190
bb188:
  %t581 = load ptr, ptr %l25, !tbaa !29
  %t583 = getelementptr %"compiler/ast:JoinS", ptr %t581, i32 0, i32 2
  %t584 = load { i64, ptr }, ptr %t583, !tbaa !27
  %t585 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t588 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t584, { i64, ptr } %t585)
  store i1 %t588, ptr %l299
  br label %bb189
bb189:
  %t589 = load i1, ptr %l299, !tbaa !21
  store i1 %t589, ptr %l295, !tbaa !21
  br label %bb190
bb190:
  %t590 = load i1, ptr %l295, !tbaa !21
  store i1 %t590, ptr %rv
  br label %ret
bb191:
  %t591 = load ptr, ptr %l0, !tbaa !29
  store ptr %t591, ptr %l300, !tbaa !29
  store i1 false, ptr %l301, !tbaa !21
  %t592 = load ptr, ptr %l300, !tbaa !29
  %t593 = icmp ne ptr %t592, null
  br i1 %t593, label %bb192, label %bb193
bb192:
  %t595 = load ptr, ptr %l300, !tbaa !29
  %t596 = load i64, ptr %t595, !range !{i64 0, i64 22}
  %t598 = icmp eq i64 %t596, 19
  store i1 %t598, ptr %l301, !tbaa !21
  br label %bb193
bb193:
  %t599 = load i1, ptr %l301, !tbaa !21
  br i1 %t599, label %bb194, label %bb195
bb194:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = getelementptr { i64, [4 x i64] }, ptr %t600, i32 0, i32 1
  %t603 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t602, i32 0, i32 1
  %t604 = load ptr, ptr %t603
  store ptr %t604, ptr %l26, !tbaa !29
  br label %bb196
bb195:
  br label %bb198
bb196:
  %t606 = load ptr, ptr %l26, !tbaa !29
  %t608 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t611 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t606, { i64, ptr } %t608)
  store i1 %t611, ptr %l309
  br label %bb197
bb197:
  %t612 = load i1, ptr %l309, !tbaa !21
  store i1 %t612, ptr %rv
  br label %ret
bb198:
  %t613 = load ptr, ptr %l0, !tbaa !29
  store ptr %t613, ptr %l310, !tbaa !29
  store i1 false, ptr %l311, !tbaa !21
  %t614 = load ptr, ptr %l310, !tbaa !29
  %t615 = icmp ne ptr %t614, null
  br i1 %t615, label %bb199, label %bb200
bb199:
  %t617 = load ptr, ptr %l310, !tbaa !29
  %t618 = load i64, ptr %t617, !range !{i64 0, i64 22}
  %t620 = icmp eq i64 %t618, 17
  store i1 %t620, ptr %l311, !tbaa !21
  br label %bb200
bb200:
  %t621 = load i1, ptr %l311, !tbaa !21
  br i1 %t621, label %bb201, label %bb202
bb201:
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr { i64, [4 x i64] }, ptr %t622, i32 0, i32 1
  %t625 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t624, i32 0, i32 1
  %t626 = load { i64, ptr }, ptr %t625
  store { i64, ptr } %t626, ptr %l27, !tbaa !27
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr { i64, [4 x i64] }, ptr %t628, i32 0, i32 1
  %t631 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t630, i32 0, i32 2
  %t632 = load ptr, ptr %t631
  store ptr %t632, ptr %l28, !tbaa !29
  br label %bb203
bb202:
  br label %bb219
bb203:
  %t634 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t634, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t636 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t636, 0
  store i64 %t638, ptr %l31, !tbaa !24
  br label %bb204
bb204:
  %t640 = load i64, ptr %l30, !tbaa !24
  %t641 = load i64, ptr %l31, !tbaa !24
  %t644 = icmp slt i64 %t640, %t641
  %t646 = xor i1 %t644, true
  br i1 %t646, label %bb205, label %bb206
bb205:
  br label %bb217
bb206:
  br label %bb207
bb207:
  %t648 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t648, ptr %l325, !tbaa !27
  %t649 = load i64, ptr %l30, !tbaa !24
  %t651 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !27
  %t653 = getelementptr ptr, ptr %t652, i64 %t649
  %t654 = load ptr, ptr %t653, !tbaa !39
  store ptr %t654, ptr %l32, !tbaa !29
  %t656 = load ptr, ptr %l32, !tbaa !29
  %t657 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t660 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t656, { i64, ptr } %t657)
  store i1 %t660, ptr %l330
  br label %bb208
bb208:
  %t661 = load i1, ptr %l330, !tbaa !21
  br i1 %t661, label %bb209, label %bb210
bb209:
  store i1 true, ptr %l331, !tbaa !21
  br label %bb212
bb210:
  %t662 = load ptr, ptr %l32, !tbaa !29
  %t664 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t667 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t662, { i64, ptr } %t664)
  store i1 %t667, ptr %l335
  br label %bb211
bb211:
  %t668 = load i1, ptr %l335, !tbaa !21
  store i1 %t668, ptr %l331, !tbaa !21
  br label %bb212
bb212:
  %t669 = load i1, ptr %l331, !tbaa !21
  br i1 %t669, label %bb213, label %bb214
bb213:
  store i1 true, ptr %rv
  br label %ret
bb214:
  br label %bb215
bb215:
  br label %bb216
bb216:
  %t671 = load i64, ptr %l30, !tbaa !24
  %t673 = add i64 %t671, 1
  store i64 %t673, ptr %l30, !tbaa !24
  br label %bb204
bb217:
  %t675 = load ptr, ptr %l28, !tbaa !29
  %t677 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t680 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t675, { i64, ptr } %t677)
  store i1 %t680, ptr %l342
  br label %bb218
bb218:
  %t681 = load i1, ptr %l342, !tbaa !21
  store i1 %t681, ptr %rv
  br label %ret
bb219:
  call void @__olang_check_failed(ptr @olang_loc_3f7a94628940c729_cdb98f41ead125dd)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l18 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t4, ptr %t6)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Match", ptr %t9, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %t32, ptr %t35)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:EmbedAsk" @compiler_2fcheck_3aEmbedAsk_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/check:EmbedAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:EmbedAsk" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/check:EmbedAsk" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/check:EmbedAsk" %t10, i32 %a2, 2
  store %"compiler/check:EmbedAsk" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:EmbedAsk", ptr %rv
  ret %"compiler/check:EmbedAsk" %rr
}

define dso_local %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/check:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:Gap" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/check:Gap" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/check:Gap" %t10, { i64, ptr } %a2, 2
  store %"compiler/check:Gap" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:Gap", ptr %rv
  ret %"compiler/check:Gap" %rr
}

define dso_local %"compiler/check:rawTable" @compiler_2fcheck_3arawTable_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i1 %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/check:rawTable"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:rawTable" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/check:rawTable" %t10, i1 %a1, 1
  %t14 = insertvalue %"compiler/check:rawTable" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/check:rawTable" %t14, { i64, ptr } %a3, 3
  store %"compiler/check:rawTable" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:rawTable", ptr %rv
  ret %"compiler/check:rawTable" %rr
}

define dso_local %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i1 %a3, i64 %a4, %"compiler/source:Span" %a5, i32 %a6, i1 %a7) #0 {
entry:
  %rv = alloca %"compiler/check:unsetCand"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/check:unsetCand" undef, i64 %a0, 0
  %t20 = insertvalue %"compiler/check:unsetCand" %t18, i64 %a1, 1
  %t22 = insertvalue %"compiler/check:unsetCand" %t20, i64 %a2, 2
  %t24 = insertvalue %"compiler/check:unsetCand" %t22, i1 %a3, 3
  %t26 = insertvalue %"compiler/check:unsetCand" %t24, i64 %a4, 4
  %t28 = insertvalue %"compiler/check:unsetCand" %t26, %"compiler/source:Span" %a5, 5
  %t30 = insertvalue %"compiler/check:unsetCand" %t28, i32 %a6, 6
  %t32 = insertvalue %"compiler/check:unsetCand" %t30, i1 %a7, 7
  store %"compiler/check:unsetCand" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:unsetCand", ptr %rv
  ret %"compiler/check:unsetCand" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Attr" }>, align 8
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"HasAttr" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_5(ptr %env, i32 %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrBefore(ptr %vc0, ptr %cv0, i32 %a0, i32 %a1)
  store i1 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_empty_array = external constant [16 x i64]
declare void @__olang_ert_req_clear()
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!=" }>, align 8
@.d18 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"==" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d20 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c".Len() > 0" }>, align 8
@.d21 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c".Len() == 0" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d23 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"try" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d25 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/array" }>, align 8
@.d26 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ArrayError" }>, align 8
@.d27 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"OutOfRange" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Name" }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d30 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d31 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d34 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d36 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d38 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Default" }>, align 8
@.d39 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"Name, Type, Offset, Of, Attr and HasAttr" }>, align 8
@.d40 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"Name, Fields, Attr and HasAttr" }>, align 8
@.d41 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"Name, Type, HasDefault, Default, Attr and HasAttr" }>, align 8
@.d42 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"Name, Type, Params, Results, Errors, Attr and HasAttr - and it is called" }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d44 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"field" }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"case" }>, align 8
@.d46 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"parameter" }>, align 8
@.d47 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"function" }>, align 8
@.d48 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"result" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d56 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d57 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extends" }>, align 8
@.d58 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/enums" }>, align 8
@.d59 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"CaseError" }>, align 8
@.d60 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"WrongCase" }>, align 8
declare i128 @llvm.ctlz.i128(i128, i1)
declare bfloat @__olang_int_bf16(i64, i1)
declare double @llvm.arithmetic.fence.f64(double)
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
declare i64 @__olang_fmt_u128(ptr, i128)
declare i64 @__olang_fmt_u64(ptr, i64)
declare i64 @__olang_fmt_i64(ptr, i64)
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"compiler/check:litv" @compiler_2fcheck_2enoLit()
declare %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %a0, i128 %a1)
@olang_loc_27266ce16db26f9e_9560a2a6a3954b82 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_b38f45ec26bed975_efda74b8eb60f0c1 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternRules(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportRules(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorMethod(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einheritClash(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverrideClash(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodOverlap(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnTypeParams(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSets(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForms(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etailSets(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettle(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_e8df0bdf3cd721f8_b505cb518d2727a4 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_15d8d795344f0f34_d9e3bc129d8abb98 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@olang_loc_2b2e21654e3310f6_a1c2a2453bd05f02 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_f6343df54e321530_17a07bfc25de31ec = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2eprotocolArity(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolBothSpellings(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2farray_2eArray_3ccompiler_2ftypes_3aTypeId_3e_2eSort_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f18babf7f50c335e_33607163d02cbb5a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %v0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eToA_H65e94094dadf75016f6073f244c91f3b(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
@olang_loc_f9674bcb1008789c_bed0ff146db7b878 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
@olang_loc_7d2067b11442aa69_727f8f68f20a38e5 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
@olang_loc_fe55a007e1b3e29_3c78fea0979d4bfd = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_c4a343fb9b24edff_3458e4f6b03fbc5b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_bc2b949bbef92b23_ac5d28fb0edf1ff = external constant [0 x i8]
@olang_loc_fc391d98a693d1b5_39c844f8cb4c6229 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCountRange(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ff2084232290eae7_203579eb66e705cb = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ehasNamed(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_7f8223142f689eb4_f934e4a817092f38 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_a395790432891bd8_5a5437b807a0153c = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchErrorWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
@olang_loc_fde34f6ad3d04e85_8bb8dc064f471149 = external constant [0 x i8]
@olang_loc_7e2870e38111b7d4_913a9c3a02b86678 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2enullValue(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsCover(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenElem(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fgeneric_2eGenPerTurn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_d7ab675994707360_a9a9e17072f91bbc = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenElemWritable(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenElemNullable(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2fgeneric_2eGenBadScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenElemScopeUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenElemByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_dacfb485414cf771_d273518bcacb276d = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_48c434cc052a730a_3ea1b318a5aaa0d6 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsOnlyNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsCaseWritten(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNullOfNull(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNonNull(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNullOfValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayIsNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeverNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
@olang_loc_6c69e074d5382e65_c76aefb5b106fb41 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, ptr %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eTrunca_Hc8531d0d5535cc9766a27157f9c0b07c(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2fcheck_2eLaneUn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_968ede9ca4457b20_d4cd8e7344b6f50c = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_77892b47b9a99b47_46cd468a4d441f7b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNothingFails(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderModule(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fcheck_3arawTable_2_H63c69eede5e7cc65b54d8ce1ed292a98(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fcheck_3arawTable_2_Hc06038cfd2a883d900a989353ba26a88(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_4c4a12b05c2c1d31_444cdf7465594545 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawTable(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fcheck_3arawTable_2_Hfe32448d245bb62a962210add151a121(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflListValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflVal" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoKind(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoLength(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoLayout(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDefault(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/generic:Desc" %a2)
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@olang_loc_6fa12bf18c08968_7f63ef0109416d3c = external constant [0 x i8]
@olang_loc_366830190f407939_a82d5f1c611378ed = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6b233227628ca57_40576c0d91c202cb = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H970bb490312910b3b744570a26468c6c(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd27b567062a69be2f699d8e9ab74cf5a(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a2)
declare { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hca9d4f63e6a0ec4764c25705e3ecdd1f(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimmutableGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_29e885d4e6352517_4af5f3c2b7cab7a3 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_62c5ac3e914a4019_8e197c98e172d865 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a1)
@olang_loc_19fb235390dd08bf_74b3a6d5c5264653 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryChecks(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultExisting(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTestTargetTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTestTargetElsewhere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTestTargetUnknownMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTestTargetUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotConverted(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyMeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyTable(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCopies(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2eCtorOwner(i32 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
@olang_loc_86f2d648d7a819c5_fc1d6e84e063e4d9 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarsNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
@olang_loc_e722c21055ee6b49_58bcebf0b772fb7d = external constant [0 x i8]
@olang_loc_eca48244095fc078_aacf4c954a6e214c = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarNamesType(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_42d76eb8aa19d24d_a6d8d644d4fa1309 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotStruct(ptr %v0)
@olang_loc_e4a3554ab68c2525_45e0e0bdd3564951 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorVarRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_ae3b040bf00e496e_c2dc96e6bf91aeba = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredOverAggregate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsSelf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayTypeHoldsItself(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_23ed2e0ac54fea2f_24addeed96b3b3b = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2efieldSpans(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_ce02ed0312eba71_989ffc88692334e5 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7c3b8624efb20ec9_1268f42db05aedcd = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExtendsNotBase(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflTryList(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %a0)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8302d182975d1c39_f0b10209f7a6052d = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_61f61c7eea085c49_e2109341212ff245 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5688429828d7ebe2_8ea9fe01fea3ad9e = external constant [0 x i8]
@olang_loc_83df14ccfb59caa2_79e7c0956b45666e = external constant [0 x i8]
@olang_loc_94831dcf6c50df99_e0fe015107062615 = external constant [0 x i8]
@olang_loc_f65b5445e0db363a_c2ab951bd73e6226 = external constant [0 x i8]
@olang_loc_327c34393f585585_f16c5fd873651789 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_3f7a94628940c729_cdb98f41ead125dd = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrBefore(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
