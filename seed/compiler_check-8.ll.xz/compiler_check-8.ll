; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:ValueAsk" = type { i32, i64, %"compiler/source:Span", i32, i64, { i64, [3 x i64] } }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:Ask" = type { i64, i64, i32, ptr, i64, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:atRec" = type { i64, i64, ptr, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/check:roDeepArg" = type { i64, ptr, i64, i64 }
%"compiler/check:roOrigin" = type { ptr, i1 }
define dso_local void @compiler_2fcheck_2eCtEntry_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2fcheck_2eCtEntry, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store ptr null, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TypeDecl", ptr %t14, i32 0, i32 3
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l2, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 1
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr { i64, [6 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { { i64, ptr }, ptr }, ptr %t30, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t34 = load i64, ptr %l1, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp slt i64 %t34, %t37
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l23, !tbaa !29
  br label %bb14
bb13:
  store ptr null, ptr %l23, !tbaa !29
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l23, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
bb15:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca { i64, [2 x i64] }
  %l30 = alloca i32
  %l33 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l44 = alloca %"compiler/generic:Context"
  %l46 = alloca ptr
  %l49 = alloca i32
  %l52 = alloca i64
  %l56 = alloca i32
  %l63 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca i32
  %l76 = alloca i1
  %l81 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l90 = alloca i32
  %l96 = alloca ptr
  %l100 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l106 = alloca %"compiler/source:Span"
  %l107 = alloca i32
  %l109 = alloca { i64, ptr }
  %l113 = alloca i32
  %l114 = alloca %"compiler/typed:Text"
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l126 = alloca { i64, ptr }
  %l127 = alloca %"compiler/typed:Block"
  %l135 = alloca i64
  %l143 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t24 = alloca { i64, [2 x i64] }, align 8
  %t100 = alloca { i64, [4 x i64] }, align 8
  %t178 = alloca { i64, [5 x i64] }, align 8
  %t190 = alloca { i64, [2 x i64] }, align 8
  %t200 = alloca { i64, [2 x i64] }, align 8
  %t230 = alloca { i64, [5 x i64] }, align 8
  %t242 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l19
  br label %bb1
bb1:
  %t15 = load i64, ptr %l19, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t16)
  store i32 %t18, ptr %l21
  br label %bb2
bb2:
  %t19 = load i32, ptr %l21, !tbaa !23
  store i32 %t19, ptr %l6, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l22, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 0
  store i64 7, ptr %t25
  %t27 = insertvalue { i64, i32 } undef, i64 %t21, 0
  %t29 = insertvalue { i64, i32 } %t27, i32 %t23, 1
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 1
  store { i64, i32 } %t29, ptr %t30
  %t31 = load { i64, [2 x i64] }, ptr %t24
  store { i64, [2 x i64] } %t31, ptr %l25
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t37, i32 0, i32 %t38, i32 0, i32 0, i64 0)
  store i32 %t41, ptr %l30
  br label %bb3
bb3:
  %t42 = load i64, ptr %l1, !tbaa !24
  %t43 = load %"compiler/source:Span", ptr %l3
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load { i64, [2 x i64] }, ptr %l25
  %t46 = load i32, ptr %l30, !tbaa !23
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t44, { i64, [2 x i64] } %t45, i32 %t46, i64 %t42, %"compiler/source:Span" %t43)
  store i64 %t49, ptr %l33
  br label %bb4
bb4:
  %t50 = load i64, ptr %l33, !tbaa !24
  store i64 %t50, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 16
  %t54 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t53, i64 %t54, i64 1)
  br label %bb5
bb5:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = load i32, ptr %l6, !tbaa !23
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t57, i64 %t58, i64 %t59, i32 %t60, i32 0)
  store ptr %t65, ptr %l41
  br label %bb6
bb6:
  %t66 = load ptr, ptr %l41, !tbaa !29
  store ptr %t66, ptr %l42, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  %t70 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %t68, i64 -1)
  store %"compiler/generic:Context" %t70, ptr %l44
  br label %bb7
bb7:
  %t71 = load %"compiler/generic:Context", ptr %l44
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = getelementptr %"compiler/check:frame", ptr %t72, i32 0, i32 4
  store %"compiler/generic:Context" %t71, ptr %t73
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t74)
  store ptr %t76, ptr %l46
  br label %bb8
bb8:
  %t77 = load %"compiler/source:Span", ptr %l3
  %t78 = load ptr, ptr %l46, !tbaa !29
  %t81 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t78, i32 -1, i32 0, %"compiler/source:Span" %t77)
  store i32 %t81, ptr %l49
  br label %bb9
bb9:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 33
  %t86 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l52
  br label %bb10
bb10:
  %t87 = load i64, ptr %l52, !tbaa !24
  store i64 %t87, ptr %l9, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load i32, ptr %l2, !tbaa !23
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t88, i64 %t89, i32 %t90)
  store i32 %t94, ptr %l56
  br label %bb11
bb11:
  %t95 = load i32, ptr %l56, !tbaa !23
  store i32 %t95, ptr %l10, !tbaa !23
  %t96 = load %"compiler/source:Span", ptr %l3
  %t97 = load i32, ptr %l10, !tbaa !23
  %t98 = load i64, ptr %l1, !tbaa !24
  %t99 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 0
  store i64 1, ptr %t101
  %t103 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t96, 0
  %t105 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t103, i32 %t97, 1
  %t107 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t105, i64 %t98, 2
  %t109 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t107, i32 %t99, 3
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t109, ptr %t110
  %t111 = load { i64, [4 x i64] }, ptr %t100
  %t113 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t111, ptr %t113
  store ptr %t113, ptr %l11, !tbaa !29
  %t115 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %l63
  br label %bb12
bb12:
  %t116 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %l12
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %s0, ptr %t117, i32 %t118, ptr %l12, i64 0)
  br label %bb13
bb13:
  %t122 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %l67
  br label %bb14
bb14:
  %t123 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l67
  %t124 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t123, ptr %t124
  store ptr %t124, ptr %l13, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l10, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l73
  br label %bb15
bb15:
  %t136 = load i32, ptr %l73
  %t138 = trunc i64 19 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb16, label %bb17
bb16:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l10, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l81
  br label %bb18
bb17:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb19
bb18:
  %t151 = load i32, ptr %l81, !tbaa !23
  %t152 = icmp ne i32 %t151, 0
  store i1 %t152, ptr %l76, !tbaa !21
  br label %bb19
bb19:
  %t154 = load i1, ptr %l76, !tbaa !21
  br i1 %t154, label %bb20, label %bb21
bb20:
  %t155 = load ptr, ptr %l13, !tbaa !29
  store ptr %t155, ptr %l83, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t156, ptr %l84
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  %t163 = load i32, ptr %l10, !tbaa !23
  %t164 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t162, i32 %t163, i64 %t164)
  store i32 %t168, ptr %l90
  br label %bb22
bb21:
  %t169 = load ptr, ptr %l13, !tbaa !29
  store ptr %t169, ptr %l96, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l3
  %t172 = load ptr, ptr %l11, !tbaa !29
  %t176 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t170, %"compiler/source:Span" %t171, ptr %t172)
  store ptr %t176, ptr %l100
  br label %bb24
bb22:
  %t177 = load ptr, ptr %l11, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 0
  store i64 3, ptr %t179
  %t180 = load %"compiler/source:Span", ptr %l84
  %t181 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t180, 0
  %t182 = load i32, ptr %l90, !tbaa !23
  %t183 = insertvalue { %"compiler/source:Span", i32, ptr } %t181, i32 %t182, 1
  %t185 = insertvalue { %"compiler/source:Span", i32, ptr } %t183, ptr %t177, 2
  %t186 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t185, ptr %t186
  %t187 = load { i64, [5 x i64] }, ptr %t178
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t187, ptr %t189
  store { i64, [2 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [2 x i64] }, ptr %t190, i32 0, i32 0
  store i64 1, ptr %t191
  %t193 = insertvalue { ptr } undef, ptr %t189, 0
  %t194 = getelementptr { i64, [2 x i64] }, ptr %t190, i32 0, i32 1
  store { ptr } %t193, ptr %t194
  %t195 = load { i64, [2 x i64] }, ptr %t190
  %t197 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t195, ptr %t197
  %t198 = load ptr, ptr %l83, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2ePu_Hf3d190a214b599b1db3fb8bde0778037(ptr %v0, ptr %v0, ptr %t198, ptr %t197)
  br label %bb23
bb23:
  br label %bb26
bb24:
  store { i64, [2 x i64] } zeroinitializer, ptr %t200
  %t201 = getelementptr { i64, [2 x i64] }, ptr %t200, i32 0, i32 0
  store i64 1, ptr %t201
  %t202 = load ptr, ptr %l100, !tbaa !29
  %t203 = insertvalue { ptr } undef, ptr %t202, 0
  %t204 = getelementptr { i64, [2 x i64] }, ptr %t200, i32 0, i32 1
  store { ptr } %t203, ptr %t204
  %t205 = load { i64, [2 x i64] }, ptr %t200
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t205, ptr %t207
  %t208 = load ptr, ptr %l96, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2ePu_Hf3d190a214b599b1db3fb8bde0778037(ptr %v0, ptr %v0, ptr %t208, ptr %t207)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 33
  store ptr %t212, ptr %l104, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t213, ptr %l105
  %t214 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t214, ptr %l106
  %t215 = load i32, ptr %l6, !tbaa !23
  store i32 %t215, ptr %l107, !tbaa !23
  %t216 = load ptr, ptr %l13, !tbaa !29
  %t218 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2eTo_H8a5ee0a19875600d5129e9d1ac97555e(ptr %v0, ptr %v0, ptr %t216)
  store { i64, ptr } %t218, ptr %l109
  br label %bb27
bb27:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l3
  %t224 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t219, i32 4, %"compiler/source:Span" %t220)
  store i32 %t224, ptr %l113
  br label %bb28
bb28:
  %t225 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t226 = load i32, ptr %l113, !tbaa !23
  %t227 = call %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v0, { i64, ptr } %t225, i32 %t226)
  store %"compiler/typed:Text" %t227, ptr %l114
  br label %bb29
bb29:
  %t228 = load %"compiler/typed:Text", ptr %l114
  %t229 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Text" %t228, ptr %t229
  store { i64, [5 x i64] } zeroinitializer, ptr %t230
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t230, i32 0, i32 0
  store i64 16, ptr %t231
  %t232 = load %"compiler/source:Span", ptr %l106
  %t233 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t232, 0
  %t234 = load i32, ptr %l107, !tbaa !23
  %t235 = insertvalue { %"compiler/source:Span", i32, ptr } %t233, i32 %t234, 1
  %t237 = insertvalue { %"compiler/source:Span", i32, ptr } %t235, ptr %t229, 2
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t230, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t237, ptr %t238
  %t239 = load { i64, [5 x i64] }, ptr %t230
  %t241 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t239, ptr %t241
  store { i64, [3 x i64] } zeroinitializer, ptr %t242
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t242, i32 0, i32 0
  store i64 6, ptr %t243
  %t244 = load %"compiler/source:Span", ptr %l105
  %t245 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t244, 0
  %t247 = insertvalue { %"compiler/source:Span", ptr } %t245, ptr %t241, 1
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t242, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t247, ptr %t248
  %t249 = load { i64, [3 x i64] }, ptr %t242
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t249, ptr %t251
  %t252 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t252, ptr %t251)
  br label %bb30
bb30:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t254)
  store ptr %t256, ptr %l121
  br label %bb31
bb31:
  %t257 = load ptr, ptr %l121, !tbaa !29
  store ptr %t257, ptr %l122, !tbaa !29
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/check:Checker", ptr %t258, i32 0, i32 33
  %t261 = load i64, ptr %l9, !tbaa !24
  %t264 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t260, i64 %t261)
  store { i64, ptr } %t264, ptr %l126
  br label %bb32
bb32:
  %t265 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t266 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t265)
  store %"compiler/typed:Block" %t266, ptr %l127
  br label %bb33
bb33:
  %t267 = load %"compiler/typed:Block", ptr %l127
  %t268 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t267, ptr %t268
  %t270 = load ptr, ptr %l122, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Body", ptr %t270, i32 0, i32 11
  store ptr %t268, ptr %t271, !tbaa !29
  %t272 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t272)
  br label %bb34
bb34:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 16
  %t277 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t276, i64 %t277, i64 2)
  br label %bb35
bb35:
  %t280 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t280)
  br label %bb36
bb36:
  %t282 = load ptr, ptr %l4, !tbaa !29
  %t284 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t282)
  store i64 %t284, ptr %l135
  br label %bb37
bb37:
  %t285 = load i64, ptr %l5, !tbaa !24
  %t286 = load i64, ptr %l135, !tbaa !24
  %t288 = icmp sgt i64 %t286, %t285
  br i1 %t288, label %bb38, label %bb39
bb38:
  %t290 = load ptr, ptr %l4, !tbaa !29
  %t291 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t290, i64 %t291)
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/check:Checker", ptr %t294, i32 0, i32 11
  %t297 = load i64, ptr %l7, !tbaa !24
  %t300 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t296, i64 %t297)
  store ptr %t300, ptr %l143
  br label %bb41
bb41:
  %t301 = load ptr, ptr %l143, !tbaa !29
  %t303 = getelementptr %"compiler/typed:Body", ptr %t301, i32 0, i32 11
  store ptr null, ptr %t303, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb42:
  %t305 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t305, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l18 = alloca { i64, ptr }
  %l25 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t28, ptr %a2)
  store i1 %t37, ptr %l25
  br label %bb8
bb8:
  %t38 = load i1, ptr %l25, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb4
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 64
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = sub i64 0, 1
  store i64 %t11, ptr %l8, !tbaa !65
  br label %bb4
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l10, !tbaa !24
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = shl i64 1, %t15
  %t18 = sub i64 %t16, 1
  store i64 %t18, ptr %l8, !tbaa !65
  br label %bb4
bb4:
  %t20 = load i64, ptr %l8, !tbaa !65
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:Context"
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i1
  %l21 = alloca i64
  %l23 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca %"compiler/source:Span"
  %l60 = alloca { i64, ptr }
  %l62 = alloca %"compiler/msgs:Msg"
  %l63 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i64
  %l71 = alloca ptr
  %l78 = alloca ptr
  %l81 = alloca { i64, [2 x i64] }
  %l86 = alloca i32
  %l89 = alloca i64
  %l97 = alloca ptr
  %l101 = alloca ptr
  %l104 = alloca i32
  %l107 = alloca i64
  %l111 = alloca ptr
  %l116 = alloca ptr
  %l120 = alloca ptr
  %l126 = alloca ptr
  %l135 = alloca ptr
  %l136 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l141 = alloca %"compiler/typed:Block"
  %l149 = alloca i64
  %l152 = alloca i1
  %l155 = alloca i64
  %l166 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca i64
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca i32
  %l174 = alloca i64
  %l182 = alloca { i64, [3 x i64] }
  %l183 = alloca %"compiler/check:ValueAsk"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t140 = alloca { i64, [2 x i64] }, align 8
  %t243 = alloca { i64, [3 x i64] }, align 8
  %t341 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 85
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 13
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l21
  br label %bb3
bb3:
  %t11 = load i64, ptr %l21, !tbaa !24
  %t12 = icmp eq i64 %t11, 0
  store i1 %t12, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l18, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb7
bb6:
  %t15 = load i32, ptr %l3, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp eq i32 %t15, %t16
  store i1 %t19, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l23, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t22 = load i32, ptr %l1
  %t24 = trunc i64 0 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l33
  br label %bb13
bb12:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  %t34 = load i1, ptr %l33, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l30, !tbaa !21
  br i1 %t37, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  br label %bb17
bb17:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 4
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l5, !tbaa !29
  %t49 = load i32, ptr %l1
  %t51 = trunc i64 0 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l3, !tbaa !23
  %t60 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l45
  br label %bb20
bb19:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb21
bb20:
  %t61 = load i1, ptr %l45, !tbaa !21
  store i1 %t61, ptr %l42, !tbaa !21
  br label %bb21
bb21:
  %t62 = load i1, ptr %l42, !tbaa !21
  br i1 %t62, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l48, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l3, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l53
  br label %bb24
bb23:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb26
bb24:
  %t77 = load ptr, ptr %l48, !tbaa !29
  %t78 = load i32, ptr %l53, !tbaa !23
  %t79 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %t77, i32 %t78)
  store i64 %t79, ptr %l54
  br label %bb25
bb25:
  %t80 = load i64, ptr %l54, !tbaa !24
  %t81 = icmp sgt i64 %t80, 0
  store i1 %t81, ptr %l46, !tbaa !21
  br label %bb26
bb26:
  %t83 = load i1, ptr %l46, !tbaa !21
  br i1 %t83, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l56, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t85, ptr %l57
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t86, i32 %t87)
  store { i64, ptr } %t90, ptr %l60
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t91 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t93 = extractvalue { i64, ptr } %t91, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t99 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t97, { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t99, ptr %l62
  br label %bb30
bb30:
  %t100 = load ptr, ptr %l56, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l57
  %t102 = load %"compiler/msgs:Msg", ptr %l62
  %t103 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t100, %"compiler/source:Span" %t101, %"compiler/msgs:Msg" %t102)
  store i64 %t103, ptr %l63
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t104 = load ptr, ptr %l5, !tbaa !29
  %t106 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t104)
  store i64 %t106, ptr %l65
  br label %bb33
bb33:
  %t107 = load i64, ptr %l65, !tbaa !24
  store i64 %t107, ptr %l6, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 12
  %t112 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t110)
  store i64 %t112, ptr %l68
  br label %bb34
bb34:
  %t113 = load i64, ptr %l68, !tbaa !24
  store i64 %t113, ptr %l7, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 85
  store i1 true, ptr %t116, !tbaa !21
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t117)
  store ptr %t119, ptr %l71
  br label %bb35
bb35:
  %t120 = load ptr, ptr %l71, !tbaa !29
  store ptr %t120, ptr %l8, !tbaa !29
  %t121 = load ptr, ptr %l8, !tbaa !29
  %t123 = getelementptr %"compiler/check:frame", ptr %t121, i32 0, i32 1
  %t124 = load i64, ptr %t123, !tbaa !24
  store i64 %t124, ptr %l9, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t128 = getelementptr %"compiler/check:frame", ptr %t126, i32 0, i32 2
  %t129 = load i64, ptr %t128, !tbaa !24
  store i64 %t129, ptr %l10, !tbaa !24
  %t131 = load ptr, ptr %l8, !tbaa !29
  %t133 = getelementptr %"compiler/check:frame", ptr %t131, i32 0, i32 4
  %t134 = load %"compiler/generic:Context", ptr %t133
  store %"compiler/generic:Context" %t134, ptr %l11
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l78, !tbaa !29
  %t137 = load i64, ptr %l9, !tbaa !24
  %t138 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t139 = load i32, ptr %t138, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [2 x i64] }, ptr %t140, i32 0, i32 0
  store i64 7, ptr %t141
  %t143 = insertvalue { i64, i32 } undef, i64 %t137, 0
  %t145 = insertvalue { i64, i32 } %t143, i32 %t139, 1
  %t146 = getelementptr { i64, [2 x i64] }, ptr %t140, i32 0, i32 1
  store { i64, i32 } %t145, ptr %t146
  %t147 = load { i64, [2 x i64] }, ptr %t140
  store { i64, [2 x i64] } %t147, ptr %l81
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load i32, ptr %l3, !tbaa !23
  %t157 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t153, i32 0, i32 %t154, i32 0, i32 0, i64 0)
  store i32 %t157, ptr %l86
  br label %bb36
bb36:
  %t158 = load i64, ptr %l9, !tbaa !24
  %t159 = load %"compiler/source:Span", ptr %l2
  %t160 = load ptr, ptr %l78, !tbaa !29
  %t161 = load { i64, [2 x i64] }, ptr %l81
  %t162 = load i32, ptr %l86, !tbaa !23
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t160, { i64, [2 x i64] } %t161, i32 %t162, i64 %t158, %"compiler/source:Span" %t159)
  store i64 %t165, ptr %l89
  br label %bb37
bb37:
  %t166 = load i64, ptr %l89, !tbaa !24
  store i64 %t166, ptr %l12, !tbaa !24
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 16
  %t170 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t169, i64 %t170, i64 1)
  br label %bb38
bb38:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l12, !tbaa !24
  %t175 = load i64, ptr %l9, !tbaa !24
  %t176 = load i32, ptr %l3, !tbaa !23
  %t181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t173, i64 %t174, i64 %t175, i32 %t176, i32 0)
  store ptr %t181, ptr %l97
  br label %bb39
bb39:
  %t182 = load ptr, ptr %l97, !tbaa !29
  %t184 = load %"compiler/generic:Context", ptr %l11
  %t187 = getelementptr %"compiler/check:frame", ptr %t182, i32 0, i32 4
  store %"compiler/generic:Context" %t184, ptr %t187
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t188)
  store ptr %t190, ptr %l101
  br label %bb40
bb40:
  %t191 = load %"compiler/source:Span", ptr %l2
  %t192 = load ptr, ptr %l101, !tbaa !29
  %t195 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t192, i32 -1, i32 0, %"compiler/source:Span" %t191)
  store i32 %t195, ptr %l104
  br label %bb41
bb41:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 33
  %t200 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t198)
  store i64 %t200, ptr %l107
  br label %bb42
bb42:
  %t201 = load i64, ptr %l107, !tbaa !24
  store i64 %t201, ptr %l14, !tbaa !24
  %t202 = load ptr, ptr %l4, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb43, label %bb44
bb43:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l4, !tbaa !29
  %t211 = load i32, ptr %l3, !tbaa !23
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %t208, ptr %t209, i32 %t211)
  store ptr %t215, ptr %l116
  br label %bb45
bb44:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l2
  %t218 = load i32, ptr %l3, !tbaa !23
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %t216, %"compiler/source:Span" %t217, i32 %t218)
  store ptr %t222, ptr %l120
  br label %bb46
bb45:
  %t223 = load ptr, ptr %l116, !tbaa !29
  store ptr %t223, ptr %l111, !tbaa !29
  br label %bb47
bb46:
  %t224 = load ptr, ptr %l120, !tbaa !29
  store ptr %t224, ptr %l111, !tbaa !29
  br label %bb47
bb47:
  %t226 = load ptr, ptr %l111, !tbaa !29
  store ptr %t226, ptr %l15, !tbaa !29
  %t227 = load ptr, ptr %l15, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  br i1 %t229, label %bb48, label %bb49
bb48:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l2
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t231, %"compiler/source:Span" %t232)
  store ptr %t235, ptr %l126
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t236 = load ptr, ptr %l126, !tbaa !29
  store ptr %t236, ptr %l15, !tbaa !29
  br label %bb51
bb51:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 33
  %t241 = load %"compiler/source:Span", ptr %l2
  %t242 = load ptr, ptr %l15, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t243
  %t244 = getelementptr { i64, [3 x i64] }, ptr %t243, i32 0, i32 0
  store i64 6, ptr %t244
  %t246 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t241, 0
  %t248 = insertvalue { %"compiler/source:Span", ptr } %t246, ptr %t242, 1
  %t249 = getelementptr { i64, [3 x i64] }, ptr %t243, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t248, ptr %t249
  %t250 = load { i64, [3 x i64] }, ptr %t243
  %t252 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t250, ptr %t252
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t240, ptr %t252)
  br label %bb52
bb52:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t255)
  store ptr %t257, ptr %l135
  br label %bb53
bb53:
  %t258 = load ptr, ptr %l135, !tbaa !29
  store ptr %t258, ptr %l136, !tbaa !29
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t259, i32 0, i32 33
  %t262 = load i64, ptr %l14, !tbaa !24
  %t265 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t261, i64 %t262)
  store { i64, ptr } %t265, ptr %l140
  br label %bb54
bb54:
  %t266 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t267 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t266)
  store %"compiler/typed:Block" %t267, ptr %l141
  br label %bb55
bb55:
  %t268 = load %"compiler/typed:Block", ptr %l141
  %t269 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t268, ptr %t269
  %t271 = load ptr, ptr %l136, !tbaa !29
  %t272 = getelementptr %"compiler/typed:Body", ptr %t271, i32 0, i32 11
  store ptr %t269, ptr %t272, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t273)
  br label %bb56
bb56:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 16
  %t278 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t277, i64 %t278, i64 2)
  br label %bb57
bb57:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 85
  store i1 false, ptr %t283, !tbaa !21
  %t284 = load ptr, ptr %l5, !tbaa !29
  %t286 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t284)
  store i64 %t286, ptr %l149
  br label %bb58
bb58:
  %t287 = load i64, ptr %l6, !tbaa !24
  %t288 = load i64, ptr %l149, !tbaa !24
  %t290 = icmp sgt i64 %t288, %t287
  br i1 %t290, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l152, !tbaa !21
  br label %bb62
bb60:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 12
  %t296 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t294)
  store i64 %t296, ptr %l155
  br label %bb61
bb61:
  %t297 = load i64, ptr %l7, !tbaa !24
  %t298 = load i64, ptr %l155, !tbaa !24
  %t300 = icmp sgt i64 %t298, %t297
  store i1 %t300, ptr %l152, !tbaa !21
  br label %bb62
bb62:
  %t302 = load i1, ptr %l152, !tbaa !21
  br i1 %t302, label %bb63, label %bb64
bb63:
  %t303 = load ptr, ptr %l5, !tbaa !29
  %t304 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t303, i64 %t304)
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 12
  %t310 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2eTruncate_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t309, i64 %t310)
  br label %bb66
bb66:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/check:Checker", ptr %t313, i32 0, i32 11
  %t316 = load i64, ptr %l12, !tbaa !24
  %t319 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t315, i64 %t316)
  store ptr %t319, ptr %l166
  br label %bb67
bb67:
  %t320 = load ptr, ptr %l166, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Body", ptr %t320, i32 0, i32 11
  store ptr null, ptr %t322, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb68:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/check:Checker", ptr %t323, i32 0, i32 79
  store ptr %t325, ptr %l169, !tbaa !29
  %t326 = load i32, ptr %l1
  store i32 %t326, ptr %l170
  %t327 = load i64, ptr %l10, !tbaa !24
  store i64 %t327, ptr %l171, !tbaa !24
  %t328 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t328, ptr %l172
  %t329 = load i32, ptr %l3, !tbaa !23
  store i32 %t329, ptr %l173, !tbaa !23
  %t330 = load i64, ptr %l12, !tbaa !24
  store i64 %t330, ptr %l174, !tbaa !24
  %t331 = load ptr, ptr %l5, !tbaa !29
  %t332 = load i64, ptr %l10, !tbaa !24
  %t333 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t334 = load i32, ptr %t333, !tbaa !23
  %t336 = sext i32 %t334 to i64
  %t337 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t338 = load i32, ptr %t337, !tbaa !23
  %t340 = sext i32 %t338 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t341
  %t342 = getelementptr { i64, [3 x i64] }, ptr %t341, i32 0, i32 0
  store i64 3, ptr %t342
  %t344 = insertvalue { i64, i64, i64 } undef, i64 %t332, 0
  %t346 = insertvalue { i64, i64, i64 } %t344, i64 %t336, 1
  %t348 = insertvalue { i64, i64, i64 } %t346, i64 %t340, 2
  %t349 = getelementptr { i64, [3 x i64] }, ptr %t341, i32 0, i32 1
  store { i64, i64, i64 } %t348, ptr %t349
  %t350 = load { i64, [3 x i64] }, ptr %t341
  %t353 = call { i64, [3 x i64] } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eUseOf(ptr %v0, ptr %t331, { i64, [3 x i64] } %t350)
  store { i64, [3 x i64] } %t353, ptr %l182
  br label %bb69
bb69:
  %t354 = load i32, ptr %l170
  %t355 = load i64, ptr %l171, !tbaa !24
  %t356 = load %"compiler/source:Span", ptr %l172
  %t357 = load i32, ptr %l173, !tbaa !23
  %t358 = load i64, ptr %l174, !tbaa !24
  %t359 = load { i64, [3 x i64] }, ptr %l182
  %t360 = call %"compiler/check:ValueAsk" @compiler_2fcheck_3aValueAsk_2ector(ptr %s0, i32 %t354, i64 %t355, %"compiler/source:Span" %t356, i32 %t357, i64 %t358, { i64, [3 x i64] } %t359)
  store %"compiler/check:ValueAsk" %t360, ptr %l183
  br label %bb70
bb70:
  %t361 = load ptr, ptr %l169, !tbaa !29
  %t362 = load %"compiler/check:ValueAsk", ptr %l183
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2ePu_Hfa45de49c8c8d06dcd560076652adff8(ptr %v0, ptr %t361, %"compiler/check:ValueAsk" %t362)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebang(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %lp10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i32
  %l32 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i32
  %l59 = alloca i1
  %l61 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca %"compiler/msgs:Msg"
  %l74 = alloca i64
  %l77 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l84 = alloca i32
  %l86 = alloca ptr
  %l90 = alloca %"compiler/typed:Try"
  %l94 = alloca ptr
  %l98 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t167 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l12, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 25
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 16
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l6, !tbaa !24
  %t16 = load ptr, ptr %l4, !tbaa !29
  store ptr %t16, ptr %l18, !tbaa !29
  %t17 = load ptr, ptr %l18, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 15
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 15
  store i64 %t21, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store ptr %a2, ptr %l23, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l26
  br label %bb3
bb3:
  %t33 = load i1, ptr %l26, !tbaa !21
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l32
  br label %bb6
bb5:
  %t44 = load i32, ptr %l3, !tbaa !23
  store i32 %t44, ptr %l27, !tbaa !23
  br label %bb7
bb6:
  %t46 = load i32, ptr %l32, !tbaa !23
  store i32 %t46, ptr %l27, !tbaa !23
  br label %bb7
bb7:
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load i32, ptr %l27, !tbaa !23
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t47, ptr %t48, i32 %t49)
  store ptr %t50, ptr %l34
  br label %bb8
bb8:
  %t51 = load ptr, ptr %l34, !tbaa !29
  store ptr %t51, ptr %l7, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  store ptr %t52, ptr %l35, !tbaa !29
  %t53 = load ptr, ptr %l35, !tbaa !29
  %t54 = getelementptr %"compiler/check:frame", ptr %t53, i32 0, i32 15
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = sub i64 %t55, 1
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = getelementptr %"compiler/check:frame", ptr %t59, i32 0, i32 15
  store i64 %t57, ptr %t60, !tbaa !24
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 16
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp ne i64 %t64, %t65
  store i1 %t68, ptr %l8, !tbaa !21
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = getelementptr %"compiler/check:frame", ptr %t70, i32 0, i32 16
  store i64 %t71, ptr %t74, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  store ptr %t80, ptr %l46, !tbaa !29
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t84 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t81)
  store i32 %t84, ptr %l49
  br label %bb9
bb9:
  %t85 = load ptr, ptr %l46, !tbaa !29
  %t86 = load i32, ptr %l49, !tbaa !23
  %t87 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t87, ptr %l50
  br label %bb10
bb10:
  %t88 = load i1, ptr %l50, !tbaa !21
  store i1 %t88, ptr %l9, !tbaa !21
  %t89 = load i1, ptr %l8, !tbaa !21
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb11, label %bb12
bb11:
  %t93 = load ptr, ptr %l7, !tbaa !29
  %t96 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t93)
  store i32 %t96, ptr %l56
  br label %bb13
bb12:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb14
bb13:
  %t97 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t98 = load i32, ptr %l56, !tbaa !23
  %t100 = icmp ne i32 %t98, %t97
  store i1 %t100, ptr %l53, !tbaa !21
  br label %bb14
bb14:
  %t102 = load i1, ptr %l53, !tbaa !21
  br i1 %t102, label %bb15, label %bb16
bb15:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %t103)
  store i1 %t105, ptr %l61
  br label %bb17
bb16:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb18
bb17:
  %t106 = load i1, ptr %l61, !tbaa !21
  %t107 = xor i1 %t106, true
  store i1 %t107, ptr %l59, !tbaa !21
  br label %bb18
bb18:
  %t109 = load i1, ptr %l59, !tbaa !21
  br i1 %t109, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s1
  %t110 = load i1, ptr %l9, !tbaa !21
  br i1 %t110, label %bb21, label %bb22
bb20:
  br label %bb29
bb21:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l1
  %t114 = load ptr, ptr %l7, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %t112, %"compiler/source:Span" %t113, ptr %t114)
  store ptr %t118, ptr %l67
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s1)
  %t119 = load ptr, ptr %l67, !tbaa !29
  store ptr %t119, ptr %rv
  br label %ret
bb24:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l68, !tbaa !29
  %t121 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t122 = load i32, ptr %t121, !tbaa !23
  %t124 = sub i32 %t122, 1
  %t125 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t126 = load i32, ptr %t125, !tbaa !23
  %t129 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t124, i32 %t126)
  store %"compiler/source:Span" %t129, ptr %l72
  br label %bb25
bb25:
  %t130 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBangNothingFails(ptr %s1)
  store %"compiler/msgs:Msg" %t130, ptr %l73
  br label %bb26
bb26:
  %t131 = load ptr, ptr %l68, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l72
  %t133 = load %"compiler/msgs:Msg", ptr %l73
  %t134 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t131, %"compiler/source:Span" %t132, %"compiler/msgs:Msg" %t133)
  store i64 %t134, ptr %l74
  br label %bb27
bb27:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t135, %"compiler/source:Span" %t136)
  store ptr %t139, ptr %l77
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s1)
  %t140 = load ptr, ptr %l77, !tbaa !29
  store ptr %t140, ptr %rv
  br label %ret
bb29:
  %t141 = load ptr, ptr %l4, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t141, i32 0, i32 25
  %t144 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %t143, i64 %t144)
  br label %bb30
bb30:
  %t147 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t147, ptr %l81
  %t148 = load ptr, ptr %l7, !tbaa !29
  %t151 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t148)
  store i32 %t151, ptr %l84
  br label %bb31
bb31:
  %t152 = load ptr, ptr %l7, !tbaa !29
  store ptr %t152, ptr %l86, !tbaa !29
  %t154 = icmp sge i64 0, 0
  br i1 %t154, label %bb32, label %bb33
bb32:
  %t156 = icmp sle i64 0, 1152921504606846975
  br i1 %t156, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_77940e7aab679ede_bd13144cbc386012)
  unreachable
bb34:
  %t158 = mul i64 0, 8
  %t159 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t158)
  %t160 = insertvalue { i64, ptr } undef, i64 0, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  %t162 = load ptr, ptr %l86, !tbaa !29
  %t164 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t162, { i64, ptr } %t161, i1 true, i1 false)
  store %"compiler/typed:Try" %t164, ptr %l90
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_77940e7aab679ede_bd13144cbc386012)
  unreachable
bb36:
  %t165 = load %"compiler/typed:Try", ptr %l90
  %t166 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t165, ptr %t166
  store { i64, [5 x i64] } zeroinitializer, ptr %t167
  %t168 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 0
  store i64 14, ptr %t168
  %t169 = load %"compiler/source:Span", ptr %l81
  %t170 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t169, 0
  %t171 = load i32, ptr %l84, !tbaa !23
  %t172 = insertvalue { %"compiler/source:Span", i32, ptr } %t170, i32 %t171, 1
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } %t172, ptr %t166, 2
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t174, ptr %t175
  %t176 = load { i64, [5 x i64] }, ptr %t167
  %t177 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t177, ptr %lp10
  %t179 = load ptr, ptr %lp10
  store { i64, [5 x i64] } %t176, ptr %t179
  %t180 = load i1, ptr %l9, !tbaa !21
  br i1 %t180, label %bb37, label %bb38
bb37:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load %"compiler/source:Span", ptr %l1
  %t184 = load ptr, ptr %lp10
  %t188 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %t182, %"compiler/source:Span" %t183, ptr %t184)
  store ptr %t188, ptr %l98
  br label %bb39
bb38:
  %t189 = load ptr, ptr %lp10
  store ptr %t189, ptr %l94, !tbaa !29
  br label %bb40
bb39:
  %t191 = load ptr, ptr %l98, !tbaa !29
  store ptr %t191, ptr %l94, !tbaa !29
  br label %bb40
bb40:
  %t192 = load ptr, ptr %l94, !tbaa !29
  store ptr %t192, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindsType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %t17)
  store { i64, ptr } %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t22, ptr %l12
  br label %bb7
bb7:
  %t23 = load i1, ptr %l12, !tbaa !21
  %t24 = xor i1 %t23, true
  call void @__olang_scope_close(ptr %s1)
  store i1 %t24, ptr %rv
  br label %ret
bb8:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i1, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i1
  %l29 = alloca i64
  %l31 = alloca ptr
  %l35 = alloca %"compiler/check:errBind"
  %l39 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca i64
  %l50 = alloca i64
  %l69 = alloca { i64, ptr }
  %l73 = alloca i1
  %l77 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca i64
  %l81 = alloca ptr
  %l83 = alloca %"compiler/source:Span"
  %l86 = alloca { i64, ptr }
  %l88 = alloca %"compiler/msgs:Msg"
  %l89 = alloca i64
  %l90 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca i1
  %l110 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca ptr
  %l112 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l125 = alloca { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
  %l130 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca i64
  %l138 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l140 = alloca i64
  %l142 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l147 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l157 = alloca %"compiler/msgs:Msg"
  %l158 = alloca i64
  %l163 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l164 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l167 = alloca %"compiler/msgs:Msg"
  %l168 = alloca i64
  %l174 = alloca ptr
  %l176 = alloca ptr
  %l180 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l182 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l186 = alloca i1
  %l190 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l192 = alloca i64
  %l195 = alloca i1
  %l198 = alloca i1
  %l202 = alloca ptr
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca ptr
  %l211 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l213 = alloca { i64, ptr }
  %l215 = alloca %"compiler/msgs:Msg"
  %l216 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i1, i1 }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l29
  br label %bb1
bb1:
  %t9 = load i64, ptr %l29, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l31
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l31, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 53
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/check:errBind" %t19, ptr %l35
  br label %bb3
bb3:
  %t20 = getelementptr %"compiler/check:errBind", ptr %l35, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l4, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNow(ptr %v0, ptr %s0, ptr %t23, i64 %t24)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l39
  br label %bb4
bb4:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l5
  %t29 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l40
  br label %bb5
bb5:
  %t30 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l6
  store i1 true, ptr %l7, !tbaa !21
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Match", ptr %t31, i32 0, i32 3
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t38 = load i64, ptr %l10, !tbaa !24
  %t39 = load i64, ptr %l9, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb6, label %bb7
bb6:
  %t44 = load i64, ptr %l11, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb11
bb8:
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l11, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l11, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l50, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb10
bb10:
  %t64 = load i64, ptr %l50, !tbaa !24
  store i64 %t64, ptr %l47, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l47, !tbaa !24
  store i64 %t65, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t66 = load i64, ptr %l13, !tbaa !24
  %t67 = load i64, ptr %l12, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb80
bb14:
  br label %bb15
bb15:
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l13, !tbaa !24
  %t76 = load i64, ptr %l11, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Match", ptr %t84, i32 0, i32 3
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l69, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr ptr, ptr %t91, i64 %t82
  %t93 = load ptr, ptr %t92, !tbaa !39
  store ptr %t93, ptr %l15, !tbaa !29
  %t95 = load i1, ptr %l8, !tbaa !21
  br i1 %t95, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb20
bb17:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t101 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s2, ptr %t97, ptr %l5, ptr %l6)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t101, ptr %l77
  br label %bb18
bb18:
  %t102 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l77
  %t103 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %t103
  %t105 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s2, ptr %t103)
  store i64 %t105, ptr %l79
  br label %bb19
bb19:
  %t106 = load i64, ptr %l79, !tbaa !24
  %t107 = icmp eq i64 %t106, 0
  store i1 %t107, ptr %l73, !tbaa !21
  br label %bb20
bb20:
  %t109 = load i1, ptr %l73, !tbaa !21
  br i1 %t109, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l81, !tbaa !29
  %t111 = load ptr, ptr %l15, !tbaa !29
  %t113 = getelementptr %"compiler/ast:Case", ptr %t111, i32 0, i32 0
  %t114 = load %"compiler/source:Span", ptr %t113
  store %"compiler/source:Span" %t114, ptr %l83
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l4, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t115, i32 %t116)
  store { i64, ptr } %t119, ptr %l86
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t120 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseNever(ptr %s3, ptr %s3, { i64, ptr } %t126)
  store %"compiler/msgs:Msg" %t128, ptr %l88
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l81, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l83
  %t131 = load %"compiler/msgs:Msg", ptr %l88
  %t132 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t129, %"compiler/source:Span" %t130, %"compiler/msgs:Msg" %t131)
  store i64 %t132, ptr %l89
  br label %bb25
bb25:
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb79
bb26:
  %t133 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %s2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %l90
  br label %bb27
bb27:
  %t134 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %l16
  %t135 = load ptr, ptr %l15, !tbaa !29
  %t137 = getelementptr %"compiler/ast:Case", ptr %t135, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l19, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t144 = load i64, ptr %l18, !tbaa !24
  %t145 = load i64, ptr %l19, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb73
bb30:
  br label %bb31
bb31:
  %t152 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t152, ptr %l99, !tbaa !27
  %t153 = load i64, ptr %l18, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr ptr, ptr %t156, i64 %t153
  %t158 = load ptr, ptr %t157, !tbaa !39
  store ptr %t158, ptr %l20, !tbaa !29
  %t160 = load ptr, ptr %l20, !tbaa !29
  store ptr %t160, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t161 = load ptr, ptr %l102, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb32, label %bb33
bb32:
  %t164 = load ptr, ptr %l102, !tbaa !29
  %t165 = load i64, ptr %t164
  %t167 = icmp eq i64 %t165, 0
  store i1 %t167, ptr %l103, !tbaa !21
  br label %bb33
bb33:
  %t168 = load i1, ptr %l103, !tbaa !21
  br i1 %t168, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb38
bb36:
  store i1 true, ptr %l8, !tbaa !21
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t172 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, ptr %t172
  %t176 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s2, ptr %s0, ptr %s2, ptr %t169, ptr %t172, ptr %l5)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t176, ptr %l110
  br label %bb37
bb37:
  %t177 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t177, ptr %l16
  br label %bb71
bb38:
  %t178 = load ptr, ptr %l20, !tbaa !29
  store ptr %t178, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t179 = load ptr, ptr %l111, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb39, label %bb40
bb39:
  %t182 = load ptr, ptr %l111, !tbaa !29
  %t183 = load i64, ptr %t182
  %t185 = icmp eq i64 %t183, 1
  store i1 %t185, ptr %l112, !tbaa !21
  br label %bb40
bb40:
  %t186 = load i1, ptr %l112, !tbaa !21
  br i1 %t186, label %bb41, label %bb42
bb41:
  %t187 = load ptr, ptr %l20, !tbaa !29
  %t189 = getelementptr { i64, [4 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", ptr }, ptr %t189, i32 0, i32 1
  %t191 = load ptr, ptr %t190
  store ptr %t191, ptr %l21, !tbaa !29
  br label %bb47
bb42:
  %t193 = load ptr, ptr %l20, !tbaa !29
  store ptr %t193, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t194 = load ptr, ptr %l117, !tbaa !29
  %t195 = icmp ne ptr %t194, null
  br i1 %t195, label %bb43, label %bb44
bb43:
  %t197 = load ptr, ptr %l117, !tbaa !29
  %t198 = load i64, ptr %t197
  %t200 = icmp eq i64 %t198, 4
  store i1 %t200, ptr %l118, !tbaa !21
  br label %bb44
bb44:
  %t201 = load i1, ptr %l118, !tbaa !21
  br i1 %t201, label %bb45, label %bb46
bb45:
  %t202 = load ptr, ptr %l20, !tbaa !29
  %t204 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 1
  %t205 = getelementptr { %"compiler/source:Span", ptr }, ptr %t204, i32 0, i32 1
  %t206 = load ptr, ptr %t205
  store ptr %t206, ptr %l21, !tbaa !29
  br label %bb47
bb46:
  br label %bb67
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l21, !tbaa !29
  %t212 = call { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %s7, ptr %t208, ptr %t209)
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t212, ptr %l125
  br label %bb48
bb48:
  %t213 = load { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }, ptr %l125
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t213, ptr %l22
  %t214 = getelementptr { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }, ptr %l22, i32 0, i32 0
  %t215 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t214
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t215, ptr %l23
  %t217 = getelementptr { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }, ptr %l22, i32 0, i32 1
  %t218 = load i1, ptr %t217, !tbaa !21
  %t222 = xor i1 %t218, true
  br i1 %t222, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l130, !tbaa !29
  %t225 = load ptr, ptr %l20, !tbaa !29
  %t227 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t225)
  store %"compiler/source:Span" %t227, ptr %l132
  br label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t232 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %s0, ptr %s7, ptr %s9, ptr %t228, ptr %l5, ptr %l23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t232, ptr %l138
  br label %bb54
bb51:
  %t233 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %s8)
  store %"compiler/msgs:Msg" %t233, ptr %l133
  br label %bb52
bb52:
  %t234 = load ptr, ptr %l130, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l132
  %t236 = load %"compiler/msgs:Msg", ptr %l133
  %t237 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t234, %"compiler/source:Span" %t235, %"compiler/msgs:Msg" %t236)
  store i64 %t237, ptr %l134
  br label %bb53
bb53:
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb66
bb54:
  %t238 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l138
  %t239 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %t239
  %t241 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s9, ptr %t239)
  store i64 %t241, ptr %l140
  br label %bb55
bb55:
  %t242 = load i64, ptr %l140, !tbaa !24
  %t243 = icmp eq i64 %t242, 0
  br i1 %t243, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l142, !tbaa !29
  %t246 = load ptr, ptr %l20, !tbaa !29
  %t248 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t246)
  store %"compiler/source:Span" %t248, ptr %l144
  br label %bb58
bb57:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t252 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t250, ptr %t252
  %t256 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s2, ptr %s7, ptr %s2, ptr %t249, ptr %t252, ptr %l23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t256, ptr %l163
  br label %bb64
bb58:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l4, !tbaa !23
  %t261 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s10, ptr %t257, i32 %t258)
  store { i64, ptr } %t261, ptr %l147
  br label %bb59
bb59:
  %t262 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  %t264 = extractvalue { i64, ptr } %t262, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l148, !tbaa !27
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t272 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s7, ptr %s10, ptr %t269, ptr %l23)
  store { i64, ptr } %t272, ptr %l151
  br label %bb60
bb60:
  %t273 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 0
  %t275 = extractvalue { i64, ptr } %t273, 1
  %t276 = mul i64 %t274, 1
  %t277 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t276)
  call void @llvm.memcpy.p0.p0.i64(ptr %t277, ptr %t275, i64 %t276, i1 false)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  store { i64, ptr } %t279, ptr %l152, !tbaa !27
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t283 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s0, ptr %s10, ptr %t280, ptr %l5)
  store { i64, ptr } %t283, ptr %l155
  br label %bb61
bb61:
  %t284 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  %t286 = extractvalue { i64, ptr } %t284, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  %t291 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t292 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t294 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %s10, ptr %s10, ptr %s10, ptr %s10, { i64, ptr } %t291, { i64, ptr } %t292, { i64, ptr } %t290)
  store %"compiler/msgs:Msg" %t294, ptr %l157
  br label %bb62
bb62:
  %t295 = load ptr, ptr %l142, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l144
  %t297 = load %"compiler/msgs:Msg", ptr %l157
  %t298 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t295, %"compiler/source:Span" %t296, %"compiler/msgs:Msg" %t297)
  store i64 %t298, ptr %l158
  br label %bb63
bb63:
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  br label %bb65
bb64:
  %t299 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l163
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t299, ptr %l16
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb67:
  store %olang.scope zeroinitializer, ptr %s12
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l164, !tbaa !29
  %t301 = load ptr, ptr %l20, !tbaa !29
  %t303 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t301)
  store %"compiler/source:Span" %t303, ptr %l166
  br label %bb68
bb68:
  %t304 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %s12)
  store %"compiler/msgs:Msg" %t304, ptr %l167
  br label %bb69
bb69:
  %t305 = load ptr, ptr %l164, !tbaa !29
  %t306 = load %"compiler/source:Span", ptr %l166
  %t307 = load %"compiler/msgs:Msg", ptr %l167
  %t308 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t305, %"compiler/source:Span" %t306, %"compiler/msgs:Msg" %t307)
  store i64 %t308, ptr %l168
  br label %bb70
bb70:
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s12)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s5)
  br label %bb72
bb72:
  %t309 = load i64, ptr %l18, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l18, !tbaa !24
  br label %bb28
bb73:
  %t313 = load ptr, ptr %l15, !tbaa !29
  %t315 = getelementptr %"compiler/ast:Case", ptr %t313, i32 0, i32 3
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t318 = icmp eq ptr %t316, null
  br i1 %t318, label %bb74, label %bb75
bb74:
  %t320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t320, ptr %l174, !tbaa !29
  %t321 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t323 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t321, ptr %t323
  store ptr %t323, ptr %l176, !tbaa !29
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t328 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %s2, ptr %s0, ptr %s0, ptr %t324, ptr %l16, ptr %l5)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t328, ptr %l180
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t329 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l180
  %t330 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t329, ptr %t330
  %t331 = load ptr, ptr %l174, !tbaa !29
  %t332 = load ptr, ptr %l176, !tbaa !29
  %t334 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t331, ptr %t332, ptr %t330)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t334, ptr %l182
  br label %bb77
bb77:
  %t335 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l182
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t335, ptr %l6
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s2)
  br label %bb79
bb79:
  %t336 = load i64, ptr %l13, !tbaa !24
  %t338 = add i64 %t336, 1
  store i64 %t338, ptr %l13, !tbaa !24
  br label %bb12
bb80:
  %t340 = load i1, ptr %l8, !tbaa !21
  br i1 %t340, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb85
bb82:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t346 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t342, ptr %l5, ptr %l6)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t346, ptr %l190
  br label %bb83
bb83:
  %t347 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l190
  %t348 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t347, ptr %t348
  %t350 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t348)
  store i64 %t350, ptr %l192
  br label %bb84
bb84:
  %t351 = load i64, ptr %l192, !tbaa !24
  %t352 = icmp eq i64 %t351, 0
  store i1 %t352, ptr %l186, !tbaa !21
  br label %bb85
bb85:
  %t354 = load i1, ptr %l186, !tbaa !21
  store i1 %t354, ptr %l25, !tbaa !21
  %t355 = load i1, ptr %l7, !tbaa !21
  br i1 %t355, label %bb86, label %bb87
bb86:
  %t357 = load i1, ptr %l25, !tbaa !21
  %t359 = xor i1 %t357, true
  store i1 %t359, ptr %l195, !tbaa !21
  br label %bb88
bb87:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb88
bb88:
  %t361 = load i1, ptr %l195, !tbaa !21
  br i1 %t361, label %bb89, label %bb90
bb89:
  %t362 = load ptr, ptr %l2, !tbaa !29
  %t364 = getelementptr %"compiler/ast:Match", ptr %t362, i32 0, i32 4
  %t365 = load ptr, ptr %t364, !tbaa !29
  %t367 = icmp eq ptr %t365, null
  store i1 %t367, ptr %l198, !tbaa !21
  br label %bb91
bb90:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb91
bb91:
  %t369 = load i1, ptr %l198, !tbaa !21
  br i1 %t369, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s16
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l202, !tbaa !29
  %t371 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t372 = load i32, ptr %t371, !tbaa !23
  %t373 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t374 = load i32, ptr %t373, !tbaa !23
  %t376 = add i32 %t374, 5
  %t379 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s16, i32 %t372, i32 %t376)
  store %"compiler/source:Span" %t379, ptr %l206
  br label %bb94
bb93:
  br label %bb99
bb94:
  %t380 = load ptr, ptr %l0, !tbaa !29
  store ptr %t380, ptr %l207, !tbaa !29
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t385 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s16, ptr %t381, ptr %l5, ptr %l6)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t385, ptr %l211
  br label %bb95
bb95:
  %t386 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l211
  %t387 = call ptr @__olang_scope_alloc_a(ptr %s16, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t386, ptr %t387
  %t388 = load ptr, ptr %l207, !tbaa !29
  %t390 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s16, ptr %s16, ptr %t388, ptr %t387)
  store { i64, ptr } %t390, ptr %l213
  br label %bb96
bb96:
  %t391 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t391, 0
  %t393 = extractvalue { i64, ptr } %t391, 1
  %t394 = mul i64 %t392, 1
  %t395 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t394)
  call void @llvm.memcpy.p0.p0.i64(ptr %t395, ptr %t393, i64 %t394, i1 false)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  %t399 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtMatchMissing(ptr %s16, ptr %s16, { i64, ptr } %t397)
  store %"compiler/msgs:Msg" %t399, ptr %l215
  br label %bb97
bb97:
  %t400 = load ptr, ptr %l202, !tbaa !29
  %t401 = load %"compiler/source:Span", ptr %l206
  %t402 = load %"compiler/msgs:Msg", ptr %l215
  %t403 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t400, %"compiler/source:Span" %t401, %"compiler/msgs:Msg" %t402)
  store i64 %t403, ptr %l216
  br label %bb98
bb98:
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s16)
  br label %bb99
bb99:
  %t404 = load i1, ptr %l7, !tbaa !21
  %t405 = load i1, ptr %l25, !tbaa !21
  %t407 = insertvalue { i1, i1 } undef, i1 %t404, 0
  %t409 = insertvalue { i1, i1 } %t407, i1 %t405, 1
  call void @__olang_scope_close(ptr %s0)
  store { i1, i1 } %t409, ptr %rv
  br label %ret
ret:
  %rr = load { i1, i1 }, ptr %rv
  ret { i1, i1 } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, ptr }
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca %"compiler/check:litv"
  %l59 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca %"compiler/check:litv"
  %l89 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca i32
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l13, !tbaa !27
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l6, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Chain", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = add i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Chain", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l22, !tbaa !27
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l8
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb1, label %bb2
bb1:
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb3
bb3:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb4, label %bb5
bb4:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  %t47 = load i32, ptr %l8
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v1, ptr %t45, %"compiler/source:Span" %t46, i32 %t47, ptr %t48, ptr %t49, i32 %t50)
  store ptr %t57, ptr %l36
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load ptr, ptr %l36, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb7:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l37, !tbaa !29
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t60)
  store %"compiler/source:Span" %t62, ptr %l39
  br label %bb8
bb8:
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l41
  br label %bb9
bb9:
  %t66 = load i32, ptr %l8
  %t68 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t66)
  store { i64, ptr } %t68, ptr %l43
  br label %bb10
bb10:
  %t69 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l39
  %t73 = load %"compiler/source:Span", ptr %l41
  %t75 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t71, %"compiler/source:Span" %t72, %"compiler/source:Span" %t73, i64 %t70)
  store %"compiler/source:Span" %t75, ptr %l45
  br label %bb11
bb11:
  %t76 = load %"compiler/source:Span", ptr %l45
  store %"compiler/source:Span" %t76, ptr %l9
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb12, label %bb13
bb12:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l48, !tbaa !29
  %t82 = load ptr, ptr %l6, !tbaa !29
  store ptr %t82, ptr %l49, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t88 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  store %"compiler/check:litv" %t88, ptr %l53
  br label %bb14
bb13:
  br label %bb29
bb14:
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_854899d5724a103b_e7dfb19072d83fa7)
  unreachable
bb16:
  br label %bb17
bb17:
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t94 = load i32, ptr %l8
  %t95 = load %"compiler/source:Span", ptr %l9
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = load %"compiler/check:litv", ptr %l53
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %t96, ptr %t97, %"compiler/check:litv" %t98, ptr %t93, i32 %t94, %"compiler/source:Span" %t95, i1 false)
  store ptr %t102, ptr %l59
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l59, !tbaa !29
  store ptr %t103, ptr %l10, !tbaa !29
  %t104 = load ptr, ptr %l10, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb19, label %bb20
bb19:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t108, %"compiler/source:Span" %t109)
  store ptr %t112, ptr %l64
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load ptr, ptr %l64, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb22:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l65, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t115, ptr %l66
  %t116 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t116, ptr %l67
  %t117 = load i32, ptr %l8
  store i32 %t117, ptr %l68
  %t118 = load ptr, ptr %l10, !tbaa !29
  store ptr %t118, ptr %l69, !tbaa !29
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  br i1 %t121, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_852b58c2eb82b3cc_e47a0c64d3951188)
  unreachable
bb24:
  br label %bb25
bb25:
  %t123 = load ptr, ptr %l5, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t124)
  store %"compiler/source:Span" %t126, ptr %l74
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t129 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t127)
  store %"compiler/source:Span" %t129, ptr %l76
  br label %bb27
bb27:
  %t130 = load ptr, ptr %l65, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l66
  %t132 = load %"compiler/source:Span", ptr %l67
  %t133 = load i32, ptr %l68
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = load ptr, ptr %l72, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l74
  %t137 = load %"compiler/source:Span", ptr %l76
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t130, %"compiler/source:Span" %t131, %"compiler/source:Span" %t132, i32 %t133, ptr %t134, ptr %t135, %"compiler/source:Span" %t136, %"compiler/source:Span" %t137)
  store ptr %t138, ptr %l77
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t139 = load ptr, ptr %l77, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb29:
  %t140 = load ptr, ptr %l5, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb30, label %bb31
bb30:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l80, !tbaa !29
  %t145 = load ptr, ptr %l7, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l7, !tbaa !29
  %t151 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t146, ptr %t147)
  store %"compiler/check:litv" %t151, ptr %l85
  br label %bb32
bb31:
  br label %bb41
bb32:
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t153 = load i32, ptr %l8
  %t154 = load %"compiler/source:Span", ptr %l9
  %t155 = load ptr, ptr %l80, !tbaa !29
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load %"compiler/check:litv", ptr %l85
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %t155, ptr %t156, %"compiler/check:litv" %t157, ptr %t152, i32 %t153, %"compiler/source:Span" %t154, i1 true)
  store ptr %t161, ptr %l89
  br label %bb33
bb33:
  %t162 = load ptr, ptr %l89, !tbaa !29
  store ptr %t162, ptr %l11, !tbaa !29
  %t163 = load ptr, ptr %l11, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  br i1 %t165, label %bb34, label %bb35
bb34:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t167, %"compiler/source:Span" %t168)
  store ptr %t171, ptr %l94
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t172 = load ptr, ptr %l94, !tbaa !29
  store ptr %t172, ptr %rv
  br label %ret
bb37:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l95, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t174, ptr %l96
  %t175 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t175, ptr %l97
  %t176 = load i32, ptr %l8
  store i32 %t176, ptr %l98
  %t177 = load ptr, ptr %l4, !tbaa !29
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load ptr, ptr %l11, !tbaa !29
  store ptr %t178, ptr %l100, !tbaa !29
  %t179 = load ptr, ptr %l6, !tbaa !29
  %t181 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t179)
  store %"compiler/source:Span" %t181, ptr %l102
  br label %bb38
bb38:
  %t182 = load ptr, ptr %l7, !tbaa !29
  %t184 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t182)
  store %"compiler/source:Span" %t184, ptr %l104
  br label %bb39
bb39:
  %t185 = load ptr, ptr %l95, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l96
  %t187 = load %"compiler/source:Span", ptr %l97
  %t188 = load i32, ptr %l98
  %t189 = load ptr, ptr %l99, !tbaa !29
  %t190 = load ptr, ptr %l100, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l102
  %t192 = load %"compiler/source:Span", ptr %l104
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t185, %"compiler/source:Span" %t186, %"compiler/source:Span" %t187, i32 %t188, ptr %t189, ptr %t190, %"compiler/source:Span" %t191, %"compiler/source:Span" %t192)
  store ptr %t193, ptr %l105
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t194 = load ptr, ptr %l105, !tbaa !29
  store ptr %t194, ptr %rv
  br label %ret
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l106, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t196, ptr %l107
  %t197 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t197, ptr %l108
  %t198 = load i32, ptr %l8
  store i32 %t198, ptr %l109
  %t199 = load ptr, ptr %l4, !tbaa !29
  store ptr %t199, ptr %l110, !tbaa !29
  %t200 = load ptr, ptr %l5, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t203 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t201)
  store %"compiler/source:Span" %t203, ptr %l113
  br label %bb42
bb42:
  %t204 = load ptr, ptr %l7, !tbaa !29
  %t206 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t204)
  store %"compiler/source:Span" %t206, ptr %l115
  br label %bb43
bb43:
  %t207 = load ptr, ptr %l106, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l107
  %t209 = load %"compiler/source:Span", ptr %l108
  %t210 = load i32, ptr %l109
  %t211 = load ptr, ptr %l110, !tbaa !29
  %t212 = load ptr, ptr %l111, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l113
  %t214 = load %"compiler/source:Span", ptr %l115
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t207, %"compiler/source:Span" %t208, %"compiler/source:Span" %t209, i32 %t210, ptr %t211, ptr %t212, %"compiler/source:Span" %t213, %"compiler/source:Span" %t214)
  store ptr %t215, ptr %l116
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t216 = load ptr, ptr %l116, !tbaa !29
  store ptr %t216, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/typed:Item"
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l59 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l67 = alloca i1
  %l72 = alloca ptr
  %l75 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/msgs:Msg"
  %l80 = alloca i64
  %l84 = alloca i1
  %l88 = alloca i1
  %l93 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca i64
  %l101 = alloca i64
  %l119 = alloca ptr
  %l122 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l138 = alloca i1
  %l141 = alloca i32
  %l147 = alloca i64
  %l149 = alloca i32
  %l153 = alloca i32
  %l159 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca %"compiler/msgs:Msg"
  %l164 = alloca i64
  %l173 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/msgs:Msg"
  %l178 = alloca i64
  %l184 = alloca ptr
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca %"compiler/msgs:Msg"
  %l189 = alloca i64
  %l195 = alloca i1
  %l201 = alloca i1
  %l203 = alloca i1
  %l205 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca %"compiler/msgs:Msg"
  %l210 = alloca i64
  %l214 = alloca i1
  %l221 = alloca i1
  %l224 = alloca i1
  %l225 = alloca ptr
  %l228 = alloca %"compiler/source:Span"
  %l229 = alloca %"compiler/msgs:Msg"
  %l230 = alloca i64
  %l233 = alloca i1
  %l238 = alloca i32
  %l243 = alloca ptr
  %l248 = alloca i32
  %l249 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l259 = alloca %"compiler/source:Span"
  %l264 = alloca %"compiler/msgs:Msg"
  %l265 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l5, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb9
bb6:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l41, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l41, !tbaa !24
  store i64 %t38, ptr %l38, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l38, !tbaa !24
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb138
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l59, !tbaa !27
  %t59 = load i64, ptr %l10, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr ptr, ptr %t62, i64 %t59
  %t64 = load ptr, ptr %t63, !tbaa !39
  store ptr %t64, ptr %l11, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t67 = load i64, ptr %l10, !tbaa !24
  %t70 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v2, ptr %v2, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l64
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l64, !tbaa !29
  store ptr %t71, ptr %l12, !tbaa !29
  %t72 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i64, ptr %l10, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t83 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v2, ptr %s3, ptr %t76, i64 %t80)
  store ptr %t83, ptr %l72
  br label %bb17
bb16:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb18
bb17:
  %t84 = load ptr, ptr %l72, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Clause", ptr %t84, i32 0, i32 2
  %t87 = load i1, ptr %t86, !tbaa !21
  store i1 %t87, ptr %l67, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l67, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l75, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l11, !tbaa !29
  %t95 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store %"compiler/source:Span" %t95, ptr %l78
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t96 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %s4)
  store %"compiler/msgs:Msg" %t96, ptr %l79
  br label %bb22
bb22:
  %t97 = load ptr, ptr %l75, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l78
  %t99 = load %"compiler/msgs:Msg", ptr %l79
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t97, %"compiler/source:Span" %t98, %"compiler/msgs:Msg" %t99)
  store i64 %t100, ptr %l80
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb24:
  %t102 = load i64, ptr %l10, !tbaa !24
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = load ptr, ptr %l12, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Clause", ptr %t106, i32 0, i32 2
  %t109 = load i1, ptr %t108, !tbaa !21
  %t111 = xor i1 %t109, true
  store i1 %t111, ptr %l84, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb27
bb27:
  %t113 = load i1, ptr %l84, !tbaa !21
  br i1 %t113, label %bb28, label %bb29
bb28:
  %t114 = load ptr, ptr %l12, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Clause", ptr %t114, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = icmp sgt i64 %t119, 0
  store i1 %t121, ptr %l88, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l88, !tbaa !21
  br i1 %t123, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t124 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e(ptr %s5)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %l93
  br label %bb33
bb32:
  br label %bb71
bb33:
  %t125 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l93
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l10, !tbaa !24
  store i64 %t126, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb34, label %bb35
bb34:
  %t134 = load i64, ptr %l16, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb39
bb36:
  %t138 = load i64, ptr %l15, !tbaa !24
  %t139 = load i64, ptr %l14, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l16, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l16, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l101, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb38
bb38:
  %t154 = load i64, ptr %l101, !tbaa !24
  store i64 %t154, ptr %l98, !tbaa !24
  br label %bb39
bb39:
  %t155 = load i64, ptr %l98, !tbaa !24
  store i64 %t155, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t156 = load i64, ptr %l18, !tbaa !24
  %t157 = load i64, ptr %l17, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t164 = load i64, ptr %l14, !tbaa !24
  %t165 = load i64, ptr %l18, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store ptr %l13, ptr %l119, !tbaa !29
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t178 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v2, ptr %v2, ptr %t174, i64 %t172)
  store ptr %t178, ptr %l122
  br label %bb44
bb44:
  %t179 = load ptr, ptr %l119, !tbaa !29
  %t180 = load ptr, ptr %l122, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eP_Hee51906bde9346e7b7b6808fdce5ba81(ptr %s5, ptr %v2, ptr %t179, ptr %t180)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  %t181 = load i64, ptr %l18, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l18, !tbaa !24
  br label %bb40
bb47:
  store i1 true, ptr %l20, !tbaa !21
  %t185 = load ptr, ptr %l12, !tbaa !29
  %t187 = getelementptr %"compiler/typed:Clause", ptr %t185, i32 0, i32 1
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l23, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  %t194 = load i64, ptr %l22, !tbaa !24
  %t195 = load i64, ptr %l23, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb50:
  br label %bb51
bb51:
  %t202 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t202, ptr %l133, !tbaa !27
  %t203 = load i64, ptr %l22, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr %"compiler/typed:Item", ptr %t206, i64 %t203
  %t208 = load %"compiler/typed:Item", ptr %t207
  store %"compiler/typed:Item" %t208, ptr %l24
  %t210 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t211 = load i64, ptr %t210, !tbaa !24
  %t213 = icmp slt i64 %t211, 0
  br i1 %t213, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb54
bb53:
  %t215 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t216 = load i64, ptr %t215, !tbaa !24
  %t218 = icmp sge i64 %t216, 64
  store i1 %t218, ptr %l138, !tbaa !21
  br label %bb54
bb54:
  %t220 = load i1, ptr %l138, !tbaa !21
  br i1 %t220, label %bb55, label %bb56
bb55:
  %t221 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 0
  %t222 = load i32, ptr %t221, !tbaa !23
  store i32 %t222, ptr %l141, !tbaa !23
  br label %bb58
bb56:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 2
  %t230 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 0
  %t231 = load i32, ptr %t230, !tbaa !23
  %t232 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t233 = load i64, ptr %t232, !tbaa !24
  store i64 %t233, ptr %l147, !tbaa !24
  %t234 = load i64, ptr %l147, !tbaa !24
  %t235 = load i64, ptr %l147, !tbaa !24
  %t236 = shl i64 1, %t235
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t229, i32 %t231, i64 %t236)
  store i32 %t240, ptr %l149
  br label %bb57
bb57:
  %t241 = load i32, ptr %l149, !tbaa !23
  store i32 %t241, ptr %l141, !tbaa !23
  br label %bb58
bb58:
  %t242 = load i32, ptr %l141, !tbaa !23
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t248 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %s5, ptr %t243, i32 %t242, ptr %l13)
  store i32 %t248, ptr %l153
  br label %bb59
bb59:
  %t249 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t250 = load i32, ptr %l153, !tbaa !23
  %t252 = icmp ne i32 %t250, %t249
  br i1 %t252, label %bb60, label %bb61
bb60:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  %t254 = load i64, ptr %l22, !tbaa !24
  %t256 = add i64 %t254, 1
  store i64 %t256, ptr %l22, !tbaa !24
  br label %bb48
bb64:
  %t258 = load i1, ptr %l20, !tbaa !21
  br i1 %t258, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s13
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l159, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t265 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t261, ptr %t262)
  store %"compiler/source:Span" %t265, ptr %l162
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t266 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %s13)
  store %"compiler/msgs:Msg" %t266, ptr %l163
  br label %bb68
bb68:
  %t267 = load ptr, ptr %l159, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l162
  %t269 = load %"compiler/msgs:Msg", ptr %l163
  %t270 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t267, %"compiler/source:Span" %t268, %"compiler/msgs:Msg" %t269)
  store i64 %t270, ptr %l164
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb70:
  call void @__olang_scope_close(ptr %s5)
  br label %bb71
bb71:
  %t272 = load ptr, ptr %l11, !tbaa !29
  %t274 = getelementptr %"compiler/ast:Catch", ptr %t272, i32 0, i32 3
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t279 = icmp sgt i64 %t277, 0
  store i1 %t279, ptr %l26, !tbaa !21
  %t283 = xor i1 %a3, true
  br i1 %t283, label %bb72, label %bb73
bb72:
  %t285 = load i1, ptr %l26, !tbaa !21
  br i1 %t285, label %bb74, label %bb75
bb73:
  br label %bb80
bb74:
  store %olang.scope zeroinitializer, ptr %s15
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l173, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l11, !tbaa !29
  %t292 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t288, ptr %t289)
  store %"compiler/source:Span" %t292, ptr %l176
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t293 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %s15)
  store %"compiler/msgs:Msg" %t293, ptr %l177
  br label %bb77
bb77:
  %t294 = load ptr, ptr %l173, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l176
  %t296 = load %"compiler/msgs:Msg", ptr %l177
  %t297 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t294, %"compiler/source:Span" %t295, %"compiler/msgs:Msg" %t296)
  store i64 %t297, ptr %l178
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb79:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb80:
  %t299 = load i32, ptr %l4, !tbaa !23
  %t300 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t303 = icmp eq i32 %t299, %t300
  br i1 %t303, label %bb81, label %bb82
bb81:
  %t305 = load i1, ptr %l26, !tbaa !21
  br i1 %t305, label %bb83, label %bb84
bb82:
  br label %bb89
bb83:
  store %olang.scope zeroinitializer, ptr %s17
  %t307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t307, ptr %l184, !tbaa !29
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l11, !tbaa !29
  %t312 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t308, ptr %t309)
  store %"compiler/source:Span" %t312, ptr %l187
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t313 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %s17)
  store %"compiler/msgs:Msg" %t313, ptr %l188
  br label %bb86
bb86:
  %t314 = load ptr, ptr %l184, !tbaa !29
  %t315 = load %"compiler/source:Span", ptr %l187
  %t316 = load %"compiler/msgs:Msg", ptr %l188
  %t317 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t314, %"compiler/source:Span" %t315, %"compiler/msgs:Msg" %t316)
  store i64 %t317, ptr %l189
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb88:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb89:
  %t319 = load ptr, ptr %l12, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Clause", ptr %t319, i32 0, i32 3
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = icmp eq ptr %t322, null
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb90, label %bb91
bb90:
  %t328 = load ptr, ptr %l12, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Clause", ptr %t328, i32 0, i32 3
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = icmp eq ptr %t331, null
  br i1 %t333, label %bb92, label %bb93
bb91:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb96
bb92:
  call void @__olang_check_failed(ptr @olang_loc_20fb2e81a5b7d68a_7759df49ce89a9e)
  unreachable
bb93:
  br label %bb94
bb94:
  %t335 = load ptr, ptr %l12, !tbaa !29
  %t337 = getelementptr %"compiler/typed:Clause", ptr %t335, i32 0, i32 3
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t340 = call i1 @compiler_2fcheck_2eleavesValue(ptr %v2, ptr %t338)
  store i1 %t340, ptr %l201
  br label %bb95
bb95:
  %t341 = load i1, ptr %l201, !tbaa !21
  store i1 %t341, ptr %l195, !tbaa !21
  br label %bb96
bb96:
  %t342 = load i1, ptr %l195, !tbaa !21
  store i1 %t342, ptr %l27, !tbaa !21
  %t343 = load i1, ptr %l27, !tbaa !21
  br i1 %t343, label %bb97, label %bb98
bb97:
  %t345 = load i1, ptr %l26, !tbaa !21
  store i1 %t345, ptr %l203, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb99
bb99:
  %t347 = load i1, ptr %l203, !tbaa !21
  br i1 %t347, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s18
  %t348 = load ptr, ptr %l0, !tbaa !29
  store ptr %t348, ptr %l205, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load ptr, ptr %l11, !tbaa !29
  %t353 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t349, ptr %t350)
  store %"compiler/source:Span" %t353, ptr %l208
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t354 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %s18)
  store %"compiler/msgs:Msg" %t354, ptr %l209
  br label %bb103
bb103:
  %t355 = load ptr, ptr %l205, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l208
  %t357 = load %"compiler/msgs:Msg", ptr %l209
  %t358 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t355, %"compiler/source:Span" %t356, %"compiler/msgs:Msg" %t357)
  store i64 %t358, ptr %l210
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb105:
  %t360 = load i1, ptr %l27, !tbaa !21
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb106, label %bb107
bb106:
  %t364 = load i1, ptr %l26, !tbaa !21
  %t366 = xor i1 %t364, true
  store i1 %t366, ptr %l214, !tbaa !21
  br label %bb108
bb107:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb108
bb108:
  %t368 = load i1, ptr %l214, !tbaa !21
  br i1 %t368, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s19
  %t369 = load ptr, ptr %l11, !tbaa !29
  %t371 = getelementptr %"compiler/ast:Catch", ptr %t369, i32 0, i32 2
  %t372 = load { i64, ptr }, ptr %t371, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t376 = icmp sgt i64 %t374, 0
  br i1 %t376, label %bb111, label %bb112
bb110:
  br label %bb121
bb111:
  %t378 = load ptr, ptr %l11, !tbaa !29
  %t380 = getelementptr %"compiler/ast:Catch", ptr %t378, i32 0, i32 2
  %t381 = load { i64, ptr }, ptr %t380, !tbaa !27
  %t383 = call i1 @compiler_2fcheck_2elastIsValue(ptr %v1, { i64, ptr } %t381)
  store i1 %t383, ptr %l224
  br label %bb113
bb112:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb114
bb113:
  %t384 = load i1, ptr %l224, !tbaa !21
  store i1 %t384, ptr %l221, !tbaa !21
  br label %bb114
bb114:
  %t385 = load i1, ptr %l221, !tbaa !21
  br i1 %t385, label %bb115, label %bb116
bb115:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb116:
  br label %bb117
bb117:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l225, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l11, !tbaa !29
  %t391 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t387, ptr %t388)
  store %"compiler/source:Span" %t391, ptr %l228
  br label %bb118
bb118:
  %t392 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %s19)
  store %"compiler/msgs:Msg" %t392, ptr %l229
  br label %bb119
bb119:
  %t393 = load ptr, ptr %l225, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l228
  %t395 = load %"compiler/msgs:Msg", ptr %l229
  %t396 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t393, %"compiler/source:Span" %t394, %"compiler/msgs:Msg" %t395)
  store i64 %t396, ptr %l230
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb121:
  %t398 = load i1, ptr %l26, !tbaa !21
  br i1 %t398, label %bb122, label %bb123
bb122:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = getelementptr %"compiler/generic:Program", ptr %t403, i32 0, i32 2
  %t406 = load i32, ptr %l4, !tbaa !23
  %t409 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t405, i32 %t406)
  store i32 %t409, ptr %l238
  br label %bb124
bb123:
  store i1 false, ptr %l233, !tbaa !21
  br label %bb125
bb124:
  %t410 = load i32, ptr %l238
  %t412 = trunc i64 22 to i32
  %t413 = icmp eq i32 %t410, %t412
  store i1 %t413, ptr %l233, !tbaa !21
  br label %bb125
bb125:
  %t415 = load i1, ptr %l233, !tbaa !21
  br i1 %t415, label %bb126, label %bb127
bb126:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/check:Checker", ptr %t416, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !29
  %t421 = getelementptr %"compiler/generic:Program", ptr %t419, i32 0, i32 2
  store ptr %t421, ptr %l243, !tbaa !29
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/check:Checker", ptr %t422, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !29
  %t427 = getelementptr %"compiler/generic:Program", ptr %t425, i32 0, i32 2
  %t428 = load i32, ptr %l4, !tbaa !23
  %t431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l248
  br label %bb128
bb127:
  br label %bb136
bb128:
  %t432 = load ptr, ptr %l243, !tbaa !29
  %t433 = load i32, ptr %l248, !tbaa !23
  %t434 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t432, i32 %t433)
  store { i64, ptr } %t434, ptr %l249
  br label %bb129
bb129:
  %t435 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t435, 0
  store i64 %t436, ptr %l28, !tbaa !24
  %t438 = load ptr, ptr %l11, !tbaa !29
  %t440 = getelementptr %"compiler/ast:Catch", ptr %t438, i32 0, i32 3
  %t441 = load { i64, ptr }, ptr %t440, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t444 = load i64, ptr %l28, !tbaa !24
  %t447 = icmp ne i64 %t443, %t444
  br i1 %t447, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s22
  %t449 = load ptr, ptr %l0, !tbaa !29
  store ptr %t449, ptr %l256, !tbaa !29
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load ptr, ptr %l11, !tbaa !29
  %t454 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t450, ptr %t451)
  store %"compiler/source:Span" %t454, ptr %l259
  br label %bb132
bb131:
  br label %bb135
bb132:
  %t455 = load i64, ptr %l28, !tbaa !24
  %t456 = load ptr, ptr %l11, !tbaa !29
  %t458 = getelementptr %"compiler/ast:Catch", ptr %t456, i32 0, i32 3
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t464 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %s22, i64 %t455, i64 %t461)
  store %"compiler/msgs:Msg" %t464, ptr %l264
  br label %bb133
bb133:
  %t465 = load ptr, ptr %l256, !tbaa !29
  %t466 = load %"compiler/source:Span", ptr %l259
  %t467 = load %"compiler/msgs:Msg", ptr %l264
  %t468 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t465, %"compiler/source:Span" %t466, %"compiler/msgs:Msg" %t467)
  store i64 %t468, ptr %l265
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb135:
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb137:
  %t470 = load i64, ptr %l9, !tbaa !24
  %t472 = add i64 %t470, 1
  store i64 %t472, ptr %l9, !tbaa !24
  br label %bb10
bb138:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/generic:Context" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectContext(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l11 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca i64
  %l26 = alloca i32
  %l27 = alloca %"compiler/generic:Context"
  %l36 = alloca %"compiler/generic:Context"
  %l42 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca %"compiler/generic:Context"
  %l52 = alloca ptr
  %l55 = alloca %"compiler/generic:Context"
  %rv = alloca %"compiler/generic:Context"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 11
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l11, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t29, i64 %t30)
  store i64 %t33, ptr %l22
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t37, i64 %t38)
  store i32 %t41, ptr %l26
  br label %bb6
bb6:
  %t42 = load ptr, ptr %l18, !tbaa !29
  %t43 = load i64, ptr %l22, !tbaa !24
  %t44 = load i32, ptr %l26, !tbaa !23
  %t45 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %v0, ptr %v1, ptr %t42, i64 %t43, i32 %t44)
  store %"compiler/generic:Context" %t45, ptr %l27
  br label %bb7
bb7:
  %t46 = load %"compiler/generic:Context", ptr %l27
  store %"compiler/generic:Context" %t46, ptr %rv
  br label %ret
bb8:
  %t47 = load { i64, [2 x i64] }, ptr %l2
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 1
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t53 = getelementptr { i32, i32 }, ptr %t52, i32 0, i32 0
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l4, !tbaa !23
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t57 = getelementptr { i32, i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l5, !tbaa !23
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  %t65 = load i32, ptr %l5, !tbaa !23
  %t69 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorContext(ptr %v0, ptr %v1, ptr %t63, i32 %t64, i32 %t65)
  store %"compiler/generic:Context" %t69, ptr %l36
  br label %bb12
bb12:
  %t70 = load %"compiler/generic:Context", ptr %l36
  store %"compiler/generic:Context" %t70, ptr %rv
  br label %ret
bb13:
  %t71 = load { i64, [2 x i64] }, ptr %l2
  %t73 = extractvalue { i64, [2 x i64] } %t71, 0
  %t74 = icmp eq i64 %t73, 10
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t77 = getelementptr { i32, i64 }, ptr %t76, i32 0, i32 0
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l6, !tbaa !23
  %t80 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t81 = getelementptr { i32, i64 }, ptr %t80, i32 0, i32 1
  %t82 = load i64, ptr %t81
  store i64 %t82, ptr %l7, !tbaa !24
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  store ptr %t87, ptr %l42, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t92 = load i32, ptr %l6, !tbaa !23
  %t95 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t91, i32 %t92)
  store { i64, ptr } %t95, ptr %l46
  br label %bb17
bb17:
  %t96 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t96, ptr %l47, !tbaa !27
  %t97 = load i64, ptr %l7, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr %"compiler/generic:AnySlot", ptr %t100, i64 %t97
  %t102 = getelementptr %"compiler/generic:AnySlot", ptr %t101, i32 0, i32 1
  %t103 = load i32, ptr %t102, !tbaa !23
  %t104 = load ptr, ptr %l42, !tbaa !29
  %t106 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %v0, ptr %v1, ptr %t104, i32 %t103)
  store %"compiler/generic:Context" %t106, ptr %l50
  br label %bb18
bb18:
  %t107 = load %"compiler/generic:Context", ptr %l50
  store %"compiler/generic:Context" %t107, ptr %rv
  br label %ret
bb19:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t108)
  store ptr %t110, ptr %l52
  br label %bb20
bb20:
  %t111 = load ptr, ptr %l52, !tbaa !29
  %t113 = getelementptr %"compiler/check:frame", ptr %t111, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t116 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v1, i64 %t114, i64 -1)
  store %"compiler/generic:Context" %t116, ptr %l55
  br label %bb21
bb21:
  %t117 = load %"compiler/generic:Context", ptr %l55
  store %"compiler/generic:Context" %t117, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Context", ptr %rv
  ret %"compiler/generic:Context" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %a0, i32 %a1, i32 0)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 11
  store ptr %t13, ptr %l7, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t14)
  store ptr %t16, ptr %l9
  br label %bb4
bb3:
  %t17 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t19 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  call void @__olang_check_failed_text(ptr @olang_loc_43d20343d6f566de_136f8b7be912828a, { i64, ptr } %t20)
  unreachable
bb4:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 0
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t27 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t25, i64 %t24)
  store ptr %t27, ptr %l12
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l12, !tbaa !29
  store ptr %t28, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, [3 x i64] }
  %l13 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 10
  %t4 = load { i64, [3 x i64] }, ptr %t3
  %t6 = extractvalue { i64, [3 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 0
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 4
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l9, !tbaa !29
  store i64 %a1, ptr %l10, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 10
  %t25 = load { i64, [3 x i64] }, ptr %t24
  store { i64, [3 x i64] } %t25, ptr %l12
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %s1)
  store %"compiler/msgs:Msg" %t26, ptr %l13
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t27 = load ptr, ptr %l9, !tbaa !29
  %t28 = load i64, ptr %l10, !tbaa !24
  %t29 = load { i64, [3 x i64] }, ptr %l12
  %t30 = load %"compiler/msgs:Msg", ptr %l13
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s1, ptr %t27, i64 %t28, { i64, [3 x i64] } %t29, %"compiler/msgs:Msg" %t30)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i32
  %l10 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l10
  br label %bb4
bb3:
  %t17 = load i32, ptr %l1, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  br label %bb5
bb4:
  %t19 = load i32, ptr %l10, !tbaa !23
  store i32 %t19, ptr %l5, !tbaa !23
  br label %bb5
bb5:
  %t20 = load i32, ptr %l5, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/check:litv"
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"compiler/check:litv"
  %l15 = alloca { i1, i64 }
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca %"compiler/check:litv"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/check:litv"
  %l23 = alloca %"compiler/check:litv"
  %l24 = alloca double
  %l25 = alloca double
  %l26 = alloca { i1, i64 }
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca { i1, i64 }
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"compiler/check:litv"
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l40 = alloca %"compiler/check:litv"
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca i32
  %l81 = alloca i64
  %l82 = alloca i32
  %l83 = alloca %"compiler/check:litv"
  %l86 = alloca %"compiler/check:litv"
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i32
  %l92 = alloca i64
  %l93 = alloca i32
  %l94 = alloca i64
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca i32
  %l98 = alloca i64
  %l99 = alloca i32
  %l100 = alloca %"compiler/check:litv"
  %l103 = alloca %"compiler/check:litv"
  %l105 = alloca %"compiler/check:litv"
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l114 = alloca double
  %l116 = alloca double
  %l117 = alloca i32
  %l118 = alloca %"compiler/check:litv"
  %l120 = alloca %"compiler/check:litv"
  %l121 = alloca %"compiler/check:litv"
  %l122 = alloca ptr
  %l123 = alloca i1
  %l131 = alloca %"compiler/check:litv"
  %l132 = alloca ptr
  %l133 = alloca i1
  %l143 = alloca %"compiler/check:litv"
  %l146 = alloca %"compiler/check:litv"
  %l152 = alloca %"compiler/check:litv"
  %l154 = alloca { i1, i64 }
  %l159 = alloca %"compiler/check:litv"
  %l163 = alloca %"compiler/check:litv"
  %l164 = alloca %"compiler/check:litv"
  %l167 = alloca i1
  %l170 = alloca i1
  %l175 = alloca %"compiler/check:litv"
  %l178 = alloca %"compiler/check:litv"
  %l179 = alloca ptr
  %l180 = alloca i1
  %l191 = alloca %"compiler/check:litv"
  %l194 = alloca %"compiler/check:litv"
  %l197 = alloca i1
  %l200 = alloca %"compiler/check:litv"
  %l202 = alloca i1
  %l205 = alloca i1
  %l207 = alloca %"compiler/check:litv"
  %l209 = alloca double
  %l214 = alloca double
  %l223 = alloca %"compiler/check:litv"
  %l229 = alloca %"compiler/check:litv"
  %l235 = alloca %"compiler/check:litv"
  %l241 = alloca %"compiler/check:litv"
  %l242 = alloca %"compiler/check:litv"
  %l244 = alloca { i1, i64 }
  %l248 = alloca { i1, i64 }
  %l257 = alloca %"compiler/check:litv"
  %l265 = alloca %"compiler/check:litv"
  %l270 = alloca i1
  %l275 = alloca %"compiler/check:litv"
  %l282 = alloca i1
  %l286 = alloca %"compiler/check:litv"
  %l289 = alloca i1
  %l292 = alloca i1
  %l297 = alloca i64
  %l303 = alloca i64
  %l311 = alloca %"compiler/check:litv"
  %l313 = alloca i1
  %l315 = alloca i1
  %l319 = alloca %"compiler/check:litv"
  %l321 = alloca i1
  %l325 = alloca i1
  %l327 = alloca %"compiler/check:litv"
  %l332 = alloca i1
  %l335 = alloca i1
  %l339 = alloca i1
  %l346 = alloca %"compiler/check:litv"
  %l349 = alloca i1
  %l352 = alloca i1
  %l358 = alloca %"compiler/check:litv"
  %l361 = alloca i1
  %l364 = alloca i1
  %l367 = alloca i1
  %l372 = alloca i64
  %l376 = alloca i64
  %l380 = alloca %"compiler/check:litv"
  %l382 = alloca %"compiler/check:litv"
  %l385 = alloca i1
  %l388 = alloca i1
  %l392 = alloca i64
  %l394 = alloca %"compiler/check:litv"
  %l395 = alloca %"compiler/check:litv"
  %l396 = alloca %"compiler/check:litv"
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t5, ptr %l40
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load %"compiler/check:litv", ptr %l40
  store %"compiler/check:litv" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t8 = load ptr, ptr %l41, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l41, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 1
  store i1 %t14, ptr %l42, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l42, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l2
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l3
  br label %bb9
bb8:
  br label %bb66
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l2
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t28, %"compiler/source:Span" %t29)
  store { i64, ptr } %t32, ptr %l51
  br label %bb10
bb10:
  %t33 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load i32, ptr %l3
  %t36 = trunc i64 2 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp sgt i64 %t41, 2
  br i1 %t43, label %bb13, label %bb14
bb12:
  br label %bb54
bb13:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l58, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i8, ptr %t47, i64 0
  %t49 = load i8, ptr %t48, !tbaa !32
  %t51 = icmp eq i8 %t49, 48
  store i1 %t51, ptr %l57, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l57, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t54, ptr %l62, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 1
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = icmp eq i8 %t58, 120
  br i1 %t60, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb27
bb18:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb20
bb19:
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t62, ptr %l66, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 1
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp eq i8 %t66, 88
  store i1 %t68, ptr %l65, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l65, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb23
bb22:
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 1
  %t75 = load i8, ptr %t74, !tbaa !32
  %t77 = icmp eq i8 %t75, 98
  store i1 %t77, ptr %l69, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l69, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb26
bb25:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l74, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i8, ptr %t82, i64 1
  %t84 = load i8, ptr %t83, !tbaa !32
  %t86 = icmp eq i8 %t84, 66
  store i1 %t86, ptr %l73, !tbaa !21
  br label %bb26
bb26:
  %t88 = load i1, ptr %l73, !tbaa !21
  store i1 %t88, ptr %l61, !tbaa !21
  br label %bb27
bb27:
  %t89 = load i1, ptr %l61, !tbaa !21
  br i1 %t89, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t90, ptr %l78, !tbaa !27
  %t91 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 0)
  %t92 = extractvalue { i32, i64 } %t91, 1
  %t93 = extractvalue { i32, i64 } %t91, 0
  store i32 %t93, ptr %l80
  %t94 = icmp ne i32 %t93, 0
  br i1 %t94, label %bb31, label %ok.95
ok.95:
  store i64 %t92, ptr %l79
  br label %bb30
bb29:
  br label %bb38
bb30:
  %t96 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t97 = load i64, ptr %l79, !tbaa !24
  %t98 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t96, i64 %t97)
  %t99 = extractvalue { i32, i64 } %t98, 1
  %t100 = extractvalue { i32, i64 } %t98, 0
  store i32 %t100, ptr %l82
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb34, label %ok.102
ok.102:
  store i64 %t99, ptr %l81
  br label %bb33
bb31:
  br label %bb32
bb32:
  call void @__olang_ert_req_clear()
  %t103 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t103, ptr %l83
  br label %bb35
bb33:
  %t104 = load i64, ptr %l81, !tbaa !65
  store i64 %t104, ptr %l77, !tbaa !65
  br label %bb36
bb34:
  br label %bb32
bb35:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  %t105 = load %"compiler/check:litv", ptr %l83
  store %"compiler/check:litv" %t105, ptr %rv
  br label %ret
bb36:
  %t106 = load i64, ptr %l77, !tbaa !65
  %t110 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t106)
  store %"compiler/check:litv" %t110, ptr %l86
  br label %bb37
bb37:
  %t111 = load %"compiler/check:litv", ptr %l86
  store %"compiler/check:litv" %t111, ptr %l6
  %t112 = getelementptr %"compiler/check:litv", ptr %l6, i32 0, i32 5
  store i1 true, ptr %t112, !tbaa !21
  %t113 = load %"compiler/check:litv", ptr %l6
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store %"compiler/check:litv" %t113, ptr %rv
  br label %ret
bb38:
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t115, ptr %l89, !tbaa !27
  %t116 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s3, i64 0)
  %t117 = extractvalue { i32, i64 } %t116, 1
  %t118 = extractvalue { i32, i64 } %t116, 0
  store i32 %t118, ptr %l91
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb40, label %ok.120
ok.120:
  store i64 %t117, ptr %l90
  br label %bb39
bb39:
  %t121 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t122 = load i64, ptr %l90, !tbaa !24
  %t123 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t121, i64 %t122)
  %t124 = extractvalue { i32, i64 } %t123, 1
  %t125 = extractvalue { i32, i64 } %t123, 0
  store i32 %t125, ptr %l93
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb43, label %ok.127
ok.127:
  store i64 %t124, ptr %l92
  br label %bb42
bb40:
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s6
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l95, !tbaa !27
  %t129 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 0)
  %t130 = extractvalue { i32, i64 } %t129, 1
  %t131 = extractvalue { i32, i64 } %t129, 0
  store i32 %t131, ptr %l97
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb45, label %ok.133
ok.133:
  store i64 %t130, ptr %l96
  br label %bb44
bb42:
  %t134 = load i64, ptr %l92, !tbaa !24
  store i64 %t134, ptr %l88, !tbaa !24
  br label %bb52
bb43:
  br label %bb41
bb44:
  %t135 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t136 = load i64, ptr %l96, !tbaa !24
  %t137 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t135, i64 %t136)
  %t138 = extractvalue { i32, i64 } %t137, 1
  %t139 = extractvalue { i32, i64 } %t137, 0
  store i32 %t139, ptr %l99
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb48, label %ok.141
ok.141:
  store i64 %t138, ptr %l98
  br label %bb47
bb45:
  br label %bb46
bb46:
  call void @__olang_ert_req_clear()
  %t142 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t142, ptr %l100
  br label %bb49
bb47:
  %t143 = load i64, ptr %l98, !tbaa !65
  store i64 %t143, ptr %l94, !tbaa !65
  br label %bb50
bb48:
  br label %bb46
bb49:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  %t144 = load %"compiler/check:litv", ptr %l100
  store %"compiler/check:litv" %t144, ptr %rv
  br label %ret
bb50:
  %t145 = load i64, ptr %l94, !tbaa !65
  %t149 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s6, i1 true, i1 false, i1 true, i64 %t145, double 0x0000000000000000)
  store %"compiler/check:litv" %t149, ptr %l103
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  %t150 = load %"compiler/check:litv", ptr %l103
  store %"compiler/check:litv" %t150, ptr %rv
  br label %ret
bb52:
  %t151 = load i64, ptr %l88, !tbaa !24
  %t154 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t151)
  store %"compiler/check:litv" %t154, ptr %l105
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s3)
  %t155 = load %"compiler/check:litv", ptr %l105
  store %"compiler/check:litv" %t155, ptr %rv
  br label %ret
bb54:
  %t156 = load i32, ptr %l3
  %t158 = trunc i64 3 to i32
  %t159 = icmp eq i32 %t156, %t158
  br i1 %t159, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s8
  %t161 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l110, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l111, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t166 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t161, { i64, ptr } %t164, { i64, ptr } %t165)
  store { i64, ptr } %t166, ptr %l112
  br label %bb57
bb56:
  br label %bb64
bb57:
  %t167 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t171 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %s8, { i64, ptr } %t167)
  %t172 = extractvalue { i32, double } %t171, 1
  %t173 = extractvalue { i32, double } %t171, 0
  store i32 %t173, ptr %l117
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb59, label %ok.175
ok.175:
  store double %t172, ptr %l116
  br label %bb58
bb58:
  %t176 = load double, ptr %l116, !tbaa !26
  store double %t176, ptr %l114, !tbaa !26
  br label %bb62
bb59:
  br label %bb60
bb60:
  call void @__olang_ert_req_clear()
  %t177 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t177, ptr %l118
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s8)
  %t178 = load %"compiler/check:litv", ptr %l118
  store %"compiler/check:litv" %t178, ptr %rv
  br label %ret
bb62:
  %t179 = load double, ptr %l114, !tbaa !26
  %t182 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t179)
  store %"compiler/check:litv" %t182, ptr %l120
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  %t183 = load %"compiler/check:litv", ptr %l120
  store %"compiler/check:litv" %t183, ptr %rv
  br label %ret
bb64:
  %t184 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t184, ptr %l121
  br label %bb65
bb65:
  %t185 = load %"compiler/check:litv", ptr %l121
  store %"compiler/check:litv" %t185, ptr %rv
  br label %ret
bb66:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t187 = load ptr, ptr %l122, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb67, label %bb68
bb67:
  %t190 = load ptr, ptr %l122, !tbaa !29
  %t191 = load i64, ptr %t190
  %t193 = icmp eq i64 %t191, 2
  store i1 %t193, ptr %l123, !tbaa !21
  br label %bb68
bb68:
  %t194 = load i1, ptr %l123, !tbaa !21
  br i1 %t194, label %bb69, label %bb70
bb69:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", ptr }, ptr %t197, i32 0, i32 1
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l11, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load ptr, ptr %l11, !tbaa !29
  %t206 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t201, ptr %t202)
  store %"compiler/check:litv" %t206, ptr %l131
  br label %bb72
bb72:
  %t207 = load %"compiler/check:litv", ptr %l131
  store %"compiler/check:litv" %t207, ptr %rv
  br label %ret
bb73:
  %t208 = load ptr, ptr %l1, !tbaa !29
  store ptr %t208, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t209 = load ptr, ptr %l132, !tbaa !29
  %t210 = icmp ne ptr %t209, null
  br i1 %t210, label %bb74, label %bb75
bb74:
  %t212 = load ptr, ptr %l132, !tbaa !29
  %t213 = load i64, ptr %t212
  %t215 = icmp eq i64 %t213, 3
  store i1 %t215, ptr %l133, !tbaa !21
  br label %bb75
bb75:
  %t216 = load i1, ptr %l133, !tbaa !21
  br i1 %t216, label %bb76, label %bb77
bb76:
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr { i64, [5 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t219, i32 0, i32 1
  %t221 = load i32, ptr %t220
  store i32 %t221, ptr %l12
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t225, i32 0, i32 2
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l13, !tbaa !29
  br label %bb78
bb77:
  br label %bb108
bb78:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l13, !tbaa !29
  %t234 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t229, ptr %t230)
  store %"compiler/check:litv" %t234, ptr %l143
  br label %bb79
bb79:
  %t235 = load %"compiler/check:litv", ptr %l143
  store %"compiler/check:litv" %t235, ptr %l14
  %t236 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 0
  %t237 = load i1, ptr %t236, !tbaa !21
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb80, label %bb81
bb80:
  %t241 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t241, ptr %l146
  br label %bb82
bb81:
  br label %bb83
bb82:
  %t242 = load %"compiler/check:litv", ptr %l146
  store %"compiler/check:litv" %t242, ptr %rv
  br label %ret
bb83:
  %t243 = load i32, ptr %l12
  %t245 = trunc i64 52 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb84, label %bb85
bb84:
  %t248 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 1
  %t249 = load i1, ptr %t248, !tbaa !21
  br i1 %t249, label %bb86, label %bb87
bb85:
  br label %bb96
bb86:
  %t251 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 4
  %t252 = load double, ptr %t251, !tbaa !26
  %t254 = fneg double %t252
  %t256 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t254)
  store %"compiler/check:litv" %t256, ptr %l152
  br label %bb88
bb87:
  br label %bb89
bb88:
  %t257 = load %"compiler/check:litv", ptr %l152
  store %"compiler/check:litv" %t257, ptr %rv
  br label %ret
bb89:
  %t258 = load %"compiler/check:litv", ptr %l14
  %t260 = call { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t258)
  store { i1, i64 } %t260, ptr %l154
  br label %bb90
bb90:
  %t261 = load { i1, i64 }, ptr %l154
  store { i1, i64 } %t261, ptr %l15
  %t262 = getelementptr { i1, i64 }, ptr %l15, i32 0, i32 0
  %t263 = load i1, ptr %t262, !tbaa !21
  store i1 %t263, ptr %l16, !tbaa !21
  %t265 = getelementptr { i1, i64 }, ptr %l15, i32 0, i32 1
  %t266 = load i64, ptr %t265, !tbaa !65
  store i64 %t266, ptr %l17, !tbaa !65
  %t268 = load i64, ptr %l17, !tbaa !65
  %t270 = icmp ne i64 %t268, 0
  br i1 %t270, label %bb91, label %bb92
bb91:
  %t272 = load i1, ptr %l16, !tbaa !21
  %t274 = xor i1 %t272, true
  %t275 = load i64, ptr %l17, !tbaa !65
  %t278 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t274, i64 %t275)
  store %"compiler/check:litv" %t278, ptr %l163
  br label %bb93
bb92:
  %t279 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 0)
  store %"compiler/check:litv" %t279, ptr %l164
  br label %bb94
bb93:
  %t280 = load %"compiler/check:litv", ptr %l163
  store %"compiler/check:litv" %t280, ptr %l159
  br label %bb95
bb94:
  %t281 = load %"compiler/check:litv", ptr %l164
  store %"compiler/check:litv" %t281, ptr %l159
  br label %bb95
bb95:
  %t282 = load %"compiler/check:litv", ptr %l159
  store %"compiler/check:litv" %t282, ptr %rv
  br label %ret
bb96:
  %t283 = load i32, ptr %l12
  %t285 = trunc i64 86 to i32
  %t286 = icmp eq i32 %t283, %t285
  br i1 %t286, label %bb97, label %bb98
bb97:
  %t288 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 1
  %t289 = load i1, ptr %t288, !tbaa !21
  %t291 = xor i1 %t289, true
  store i1 %t291, ptr %l167, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb99
bb99:
  %t293 = load i1, ptr %l167, !tbaa !21
  br i1 %t293, label %bb100, label %bb101
bb100:
  %t294 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 2
  %t295 = load i1, ptr %t294, !tbaa !21
  %t297 = xor i1 %t295, true
  store i1 %t297, ptr %l170, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb102
bb102:
  %t299 = load i1, ptr %l170, !tbaa !21
  br i1 %t299, label %bb103, label %bb104
bb103:
  %t300 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 3
  %t301 = load i64, ptr %t300, !tbaa !24
  %t303 = xor i64 %t301, -1
  %t305 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t303)
  store %"compiler/check:litv" %t305, ptr %l175
  br label %bb105
bb104:
  br label %bb106
bb105:
  %t306 = load %"compiler/check:litv", ptr %l175
  store %"compiler/check:litv" %t306, ptr %l18
  %t307 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 5
  %t308 = load i1, ptr %t307, !tbaa !21
  %t310 = getelementptr %"compiler/check:litv", ptr %l18, i32 0, i32 5
  store i1 %t308, ptr %t310, !tbaa !21
  %t311 = load %"compiler/check:litv", ptr %l18
  store %"compiler/check:litv" %t311, ptr %rv
  br label %ret
bb106:
  %t313 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t313, ptr %l178
  br label %bb107
bb107:
  %t314 = load %"compiler/check:litv", ptr %l178
  store %"compiler/check:litv" %t314, ptr %rv
  br label %ret
bb108:
  %t315 = load ptr, ptr %l1, !tbaa !29
  store ptr %t315, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t316 = load ptr, ptr %l179, !tbaa !29
  %t317 = icmp ne ptr %t316, null
  br i1 %t317, label %bb109, label %bb110
bb109:
  %t319 = load ptr, ptr %l179, !tbaa !29
  %t320 = load i64, ptr %t319
  %t322 = icmp eq i64 %t320, 5
  store i1 %t322, ptr %l180, !tbaa !21
  br label %bb110
bb110:
  %t323 = load i1, ptr %l180, !tbaa !21
  br i1 %t323, label %bb111, label %bb112
bb111:
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr { i64, [5 x i64] }, ptr %t324, i32 0, i32 1
  %t327 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t326, i32 0, i32 1
  %t328 = load i32, ptr %t327
  store i32 %t328, ptr %l19
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr { i64, [5 x i64] }, ptr %t330, i32 0, i32 1
  %t333 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t332, i32 0, i32 2
  %t334 = load ptr, ptr %t333
  store ptr %t334, ptr %l20, !tbaa !29
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t338 = getelementptr { i64, [5 x i64] }, ptr %t336, i32 0, i32 1
  %t339 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t338, i32 0, i32 3
  %t340 = load ptr, ptr %t339
  store ptr %t340, ptr %l21, !tbaa !29
  br label %bb113
bb112:
  br label %bb270
bb113:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l20, !tbaa !29
  %t346 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t342, ptr %t343)
  store %"compiler/check:litv" %t346, ptr %l191
  br label %bb114
bb114:
  %t347 = load %"compiler/check:litv", ptr %l191
  store %"compiler/check:litv" %t347, ptr %l22
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l21, !tbaa !29
  %t352 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t348, ptr %t349)
  store %"compiler/check:litv" %t352, ptr %l194
  br label %bb115
bb115:
  %t353 = load %"compiler/check:litv", ptr %l194
  store %"compiler/check:litv" %t353, ptr %l23
  %t354 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 0
  %t355 = load i1, ptr %t354, !tbaa !21
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb116, label %bb117
bb116:
  store i1 true, ptr %l197, !tbaa !21
  br label %bb118
bb117:
  %t359 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 0
  %t360 = load i1, ptr %t359, !tbaa !21
  %t362 = xor i1 %t360, true
  store i1 %t362, ptr %l197, !tbaa !21
  br label %bb118
bb118:
  %t364 = load i1, ptr %l197, !tbaa !21
  br i1 %t364, label %bb119, label %bb120
bb119:
  %t365 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t365, ptr %l200
  br label %bb121
bb120:
  br label %bb122
bb121:
  %t366 = load %"compiler/check:litv", ptr %l200
  store %"compiler/check:litv" %t366, ptr %rv
  br label %ret
bb122:
  %t367 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 1
  %t368 = load i1, ptr %t367, !tbaa !21
  br i1 %t368, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb125
bb124:
  %t370 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 1
  %t371 = load i1, ptr %t370, !tbaa !21
  store i1 %t371, ptr %l202, !tbaa !21
  br label %bb125
bb125:
  %t373 = load i1, ptr %l202, !tbaa !21
  br i1 %t373, label %bb126, label %bb127
bb126:
  %t374 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t375 = load i1, ptr %t374, !tbaa !21
  br i1 %t375, label %bb128, label %bb129
bb127:
  br label %bb158
bb128:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb130
bb129:
  %t377 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t378 = load i1, ptr %t377, !tbaa !21
  store i1 %t378, ptr %l205, !tbaa !21
  br label %bb130
bb130:
  %t380 = load i1, ptr %l205, !tbaa !21
  br i1 %t380, label %bb131, label %bb132
bb131:
  %t381 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t381, ptr %l207
  br label %bb133
bb132:
  br label %bb134
bb133:
  %t382 = load %"compiler/check:litv", ptr %l207
  store %"compiler/check:litv" %t382, ptr %rv
  br label %ret
bb134:
  %t383 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 1
  %t384 = load i1, ptr %t383, !tbaa !21
  br i1 %t384, label %bb135, label %bb136
bb135:
  %t386 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 4
  %t387 = load double, ptr %t386, !tbaa !26
  store double %t387, ptr %l209, !tbaa !26
  br label %bb137
bb136:
  %t389 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t390 = load i64, ptr %t389, !tbaa !24
  %t392 = sitofp i64 %t390 to double
  store double %t392, ptr %l209, !tbaa !26
  br label %bb137
bb137:
  %t394 = load double, ptr %l209, !tbaa !26
  store double %t394, ptr %l24, !tbaa !26
  %t395 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 1
  %t396 = load i1, ptr %t395, !tbaa !21
  br i1 %t396, label %bb138, label %bb139
bb138:
  %t398 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 4
  %t399 = load double, ptr %t398, !tbaa !26
  store double %t399, ptr %l214, !tbaa !26
  br label %bb140
bb139:
  %t401 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t402 = load i64, ptr %t401, !tbaa !24
  %t404 = sitofp i64 %t402 to double
  store double %t404, ptr %l214, !tbaa !26
  br label %bb140
bb140:
  %t406 = load double, ptr %l214, !tbaa !26
  store double %t406, ptr %l25, !tbaa !26
  %t407 = load i32, ptr %l19
  %t409 = trunc i64 51 to i32
  %t410 = icmp eq i32 %t407, %t409
  br i1 %t410, label %bb141, label %bb142
bb141:
  %t412 = load double, ptr %l24, !tbaa !26
  %t413 = load double, ptr %l25, !tbaa !26
  %t416 = fadd double %t412, %t413
  %t418 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t416)
  store %"compiler/check:litv" %t418, ptr %l223
  br label %bb143
bb142:
  br label %bb144
bb143:
  %t419 = load %"compiler/check:litv", ptr %l223
  store %"compiler/check:litv" %t419, ptr %rv
  br label %ret
bb144:
  %t420 = load i32, ptr %l19
  %t422 = trunc i64 52 to i32
  %t423 = icmp eq i32 %t420, %t422
  br i1 %t423, label %bb145, label %bb146
bb145:
  %t425 = load double, ptr %l24, !tbaa !26
  %t426 = load double, ptr %l25, !tbaa !26
  %t429 = fsub double %t425, %t426
  %t431 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t429)
  store %"compiler/check:litv" %t431, ptr %l229
  br label %bb147
bb146:
  br label %bb148
bb147:
  %t432 = load %"compiler/check:litv", ptr %l229
  store %"compiler/check:litv" %t432, ptr %rv
  br label %ret
bb148:
  %t433 = load i32, ptr %l19
  %t435 = trunc i64 53 to i32
  %t436 = icmp eq i32 %t433, %t435
  br i1 %t436, label %bb149, label %bb150
bb149:
  %t438 = load double, ptr %l24, !tbaa !26
  %t439 = load double, ptr %l25, !tbaa !26
  %t442 = fmul double %t438, %t439
  %t444 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t442)
  store %"compiler/check:litv" %t444, ptr %l235
  br label %bb151
bb150:
  br label %bb152
bb151:
  %t445 = load %"compiler/check:litv", ptr %l235
  store %"compiler/check:litv" %t445, ptr %rv
  br label %ret
bb152:
  %t446 = load i32, ptr %l19
  %t448 = trunc i64 54 to i32
  %t449 = icmp eq i32 %t446, %t448
  br i1 %t449, label %bb153, label %bb154
bb153:
  %t451 = load double, ptr %l24, !tbaa !26
  %t452 = load double, ptr %l25, !tbaa !26
  %t455 = fdiv double %t451, %t452
  %t457 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t455)
  store %"compiler/check:litv" %t457, ptr %l241
  br label %bb155
bb154:
  br label %bb156
bb155:
  %t458 = load %"compiler/check:litv", ptr %l241
  store %"compiler/check:litv" %t458, ptr %rv
  br label %ret
bb156:
  %t459 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t459, ptr %l242
  br label %bb157
bb157:
  %t460 = load %"compiler/check:litv", ptr %l242
  store %"compiler/check:litv" %t460, ptr %rv
  br label %ret
bb158:
  %t461 = load %"compiler/check:litv", ptr %l22
  %t463 = call { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t461)
  store { i1, i64 } %t463, ptr %l244
  br label %bb159
bb159:
  %t464 = load { i1, i64 }, ptr %l244
  store { i1, i64 } %t464, ptr %l26
  %t465 = getelementptr { i1, i64 }, ptr %l26, i32 0, i32 0
  %t466 = load i1, ptr %t465, !tbaa !21
  store i1 %t466, ptr %l27, !tbaa !21
  %t468 = getelementptr { i1, i64 }, ptr %l26, i32 0, i32 1
  %t469 = load i64, ptr %t468, !tbaa !65
  store i64 %t469, ptr %l28, !tbaa !65
  %t471 = load %"compiler/check:litv", ptr %l23
  %t473 = call { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t471)
  store { i1, i64 } %t473, ptr %l248
  br label %bb160
bb160:
  %t474 = load { i1, i64 }, ptr %l248
  store { i1, i64 } %t474, ptr %l29
  %t475 = getelementptr { i1, i64 }, ptr %l29, i32 0, i32 0
  %t476 = load i1, ptr %t475, !tbaa !21
  store i1 %t476, ptr %l30, !tbaa !21
  %t478 = getelementptr { i1, i64 }, ptr %l29, i32 0, i32 1
  %t479 = load i64, ptr %t478, !tbaa !65
  store i64 %t479, ptr %l31, !tbaa !65
  %t481 = load i32, ptr %l19
  %t483 = trunc i64 51 to i32
  %t484 = icmp eq i32 %t481, %t483
  br i1 %t484, label %bb161, label %bb162
bb161:
  %t486 = load i1, ptr %l27, !tbaa !21
  %t487 = load i64, ptr %l28, !tbaa !65
  %t488 = load i1, ptr %l30, !tbaa !21
  %t489 = load i64, ptr %l31, !tbaa !65
  %t494 = call %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %t486, i64 %t487, i1 %t488, i64 %t489)
  store %"compiler/check:litv" %t494, ptr %l257
  br label %bb163
bb162:
  br label %bb164
bb163:
  %t495 = load %"compiler/check:litv", ptr %l257
  store %"compiler/check:litv" %t495, ptr %rv
  br label %ret
bb164:
  %t496 = load i32, ptr %l19
  %t498 = trunc i64 52 to i32
  %t499 = icmp eq i32 %t496, %t498
  br i1 %t499, label %bb165, label %bb166
bb165:
  %t501 = load i1, ptr %l27, !tbaa !21
  %t502 = load i64, ptr %l28, !tbaa !65
  %t503 = load i1, ptr %l30, !tbaa !21
  %t505 = xor i1 %t503, true
  %t506 = load i64, ptr %l31, !tbaa !65
  %t511 = call %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %t501, i64 %t502, i1 %t505, i64 %t506)
  store %"compiler/check:litv" %t511, ptr %l265
  br label %bb167
bb166:
  br label %bb168
bb167:
  %t512 = load %"compiler/check:litv", ptr %l265
  store %"compiler/check:litv" %t512, ptr %rv
  br label %ret
bb168:
  %t513 = load i32, ptr %l19
  %t515 = trunc i64 53 to i32
  %t516 = icmp eq i32 %t513, %t515
  br i1 %t516, label %bb169, label %bb170
bb169:
  %t518 = load i64, ptr %l28, !tbaa !65
  %t520 = icmp ne i64 %t518, 0
  br i1 %t520, label %bb171, label %bb172
bb170:
  br label %bb182
bb171:
  %t522 = load i64, ptr %l31, !tbaa !65
  %t523 = load i64, ptr %l28, !tbaa !65
  %t525 = udiv i64 -1, %t523
  %t528 = icmp ugt i64 %t522, %t525
  store i1 %t528, ptr %l270, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l270, !tbaa !21
  br label %bb173
bb173:
  %t530 = load i1, ptr %l270, !tbaa !21
  br i1 %t530, label %bb174, label %bb175
bb174:
  %t531 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t531, ptr %l275
  br label %bb176
bb175:
  br label %bb177
bb176:
  %t532 = load %"compiler/check:litv", ptr %l275
  store %"compiler/check:litv" %t532, ptr %rv
  br label %ret
bb177:
  %t533 = load i64, ptr %l28, !tbaa !65
  %t534 = load i64, ptr %l31, !tbaa !65
  %t537 = mul i64 %t533, %t534
  store i64 %t537, ptr %l32, !tbaa !65
  %t539 = load i1, ptr %l27, !tbaa !21
  %t540 = load i1, ptr %l30, !tbaa !21
  %t543 = icmp ne i1 %t539, %t540
  br i1 %t543, label %bb178, label %bb179
bb178:
  %t545 = load i64, ptr %l32, !tbaa !65
  %t547 = icmp ne i64 %t545, 0
  store i1 %t547, ptr %l282, !tbaa !21
  br label %bb180
bb179:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb180
bb180:
  %t549 = load i64, ptr %l32, !tbaa !65
  %t550 = load i1, ptr %l282, !tbaa !21
  %t552 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t550, i64 %t549)
  store %"compiler/check:litv" %t552, ptr %l286
  br label %bb181
bb181:
  %t553 = load %"compiler/check:litv", ptr %l286
  store %"compiler/check:litv" %t553, ptr %rv
  br label %ret
bb182:
  %t554 = load i32, ptr %l19
  %t556 = trunc i64 83 to i32
  %t557 = icmp eq i32 %t554, %t556
  br i1 %t557, label %bb183, label %bb184
bb183:
  store i1 true, ptr %l289, !tbaa !21
  br label %bb185
bb184:
  %t559 = load i32, ptr %l19
  %t561 = trunc i64 84 to i32
  %t562 = icmp eq i32 %t559, %t561
  store i1 %t562, ptr %l289, !tbaa !21
  br label %bb185
bb185:
  %t564 = load i1, ptr %l289, !tbaa !21
  br i1 %t564, label %bb186, label %bb187
bb186:
  store i1 true, ptr %l292, !tbaa !21
  br label %bb188
bb187:
  %t565 = load i32, ptr %l19
  %t567 = trunc i64 85 to i32
  %t568 = icmp eq i32 %t565, %t567
  store i1 %t568, ptr %l292, !tbaa !21
  br label %bb188
bb188:
  %t570 = load i1, ptr %l292, !tbaa !21
  br i1 %t570, label %bb189, label %bb190
bb189:
  %t571 = load i32, ptr %l19
  %t573 = trunc i64 83 to i32
  %t574 = icmp eq i32 %t571, %t573
  br i1 %t574, label %bb191, label %bb192
bb190:
  br label %bb211
bb191:
  %t576 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t577 = load i64, ptr %t576, !tbaa !24
  %t578 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t579 = load i64, ptr %t578, !tbaa !24
  %t582 = and i64 %t577, %t579
  store i64 %t582, ptr %l297, !tbaa !24
  br label %bb196
bb192:
  %t584 = load i32, ptr %l19
  %t586 = trunc i64 84 to i32
  %t587 = icmp eq i32 %t584, %t586
  br i1 %t587, label %bb193, label %bb194
bb193:
  %t589 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t590 = load i64, ptr %t589, !tbaa !24
  %t591 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t592 = load i64, ptr %t591, !tbaa !24
  %t595 = or i64 %t590, %t592
  store i64 %t595, ptr %l303, !tbaa !24
  br label %bb195
bb194:
  %t597 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t598 = load i64, ptr %t597, !tbaa !24
  %t599 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t600 = load i64, ptr %t599, !tbaa !24
  %t603 = xor i64 %t598, %t600
  store i64 %t603, ptr %l303, !tbaa !24
  br label %bb195
bb195:
  %t605 = load i64, ptr %l303, !tbaa !24
  store i64 %t605, ptr %l297, !tbaa !24
  br label %bb196
bb196:
  %t606 = load i64, ptr %l297, !tbaa !24
  store i64 %t606, ptr %l33, !tbaa !24
  %t607 = load i64, ptr %l33, !tbaa !24
  %t609 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t607)
  store %"compiler/check:litv" %t609, ptr %l311
  br label %bb197
bb197:
  %t610 = load %"compiler/check:litv", ptr %l311
  store %"compiler/check:litv" %t610, ptr %l34
  %t611 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t612 = load i1, ptr %t611, !tbaa !21
  br i1 %t612, label %bb198, label %bb199
bb198:
  store i1 true, ptr %l313, !tbaa !21
  br label %bb200
bb199:
  %t614 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t615 = load i1, ptr %t614, !tbaa !21
  store i1 %t615, ptr %l313, !tbaa !21
  br label %bb200
bb200:
  %t617 = load i1, ptr %l313, !tbaa !21
  br i1 %t617, label %bb201, label %bb202
bb201:
  %t618 = load i64, ptr %l33, !tbaa !24
  %t620 = icmp slt i64 %t618, 0
  store i1 %t620, ptr %l315, !tbaa !21
  br label %bb203
bb202:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb203
bb203:
  %t622 = load i1, ptr %l315, !tbaa !21
  br i1 %t622, label %bb204, label %bb205
bb204:
  store %olang.scope zeroinitializer, ptr %s29
  %t623 = load i64, ptr %l33, !tbaa !24
  %t625 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s29, i1 true, i1 false, i1 true, i64 %t623, double 0x0000000000000000)
  store %"compiler/check:litv" %t625, ptr %l319
  br label %bb206
bb205:
  br label %bb207
bb206:
  %t626 = load %"compiler/check:litv", ptr %l319
  store %"compiler/check:litv" %t626, ptr %l34
  call void @__olang_scope_close(ptr %s29)
  br label %bb207
bb207:
  %t627 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 5
  %t628 = load i1, ptr %t627, !tbaa !21
  br i1 %t628, label %bb208, label %bb209
bb208:
  store i1 true, ptr %l321, !tbaa !21
  br label %bb210
bb209:
  %t630 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 5
  %t631 = load i1, ptr %t630, !tbaa !21
  store i1 %t631, ptr %l321, !tbaa !21
  br label %bb210
bb210:
  %t633 = load i1, ptr %l321, !tbaa !21
  %t634 = getelementptr %"compiler/check:litv", ptr %l34, i32 0, i32 5
  store i1 %t633, ptr %t634, !tbaa !21
  %t635 = load %"compiler/check:litv", ptr %l34
  store %"compiler/check:litv" %t635, ptr %rv
  br label %ret
bb211:
  %t637 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t638 = load i1, ptr %t637, !tbaa !21
  br i1 %t638, label %bb212, label %bb213
bb212:
  store i1 true, ptr %l325, !tbaa !21
  br label %bb214
bb213:
  %t640 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t641 = load i1, ptr %t640, !tbaa !21
  store i1 %t641, ptr %l325, !tbaa !21
  br label %bb214
bb214:
  %t643 = load i1, ptr %l325, !tbaa !21
  br i1 %t643, label %bb215, label %bb216
bb215:
  %t644 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t644, ptr %l327
  br label %bb217
bb216:
  br label %bb218
bb217:
  %t645 = load %"compiler/check:litv", ptr %l327
  store %"compiler/check:litv" %t645, ptr %rv
  br label %ret
bb218:
  %t646 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t647 = load i64, ptr %t646, !tbaa !24
  store i64 %t647, ptr %l35, !tbaa !24
  %t649 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t650 = load i64, ptr %t649, !tbaa !24
  store i64 %t650, ptr %l36, !tbaa !24
  %t652 = load i32, ptr %l19
  %t654 = trunc i64 54 to i32
  %t655 = icmp eq i32 %t652, %t654
  br i1 %t655, label %bb219, label %bb220
bb219:
  %t657 = load i64, ptr %l36, !tbaa !24
  %t659 = icmp ne i64 %t657, 0
  store i1 %t659, ptr %l332, !tbaa !21
  br label %bb221
bb220:
  store i1 false, ptr %l332, !tbaa !21
  br label %bb221
bb221:
  %t661 = load i1, ptr %l332, !tbaa !21
  br i1 %t661, label %bb222, label %bb223
bb222:
  %t662 = load i64, ptr %l35, !tbaa !24
  %t663 = sub i64 -9223372036854775807, 1
  %t666 = icmp eq i64 %t662, %t663
  br i1 %t666, label %bb224, label %bb225
bb223:
  store i1 false, ptr %l335, !tbaa !21
  br label %bb227
bb224:
  %t668 = load i64, ptr %l36, !tbaa !24
  %t670 = icmp eq i64 %t668, -1
  store i1 %t670, ptr %l339, !tbaa !21
  br label %bb226
bb225:
  store i1 false, ptr %l339, !tbaa !21
  br label %bb226
bb226:
  %t672 = load i1, ptr %l339, !tbaa !21
  %t673 = xor i1 %t672, true
  store i1 %t673, ptr %l335, !tbaa !21
  br label %bb227
bb227:
  %t675 = load i1, ptr %l335, !tbaa !21
  br i1 %t675, label %bb228, label %bb229
bb228:
  %t676 = load i64, ptr %l35, !tbaa !24
  %t677 = load i64, ptr %l36, !tbaa !24
  %t680 = sdiv i64 %t676, %t677
  %t682 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t680)
  store %"compiler/check:litv" %t682, ptr %l346
  br label %bb230
bb229:
  br label %bb231
bb230:
  %t683 = load %"compiler/check:litv", ptr %l346
  store %"compiler/check:litv" %t683, ptr %rv
  br label %ret
bb231:
  %t684 = load i32, ptr %l19
  %t686 = trunc i64 55 to i32
  %t687 = icmp eq i32 %t684, %t686
  br i1 %t687, label %bb232, label %bb233
bb232:
  %t689 = load i64, ptr %l36, !tbaa !24
  %t691 = icmp ne i64 %t689, 0
  store i1 %t691, ptr %l349, !tbaa !21
  br label %bb234
bb233:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb234
bb234:
  %t693 = load i1, ptr %l349, !tbaa !21
  br i1 %t693, label %bb235, label %bb236
bb235:
  %t694 = load i64, ptr %l36, !tbaa !24
  %t696 = icmp ne i64 %t694, -1
  store i1 %t696, ptr %l352, !tbaa !21
  br label %bb237
bb236:
  store i1 false, ptr %l352, !tbaa !21
  br label %bb237
bb237:
  %t698 = load i1, ptr %l352, !tbaa !21
  br i1 %t698, label %bb238, label %bb239
bb238:
  %t699 = load i64, ptr %l35, !tbaa !24
  %t700 = load i64, ptr %l36, !tbaa !24
  %t703 = srem i64 %t699, %t700
  %t705 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t703)
  store %"compiler/check:litv" %t705, ptr %l358
  br label %bb240
bb239:
  br label %bb241
bb240:
  %t706 = load %"compiler/check:litv", ptr %l358
  store %"compiler/check:litv" %t706, ptr %rv
  br label %ret
bb241:
  %t707 = load i32, ptr %l19
  %t709 = trunc i64 88 to i32
  %t710 = icmp eq i32 %t707, %t709
  br i1 %t710, label %bb242, label %bb243
bb242:
  %t712 = load i1, ptr %l27, !tbaa !21
  %t714 = xor i1 %t712, true
  store i1 %t714, ptr %l361, !tbaa !21
  br label %bb244
bb243:
  store i1 false, ptr %l361, !tbaa !21
  br label %bb244
bb244:
  %t716 = load i1, ptr %l361, !tbaa !21
  br i1 %t716, label %bb245, label %bb246
bb245:
  %t717 = load i64, ptr %l36, !tbaa !24
  %t719 = icmp sge i64 %t717, 0
  store i1 %t719, ptr %l364, !tbaa !21
  br label %bb247
bb246:
  store i1 false, ptr %l364, !tbaa !21
  br label %bb247
bb247:
  %t721 = load i1, ptr %l364, !tbaa !21
  br i1 %t721, label %bb248, label %bb249
bb248:
  %t722 = load i64, ptr %l36, !tbaa !24
  %t724 = icmp slt i64 %t722, 64
  store i1 %t724, ptr %l367, !tbaa !21
  br label %bb250
bb249:
  store i1 false, ptr %l367, !tbaa !21
  br label %bb250
bb250:
  %t726 = load i1, ptr %l367, !tbaa !21
  br i1 %t726, label %bb251, label %bb252
bb251:
  %t727 = load i64, ptr %l28, !tbaa !65
  %t728 = load i64, ptr %l36, !tbaa !24
  store i64 %t728, ptr %l372, !tbaa !65
  %t731 = load i64, ptr %l372, !tbaa !65
  %t732 = load i64, ptr %l372, !tbaa !65
  %t733 = shl i64 %t727, %t732
  store i64 %t733, ptr %l37, !tbaa !65
  %t735 = load i64, ptr %l37, !tbaa !65
  %t736 = load i64, ptr %l36, !tbaa !24
  store i64 %t736, ptr %l376, !tbaa !65
  %t739 = load i64, ptr %l376, !tbaa !65
  %t740 = load i64, ptr %l376, !tbaa !65
  %t741 = lshr i64 %t735, %t740
  %t742 = load i64, ptr %l28, !tbaa !65
  %t745 = icmp ne i64 %t741, %t742
  br i1 %t745, label %bb253, label %bb254
bb252:
  br label %bb258
bb253:
  %t747 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t747, ptr %l380
  br label %bb255
bb254:
  br label %bb256
bb255:
  %t748 = load %"compiler/check:litv", ptr %l380
  store %"compiler/check:litv" %t748, ptr %rv
  br label %ret
bb256:
  %t749 = load i64, ptr %l37, !tbaa !65
  %t751 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 false, i64 %t749)
  store %"compiler/check:litv" %t751, ptr %l382
  br label %bb257
bb257:
  %t752 = load %"compiler/check:litv", ptr %l382
  store %"compiler/check:litv" %t752, ptr %rv
  br label %ret
bb258:
  %t753 = load i32, ptr %l19
  %t755 = trunc i64 89 to i32
  %t756 = icmp eq i32 %t753, %t755
  br i1 %t756, label %bb259, label %bb260
bb259:
  %t758 = load i64, ptr %l36, !tbaa !24
  %t760 = icmp sge i64 %t758, 0
  store i1 %t760, ptr %l385, !tbaa !21
  br label %bb261
bb260:
  store i1 false, ptr %l385, !tbaa !21
  br label %bb261
bb261:
  %t762 = load i1, ptr %l385, !tbaa !21
  br i1 %t762, label %bb262, label %bb263
bb262:
  %t763 = load i64, ptr %l36, !tbaa !24
  %t765 = icmp slt i64 %t763, 64
  store i1 %t765, ptr %l388, !tbaa !21
  br label %bb264
bb263:
  store i1 false, ptr %l388, !tbaa !21
  br label %bb264
bb264:
  %t767 = load i1, ptr %l388, !tbaa !21
  br i1 %t767, label %bb265, label %bb266
bb265:
  %t768 = load i64, ptr %l35, !tbaa !24
  %t769 = load i64, ptr %l36, !tbaa !24
  store i64 %t769, ptr %l392, !tbaa !24
  %t771 = load i64, ptr %l392, !tbaa !24
  %t772 = load i64, ptr %l392, !tbaa !24
  %t773 = ashr i64 %t768, %t772
  %t775 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t773)
  store %"compiler/check:litv" %t775, ptr %l394
  br label %bb267
bb266:
  br label %bb268
bb267:
  %t776 = load %"compiler/check:litv", ptr %l394
  store %"compiler/check:litv" %t776, ptr %rv
  br label %ret
bb268:
  %t777 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t777, ptr %l395
  br label %bb269
bb269:
  %t778 = load %"compiler/check:litv", ptr %l395
  store %"compiler/check:litv" %t778, ptr %rv
  br label %ret
bb270:
  %t779 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t779, ptr %l396
  br label %bb271
bb271:
  %t780 = load %"compiler/check:litv", ptr %l396
  store %"compiler/check:litv" %t780, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenResultMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l23 = alloca { i64, ptr }
  %l27 = alloca i1
  %l32 = alloca i1
  %s4 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t36, ptr %l23, !tbaa !27
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 %t37
  %t42 = load ptr, ptr %t41, !tbaa !39
  store ptr %t42, ptr %l6, !tbaa !29
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = call i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v1, ptr %t44)
  store i1 %t46, ptr %l27
  br label %bb13
bb13:
  %t47 = load i1, ptr %l27, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l6, !tbaa !29
  %t55 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %t51)
  store i1 %t55, ptr %l32
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l4, !tbaa !24
  br label %bb9
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericCase(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/generic:Binding"
  %lp22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca %"compiler/check:litv"
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l45 = alloca i32
  %l48 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i32
  %l57 = alloca i1
  %l62 = alloca i32
  %l65 = alloca i1
  %l70 = alloca i32
  %l73 = alloca i1
  %l78 = alloca i32
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca i32
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l93 = alloca i32
  %l97 = alloca i1
  %l103 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l117 = alloca i64
  %l120 = alloca i64
  %l138 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca %"compiler/source:Span"
  %l153 = alloca %"compiler/msgs:Msg"
  %l154 = alloca i64
  %l159 = alloca ptr
  %l164 = alloca i32
  %l170 = alloca ptr
  %l172 = alloca i64
  %l177 = alloca i64
  %l180 = alloca ptr
  %l185 = alloca i32
  %l186 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l195 = alloca i64
  %l199 = alloca { i64, ptr }
  %l202 = alloca %"compiler/msgs:Msg"
  %l203 = alloca i64
  %l208 = alloca ptr
  %l211 = alloca %"compiler/generic:Binding"
  %l212 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l218 = alloca i64
  %l221 = alloca i64
  %l240 = alloca { i64, ptr }
  %l244 = alloca %"compiler/check:litv"
  %l246 = alloca i1
  %l248 = alloca { i64, ptr }
  %l251 = alloca i1
  %l253 = alloca i1
  %l256 = alloca { i64, ptr }
  %l259 = alloca i1
  %l260 = alloca ptr
  %l261 = alloca { i64, ptr }
  %l263 = alloca i32
  %l265 = alloca i32
  %l269 = alloca i32
  %l271 = alloca i32
  %l273 = alloca { i64, ptr }
  %l276 = alloca ptr
  %l277 = alloca i1
  %l280 = alloca ptr
  %l281 = alloca i1
  %l285 = alloca { i64, ptr }
  %l290 = alloca ptr
  %l295 = alloca i1
  %l298 = alloca i32
  %l301 = alloca i1
  %l304 = alloca i32
  %l307 = alloca ptr
  %l308 = alloca { i64, ptr }
  %l310 = alloca i32
  %l313 = alloca i32
  %l331 = alloca i64
  %l334 = alloca i64
  %l352 = alloca { i64, ptr }
  %l358 = alloca i1
  %l363 = alloca i1
  %l364 = alloca { i64, ptr }
  %l365 = alloca i64
  %l368 = alloca i32
  %l372 = alloca ptr
  %l377 = alloca i32
  %l378 = alloca { i64, ptr }
  %l379 = alloca ptr
  %l380 = alloca %"compiler/source:Span"
  %l381 = alloca { i64, ptr }
  %l382 = alloca { i64, ptr }
  %l385 = alloca { i64, ptr }
  %l388 = alloca %"compiler/msgs:Msg"
  %l389 = alloca i64
  %l392 = alloca ptr
  %l395 = alloca i1
  %l396 = alloca { i64, ptr }
  %l397 = alloca i64
  %l400 = alloca ptr
  %l405 = alloca i32
  %l407 = alloca i32
  %l410 = alloca ptr
  %l413 = alloca i32
  %l414 = alloca i32
  %l417 = alloca { i64, ptr }
  %l418 = alloca i64
  %l424 = alloca i32
  %l428 = alloca ptr
  %l429 = alloca i32
  %l434 = alloca i32
  %l435 = alloca i32
  %l439 = alloca i1
  %l441 = alloca i1
  %l445 = alloca i1
  %l449 = alloca ptr
  %l450 = alloca ptr
  %l451 = alloca %"compiler/source:Span"
  %l452 = alloca %"compiler/source:Span"
  %l453 = alloca i32
  %l454 = alloca i32
  %l455 = alloca { i64, ptr }
  %l457 = alloca { i64, ptr }
  %l458 = alloca ptr
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l6, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l48, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l6, !tbaa !23
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l51
  br label %bb3
bb2:
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t18, ptr %l45, !tbaa !23
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l48, !tbaa !29
  %t21 = load i32, ptr %l51, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t22, ptr %l52
  br label %bb4
bb4:
  %t23 = load i32, ptr %l52, !tbaa !23
  store i32 %t23, ptr %l45, !tbaa !23
  br label %bb5
bb5:
  %t24 = load i32, ptr %l45, !tbaa !23
  store i32 %t24, ptr %l7, !tbaa !23
  %t25 = load i32, ptr %l7, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp ne i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l7, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l62
  br label %bb8
bb7:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb9
bb8:
  %t41 = load i32, ptr %l62
  %t43 = trunc i64 18 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l57, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l57, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l7, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l70
  br label %bb12
bb11:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb13
bb12:
  %t57 = load i32, ptr %l3, !tbaa !23
  %t58 = load i32, ptr %l70, !tbaa !23
  %t60 = icmp eq i32 %t58, %t57
  store i1 %t60, ptr %l65, !tbaa !21
  br label %bb13
bb13:
  %t62 = load i1, ptr %l65, !tbaa !21
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l7, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l78
  br label %bb16
bb15:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb17
bb16:
  %t73 = load i32, ptr %l78, !tbaa !23
  %t74 = icmp ne i32 %t73, 0
  store i1 %t74, ptr %l73, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l73, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l80, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t78, ptr %l81
  %t79 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t79, ptr %l82
  %t80 = load i32, ptr %l7, !tbaa !23
  store i32 %t80, ptr %l83, !tbaa !23
  %t81 = load i32, ptr %l4, !tbaa !23
  store i32 %t81, ptr %l84, !tbaa !23
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t82, ptr %l85, !tbaa !27
  %t83 = icmp sge i64 0, 0
  br i1 %t83, label %bb20, label %bb21
bb19:
  br label %bb25
bb20:
  %t85 = icmp sle i64 0, 1152921504606846975
  br i1 %t85, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9c930588fc11ccad_eb7b13c9402bcb61)
  unreachable
bb22:
  %t87 = mul i64 0, 8
  %t88 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 0, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load ptr, ptr %l80, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l81
  %t93 = load %"compiler/source:Span", ptr %l82
  %t94 = load i32, ptr %l83, !tbaa !23
  %t95 = load i32, ptr %l84, !tbaa !23
  %t96 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t98 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v0, ptr %t91, %"compiler/source:Span" %t92, %"compiler/source:Span" %t93, i32 %t94, i32 %t95, { i64, ptr } %t96, { i64, ptr } %t90)
  store ptr %t98, ptr %l89
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_9c930588fc11ccad_eb7b13c9402bcb61)
  unreachable
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t99 = load ptr, ptr %l89, !tbaa !29
  store ptr %t99, ptr %rv
  br label %ret
bb25:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t104 = load i32, ptr %l3, !tbaa !23
  %t107 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l93
  br label %bb26
bb26:
  %t108 = load i32, ptr %l93, !tbaa !23
  store i32 %t108, ptr %l8, !tbaa !23
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load i32, ptr %l8, !tbaa !23
  %t116 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t112, i32 %t113)
  store i1 %t116, ptr %l97
  br label %bb27
bb27:
  %t117 = load i1, ptr %l97, !tbaa !21
  %t118 = xor i1 %t117, true
  br i1 %t118, label %bb28, label %bb29
bb28:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t120, { i64, ptr } %t121)
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l1
  %t128 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t124, %"compiler/source:Span" %t125)
  store ptr %t128, ptr %l103
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t129 = load ptr, ptr %l103, !tbaa !29
  store ptr %t129, ptr %rv
  br label %ret
bb32:
  store i64 -1, ptr %l9, !tbaa !24
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  %t136 = load i32, ptr %l8, !tbaa !23
  %t139 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t135, i32 %t136)
  store { i64, ptr } %t139, ptr %l108
  br label %bb33
bb33:
  %t140 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t140, ptr %l10, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb34, label %bb35
bb34:
  store i64 0, ptr %l11, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  store i64 %t149, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l11, !tbaa !24
  %t155 = icmp sgt i64 %t151, %t152
  br i1 %t155, label %bb36, label %bb37
bb35:
  br label %bb51
bb36:
  %t157 = load i64, ptr %l13, !tbaa !24
  %t159 = icmp sgt i64 %t157, 0
  br i1 %t159, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb41
bb38:
  %t161 = load i64, ptr %l12, !tbaa !24
  %t162 = load i64, ptr %l11, !tbaa !24
  %t165 = sub i64 %t161, %t162
  %t166 = load i64, ptr %l13, !tbaa !24
  %t169 = add i64 %t165, %t166
  %t171 = sub i64 %t169, 1
  %t172 = load i64, ptr %l13, !tbaa !24
  %t175 = sdiv i64 %t171, %t172
  store i64 %t175, ptr %l120, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb40
bb40:
  %t177 = load i64, ptr %l120, !tbaa !24
  store i64 %t177, ptr %l117, !tbaa !24
  br label %bb41
bb41:
  %t178 = load i64, ptr %l117, !tbaa !24
  store i64 %t178, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s5
  %t179 = load i64, ptr %l15, !tbaa !24
  %t180 = load i64, ptr %l14, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb44:
  br label %bb45
bb45:
  %t187 = load i64, ptr %l11, !tbaa !24
  %t188 = load i64, ptr %l15, !tbaa !24
  %t189 = load i64, ptr %l13, !tbaa !24
  %t192 = mul i64 %t188, %t189
  %t195 = add i64 %t187, %t192
  store i64 %t195, ptr %l16, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t197, ptr %l138, !tbaa !27
  %t198 = load i64, ptr %l16, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr i32, ptr %t201, i64 %t198
  %t203 = load i32, ptr %t202, !tbaa !33
  %t204 = load i32, ptr %l4, !tbaa !23
  %t207 = icmp eq i32 %t203, %t204
  br i1 %t207, label %bb46, label %bb47
bb46:
  %t209 = load i64, ptr %l16, !tbaa !24
  store i64 %t209, ptr %l9, !tbaa !24
  br label %bb48
bb47:
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb49:
  %t211 = load i64, ptr %l15, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l15, !tbaa !24
  br label %bb42
bb50:
  br label %bb51
bb51:
  %t215 = load i64, ptr %l9, !tbaa !24
  %t217 = icmp slt i64 %t215, 0
  br i1 %t217, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s8
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l148, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t220, ptr %l149
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l8, !tbaa !23
  %t223 = load i32, ptr %l4, !tbaa !23
  %t227 = call %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %s8, ptr %t221, i32 %t222, i32 %t223)
  store %"compiler/msgs:Msg" %t227, ptr %l153
  br label %bb54
bb53:
  br label %bb58
bb54:
  %t228 = load ptr, ptr %l148, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l149
  %t230 = load %"compiler/msgs:Msg", ptr %l153
  %t231 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t228, %"compiler/source:Span" %t229, %"compiler/msgs:Msg" %t230)
  store i64 %t231, ptr %l154
  br label %bb55
bb55:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t232, { i64, ptr } %t233)
  br label %bb56
bb56:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load %"compiler/source:Span", ptr %l1
  %t240 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t236, %"compiler/source:Span" %t237)
  store ptr %t240, ptr %l159
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t241 = load ptr, ptr %l159, !tbaa !29
  store ptr %t241, ptr %rv
  br label %ret
bb58:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/check:Checker", ptr %t242, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t246 = load i32, ptr %l8, !tbaa !23
  %t247 = load i64, ptr %l9, !tbaa !24
  %t251 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t245, i32 %t246, i64 %t247)
  store i32 %t251, ptr %l164
  br label %bb59
bb59:
  %t252 = load i32, ptr %l164, !tbaa !23
  store i32 %t252, ptr %l17, !tbaa !23
  %t253 = load i32, ptr %l17, !tbaa !23
  %t254 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t257 = icmp eq i32 %t253, %t254
  br i1 %t257, label %bb60, label %bb61
bb60:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l1
  %t263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t259, %"compiler/source:Span" %t260)
  store ptr %t263, ptr %l170
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_scope_close(ptr %s0)
  %t264 = load ptr, ptr %l170, !tbaa !29
  store ptr %t264, ptr %rv
  br label %ret
bb63:
  %t265 = load i32, ptr %l3, !tbaa !23
  %t267 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t265)
  store i64 %t267, ptr %l172
  br label %bb64
bb64:
  %t268 = load i64, ptr %l172, !tbaa !24
  store i64 %t268, ptr %l18, !tbaa !24
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t269, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = getelementptr %"compiler/generic:Program", ptr %t272, i32 0, i32 2
  %t275 = load i32, ptr %l3, !tbaa !23
  %t278 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t274, i32 %t275)
  store i64 %t278, ptr %l177
  br label %bb65
bb65:
  %t279 = load i64, ptr %l177, !tbaa !24
  store i64 %t279, ptr %l19, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t285 = getelementptr %"compiler/generic:Program", ptr %t283, i32 0, i32 2
  store ptr %t285, ptr %l180, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/check:Checker", ptr %t286, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !29
  %t291 = getelementptr %"compiler/generic:Program", ptr %t289, i32 0, i32 2
  %t292 = load i32, ptr %l17, !tbaa !23
  %t295 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t291, i32 %t292)
  store i32 %t295, ptr %l185
  br label %bb66
bb66:
  %t296 = load ptr, ptr %l180, !tbaa !29
  %t297 = load i32, ptr %l185, !tbaa !23
  %t298 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t296, i32 %t297)
  store { i64, ptr } %t298, ptr %l186
  br label %bb67
bb67:
  %t299 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t299, ptr %l20, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t308 = icmp ne i64 %t302, %t305
  br i1 %t308, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s10
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l192, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t311, ptr %l193
  %t312 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t312, 0
  store i64 %t314, ptr %l195, !tbaa !24
  %t315 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t319 = icmp eq i64 %t317, 1
  br i1 %t319, label %bb70, label %bb71
bb69:
  br label %bb77
bb70:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l199, !tbaa !27
  br label %bb72
bb71:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l199, !tbaa !27
  br label %bb72
bb72:
  %t321 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = load i64, ptr %l195, !tbaa !24
  %t325 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t327 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s10, ptr %s10, i64 %t324, { i64, ptr } %t325, i64 %t323)
  store %"compiler/msgs:Msg" %t327, ptr %l202
  br label %bb73
bb73:
  %t328 = load ptr, ptr %l192, !tbaa !29
  %t329 = load %"compiler/source:Span", ptr %l193
  %t330 = load %"compiler/msgs:Msg", ptr %l202
  %t331 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t328, %"compiler/source:Span" %t329, %"compiler/msgs:Msg" %t330)
  store i64 %t331, ptr %l203
  br label %bb74
bb74:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t332, { i64, ptr } %t333)
  br label %bb75
bb75:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l1
  %t340 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t336, %"compiler/source:Span" %t337)
  store ptr %t340, ptr %l208
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t341 = load ptr, ptr %l208, !tbaa !29
  store ptr %t341, ptr %rv
  br label %ret
bb77:
  %t342 = load i64, ptr %l18, !tbaa !24
  %t343 = load i64, ptr %l19, !tbaa !24
  %t346 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t342, i64 %t343)
  store %"compiler/generic:Binding" %t346, ptr %l211
  br label %bb78
bb78:
  %t347 = load %"compiler/generic:Binding", ptr %l211
  store %"compiler/generic:Binding" %t347, ptr %l21
  %t348 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t348, ptr %l212
  br label %bb79
bb79:
  %t349 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t349, ptr %lp22
  %t350 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l212
  %t351 = load ptr, ptr %lp22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t350, ptr %t351
  store i64 0, ptr %l23, !tbaa !24
  %t352 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t352, 0
  store i64 %t354, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t356 = load i64, ptr %l24, !tbaa !24
  %t357 = load i64, ptr %l23, !tbaa !24
  %t360 = icmp sgt i64 %t356, %t357
  br i1 %t360, label %bb80, label %bb81
bb80:
  %t362 = load i64, ptr %l25, !tbaa !24
  %t364 = icmp sgt i64 %t362, 0
  br i1 %t364, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l218, !tbaa !24
  br label %bb85
bb82:
  %t366 = load i64, ptr %l24, !tbaa !24
  %t367 = load i64, ptr %l23, !tbaa !24
  %t370 = sub i64 %t366, %t367
  %t371 = load i64, ptr %l25, !tbaa !24
  %t374 = add i64 %t370, %t371
  %t376 = sub i64 %t374, 1
  %t377 = load i64, ptr %l25, !tbaa !24
  %t380 = sdiv i64 %t376, %t377
  store i64 %t380, ptr %l221, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l221, !tbaa !24
  br label %bb84
bb84:
  %t382 = load i64, ptr %l221, !tbaa !24
  store i64 %t382, ptr %l218, !tbaa !24
  br label %bb85
bb85:
  %t383 = load i64, ptr %l218, !tbaa !24
  store i64 %t383, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s12
  %t384 = load i64, ptr %l27, !tbaa !24
  %t385 = load i64, ptr %l26, !tbaa !24
  %t388 = icmp slt i64 %t384, %t385
  %t390 = xor i1 %t388, true
  br i1 %t390, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s12)
  br label %bb139
bb88:
  br label %bb89
bb89:
  %t392 = load i64, ptr %l23, !tbaa !24
  %t393 = load i64, ptr %l27, !tbaa !24
  %t394 = load i64, ptr %l25, !tbaa !24
  %t397 = mul i64 %t393, %t394
  %t400 = add i64 %t392, %t397
  store i64 %t400, ptr %l28, !tbaa !24
  store ptr null, ptr %l29, !tbaa !29
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t403, ptr %l240, !tbaa !27
  %t404 = load i64, ptr %l28, !tbaa !24
  %t406 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !27
  %t408 = getelementptr ptr, ptr %t407, i64 %t404
  %t409 = load ptr, ptr %t408, !tbaa !39
  %t413 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t402, ptr %t409)
  store %"compiler/check:litv" %t413, ptr %l244
  br label %bb90
bb90:
  %t414 = load %"compiler/check:litv", ptr %l244
  store %"compiler/check:litv" %t414, ptr %l30
  %t415 = getelementptr %"compiler/check:litv", ptr %l30, i32 0, i32 0
  %t416 = load i1, ptr %t415, !tbaa !21
  br i1 %t416, label %bb91, label %bb92
bb91:
  store i1 true, ptr %l246, !tbaa !21
  br label %bb94
bb92:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t419, ptr %l248, !tbaa !27
  %t420 = load i64, ptr %l28, !tbaa !24
  %t422 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr ptr, ptr %t423, i64 %t420
  %t425 = load ptr, ptr %t424, !tbaa !39
  %t428 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t418, ptr %t425)
  store i1 %t428, ptr %l251
  br label %bb93
bb93:
  %t429 = load i1, ptr %l251, !tbaa !21
  store i1 %t429, ptr %l246, !tbaa !21
  br label %bb94
bb94:
  %t430 = load i1, ptr %l246, !tbaa !21
  br i1 %t430, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s13
  %t431 = getelementptr %"compiler/check:litv", ptr %l30, i32 0, i32 0
  %t432 = load i1, ptr %t431, !tbaa !21
  br i1 %t432, label %bb97, label %bb98
bb96:
  %t434 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t434, ptr %l273, !tbaa !27
  %t435 = load i64, ptr %l28, !tbaa !24
  %t437 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr ptr, ptr %t438, i64 %t435
  %t440 = load ptr, ptr %t439, !tbaa !39
  store ptr %t440, ptr %l32, !tbaa !29
  %t442 = load ptr, ptr %l32, !tbaa !29
  store ptr %t442, ptr %l276, !tbaa !29
  store i1 false, ptr %l277, !tbaa !21
  %t443 = load ptr, ptr %l276, !tbaa !29
  %t444 = icmp ne ptr %t443, null
  br i1 %t444, label %bb107, label %bb108
bb97:
  %t446 = getelementptr %"compiler/check:litv", ptr %l30, i32 0, i32 1
  %t447 = load i1, ptr %t446, !tbaa !21
  store i1 %t447, ptr %l253, !tbaa !21
  br label %bb100
bb98:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t450 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t450, ptr %l256, !tbaa !27
  %t451 = load i64, ptr %l28, !tbaa !24
  %t453 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !27
  %t455 = getelementptr ptr, ptr %t454, i64 %t451
  %t456 = load ptr, ptr %t455, !tbaa !39
  %t459 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %t449, ptr %t456)
  store i1 %t459, ptr %l259
  br label %bb99
bb99:
  %t460 = load i1, ptr %l259, !tbaa !21
  store i1 %t460, ptr %l253, !tbaa !21
  br label %bb100
bb100:
  %t461 = load i1, ptr %l253, !tbaa !21
  %t462 = load ptr, ptr %l0, !tbaa !29
  store ptr %t462, ptr %l260, !tbaa !29
  %t463 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t463, ptr %l261, !tbaa !27
  %t464 = load i64, ptr %l28, !tbaa !24
  %t466 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t467 = load ptr, ptr %t466, !tbaa !27
  %t468 = getelementptr i32, ptr %t467, i64 %t464
  %t469 = load i32, ptr %t468, !tbaa !33
  store i32 %t469, ptr %l263, !tbaa !23
  br i1 %t461, label %bb101, label %bb102
bb101:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/check:Checker", ptr %t472, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t477 = getelementptr %"compiler/generic:Program", ptr %t475, i32 0, i32 2
  %t479 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s13, ptr %t477, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i32 %t479, ptr %l269
  br label %bb103
bb102:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t480)
  store i32 %t482, ptr %l271
  br label %bb104
bb103:
  %t483 = load i32, ptr %l269, !tbaa !23
  store i32 %t483, ptr %l265, !tbaa !23
  br label %bb105
bb104:
  %t484 = load i32, ptr %l271, !tbaa !23
  store i32 %t484, ptr %l265, !tbaa !23
  br label %bb105
bb105:
  %t485 = load ptr, ptr %l260, !tbaa !29
  %t486 = load i32, ptr %l263, !tbaa !23
  %t487 = load i32, ptr %l265, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t485, i32 %t486, i32 %t487, ptr %l21, i1 true, i1 false)
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s13)
  br label %bb119
bb107:
  %t489 = load ptr, ptr %l276, !tbaa !29
  %t490 = load i64, ptr %t489
  %t492 = icmp eq i64 %t490, 23
  store i1 %t492, ptr %l277, !tbaa !21
  br label %bb108
bb108:
  %t493 = load i1, ptr %l277, !tbaa !21
  br i1 %t493, label %bb109, label %bb110
bb109:
  br label %bb115
bb110:
  %t494 = load ptr, ptr %l32, !tbaa !29
  store ptr %t494, ptr %l280, !tbaa !29
  store i1 false, ptr %l281, !tbaa !21
  %t495 = load ptr, ptr %l280, !tbaa !29
  %t496 = icmp ne ptr %t495, null
  br i1 %t496, label %bb111, label %bb112
bb111:
  %t498 = load ptr, ptr %l280, !tbaa !29
  %t499 = load i64, ptr %t498
  %t501 = icmp eq i64 %t499, 26
  store i1 %t501, ptr %l281, !tbaa !21
  br label %bb112
bb112:
  %t502 = load i1, ptr %l281, !tbaa !21
  br i1 %t502, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t504, ptr %l285, !tbaa !27
  %t505 = load i64, ptr %l28, !tbaa !24
  %t507 = getelementptr { i64, ptr }, ptr %l285, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !27
  %t509 = getelementptr ptr, ptr %t508, i64 %t505
  %t510 = load ptr, ptr %t509, !tbaa !39
  %t512 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t516 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t503, ptr %t510, i32 %t512)
  store ptr %t516, ptr %l290
  br label %bb117
bb117:
  %t517 = load ptr, ptr %l290, !tbaa !29
  store ptr %t517, ptr %l29, !tbaa !29
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t519 = load ptr, ptr %l29, !tbaa !29
  %t521 = icmp eq ptr %t519, null
  %t523 = xor i1 %t521, true
  br i1 %t523, label %bb120, label %bb121
bb120:
  %t525 = load ptr, ptr %l29, !tbaa !29
  %t528 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t525)
  store i32 %t528, ptr %l298
  br label %bb122
bb121:
  store i1 false, ptr %l295, !tbaa !21
  br label %bb123
bb122:
  %t529 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t530 = load i32, ptr %l298, !tbaa !23
  %t532 = icmp ne i32 %t530, %t529
  store i1 %t532, ptr %l295, !tbaa !21
  br label %bb123
bb123:
  %t534 = load i1, ptr %l295, !tbaa !21
  br i1 %t534, label %bb124, label %bb125
bb124:
  %t535 = load ptr, ptr %l29, !tbaa !29
  %t538 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t535)
  store i32 %t538, ptr %l304
  br label %bb126
bb125:
  store i1 false, ptr %l301, !tbaa !21
  br label %bb127
bb126:
  %t539 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t540 = load i32, ptr %l304, !tbaa !23
  %t542 = icmp ne i32 %t540, %t539
  store i1 %t542, ptr %l301, !tbaa !21
  br label %bb127
bb127:
  %t544 = load i1, ptr %l301, !tbaa !21
  br i1 %t544, label %bb128, label %bb129
bb128:
  %t545 = load ptr, ptr %l0, !tbaa !29
  store ptr %t545, ptr %l307, !tbaa !29
  %t546 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t546, ptr %l308, !tbaa !27
  %t547 = load i64, ptr %l28, !tbaa !24
  %t549 = getelementptr { i64, ptr }, ptr %l308, i32 0, i32 1
  %t550 = load ptr, ptr %t549, !tbaa !27
  %t551 = getelementptr i32, ptr %t550, i64 %t547
  %t552 = load i32, ptr %t551, !tbaa !33
  store i32 %t552, ptr %l310, !tbaa !23
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load ptr, ptr %l29, !tbaa !29
  %t557 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v0, ptr %t553, ptr %t554)
  store i32 %t557, ptr %l313
  br label %bb130
bb129:
  br label %bb132
bb130:
  %t558 = load ptr, ptr %l307, !tbaa !29
  %t559 = load i32, ptr %l310, !tbaa !23
  %t560 = load i32, ptr %l313, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t558, i32 %t559, i32 %t560, ptr %l21, i1 false, i1 false)
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t562 = load ptr, ptr %l29, !tbaa !29
  %t564 = icmp eq ptr %t562, null
  br i1 %t564, label %bb133, label %bb134
bb133:
  %t566 = load ptr, ptr %lp22
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t569 = getelementptr %"compiler/check:Checker", ptr %t567, i32 0, i32 0
  %t570 = load ptr, ptr %t569, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t566, ptr %t570)
  br label %bb135
bb134:
  %t573 = load ptr, ptr %lp22
  %t574 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t573, ptr %t574)
  br label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s12)
  br label %bb138
bb138:
  %t577 = load i64, ptr %l27, !tbaa !24
  %t579 = add i64 %t577, 1
  store i64 %t579, ptr %l27, !tbaa !24
  br label %bb86
bb139:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = getelementptr %"compiler/check:Checker", ptr %t581, i32 0, i32 1
  %t584 = load ptr, ptr %t583, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t584, ptr %l21)
  br label %bb140
bb140:
  store i64 0, ptr %l33, !tbaa !24
  %t587 = load i64, ptr %l19, !tbaa !24
  store i64 %t587, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t589 = load i64, ptr %l34, !tbaa !24
  %t590 = load i64, ptr %l33, !tbaa !24
  %t593 = icmp sgt i64 %t589, %t590
  br i1 %t593, label %bb141, label %bb142
bb141:
  %t595 = load i64, ptr %l35, !tbaa !24
  %t597 = icmp sgt i64 %t595, 0
  br i1 %t597, label %bb143, label %bb144
bb142:
  store i64 0, ptr %l331, !tbaa !24
  br label %bb146
bb143:
  %t599 = load i64, ptr %l34, !tbaa !24
  %t600 = load i64, ptr %l33, !tbaa !24
  %t603 = sub i64 %t599, %t600
  %t604 = load i64, ptr %l35, !tbaa !24
  %t607 = add i64 %t603, %t604
  %t609 = sub i64 %t607, 1
  %t610 = load i64, ptr %l35, !tbaa !24
  %t613 = sdiv i64 %t609, %t610
  store i64 %t613, ptr %l334, !tbaa !24
  br label %bb145
bb144:
  store i64 0, ptr %l334, !tbaa !24
  br label %bb145
bb145:
  %t615 = load i64, ptr %l334, !tbaa !24
  store i64 %t615, ptr %l331, !tbaa !24
  br label %bb146
bb146:
  %t616 = load i64, ptr %l331, !tbaa !24
  store i64 %t616, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb147
bb147:
  store %olang.scope zeroinitializer, ptr %s22
  %t617 = load i64, ptr %l37, !tbaa !24
  %t618 = load i64, ptr %l36, !tbaa !24
  %t621 = icmp slt i64 %t617, %t618
  %t623 = xor i1 %t621, true
  br i1 %t623, label %bb148, label %bb149
bb148:
  call void @__olang_scope_close(ptr %s22)
  br label %bb181
bb149:
  br label %bb150
bb150:
  %t625 = load i64, ptr %l33, !tbaa !24
  %t626 = load i64, ptr %l37, !tbaa !24
  %t627 = load i64, ptr %l35, !tbaa !24
  %t630 = mul i64 %t626, %t627
  %t633 = add i64 %t625, %t630
  store i64 %t633, ptr %l38, !tbaa !24
  %t635 = getelementptr %"compiler/generic:Binding", ptr %l21, i32 0, i32 2
  %t636 = load { i64, ptr }, ptr %t635, !tbaa !27
  store { i64, ptr } %t636, ptr %l352, !tbaa !27
  %t637 = load i64, ptr %l38, !tbaa !24
  %t639 = getelementptr { i64, ptr }, ptr %l352, i32 0, i32 1
  %t640 = load ptr, ptr %t639, !tbaa !27
  %t641 = getelementptr i32, ptr %t640, i64 %t637
  %t642 = load i32, ptr %t641, !tbaa !33
  store i32 %t642, ptr %l39, !tbaa !23
  %t644 = load i32, ptr %l39, !tbaa !23
  %t645 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t648 = icmp eq i32 %t644, %t645
  br i1 %t648, label %bb151, label %bb152
bb151:
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t652 = getelementptr %"compiler/check:Checker", ptr %t650, i32 0, i32 1
  %t653 = load ptr, ptr %t652, !tbaa !29
  %t654 = load i64, ptr %l18, !tbaa !24
  %t655 = load i64, ptr %l38, !tbaa !24
  %t659 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %t653, i64 %t654, i64 %t655)
  store i1 %t659, ptr %l363
  br label %bb153
bb152:
  store i1 false, ptr %l358, !tbaa !21
  br label %bb154
bb153:
  %t660 = load i1, ptr %l363, !tbaa !21
  store i1 %t660, ptr %l358, !tbaa !21
  br label %bb154
bb154:
  %t661 = load i1, ptr %l358, !tbaa !21
  br i1 %t661, label %bb155, label %bb156
bb155:
  %t662 = getelementptr %"compiler/generic:Binding", ptr %l21, i32 0, i32 2
  %t663 = load { i64, ptr }, ptr %t662, !tbaa !27
  store { i64, ptr } %t663, ptr %l364, !tbaa !27
  %t664 = load i64, ptr %l38, !tbaa !24
  store i64 %t664, ptr %l365, !tbaa !24
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t667 = getelementptr %"compiler/check:Checker", ptr %t665, i32 0, i32 1
  %t668 = load ptr, ptr %t667, !tbaa !29
  %t670 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t668, i32 0)
  store i32 %t670, ptr %l368
  br label %bb157
bb156:
  br label %bb158
bb157:
  %t671 = load i32, ptr %l368, !tbaa !23
  %t672 = load i64, ptr %l365, !tbaa !24
  %t673 = getelementptr { i64, ptr }, ptr %l364, i32 0, i32 1
  %t674 = load ptr, ptr %t673, !tbaa !27
  %t675 = getelementptr i32, ptr %t674, i64 %t672
  store i32 %t671, ptr %t675, !tbaa !33
  call void @__olang_scope_close(ptr %s22)
  br label %bb180
bb158:
  %t676 = load i32, ptr %l39, !tbaa !23
  %t677 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t680 = icmp eq i32 %t676, %t677
  br i1 %t680, label %bb159, label %bb160
bb159:
  store %olang.scope zeroinitializer, ptr %s24
  %t682 = load ptr, ptr %l0, !tbaa !29
  store ptr %t682, ptr %l372, !tbaa !29
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t685 = getelementptr %"compiler/check:Checker", ptr %t683, i32 0, i32 1
  %t686 = load ptr, ptr %t685, !tbaa !29
  %t688 = getelementptr %"compiler/generic:Program", ptr %t686, i32 0, i32 2
  %t689 = load i32, ptr %l3, !tbaa !23
  %t692 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t688, i32 %t689)
  store i32 %t692, ptr %l377
  br label %bb161
bb160:
  br label %bb167
bb161:
  %t693 = load ptr, ptr %l372, !tbaa !29
  %t694 = load i32, ptr %l377, !tbaa !23
  %t695 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t693, i32 %t694)
  store { i64, ptr } %t695, ptr %l378
  br label %bb162
bb162:
  %t696 = load { i64, ptr }, ptr %l378, !tbaa !27
  store { i64, ptr } %t696, ptr %l40, !tbaa !27
  %t697 = load ptr, ptr %l0, !tbaa !29
  store ptr %t697, ptr %l379, !tbaa !29
  %t698 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t698, ptr %l380
  %t699 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t699, ptr %l381, !tbaa !27
  %t700 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t700, ptr %l382, !tbaa !27
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t702 = load i32, ptr %l4, !tbaa !23
  %t705 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t701, i32 %t702)
  store { i64, ptr } %t705, ptr %l385
  br label %bb163
bb163:
  %t706 = load { i64, ptr }, ptr %l382, !tbaa !27
  %t707 = extractvalue { i64, ptr } %t706, 1
  %t708 = extractvalue { i64, ptr } %t706, 0
  %t709 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t710 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t711 = add i64 %t708, %t710
  %t712 = load { i64, ptr }, ptr %l385, !tbaa !27
  %t713 = extractvalue { i64, ptr } %t712, 1
  %t714 = extractvalue { i64, ptr } %t712, 0
  %t715 = add i64 %t711, %t714
  %t716 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t715)
  call void @olang_textcopy(ptr %t716, ptr %t707, i64 %t708)
  %t717 = getelementptr i8, ptr %t716, i64 %t708
  call void @olang_textcopy(ptr %t717, ptr %t709, i64 %t710)
  %t718 = getelementptr i8, ptr %t717, i64 %t710
  call void @olang_textcopy(ptr %t718, ptr %t713, i64 %t714)
  %t719 = insertvalue { i64, ptr } undef, i64 %t715, 0
  %t720 = insertvalue { i64, ptr } %t719, ptr %t716, 1
  %t722 = extractvalue { i64, ptr } %t720, 0
  %t723 = extractvalue { i64, ptr } %t720, 1
  %t724 = mul i64 %t722, 1
  %t725 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t724)
  call void @llvm.memcpy.p0.p0.i64(ptr %t725, ptr %t723, i64 %t724, i1 false)
  %t726 = insertvalue { i64, ptr } undef, i64 %t722, 0
  %t727 = insertvalue { i64, ptr } %t726, ptr %t725, 1
  %t728 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t730 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTypeArgsNotInferable(ptr %v0, ptr %s24, ptr %s24, { i64, ptr } %t728, { i64, ptr } %t727)
  store %"compiler/msgs:Msg" %t730, ptr %l388
  br label %bb164
bb164:
  %t731 = load ptr, ptr %l379, !tbaa !29
  %t732 = load %"compiler/source:Span", ptr %l380
  %t733 = load %"compiler/msgs:Msg", ptr %l388
  %t734 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s24, ptr %t731, %"compiler/source:Span" %t732, %"compiler/msgs:Msg" %t733)
  store i64 %t734, ptr %l389
  br label %bb165
bb165:
  %t735 = load ptr, ptr %l0, !tbaa !29
  %t736 = load %"compiler/source:Span", ptr %l1
  %t739 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t735, %"compiler/source:Span" %t736)
  store ptr %t739, ptr %l392
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  %t740 = load ptr, ptr %l392, !tbaa !29
  store ptr %t740, ptr %rv
  br label %ret
bb167:
  %t741 = load ptr, ptr %l0, !tbaa !29
  %t742 = load i32, ptr %l39, !tbaa !23
  %t745 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t741, i32 %t742)
  store i1 %t745, ptr %l395
  br label %bb168
bb168:
  %t746 = load i1, ptr %l395, !tbaa !21
  br i1 %t746, label %bb169, label %bb170
bb169:
  %t747 = getelementptr %"compiler/generic:Binding", ptr %l21, i32 0, i32 2
  %t748 = load { i64, ptr }, ptr %t747, !tbaa !27
  store { i64, ptr } %t748, ptr %l396, !tbaa !27
  %t749 = load i64, ptr %l38, !tbaa !24
  store i64 %t749, ptr %l397, !tbaa !24
  %t750 = load ptr, ptr %l0, !tbaa !29
  %t752 = getelementptr %"compiler/check:Checker", ptr %t750, i32 0, i32 1
  %t753 = load ptr, ptr %t752, !tbaa !29
  %t755 = getelementptr %"compiler/generic:Program", ptr %t753, i32 0, i32 2
  store ptr %t755, ptr %l400, !tbaa !29
  %t756 = load ptr, ptr %l0, !tbaa !29
  %t758 = getelementptr %"compiler/check:Checker", ptr %t756, i32 0, i32 1
  %t759 = load ptr, ptr %t758, !tbaa !29
  %t761 = getelementptr %"compiler/generic:Program", ptr %t759, i32 0, i32 2
  %t762 = load i32, ptr %l39, !tbaa !23
  %t765 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t761, i32 %t762)
  store i32 %t765, ptr %l405
  br label %bb171
bb170:
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t768 = getelementptr %"compiler/check:Checker", ptr %t766, i32 0, i32 1
  %t769 = load ptr, ptr %t768, !tbaa !29
  %t771 = getelementptr %"compiler/generic:Program", ptr %t769, i32 0, i32 2
  store ptr %t771, ptr %l410, !tbaa !29
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t773 = load i32, ptr %l39, !tbaa !23
  %t776 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t772, i32 %t773)
  store i32 %t776, ptr %l413
  br label %bb173
bb171:
  %t777 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t778 = load ptr, ptr %l400, !tbaa !29
  %t779 = load i32, ptr %l405, !tbaa !23
  %t781 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t778, i32 %t779, i64 %t777)
  store i32 %t781, ptr %l407
  br label %bb172
bb172:
  %t782 = load i32, ptr %l407, !tbaa !23
  %t783 = load i64, ptr %l397, !tbaa !24
  %t784 = getelementptr { i64, ptr }, ptr %l396, i32 0, i32 1
  %t785 = load ptr, ptr %t784, !tbaa !27
  %t786 = getelementptr i32, ptr %t785, i64 %t783
  store i32 %t782, ptr %t786, !tbaa !33
  br label %bb179
bb173:
  %t787 = load ptr, ptr %l410, !tbaa !29
  %t788 = load i32, ptr %l413, !tbaa !23
  %t789 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t787, i32 %t788)
  store i32 %t789, ptr %l414
  br label %bb174
bb174:
  %t790 = load i32, ptr %l414
  %t792 = trunc i64 19 to i32
  %t793 = icmp eq i32 %t790, %t792
  br i1 %t793, label %bb175, label %bb176
bb175:
  %t795 = getelementptr %"compiler/generic:Binding", ptr %l21, i32 0, i32 2
  %t796 = load { i64, ptr }, ptr %t795, !tbaa !27
  store { i64, ptr } %t796, ptr %l417, !tbaa !27
  %t797 = load i64, ptr %l38, !tbaa !24
  store i64 %t797, ptr %l418, !tbaa !24
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t800 = getelementptr %"compiler/check:Checker", ptr %t798, i32 0, i32 1
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t803 = getelementptr %"compiler/generic:Program", ptr %t801, i32 0, i32 2
  %t804 = load i32, ptr %l39, !tbaa !23
  %t805 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t809 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t803, i32 %t804, i64 %t805)
  store i32 %t809, ptr %l424
  br label %bb177
bb176:
  br label %bb178
bb177:
  %t810 = load i32, ptr %l424, !tbaa !23
  %t811 = load i64, ptr %l418, !tbaa !24
  %t812 = getelementptr { i64, ptr }, ptr %l417, i32 0, i32 1
  %t813 = load ptr, ptr %t812, !tbaa !27
  %t814 = getelementptr i32, ptr %t813, i64 %t811
  store i32 %t810, ptr %t814, !tbaa !33
  br label %bb178
bb178:
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s22)
  br label %bb180
bb180:
  %t815 = load i64, ptr %l37, !tbaa !24
  %t817 = add i64 %t815, 1
  store i64 %t817, ptr %l37, !tbaa !24
  br label %bb147
bb181:
  %t819 = load ptr, ptr %l0, !tbaa !29
  %t821 = getelementptr %"compiler/check:Checker", ptr %t819, i32 0, i32 1
  %t822 = load ptr, ptr %t821, !tbaa !29
  store ptr %t822, ptr %l428, !tbaa !29
  %t823 = load i32, ptr %l3, !tbaa !23
  store i32 %t823, ptr %l429, !tbaa !23
  %t824 = load ptr, ptr %l0, !tbaa !29
  %t826 = getelementptr %"compiler/check:Checker", ptr %t824, i32 0, i32 1
  %t827 = load ptr, ptr %t826, !tbaa !29
  %t829 = getelementptr %"compiler/generic:Program", ptr %t827, i32 0, i32 2
  %t830 = getelementptr %"compiler/generic:Binding", ptr %l21, i32 0, i32 2
  %t831 = load { i64, ptr }, ptr %t830, !tbaa !27
  %t834 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t829, { i64, ptr } %t831)
  store i32 %t834, ptr %l434
  br label %bb182
bb182:
  %t835 = load ptr, ptr %l428, !tbaa !29
  %t836 = load i32, ptr %l429, !tbaa !23
  %t837 = load i32, ptr %l434, !tbaa !23
  %t838 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t835, i32 %t836, i32 %t837)
  store i32 %t838, ptr %l435
  br label %bb183
bb183:
  %t839 = load i32, ptr %l435, !tbaa !23
  store i32 %t839, ptr %l41, !tbaa !23
  %t840 = load ptr, ptr %l0, !tbaa !29
  %t841 = load i32, ptr %l41, !tbaa !23
  %t842 = load %"compiler/source:Span", ptr %l2
  %t846 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t840, i32 %t841, %"compiler/source:Span" %t842)
  store i1 %t846, ptr %l439
  br label %bb184
bb184:
  %t847 = load i1, ptr %l439, !tbaa !21
  %t848 = xor i1 %t847, true
  br i1 %t848, label %bb185, label %bb186
bb185:
  store i1 true, ptr %l441, !tbaa !21
  br label %bb188
bb186:
  %t850 = load ptr, ptr %l0, !tbaa !29
  %t852 = getelementptr %"compiler/check:Checker", ptr %t850, i32 0, i32 1
  %t853 = load ptr, ptr %t852, !tbaa !29
  %t854 = load i32, ptr %l41, !tbaa !23
  %t857 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t853, i32 %t854)
  store i1 %t857, ptr %l445
  br label %bb187
bb187:
  %t858 = load i1, ptr %l445, !tbaa !21
  %t859 = xor i1 %t858, true
  store i1 %t859, ptr %l441, !tbaa !21
  br label %bb188
bb188:
  %t861 = load i1, ptr %l441, !tbaa !21
  br i1 %t861, label %bb189, label %bb190
bb189:
  %t862 = load ptr, ptr %l0, !tbaa !29
  %t863 = load %"compiler/source:Span", ptr %l1
  %t866 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t862, %"compiler/source:Span" %t863)
  store ptr %t866, ptr %l449
  br label %bb191
bb190:
  br label %bb192
bb191:
  call void @__olang_scope_close(ptr %s0)
  %t867 = load ptr, ptr %l449, !tbaa !29
  store ptr %t867, ptr %rv
  br label %ret
bb192:
  %t868 = load ptr, ptr %l0, !tbaa !29
  store ptr %t868, ptr %l450, !tbaa !29
  %t869 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t869, ptr %l451
  %t870 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t870, ptr %l452
  %t871 = load i32, ptr %l41, !tbaa !23
  store i32 %t871, ptr %l453, !tbaa !23
  %t872 = load i32, ptr %l4, !tbaa !23
  store i32 %t872, ptr %l454, !tbaa !23
  %t873 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t873, ptr %l455, !tbaa !27
  %t874 = load ptr, ptr %lp22
  %t876 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eToA_H3b732fb6bb2c20fd2f0446a621d56c2c(ptr %v0, ptr %v0, ptr %t874)
  store { i64, ptr } %t876, ptr %l457
  br label %bb193
bb193:
  %t877 = load ptr, ptr %l450, !tbaa !29
  %t878 = load %"compiler/source:Span", ptr %l451
  %t879 = load %"compiler/source:Span", ptr %l452
  %t880 = load i32, ptr %l453, !tbaa !23
  %t881 = load i32, ptr %l454, !tbaa !23
  %t882 = load { i64, ptr }, ptr %l455, !tbaa !27
  %t883 = load { i64, ptr }, ptr %l457, !tbaa !27
  %t884 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v0, ptr %t877, %"compiler/source:Span" %t878, %"compiler/source:Span" %t879, i32 %t880, i32 %t881, { i64, ptr } %t882, { i64, ptr } %t883)
  store ptr %t884, ptr %l458
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s0)
  %t885 = load ptr, ptr %l458, !tbaa !29
  store ptr %t885, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca ptr
  %rv = alloca ptr
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr ptr, ptr %t13, i64 %t10
  %t15 = load ptr, ptr %t14, !tbaa !39
  store ptr %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a0, ptr %l11, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t24)
  store %"compiler/source:Span" %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l11, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l15
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t32, %"compiler/source:Span" %t33, i64 %t34)
  store ptr %t35, ptr %l19
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l19, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, i64 }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca { i64, i64 }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, i64, i64 }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca ptr
  %l45 = alloca ptr
  %l51 = alloca i64
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca ptr
  %l61 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l71 = alloca ptr
  %l75 = alloca i32
  %l79 = alloca %"compiler/typed:Block"
  %l85 = alloca ptr
  %l86 = alloca i1
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca ptr
  %l103 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l117 = alloca ptr
  %l123 = alloca ptr
  %l125 = alloca i64
  %l131 = alloca %"compiler/source:Span"
  %l134 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l138 = alloca i1
  %l139 = alloca i1
  %l143 = alloca i1
  %l144 = alloca i32
  %l153 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l165 = alloca ptr
  %l171 = alloca ptr
  %l182 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l195 = alloca ptr
  %l199 = alloca i32
  %l203 = alloca %"compiler/typed:Block"
  %l209 = alloca ptr
  %l210 = alloca i1
  %l218 = alloca i1
  %l227 = alloca ptr
  %l235 = alloca ptr
  %l236 = alloca %"compiler/source:Span"
  %l242 = alloca ptr
  %l246 = alloca i1
  %l247 = alloca i1
  %l253 = alloca i1
  %l259 = alloca i1
  %l268 = alloca i1
  %l269 = alloca ptr
  %l277 = alloca i1
  %l278 = alloca ptr
  %l280 = alloca ptr
  %l282 = alloca i64
  %l288 = alloca i64
  %l292 = alloca ptr
  %l293 = alloca i64
  %l295 = alloca ptr
  %l297 = alloca i64
  %l303 = alloca %"compiler/source:Span"
  %l304 = alloca i32
  %l305 = alloca ptr
  %l307 = alloca ptr
  %l309 = alloca i64
  %l312 = alloca { i64, ptr }
  %l313 = alloca %"compiler/check:Ask"
  %l317 = alloca i1
  %l329 = alloca i1
  %l330 = alloca ptr
  %l338 = alloca i1
  %l342 = alloca %"compiler/source:Span"
  %l344 = alloca ptr
  %l348 = alloca i32
  %l352 = alloca %"compiler/typed:Block"
  %l356 = alloca ptr
  %l357 = alloca %"compiler/source:Span"
  %l363 = alloca ptr
  %l372 = alloca i1
  %l377 = alloca i1
  %l378 = alloca ptr
  %l384 = alloca i1
  %l385 = alloca %"compiler/source:Span"
  %l386 = alloca ptr
  %l392 = alloca ptr
  %l403 = alloca i1
  %l404 = alloca ptr
  %l412 = alloca i1
  %l413 = alloca i1
  %l414 = alloca ptr
  %l422 = alloca i1
  %l423 = alloca i1
  %l427 = alloca i1
  %l430 = alloca %"compiler/source:Span"
  %l432 = alloca ptr
  %l436 = alloca i32
  %l440 = alloca %"compiler/typed:Block"
  %l444 = alloca ptr
  %l450 = alloca i64
  %l453 = alloca %"compiler/source:Span"
  %l454 = alloca ptr
  %l460 = alloca ptr
  %l468 = alloca %"compiler/source:Span"
  %l470 = alloca ptr
  %l474 = alloca i32
  %l478 = alloca %"compiler/typed:Block"
  %l484 = alloca ptr
  %l485 = alloca i1
  %l495 = alloca %"compiler/source:Span"
  %l496 = alloca ptr
  %l502 = alloca ptr
  %l508 = alloca ptr
  %l509 = alloca ptr
  %l510 = alloca %"compiler/source:Span"
  %l516 = alloca ptr
  %l521 = alloca ptr
  %l527 = alloca ptr
  %l529 = alloca i1
  %l532 = alloca i32
  %l535 = alloca ptr
  %l536 = alloca ptr
  %l542 = alloca %"compiler/source:Span"
  %l543 = alloca %"compiler/msgs:Msg"
  %l544 = alloca i64
  %l545 = alloca ptr
  %l552 = alloca { i64, i64 }
  %l555 = alloca ptr
  %l565 = alloca ptr
  %l572 = alloca ptr
  %l573 = alloca i1
  %l583 = alloca ptr
  %l590 = alloca { i64, i64 }
  %l593 = alloca ptr
  %l603 = alloca ptr
  %l607 = alloca i64
  %l611 = alloca { i64, i64, i64 }
  %l615 = alloca ptr
  %l622 = alloca ptr
  %l629 = alloca ptr
  %l633 = alloca ptr
  %l639 = alloca ptr
  %l641 = alloca ptr
  %l647 = alloca %"compiler/source:Span"
  %l648 = alloca %"compiler/source:Span"
  %l652 = alloca %"compiler/typed:If"
  %s0 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %rv = alloca ptr
  %t24 = alloca { i64, [3 x i64] }, align 8
  %t64 = alloca { i64, [3 x i64] }, align 8
  %t110 = alloca { i64, [3 x i64] }, align 8
  %t170 = alloca { i64, [3 x i64] }, align 8
  %t326 = alloca { i64, [3 x i64] }, align 8
  %t404 = alloca { i64, [3 x i64] }, align 8
  %t731 = alloca { i64, [3 x i64] }, align 8
  %t821 = alloca { i64, [3 x i64] }, align 8
  %t930 = alloca { i64, [3 x i64] }, align 8
  %t977 = alloca { i64, [3 x i64] }, align 8
  %t1023 = alloca { i64, [3 x i64] }, align 8
  %t1083 = alloca { i64, [3 x i64] }, align 8
  %t1419 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l38
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l39, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/ast:If", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_a622476533ee0612_1aeb16e8ac1e1db6)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/ast:If", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load ptr, ptr %l39, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t21, ptr %t20)
  store ptr %t23, ptr %l45
  br label %bb6
bb6:
  store { i64, [3 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 0
  store i64 11, ptr %t25
  %t26 = load %"compiler/source:Span", ptr %l38
  %t27 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t26, 0
  %t28 = load ptr, ptr %l45, !tbaa !29
  %t29 = insertvalue { %"compiler/source:Span", ptr } %t27, ptr %t28, 1
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t29, ptr %t30
  %t31 = load { i64, [3 x i64] }, ptr %t24
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t31, ptr %t33
  call void @__olang_scope_close(ptr %s0)
  store ptr %t33, ptr %rv
  br label %ret
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/ast:If", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t35, ptr %t39)
  store i64 %t42, ptr %l51
  br label %bb8
bb8:
  %t43 = load i64, ptr %l51, !tbaa !24
  store i64 %t43, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = icmp eq i64 %t44, 1
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l54
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l55, !tbaa !29
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/ast:If", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb11, label %bb12
bb10:
  br label %bb15
bb11:
  call void @__olang_check_failed(ptr @olang_loc_319f2f7a6670a39_e028e643a90bcd1d)
  unreachable
bb12:
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/ast:If", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load ptr, ptr %l55, !tbaa !29
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t61, ptr %t60)
  store ptr %t63, ptr %l61
  br label %bb14
bb14:
  store { i64, [3 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 0
  store i64 11, ptr %t65
  %t66 = load %"compiler/source:Span", ptr %l54
  %t67 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t66, 0
  %t68 = load ptr, ptr %l61, !tbaa !29
  %t69 = insertvalue { %"compiler/source:Span", ptr } %t67, ptr %t68, 1
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t69, ptr %t70
  %t71 = load { i64, [3 x i64] }, ptr %t64
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t71, ptr %t73
  call void @__olang_scope_close(ptr %s0)
  store ptr %t73, ptr %rv
  br label %ret
bb15:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = icmp eq i64 %t75, 0
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr %"compiler/ast:If", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb18, label %bb19
bb17:
  br label %bb45
bb18:
  %t86 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t86, ptr %l69
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t87)
  store ptr %t89, ptr %l71
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t90 = load ptr, ptr %l71, !tbaa !29
  %t92 = getelementptr %"compiler/check:frame", ptr %t90, i32 0, i32 7
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = trunc i64 %t93 to i32
  store i32 %t95, ptr %l75, !tbaa !23
  %t97 = icmp sge i64 0, 0
  br i1 %t97, label %bb21, label %bb22
bb21:
  %t99 = icmp sle i64 0, 1152921504606846975
  br i1 %t99, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_c3c7b193c2dffac4_485cea4ac45d2600)
  unreachable
bb23:
  %t101 = mul i64 0, 8
  %t102 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 0, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load i32, ptr %l75, !tbaa !23
  %t107 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t105, { i64, ptr } %t104)
  store %"compiler/typed:Block" %t107, ptr %l79
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_c3c7b193c2dffac4_485cea4ac45d2600)
  unreachable
bb25:
  %t108 = load %"compiler/typed:Block", ptr %l79
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t108, ptr %t109
  store { i64, [3 x i64] } zeroinitializer, ptr %t110
  %t111 = getelementptr { i64, [3 x i64] }, ptr %t110, i32 0, i32 0
  store i64 11, ptr %t111
  %t112 = load %"compiler/source:Span", ptr %l69
  %t113 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t112, 0
  %t115 = insertvalue { %"compiler/source:Span", ptr } %t113, ptr %t109, 1
  %t116 = getelementptr { i64, [3 x i64] }, ptr %t110, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t115, ptr %t116
  %t117 = load { i64, [3 x i64] }, ptr %t110
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t117, ptr %t119
  call void @__olang_scope_close(ptr %s0)
  store ptr %t119, ptr %rv
  br label %ret
bb26:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr %"compiler/ast:If", ptr %t121, i32 0, i32 2
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l4, !tbaa !29
  %t126 = load ptr, ptr %l4, !tbaa !29
  store ptr %t126, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t127 = load ptr, ptr %l85, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb27, label %bb28
bb27:
  %t130 = load ptr, ptr %l85, !tbaa !29
  %t131 = load i64, ptr %t130
  %t133 = icmp eq i64 %t131, 5
  store i1 %t133, ptr %l86, !tbaa !21
  br label %bb28
bb28:
  %t134 = load i1, ptr %l86, !tbaa !21
  br i1 %t134, label %bb29, label %bb30
bb29:
  %t135 = load ptr, ptr %l4, !tbaa !29
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", ptr }, ptr %t137, i32 0, i32 0
  %t139 = load %"compiler/source:Span", ptr %t138
  store %"compiler/source:Span" %t139, ptr %l5
  %t141 = load ptr, ptr %l4, !tbaa !29
  %t143 = getelementptr { i64, [4 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", ptr }, ptr %t143, i32 0, i32 1
  %t145 = load ptr, ptr %t144
  store ptr %t145, ptr %l6, !tbaa !29
  br label %bb31
bb30:
  br label %bb40
bb31:
  %t147 = load ptr, ptr %l6, !tbaa !29
  %t149 = getelementptr %"compiler/ast:If", ptr %t147, i32 0, i32 0
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb32, label %bb33
bb32:
  %t154 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t154, ptr %l96
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l97, !tbaa !29
  %t156 = load ptr, ptr %l6, !tbaa !29
  %t158 = getelementptr %"compiler/ast:If", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = icmp eq ptr %t159, null
  br i1 %t161, label %bb34, label %bb35
bb33:
  br label %bb38
bb34:
  call void @__olang_check_failed(ptr @olang_loc_6de95c363ba43753_b985f35754c3cc67)
  unreachable
bb35:
  br label %bb36
bb36:
  %t163 = load ptr, ptr %l6, !tbaa !29
  %t165 = getelementptr %"compiler/ast:If", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load ptr, ptr %l97, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t167, ptr %t166)
  store ptr %t169, ptr %l103
  br label %bb37
bb37:
  store { i64, [3 x i64] } zeroinitializer, ptr %t170
  %t171 = getelementptr { i64, [3 x i64] }, ptr %t170, i32 0, i32 0
  store i64 11, ptr %t171
  %t172 = load %"compiler/source:Span", ptr %l96
  %t173 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t172, 0
  %t174 = load ptr, ptr %l103, !tbaa !29
  %t175 = insertvalue { %"compiler/source:Span", ptr } %t173, ptr %t174, 1
  %t176 = getelementptr { i64, [3 x i64] }, ptr %t170, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t175, ptr %t176
  %t177 = load { i64, [3 x i64] }, ptr %t170
  %t179 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t177, ptr %t179
  call void @__olang_scope_close(ptr %s0)
  store ptr %t179, ptr %rv
  br label %ret
bb38:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l5
  %t183 = load ptr, ptr %l6, !tbaa !29
  %t187 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %t181, %"compiler/source:Span" %t182, ptr %t183)
  store ptr %t187, ptr %l109
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t188 = load ptr, ptr %l109, !tbaa !29
  store ptr %t188, ptr %rv
  br label %ret
bb40:
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l110, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t190, ptr %l111
  %t191 = load ptr, ptr %l2, !tbaa !29
  %t193 = getelementptr %"compiler/ast:If", ptr %t191, i32 0, i32 2
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = icmp eq ptr %t194, null
  br i1 %t196, label %bb41, label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_62c8ad0b34d7b82e_8c827e0bb8ee6f7a)
  unreachable
bb42:
  br label %bb43
bb43:
  %t198 = load ptr, ptr %l2, !tbaa !29
  %t200 = getelementptr %"compiler/ast:If", ptr %t198, i32 0, i32 2
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t202 = load ptr, ptr %l110, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l111
  %t205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseOf(ptr %v0, ptr %v1, ptr %t202, %"compiler/source:Span" %t203, ptr %t201)
  store ptr %t205, ptr %l117
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t206 = load ptr, ptr %l117, !tbaa !29
  store ptr %t206, ptr %rv
  br label %ret
bb45:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = getelementptr %"compiler/generic:Program", ptr %t210, i32 0, i32 0
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = getelementptr %"compiler/load:Loader", ptr %t213, i32 0, i32 4
  %t216 = load ptr, ptr %t215, !tbaa !29
  store ptr %t216, ptr %l7, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t218)
  store ptr %t220, ptr %l123
  br label %bb46
bb46:
  %t221 = load ptr, ptr %l123, !tbaa !29
  %t223 = getelementptr %"compiler/check:frame", ptr %t221, i32 0, i32 2
  %t224 = load i64, ptr %t223, !tbaa !24
  store i64 %t224, ptr %l125, !tbaa !24
  %t225 = load ptr, ptr %l2, !tbaa !29
  %t227 = getelementptr %"compiler/ast:If", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = icmp eq ptr %t228, null
  br i1 %t230, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_fdfae68a787e97d5_65790712af8f8e01)
  unreachable
bb48:
  br label %bb49
bb49:
  %t232 = load ptr, ptr %l2, !tbaa !29
  %t234 = getelementptr %"compiler/ast:If", ptr %t232, i32 0, i32 0
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t235)
  store %"compiler/source:Span" %t237, ptr %l131
  br label %bb50
bb50:
  %t238 = getelementptr %"compiler/source:Span", ptr %l131, i32 0, i32 0
  %t239 = load i32, ptr %t238, !tbaa !23
  %t241 = sext i32 %t239 to i64
  %t242 = load i64, ptr %l125, !tbaa !24
  %t244 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t242, i64 %t241)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t244, ptr %l134
  br label %bb51
bb51:
  %t245 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l134
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t245, ptr %l8
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t246, i32 0, i32 75
  %t249 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t252 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t248, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t249)
  store i1 %t252, ptr %l138
  br label %bb52
bb52:
  %t253 = load i1, ptr %l138, !tbaa !21
  br i1 %t253, label %bb53, label %bb54
bb53:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t254, i32 0, i32 75
  %t257 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t260 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %t256, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t257)
  %t261 = extractvalue { i32, i1 } %t260, 1
  %t262 = extractvalue { i32, i1 } %t260, 0
  store i32 %t262, ptr %l144
  %t263 = icmp ne i32 %t262, 0
  br i1 %t263, label %bb56, label %ok.264
ok.264:
  store i1 %t261, ptr %l143
  br label %bb55
bb54:
  br label %bb120
bb55:
  %t265 = load i1, ptr %l143, !tbaa !21
  store i1 %t265, ptr %l139, !tbaa !21
  br label %bb58
bb56:
  br label %bb57
bb57:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l139, !tbaa !21
  br label %bb58
bb58:
  %t266 = load i1, ptr %l139, !tbaa !21
  br i1 %t266, label %bb59, label %bb60
bb59:
  %t267 = load ptr, ptr %l2, !tbaa !29
  %t269 = getelementptr %"compiler/ast:If", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = icmp eq ptr %t270, null
  br i1 %t272, label %bb61, label %bb62
bb60:
  br label %bb76
bb61:
  call void @__olang_check_failed(ptr @olang_loc_9bced391e891fdc0_daecba1c3e9b04cc)
  unreachable
bb62:
  br label %bb63
bb63:
  %t274 = load ptr, ptr %l2, !tbaa !29
  %t276 = getelementptr %"compiler/ast:If", ptr %t274, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t280 = getelementptr %"compiler/ast:Branch", ptr %t277, i32 0, i32 2
  %t281 = load i64, ptr %t280, !tbaa !24
  %t283 = icmp sge i64 %t281, 0
  br i1 %t283, label %bb64, label %bb65
bb64:
  %t285 = load ptr, ptr %l7, !tbaa !29
  store ptr %t285, ptr %l153, !tbaa !29
  %t286 = load ptr, ptr %l2, !tbaa !29
  %t288 = getelementptr %"compiler/ast:If", ptr %t286, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !29
  %t291 = icmp eq ptr %t289, null
  br i1 %t291, label %bb66, label %bb67
bb65:
  br label %bb70
bb66:
  call void @__olang_check_failed(ptr @olang_loc_9bced391e891fdc0_daecba1c3e9b04cc)
  unreachable
bb67:
  br label %bb68
bb68:
  %t293 = load ptr, ptr %l2, !tbaa !29
  %t295 = getelementptr %"compiler/ast:If", ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t299 = getelementptr %"compiler/ast:Branch", ptr %t296, i32 0, i32 2
  %t300 = load i64, ptr %t299, !tbaa !24
  %t301 = load ptr, ptr %l153, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t301, i64 %t300)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load ptr, ptr %l2, !tbaa !29
  %t306 = getelementptr %"compiler/ast:If", ptr %t304, i32 0, i32 2
  %t307 = load ptr, ptr %t306, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropElse(ptr %v0, ptr %v1, ptr %t303, ptr %t307)
  br label %bb71
bb71:
  %t310 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t310, ptr %l164
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l165, !tbaa !29
  %t312 = load ptr, ptr %l2, !tbaa !29
  %t314 = getelementptr %"compiler/ast:If", ptr %t312, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t317 = icmp eq ptr %t315, null
  br i1 %t317, label %bb72, label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_8beb387543c1195f_db09fb2ec562613b)
  unreachable
bb73:
  br label %bb74
bb74:
  %t319 = load ptr, ptr %l2, !tbaa !29
  %t321 = getelementptr %"compiler/ast:If", ptr %t319, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t323 = load ptr, ptr %l165, !tbaa !29
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t323, ptr %t322)
  store ptr %t325, ptr %l171
  br label %bb75
bb75:
  store { i64, [3 x i64] } zeroinitializer, ptr %t326
  %t327 = getelementptr { i64, [3 x i64] }, ptr %t326, i32 0, i32 0
  store i64 11, ptr %t327
  %t328 = load %"compiler/source:Span", ptr %l164
  %t329 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t328, 0
  %t330 = load ptr, ptr %l171, !tbaa !29
  %t331 = insertvalue { %"compiler/source:Span", ptr } %t329, ptr %t330, 1
  %t332 = getelementptr { i64, [3 x i64] }, ptr %t326, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t331, ptr %t332
  %t333 = load { i64, [3 x i64] }, ptr %t326
  %t335 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t333, ptr %t335
  call void @__olang_scope_close(ptr %s0)
  store ptr %t335, ptr %rv
  br label %ret
bb76:
  %t337 = load ptr, ptr %l2, !tbaa !29
  %t339 = getelementptr %"compiler/ast:If", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  %t342 = icmp eq ptr %t340, null
  br i1 %t342, label %bb77, label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_58a847b11cbe2c6a_cfe1571b02fdc8be)
  unreachable
bb78:
  br label %bb79
bb79:
  %t344 = load ptr, ptr %l2, !tbaa !29
  %t346 = getelementptr %"compiler/ast:If", ptr %t344, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !29
  %t350 = getelementptr %"compiler/ast:Branch", ptr %t347, i32 0, i32 2
  %t351 = load i64, ptr %t350, !tbaa !24
  %t353 = icmp sge i64 %t351, 0
  br i1 %t353, label %bb80, label %bb81
bb80:
  %t355 = load ptr, ptr %l7, !tbaa !29
  store ptr %t355, ptr %l182, !tbaa !29
  %t356 = load ptr, ptr %l2, !tbaa !29
  %t358 = getelementptr %"compiler/ast:If", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t361 = icmp eq ptr %t359, null
  br i1 %t361, label %bb82, label %bb83
bb81:
  br label %bb86
bb82:
  call void @__olang_check_failed(ptr @olang_loc_58a847b11cbe2c6a_cfe1571b02fdc8be)
  unreachable
bb83:
  br label %bb84
bb84:
  %t363 = load ptr, ptr %l2, !tbaa !29
  %t365 = getelementptr %"compiler/ast:If", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t369 = getelementptr %"compiler/ast:Branch", ptr %t366, i32 0, i32 2
  %t370 = load i64, ptr %t369, !tbaa !24
  %t371 = load ptr, ptr %l182, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t371, i64 %t370)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t373 = load ptr, ptr %l2, !tbaa !29
  %t375 = getelementptr %"compiler/ast:If", ptr %t373, i32 0, i32 2
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t378 = icmp eq ptr %t376, null
  br i1 %t378, label %bb87, label %bb88
bb87:
  %t380 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t380, ptr %l193
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t381)
  store ptr %t383, ptr %l195
  br label %bb89
bb88:
  br label %bb95
bb89:
  %t384 = load ptr, ptr %l195, !tbaa !29
  %t386 = getelementptr %"compiler/check:frame", ptr %t384, i32 0, i32 7
  %t387 = load i64, ptr %t386, !tbaa !24
  %t389 = trunc i64 %t387 to i32
  store i32 %t389, ptr %l199, !tbaa !23
  %t391 = icmp sge i64 0, 0
  br i1 %t391, label %bb90, label %bb91
bb90:
  %t393 = icmp sle i64 0, 1152921504606846975
  br i1 %t393, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @olang_loc_52eef6690961319f_3e44ce9e4bd0006b)
  unreachable
bb92:
  %t395 = mul i64 0, 8
  %t396 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t395)
  %t397 = insertvalue { i64, ptr } undef, i64 0, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  %t399 = load i32, ptr %l199, !tbaa !23
  %t401 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t399, { i64, ptr } %t398)
  store %"compiler/typed:Block" %t401, ptr %l203
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_52eef6690961319f_3e44ce9e4bd0006b)
  unreachable
bb94:
  %t402 = load %"compiler/typed:Block", ptr %l203
  %t403 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t402, ptr %t403
  store { i64, [3 x i64] } zeroinitializer, ptr %t404
  %t405 = getelementptr { i64, [3 x i64] }, ptr %t404, i32 0, i32 0
  store i64 11, ptr %t405
  %t406 = load %"compiler/source:Span", ptr %l193
  %t407 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t406, 0
  %t409 = insertvalue { %"compiler/source:Span", ptr } %t407, ptr %t403, 1
  %t410 = getelementptr { i64, [3 x i64] }, ptr %t404, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t409, ptr %t410
  %t411 = load { i64, [3 x i64] }, ptr %t404
  %t413 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t411, ptr %t413
  call void @__olang_scope_close(ptr %s0)
  store ptr %t413, ptr %rv
  br label %ret
bb95:
  %t415 = load ptr, ptr %l2, !tbaa !29
  %t417 = getelementptr %"compiler/ast:If", ptr %t415, i32 0, i32 2
  %t418 = load ptr, ptr %t417, !tbaa !29
  store ptr %t418, ptr %l9, !tbaa !29
  %t420 = load ptr, ptr %l9, !tbaa !29
  store ptr %t420, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t421 = load ptr, ptr %l209, !tbaa !29
  %t422 = icmp ne ptr %t421, null
  br i1 %t422, label %bb96, label %bb97
bb96:
  %t424 = load ptr, ptr %l209, !tbaa !29
  %t425 = load i64, ptr %t424
  %t427 = icmp eq i64 %t425, 5
  store i1 %t427, ptr %l210, !tbaa !21
  br label %bb97
bb97:
  %t428 = load i1, ptr %l210, !tbaa !21
  br i1 %t428, label %bb98, label %bb99
bb98:
  %t429 = load ptr, ptr %l9, !tbaa !29
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", ptr }, ptr %t431, i32 0, i32 1
  %t433 = load ptr, ptr %t432
  store ptr %t433, ptr %l10, !tbaa !29
  br label %bb100
bb99:
  br label %bb114
bb100:
  %t435 = load ptr, ptr %l10, !tbaa !29
  %t437 = getelementptr %"compiler/ast:If", ptr %t435, i32 0, i32 0
  %t438 = load ptr, ptr %t437, !tbaa !29
  %t440 = icmp eq ptr %t438, null
  br i1 %t440, label %bb101, label %bb102
bb101:
  %t442 = load ptr, ptr %l10, !tbaa !29
  %t444 = getelementptr %"compiler/ast:If", ptr %t442, i32 0, i32 1
  %t445 = load ptr, ptr %t444, !tbaa !29
  %t447 = icmp eq ptr %t445, null
  br i1 %t447, label %bb103, label %bb104
bb102:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb106
bb103:
  call void @__olang_check_failed(ptr @olang_loc_ccb3ed4617d06259_8e58603f3b63faf5)
  unreachable
bb104:
  br label %bb105
bb105:
  %t449 = load ptr, ptr %l10, !tbaa !29
  %t451 = getelementptr %"compiler/ast:If", ptr %t449, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !29
  %t455 = getelementptr %"compiler/ast:Branch", ptr %t452, i32 0, i32 2
  %t456 = load i64, ptr %t455, !tbaa !24
  %t458 = icmp sge i64 %t456, 0
  store i1 %t458, ptr %l218, !tbaa !21
  br label %bb106
bb106:
  %t460 = load i1, ptr %l218, !tbaa !21
  br i1 %t460, label %bb107, label %bb108
bb107:
  %t461 = load ptr, ptr %l7, !tbaa !29
  store ptr %t461, ptr %l227, !tbaa !29
  %t462 = load ptr, ptr %l10, !tbaa !29
  %t464 = getelementptr %"compiler/ast:If", ptr %t462, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !29
  %t467 = icmp eq ptr %t465, null
  br i1 %t467, label %bb109, label %bb110
bb108:
  br label %bb113
bb109:
  call void @__olang_check_failed(ptr @olang_loc_ccb3ed4617d06259_8e58603f3b63faf5)
  unreachable
bb110:
  br label %bb111
bb111:
  %t469 = load ptr, ptr %l10, !tbaa !29
  %t471 = getelementptr %"compiler/ast:If", ptr %t469, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !29
  %t475 = getelementptr %"compiler/ast:Branch", ptr %t472, i32 0, i32 2
  %t476 = load i64, ptr %t475, !tbaa !24
  %t477 = load ptr, ptr %l227, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t477, i64 %t476)
  br label %bb112
bb112:
  br label %bb113
bb113:
  br label %bb115
bb114:
  br label %bb115
bb115:
  %t479 = load ptr, ptr %l0, !tbaa !29
  store ptr %t479, ptr %l235, !tbaa !29
  %t480 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t480, ptr %l236
  %t481 = load ptr, ptr %l2, !tbaa !29
  %t483 = getelementptr %"compiler/ast:If", ptr %t481, i32 0, i32 2
  %t484 = load ptr, ptr %t483, !tbaa !29
  %t486 = icmp eq ptr %t484, null
  br i1 %t486, label %bb116, label %bb117
bb116:
  call void @__olang_check_failed(ptr @olang_loc_c77fa73b8d335132_2d868ec26eb5ab4e)
  unreachable
bb117:
  br label %bb118
bb118:
  %t488 = load ptr, ptr %l2, !tbaa !29
  %t490 = getelementptr %"compiler/ast:If", ptr %t488, i32 0, i32 2
  %t491 = load ptr, ptr %t490, !tbaa !29
  %t492 = load ptr, ptr %l235, !tbaa !29
  %t493 = load %"compiler/source:Span", ptr %l236
  %t495 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseOf(ptr %v0, ptr %v1, ptr %t492, %"compiler/source:Span" %t493, ptr %t491)
  store ptr %t495, ptr %l242
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s0)
  %t496 = load ptr, ptr %l242, !tbaa !29
  store ptr %t496, ptr %rv
  br label %ret
bb120:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/check:Checker", ptr %t497, i32 0, i32 92
  %t500 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t503 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t499, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t500)
  store i1 %t503, ptr %l246
  br label %bb121
bb121:
  %t504 = load i1, ptr %l246, !tbaa !21
  br i1 %t504, label %bb122, label %bb123
bb122:
  store i1 true, ptr %l247, !tbaa !21
  br label %bb125
bb123:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t507 = getelementptr %"compiler/check:Checker", ptr %t505, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !29
  %t510 = getelementptr %"compiler/generic:Program", ptr %t508, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !29
  %t513 = getelementptr %"compiler/names:Resolver", ptr %t511, i32 0, i32 16
  %t514 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t517 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t513, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t514)
  store i1 %t517, ptr %l253
  br label %bb124
bb124:
  %t518 = load i1, ptr %l253, !tbaa !21
  store i1 %t518, ptr %l247, !tbaa !21
  br label %bb125
bb125:
  %t519 = load i1, ptr %l247, !tbaa !21
  store i1 %t519, ptr %l11, !tbaa !21
  %t520 = load i1, ptr %l11, !tbaa !21
  br i1 %t520, label %bb126, label %bb127
bb126:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %t522, ptr %t523)
  br label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb129
bb129:
  store i1 false, ptr %l12, !tbaa !21
  %t526 = load i1, ptr %l11, !tbaa !21
  %t528 = xor i1 %t526, true
  br i1 %t528, label %bb130, label %bb131
bb130:
  %t530 = load ptr, ptr %l2, !tbaa !29
  %t532 = getelementptr %"compiler/ast:If", ptr %t530, i32 0, i32 1
  %t533 = load ptr, ptr %t532, !tbaa !29
  %t535 = icmp eq ptr %t533, null
  br i1 %t535, label %bb132, label %bb133
bb131:
  store i1 false, ptr %l259, !tbaa !21
  br label %bb135
bb132:
  call void @__olang_check_failed(ptr @olang_loc_b9205633ccf2d073_299d3206908c6fff)
  unreachable
bb133:
  br label %bb134
bb134:
  %t537 = load ptr, ptr %l2, !tbaa !29
  %t539 = getelementptr %"compiler/ast:If", ptr %t537, i32 0, i32 1
  %t540 = load ptr, ptr %t539, !tbaa !29
  %t543 = getelementptr %"compiler/ast:Branch", ptr %t540, i32 0, i32 2
  %t544 = load i64, ptr %t543, !tbaa !24
  %t546 = icmp sge i64 %t544, 0
  store i1 %t546, ptr %l259, !tbaa !21
  br label %bb135
bb135:
  %t548 = load i1, ptr %l259, !tbaa !21
  br i1 %t548, label %bb136, label %bb137
bb136:
  %t549 = load ptr, ptr %l7, !tbaa !29
  store ptr %t549, ptr %l269, !tbaa !29
  %t550 = load ptr, ptr %l2, !tbaa !29
  %t552 = getelementptr %"compiler/ast:If", ptr %t550, i32 0, i32 1
  %t553 = load ptr, ptr %t552, !tbaa !29
  %t555 = icmp eq ptr %t553, null
  br i1 %t555, label %bb138, label %bb139
bb137:
  store i1 false, ptr %l268, !tbaa !21
  br label %bb142
bb138:
  call void @__olang_check_failed(ptr @olang_loc_b9205633ccf2d073_299d3206908c6fff)
  unreachable
bb139:
  br label %bb140
bb140:
  %t557 = load ptr, ptr %l2, !tbaa !29
  %t559 = getelementptr %"compiler/ast:If", ptr %t557, i32 0, i32 1
  %t560 = load ptr, ptr %t559, !tbaa !29
  %t563 = getelementptr %"compiler/ast:Branch", ptr %t560, i32 0, i32 2
  %t564 = load i64, ptr %t563, !tbaa !24
  %t565 = load ptr, ptr %l269, !tbaa !29
  %t567 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %t565, i64 %t564)
  store i1 %t567, ptr %l277
  br label %bb141
bb141:
  %t568 = load i1, ptr %l277, !tbaa !21
  store i1 %t568, ptr %l268, !tbaa !21
  br label %bb142
bb142:
  %t569 = load i1, ptr %l268, !tbaa !21
  br i1 %t569, label %bb143, label %bb144
bb143:
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l278, !tbaa !29
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t571)
  store ptr %t573, ptr %l280
  br label %bb145
bb144:
  br label %bb167
bb145:
  %t574 = load ptr, ptr %l280, !tbaa !29
  %t576 = getelementptr %"compiler/check:frame", ptr %t574, i32 0, i32 1
  %t577 = load i64, ptr %t576, !tbaa !24
  store i64 %t577, ptr %l282, !tbaa !24
  %t578 = load ptr, ptr %l2, !tbaa !29
  %t580 = getelementptr %"compiler/ast:If", ptr %t578, i32 0, i32 0
  %t581 = load ptr, ptr %t580, !tbaa !29
  %t583 = icmp eq ptr %t581, null
  br i1 %t583, label %bb146, label %bb147
bb146:
  call void @__olang_check_failed(ptr @olang_loc_63e876f984926a4_8a5a5385d13272e0)
  unreachable
bb147:
  br label %bb148
bb148:
  %t585 = load ptr, ptr %l2, !tbaa !29
  %t587 = getelementptr %"compiler/ast:If", ptr %t585, i32 0, i32 0
  %t588 = load ptr, ptr %t587, !tbaa !29
  %t589 = load ptr, ptr %l278, !tbaa !29
  %t590 = load i64, ptr %l282, !tbaa !24
  %t592 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %t589, i64 %t590, ptr %t588)
  store i64 %t592, ptr %l288
  br label %bb149
bb149:
  %t593 = load i64, ptr %l288, !tbaa !24
  store i64 %t593, ptr %l13, !tbaa !24
  %t594 = load i64, ptr %l13, !tbaa !24
  %t596 = icmp sge i64 %t594, 0
  br i1 %t596, label %bb150, label %bb151
bb150:
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t600 = getelementptr %"compiler/check:Checker", ptr %t598, i32 0, i32 76
  store ptr %t600, ptr %l292, !tbaa !29
  %t601 = load i64, ptr %l13, !tbaa !24
  store i64 %t601, ptr %l293, !tbaa !24
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t604 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t602)
  store ptr %t604, ptr %l295
  br label %bb152
bb151:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load ptr, ptr %l2, !tbaa !29
  %t608 = getelementptr %"compiler/ast:If", ptr %t606, i32 0, i32 0
  %t609 = load ptr, ptr %t608, !tbaa !29
  %t612 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t605, ptr %t609)
  store i1 %t612, ptr %l317
  br label %bb161
bb152:
  %t613 = load ptr, ptr %l295, !tbaa !29
  %t615 = getelementptr %"compiler/check:frame", ptr %t613, i32 0, i32 2
  %t616 = load i64, ptr %t615, !tbaa !24
  store i64 %t616, ptr %l297, !tbaa !24
  %t617 = load ptr, ptr %l2, !tbaa !29
  %t619 = getelementptr %"compiler/ast:If", ptr %t617, i32 0, i32 0
  %t620 = load ptr, ptr %t619, !tbaa !29
  %t622 = icmp eq ptr %t620, null
  br i1 %t622, label %bb153, label %bb154
bb153:
  call void @__olang_check_failed(ptr @olang_loc_2925a2ee61841cf5_31e6aa96f1b04059)
  unreachable
bb154:
  br label %bb155
bb155:
  %t624 = load ptr, ptr %l2, !tbaa !29
  %t626 = getelementptr %"compiler/ast:If", ptr %t624, i32 0, i32 0
  %t627 = load ptr, ptr %t626, !tbaa !29
  %t629 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t627)
  store %"compiler/source:Span" %t629, ptr %l303
  br label %bb156
bb156:
  %t630 = getelementptr %"compiler/source:Span", ptr %l303, i32 0, i32 0
  %t631 = load i32, ptr %t630, !tbaa !23
  store i32 %t631, ptr %l304, !tbaa !23
  %t632 = load ptr, ptr %l2, !tbaa !29
  store ptr %t632, ptr %l305, !tbaa !29
  %t633 = load ptr, ptr %l0, !tbaa !29
  %t635 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t633)
  store ptr %t635, ptr %l307
  br label %bb157
bb157:
  %t636 = load ptr, ptr %l307, !tbaa !29
  %t638 = getelementptr %"compiler/check:frame", ptr %t636, i32 0, i32 0
  %t639 = load i64, ptr %t638, !tbaa !24
  store i64 %t639, ptr %l309, !tbaa !24
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t642 = getelementptr %"compiler/check:Checker", ptr %t640, i32 0, i32 90
  %t644 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v0, ptr %t642)
  store { i64, ptr } %t644, ptr %l312
  br label %bb158
bb158:
  %t645 = load i64, ptr %l293, !tbaa !24
  %t646 = load i64, ptr %l297, !tbaa !24
  %t647 = load i32, ptr %l304, !tbaa !23
  %t648 = load ptr, ptr %l305, !tbaa !29
  %t649 = load i64, ptr %l309, !tbaa !24
  %t650 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t651 = call %"compiler/check:Ask" @compiler_2fcheck_3aAsk_2ector(ptr %v1, ptr %v0, ptr %v0, i64 %t645, i64 %t646, i32 %t647, ptr %t648, i64 %t649, { i64, ptr } %t650)
  store %"compiler/check:Ask" %t651, ptr %l313
  br label %bb159
bb159:
  %t652 = load ptr, ptr %l292, !tbaa !29
  %t653 = load %"compiler/check:Ask", ptr %l313
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2ePush_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v0, ptr %t652, %"compiler/check:Ask" %t653)
  br label %bb160
bb160:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb166
bb161:
  %t654 = load i1, ptr %l317, !tbaa !21
  %t655 = xor i1 %t654, true
  br i1 %t655, label %bb162, label %bb163
bb162:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %t657, ptr %t658)
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb165
bb165:
  br label %bb166
bb166:
  br label %bb167
bb167:
  %t661 = load ptr, ptr %l2, !tbaa !29
  %t663 = getelementptr %"compiler/ast:If", ptr %t661, i32 0, i32 1
  %t664 = load ptr, ptr %t663, !tbaa !29
  %t666 = icmp eq ptr %t664, null
  br i1 %t666, label %bb168, label %bb169
bb168:
  call void @__olang_check_failed(ptr @olang_loc_c853d17194d5cd4e_2cb2648c67132f32)
  unreachable
bb169:
  br label %bb170
bb170:
  %t668 = load ptr, ptr %l2, !tbaa !29
  %t670 = getelementptr %"compiler/ast:If", ptr %t668, i32 0, i32 1
  %t671 = load ptr, ptr %t670, !tbaa !29
  %t674 = getelementptr %"compiler/ast:Branch", ptr %t671, i32 0, i32 2
  %t675 = load i64, ptr %t674, !tbaa !24
  %t677 = icmp sge i64 %t675, 0
  br i1 %t677, label %bb171, label %bb172
bb171:
  %t679 = load ptr, ptr %l7, !tbaa !29
  store ptr %t679, ptr %l330, !tbaa !29
  %t680 = load ptr, ptr %l2, !tbaa !29
  %t682 = getelementptr %"compiler/ast:If", ptr %t680, i32 0, i32 1
  %t683 = load ptr, ptr %t682, !tbaa !29
  %t685 = icmp eq ptr %t683, null
  br i1 %t685, label %bb173, label %bb174
bb172:
  store i1 false, ptr %l329, !tbaa !21
  br label %bb177
bb173:
  call void @__olang_check_failed(ptr @olang_loc_c853d17194d5cd4e_2cb2648c67132f32)
  unreachable
bb174:
  br label %bb175
bb175:
  %t687 = load ptr, ptr %l2, !tbaa !29
  %t689 = getelementptr %"compiler/ast:If", ptr %t687, i32 0, i32 1
  %t690 = load ptr, ptr %t689, !tbaa !29
  %t693 = getelementptr %"compiler/ast:Branch", ptr %t690, i32 0, i32 2
  %t694 = load i64, ptr %t693, !tbaa !24
  %t695 = load ptr, ptr %l330, !tbaa !29
  %t697 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %t695, i64 %t694)
  store i1 %t697, ptr %l338
  br label %bb176
bb176:
  %t698 = load i1, ptr %l338, !tbaa !21
  store i1 %t698, ptr %l329, !tbaa !21
  br label %bb177
bb177:
  %t699 = load i1, ptr %l329, !tbaa !21
  br i1 %t699, label %bb178, label %bb179
bb178:
  %t700 = load ptr, ptr %l2, !tbaa !29
  %t702 = getelementptr %"compiler/ast:If", ptr %t700, i32 0, i32 2
  %t703 = load ptr, ptr %t702, !tbaa !29
  %t705 = icmp eq ptr %t703, null
  br i1 %t705, label %bb180, label %bb181
bb179:
  br label %bb193
bb180:
  %t707 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t707, ptr %l342
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t710 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t708)
  store ptr %t710, ptr %l344
  br label %bb182
bb181:
  br label %bb188
bb182:
  %t711 = load ptr, ptr %l344, !tbaa !29
  %t713 = getelementptr %"compiler/check:frame", ptr %t711, i32 0, i32 7
  %t714 = load i64, ptr %t713, !tbaa !24
  %t716 = trunc i64 %t714 to i32
  store i32 %t716, ptr %l348, !tbaa !23
  %t718 = icmp sge i64 0, 0
  br i1 %t718, label %bb183, label %bb184
bb183:
  %t720 = icmp sle i64 0, 1152921504606846975
  br i1 %t720, label %bb185, label %bb186
bb184:
  call void @__olang_check_failed(ptr @olang_loc_286b86a66182be45_96c217cd656b05f1)
  unreachable
bb185:
  %t722 = mul i64 0, 8
  %t723 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t722)
  %t724 = insertvalue { i64, ptr } undef, i64 0, 0
  %t725 = insertvalue { i64, ptr } %t724, ptr %t723, 1
  %t726 = load i32, ptr %l348, !tbaa !23
  %t728 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t726, { i64, ptr } %t725)
  store %"compiler/typed:Block" %t728, ptr %l352
  br label %bb187
bb186:
  call void @__olang_check_failed(ptr @olang_loc_286b86a66182be45_96c217cd656b05f1)
  unreachable
bb187:
  %t729 = load %"compiler/typed:Block", ptr %l352
  %t730 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t729, ptr %t730
  store { i64, [3 x i64] } zeroinitializer, ptr %t731
  %t732 = getelementptr { i64, [3 x i64] }, ptr %t731, i32 0, i32 0
  store i64 11, ptr %t732
  %t733 = load %"compiler/source:Span", ptr %l342
  %t734 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t733, 0
  %t736 = insertvalue { %"compiler/source:Span", ptr } %t734, ptr %t730, 1
  %t737 = getelementptr { i64, [3 x i64] }, ptr %t731, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t736, ptr %t737
  %t738 = load { i64, [3 x i64] }, ptr %t731
  %t740 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t738, ptr %t740
  call void @__olang_scope_close(ptr %s0)
  store ptr %t740, ptr %rv
  br label %ret
bb188:
  %t742 = load ptr, ptr %l0, !tbaa !29
  store ptr %t742, ptr %l356, !tbaa !29
  %t743 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t743, ptr %l357
  %t744 = load ptr, ptr %l2, !tbaa !29
  %t746 = getelementptr %"compiler/ast:If", ptr %t744, i32 0, i32 2
  %t747 = load ptr, ptr %t746, !tbaa !29
  %t749 = icmp eq ptr %t747, null
  br i1 %t749, label %bb189, label %bb190
bb189:
  call void @__olang_check_failed(ptr @olang_loc_25279634f75294e0_6b7144c0722904a4)
  unreachable
bb190:
  br label %bb191
bb191:
  %t751 = load ptr, ptr %l2, !tbaa !29
  %t753 = getelementptr %"compiler/ast:If", ptr %t751, i32 0, i32 2
  %t754 = load ptr, ptr %t753, !tbaa !29
  %t755 = load ptr, ptr %l356, !tbaa !29
  %t756 = load %"compiler/source:Span", ptr %l357
  %t758 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseOf(ptr %v0, ptr %v1, ptr %t755, %"compiler/source:Span" %t756, ptr %t754)
  store ptr %t758, ptr %l363
  br label %bb192
bb192:
  call void @__olang_scope_close(ptr %s0)
  %t759 = load ptr, ptr %l363, !tbaa !29
  store ptr %t759, ptr %rv
  br label %ret
bb193:
  %t760 = load ptr, ptr %l2, !tbaa !29
  %t762 = getelementptr %"compiler/ast:If", ptr %t760, i32 0, i32 1
  %t763 = load ptr, ptr %t762, !tbaa !29
  %t765 = icmp eq ptr %t763, null
  br i1 %t765, label %bb194, label %bb195
bb194:
  call void @__olang_check_failed(ptr @olang_loc_204174f82b625491_c4a24154dc66de6d)
  unreachable
bb195:
  br label %bb196
bb196:
  %t767 = load ptr, ptr %l2, !tbaa !29
  %t769 = getelementptr %"compiler/ast:If", ptr %t767, i32 0, i32 1
  %t770 = load ptr, ptr %t769, !tbaa !29
  %t773 = getelementptr %"compiler/ast:Branch", ptr %t770, i32 0, i32 2
  %t774 = load i64, ptr %t773, !tbaa !24
  %t776 = icmp sge i64 %t774, 0
  br i1 %t776, label %bb197, label %bb198
bb197:
  %t778 = load ptr, ptr %l2, !tbaa !29
  %t780 = getelementptr %"compiler/ast:If", ptr %t778, i32 0, i32 2
  %t781 = load ptr, ptr %t780, !tbaa !29
  %t783 = icmp eq ptr %t781, null
  %t785 = xor i1 %t783, true
  store i1 %t785, ptr %l372, !tbaa !21
  br label %bb199
bb198:
  store i1 false, ptr %l372, !tbaa !21
  br label %bb199
bb199:
  %t787 = load i1, ptr %l372, !tbaa !21
  br i1 %t787, label %bb200, label %bb201
bb200:
  %t788 = load ptr, ptr %l0, !tbaa !29
  store ptr %t788, ptr %l378, !tbaa !29
  %t789 = load ptr, ptr %l2, !tbaa !29
  %t791 = getelementptr %"compiler/ast:If", ptr %t789, i32 0, i32 2
  %t792 = load ptr, ptr %t791, !tbaa !29
  %t794 = icmp eq ptr %t792, null
  br i1 %t794, label %bb202, label %bb203
bb201:
  store i1 false, ptr %l377, !tbaa !21
  br label %bb206
bb202:
  call void @__olang_check_failed(ptr @olang_loc_204174f82b625491_c4a24154dc66de6d)
  unreachable
bb203:
  br label %bb204
bb204:
  %t796 = load ptr, ptr %l2, !tbaa !29
  %t798 = getelementptr %"compiler/ast:If", ptr %t796, i32 0, i32 2
  %t799 = load ptr, ptr %t798, !tbaa !29
  %t800 = load ptr, ptr %l378, !tbaa !29
  %t802 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseDropped(ptr %v0, ptr %v1, ptr %t800, ptr %t799)
  store i1 %t802, ptr %l384
  br label %bb205
bb205:
  %t803 = load i1, ptr %l384, !tbaa !21
  store i1 %t803, ptr %l377, !tbaa !21
  br label %bb206
bb206:
  %t804 = load i1, ptr %l377, !tbaa !21
  br i1 %t804, label %bb207, label %bb208
bb207:
  %t805 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t805, ptr %l385
  %t806 = load ptr, ptr %l0, !tbaa !29
  store ptr %t806, ptr %l386, !tbaa !29
  %t807 = load ptr, ptr %l2, !tbaa !29
  %t809 = getelementptr %"compiler/ast:If", ptr %t807, i32 0, i32 1
  %t810 = load ptr, ptr %t809, !tbaa !29
  %t812 = icmp eq ptr %t810, null
  br i1 %t812, label %bb209, label %bb210
bb208:
  br label %bb213
bb209:
  call void @__olang_check_failed(ptr @olang_loc_129174e89ad23b8a_c281ac2402d9bb86)
  unreachable
bb210:
  br label %bb211
bb211:
  %t814 = load ptr, ptr %l2, !tbaa !29
  %t816 = getelementptr %"compiler/ast:If", ptr %t814, i32 0, i32 1
  %t817 = load ptr, ptr %t816, !tbaa !29
  %t818 = load ptr, ptr %l386, !tbaa !29
  %t820 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t818, ptr %t817)
  store ptr %t820, ptr %l392
  br label %bb212
bb212:
  store { i64, [3 x i64] } zeroinitializer, ptr %t821
  %t822 = getelementptr { i64, [3 x i64] }, ptr %t821, i32 0, i32 0
  store i64 11, ptr %t822
  %t823 = load %"compiler/source:Span", ptr %l385
  %t824 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t823, 0
  %t825 = load ptr, ptr %l392, !tbaa !29
  %t826 = insertvalue { %"compiler/source:Span", ptr } %t824, ptr %t825, 1
  %t827 = getelementptr { i64, [3 x i64] }, ptr %t821, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t826, ptr %t827
  %t828 = load { i64, [3 x i64] }, ptr %t821
  %t830 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t828, ptr %t830
  call void @__olang_scope_close(ptr %s0)
  store ptr %t830, ptr %rv
  br label %ret
bb213:
  %t832 = load ptr, ptr %l2, !tbaa !29
  %t834 = getelementptr %"compiler/ast:If", ptr %t832, i32 0, i32 1
  %t835 = load ptr, ptr %t834, !tbaa !29
  %t837 = icmp eq ptr %t835, null
  br i1 %t837, label %bb214, label %bb215
bb214:
  call void @__olang_check_failed(ptr @olang_loc_aaca5398e8f6066a_f405ea46c1055e66)
  unreachable
bb215:
  br label %bb216
bb216:
  %t839 = load ptr, ptr %l2, !tbaa !29
  %t841 = getelementptr %"compiler/ast:If", ptr %t839, i32 0, i32 1
  %t842 = load ptr, ptr %t841, !tbaa !29
  %t845 = getelementptr %"compiler/ast:Branch", ptr %t842, i32 0, i32 2
  %t846 = load i64, ptr %t845, !tbaa !24
  %t848 = icmp sge i64 %t846, 0
  br i1 %t848, label %bb217, label %bb218
bb217:
  %t850 = load ptr, ptr %l7, !tbaa !29
  store ptr %t850, ptr %l404, !tbaa !29
  %t851 = load ptr, ptr %l2, !tbaa !29
  %t853 = getelementptr %"compiler/ast:If", ptr %t851, i32 0, i32 1
  %t854 = load ptr, ptr %t853, !tbaa !29
  %t856 = icmp eq ptr %t854, null
  br i1 %t856, label %bb219, label %bb220
bb218:
  store i1 false, ptr %l403, !tbaa !21
  br label %bb223
bb219:
  call void @__olang_check_failed(ptr @olang_loc_aaca5398e8f6066a_f405ea46c1055e66)
  unreachable
bb220:
  br label %bb221
bb221:
  %t858 = load ptr, ptr %l2, !tbaa !29
  %t860 = getelementptr %"compiler/ast:If", ptr %t858, i32 0, i32 1
  %t861 = load ptr, ptr %t860, !tbaa !29
  %t864 = getelementptr %"compiler/ast:Branch", ptr %t861, i32 0, i32 2
  %t865 = load i64, ptr %t864, !tbaa !24
  %t866 = load ptr, ptr %l404, !tbaa !29
  %t868 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %t866, i64 %t865)
  store i1 %t868, ptr %l412
  br label %bb222
bb222:
  %t869 = load i1, ptr %l412, !tbaa !21
  store i1 %t869, ptr %l403, !tbaa !21
  br label %bb223
bb223:
  %t870 = load i1, ptr %l403, !tbaa !21
  br i1 %t870, label %bb224, label %bb225
bb224:
  %t871 = load ptr, ptr %l7, !tbaa !29
  store ptr %t871, ptr %l414, !tbaa !29
  %t872 = load ptr, ptr %l2, !tbaa !29
  %t874 = getelementptr %"compiler/ast:If", ptr %t872, i32 0, i32 1
  %t875 = load ptr, ptr %t874, !tbaa !29
  %t877 = icmp eq ptr %t875, null
  br i1 %t877, label %bb226, label %bb227
bb225:
  store i1 false, ptr %l413, !tbaa !21
  br label %bb234
bb226:
  call void @__olang_check_failed(ptr @olang_loc_aaca5398e8f6066a_f405ea46c1055e66)
  unreachable
bb227:
  br label %bb228
bb228:
  %t879 = load ptr, ptr %l2, !tbaa !29
  %t881 = getelementptr %"compiler/ast:If", ptr %t879, i32 0, i32 1
  %t882 = load ptr, ptr %t881, !tbaa !29
  %t885 = getelementptr %"compiler/ast:Branch", ptr %t882, i32 0, i32 2
  %t886 = load i64, ptr %t885, !tbaa !24
  %t887 = load ptr, ptr %l414, !tbaa !29
  %t889 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t887, i64 %t886)
  store i1 %t889, ptr %l422
  br label %bb229
bb229:
  %t890 = load i1, ptr %l422, !tbaa !21
  br i1 %t890, label %bb230, label %bb231
bb230:
  store i1 true, ptr %l423, !tbaa !21
  br label %bb233
bb231:
  %t891 = load ptr, ptr %l0, !tbaa !29
  %t892 = load ptr, ptr %l2, !tbaa !29
  %t894 = getelementptr %"compiler/ast:If", ptr %t892, i32 0, i32 2
  %t895 = load ptr, ptr %t894, !tbaa !29
  %t898 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseHolds(ptr %v0, ptr %v1, ptr %t891, ptr %t895)
  store i1 %t898, ptr %l427
  br label %bb232
bb232:
  %t899 = load i1, ptr %l427, !tbaa !21
  store i1 %t899, ptr %l423, !tbaa !21
  br label %bb233
bb233:
  %t900 = load i1, ptr %l423, !tbaa !21
  store i1 %t900, ptr %l413, !tbaa !21
  br label %bb234
bb234:
  %t901 = load i1, ptr %l413, !tbaa !21
  br i1 %t901, label %bb235, label %bb236
bb235:
  store %olang.scope zeroinitializer, ptr %s24
  %t902 = load ptr, ptr %l0, !tbaa !29
  %t903 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s24, ptr %t902, %"compiler/source:Span" %t903, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d9, i32 0, i32 1) })
  br label %bb237
bb236:
  br label %bb244
bb237:
  %t906 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t906, ptr %l430
  %t907 = load ptr, ptr %l0, !tbaa !29
  %t909 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t907)
  store ptr %t909, ptr %l432
  br label %bb238
bb238:
  %t910 = load ptr, ptr %l432, !tbaa !29
  %t912 = getelementptr %"compiler/check:frame", ptr %t910, i32 0, i32 7
  %t913 = load i64, ptr %t912, !tbaa !24
  %t915 = trunc i64 %t913 to i32
  store i32 %t915, ptr %l436, !tbaa !23
  %t917 = icmp sge i64 0, 0
  br i1 %t917, label %bb239, label %bb240
bb239:
  %t919 = icmp sle i64 0, 1152921504606846975
  br i1 %t919, label %bb241, label %bb242
bb240:
  call void @__olang_check_failed(ptr @olang_loc_fca31ed42f743f9f_86b4bf9b48cda613)
  unreachable
bb241:
  %t921 = mul i64 0, 8
  %t922 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t921)
  %t923 = insertvalue { i64, ptr } undef, i64 0, 0
  %t924 = insertvalue { i64, ptr } %t923, ptr %t922, 1
  %t925 = load i32, ptr %l436, !tbaa !23
  %t927 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t925, { i64, ptr } %t924)
  store %"compiler/typed:Block" %t927, ptr %l440
  br label %bb243
bb242:
  call void @__olang_check_failed(ptr @olang_loc_fca31ed42f743f9f_86b4bf9b48cda613)
  unreachable
bb243:
  %t928 = load %"compiler/typed:Block", ptr %l440
  %t929 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t928, ptr %t929
  store { i64, [3 x i64] } zeroinitializer, ptr %t930
  %t931 = getelementptr { i64, [3 x i64] }, ptr %t930, i32 0, i32 0
  store i64 11, ptr %t931
  %t932 = load %"compiler/source:Span", ptr %l430
  %t933 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t932, 0
  %t935 = insertvalue { %"compiler/source:Span", ptr } %t933, ptr %t929, 1
  %t936 = getelementptr { i64, [3 x i64] }, ptr %t930, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t935, ptr %t936
  %t937 = load { i64, [3 x i64] }, ptr %t930
  %t939 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t937, ptr %t939
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t939, ptr %rv
  br label %ret
bb244:
  %t941 = load ptr, ptr %l0, !tbaa !29
  store ptr %t941, ptr %l444, !tbaa !29
  %t942 = load ptr, ptr %l2, !tbaa !29
  %t944 = getelementptr %"compiler/ast:If", ptr %t942, i32 0, i32 0
  %t945 = load ptr, ptr %t944, !tbaa !29
  %t947 = icmp eq ptr %t945, null
  br i1 %t947, label %bb245, label %bb246
bb245:
  call void @__olang_check_failed(ptr @olang_loc_6f3b4b685ddeb67c_7b5ce21143ef4c38)
  unreachable
bb246:
  br label %bb247
bb247:
  %t949 = load ptr, ptr %l2, !tbaa !29
  %t951 = getelementptr %"compiler/ast:If", ptr %t949, i32 0, i32 0
  %t952 = load ptr, ptr %t951, !tbaa !29
  %t953 = load ptr, ptr %l444, !tbaa !29
  %t955 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v1, ptr %t953, ptr %t952)
  store i64 %t955, ptr %l450
  br label %bb248
bb248:
  %t956 = load i64, ptr %l450, !tbaa !24
  store i64 %t956, ptr %l14, !tbaa !24
  %t957 = load i64, ptr %l14, !tbaa !24
  %t959 = icmp eq i64 %t957, 1
  br i1 %t959, label %bb249, label %bb250
bb249:
  %t961 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t961, ptr %l453
  %t962 = load ptr, ptr %l0, !tbaa !29
  store ptr %t962, ptr %l454, !tbaa !29
  %t963 = load ptr, ptr %l2, !tbaa !29
  %t965 = getelementptr %"compiler/ast:If", ptr %t963, i32 0, i32 1
  %t966 = load ptr, ptr %t965, !tbaa !29
  %t968 = icmp eq ptr %t966, null
  br i1 %t968, label %bb251, label %bb252
bb250:
  br label %bb255
bb251:
  call void @__olang_check_failed(ptr @olang_loc_e7da762e638de5eb_7df0529e92f5f857)
  unreachable
bb252:
  br label %bb253
bb253:
  %t970 = load ptr, ptr %l2, !tbaa !29
  %t972 = getelementptr %"compiler/ast:If", ptr %t970, i32 0, i32 1
  %t973 = load ptr, ptr %t972, !tbaa !29
  %t974 = load ptr, ptr %l454, !tbaa !29
  %t976 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t974, ptr %t973)
  store ptr %t976, ptr %l460
  br label %bb254
bb254:
  store { i64, [3 x i64] } zeroinitializer, ptr %t977
  %t978 = getelementptr { i64, [3 x i64] }, ptr %t977, i32 0, i32 0
  store i64 11, ptr %t978
  %t979 = load %"compiler/source:Span", ptr %l453
  %t980 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t979, 0
  %t981 = load ptr, ptr %l460, !tbaa !29
  %t982 = insertvalue { %"compiler/source:Span", ptr } %t980, ptr %t981, 1
  %t983 = getelementptr { i64, [3 x i64] }, ptr %t977, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t982, ptr %t983
  %t984 = load { i64, [3 x i64] }, ptr %t977
  %t986 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t984, ptr %t986
  call void @__olang_scope_close(ptr %s0)
  store ptr %t986, ptr %rv
  br label %ret
bb255:
  %t988 = load i64, ptr %l14, !tbaa !24
  %t990 = icmp eq i64 %t988, 0
  br i1 %t990, label %bb256, label %bb257
bb256:
  %t992 = load ptr, ptr %l2, !tbaa !29
  %t994 = getelementptr %"compiler/ast:If", ptr %t992, i32 0, i32 2
  %t995 = load ptr, ptr %t994, !tbaa !29
  %t997 = icmp eq ptr %t995, null
  br i1 %t997, label %bb258, label %bb259
bb257:
  br label %bb285
bb258:
  %t999 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t999, ptr %l468
  %t1000 = load ptr, ptr %l0, !tbaa !29
  %t1002 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1000)
  store ptr %t1002, ptr %l470
  br label %bb260
bb259:
  br label %bb266
bb260:
  %t1003 = load ptr, ptr %l470, !tbaa !29
  %t1005 = getelementptr %"compiler/check:frame", ptr %t1003, i32 0, i32 7
  %t1006 = load i64, ptr %t1005, !tbaa !24
  %t1008 = trunc i64 %t1006 to i32
  store i32 %t1008, ptr %l474, !tbaa !23
  %t1010 = icmp sge i64 0, 0
  br i1 %t1010, label %bb261, label %bb262
bb261:
  %t1012 = icmp sle i64 0, 1152921504606846975
  br i1 %t1012, label %bb263, label %bb264
bb262:
  call void @__olang_check_failed(ptr @olang_loc_59798b902320b6de_8af9bcd9624748ca)
  unreachable
bb263:
  %t1014 = mul i64 0, 8
  %t1015 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t1014)
  %t1016 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1017 = insertvalue { i64, ptr } %t1016, ptr %t1015, 1
  %t1018 = load i32, ptr %l474, !tbaa !23
  %t1020 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t1018, { i64, ptr } %t1017)
  store %"compiler/typed:Block" %t1020, ptr %l478
  br label %bb265
bb264:
  call void @__olang_check_failed(ptr @olang_loc_59798b902320b6de_8af9bcd9624748ca)
  unreachable
bb265:
  %t1021 = load %"compiler/typed:Block", ptr %l478
  %t1022 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t1021, ptr %t1022
  store { i64, [3 x i64] } zeroinitializer, ptr %t1023
  %t1024 = getelementptr { i64, [3 x i64] }, ptr %t1023, i32 0, i32 0
  store i64 11, ptr %t1024
  %t1025 = load %"compiler/source:Span", ptr %l468
  %t1026 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1025, 0
  %t1028 = insertvalue { %"compiler/source:Span", ptr } %t1026, ptr %t1022, 1
  %t1029 = getelementptr { i64, [3 x i64] }, ptr %t1023, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1028, ptr %t1029
  %t1030 = load { i64, [3 x i64] }, ptr %t1023
  %t1032 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1030, ptr %t1032
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1032, ptr %rv
  br label %ret
bb266:
  %t1034 = load ptr, ptr %l2, !tbaa !29
  %t1036 = getelementptr %"compiler/ast:If", ptr %t1034, i32 0, i32 2
  %t1037 = load ptr, ptr %t1036, !tbaa !29
  store ptr %t1037, ptr %l15, !tbaa !29
  %t1039 = load ptr, ptr %l15, !tbaa !29
  store ptr %t1039, ptr %l484, !tbaa !29
  store i1 false, ptr %l485, !tbaa !21
  %t1040 = load ptr, ptr %l484, !tbaa !29
  %t1041 = icmp ne ptr %t1040, null
  br i1 %t1041, label %bb267, label %bb268
bb267:
  %t1043 = load ptr, ptr %l484, !tbaa !29
  %t1044 = load i64, ptr %t1043
  %t1046 = icmp eq i64 %t1044, 5
  store i1 %t1046, ptr %l485, !tbaa !21
  br label %bb268
bb268:
  %t1047 = load i1, ptr %l485, !tbaa !21
  br i1 %t1047, label %bb269, label %bb270
bb269:
  %t1048 = load ptr, ptr %l15, !tbaa !29
  %t1050 = getelementptr { i64, [4 x i64] }, ptr %t1048, i32 0, i32 1
  %t1051 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1050, i32 0, i32 0
  %t1052 = load %"compiler/source:Span", ptr %t1051
  store %"compiler/source:Span" %t1052, ptr %l16
  %t1054 = load ptr, ptr %l15, !tbaa !29
  %t1056 = getelementptr { i64, [4 x i64] }, ptr %t1054, i32 0, i32 1
  %t1057 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1056, i32 0, i32 1
  %t1058 = load ptr, ptr %t1057
  store ptr %t1058, ptr %l17, !tbaa !29
  br label %bb271
bb270:
  br label %bb280
bb271:
  %t1060 = load ptr, ptr %l17, !tbaa !29
  %t1062 = getelementptr %"compiler/ast:If", ptr %t1060, i32 0, i32 0
  %t1063 = load ptr, ptr %t1062, !tbaa !29
  %t1065 = icmp eq ptr %t1063, null
  br i1 %t1065, label %bb272, label %bb273
bb272:
  %t1067 = load %"compiler/source:Span", ptr %l16
  store %"compiler/source:Span" %t1067, ptr %l495
  %t1068 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1068, ptr %l496, !tbaa !29
  %t1069 = load ptr, ptr %l17, !tbaa !29
  %t1071 = getelementptr %"compiler/ast:If", ptr %t1069, i32 0, i32 1
  %t1072 = load ptr, ptr %t1071, !tbaa !29
  %t1074 = icmp eq ptr %t1072, null
  br i1 %t1074, label %bb274, label %bb275
bb273:
  br label %bb278
bb274:
  call void @__olang_check_failed(ptr @olang_loc_4ac5dcd3d6b95a4d_7a015a3c37ae2071)
  unreachable
bb275:
  br label %bb276
bb276:
  %t1076 = load ptr, ptr %l17, !tbaa !29
  %t1078 = getelementptr %"compiler/ast:If", ptr %t1076, i32 0, i32 1
  %t1079 = load ptr, ptr %t1078, !tbaa !29
  %t1080 = load ptr, ptr %l496, !tbaa !29
  %t1082 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t1080, ptr %t1079)
  store ptr %t1082, ptr %l502
  br label %bb277
bb277:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1083
  %t1084 = getelementptr { i64, [3 x i64] }, ptr %t1083, i32 0, i32 0
  store i64 11, ptr %t1084
  %t1085 = load %"compiler/source:Span", ptr %l495
  %t1086 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1085, 0
  %t1087 = load ptr, ptr %l502, !tbaa !29
  %t1088 = insertvalue { %"compiler/source:Span", ptr } %t1086, ptr %t1087, 1
  %t1089 = getelementptr { i64, [3 x i64] }, ptr %t1083, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1088, ptr %t1089
  %t1090 = load { i64, [3 x i64] }, ptr %t1083
  %t1092 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1090, ptr %t1092
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1092, ptr %rv
  br label %ret
bb278:
  %t1094 = load ptr, ptr %l0, !tbaa !29
  %t1095 = load %"compiler/source:Span", ptr %l16
  %t1096 = load ptr, ptr %l17, !tbaa !29
  %t1100 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %t1094, %"compiler/source:Span" %t1095, ptr %t1096)
  store ptr %t1100, ptr %l508
  br label %bb279
bb279:
  call void @__olang_scope_close(ptr %s0)
  %t1101 = load ptr, ptr %l508, !tbaa !29
  store ptr %t1101, ptr %rv
  br label %ret
bb280:
  %t1102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1102, ptr %l509, !tbaa !29
  %t1103 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1103, ptr %l510
  %t1104 = load ptr, ptr %l2, !tbaa !29
  %t1106 = getelementptr %"compiler/ast:If", ptr %t1104, i32 0, i32 2
  %t1107 = load ptr, ptr %t1106, !tbaa !29
  %t1109 = icmp eq ptr %t1107, null
  br i1 %t1109, label %bb281, label %bb282
bb281:
  call void @__olang_check_failed(ptr @olang_loc_162a24c06a0f6e38_d46e08b937be947c)
  unreachable
bb282:
  br label %bb283
bb283:
  %t1111 = load ptr, ptr %l2, !tbaa !29
  %t1113 = getelementptr %"compiler/ast:If", ptr %t1111, i32 0, i32 2
  %t1114 = load ptr, ptr %t1113, !tbaa !29
  %t1115 = load ptr, ptr %l509, !tbaa !29
  %t1116 = load %"compiler/source:Span", ptr %l510
  %t1118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseOf(ptr %v0, ptr %v1, ptr %t1115, %"compiler/source:Span" %t1116, ptr %t1114)
  store ptr %t1118, ptr %l516
  br label %bb284
bb284:
  call void @__olang_scope_close(ptr %s0)
  %t1119 = load ptr, ptr %l516, !tbaa !29
  store ptr %t1119, ptr %rv
  br label %ret
bb285:
  %t1120 = load i1, ptr %l12, !tbaa !21
  %t1122 = xor i1 %t1120, true
  br i1 %t1122, label %bb286, label %bb287
bb286:
  %t1124 = load ptr, ptr %l0, !tbaa !29
  %t1125 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %t1124, ptr %t1125)
  br label %bb288
bb287:
  br label %bb289
bb288:
  br label %bb289
bb289:
  %t1128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1128, ptr %l521, !tbaa !29
  %t1129 = load ptr, ptr %l2, !tbaa !29
  %t1131 = getelementptr %"compiler/ast:If", ptr %t1129, i32 0, i32 0
  %t1132 = load ptr, ptr %t1131, !tbaa !29
  %t1134 = icmp eq ptr %t1132, null
  br i1 %t1134, label %bb290, label %bb291
bb290:
  call void @__olang_check_failed(ptr @olang_loc_18bd954db9161a57_4d0d337f3d6dc3eb)
  unreachable
bb291:
  br label %bb292
bb292:
  %t1136 = load ptr, ptr %l2, !tbaa !29
  %t1138 = getelementptr %"compiler/ast:If", ptr %t1136, i32 0, i32 0
  %t1139 = load ptr, ptr %t1138, !tbaa !29
  %t1140 = load ptr, ptr %l521, !tbaa !29
  %t1142 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %t1140, ptr %t1139)
  store ptr %t1142, ptr %l527
  br label %bb293
bb293:
  %t1143 = load ptr, ptr %l527, !tbaa !29
  store ptr %t1143, ptr %l18, !tbaa !29
  %t1144 = load i1, ptr %l11, !tbaa !21
  br i1 %t1144, label %bb294, label %bb295
bb294:
  %t1146 = load ptr, ptr %l18, !tbaa !29
  %t1149 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1146)
  store i32 %t1149, ptr %l532
  br label %bb296
bb295:
  store i1 false, ptr %l529, !tbaa !21
  br label %bb297
bb296:
  %t1150 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1151 = load i32, ptr %l532, !tbaa !23
  %t1153 = icmp eq i32 %t1151, %t1150
  store i1 %t1153, ptr %l529, !tbaa !21
  br label %bb297
bb297:
  %t1155 = load i1, ptr %l529, !tbaa !21
  br i1 %t1155, label %bb298, label %bb299
bb298:
  store %olang.scope zeroinitializer, ptr %s32
  %t1156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1156, ptr %l535, !tbaa !29
  %t1157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1157, ptr %l536, !tbaa !29
  %t1158 = load ptr, ptr %l2, !tbaa !29
  %t1160 = getelementptr %"compiler/ast:If", ptr %t1158, i32 0, i32 0
  %t1161 = load ptr, ptr %t1160, !tbaa !29
  %t1163 = icmp eq ptr %t1161, null
  br i1 %t1163, label %bb300, label %bb301
bb299:
  br label %bb306
bb300:
  call void @__olang_check_failed(ptr @olang_loc_f844534d0025e012_1a1d7643daef702e)
  unreachable
bb301:
  br label %bb302
bb302:
  %t1165 = load ptr, ptr %l2, !tbaa !29
  %t1167 = getelementptr %"compiler/ast:If", ptr %t1165, i32 0, i32 0
  %t1168 = load ptr, ptr %t1167, !tbaa !29
  %t1169 = load ptr, ptr %l536, !tbaa !29
  %t1171 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %t1169, ptr %t1168)
  store %"compiler/source:Span" %t1171, ptr %l542
  br label %bb303
bb303:
  %t1172 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eConditionConstant(ptr %s32)
  store %"compiler/msgs:Msg" %t1172, ptr %l543
  br label %bb304
bb304:
  %t1173 = load ptr, ptr %l535, !tbaa !29
  %t1174 = load %"compiler/source:Span", ptr %l542
  %t1175 = load %"compiler/msgs:Msg", ptr %l543
  %t1176 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s32, ptr %t1173, %"compiler/source:Span" %t1174, %"compiler/msgs:Msg" %t1175)
  store i64 %t1176, ptr %l544
  br label %bb305
bb305:
  call void @__olang_scope_close(ptr %s32)
  br label %bb306
bb306:
  %t1177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1177, ptr %l545, !tbaa !29
  %t1178 = load ptr, ptr %l2, !tbaa !29
  %t1180 = getelementptr %"compiler/ast:If", ptr %t1178, i32 0, i32 0
  %t1181 = load ptr, ptr %t1180, !tbaa !29
  %t1183 = icmp eq ptr %t1181, null
  br i1 %t1183, label %bb307, label %bb308
bb307:
  call void @__olang_check_failed(ptr @olang_loc_553bfedf729ee439_b54fafc31e964fd5)
  unreachable
bb308:
  br label %bb309
bb309:
  %t1185 = load ptr, ptr %l2, !tbaa !29
  %t1187 = getelementptr %"compiler/ast:If", ptr %t1185, i32 0, i32 0
  %t1188 = load ptr, ptr %t1187, !tbaa !29
  %t1189 = load ptr, ptr %l545, !tbaa !29
  %t1192 = call { i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOf(ptr %v0, ptr %v1, ptr %t1189, ptr %t1188, i32 75)
  store { i64, i64 } %t1192, ptr %l552
  br label %bb310
bb310:
  %t1193 = load { i64, i64 }, ptr %l552
  store { i64, i64 } %t1193, ptr %l19
  %t1194 = getelementptr { i64, i64 }, ptr %l19, i32 0, i32 0
  %t1195 = load i64, ptr %t1194, !tbaa !24
  store i64 %t1195, ptr %l20, !tbaa !24
  %t1197 = getelementptr { i64, i64 }, ptr %l19, i32 0, i32 1
  %t1198 = load i64, ptr %t1197, !tbaa !24
  store i64 %t1198, ptr %l21, !tbaa !24
  %t1200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1200, ptr %l555, !tbaa !29
  %t1201 = load ptr, ptr %l2, !tbaa !29
  %t1203 = getelementptr %"compiler/ast:If", ptr %t1201, i32 0, i32 1
  %t1204 = load ptr, ptr %t1203, !tbaa !29
  %t1206 = icmp eq ptr %t1204, null
  br i1 %t1206, label %bb311, label %bb312
bb311:
  call void @__olang_check_failed(ptr @olang_loc_2032043ec708821f_9b3365a6aba1b47b)
  unreachable
bb312:
  br label %bb313
bb313:
  %t1208 = load ptr, ptr %l2, !tbaa !29
  %t1210 = getelementptr %"compiler/ast:If", ptr %t1208, i32 0, i32 1
  %t1211 = load ptr, ptr %t1210, !tbaa !29
  %t1212 = load i64, ptr %l20, !tbaa !24
  %t1213 = load i64, ptr %l21, !tbaa !24
  %t1214 = load ptr, ptr %l2, !tbaa !29
  %t1216 = getelementptr %"compiler/ast:If", ptr %t1214, i32 0, i32 0
  %t1217 = load ptr, ptr %t1216, !tbaa !29
  %t1218 = load ptr, ptr %l555, !tbaa !29
  %t1223 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedBranch(ptr %v0, ptr %v1, ptr %v1, ptr %t1218, ptr %t1211, i64 %t1212, i64 %t1213, ptr %t1217, i1 true)
  store ptr %t1223, ptr %l565
  br label %bb314
bb314:
  %t1224 = load ptr, ptr %l565, !tbaa !29
  store ptr %t1224, ptr %l22, !tbaa !29
  store ptr null, ptr %l23, !tbaa !29
  %t1225 = load ptr, ptr %l2, !tbaa !29
  %t1227 = getelementptr %"compiler/ast:If", ptr %t1225, i32 0, i32 2
  %t1228 = load ptr, ptr %t1227, !tbaa !29
  %t1230 = icmp eq ptr %t1228, null
  %t1232 = xor i1 %t1230, true
  br i1 %t1232, label %bb315, label %bb316
bb315:
  %t1234 = load ptr, ptr %l2, !tbaa !29
  %t1236 = getelementptr %"compiler/ast:If", ptr %t1234, i32 0, i32 2
  %t1237 = load ptr, ptr %t1236, !tbaa !29
  store ptr %t1237, ptr %l24, !tbaa !29
  %t1239 = load ptr, ptr %l24, !tbaa !29
  store ptr %t1239, ptr %l572, !tbaa !29
  store i1 false, ptr %l573, !tbaa !21
  %t1240 = load ptr, ptr %l572, !tbaa !29
  %t1241 = icmp ne ptr %t1240, null
  br i1 %t1241, label %bb317, label %bb318
bb316:
  br label %bb353
bb317:
  %t1243 = load ptr, ptr %l572, !tbaa !29
  %t1244 = load i64, ptr %t1243
  %t1246 = icmp eq i64 %t1244, 5
  store i1 %t1246, ptr %l573, !tbaa !21
  br label %bb318
bb318:
  %t1247 = load i1, ptr %l573, !tbaa !21
  br i1 %t1247, label %bb319, label %bb320
bb319:
  %t1248 = load ptr, ptr %l24, !tbaa !29
  %t1250 = getelementptr { i64, [4 x i64] }, ptr %t1248, i32 0, i32 1
  %t1251 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1250, i32 0, i32 0
  %t1252 = load %"compiler/source:Span", ptr %t1251
  store %"compiler/source:Span" %t1252, ptr %l25
  %t1254 = load ptr, ptr %l24, !tbaa !29
  %t1256 = getelementptr { i64, [4 x i64] }, ptr %t1254, i32 0, i32 1
  %t1257 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1256, i32 0, i32 1
  %t1258 = load ptr, ptr %t1257
  store ptr %t1258, ptr %l26, !tbaa !29
  br label %bb321
bb320:
  br label %bb346
bb321:
  %t1260 = load ptr, ptr %l26, !tbaa !29
  %t1262 = getelementptr %"compiler/ast:If", ptr %t1260, i32 0, i32 0
  %t1263 = load ptr, ptr %t1262, !tbaa !29
  %t1265 = icmp eq ptr %t1263, null
  br i1 %t1265, label %bb322, label %bb323
bb322:
  %t1267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1267, ptr %l583, !tbaa !29
  %t1268 = load ptr, ptr %l2, !tbaa !29
  %t1270 = getelementptr %"compiler/ast:If", ptr %t1268, i32 0, i32 0
  %t1271 = load ptr, ptr %t1270, !tbaa !29
  %t1273 = icmp eq ptr %t1271, null
  br i1 %t1273, label %bb324, label %bb325
bb323:
  %t1275 = load ptr, ptr %l0, !tbaa !29
  %t1277 = getelementptr %"compiler/check:Checker", ptr %t1275, i32 0, i32 33
  %t1279 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1277)
  store i64 %t1279, ptr %l607
  br label %bb332
bb324:
  call void @__olang_check_failed(ptr @olang_loc_7e262e55150b6580_229faafeaed7320c)
  unreachable
bb325:
  br label %bb326
bb326:
  %t1280 = load ptr, ptr %l2, !tbaa !29
  %t1282 = getelementptr %"compiler/ast:If", ptr %t1280, i32 0, i32 0
  %t1283 = load ptr, ptr %t1282, !tbaa !29
  %t1284 = load ptr, ptr %l583, !tbaa !29
  %t1287 = call { i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOf(ptr %v0, ptr %v1, ptr %t1284, ptr %t1283, i32 77)
  store { i64, i64 } %t1287, ptr %l590
  br label %bb327
bb327:
  %t1288 = load { i64, i64 }, ptr %l590
  store { i64, i64 } %t1288, ptr %l27
  %t1289 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 0
  %t1290 = load i64, ptr %t1289, !tbaa !24
  store i64 %t1290, ptr %l28, !tbaa !24
  %t1292 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 1
  %t1293 = load i64, ptr %t1292, !tbaa !24
  store i64 %t1293, ptr %l29, !tbaa !24
  %t1295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1295, ptr %l593, !tbaa !29
  %t1296 = load ptr, ptr %l26, !tbaa !29
  %t1298 = getelementptr %"compiler/ast:If", ptr %t1296, i32 0, i32 1
  %t1299 = load ptr, ptr %t1298, !tbaa !29
  %t1301 = icmp eq ptr %t1299, null
  br i1 %t1301, label %bb328, label %bb329
bb328:
  call void @__olang_check_failed(ptr @olang_loc_2f295e3784570d95_d107a97c68b54b41)
  unreachable
bb329:
  br label %bb330
bb330:
  %t1303 = load ptr, ptr %l26, !tbaa !29
  %t1305 = getelementptr %"compiler/ast:If", ptr %t1303, i32 0, i32 1
  %t1306 = load ptr, ptr %t1305, !tbaa !29
  %t1307 = load i64, ptr %l28, !tbaa !24
  %t1308 = load i64, ptr %l29, !tbaa !24
  %t1309 = load ptr, ptr %l2, !tbaa !29
  %t1311 = getelementptr %"compiler/ast:If", ptr %t1309, i32 0, i32 0
  %t1312 = load ptr, ptr %t1311, !tbaa !29
  %t1313 = load ptr, ptr %l593, !tbaa !29
  %t1318 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedBranch(ptr %v0, ptr %v1, ptr %v1, ptr %t1313, ptr %t1306, i64 %t1307, i64 %t1308, ptr %t1312, i1 false)
  store ptr %t1318, ptr %l603
  br label %bb331
bb331:
  %t1319 = load ptr, ptr %l603, !tbaa !29
  store ptr %t1319, ptr %l23, !tbaa !29
  br label %bb345
bb332:
  %t1321 = load i64, ptr %l607, !tbaa !24
  store i64 %t1321, ptr %l30, !tbaa !24
  %t1322 = load ptr, ptr %l0, !tbaa !29
  %t1323 = load %"compiler/source:Span", ptr %l25
  %t1327 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t1322, i32 1, %"compiler/source:Span" %t1323)
  store { i64, i64, i64 } %t1327, ptr %l611
  br label %bb333
bb333:
  %t1328 = load { i64, i64, i64 }, ptr %l611
  store { i64, i64, i64 } %t1328, ptr %l31
  %t1329 = getelementptr { i64, i64, i64 }, ptr %l31, i32 0, i32 0
  %t1330 = load i64, ptr %t1329, !tbaa !24
  store i64 %t1330, ptr %l32, !tbaa !24
  %t1332 = getelementptr { i64, i64, i64 }, ptr %l31, i32 0, i32 1
  %t1333 = load i64, ptr %t1332, !tbaa !24
  store i64 %t1333, ptr %l33, !tbaa !24
  %t1335 = getelementptr { i64, i64, i64 }, ptr %l31, i32 0, i32 2
  %t1336 = load i64, ptr %t1335, !tbaa !24
  store i64 %t1336, ptr %l34, !tbaa !24
  %t1338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1338, ptr %l615, !tbaa !29
  %t1339 = load ptr, ptr %l2, !tbaa !29
  %t1341 = getelementptr %"compiler/ast:If", ptr %t1339, i32 0, i32 0
  %t1342 = load ptr, ptr %t1341, !tbaa !29
  %t1344 = icmp eq ptr %t1342, null
  br i1 %t1344, label %bb334, label %bb335
bb334:
  call void @__olang_check_failed(ptr @olang_loc_243e81cb3c32d1ee_d10bd76f726657ba)
  unreachable
bb335:
  br label %bb336
bb336:
  %t1346 = load ptr, ptr %l2, !tbaa !29
  %t1348 = getelementptr %"compiler/ast:If", ptr %t1346, i32 0, i32 0
  %t1349 = load ptr, ptr %t1348, !tbaa !29
  %t1350 = load i64, ptr %l32, !tbaa !24
  %t1351 = load ptr, ptr %l615, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %t1351, ptr %t1349, i1 false, i64 %t1350)
  br label %bb337
bb337:
  %t1354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1354, ptr %l622, !tbaa !29
  %t1355 = load ptr, ptr %l2, !tbaa !29
  %t1357 = getelementptr %"compiler/ast:If", ptr %t1355, i32 0, i32 0
  %t1358 = load ptr, ptr %t1357, !tbaa !29
  %t1360 = icmp eq ptr %t1358, null
  br i1 %t1360, label %bb338, label %bb339
bb338:
  call void @__olang_check_failed(ptr @olang_loc_1de170122f32f713_27e6b5ec6f6061a7)
  unreachable
bb339:
  br label %bb340
bb340:
  %t1362 = load ptr, ptr %l2, !tbaa !29
  %t1364 = getelementptr %"compiler/ast:If", ptr %t1362, i32 0, i32 0
  %t1365 = load ptr, ptr %t1364, !tbaa !29
  %t1366 = load i64, ptr %l32, !tbaa !24
  %t1367 = load ptr, ptr %l622, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushErrNarrow(ptr %v0, ptr %v1, ptr %t1367, ptr %t1365, i1 false, i64 %t1366)
  br label %bb341
bb341:
  %t1370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1370, ptr %l629, !tbaa !29
  %t1371 = load ptr, ptr %l0, !tbaa !29
  %t1372 = load %"compiler/source:Span", ptr %l25
  %t1373 = load ptr, ptr %l26, !tbaa !29
  %t1377 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %t1371, %"compiler/source:Span" %t1372, ptr %t1373)
  store ptr %t1377, ptr %l633
  br label %bb342
bb342:
  %t1378 = load ptr, ptr %l629, !tbaa !29
  %t1379 = load ptr, ptr %l633, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1378, ptr %t1379)
  br label %bb343
bb343:
  %t1380 = load ptr, ptr %l0, !tbaa !29
  %t1381 = load i64, ptr %l32, !tbaa !24
  %t1382 = load i64, ptr %l33, !tbaa !24
  %t1383 = load i64, ptr %l34, !tbaa !24
  %t1384 = load i64, ptr %l30, !tbaa !24
  %t1390 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t1380, i64 %t1381, i64 %t1382, i64 %t1383, i64 %t1384)
  store ptr %t1390, ptr %l639
  br label %bb344
bb344:
  %t1391 = load ptr, ptr %l639, !tbaa !29
  store ptr %t1391, ptr %l23, !tbaa !29
  br label %bb345
bb345:
  br label %bb352
bb346:
  store %olang.scope zeroinitializer, ptr %s37
  %t1393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1393, ptr %l641, !tbaa !29
  %t1394 = load ptr, ptr %l2, !tbaa !29
  %t1396 = getelementptr %"compiler/ast:If", ptr %t1394, i32 0, i32 2
  %t1397 = load ptr, ptr %t1396, !tbaa !29
  %t1399 = icmp eq ptr %t1397, null
  br i1 %t1399, label %bb347, label %bb348
bb347:
  call void @__olang_check_failed(ptr @olang_loc_4c9c4b94d2908344_248110c0d01d3388)
  unreachable
bb348:
  br label %bb349
bb349:
  %t1401 = load ptr, ptr %l2, !tbaa !29
  %t1403 = getelementptr %"compiler/ast:If", ptr %t1401, i32 0, i32 2
  %t1404 = load ptr, ptr %t1403, !tbaa !29
  %t1406 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t1404)
  store %"compiler/source:Span" %t1406, ptr %l647
  br label %bb350
bb350:
  %t1407 = load ptr, ptr %l641, !tbaa !29
  %t1408 = load %"compiler/source:Span", ptr %l647
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s37, ptr %t1407, %"compiler/source:Span" %t1408, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d10, i32 0, i32 1) })
  br label %bb351
bb351:
  call void @__olang_scope_close(ptr %s37)
  br label %bb352
bb352:
  br label %bb353
bb353:
  %t1409 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1409, ptr %l648
  %t1410 = load ptr, ptr %l18, !tbaa !29
  %t1411 = load ptr, ptr %l22, !tbaa !29
  %t1412 = load ptr, ptr %l23, !tbaa !29
  %t1416 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1410, ptr %t1411, ptr %t1412)
  store %"compiler/typed:If" %t1416, ptr %l652
  br label %bb354
bb354:
  %t1417 = load %"compiler/typed:If", ptr %l652
  %t1418 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t1417, ptr %t1418
  store { i64, [3 x i64] } zeroinitializer, ptr %t1419
  %t1420 = getelementptr { i64, [3 x i64] }, ptr %t1419, i32 0, i32 0
  store i64 3, ptr %t1420
  %t1421 = load %"compiler/source:Span", ptr %l648
  %t1422 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1421, 0
  %t1424 = insertvalue { %"compiler/source:Span", ptr } %t1422, ptr %t1418, 1
  %t1425 = getelementptr { i64, [3 x i64] }, ptr %t1419, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1424, ptr %t1425
  %t1426 = load { i64, [3 x i64] }, ptr %t1419
  %t1428 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1426, ptr %t1428
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1428, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i1
  %l9 = alloca i1
  %l18 = alloca i32
  %l25 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i32
  %l43 = alloca i1
  %l45 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca i64
  %l60 = alloca i1
  %l68 = alloca ptr
  %l73 = alloca i32
  %l77 = alloca i1
  %l80 = alloca ptr
  %l85 = alloca i32
  %l89 = alloca i1
  %l92 = alloca ptr
  %l97 = alloca i32
  %l100 = alloca i1
  %l103 = alloca ptr
  %l108 = alloca i32
  %l112 = alloca i1
  %l117 = alloca ptr
  %l122 = alloca i32
  %l125 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l9, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l18
  br label %bb7
bb7:
  %t23 = load i32, ptr %l18
  store i32 %t23, ptr %l4
  %t24 = load i32, ptr %l4
  %t26 = trunc i64 18 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb35
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l25
  br label %bb11
bb11:
  %t39 = load i32, ptr %l25, !tbaa !23
  store i32 %t39, ptr %l5, !tbaa !23
  %t40 = load i32, ptr %l5, !tbaa !23
  %t42 = icmp eq i32 %t40, 0
  br i1 %t42, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 56
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l32
  br label %bb15
bb15:
  %t52 = load i1, ptr %l32, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 56
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H257d83b06934604763b32ef91c51c1d2(ptr %v0, ptr %t55, i32 %t56)
  %t60 = extractvalue { i32, i1 } %t59, 1
  %t61 = extractvalue { i32, i1 } %t59, 0
  store i32 %t61, ptr %l38
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb19, label %ok.63
ok.63:
  store i1 %t60, ptr %l37
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t64 = load i1, ptr %l37, !tbaa !21
  store i1 %t64, ptr %l33, !tbaa !21
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  store i1 true, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t65 = load i1, ptr %l33, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
bb22:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l5, !tbaa !23
  %t68 = load %"compiler/source:Span", ptr %l2
  %t69 = load i64, ptr %l3, !tbaa !24
  %t74 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMet(ptr %v0, ptr %t66, i32 %t67, %"compiler/source:Span" %t68, i64 %t69)
  store i1 %t74, ptr %l43
  br label %bb23
bb23:
  %t75 = load i1, ptr %l43, !tbaa !21
  store i1 %t75, ptr %l6, !tbaa !21
  %t76 = load i1, ptr %l6, !tbaa !21
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr %l1, !tbaa !23
  %t87 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l50
  br label %bb26
bb25:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb27
bb26:
  %t88 = load i1, ptr %l50, !tbaa !21
  store i1 %t88, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t89 = load i1, ptr %l45, !tbaa !21
  br i1 %t89, label %bb28, label %bb29
bb28:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l51, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l56
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t101 = load i32, ptr %l56, !tbaa !23
  %t102 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t101)
  store i64 %t102, ptr %l57
  br label %bb31
bb31:
  %t103 = load i32, ptr %l5, !tbaa !23
  %t104 = load %"compiler/source:Span", ptr %l2
  %t105 = load ptr, ptr %l51, !tbaa !29
  %t106 = load i64, ptr %l57, !tbaa !24
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebound(ptr %v0, ptr %t105, i64 %t106, i32 %t103, %"compiler/source:Span" %t104)
  store i1 %t109, ptr %l60
  br label %bb32
bb32:
  %t110 = load i1, ptr %l60, !tbaa !21
  store i1 %t110, ptr %l6, !tbaa !21
  br label %bb33
bb33:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 56
  %t114 = load i32, ptr %l1, !tbaa !23
  %t115 = load i1, ptr %l6, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t113, i32 %t114, i1 %t115)
  br label %bb34
bb34:
  %t119 = load i1, ptr %l6, !tbaa !21
  store i1 %t119, ptr %rv
  br label %ret
bb35:
  %t121 = load i32, ptr %l4
  %t123 = trunc i64 20 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l68, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l1, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l73
  br label %bb39
bb39:
  %t137 = load %"compiler/source:Span", ptr %l2
  %t138 = load i64, ptr %l3, !tbaa !24
  %t140 = add i64 %t138, 1
  %t141 = load ptr, ptr %l68, !tbaa !29
  %t142 = load i32, ptr %l73, !tbaa !23
  %t145 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %t141, i32 %t142, %"compiler/source:Span" %t137, i64 %t140)
  store i1 %t145, ptr %l77
  br label %bb40
bb40:
  %t146 = load i1, ptr %l77, !tbaa !21
  store i1 %t146, ptr %rv
  br label %ret
bb41:
  %t147 = load i32, ptr %l4
  %t149 = trunc i64 19 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l80, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/check:Checker", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 2
  %t159 = load i32, ptr %l1, !tbaa !23
  %t162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t158, i32 %t159)
  store i32 %t162, ptr %l85
  br label %bb45
bb45:
  %t163 = load %"compiler/source:Span", ptr %l2
  %t164 = load i64, ptr %l3, !tbaa !24
  %t166 = add i64 %t164, 1
  %t167 = load ptr, ptr %l80, !tbaa !29
  %t168 = load i32, ptr %l85, !tbaa !23
  %t171 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %t167, i32 %t168, %"compiler/source:Span" %t163, i64 %t166)
  store i1 %t171, ptr %l89
  br label %bb46
bb46:
  %t172 = load i1, ptr %l89, !tbaa !21
  store i1 %t172, ptr %rv
  br label %ret
bb47:
  %t173 = load i32, ptr %l4
  %t175 = trunc i64 21 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb58
bb50:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l92, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l1, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l97
  br label %bb51
bb51:
  %t189 = load %"compiler/source:Span", ptr %l2
  %t190 = load i64, ptr %l3, !tbaa !24
  %t191 = load ptr, ptr %l92, !tbaa !29
  %t192 = load i32, ptr %l97, !tbaa !23
  %t195 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMet(ptr %v0, ptr %t191, i32 %t192, %"compiler/source:Span" %t189, i64 %t190)
  store i1 %t195, ptr %l100
  br label %bb52
bb52:
  %t196 = load i1, ptr %l100, !tbaa !21
  %t197 = xor i1 %t196, true
  br i1 %t197, label %bb53, label %bb54
bb53:
  store i1 false, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l103, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/check:Checker", ptr %t201, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 2
  %t207 = load i32, ptr %l1, !tbaa !23
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t206, i32 %t207)
  store i32 %t210, ptr %l108
  br label %bb56
bb56:
  %t211 = load %"compiler/source:Span", ptr %l2
  %t212 = load i64, ptr %l3, !tbaa !24
  %t214 = add i64 %t212, 1
  %t215 = load ptr, ptr %l103, !tbaa !29
  %t216 = load i32, ptr %l108, !tbaa !23
  %t219 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %t215, i32 %t216, %"compiler/source:Span" %t211, i64 %t214)
  store i1 %t219, ptr %l112
  br label %bb57
bb57:
  %t220 = load i1, ptr %l112, !tbaa !21
  store i1 %t220, ptr %rv
  br label %ret
bb58:
  %t221 = load i32, ptr %l4
  %t223 = trunc i64 22 to i32
  %t224 = icmp eq i32 %t221, %t223
  br i1 %t224, label %bb59, label %bb60
bb59:
  br label %bb63
bb60:
  %t226 = load i32, ptr %l4
  %t228 = trunc i64 23 to i32
  %t229 = icmp eq i32 %t226, %t228
  br i1 %t229, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l117, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  %t238 = load i32, ptr %l1, !tbaa !23
  %t241 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t237, i32 %t238)
  store i32 %t241, ptr %l122
  br label %bb64
bb64:
  %t242 = load %"compiler/source:Span", ptr %l2
  %t243 = load i64, ptr %l3, !tbaa !24
  %t244 = load ptr, ptr %l117, !tbaa !29
  %t245 = load i32, ptr %l122, !tbaa !23
  %t248 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMet(ptr %v0, ptr %t244, i32 %t245, %"compiler/source:Span" %t242, i64 %t243)
  store i1 %t248, ptr %l125
  br label %bb65
bb65:
  %t249 = load i1, ptr %l125, !tbaa !21
  store i1 %t249, ptr %rv
  br label %ret
bb66:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i64 0)
  store i1 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoinStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i64
  %l57 = alloca ptr
  %l65 = alloca ptr
  %l68 = alloca i64
  %l71 = alloca i64
  %l75 = alloca { i64, i64, i64 }
  %l91 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l111 = alloca i64
  %l113 = alloca i64
  %l115 = alloca ptr
  %l118 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i32
  %l126 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca %"compiler/msgs:Msg"
  %l136 = alloca i64
  %l137 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l141 = alloca i64
  %l145 = alloca i64
  %l148 = alloca i64
  %l169 = alloca i32
  %l171 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca i32
  %l184 = alloca { i64, ptr }
  %l204 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l210 = alloca i1
  %l215 = alloca i64
  %l217 = alloca ptr
  %l220 = alloca { i64, ptr }
  %l222 = alloca %"compiler/source:Span"
  %l223 = alloca %"compiler/msgs:Msg"
  %l224 = alloca i64
  %l228 = alloca i64
  %l230 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca %"compiler/source:Span"
  %l237 = alloca %"compiler/msgs:Msg"
  %l238 = alloca i64
  %l241 = alloca i64
  %l243 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l247 = alloca i32
  %l256 = alloca { i64, ptr }
  %l269 = alloca i64
  %l282 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l300 = alloca ptr
  %l308 = alloca i64
  %l312 = alloca i64
  %l315 = alloca i64
  %l336 = alloca ptr
  %l340 = alloca i1
  %l344 = alloca ptr
  %l350 = alloca i1
  %l352 = alloca ptr
  %l355 = alloca { i64, ptr }
  %l358 = alloca %"compiler/source:Span"
  %l359 = alloca %"compiler/msgs:Msg"
  %l360 = alloca i64
  %l367 = alloca i64
  %l368 = alloca i64
  %l371 = alloca { i64, ptr }
  %l372 = alloca i64
  %l373 = alloca i32
  %l374 = alloca ptr
  %l384 = alloca %"compiler/source:Span"
  %l388 = alloca i64
  %l390 = alloca ptr
  %l391 = alloca %"compiler/source:Span"
  %l392 = alloca ptr
  %l394 = alloca i32
  %l395 = alloca { i64, ptr }
  %l397 = alloca %"compiler/msgs:Msg"
  %l398 = alloca i64
  %l401 = alloca ptr
  %l402 = alloca %"compiler/source:Span"
  %l403 = alloca ptr
  %l405 = alloca i1
  %l407 = alloca { i64, ptr }
  %l408 = alloca %"compiler/typed:Join"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %t726 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l57
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l57, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 30
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 38
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 35
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t17, i64 0)
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 36
  store ptr %t21, ptr %l65, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 37
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l68
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l65, !tbaa !29
  %t28 = load i64, ptr %l68, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t27, i64 %t28)
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 33
  %t33 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l71
  br label %bb5
bb5:
  %t34 = load i64, ptr %l71, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l1
  %t40 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t35, i32 5, %"compiler/source:Span" %t36)
  store { i64, i64, i64 } %t40, ptr %l75
  br label %bb6
bb6:
  %t41 = load { i64, i64, i64 }, ptr %l75
  store { i64, i64, i64 } %t41, ptr %l7
  %t42 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  %t45 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t48 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l10, !tbaa !24
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/ast:JoinS", ptr %t51, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb7, label %bb8
bb7:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:JoinS", ptr %t60, i32 0, i32 1
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l13, !tbaa !24
  br label %bb9
bb8:
  br label %bb16
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load i64, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l13, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t77 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t77, ptr %l91, !tbaa !27
  %t78 = load i64, ptr %l12, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t85 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t85, ptr %t83)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t90 = load i64, ptr %l12, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l12, !tbaa !24
  br label %bb9
bb15:
  br label %bb16
bb16:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l6, !tbaa !24
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t94, i64 %t95, i64 %t96, i64 %t97, i64 %t98)
  store ptr %t104, ptr %l104
  br label %bb17
bb17:
  %t105 = load ptr, ptr %l104, !tbaa !29
  store ptr %t105, ptr %l15, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t106)
  store ptr %t108, ptr %l106
  br label %bb18
bb18:
  %t109 = load ptr, ptr %l106, !tbaa !29
  store ptr %t109, ptr %l3, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t112 = getelementptr %"compiler/check:frame", ptr %t110, i32 0, i32 35
  store ptr %t112, ptr %l108, !tbaa !29
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t115 = getelementptr %"compiler/check:frame", ptr %t113, i32 0, i32 35
  %t117 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l111
  br label %bb19
bb19:
  %t118 = load i64, ptr %l111, !tbaa !24
  %t119 = sub i64 %t118, 1
  %t120 = load ptr, ptr %l108, !tbaa !29
  %t122 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t120, i64 %t119)
  store i64 %t122, ptr %l113
  br label %bb20
bb20:
  %t123 = load i64, ptr %l113, !tbaa !24
  store i64 %t123, ptr %l16, !tbaa !24
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t126 = getelementptr %"compiler/check:frame", ptr %t124, i32 0, i32 36
  store ptr %t126, ptr %l115, !tbaa !29
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 36
  %t131 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l118
  br label %bb21
bb21:
  %t132 = load i64, ptr %l118, !tbaa !24
  %t133 = sub i64 %t132, 1
  %t134 = load ptr, ptr %l115, !tbaa !29
  %t136 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t134, i64 %t133)
  store i64 %t136, ptr %l120
  br label %bb22
bb22:
  %t137 = load i64, ptr %l120, !tbaa !24
  store i64 %t137, ptr %l17, !tbaa !24
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = getelementptr %"compiler/check:frame", ptr %t138, i32 0, i32 35
  %t142 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t140)
  %t143 = extractvalue { i32, i64 } %t142, 1
  %t144 = extractvalue { i32, i64 } %t142, 0
  store i32 %t144, ptr %l125
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb24, label %ok.146
ok.146:
  store i64 %t143, ptr %l124
  br label %bb23
bb23:
  %t147 = load i64, ptr %l124, !tbaa !24
  store i64 %t147, ptr %l121, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  br label %bb26
bb26:
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 36
  %t152 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t150)
  %t153 = extractvalue { i32, i64 } %t152, 1
  %t154 = extractvalue { i32, i64 } %t152, 0
  store i32 %t154, ptr %l130
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb28, label %ok.156
ok.156:
  store i64 %t153, ptr %l129
  br label %bb27
bb27:
  %t157 = load i64, ptr %l129, !tbaa !24
  store i64 %t157, ptr %l126, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  br label %bb30
bb30:
  %t158 = load i64, ptr %l16, !tbaa !24
  %t160 = icmp eq i64 %t158, 0
  br i1 %t160, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l133, !tbaa !29
  %t163 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t163, ptr %l134
  %t164 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinWithoutSpawn(ptr %s7)
  store %"compiler/msgs:Msg" %t164, ptr %l135
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t165 = load ptr, ptr %l133, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l134
  %t167 = load %"compiler/msgs:Msg", ptr %l135
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t165, %"compiler/source:Span" %t166, %"compiler/msgs:Msg" %t167)
  store i64 %t168, ptr %l136
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t169 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t169, ptr %l137
  br label %bb36
bb36:
  %t170 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l137
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, ptr %l18
  %t171 = load i64, ptr %l17, !tbaa !24
  store i64 %t171, ptr %l19, !tbaa !24
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t175 = getelementptr %"compiler/check:frame", ptr %t173, i32 0, i32 37
  %t177 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l141
  br label %bb37
bb37:
  %t178 = load i64, ptr %l141, !tbaa !24
  store i64 %t178, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t179 = load i64, ptr %l20, !tbaa !24
  %t180 = load i64, ptr %l19, !tbaa !24
  %t183 = icmp sgt i64 %t179, %t180
  br i1 %t183, label %bb38, label %bb39
bb38:
  %t185 = load i64, ptr %l21, !tbaa !24
  %t187 = icmp sgt i64 %t185, 0
  br i1 %t187, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb43
bb40:
  %t189 = load i64, ptr %l20, !tbaa !24
  %t190 = load i64, ptr %l19, !tbaa !24
  %t193 = sub i64 %t189, %t190
  %t194 = load i64, ptr %l21, !tbaa !24
  %t197 = add i64 %t193, %t194
  %t199 = sub i64 %t197, 1
  %t200 = load i64, ptr %l21, !tbaa !24
  %t203 = sdiv i64 %t199, %t200
  store i64 %t203, ptr %l148, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb42
bb42:
  %t205 = load i64, ptr %l148, !tbaa !24
  store i64 %t205, ptr %l145, !tbaa !24
  br label %bb43
bb43:
  %t206 = load i64, ptr %l145, !tbaa !24
  store i64 %t206, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t207 = load i64, ptr %l23, !tbaa !24
  %t208 = load i64, ptr %l22, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb46:
  br label %bb47
bb47:
  %t215 = load i64, ptr %l19, !tbaa !24
  %t216 = load i64, ptr %l23, !tbaa !24
  %t217 = load i64, ptr %l21, !tbaa !24
  %t220 = mul i64 %t216, %t217
  %t223 = add i64 %t215, %t220
  %t225 = load ptr, ptr %l3, !tbaa !29
  %t227 = getelementptr %"compiler/check:frame", ptr %t225, i32 0, i32 37
  %t231 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t227, i64 %t223)
  store i32 %t231, ptr %l169
  br label %bb48
bb48:
  %t232 = load i32, ptr %l169, !tbaa !23
  store i32 %t232, ptr %l25, !tbaa !23
  store i1 false, ptr %l26, !tbaa !21
  store ptr %l18, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t234 = load ptr, ptr %l27, !tbaa !29
  %t235 = load i64, ptr %l28, !tbaa !24
  %t238 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %s0, ptr %t234, i64 %t235)
  %t239 = extractvalue { i32, { i64, ptr } } %t238, 1
  %t240 = extractvalue { i32, { i64, ptr } } %t238, 0
  store i32 %t240, ptr %l175
  %t241 = icmp ne i32 %t240, 0
  br i1 %t241, label %bb51, label %ok.242
ok.242:
  store { i64, ptr } %t239, ptr %l174
  br label %bb50
bb50:
  %t243 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t243, ptr %l171, !tbaa !27
  br label %bb55
bb51:
  %t244 = load i32, ptr %l175, !tbaa !23
  %t245 = ashr i32 %t244, 16
  %t247 = icmp eq i32 %t245, 1
  br i1 %t247, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_55f84e4449673261_62da473350726dd5)
  unreachable
bb54:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb55:
  %t249 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t249, ptr %l29, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  store i64 %t252, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s12
  %t254 = load i64, ptr %l31, !tbaa !24
  %t255 = load i64, ptr %l30, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb58:
  br label %bb59
bb59:
  %t262 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t262, ptr %l184, !tbaa !27
  %t263 = load i64, ptr %l31, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr i32, ptr %t266, i64 %t263
  %t268 = load i32, ptr %t267, !tbaa !33
  %t271 = load i32, ptr %l25, !tbaa !23
  %t274 = icmp eq i32 %t268, %t271
  br i1 %t274, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s12)
  br label %bb63
bb63:
  %t276 = load i64, ptr %l31, !tbaa !24
  %t278 = add i64 %t276, 1
  store i64 %t278, ptr %l31, !tbaa !24
  br label %bb56
bb64:
  %t280 = load i64, ptr %l28, !tbaa !24
  %t281 = load i64, ptr %l30, !tbaa !24
  %t284 = add i64 %t280, %t281
  store i64 %t284, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb65:
  br label %bb49
bb66:
  %t286 = load i1, ptr %l26, !tbaa !21
  %t288 = xor i1 %t286, true
  br i1 %t288, label %bb67, label %bb68
bb67:
  %t290 = load i32, ptr %l25, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18, i32 %t290)
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s9)
  br label %bb71
bb71:
  %t293 = load i64, ptr %l23, !tbaa !24
  %t295 = add i64 %t293, 1
  store i64 %t295, ptr %l23, !tbaa !24
  br label %bb44
bb72:
  %t297 = load ptr, ptr %l3, !tbaa !29
  %t299 = getelementptr %"compiler/check:frame", ptr %t297, i32 0, i32 37
  %t300 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %t299, i64 %t300)
  br label %bb73
bb73:
  %t303 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t303, ptr %l204
  br label %bb74
bb74:
  %t304 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l204
  %t305 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t304, ptr %t305
  store ptr %t305, ptr %l33, !tbaa !29
  %t307 = load ptr, ptr %l2, !tbaa !29
  %t309 = getelementptr %"compiler/ast:JoinS", ptr %t307, i32 0, i32 2
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t314 = icmp sgt i64 %t312, 0
  br i1 %t314, label %bb75, label %bb76
bb75:
  %t316 = load ptr, ptr %l2, !tbaa !29
  %t318 = getelementptr %"compiler/ast:JoinS", ptr %t316, i32 0, i32 0
  %t319 = load i1, ptr %t318, !tbaa !21
  %t321 = xor i1 %t319, true
  store i1 %t321, ptr %l210, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb77
bb77:
  %t323 = load i1, ptr %l210, !tbaa !21
  br i1 %t323, label %bb78, label %bb79
bb78:
  %t325 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t325, ptr %l215
  br label %bb80
bb79:
  br label %bb87
bb80:
  %t326 = load i64, ptr %l215, !tbaa !24
  %t327 = icmp eq i64 %t326, 0
  br i1 %t327, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s18
  %t329 = load ptr, ptr %l0, !tbaa !29
  store ptr %t329, ptr %l217, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l2, !tbaa !29
  %t333 = getelementptr %"compiler/ast:JoinS", ptr %t331, i32 0, i32 2
  %t334 = load { i64, ptr }, ptr %t333, !tbaa !27
  store { i64, ptr } %t334, ptr %l220, !tbaa !27
  %t335 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr ptr, ptr %t336, i64 0
  %t338 = load ptr, ptr %t337, !tbaa !39
  %t341 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t330, ptr %t338)
  store %"compiler/source:Span" %t341, ptr %l222
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t342 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCatchNeedsTry(ptr %s18)
  store %"compiler/msgs:Msg" %t342, ptr %l223
  br label %bb84
bb84:
  %t343 = load ptr, ptr %l217, !tbaa !29
  %t344 = load %"compiler/source:Span", ptr %l222
  %t345 = load %"compiler/msgs:Msg", ptr %l223
  %t346 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t343, %"compiler/source:Span" %t344, %"compiler/msgs:Msg" %t345)
  store i64 %t346, ptr %l224
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s18)
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t347 = load ptr, ptr %l2, !tbaa !29
  %t349 = getelementptr %"compiler/ast:JoinS", ptr %t347, i32 0, i32 0
  %t350 = load i1, ptr %t349, !tbaa !21
  br i1 %t350, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s19
  %t353 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t353, ptr %l228
  br label %bb90
bb89:
  %t355 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t355, ptr %l388
  br label %bb169
bb90:
  %t356 = load i64, ptr %l228, !tbaa !24
  %t357 = icmp eq i64 %t356, 0
  br i1 %t357, label %bb91, label %bb92
bb91:
  %t359 = load ptr, ptr %l3, !tbaa !29
  %t361 = getelementptr %"compiler/check:frame", ptr %t359, i32 0, i32 38
  %t362 = load i64, ptr %t361, !tbaa !24
  %t363 = load i64, ptr %l5, !tbaa !24
  %t366 = icmp eq i64 %t362, %t363
  store i1 %t366, ptr %l230, !tbaa !21
  br label %bb93
bb92:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb93
bb93:
  %t368 = load i1, ptr %l230, !tbaa !21
  br i1 %t368, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s20
  %t369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t369, ptr %l235, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t370, ptr %l236
  %t371 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCannotFail(ptr %s20)
  store %"compiler/msgs:Msg" %t371, ptr %l237
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t372 = load ptr, ptr %l235, !tbaa !29
  %t373 = load %"compiler/source:Span", ptr %l236
  %t374 = load %"compiler/msgs:Msg", ptr %l237
  %t375 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s20, ptr %t372, %"compiler/source:Span" %t373, %"compiler/msgs:Msg" %t374)
  store i64 %t375, ptr %l238
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s20)
  br label %bb98
bb98:
  %t376 = load ptr, ptr %l3, !tbaa !29
  %t378 = getelementptr %"compiler/check:frame", ptr %t376, i32 0, i32 25
  %t380 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t378)
  store i64 %t380, ptr %l241
  br label %bb99
bb99:
  %t381 = load i64, ptr %l241, !tbaa !24
  store i64 %t381, ptr %l34, !tbaa !24
  store ptr %l18, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s22
  %t383 = load ptr, ptr %l35, !tbaa !29
  %t384 = load i64, ptr %l36, !tbaa !24
  %t387 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %s0, ptr %t383, i64 %t384)
  %t388 = extractvalue { i32, { i64, ptr } } %t387, 1
  %t389 = extractvalue { i32, { i64, ptr } } %t387, 0
  store i32 %t389, ptr %l247
  %t390 = icmp ne i32 %t389, 0
  br i1 %t390, label %bb102, label %ok.391
ok.391:
  store { i64, ptr } %t388, ptr %l246
  br label %bb101
bb101:
  %t392 = load { i64, ptr }, ptr %l246, !tbaa !27
  store { i64, ptr } %t392, ptr %l243, !tbaa !27
  br label %bb106
bb102:
  %t393 = load i32, ptr %l247, !tbaa !23
  %t394 = ashr i32 %t393, 16
  %t396 = icmp eq i32 %t394, 1
  br i1 %t396, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_a0600b9a17fc9cd0_1e19997b248853e4)
  unreachable
bb105:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s22)
  br label %bb115
bb106:
  %t398 = load { i64, ptr }, ptr %l243, !tbaa !27
  store { i64, ptr } %t398, ptr %l37, !tbaa !27
  %t399 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t399, 0
  store i64 %t401, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s23
  %t403 = load i64, ptr %l39, !tbaa !24
  %t404 = load i64, ptr %l38, !tbaa !24
  %t407 = icmp slt i64 %t403, %t404
  %t409 = xor i1 %t407, true
  br i1 %t409, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s23)
  br label %bb113
bb109:
  br label %bb110
bb110:
  %t411 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t411, ptr %l256, !tbaa !27
  %t412 = load i64, ptr %l39, !tbaa !24
  %t414 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t415 = load ptr, ptr %t414, !tbaa !27
  %t416 = getelementptr i32, ptr %t415, i64 %t412
  %t417 = load i32, ptr %t416, !tbaa !33
  %t419 = load ptr, ptr %l3, !tbaa !29
  %t421 = getelementptr %"compiler/check:frame", ptr %t419, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t421, i32 %t417)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s23)
  br label %bb112
bb112:
  %t425 = load i64, ptr %l39, !tbaa !24
  %t427 = add i64 %t425, 1
  store i64 %t427, ptr %l39, !tbaa !24
  br label %bb107
bb113:
  %t429 = load i64, ptr %l36, !tbaa !24
  %t430 = load i64, ptr %l38, !tbaa !24
  %t433 = add i64 %t429, %t430
  store i64 %t433, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb114
bb114:
  br label %bb100
bb115:
  %t435 = load ptr, ptr %l3, !tbaa !29
  %t437 = getelementptr %"compiler/check:frame", ptr %t435, i32 0, i32 25
  %t439 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t437)
  store i64 %t439, ptr %l269
  br label %bb116
bb116:
  %t440 = load i64, ptr %l269, !tbaa !24
  store i64 %t440, ptr %l41, !tbaa !24
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load ptr, ptr %l2, !tbaa !29
  %t444 = getelementptr %"compiler/ast:JoinS", ptr %t442, i32 0, i32 2
  %t445 = load { i64, ptr }, ptr %t444, !tbaa !27
  %t446 = load i64, ptr %l34, !tbaa !24
  %t447 = load i64, ptr %l41, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %t441, { i64, ptr } %t445, i64 %t446, i64 %t447)
  br label %bb117
bb117:
  %t452 = load ptr, ptr %l2, !tbaa !29
  %t454 = getelementptr %"compiler/ast:JoinS", ptr %t452, i32 0, i32 2
  %t455 = load { i64, ptr }, ptr %t454, !tbaa !27
  %t457 = extractvalue { i64, ptr } %t455, 0
  %t459 = icmp sgt i64 %t457, 0
  br i1 %t459, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s25
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load i64, ptr %l34, !tbaa !24
  %t463 = load i64, ptr %l41, !tbaa !24
  %t467 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %s25, ptr %t461, i64 %t462, i64 %t463)
  store { i64, ptr } %t467, ptr %l282
  br label %bb120
bb119:
  br label %bb160
bb120:
  %t468 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t468, ptr %l42, !tbaa !27
  %t469 = load ptr, ptr %l2, !tbaa !29
  %t471 = getelementptr %"compiler/ast:JoinS", ptr %t469, i32 0, i32 2
  %t472 = load { i64, ptr }, ptr %t471, !tbaa !27
  store { i64, ptr } %t472, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t474 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t476 = extractvalue { i64, ptr } %t474, 0
  store i64 %t476, ptr %l45, !tbaa !24
  br label %bb121
bb121:
  store %olang.scope zeroinitializer, ptr %s27
  %t478 = load i64, ptr %l44, !tbaa !24
  %t479 = load i64, ptr %l45, !tbaa !24
  %t482 = icmp slt i64 %t478, %t479
  %t484 = xor i1 %t482, true
  br i1 %t484, label %bb122, label %bb123
bb122:
  call void @__olang_scope_close(ptr %s27)
  br label %bb128
bb123:
  br label %bb124
bb124:
  %t486 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t486, ptr %l291, !tbaa !27
  %t487 = load i64, ptr %l44, !tbaa !24
  %t489 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = getelementptr ptr, ptr %t490, i64 %t487
  %t492 = load ptr, ptr %t491, !tbaa !39
  %t494 = load ptr, ptr %l33, !tbaa !29
  store ptr %t494, ptr %l294, !tbaa !29
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t498 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t499 = load ptr, ptr %l33, !tbaa !29
  %t505 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %s25, ptr %v0, ptr %t495, ptr %t492, i32 %t497, i1 false, { i64, ptr } %t498, ptr %t499)
  store ptr %t505, ptr %l300
  br label %bb125
bb125:
  %t506 = load ptr, ptr %l294, !tbaa !29
  %t507 = load ptr, ptr %l300, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eP_Hee51906bde9346e7b7b6808fdce5ba81(ptr %v0, ptr %v0, ptr %t506, ptr %t507)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s27)
  br label %bb127
bb127:
  %t508 = load i64, ptr %l44, !tbaa !24
  %t510 = add i64 %t508, 1
  store i64 %t510, ptr %l44, !tbaa !24
  br label %bb121
bb128:
  %t512 = load ptr, ptr %l3, !tbaa !29
  %t514 = getelementptr %"compiler/check:frame", ptr %t512, i32 0, i32 30
  %t515 = load i64, ptr %t514, !tbaa !24
  %t516 = load i64, ptr %l4, !tbaa !24
  %t519 = icmp sgt i64 %t515, %t516
  br i1 %t519, label %bb129, label %bb130
bb129:
  store i64 0, ptr %l47, !tbaa !24
  %t521 = load ptr, ptr %l33, !tbaa !29
  %t523 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eL_H39694dc3b7c161b4999ab170e8f3fd84(ptr %v0, ptr %t521)
  store i64 %t523, ptr %l308
  br label %bb131
bb130:
  br label %bb159
bb131:
  %t524 = load i64, ptr %l308, !tbaa !24
  store i64 %t524, ptr %l48, !tbaa !24
  store i64 1, ptr %l49, !tbaa !24
  %t525 = load i64, ptr %l48, !tbaa !24
  %t526 = load i64, ptr %l47, !tbaa !24
  %t529 = icmp sgt i64 %t525, %t526
  br i1 %t529, label %bb132, label %bb133
bb132:
  %t531 = load i64, ptr %l49, !tbaa !24
  %t533 = icmp sgt i64 %t531, 0
  br i1 %t533, label %bb134, label %bb135
bb133:
  store i64 0, ptr %l312, !tbaa !24
  br label %bb137
bb134:
  %t535 = load i64, ptr %l48, !tbaa !24
  %t536 = load i64, ptr %l47, !tbaa !24
  %t539 = sub i64 %t535, %t536
  %t540 = load i64, ptr %l49, !tbaa !24
  %t543 = add i64 %t539, %t540
  %t545 = sub i64 %t543, 1
  %t546 = load i64, ptr %l49, !tbaa !24
  %t549 = sdiv i64 %t545, %t546
  store i64 %t549, ptr %l315, !tbaa !24
  br label %bb136
bb135:
  store i64 0, ptr %l315, !tbaa !24
  br label %bb136
bb136:
  %t551 = load i64, ptr %l315, !tbaa !24
  store i64 %t551, ptr %l312, !tbaa !24
  br label %bb137
bb137:
  %t552 = load i64, ptr %l312, !tbaa !24
  store i64 %t552, ptr %l50, !tbaa !24
  store i64 0, ptr %l51, !tbaa !24
  br label %bb138
bb138:
  store %olang.scope zeroinitializer, ptr %s31
  %t553 = load i64, ptr %l51, !tbaa !24
  %t554 = load i64, ptr %l50, !tbaa !24
  %t557 = icmp slt i64 %t553, %t554
  %t559 = xor i1 %t557, true
  br i1 %t559, label %bb139, label %bb140
bb139:
  call void @__olang_scope_close(ptr %s31)
  br label %bb158
bb140:
  br label %bb141
bb141:
  %t561 = load i64, ptr %l47, !tbaa !24
  %t562 = load i64, ptr %l51, !tbaa !24
  %t563 = load i64, ptr %l49, !tbaa !24
  %t566 = mul i64 %t562, %t563
  %t569 = add i64 %t561, %t566
  store i64 %t569, ptr %l52, !tbaa !24
  %t571 = load ptr, ptr %l33, !tbaa !29
  %t573 = load i64, ptr %l52, !tbaa !24
  %t576 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v0, ptr %v0, ptr %t571, i64 %t573)
  store ptr %t576, ptr %l336
  br label %bb142
bb142:
  %t577 = load ptr, ptr %l336, !tbaa !29
  %t579 = getelementptr %"compiler/typed:Clause", ptr %t577, i32 0, i32 3
  %t580 = load ptr, ptr %t579, !tbaa !29
  %t582 = icmp eq ptr %t580, null
  br i1 %t582, label %bb143, label %bb144
bb143:
  store i1 true, ptr %l340, !tbaa !21
  br label %bb150
bb144:
  %t584 = load ptr, ptr %l33, !tbaa !29
  %t586 = load i64, ptr %l52, !tbaa !24
  %t589 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v0, ptr %v0, ptr %t584, i64 %t586)
  store ptr %t589, ptr %l344
  br label %bb145
bb145:
  %t590 = load ptr, ptr %l344, !tbaa !29
  %t592 = getelementptr %"compiler/typed:Clause", ptr %t590, i32 0, i32 3
  %t593 = load ptr, ptr %t592, !tbaa !29
  store ptr %t593, ptr %l53, !tbaa !29
  %t595 = load ptr, ptr %l53, !tbaa !29
  %t597 = icmp eq ptr %t595, null
  br i1 %t597, label %bb146, label %bb147
bb146:
  call void @__olang_check_failed(ptr @olang_loc_3aadc4e023da3b64_af78beb3670ebce8)
  unreachable
bb147:
  br label %bb148
bb148:
  %t599 = load ptr, ptr %l53, !tbaa !29
  %t601 = call i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %t599)
  store i1 %t601, ptr %l350
  br label %bb149
bb149:
  %t602 = load i1, ptr %l350, !tbaa !21
  %t603 = xor i1 %t602, true
  store i1 %t603, ptr %l340, !tbaa !21
  br label %bb150
bb150:
  %t605 = load i1, ptr %l340, !tbaa !21
  br i1 %t605, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s32
  %t606 = load ptr, ptr %l0, !tbaa !29
  store ptr %t606, ptr %l352, !tbaa !29
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t608 = load ptr, ptr %l2, !tbaa !29
  %t610 = getelementptr %"compiler/ast:JoinS", ptr %t608, i32 0, i32 2
  %t611 = load { i64, ptr }, ptr %t610, !tbaa !27
  store { i64, ptr } %t611, ptr %l355, !tbaa !27
  %t612 = load i64, ptr %l52, !tbaa !24
  %t614 = getelementptr { i64, ptr }, ptr %l355, i32 0, i32 1
  %t615 = load ptr, ptr %t614, !tbaa !27
  %t616 = getelementptr ptr, ptr %t615, i64 %t612
  %t617 = load ptr, ptr %t616, !tbaa !39
  %t620 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t607, ptr %t617)
  store %"compiler/source:Span" %t620, ptr %l358
  br label %bb153
bb152:
  br label %bb156
bb153:
  %t621 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinClauseMustLeave(ptr %s32)
  store %"compiler/msgs:Msg" %t621, ptr %l359
  br label %bb154
bb154:
  %t622 = load ptr, ptr %l352, !tbaa !29
  %t623 = load %"compiler/source:Span", ptr %l358
  %t624 = load %"compiler/msgs:Msg", ptr %l359
  %t625 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s32, ptr %t622, %"compiler/source:Span" %t623, %"compiler/msgs:Msg" %t624)
  store i64 %t625, ptr %l360
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s31)
  br label %bb158
bb156:
  call void @__olang_scope_close(ptr %s31)
  br label %bb157
bb157:
  %t626 = load i64, ptr %l51, !tbaa !24
  %t628 = add i64 %t626, 1
  store i64 %t628, ptr %l51, !tbaa !24
  br label %bb138
bb158:
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s25)
  br label %bb160
bb160:
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t631 = load i64, ptr %l34, !tbaa !24
  %t632 = load i64, ptr %l41, !tbaa !24
  %t633 = load ptr, ptr %l33, !tbaa !29
  %t638 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v0, ptr %t630, i64 %t631, i64 %t632, ptr %t633)
  store i64 %t638, ptr %l367
  br label %bb161
bb161:
  %t639 = load i64, ptr %l367, !tbaa !24
  store i64 %t639, ptr %l54, !tbaa !24
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t641 = load %"compiler/source:Span", ptr %l1
  %t644 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t640, %"compiler/source:Span" %t641)
  store { i64, ptr } %t644, ptr %l371
  br label %bb162
bb162:
  %t645 = load { i64, ptr }, ptr %l371, !tbaa !27
  %t646 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s19, { i64, ptr } %t645, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) })
  %t647 = extractvalue { i32, i64 } %t646, 1
  %t648 = extractvalue { i32, i64 } %t646, 0
  store i32 %t648, ptr %l373
  %t649 = icmp ne i32 %t648, 0
  br i1 %t649, label %bb164, label %ok.650
ok.650:
  store i64 %t647, ptr %l372
  br label %bb163
bb163:
  %t651 = load i64, ptr %l372, !tbaa !24
  store i64 %t651, ptr %l368, !tbaa !24
  br label %bb166
bb164:
  br label %bb165
bb165:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l368, !tbaa !24
  br label %bb166
bb166:
  %t652 = load i64, ptr %l368, !tbaa !24
  store i64 %t652, ptr %l55, !tbaa !24
  %t653 = load ptr, ptr %l0, !tbaa !29
  store ptr %t653, ptr %l374, !tbaa !29
  %t654 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t655 = load i32, ptr %t654, !tbaa !23
  %t656 = load i64, ptr %l55, !tbaa !24
  %t658 = trunc i64 %t656 to i32
  %t661 = add i32 %t655, %t658
  %t662 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t663 = load i32, ptr %t662, !tbaa !23
  %t664 = load i64, ptr %l55, !tbaa !24
  %t666 = trunc i64 %t664 to i32
  %t669 = add i32 %t663, %t666
  %t671 = add i32 %t669, 4
  %t674 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s19, i32 %t661, i32 %t671)
  store %"compiler/source:Span" %t674, ptr %l384
  br label %bb167
bb167:
  %t675 = load i64, ptr %l34, !tbaa !24
  %t676 = load i64, ptr %l54, !tbaa !24
  %t677 = load ptr, ptr %l374, !tbaa !29
  %t678 = load %"compiler/source:Span", ptr %l384
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %t677, %"compiler/source:Span" %t678, i64 %t675, i64 %t676)
  br label %bb168
bb168:
  call void @__olang_scope_close(ptr %s19)
  br label %bb177
bb169:
  %t681 = load i64, ptr %l388, !tbaa !24
  %t682 = icmp sgt i64 %t681, 0
  br i1 %t682, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s35
  %t684 = load ptr, ptr %l0, !tbaa !29
  store ptr %t684, ptr %l390, !tbaa !29
  %t685 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t685, ptr %l391
  %t686 = load ptr, ptr %l0, !tbaa !29
  store ptr %t686, ptr %l392, !tbaa !29
  %t688 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18, i64 0)
  store i32 %t688, ptr %l394
  br label %bb172
bb171:
  br label %bb176
bb172:
  %t689 = load ptr, ptr %l392, !tbaa !29
  %t690 = load i32, ptr %l394, !tbaa !23
  %t691 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s35, ptr %t689, i32 %t690)
  store { i64, ptr } %t691, ptr %l395
  br label %bb173
bb173:
  %t692 = load { i64, ptr }, ptr %l395, !tbaa !27
  %t693 = extractvalue { i64, ptr } %t692, 0
  %t694 = extractvalue { i64, ptr } %t692, 1
  %t695 = mul i64 %t693, 1
  %t696 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t695)
  call void @llvm.memcpy.p0.p0.i64(ptr %t696, ptr %t694, i64 %t695, i1 false)
  %t697 = insertvalue { i64, ptr } undef, i64 %t693, 0
  %t698 = insertvalue { i64, ptr } %t697, ptr %t696, 1
  %t700 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNotTried(ptr %s35, ptr %s35, { i64, ptr } %t698)
  store %"compiler/msgs:Msg" %t700, ptr %l397
  br label %bb174
bb174:
  %t701 = load ptr, ptr %l390, !tbaa !29
  %t702 = load %"compiler/source:Span", ptr %l391
  %t703 = load %"compiler/msgs:Msg", ptr %l397
  %t704 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s35, ptr %t701, %"compiler/source:Span" %t702, %"compiler/msgs:Msg" %t703)
  store i64 %t704, ptr %l398
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s35)
  br label %bb176
bb176:
  br label %bb177
bb177:
  %t705 = load ptr, ptr %l3, !tbaa !29
  %t706 = load i64, ptr %l4, !tbaa !24
  %t709 = getelementptr %"compiler/check:frame", ptr %t705, i32 0, i32 30
  store i64 %t706, ptr %t709, !tbaa !24
  %t710 = load ptr, ptr %l0, !tbaa !29
  store ptr %t710, ptr %l401, !tbaa !29
  %t711 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t711, ptr %l402
  %t712 = load ptr, ptr %l15, !tbaa !29
  store ptr %t712, ptr %l403, !tbaa !29
  %t713 = load ptr, ptr %l2, !tbaa !29
  %t715 = getelementptr %"compiler/ast:JoinS", ptr %t713, i32 0, i32 0
  %t716 = load i1, ptr %t715, !tbaa !21
  store i1 %t716, ptr %l405, !tbaa !21
  %t717 = load ptr, ptr %l33, !tbaa !29
  %t719 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eT_H39fa81f2ad510245a68cbacb663c8d87(ptr %v0, ptr %v0, ptr %t717)
  store { i64, ptr } %t719, ptr %l407
  br label %bb178
bb178:
  %t720 = load ptr, ptr %l403, !tbaa !29
  %t721 = load i1, ptr %l405, !tbaa !21
  %t722 = load { i64, ptr }, ptr %l407, !tbaa !27
  %t723 = call %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t720, i1 %t721, { i64, ptr } %t722)
  store %"compiler/typed:Join" %t723, ptr %l408
  br label %bb179
bb179:
  %t724 = load %"compiler/typed:Join", ptr %l408
  %t725 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Join" %t724, ptr %t725
  store { i64, [3 x i64] } zeroinitializer, ptr %t726
  %t727 = getelementptr { i64, [3 x i64] }, ptr %t726, i32 0, i32 0
  store i64 13, ptr %t727
  %t728 = load %"compiler/source:Span", ptr %l402
  %t729 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t728, 0
  %t731 = insertvalue { %"compiler/source:Span", ptr } %t729, ptr %t725, 1
  %t732 = getelementptr { i64, [3 x i64] }, ptr %t726, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t731, ptr %t732
  %t733 = load { i64, [3 x i64] }, ptr %t726
  %t735 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t733, ptr %t735
  %t736 = load ptr, ptr %l401, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t736, ptr %t735)
  br label %bb180
bb180:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejump(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l9 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca %"compiler/msgs:Msg"
  %l28 = alloca i64
  %l32 = alloca i1
  %l35 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca %"compiler/msgs:Msg"
  %l50 = alloca i64
  %l54 = alloca i1
  %l57 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"compiler/msgs:Msg"
  %l68 = alloca i64
  %l71 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l79 = alloca %"compiler/msgs:Msg"
  %l80 = alloca i64
  %l82 = alloca ptr
  %l85 = alloca i64
  %l87 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l92 = alloca %"compiler/msgs:Msg"
  %l93 = alloca i64
  %l97 = alloca ptr
  %l100 = alloca i64
  %l102 = alloca i64
  %l105 = alloca i32
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca i32
  %l123 = alloca ptr
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t228 = alloca { i64, [3 x i64] }, align 8
  %t254 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2
  %t3 = trunc i64 19 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l9, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t12)
  store ptr %t14, ptr %l13
  br label %bb6
bb5:
  br label %bb65
bb6:
  %t15 = load ptr, ptr %l13, !tbaa !29
  store ptr %t15, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t16, i32 0, i32 10
  %t20 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l16
  br label %bb7
bb7:
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = icmp eq i64 %t21, 0
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t24, i32 0, i32 29
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t31, ptr %l22
  %t32 = load i32, ptr %l2
  %t34 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t32)
  store { i64, ptr } %t34, ptr %l24
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t35 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t36 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s2, ptr %s2, { i64, ptr } %t35)
  store { i64, ptr } %t36, ptr %l25
  br label %bb14
bb14:
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = mul i64 %t38, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseLoopJump(ptr %s2, ptr %s2, { i64, ptr } %t43)
  store %"compiler/msgs:Msg" %t45, ptr %l27
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l22
  %t48 = load %"compiler/msgs:Msg", ptr %l27
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t46, %"compiler/source:Span" %t47, %"compiler/msgs:Msg" %t48)
  store i64 %t49, ptr %l28
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb17:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 32
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp sge i64 %t53, 0
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 10
  %t61 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t59)
  store i64 %t61, ptr %l35
  br label %bb20
bb19:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb21
bb20:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/check:frame", ptr %t62, i32 0, i32 32
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = load i64, ptr %l35, !tbaa !24
  %t68 = icmp sle i64 %t66, %t65
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t70 = load i1, ptr %l32, !tbaa !21
  br i1 %t70, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t72, ptr %l40
  %t73 = load i32, ptr %l2
  %t75 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s3, i32 %t73)
  store { i64, ptr } %t75, ptr %l42
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t76 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t77 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s3, ptr %s3, { i64, ptr } %t76)
  store { i64, ptr } %t77, ptr %l43
  br label %bb25
bb25:
  %t78 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l44, !tbaa !27
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/check:frame", ptr %t86, i32 0, i32 33
  %t89 = load i1, ptr %t88, !tbaa !21
  %t92 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %s3, ptr %t85, i1 %t89)
  store { i64, ptr } %t92, ptr %l48
  br label %bb26
bb26:
  %t93 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t95 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgLoopJump(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t93, { i64, ptr } %t94)
  store %"compiler/msgs:Msg" %t95, ptr %l49
  br label %bb27
bb27:
  %t96 = load ptr, ptr %l39, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l40
  %t98 = load %"compiler/msgs:Msg", ptr %l49
  %t99 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t96, %"compiler/source:Span" %t97, %"compiler/msgs:Msg" %t98)
  store i64 %t99, ptr %l50
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb29:
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t102 = getelementptr %"compiler/check:frame", ptr %t100, i32 0, i32 31
  %t103 = load i64, ptr %t102, !tbaa !24
  %t105 = icmp sge i64 %t103, 0
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t109 = getelementptr %"compiler/check:frame", ptr %t107, i32 0, i32 10
  %t111 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l57
  br label %bb32
bb31:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb33
bb32:
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t114 = getelementptr %"compiler/check:frame", ptr %t112, i32 0, i32 31
  %t115 = load i64, ptr %t114, !tbaa !24
  %t116 = load i64, ptr %l57, !tbaa !24
  %t118 = icmp sle i64 %t116, %t115
  store i1 %t118, ptr %l54, !tbaa !21
  br label %bb33
bb33:
  %t120 = load i1, ptr %l54, !tbaa !21
  br i1 %t120, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s4
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l61, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t122, ptr %l62
  %t123 = load i32, ptr %l2
  %t125 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t123)
  store { i64, ptr } %t125, ptr %l64
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t126 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t127 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s4, ptr %s4, { i64, ptr } %t126)
  store { i64, ptr } %t127, ptr %l65
  br label %bb37
bb37:
  %t128 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferLoopJump(ptr %s4, ptr %s4, { i64, ptr } %t134)
  store %"compiler/msgs:Msg" %t136, ptr %l67
  br label %bb38
bb38:
  %t137 = load ptr, ptr %l61, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l62
  %t139 = load %"compiler/msgs:Msg", ptr %l67
  %t140 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t137, %"compiler/source:Span" %t138, %"compiler/msgs:Msg" %t139)
  store i64 %t140, ptr %l68
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb40:
  %t141 = load ptr, ptr %l4, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t141, i32 0, i32 10
  %t145 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t143)
  store i64 %t145, ptr %l71
  br label %bb41
bb41:
  %t146 = load i64, ptr %l71, !tbaa !24
  %t147 = icmp eq i64 %t146, 0
  br i1 %t147, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s5
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l73, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t150, ptr %l74
  %t151 = load i32, ptr %l2
  %t153 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s5, i32 %t151)
  store { i64, ptr } %t153, ptr %l76
  br label %bb44
bb43:
  br label %bb48
bb44:
  %t154 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t155 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s5, ptr %s5, { i64, ptr } %t154)
  store { i64, ptr } %t155, ptr %l77
  br label %bb45
bb45:
  %t156 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t164 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBreakOutsideLoop(ptr %s5, ptr %s5, { i64, ptr } %t162)
  store %"compiler/msgs:Msg" %t164, ptr %l79
  br label %bb46
bb46:
  %t165 = load ptr, ptr %l73, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l74
  %t167 = load %"compiler/msgs:Msg", ptr %l79
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t165, %"compiler/source:Span" %t166, %"compiler/msgs:Msg" %t167)
  store i64 %t168, ptr %l80
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %ret
bb48:
  %t169 = load ptr, ptr %l4, !tbaa !29
  %t171 = getelementptr %"compiler/check:frame", ptr %t169, i32 0, i32 10
  store ptr %t171, ptr %l82, !tbaa !29
  %t172 = load ptr, ptr %l4, !tbaa !29
  %t174 = getelementptr %"compiler/check:frame", ptr %t172, i32 0, i32 10
  %t176 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t174)
  store i64 %t176, ptr %l85
  br label %bb49
bb49:
  %t177 = load i64, ptr %l85, !tbaa !24
  %t178 = sub i64 %t177, 1
  %t179 = load ptr, ptr %l82, !tbaa !29
  %t181 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t179, i64 %t178)
  store i64 %t181, ptr %l87
  br label %bb50
bb50:
  %t182 = load i64, ptr %l87, !tbaa !24
  store i64 %t182, ptr %l5, !tbaa !24
  %t183 = load i64, ptr %l5, !tbaa !24
  %t185 = icmp eq i64 %t183, -2
  br i1 %t185, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s6
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l90, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t188, ptr %l91
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInClauseExit(ptr %s6)
  store %"compiler/msgs:Msg" %t189, ptr %l92
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t190 = load ptr, ptr %l90, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l91
  %t192 = load %"compiler/msgs:Msg", ptr %l92
  %t193 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t190, %"compiler/source:Span" %t191, %"compiler/msgs:Msg" %t192)
  store i64 %t193, ptr %l93
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb55:
  %t194 = load i32, ptr %l2
  %t196 = trunc i64 19 to i32
  %t197 = icmp eq i32 %t194, %t196
  br i1 %t197, label %bb56, label %bb57
bb56:
  %t199 = load ptr, ptr %l4, !tbaa !29
  %t201 = getelementptr %"compiler/check:frame", ptr %t199, i32 0, i32 11
  store ptr %t201, ptr %l97, !tbaa !29
  %t202 = load ptr, ptr %l4, !tbaa !29
  %t204 = getelementptr %"compiler/check:frame", ptr %t202, i32 0, i32 11
  %t206 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t204)
  store i64 %t206, ptr %l100
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t207 = load i64, ptr %l100, !tbaa !24
  %t208 = sub i64 %t207, 1
  %t209 = load ptr, ptr %l97, !tbaa !29
  %t211 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t209, i64 %t208)
  store i64 %t211, ptr %l102
  br label %bb59
bb59:
  %t212 = load i64, ptr %l102, !tbaa !24
  store i64 %t212, ptr %l5, !tbaa !24
  br label %bb60
bb60:
  %t213 = load i32, ptr %l2
  %t215 = trunc i64 19 to i32
  %t216 = icmp eq i32 %t213, %t215
  br i1 %t216, label %bb61, label %bb62
bb61:
  store i32 0, ptr %l105
  br label %bb63
bb62:
  store i32 1, ptr %l105
  br label %bb63
bb63:
  %t220 = load i32, ptr %l105
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load %"compiler/source:Span", ptr %l1
  %t224 = load i64, ptr %l5, !tbaa !24
  %t226 = trunc i64 %t224 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t228
  %t229 = getelementptr { i64, [3 x i64] }, ptr %t228, i32 0, i32 0
  store i64 5, ptr %t229
  %t231 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t222, 0
  %t233 = insertvalue { %"compiler/source:Span", i32, i32 } %t231, i32 %t220, 1
  %t235 = insertvalue { %"compiler/source:Span", i32, i32 } %t233, i32 %t226, 2
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t228, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t235, ptr %t236
  %t237 = load { i64, [3 x i64] }, ptr %t228
  %t239 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t237, ptr %t239
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t221, ptr %t239)
  br label %bb64
bb64:
  br label %ret
bb65:
  %t242 = load i32, ptr %l2
  %t244 = trunc i64 21 to i32
  %t245 = icmp eq i32 %t242, %t244
  br i1 %t245, label %bb66, label %bb67
bb66:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l118, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t248, ptr %l119
  store i32 0, ptr %l120
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t253 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v1, ptr %t249, ptr %a3, i1 true)
  store ptr %t253, ptr %l123
  br label %bb68
bb67:
  br label %bb70
bb68:
  store { i64, [3 x i64] } zeroinitializer, ptr %t254
  %t255 = getelementptr { i64, [3 x i64] }, ptr %t254, i32 0, i32 0
  store i64 9, ptr %t255
  %t256 = load %"compiler/source:Span", ptr %l119
  %t257 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t256, 0
  %t258 = load i32, ptr %l120
  %t259 = insertvalue { %"compiler/source:Span", i32, ptr } %t257, i32 %t258, 1
  %t260 = load ptr, ptr %l123, !tbaa !29
  %t261 = insertvalue { %"compiler/source:Span", i32, ptr } %t259, ptr %t260, 2
  %t262 = getelementptr { i64, [3 x i64] }, ptr %t254, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t261, ptr %t262
  %t263 = load { i64, [3 x i64] }, ptr %t254
  %t265 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t263, ptr %t265
  %t266 = load ptr, ptr %l118, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t266, ptr %t265)
  br label %bb69
bb69:
  br label %bb70
bb70:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l9 = alloca i64
  %l15 = alloca %"compiler/check:laneNode"
  %l19 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i32
  %l26 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v0, ptr %t7, ptr %t8)
  store i64 %t11, ptr %l9
  br label %bb4
bb4:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 35
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %s2, ptr %t19, i64 %t20)
  store %"compiler/check:laneNode" %t23, ptr %l15
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/check:laneNode", ptr %l15, i32 0, i32 8
  %t25 = load i32, ptr %t24, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t25, ptr %rv
  br label %ret
bb8:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t27)
  store i32 %t30, ptr %l19
  br label %bb9
bb9:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %l3, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l22
  br label %bb10
bb10:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb13
bb12:
  %t43 = load i32, ptr %l3, !tbaa !23
  store i32 %t43, ptr %l23, !tbaa !23
  br label %bb14
bb13:
  %t45 = load i32, ptr %l26, !tbaa !23
  store i32 %t45, ptr %l23, !tbaa !23
  br label %bb14
bb14:
  %t46 = load i32, ptr %l23, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:laneNode"
  %l7 = alloca %"compiler/check:laneNode"
  %l11 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 35
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/check:laneNode" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/check:laneNode", ptr %l7
  store %"compiler/check:laneNode" %t8, ptr %l3
  %t9 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 0
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  %t14 = icmp eq i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  %t16 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 0
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneScalar, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t24, i64 %t25)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %ret
bb8:
  %t28 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 4
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp sge i64 %t29, 0
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 4
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %t33, i64 %t35, ptr %t36)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t40 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 5
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = icmp sge i64 %t41, 0
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 5
  %t47 = load i64, ptr %t46, !tbaa !24
  %t48 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %t45, i64 %t47, ptr %t48)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t52 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 6
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp sge i64 %t53, 0
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 6
  %t59 = load i64, ptr %t58, !tbaa !24
  %t60 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %t57, i64 %t59, ptr %t60)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l13 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i32
  %l41 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i32
  %l53 = alloca i1
  %l54 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load i32, ptr %l1
  %t11 = trunc i64 49 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i32, ptr %l2, !tbaa !23
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t18 = icmp eq i32 %t14, %t15
  br i1 %t18, label %bb6, label %bb7
bb5:
  br label %bb9
bb6:
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t20, ptr %l13, !tbaa !23
  br label %bb8
bb7:
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t22, ptr %l13, !tbaa !23
  br label %bb8
bb8:
  %t24 = load i32, ptr %l13, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l18
  br label %bb10
bb10:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l22
  br label %bb13
bb12:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb18
bb13:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t44, ptr %l27
  br label %bb16
bb15:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb17
bb16:
  %t45 = load i1, ptr %l27, !tbaa !21
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t46 = load i1, ptr %l23, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l19, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l19, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  store i32 %t51, ptr %l30, !tbaa !23
  %t52 = load i32, ptr %l1
  %t54 = trunc i64 52 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb21, label %bb22
bb20:
  br label %bb29
bb21:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb23
bb23:
  %t57 = load ptr, ptr %l29, !tbaa !29
  %t58 = load i32, ptr %l30, !tbaa !23
  %t59 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s3, ptr %t57, i32 %t58, { i64, ptr } %t59, i64 0)
  store i64 %t60, ptr %l34
  br label %bb24
bb24:
  %t61 = load i64, ptr %l34, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = icmp sge i64 %t62, 0
  br i1 %t64, label %bb25, label %bb26
bb25:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %t66, i64 %t67, i32 %t68)
  store i32 %t72, ptr %l41
  br label %bb27
bb26:
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t73, ptr %l37, !tbaa !23
  br label %bb28
bb27:
  %t75 = load i32, ptr %l41, !tbaa !23
  store i32 %t75, ptr %l37, !tbaa !23
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  %t76 = load i32, ptr %l37, !tbaa !23
  store i32 %t76, ptr %rv
  br label %ret
bb29:
  %t77 = load i32, ptr %l1
  %t79 = trunc i64 52 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb30, label %bb31
bb30:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l47
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t87 = load i1, ptr %l47, !tbaa !21
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t88 = load i32, ptr %l2, !tbaa !23
  store i32 %t88, ptr %l48, !tbaa !23
  br label %bb35
bb34:
  %t90 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t90, ptr %l48, !tbaa !23
  br label %bb35
bb35:
  %t92 = load i32, ptr %l48, !tbaa !23
  store i32 %t92, ptr %rv
  br label %ret
bb36:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l2, !tbaa !23
  %t97 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t93, i32 %t94)
  store i1 %t97, ptr %l53
  br label %bb37
bb37:
  %t98 = load i1, ptr %l53, !tbaa !21
  br i1 %t98, label %bb38, label %bb39
bb38:
  %t99 = load i32, ptr %l2, !tbaa !23
  store i32 %t99, ptr %l54, !tbaa !23
  br label %bb40
bb39:
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t101, ptr %l54, !tbaa !23
  br label %bb40
bb40:
  %t103 = load i32, ptr %l54, !tbaa !23
  store i32 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca [1 x i64]
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca %"compiler/check:laneNode"
  %l17 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca i64
  %l28 = alloca i32
  %l32 = alloca %"compiler/check:laneNode"
  %l33 = alloca i64
  %l38 = alloca i32
  %l39 = alloca %"compiler/check:laneNode"
  %l40 = alloca i64
  %l41 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %t1, ptr %a3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l10, !tbaa !29
  %t8 = load i32, ptr %l2
  store i32 %t8, ptr %l11
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 35
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = call %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %s0, ptr %t11, i64 %t12)
  store %"compiler/check:laneNode" %t15, ptr %l15
  br label %bb2
bb2:
  %t16 = getelementptr %"compiler/check:laneNode", ptr %l15, i32 0, i32 8
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l10, !tbaa !29
  %t19 = load i32, ptr %l11
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %t18, i32 %t19, i32 %t17)
  store i32 %t21, ptr %l17
  br label %bb3
bb3:
  %t22 = load i32, ptr %l17, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = insertvalue [1 x i64] undef, i64 %t23, 0
  store [1 x i64] %t25, ptr %l6
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l20, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneUn, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load i32, ptr %l2
  store i32 %t31, ptr %l24
  %t32 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t32, ptr %l25
  %t33 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t33, ptr %l26
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l27, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  store i32 %t35, ptr %l28, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 35
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = call %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %s0, ptr %t38, i64 %t39)
  store %"compiler/check:laneNode" %t42, ptr %l32
  br label %bb4
bb4:
  %t43 = getelementptr %"compiler/check:laneNode", ptr %l32, i32 0, i32 9
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l33, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = insertvalue { i64, ptr } undef, i64 1, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %l6, 1
  %t49 = load i32, ptr %l5, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %s0, ptr %t45, { i64, ptr } %t48, i32 %t49)
  store i32 %t53, ptr %l38
  br label %bb5
bb5:
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = load i32, ptr %l24
  %t56 = load %"compiler/source:Span", ptr %l25
  %t57 = load %"compiler/source:Span", ptr %l26
  %t58 = load i64, ptr %l27, !tbaa !24
  %t59 = load i32, ptr %l28, !tbaa !23
  %t60 = load i64, ptr %l33, !tbaa !24
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t54, i32 %t55, %"compiler/source:Span" %t56, %"compiler/source:Span" %t57, i64 %t58, i64 -1, i64 -1, ptr null, i32 %t59, i64 %t60, i32 %t61)
  store %"compiler/check:laneNode" %t62, ptr %l39
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l22, !tbaa !29
  %t64 = load %"compiler/check:laneNode", ptr %l39
  %t65 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t63, %"compiler/check:laneNode" %t64)
  store i64 %t65, ptr %l40
  br label %bb7
bb7:
  %t66 = load ptr, ptr %l20, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l21
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %t66, %"compiler/source:Span" %t67, i64 %t68)
  store ptr %t69, ptr %l41
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t70 = load ptr, ptr %l41, !tbaa !29
  store ptr %t70, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t14 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l13
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t28, ptr %l20, !tbaa !27
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t38, i32 %t34)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb3
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %l22 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l40 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l73 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l93 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l113 = alloca ptr
  %l115 = alloca ptr
  %l117 = alloca ptr
  %l120 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca i32
  %l128 = alloca i32
  %l135 = alloca i1
  %l140 = alloca i64
  %l145 = alloca i64
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i1 %t9, ptr %l22
  br label %bb1
bb1:
  %t10 = load i1, ptr %l22, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 -2, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l26, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t18)
  store ptr %t20, ptr %l28
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l28, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 4
  store ptr %t23, ptr %l30, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Match", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l32, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t28)
  store i32 %t30, ptr %l34
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l26, !tbaa !29
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t33 = load ptr, ptr %l32, !tbaa !29
  %t34 = load i32, ptr %l34, !tbaa !23
  %t35 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t31, ptr %t32, ptr %t33, i32 %t34)
  store i32 %t35, ptr %l35
  br label %bb7
bb7:
  %t36 = load i32, ptr %l35, !tbaa !23
  store i32 %t36, ptr %l2, !tbaa !23
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l40
  br label %bb8
bb8:
  %t47 = load i32, ptr %l40
  %t49 = trunc i64 26 to i32
  %t50 = icmp eq i32 %t47, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  store i64 -2, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Match", ptr %t55, i32 0, i32 3
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb12, label %bb13
bb12:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb17
bb14:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l4, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l54, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb16
bb16:
  %t88 = load i64, ptr %l54, !tbaa !24
  store i64 %t88, ptr %l51, !tbaa !24
  br label %bb17
bb17:
  %t89 = load i64, ptr %l51, !tbaa !24
  store i64 %t89, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb68
bb20:
  br label %bb21
bb21:
  %t98 = load i64, ptr %l4, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l9, !tbaa !24
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Match", ptr %t108, i32 0, i32 3
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l73, !tbaa !27
  %t112 = load i64, ptr %l9, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  store ptr %t117, ptr %l10, !tbaa !29
  %t119 = load ptr, ptr %l10, !tbaa !29
  %t121 = getelementptr %"compiler/ast:Case", ptr %t119, i32 0, i32 3
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  store i64 -2, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Case", ptr %t129, i32 0, i32 1
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb27:
  br label %bb28
bb28:
  %t146 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t146, ptr %l89, !tbaa !27
  %t147 = load i64, ptr %l12, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr ptr, ptr %t150, i64 %t147
  %t152 = load ptr, ptr %t151, !tbaa !39
  store ptr %t152, ptr %l14, !tbaa !29
  %t154 = load ptr, ptr %l14, !tbaa !29
  %t156 = call i1 @compiler_2fcheck_2eisWild(ptr %v1, ptr %t154)
  store i1 %t156, ptr %l93
  br label %bb29
bb29:
  %t157 = load i1, ptr %l93, !tbaa !21
  br i1 %t157, label %bb30, label %bb31
bb30:
  %t158 = load i64, ptr %l3, !tbaa !24
  %t160 = icmp slt i64 %t158, 0
  br i1 %t160, label %bb32, label %bb33
bb31:
  br label %bb35
bb32:
  %t162 = load i64, ptr %l9, !tbaa !24
  store i64 %t162, ptr %l3, !tbaa !24
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb35:
  store ptr null, ptr %l15, !tbaa !29
  %t164 = load ptr, ptr %l14, !tbaa !29
  store ptr %t164, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t165 = load ptr, ptr %l97, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb36, label %bb37
bb36:
  %t168 = load ptr, ptr %l97, !tbaa !29
  %t169 = load i64, ptr %t168
  %t171 = icmp eq i64 %t169, 4
  store i1 %t171, ptr %l98, !tbaa !21
  br label %bb37
bb37:
  %t172 = load i1, ptr %l98, !tbaa !21
  br i1 %t172, label %bb38, label %bb39
bb38:
  %t173 = load ptr, ptr %l14, !tbaa !29
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l16, !tbaa !29
  br label %bb44
bb39:
  %t179 = load ptr, ptr %l14, !tbaa !29
  store ptr %t179, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t180 = load ptr, ptr %l103, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb40, label %bb41
bb40:
  %t183 = load ptr, ptr %l103, !tbaa !29
  %t184 = load i64, ptr %t183
  %t186 = icmp eq i64 %t184, 1
  store i1 %t186, ptr %l104, !tbaa !21
  br label %bb41
bb41:
  %t187 = load i1, ptr %l104, !tbaa !21
  br i1 %t187, label %bb42, label %bb43
bb42:
  %t188 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr }, ptr %t190, i32 0, i32 1
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l16, !tbaa !29
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t194 = load ptr, ptr %l16, !tbaa !29
  store ptr %t194, ptr %l15, !tbaa !29
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s4)
  store i64 -2, ptr %rv
  br label %ret
bb46:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  store ptr %t201, ptr %l113, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t202)
  store ptr %t204, ptr %l115
  br label %bb47
bb47:
  %t205 = load ptr, ptr %l115, !tbaa !29
  %t207 = getelementptr %"compiler/check:frame", ptr %t205, i32 0, i32 4
  store ptr %t207, ptr %l117, !tbaa !29
  %t208 = load ptr, ptr %l15, !tbaa !29
  %t210 = icmp eq ptr %t208, null
  br i1 %t210, label %bb48, label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_a912cbb846bdb4fc_9416d37dc1706d90)
  unreachable
bb49:
  br label %bb50
bb50:
  %t212 = load ptr, ptr %l15, !tbaa !29
  store ptr %t212, ptr %l120, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t213)
  store i32 %t215, ptr %l122
  br label %bb51
bb51:
  %t216 = load ptr, ptr %l113, !tbaa !29
  %t217 = load ptr, ptr %l117, !tbaa !29
  %t218 = load ptr, ptr %l120, !tbaa !29
  %t219 = load i32, ptr %l122, !tbaa !23
  %t220 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t216, ptr %t217, ptr %t218, i32 %t219)
  store i32 %t220, ptr %l123
  br label %bb52
bb52:
  %t221 = load i32, ptr %l123, !tbaa !23
  store i32 %t221, ptr %l17, !tbaa !23
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  %t228 = load i32, ptr %l17, !tbaa !23
  %t231 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t227, i32 %t228)
  store i32 %t231, ptr %l128
  br label %bb53
bb53:
  %t232 = load i32, ptr %l128
  %t234 = trunc i64 26 to i32
  %t235 = icmp eq i32 %t232, %t234
  %t237 = xor i1 %t235, true
  br i1 %t237, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s4)
  store i64 -2, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t240 = load i64, ptr %l3, !tbaa !24
  %t242 = icmp slt i64 %t240, 0
  br i1 %t242, label %bb57, label %bb58
bb57:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/generic:Program", ptr %t247, i32 0, i32 2
  %t250 = load i32, ptr %l17, !tbaa !23
  %t253 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t249, i32 %t250)
  store i64 %t253, ptr %l140
  br label %bb59
bb58:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb61
bb59:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t254, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t259 = getelementptr %"compiler/generic:Program", ptr %t257, i32 0, i32 2
  %t260 = load i32, ptr %l2, !tbaa !23
  %t263 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t259, i32 %t260)
  store i64 %t263, ptr %l145
  br label %bb60
bb60:
  %t264 = load i64, ptr %l140, !tbaa !24
  %t265 = load i64, ptr %l145, !tbaa !24
  %t266 = icmp eq i64 %t264, %t265
  store i1 %t266, ptr %l135, !tbaa !21
  br label %bb61
bb61:
  %t268 = load i1, ptr %l135, !tbaa !21
  br i1 %t268, label %bb62, label %bb63
bb62:
  %t269 = load i64, ptr %l9, !tbaa !24
  store i64 %t269, ptr %l3, !tbaa !24
  br label %bb64
bb63:
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb65:
  %t271 = load i64, ptr %l12, !tbaa !24
  %t273 = add i64 %t271, 1
  store i64 %t273, ptr %l12, !tbaa !24
  br label %bb25
bb66:
  call void @__olang_scope_close(ptr %s4)
  br label %bb67
bb67:
  %t275 = load i64, ptr %l8, !tbaa !24
  %t277 = add i64 %t275, 1
  store i64 %t277, ptr %l8, !tbaa !24
  br label %bb18
bb68:
  %t279 = load i64, ptr %l3, !tbaa !24
  store i64 %t279, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l27 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t15, ptr %l14
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb7:
  br label %bb8
bb8:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t29, ptr %l21, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i32, ptr %t33, i64 %t30
  %t35 = load i32, ptr %t34, !tbaa !33
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t37, i32 %t35, i64 %a2)
  store i1 %t43, ptr %l27
  br label %bb9
bb9:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb5
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l7 = alloca %"compiler/typed:Local"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %a1)
  store %"compiler/typed:Local" %t10, ptr %l7
  br label %bb2
bb2:
  %t11 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/check:typeCase"
  %l25 = alloca %"compiler/check:typeCase"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca i32
  %l44 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/msgs:Msg"
  %l49 = alloca i64
  %l59 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/msgs:Msg"
  %l77 = alloca i64
  %l80 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca i64
  %l90 = alloca i64
  %l109 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l124 = alloca i1
  %l126 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l130 = alloca i32
  %l139 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l147 = alloca ptr
  %l149 = alloca %"compiler/source:Span"
  %l150 = alloca { i64, [3 x i64] }
  %l151 = alloca %"compiler/msgs:Msg"
  %l152 = alloca i64
  %l158 = alloca ptr
  %l160 = alloca %"compiler/check:typeCase"
  %l166 = alloca %"compiler/check:typeCase"
  %l171 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca i32
  %l184 = alloca { i64, ptr }
  %l190 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca { i64, [3 x i64] }
  %l199 = alloca %"compiler/msgs:Msg"
  %l200 = alloca i64
  %l214 = alloca i1
  %l226 = alloca ptr
  %l229 = alloca %"compiler/source:Span"
  %l232 = alloca { i64, ptr }
  %l234 = alloca %"compiler/msgs:Msg"
  %l235 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l32, !tbaa !29
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l33
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  %t4 = load ptr, ptr %l32, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 97
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Match", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t6, ptr %t10)
  store i32 %t13, ptr %l37
  br label %bb2
bb2:
  %t14 = load i32, ptr %l37, !tbaa !23
  store i32 %t14, ptr %l2, !tbaa !23
  %t15 = load i32, ptr %l2, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp eq i32 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t22 = load i32, ptr %l2, !tbaa !23
  %t24 = icmp slt i32 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l44, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Match", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t30)
  store %"compiler/source:Span" %t32, ptr %l47
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t33 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflMatchSubject(ptr %s2)
  store %"compiler/msgs:Msg" %t33, ptr %l48
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l44, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l47
  %t36 = load %"compiler/msgs:Msg", ptr %l48
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t34, %"compiler/source:Span" %t35, %"compiler/msgs:Msg" %t36)
  store i64 %t37, ptr %l49
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Match", ptr %t39, i32 0, i32 3
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l5, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb14:
  br label %bb15
bb15:
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t56, ptr %l59, !tbaa !27
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  store ptr %t62, ptr %l6, !tbaa !29
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Case", ptr %t64, i32 0, i32 3
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l66, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l67, !tbaa !29
  %t75 = load ptr, ptr %l6, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Case", ptr %t75, i32 0, i32 3
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb18, label %bb19
bb17:
  br label %bb25
bb18:
  call void @__olang_check_failed(ptr @olang_loc_775dfd67c7206a52_c2d8bc16e2444876)
  unreachable
bb19:
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l6, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Case", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t85)
  store %"compiler/source:Span" %t87, ptr %l73
  br label %bb21
bb21:
  %t88 = getelementptr %"compiler/source:Span", ptr %l73, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = load ptr, ptr %l67, !tbaa !29
  %t92 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordBefore(ptr %v0, ptr %s5, ptr %t90, i32 %t89, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store %"compiler/source:Span" %t92, ptr %l75
  br label %bb22
bb22:
  %t93 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchGuard(ptr %s5)
  store %"compiler/msgs:Msg" %t93, ptr %l76
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l66, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l75
  %t96 = load %"compiler/msgs:Msg", ptr %l76
  %t97 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t94, %"compiler/source:Span" %t95, %"compiler/msgs:Msg" %t96)
  store i64 %t97, ptr %l77
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  %t98 = load i64, ptr %l4, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l4, !tbaa !24
  br label %bb12
bb27:
  store i64 -1, ptr %l7, !tbaa !24
  %t102 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3atypeCase_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %l80
  br label %bb28
bb28:
  %t103 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t103, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/ast:Match", ptr %t104, i32 0, i32 3
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t111 = load i64, ptr %l10, !tbaa !24
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = icmp sgt i64 %t111, %t112
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t119 = icmp sgt i64 %t117, 0
  br i1 %t119, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb34
bb31:
  %t121 = load i64, ptr %l10, !tbaa !24
  %t122 = load i64, ptr %l9, !tbaa !24
  %t125 = sub i64 %t121, %t122
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = add i64 %t125, %t126
  %t131 = sub i64 %t129, 1
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = sdiv i64 %t131, %t132
  store i64 %t135, ptr %l90, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb33
bb33:
  %t137 = load i64, ptr %l90, !tbaa !24
  store i64 %t137, ptr %l87, !tbaa !24
  br label %bb34
bb34:
  %t138 = load i64, ptr %l87, !tbaa !24
  store i64 %t138, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t139 = load i64, ptr %l13, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb112
bb37:
  br label %bb38
bb38:
  %t147 = load i64, ptr %l9, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = mul i64 %t148, %t149
  %t155 = add i64 %t147, %t152
  store i64 %t155, ptr %l14, !tbaa !24
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/ast:Match", ptr %t157, i32 0, i32 3
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  store { i64, ptr } %t160, ptr %l109, !tbaa !27
  %t161 = load i64, ptr %l14, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr ptr, ptr %t164, i64 %t161
  %t166 = load ptr, ptr %t165, !tbaa !39
  %t168 = getelementptr %"compiler/ast:Case", ptr %t166, i32 0, i32 2
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  store i64 %t173, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  %t175 = load i64, ptr %l16, !tbaa !24
  %t176 = load i64, ptr %l17, !tbaa !24
  %t179 = icmp slt i64 %t175, %t176
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s10)
  br label %bb110
bb41:
  br label %bb42
bb42:
  %t183 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t183, ptr %l119, !tbaa !27
  %t184 = load i64, ptr %l16, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr ptr, ptr %t187, i64 %t184
  %t189 = load ptr, ptr %t188, !tbaa !39
  store ptr %t189, ptr %l18, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l18, !tbaa !29
  %t195 = call i1 @compiler_2fcheck_2eisWildType(ptr %v0, ptr %v1, ptr %t191, ptr %t192)
  store i1 %t195, ptr %l124
  br label %bb43
bb43:
  %t196 = load i1, ptr %l124, !tbaa !21
  br i1 %t196, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l8, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb46
bb45:
  br label %bb73
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  %t198 = load ptr, ptr %l19, !tbaa !29
  %t199 = load i64, ptr %l20, !tbaa !24
  %t202 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3atypeCase_3e_2eRu_H6eb7eaf448ada2c059532340e07086a1(ptr %s0, ptr %t198, i64 %t199)
  %t203 = extractvalue { i32, { i64, ptr } } %t202, 1
  %t204 = extractvalue { i32, { i64, ptr } } %t202, 0
  store i32 %t204, ptr %l130
  %t205 = icmp ne i32 %t204, 0
  br i1 %t205, label %bb48, label %ok.206
ok.206:
  store { i64, ptr } %t203, ptr %l129
  br label %bb47
bb47:
  %t207 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t207, ptr %l126, !tbaa !27
  br label %bb52
bb48:
  %t208 = load i32, ptr %l130, !tbaa !23
  %t209 = ashr i32 %t208, 16
  %t211 = icmp eq i32 %t209, 1
  br i1 %t211, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_a7e62a7f9d49e0b0_a2816bf575d66404)
  unreachable
bb51:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb67
bb52:
  %t213 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t213, ptr %l21, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  store i64 %t216, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s14
  %t218 = load i64, ptr %l23, !tbaa !24
  %t219 = load i64, ptr %l22, !tbaa !24
  %t222 = icmp slt i64 %t218, %t219
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s14)
  br label %bb65
bb55:
  br label %bb56
bb56:
  %t226 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t226, ptr %l139, !tbaa !27
  %t227 = load i64, ptr %l23, !tbaa !24
  %t229 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr %"compiler/check:typeCase", ptr %t230, i64 %t227
  %t232 = load %"compiler/check:typeCase", ptr %t231
  store %"compiler/check:typeCase" %t232, ptr %l24
  %t234 = getelementptr %"compiler/check:typeCase", ptr %l24, i32 0, i32 0
  %t235 = load i1, ptr %t234, !tbaa !21
  br i1 %t235, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s15
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Program", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/load:Loader", ptr %t243, i32 0, i32 4
  %t246 = load ptr, ptr %t245, !tbaa !29
  store ptr %t246, ptr %l146, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l147, !tbaa !29
  %t248 = load ptr, ptr %l18, !tbaa !29
  %t250 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t248)
  store %"compiler/source:Span" %t250, ptr %l149
  br label %bb59
bb58:
  br label %bb63
bb59:
  %t251 = load ptr, ptr %l147, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l149
  %t253 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t251, %"compiler/source:Span" %t252)
  store { i64, [3 x i64] } %t253, ptr %l150
  br label %bb60
bb60:
  %t254 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflCaseUnreachable(ptr %s15)
  store %"compiler/msgs:Msg" %t254, ptr %l151
  br label %bb61
bb61:
  %t255 = load ptr, ptr %l146, !tbaa !29
  %t256 = load { i64, [3 x i64] }, ptr %l150
  %t257 = load %"compiler/msgs:Msg", ptr %l151
  %t258 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s15, ptr %t255, { i64, [3 x i64] } %t256, %"compiler/msgs:Msg" %t257)
  store i64 %t258, ptr %l152
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s15)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s14)
  br label %bb64
bb64:
  %t259 = load i64, ptr %l23, !tbaa !24
  %t261 = add i64 %t259, 1
  store i64 %t261, ptr %l23, !tbaa !24
  br label %bb53
bb65:
  %t263 = load i64, ptr %l20, !tbaa !24
  %t264 = load i64, ptr %l22, !tbaa !24
  %t267 = add i64 %t263, %t264
  store i64 %t267, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb66
bb66:
  br label %bb46
bb67:
  store ptr %l8, ptr %l158, !tbaa !29
  %t269 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t271 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s11, i1 true, i1 false, i32 %t269, i64 0)
  store %"compiler/check:typeCase" %t271, ptr %l160
  br label %bb68
bb68:
  %t272 = load ptr, ptr %l158, !tbaa !29
  %t273 = load %"compiler/check:typeCase", ptr %l160
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3atypeCase_3e_2ePu_Hf6291ee8fee32011df4f690a3becde1c(ptr %s0, ptr %t272, %"compiler/check:typeCase" %t273)
  br label %bb69
bb69:
  %t274 = load i64, ptr %l7, !tbaa !24
  %t276 = icmp slt i64 %t274, 0
  br i1 %t276, label %bb70, label %bb71
bb70:
  %t278 = load i64, ptr %l14, !tbaa !24
  store i64 %t278, ptr %l7, !tbaa !24
  br label %bb72
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  br label %bb109
bb73:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l18, !tbaa !29
  %t284 = call %"compiler/check:typeCase" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseOf(ptr %v0, ptr %v1, ptr %t280, ptr %t281)
  store %"compiler/check:typeCase" %t284, ptr %l166
  br label %bb74
bb74:
  %t285 = load %"compiler/check:typeCase", ptr %l166
  store %"compiler/check:typeCase" %t285, ptr %l25
  %t286 = getelementptr %"compiler/check:typeCase", ptr %l25, i32 0, i32 2
  %t287 = load i32, ptr %t286, !tbaa !23
  %t288 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t291 = icmp eq i32 %t287, %t288
  br i1 %t291, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s10)
  br label %bb109
bb76:
  br label %bb77
bb77:
  store ptr %l8, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s20
  %t294 = load ptr, ptr %l26, !tbaa !29
  %t295 = load i64, ptr %l27, !tbaa !24
  %t298 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3atypeCase_3e_2eRu_H6eb7eaf448ada2c059532340e07086a1(ptr %s0, ptr %t294, i64 %t295)
  %t299 = extractvalue { i32, { i64, ptr } } %t298, 1
  %t300 = extractvalue { i32, { i64, ptr } } %t298, 0
  store i32 %t300, ptr %l175
  %t301 = icmp ne i32 %t300, 0
  br i1 %t301, label %bb80, label %ok.302
ok.302:
  store { i64, ptr } %t299, ptr %l174
  br label %bb79
bb79:
  %t303 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t303, ptr %l171, !tbaa !27
  br label %bb84
bb80:
  %t304 = load i32, ptr %l175, !tbaa !23
  %t305 = ashr i32 %t304, 16
  %t307 = icmp eq i32 %t305, 1
  br i1 %t307, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_861e0137122870eb_3ad6276ce475d93f)
  unreachable
bb83:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s20)
  br label %bb100
bb84:
  %t309 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t309, ptr %l28, !tbaa !27
  %t310 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  store i64 %t312, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s21
  %t314 = load i64, ptr %l30, !tbaa !24
  %t315 = load i64, ptr %l29, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s21)
  br label %bb98
bb87:
  br label %bb88
bb88:
  %t322 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t322, ptr %l184, !tbaa !27
  %t323 = load i64, ptr %l30, !tbaa !24
  %t325 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = getelementptr %"compiler/check:typeCase", ptr %t326, i64 %t323
  %t328 = load %"compiler/check:typeCase", ptr %t327
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = load %"compiler/check:typeCase", ptr %l25
  %t336 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseCovers(ptr %v0, ptr %t330, %"compiler/check:typeCase" %t328, %"compiler/check:typeCase" %t332)
  store i1 %t336, ptr %l190
  br label %bb89
bb89:
  %t337 = load i1, ptr %l190, !tbaa !21
  br i1 %t337, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s22
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/check:Checker", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = getelementptr %"compiler/generic:Program", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = getelementptr %"compiler/load:Loader", ptr %t344, i32 0, i32 4
  %t347 = load ptr, ptr %t346, !tbaa !29
  store ptr %t347, ptr %l194, !tbaa !29
  %t348 = load ptr, ptr %l0, !tbaa !29
  store ptr %t348, ptr %l195, !tbaa !29
  %t349 = load ptr, ptr %l18, !tbaa !29
  %t351 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t349)
  store %"compiler/source:Span" %t351, ptr %l197
  br label %bb92
bb91:
  br label %bb96
bb92:
  %t352 = load ptr, ptr %l195, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l197
  %t354 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t352, %"compiler/source:Span" %t353)
  store { i64, [3 x i64] } %t354, ptr %l198
  br label %bb93
bb93:
  %t355 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflCaseUnreachable(ptr %s22)
  store %"compiler/msgs:Msg" %t355, ptr %l199
  br label %bb94
bb94:
  %t356 = load ptr, ptr %l194, !tbaa !29
  %t357 = load { i64, [3 x i64] }, ptr %l198
  %t358 = load %"compiler/msgs:Msg", ptr %l199
  %t359 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s22, ptr %t356, { i64, [3 x i64] } %t357, %"compiler/msgs:Msg" %t358)
  store i64 %t359, ptr %l200
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s22)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s21)
  br label %bb97
bb97:
  %t360 = load i64, ptr %l30, !tbaa !24
  %t362 = add i64 %t360, 1
  store i64 %t362, ptr %l30, !tbaa !24
  br label %bb85
bb98:
  %t364 = load i64, ptr %l27, !tbaa !24
  %t365 = load i64, ptr %l29, !tbaa !24
  %t368 = add i64 %t364, %t365
  store i64 %t368, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb99
bb99:
  br label %bb78
bb100:
  %t370 = load %"compiler/check:typeCase", ptr %l25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3atypeCase_3e_2ePu_Hf6291ee8fee32011df4f690a3becde1c(ptr %s0, ptr %l8, %"compiler/check:typeCase" %t370)
  br label %bb101
bb101:
  %t373 = load i64, ptr %l7, !tbaa !24
  %t375 = icmp sge i64 %t373, 0
  br i1 %t375, label %bb102, label %bb103
bb102:
  call void @__olang_scope_close(ptr %s10)
  br label %bb109
bb103:
  br label %bb104
bb104:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load %"compiler/check:typeCase", ptr %l25
  %t379 = load i32, ptr %l2, !tbaa !23
  %t380 = load ptr, ptr %l18, !tbaa !29
  %t385 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseHolds(ptr %v0, ptr %v1, ptr %t377, %"compiler/check:typeCase" %t378, i32 %t379, ptr %t380)
  store i1 %t385, ptr %l214
  br label %bb105
bb105:
  %t386 = load i1, ptr %l214, !tbaa !21
  br i1 %t386, label %bb106, label %bb107
bb106:
  %t387 = load i64, ptr %l14, !tbaa !24
  store i64 %t387, ptr %l7, !tbaa !24
  br label %bb108
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s10)
  br label %bb109
bb109:
  %t389 = load i64, ptr %l16, !tbaa !24
  %t391 = add i64 %t389, 1
  store i64 %t391, ptr %l16, !tbaa !24
  br label %bb39
bb110:
  call void @__olang_scope_close(ptr %s8)
  br label %bb111
bb111:
  %t393 = load i64, ptr %l13, !tbaa !24
  %t395 = add i64 %t393, 1
  store i64 %t395, ptr %l13, !tbaa !24
  br label %bb35
bb112:
  %t397 = load i64, ptr %l7, !tbaa !24
  %t399 = icmp sge i64 %t397, 0
  br i1 %t399, label %bb113, label %bb114
bb113:
  %t401 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t401, ptr %rv
  br label %ret
bb114:
  br label %bb115
bb115:
  %t403 = load ptr, ptr %l1, !tbaa !29
  %t405 = getelementptr %"compiler/ast:Match", ptr %t403, i32 0, i32 4
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = icmp eq ptr %t406, null
  br i1 %t408, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s29
  %t410 = load ptr, ptr %l0, !tbaa !29
  store ptr %t410, ptr %l226, !tbaa !29
  %t411 = load ptr, ptr %l1, !tbaa !29
  %t413 = getelementptr %"compiler/ast:Match", ptr %t411, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !29
  %t416 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t414)
  store %"compiler/source:Span" %t416, ptr %l229
  br label %bb118
bb117:
  br label %bb122
bb118:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load i32, ptr %l2, !tbaa !23
  %t421 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s29, ptr %t417, i32 %t418)
  store { i64, ptr } %t421, ptr %l232
  br label %bb119
bb119:
  %t422 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t423 = extractvalue { i64, ptr } %t422, 0
  %t424 = extractvalue { i64, ptr } %t422, 1
  %t425 = mul i64 %t423, 1
  %t426 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t425)
  call void @llvm.memcpy.p0.p0.i64(ptr %t426, ptr %t424, i64 %t425, i1 false)
  %t427 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t428 = insertvalue { i64, ptr } %t427, ptr %t426, 1
  %t430 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchUncovered(ptr %s29, ptr %s29, { i64, ptr } %t428)
  store %"compiler/msgs:Msg" %t430, ptr %l234
  br label %bb120
bb120:
  %t431 = load ptr, ptr %l226, !tbaa !29
  %t432 = load %"compiler/source:Span", ptr %l229
  %t433 = load %"compiler/msgs:Msg", ptr %l234
  %t434 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s29, ptr %t431, %"compiler/source:Span" %t432, %"compiler/msgs:Msg" %t433)
  store i64 %t434, ptr %l235
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s29)
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca %"compiler/names:Ref"
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t8)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t20 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t17, i64 %t14, i32 %t16)
  store %"compiler/names:Ref" %t20, ptr %l11
  br label %bb2
bb2:
  %t21 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 0
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l2
  %t24 = load i32, ptr %l2
  %t26 = trunc i64 1 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  %t29 = load i32, ptr %l2
  %t31 = trunc i64 8 to i32
  %t32 = icmp eq i32 %t29, %t31
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l15, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca %"compiler/typed:Local"
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca i32
  %l25 = alloca i32
  %l27 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i1
  %l44 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l55 = alloca i64
  %l60 = alloca ptr
  %l64 = alloca %"compiler/typed:Local"
  %l68 = alloca i1
  %l72 = alloca i1
  %l79 = alloca i32
  %l82 = alloca i1
  %l85 = alloca ptr
  %l87 = alloca ptr
  %l89 = alloca i64
  %l92 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t24, i32 0, i32 3
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l5, !tbaa !29
  br label %bb5
bb4:
  br label %bb53
bb5:
  %t28 = load i32, ptr %l3
  store i32 %t28, ptr %l23
  store i32 %a2, ptr %l25
  %t32 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l23, ptr %l25)
  store i1 %t32, ptr %l27
  br label %bb6
bb6:
  %t33 = load i1, ptr %l27, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t37 = insertvalue { i64, i64 } %t36, i64 -1, 1
  store { i64, i64 } %t37, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l6, !tbaa !29
  %t41 = load ptr, ptr %l5, !tbaa !29
  store ptr %t41, ptr %l7, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t47 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t47, ptr %l34
  br label %bb10
bb10:
  %t48 = load i1, ptr %l34, !tbaa !21
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store i1 %t53, ptr %l38
  br label %bb13
bb12:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb14
bb13:
  %t54 = load i1, ptr %l38, !tbaa !21
  %t55 = xor i1 %t54, true
  store i1 %t55, ptr %l35, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %l5, !tbaa !29
  store ptr %t58, ptr %l6, !tbaa !29
  %t60 = load ptr, ptr %l4, !tbaa !29
  store ptr %t60, ptr %l7, !tbaa !29
  br label %bb21
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t66 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store i1 %t66, ptr %l44
  br label %bb17
bb17:
  %t67 = load i1, ptr %l44, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t70 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t71 = insertvalue { i64, i64 } %t70, i64 -1, 1
  store { i64, i64 } %t71, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l6, !tbaa !29
  store ptr %t73, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t74 = load ptr, ptr %l47, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb22, label %bb23
bb22:
  %t77 = load ptr, ptr %l47, !tbaa !29
  %t78 = load i64, ptr %t77
  %t80 = icmp eq i64 %t78, 0
  store i1 %t80, ptr %l48, !tbaa !21
  br label %bb23
bb23:
  %t81 = load i1, ptr %l48, !tbaa !21
  br i1 %t81, label %bb24, label %bb25
bb24:
  %t82 = load ptr, ptr %l6, !tbaa !29
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32 }, ptr %t84, i32 0, i32 1
  %t86 = load i32, ptr %t85
  store i32 %t86, ptr %l8, !tbaa !23
  br label %bb26
bb25:
  br label %bb52
bb26:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l8, !tbaa !23
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t88, i32 %t89)
  store i64 %t92, ptr %l55
  br label %bb27
bb27:
  %t93 = load i64, ptr %l55, !tbaa !24
  store i64 %t93, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp slt i64 %t94, 0
  br i1 %t96, label %bb28, label %bb29
bb28:
  %t98 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t99 = insertvalue { i64, i64 } %t98, i64 -1, 1
  store { i64, i64 } %t99, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t101)
  store ptr %t103, ptr %l60
  br label %bb31
bb31:
  %t104 = load ptr, ptr %l60, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Body", ptr %t104, i32 0, i32 7
  %t107 = load i64, ptr %l9, !tbaa !24
  %t110 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t106, i64 %t107)
  store %"compiler/typed:Local" %t110, ptr %l64
  br label %bb32
bb32:
  %t111 = load %"compiler/typed:Local", ptr %l64
  store %"compiler/typed:Local" %t111, ptr %l10
  %t112 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 4
  %t113 = load i32, ptr %t112
  %t115 = trunc i64 0 to i32
  %t116 = icmp eq i32 %t113, %t115
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb33, label %bb34
bb33:
  %t120 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 4
  %t121 = load i32, ptr %t120
  %t123 = trunc i64 1 to i32
  %t124 = icmp eq i32 %t121, %t123
  %t126 = xor i1 %t124, true
  store i1 %t126, ptr %l68, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb35
bb35:
  %t128 = load i1, ptr %l68, !tbaa !21
  br i1 %t128, label %bb36, label %bb37
bb36:
  %t129 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 4
  %t130 = load i32, ptr %t129
  %t132 = trunc i64 4 to i32
  %t133 = icmp eq i32 %t130, %t132
  %t135 = xor i1 %t133, true
  store i1 %t135, ptr %l72, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb38
bb38:
  %t137 = load i1, ptr %l72, !tbaa !21
  br i1 %t137, label %bb39, label %bb40
bb39:
  %t138 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t139 = insertvalue { i64, i64 } %t138, i64 -1, 1
  store { i64, i64 } %t139, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 2
  %t143 = load i32, ptr %t142, !tbaa !23
  %t146 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t141, i32 %t143)
  store i32 %t146, ptr %l79
  br label %bb42
bb42:
  %t147 = load i32, ptr %l79, !tbaa !23
  store i32 %t147, ptr %l11, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l11, !tbaa !23
  %t152 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t148, i32 %t149)
  store i1 %t152, ptr %l82
  br label %bb43
bb43:
  %t153 = load i1, ptr %l82, !tbaa !21
  %t154 = xor i1 %t153, true
  br i1 %t154, label %bb44, label %bb45
bb44:
  %t156 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t157 = insertvalue { i64, i64 } %t156, i64 -1, 1
  store { i64, i64 } %t157, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l85, !tbaa !29
  %t160 = load ptr, ptr %l7, !tbaa !29
  %t162 = call ptr @compiler_2fcheck_2ecasePath(ptr %v1, ptr %t160)
  store ptr %t162, ptr %l87
  br label %bb47
bb47:
  %t163 = load i32, ptr %l11, !tbaa !23
  %t164 = load ptr, ptr %l85, !tbaa !29
  %t165 = load ptr, ptr %l87, !tbaa !29
  %t167 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t164, ptr %t165, i32 %t163)
  store i64 %t167, ptr %l89
  br label %bb48
bb48:
  %t168 = load i64, ptr %l89, !tbaa !24
  store i64 %t168, ptr %l12, !tbaa !24
  %t169 = load i64, ptr %l12, !tbaa !24
  %t171 = icmp sge i64 %t169, 0
  br i1 %t171, label %bb49, label %bb50
bb49:
  %t173 = load i64, ptr %l9, !tbaa !24
  store i64 %t173, ptr %l92, !tbaa !24
  br label %bb51
bb50:
  store i64 -1, ptr %l92, !tbaa !24
  br label %bb51
bb51:
  %t175 = load i64, ptr %l12, !tbaa !24
  %t176 = load i64, ptr %l92, !tbaa !24
  %t177 = insertvalue { i64, i64 } undef, i64 %t176, 0
  %t179 = insertvalue { i64, i64 } %t177, i64 %t175, 1
  store { i64, i64 } %t179, ptr %rv
  br label %ret
bb52:
  %t181 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t182 = insertvalue { i64, i64 } %t181, i64 -1, 1
  store { i64, i64 } %t182, ptr %rv
  br label %ret
bb53:
  %t184 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t185 = insertvalue { i64, i64 } %t184, i64 -1, 1
  store { i64, i64 } %t185, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %rv = alloca { i64, i64, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 7
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = trunc i64 %t13 to i32
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t19, i32 %t15, i32 %a1, %"compiler/source:Span" %a2)
  store i32 %t23, ptr %l17
  br label %bb3
bb3:
  %t24 = load i32, ptr %l17, !tbaa !23
  %t25 = sext i32 %t24 to i64
  store i64 %t25, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = getelementptr %"compiler/check:frame", ptr %t27, i32 0, i32 7
  store i64 %t28, ptr %t31, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  store i64 %t33, ptr %l22, !tbaa !24
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/check:frame", ptr %t34, i32 0, i32 9
  %t38 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_Hf9d8b9e9334551fc04613fb711673451(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l25
  br label %bb4
bb4:
  %t39 = load i64, ptr %l21, !tbaa !24
  %t40 = insertvalue { i64, i64, i64 } undef, i64 %t39, 0
  %t41 = load i64, ptr %l22, !tbaa !24
  %t42 = insertvalue { i64, i64, i64 } %t40, i64 %t41, 1
  %t43 = load i64, ptr %l25, !tbaa !24
  %t44 = insertvalue { i64, i64, i64 } %t42, i64 %t43, 2
  store { i64, i64, i64 } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64, i64 }, ptr %rv
  ret { i64, i64, i64 } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/generic:Binding"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca { i64, ptr }
  %l49 = alloca %"compiler/generic:Binding"
  %l51 = alloca { i64, ptr }
  %l55 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l100 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l107 = alloca i32
  %l108 = alloca i64
  %l113 = alloca i32
  %l114 = alloca i32
  %l119 = alloca i1
  %l120 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l18, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l21, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %t17)
  store i32 %t20, ptr %l25
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l21, !tbaa !29
  %t22 = load i32, ptr %l25, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l26
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t25 = load i32, ptr %l26, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l27
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t27, ptr %l4, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp slt i64 %t28, 0
  br i1 %t30, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb6
bb5:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t38 = icmp sge i64 %t32, %t35
  store i1 %t38, ptr %l30, !tbaa !21
  br label %bb6
bb6:
  %t40 = load i1, ptr %l30, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t41, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t43)
  store i64 %t45, ptr %l37
  br label %bb10
bb10:
  %t46 = load i64, ptr %l37, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l41
  br label %bb11
bb11:
  %t55 = load i64, ptr %l41, !tbaa !24
  store i64 %t55, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp eq i64 %t56, 0
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t60, ptr %l44, !tbaa !27
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i32, ptr %t64, i64 %t61
  %t66 = load i32, ptr %t65, !tbaa !33
  call void @__olang_scope_close(ptr %s0)
  store i32 %t66, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t68, i64 %t69)
  store %"compiler/generic:Binding" %t72, ptr %l49
  br label %bb15
bb15:
  %t73 = load %"compiler/generic:Binding", ptr %l49
  store %"compiler/generic:Binding" %t73, ptr %l7
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t75, ptr %l51, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i32, ptr %t77, i64 0
  %t79 = load i32, ptr %t78, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t74, i32 %t79, i32 %a2, ptr %l7, i1 false, i1 true)
  br label %bb16
bb16:
  %t85 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  store i64 %t86, ptr %l55, !tbaa !24
  %t87 = load i64, ptr %l55, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t90 = load i64, ptr %l55, !tbaa !24
  %t91 = icmp sle i64 %t90, 2305843009213693951
  br i1 %t91, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d8c7da3a96e96ec6_ffec47baa4f6769a)
  unreachable
bb19:
  %t93 = load i64, ptr %l55, !tbaa !24
  %t94 = mul i64 %t93, 4
  %t95 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t99 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 1
  %t100 = load i64, ptr %t99, !tbaa !24
  store i64 %t100, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = icmp sgt i64 %t102, %t103
  br i1 %t106, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d8c7da3a96e96ec6_ffec47baa4f6769a)
  unreachable
bb21:
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = icmp sgt i64 %t108, 0
  br i1 %t110, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb26
bb23:
  %t112 = load i64, ptr %l10, !tbaa !24
  %t113 = load i64, ptr %l9, !tbaa !24
  %t116 = sub i64 %t112, %t113
  %t117 = load i64, ptr %l11, !tbaa !24
  %t120 = add i64 %t116, %t117
  %t122 = sub i64 %t120, 1
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = sdiv i64 %t122, %t123
  store i64 %t126, ptr %l66, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb25
bb25:
  %t128 = load i64, ptr %l66, !tbaa !24
  store i64 %t128, ptr %l63, !tbaa !24
  br label %bb26
bb26:
  %t129 = load i64, ptr %l63, !tbaa !24
  store i64 %t129, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t130 = load i64, ptr %l13, !tbaa !24
  %t131 = load i64, ptr %l12, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t138 = load i64, ptr %l9, !tbaa !24
  %t139 = load i64, ptr %l13, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l14, !tbaa !24
  %t148 = load i64, ptr %l14, !tbaa !24
  store i64 %t148, ptr %l84, !tbaa !24
  %t149 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  store { i64, ptr } %t150, ptr %l85, !tbaa !27
  %t151 = load i64, ptr %l14, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 %t151
  %t156 = load i32, ptr %t155, !tbaa !33
  %t157 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t160 = icmp ne i32 %t156, %t157
  br i1 %t160, label %bb31, label %bb32
bb31:
  %t162 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l91, !tbaa !27
  %t164 = load i64, ptr %l14, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i32, ptr %t167, i64 %t164
  %t169 = load i32, ptr %t168, !tbaa !33
  store i32 %t169, ptr %l90, !tbaa !23
  br label %bb34
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  %t177 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 0
  %t178 = load i64, ptr %t177, !tbaa !24
  %t179 = load i64, ptr %l14, !tbaa !24
  %t180 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t176, i64 %t178, i64 %t179, i64 %t180)
  store i32 %t185, ptr %l100
  br label %bb33
bb33:
  %t186 = load i32, ptr %l100, !tbaa !23
  store i32 %t186, ptr %l90, !tbaa !23
  br label %bb34
bb34:
  %t187 = load i32, ptr %l90, !tbaa !23
  %t188 = load i64, ptr %l84, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i32, ptr %t190, i64 %t188
  store i32 %t187, ptr %t191, !tbaa !33
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t192 = load i64, ptr %l13, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l13, !tbaa !24
  br label %bb27
bb36:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  store ptr %t199, ptr %l104, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t200, ptr %l105, !tbaa !27
  %t201 = load i64, ptr %l3, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr i32, ptr %t204, i64 %t201
  %t206 = load i32, ptr %t205, !tbaa !33
  store i32 %t206, ptr %l107, !tbaa !23
  %t207 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 0
  %t208 = load i64, ptr %t207, !tbaa !24
  store i64 %t208, ptr %l108, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/generic:Program", ptr %t212, i32 0, i32 2
  %t215 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t218 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t214, { i64, ptr } %t215)
  store i32 %t218, ptr %l113
  br label %bb37
bb37:
  %t219 = load ptr, ptr %l104, !tbaa !29
  %t220 = load i32, ptr %l107, !tbaa !23
  %t221 = load i64, ptr %l108, !tbaa !24
  %t222 = load i32, ptr %l113, !tbaa !23
  %t223 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t219, i32 %t220, i64 %t221, i32 %t222)
  store i32 %t223, ptr %l114
  br label %bb38
bb38:
  %t224 = load i32, ptr %l114, !tbaa !23
  store i32 %t224, ptr %l15, !tbaa !23
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = getelementptr %"compiler/generic:Program", ptr %t228, i32 0, i32 2
  %t231 = load i32, ptr %l15, !tbaa !23
  %t234 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t230, i32 %t231)
  store i1 %t234, ptr %l119
  br label %bb39
bb39:
  %t235 = load i1, ptr %l119, !tbaa !21
  br i1 %t235, label %bb40, label %bb41
bb40:
  %t236 = load i32, ptr %l15, !tbaa !23
  store i32 %t236, ptr %l120, !tbaa !23
  br label %bb42
bb41:
  %t238 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t238, ptr %l120, !tbaa !23
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t240 = load i32, ptr %l120, !tbaa !23
  store i32 %t240, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsEqual(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i1
  %l71 = alloca i32
  %l78 = alloca i32
  %l86 = alloca ptr
  %l90 = alloca i1
  %l93 = alloca i32
  %l101 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l137 = alloca i64
  %l140 = alloca i64
  %l158 = alloca ptr
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca i32
  %l164 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l183 = alloca ptr
  %l186 = alloca ptr
  %l188 = alloca %"compiler/source:Span"
  %l189 = alloca i32
  %l190 = alloca ptr
  %l192 = alloca ptr
  %l196 = alloca ptr
  %l197 = alloca %"compiler/typed:Cond"
  %l205 = alloca i64
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca i32
  %l213 = alloca { i64, ptr }
  %l216 = alloca %"compiler/typed:Seq"
  %s11 = alloca %olang.scope
  %rv = alloca ptr
  %t291 = alloca { i64, [4 x i64] }, align 8
  %t321 = alloca { i64, [4 x i64] }, align 8
  %t370 = alloca { i64, [5 x i64] }, align 8
  %t414 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l4, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i1, ptr %l22, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l27
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t17 = load i32, ptr %l27, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l28, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t19, ptr %l29
  store i32 75, ptr %l30
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t21, ptr %l32
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t25 = load %"compiler/source:Span", ptr %l1
  %t30 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t22, ptr %t23, i32 %t24, %"compiler/source:Span" %t25)
  store ptr %t30, ptr %l37
  br label %bb5
bb5:
  %t31 = load i32, ptr %l5, !tbaa !23
  %t32 = load ptr, ptr %l31, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l32
  %t34 = load ptr, ptr %l37, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t32, %"compiler/source:Span" %t33, ptr %t34, i32 %t31)
  store ptr %t36, ptr %l39
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l40, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t38, ptr %l41
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t41 = load i32, ptr %l4, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l1
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t39, ptr %t40, i32 %t41, %"compiler/source:Span" %t42)
  store ptr %t47, ptr %l46
  br label %bb7
bb7:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = load ptr, ptr %l40, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l41
  %t51 = load ptr, ptr %l46, !tbaa !29
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t49, %"compiler/source:Span" %t50, ptr %t51, i32 %t48)
  store ptr %t53, ptr %l48
  br label %bb8
bb8:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l29
  %t56 = load i32, ptr %l30
  %t57 = load ptr, ptr %l39, !tbaa !29
  %t58 = load ptr, ptr %l48, !tbaa !29
  %t59 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %t54, %"compiler/source:Span" %t55, i32 %t56, ptr %t57, ptr %t58)
  store ptr %t59, ptr %l49
  br label %bb9
bb9:
  %t60 = load ptr, ptr %l49, !tbaa !29
  store ptr %t60, ptr %rv
  br label %ret
bb10:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l55
  br label %bb11
bb11:
  %t72 = load i32, ptr %l55
  store i32 %t72, ptr %l6
  store i32 0, ptr %l7, !tbaa !23
  %t73 = load i32, ptr %l6
  %t75 = trunc i64 23 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb14
bb13:
  %t78 = load i32, ptr %l6
  %t80 = trunc i64 22 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l58, !tbaa !21
  br label %bb14
bb14:
  %t83 = load i1, ptr %l58, !tbaa !21
  br i1 %t83, label %bb15, label %bb16
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l4, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l65
  br label %bb17
bb16:
  %t94 = load i32, ptr %l6
  %t96 = trunc i64 18 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb18, label %bb19
bb17:
  %t99 = load i32, ptr %l65, !tbaa !23
  store i32 %t99, ptr %l7, !tbaa !23
  br label %bb36
bb18:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l4, !tbaa !23
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l71
  br label %bb20
bb19:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb21
bb20:
  %t105 = load i32, ptr %l71
  %t107 = trunc i64 0 to i32
  %t108 = icmp eq i32 %t105, %t107
  store i1 %t108, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t110 = load i1, ptr %l68, !tbaa !21
  br i1 %t110, label %bb22, label %bb23
bb22:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l4, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l78
  br label %bb24
bb23:
  %t121 = load i32, ptr %l6
  %t123 = trunc i64 19 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb25, label %bb26
bb24:
  %t126 = load i32, ptr %l78, !tbaa !23
  store i32 %t126, ptr %l7, !tbaa !23
  br label %bb35
bb25:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t131 = load i32, ptr %l4, !tbaa !23
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earraysEqual(ptr %v0, ptr %t127, %"compiler/source:Span" %t128, ptr %t129, ptr %t130, i32 %t131)
  store ptr %t137, ptr %l86
  br label %bb27
bb26:
  %t138 = load i32, ptr %l6
  %t140 = trunc i64 18 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb28, label %bb29
bb27:
  %t143 = load ptr, ptr %l86, !tbaa !29
  store ptr %t143, ptr %rv
  br label %ret
bb28:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l4, !tbaa !23
  %t149 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t149, ptr %l93
  br label %bb30
bb29:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb31
bb30:
  %t150 = load i32, ptr %l93
  %t152 = trunc i64 1 to i32
  %t153 = icmp eq i32 %t150, %t152
  store i1 %t153, ptr %l90, !tbaa !21
  br label %bb31
bb31:
  %t155 = load i1, ptr %l90, !tbaa !21
  br i1 %t155, label %bb32, label %bb33
bb32:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t159 = load ptr, ptr %l3, !tbaa !29
  %t160 = load i32, ptr %l4, !tbaa !23
  %t166 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumsEqual(ptr %v0, ptr %t156, %"compiler/source:Span" %t157, ptr %t158, ptr %t159, i32 %t160)
  store ptr %t166, ptr %l101
  br label %bb34
bb33:
  store ptr null, ptr %rv
  br label %ret
bb34:
  %t168 = load ptr, ptr %l101, !tbaa !29
  store ptr %t168, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 33
  %t174 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t172)
  store i64 %t174, ptr %l106
  br label %bb37
bb37:
  %t175 = load i64, ptr %l106, !tbaa !24
  store i64 %t175, ptr %l8, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l107, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t177, ptr %l108
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l2, !tbaa !29
  %t180 = load i32, ptr %l4, !tbaa !23
  %t181 = load %"compiler/source:Span", ptr %l1
  %t186 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t178, ptr %t179, i32 %t180, %"compiler/source:Span" %t181)
  store ptr %t186, ptr %l113
  br label %bb38
bb38:
  %t187 = load ptr, ptr %l107, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l108
  %t189 = load ptr, ptr %l113, !tbaa !29
  %t190 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %t187, %"compiler/source:Span" %t188, ptr %t189)
  store ptr %t190, ptr %l114
  br label %bb39
bb39:
  %t191 = load ptr, ptr %l114, !tbaa !29
  store ptr %t191, ptr %l9, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l115, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t193, ptr %l116
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t196 = load i32, ptr %l4, !tbaa !23
  %t197 = load %"compiler/source:Span", ptr %l1
  %t202 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t194, ptr %t195, i32 %t196, %"compiler/source:Span" %t197)
  store ptr %t202, ptr %l121
  br label %bb40
bb40:
  %t203 = load ptr, ptr %l115, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l116
  %t205 = load ptr, ptr %l121, !tbaa !29
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %t203, %"compiler/source:Span" %t204, ptr %t205)
  store ptr %t206, ptr %l122
  br label %bb41
bb41:
  %t207 = load ptr, ptr %l122, !tbaa !29
  store ptr %t207, ptr %l10, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l7, !tbaa !23
  %t217 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t213, i32 %t214)
  store { i64, ptr } %t217, ptr %l127
  br label %bb42
bb42:
  %t218 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t218, ptr %l11, !tbaa !27
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l1
  %t221 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t225 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t219, %"compiler/source:Span" %t220, i32 %t221, i64 1)
  store ptr %t225, ptr %l131
  br label %bb43
bb43:
  %t226 = load ptr, ptr %l131, !tbaa !29
  store ptr %t226, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  store i64 %t229, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t231 = load i64, ptr %l14, !tbaa !24
  %t232 = load i64, ptr %l13, !tbaa !24
  %t235 = icmp sgt i64 %t231, %t232
  br i1 %t235, label %bb44, label %bb45
bb44:
  %t237 = load i64, ptr %l15, !tbaa !24
  %t239 = icmp sgt i64 %t237, 0
  br i1 %t239, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb49
bb46:
  %t241 = load i64, ptr %l14, !tbaa !24
  %t242 = load i64, ptr %l13, !tbaa !24
  %t245 = sub i64 %t241, %t242
  %t246 = load i64, ptr %l15, !tbaa !24
  %t249 = add i64 %t245, %t246
  %t251 = sub i64 %t249, 1
  %t252 = load i64, ptr %l15, !tbaa !24
  %t255 = sdiv i64 %t251, %t252
  store i64 %t255, ptr %l140, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb48
bb48:
  %t257 = load i64, ptr %l140, !tbaa !24
  store i64 %t257, ptr %l137, !tbaa !24
  br label %bb49
bb49:
  %t258 = load i64, ptr %l137, !tbaa !24
  store i64 %t258, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t259 = load i64, ptr %l17, !tbaa !24
  %t260 = load i64, ptr %l16, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s11)
  br label %bb63
bb52:
  br label %bb53
bb53:
  %t267 = load i64, ptr %l13, !tbaa !24
  %t268 = load i64, ptr %l17, !tbaa !24
  %t269 = load i64, ptr %l15, !tbaa !24
  %t272 = mul i64 %t268, %t269
  %t275 = add i64 %t267, %t272
  store i64 %t275, ptr %l18, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l158, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t278, ptr %l159
  store i32 75, ptr %l160
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  %t281 = load %"compiler/source:Span", ptr %l1
  %t282 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t282, ptr %l164, !tbaa !27
  %t283 = load i64, ptr %l18, !tbaa !24
  %t285 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr i32, ptr %t286, i64 %t283
  %t288 = load i32, ptr %t287, !tbaa !33
  %t289 = load ptr, ptr %l9, !tbaa !29
  %t290 = load i64, ptr %l18, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 0
  store i64 3, ptr %t292
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t281, 0
  %t296 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t294, i32 %t288, 1
  %t298 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t296, ptr %t289, 2
  %t300 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t298, i64 %t290, 3
  %t301 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t300, ptr %t301
  %t302 = load { i64, [4 x i64] }, ptr %t291
  %t304 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t302, ptr %t304
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t279, %"compiler/source:Span" %t280, ptr %t304)
  store ptr %t308, ptr %l171
  br label %bb54
bb54:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  %t311 = load %"compiler/source:Span", ptr %l1
  %t312 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t312, ptr %l175, !tbaa !27
  %t313 = load i64, ptr %l18, !tbaa !24
  %t315 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr i32, ptr %t316, i64 %t313
  %t318 = load i32, ptr %t317, !tbaa !33
  %t319 = load ptr, ptr %l10, !tbaa !29
  %t320 = load i64, ptr %l18, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t321
  %t322 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 0
  store i64 3, ptr %t322
  %t324 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t311, 0
  %t326 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t324, i32 %t318, 1
  %t328 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t326, ptr %t319, 2
  %t330 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t328, i64 %t320, 3
  %t331 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t330, ptr %t331
  %t332 = load { i64, [4 x i64] }, ptr %t321
  %t334 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t332, ptr %t334
  %t338 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t309, %"compiler/source:Span" %t310, ptr %t334)
  store ptr %t338, ptr %l182
  br label %bb55
bb55:
  %t339 = load ptr, ptr %l158, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l159
  %t341 = load i32, ptr %l160
  %t342 = load ptr, ptr %l171, !tbaa !29
  %t343 = load ptr, ptr %l182, !tbaa !29
  %t344 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %t339, %"compiler/source:Span" %t340, i32 %t341, ptr %t342, ptr %t343)
  store ptr %t344, ptr %l183
  br label %bb56
bb56:
  %t345 = load ptr, ptr %l183, !tbaa !29
  store ptr %t345, ptr %l19, !tbaa !29
  %t346 = load i64, ptr %l18, !tbaa !24
  %t348 = icmp eq i64 %t346, 0
  br i1 %t348, label %bb57, label %bb58
bb57:
  %t350 = load ptr, ptr %l19, !tbaa !29
  store ptr %t350, ptr %l186, !tbaa !29
  br label %bb61
bb58:
  %t352 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t352, ptr %l188
  %t353 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t353, ptr %l189, !tbaa !23
  %t354 = load ptr, ptr %l12, !tbaa !29
  store ptr %t354, ptr %l190, !tbaa !29
  %t355 = load ptr, ptr %l19, !tbaa !29
  store ptr %t355, ptr %l192, !tbaa !29
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l1
  %t359 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t357, %"compiler/source:Span" %t358, i32 %t359, i64 0)
  store ptr %t363, ptr %l196
  br label %bb59
bb59:
  %t364 = load ptr, ptr %l190, !tbaa !29
  %t365 = load ptr, ptr %l192, !tbaa !29
  %t366 = load ptr, ptr %l196, !tbaa !29
  %t367 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t364, ptr %t365, ptr %t366)
  store %"compiler/typed:Cond" %t367, ptr %l197
  br label %bb60
bb60:
  %t368 = load %"compiler/typed:Cond", ptr %l197
  %t369 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t368, ptr %t369
  store { i64, [5 x i64] } zeroinitializer, ptr %t370
  %t371 = getelementptr { i64, [5 x i64] }, ptr %t370, i32 0, i32 0
  store i64 11, ptr %t371
  %t372 = load %"compiler/source:Span", ptr %l188
  %t373 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t372, 0
  %t374 = load i32, ptr %l189, !tbaa !23
  %t375 = insertvalue { %"compiler/source:Span", i32, ptr } %t373, i32 %t374, 1
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr } %t375, ptr %t369, 2
  %t378 = getelementptr { i64, [5 x i64] }, ptr %t370, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t377, ptr %t378
  %t379 = load { i64, [5 x i64] }, ptr %t370
  %t381 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t379, ptr %t381
  store ptr %t381, ptr %l186, !tbaa !29
  br label %bb61
bb61:
  %t383 = load ptr, ptr %l186, !tbaa !29
  store ptr %t383, ptr %l12, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  br label %bb62
bb62:
  %t384 = load i64, ptr %l17, !tbaa !24
  %t386 = add i64 %t384, 1
  store i64 %t386, ptr %l17, !tbaa !24
  br label %bb50
bb63:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 33
  %t392 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t390)
  store i64 %t392, ptr %l205
  br label %bb64
bb64:
  %t393 = load i64, ptr %l8, !tbaa !24
  %t394 = load i64, ptr %l205, !tbaa !24
  %t396 = icmp sgt i64 %t394, %t393
  br i1 %t396, label %bb65, label %bb66
bb65:
  %t398 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t398, ptr %l208
  %t399 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t399, ptr %l209, !tbaa !23
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 33
  %t403 = load i64, ptr %l8, !tbaa !24
  %t406 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t402, i64 %t403)
  store { i64, ptr } %t406, ptr %l213
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t407 = load ptr, ptr %l12, !tbaa !29
  %t409 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t411 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t409, ptr %t407)
  store %"compiler/typed:Seq" %t411, ptr %l216
  br label %bb68
bb68:
  %t412 = load %"compiler/typed:Seq", ptr %l216
  %t413 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t412, ptr %t413
  store { i64, [5 x i64] } zeroinitializer, ptr %t414
  %t415 = getelementptr { i64, [5 x i64] }, ptr %t414, i32 0, i32 0
  store i64 12, ptr %t415
  %t416 = load %"compiler/source:Span", ptr %l208
  %t417 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t416, 0
  %t418 = load i32, ptr %l209, !tbaa !23
  %t419 = insertvalue { %"compiler/source:Span", i32, ptr } %t417, i32 %t418, 1
  %t421 = insertvalue { %"compiler/source:Span", i32, ptr } %t419, ptr %t413, 2
  %t422 = getelementptr { i64, [5 x i64] }, ptr %t414, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t421, ptr %t422
  %t423 = load { i64, [5 x i64] }, ptr %t414
  %t425 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t423, ptr %t425
  store ptr %t425, ptr %rv
  br label %ret
bb69:
  %t427 = load ptr, ptr %l12, !tbaa !29
  store ptr %t427, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca %"compiler/names:Ref"
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca ptr
  %l42 = alloca ptr
  %l46 = alloca %"compiler/names:Ref"
  %l49 = alloca i1
  %l53 = alloca i1
  %l60 = alloca i64
  %l63 = alloca i1
  %l65 = alloca ptr
  %l72 = alloca ptr
  %l76 = alloca i64
  %l79 = alloca i64
  %l81 = alloca %"compiler/source:Span"
  %l84 = alloca i32
  %l88 = alloca ptr
  %l92 = alloca i32
  %l96 = alloca %"compiler/source:Span"
  %l99 = alloca i32
  %l108 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l116 = alloca i32
  %l121 = alloca ptr
  %l122 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca i1
  %l142 = alloca ptr
  %l144 = alloca ptr
  %l148 = alloca %"compiler/names:Ref"
  %l151 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l162 = alloca i1
  %l165 = alloca i32
  %l170 = alloca i64
  %l173 = alloca %"compiler/source:Span"
  %l176 = alloca i32
  %l180 = alloca ptr
  %l184 = alloca i32
  %l189 = alloca ptr
  %l193 = alloca ptr
  %l194 = alloca %"compiler/source:Span"
  %l195 = alloca %"compiler/source:Span"
  %l198 = alloca { i64, ptr }
  %l200 = alloca %"compiler/source:Span"
  %l203 = alloca ptr
  %l204 = alloca ptr
  %l205 = alloca i1
  %l216 = alloca i32
  %l218 = alloca i1
  %l221 = alloca %"compiler/check:reflList"
  %l228 = alloca ptr
  %l229 = alloca ptr
  %l230 = alloca i1
  %l239 = alloca ptr
  %l240 = alloca i1
  %l251 = alloca { i64, ptr }
  %l252 = alloca i1
  %l255 = alloca i32
  %l262 = alloca ptr
  %l263 = alloca %"compiler/source:Span"
  %l265 = alloca %"compiler/source:Span"
  %l268 = alloca ptr
  %l273 = alloca ptr
  %l276 = alloca i32
  %l282 = alloca ptr
  %l289 = alloca %"compiler/source:Span"
  %l290 = alloca i32
  %l291 = alloca ptr
  %l292 = alloca ptr
  %l293 = alloca i32
  %l295 = alloca %"compiler/source:Span"
  %l296 = alloca i32
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t138 = alloca { i64, [4 x i64] }, align 8
  %t165 = alloca { i64, [4 x i64] }, align 8
  %t205 = alloca { i64, [4 x i64] }, align 8
  %t307 = alloca { i64, [4 x i64] }, align 8
  %t368 = alloca { i64, [4 x i64] }, align 8
  %t612 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 9
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 9
  store i1 false, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t10 = load ptr, ptr %l30, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l30, !tbaa !29
  %t14 = load i64, ptr %t13
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l31, !tbaa !21
  br label %bb2
bb2:
  %t17 = load i1, ptr %l31, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32 }, ptr %t20, i32 0, i32 0
  %t22 = load %"compiler/source:Span", ptr %t21
  store %"compiler/source:Span" %t22, ptr %l3
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32 }, ptr %t26, i32 0, i32 1
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb46
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l40, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t37)
  store ptr %t39, ptr %l42
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l42, !tbaa !29
  %t42 = getelementptr %"compiler/check:frame", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = load ptr, ptr %l40, !tbaa !29
  %t49 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t46, i64 %t43, i32 %t45)
  store %"compiler/names:Ref" %t49, ptr %l46
  br label %bb7
bb7:
  %t50 = load %"compiler/names:Ref", ptr %l46
  store %"compiler/names:Ref" %t50, ptr %l5
  %t51 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t52 = load i32, ptr %t51
  %t54 = trunc i64 1 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb8, label %bb9
bb8:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l3
  %t59 = load i32, ptr %l4, !tbaa !23
  %t63 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMisused(ptr %v0, ptr %t57, %"compiler/source:Span" %t58, i32 %t59)
  store i1 %t63, ptr %l53
  br label %bb10
bb9:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb11
bb10:
  %t64 = load i1, ptr %l53, !tbaa !21
  store i1 %t64, ptr %l49, !tbaa !21
  br label %bb11
bb11:
  %t65 = load i1, ptr %l49, !tbaa !21
  br i1 %t65, label %bb12, label %bb13
bb12:
  store ptr null, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t67 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t68 = load i32, ptr %t67
  %t70 = trunc i64 1 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l4, !tbaa !23
  %t75 = load %"compiler/source:Span", ptr %l3
  %t79 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %t73, i32 %t74, %"compiler/source:Span" %t75)
  store i64 %t79, ptr %l60
  br label %bb17
bb16:
  br label %bb41
bb17:
  %t80 = load i64, ptr %l60, !tbaa !24
  store i64 %t80, ptr %l6, !tbaa !24
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = icmp slt i64 %t81, 0
  br i1 %t83, label %bb18, label %bb19
bb18:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t85)
  store ptr %t87, ptr %l65
  br label %bb20
bb19:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb21
bb20:
  %t88 = load ptr, ptr %l65, !tbaa !29
  %t90 = getelementptr %"compiler/check:frame", ptr %t88, i32 0, i32 28
  %t91 = load i64, ptr %t90, !tbaa !24
  %t93 = icmp sge i64 %t91, 0
  store i1 %t93, ptr %l63, !tbaa !21
  br label %bb21
bb21:
  %t95 = load i1, ptr %l63, !tbaa !21
  br i1 %t95, label %bb22, label %bb23
bb22:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l3
  %t98 = load i32, ptr %l4, !tbaa !23
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %t96, %"compiler/source:Span" %t97, i32 %t98)
  store ptr %t102, ptr %l72
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t103 = load ptr, ptr %l72, !tbaa !29
  store ptr %t103, ptr %rv
  br label %ret
bb25:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t106 = icmp slt i64 %t104, 0
  br i1 %t106, label %bb26, label %bb27
bb26:
  store ptr null, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t109 = load i64, ptr %l6, !tbaa !24
  store i64 %t109, ptr %l76, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i32, ptr %l4, !tbaa !23
  %t114 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t110, i32 %t111)
  store i64 %t114, ptr %l79
  br label %bb29
bb29:
  %t115 = load i64, ptr %l76, !tbaa !24
  %t116 = load i64, ptr %l79, !tbaa !24
  %t117 = icmp ne i64 %t115, %t116
  br i1 %t117, label %bb30, label %bb31
bb30:
  %t119 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t119, ptr %l81
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i64, ptr %l6, !tbaa !24
  %t124 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t120, i64 %t121)
  store i32 %t124, ptr %l84
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l3
  %t127 = load i64, ptr %l6, !tbaa !24
  %t131 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t125, %"compiler/source:Span" %t126, i64 %t127)
  store ptr %t131, ptr %l88
  br label %bb33
bb33:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l3
  %t137 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t132, i32 8, %"compiler/source:Span" %t133)
  store i32 %t137, ptr %l92
  br label %bb34
bb34:
  store { i64, [4 x i64] } zeroinitializer, ptr %t138
  %t139 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 0
  store i64 6, ptr %t139
  %t140 = load %"compiler/source:Span", ptr %l81
  %t141 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t140, 0
  %t142 = load i32, ptr %l84, !tbaa !23
  %t143 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t141, i32 %t142, 1
  %t144 = load ptr, ptr %l88, !tbaa !29
  %t145 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t143, ptr %t144, 2
  %t146 = load i32, ptr %l92, !tbaa !23
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t145, i32 %t146, 3
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t147, ptr %t148
  %t149 = load { i64, [4 x i64] }, ptr %t138
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t149, ptr %t151
  store ptr %t151, ptr %rv
  br label %ret
bb35:
  %t153 = load i1, ptr %l2, !tbaa !21
  br i1 %t153, label %bb36, label %bb37
bb36:
  %t155 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t155, ptr %l96
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i64, ptr %l6, !tbaa !24
  %t160 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t156, i64 %t157)
  store i32 %t160, ptr %l99
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t161 = load i64, ptr %l6, !tbaa !24
  %t163 = trunc i64 %t161 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 0
  store i64 0, ptr %t166
  %t167 = load %"compiler/source:Span", ptr %l96
  %t168 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t167, 0
  %t169 = load i32, ptr %l99, !tbaa !23
  %t170 = insertvalue { %"compiler/source:Span", i32, i32 } %t168, i32 %t169, 1
  %t172 = insertvalue { %"compiler/source:Span", i32, i32 } %t170, i32 %t163, 2
  %t173 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t172, ptr %t173
  %t174 = load { i64, [4 x i64] }, ptr %t165
  %t176 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t174, ptr %t176
  store ptr %t176, ptr %rv
  br label %ret
bb39:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l3
  %t180 = load i64, ptr %l6, !tbaa !24
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %t178, %"compiler/source:Span" %t179, i64 %t180)
  store ptr %t184, ptr %l108
  br label %bb40
bb40:
  %t185 = load ptr, ptr %l108, !tbaa !29
  store ptr %t185, ptr %rv
  br label %ret
bb41:
  %t187 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t188 = load i32, ptr %t187
  %t190 = trunc i64 2 to i32
  %t191 = icmp eq i32 %t188, %t190
  br i1 %t191, label %bb42, label %bb43
bb42:
  %t193 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t193, ptr %l112
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t196 = load i64, ptr %t195, !tbaa !24
  %t197 = load i32, ptr %l4, !tbaa !23
  %t201 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t194, i64 %t196, i32 %t197)
  store i32 %t201, ptr %l116
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t202 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t203 = load i64, ptr %t202, !tbaa !24
  %t204 = load i32, ptr %l4, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t205, i32 0, i32 0
  store i64 1, ptr %t206
  %t207 = load %"compiler/source:Span", ptr %l112
  %t208 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t207, 0
  %t209 = load i32, ptr %l116, !tbaa !23
  %t210 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t208, i32 %t209, 1
  %t212 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t210, i64 %t203, 2
  %t214 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t212, i32 %t204, 3
  %t215 = getelementptr { i64, [4 x i64] }, ptr %t205, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t214, ptr %t215
  %t216 = load { i64, [4 x i64] }, ptr %t205
  %t218 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t216, ptr %t218
  store ptr %t218, ptr %rv
  br label %ret
bb45:
  br label %bb129
bb46:
  %t220 = load ptr, ptr %l1, !tbaa !29
  store ptr %t220, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t221 = load ptr, ptr %l121, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb47, label %bb48
bb47:
  %t224 = load ptr, ptr %l121, !tbaa !29
  %t225 = load i64, ptr %t224
  %t227 = icmp eq i64 %t225, 2
  store i1 %t227, ptr %l122, !tbaa !21
  br label %bb48
bb48:
  %t228 = load i1, ptr %l122, !tbaa !21
  br i1 %t228, label %bb49, label %bb50
bb49:
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", ptr }, ptr %t231, i32 0, i32 1
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l7, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l7, !tbaa !29
  %t239 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t235, ptr %t236)
  store ptr %t239, ptr %l129
  br label %bb52
bb52:
  %t240 = load ptr, ptr %l129, !tbaa !29
  store ptr %t240, ptr %rv
  br label %ret
bb53:
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t242 = load ptr, ptr %l130, !tbaa !29
  %t243 = icmp ne ptr %t242, null
  br i1 %t243, label %bb54, label %bb55
bb54:
  %t245 = load ptr, ptr %l130, !tbaa !29
  %t246 = load i64, ptr %t245
  %t248 = icmp eq i64 %t246, 15
  store i1 %t248, ptr %l131, !tbaa !21
  br label %bb55
bb55:
  %t249 = load i1, ptr %l131, !tbaa !21
  br i1 %t249, label %bb56, label %bb57
bb56:
  %t250 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr { i64, [5 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t252, i32 0, i32 0
  %t254 = load %"compiler/source:Span", ptr %t253
  store %"compiler/source:Span" %t254, ptr %l8
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l9, !tbaa !29
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [5 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t264, i32 0, i32 2
  %t266 = load i32, ptr %t265
  store i32 %t266, ptr %l10, !tbaa !23
  br label %bb58
bb57:
  br label %bb86
bb58:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !29
  store ptr %t274, ptr %l142, !tbaa !29
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t275)
  store ptr %t277, ptr %l144
  br label %bb59
bb59:
  %t278 = load ptr, ptr %l144, !tbaa !29
  %t280 = getelementptr %"compiler/check:frame", ptr %t278, i32 0, i32 2
  %t281 = load i64, ptr %t280, !tbaa !24
  %t282 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t283 = load i32, ptr %t282, !tbaa !23
  %t284 = load ptr, ptr %l142, !tbaa !29
  %t287 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t284, i64 %t281, i32 %t283)
  store %"compiler/names:Ref" %t287, ptr %l148
  br label %bb60
bb60:
  %t288 = load %"compiler/names:Ref", ptr %l148
  store %"compiler/names:Ref" %t288, ptr %l11
  %t289 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 0
  %t290 = load i32, ptr %t289
  %t292 = trunc i64 2 to i32
  %t293 = icmp eq i32 %t290, %t292
  br i1 %t293, label %bb61, label %bb62
bb61:
  %t295 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t295, ptr %l151
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 1
  %t298 = load i64, ptr %t297, !tbaa !24
  %t299 = load i32, ptr %l10, !tbaa !23
  %t303 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t296, i64 %t298, i32 %t299)
  store i32 %t303, ptr %l155
  br label %bb63
bb62:
  br label %bb64
bb63:
  %t304 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 1
  %t305 = load i64, ptr %t304, !tbaa !24
  %t306 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t307
  %t308 = getelementptr { i64, [4 x i64] }, ptr %t307, i32 0, i32 0
  store i64 1, ptr %t308
  %t309 = load %"compiler/source:Span", ptr %l151
  %t310 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t309, 0
  %t311 = load i32, ptr %l155, !tbaa !23
  %t312 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t310, i32 %t311, 1
  %t314 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t312, i64 %t305, 2
  %t316 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t314, i32 %t306, 3
  %t317 = getelementptr { i64, [4 x i64] }, ptr %t307, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t316, ptr %t317
  %t318 = load { i64, [4 x i64] }, ptr %t307
  %t320 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t318, ptr %t320
  store ptr %t320, ptr %rv
  br label %ret
bb64:
  %t322 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 0
  %t323 = load i32, ptr %t322
  %t325 = trunc i64 0 to i32
  %t326 = icmp eq i32 %t323, %t325
  br i1 %t326, label %bb65, label %bb66
bb65:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load ptr, ptr %l9, !tbaa !29
  %t332 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t328, ptr %t329)
  store i32 %t332, ptr %l165
  br label %bb67
bb66:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb68
bb67:
  %t333 = load i32, ptr %l165, !tbaa !23
  %t334 = icmp slt i32 %t333, 0
  store i1 %t334, ptr %l162, !tbaa !21
  br label %bb68
bb68:
  %t336 = load i1, ptr %l162, !tbaa !21
  br i1 %t336, label %bb69, label %bb70
bb69:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load ptr, ptr %l9, !tbaa !29
  %t339 = load i32, ptr %l10, !tbaa !23
  %t343 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedName(ptr %v0, ptr %v1, ptr %t337, ptr %t338, i32 %t339)
  store i64 %t343, ptr %l170
  br label %bb71
bb70:
  br label %bb85
bb71:
  %t344 = load i64, ptr %l170, !tbaa !24
  store i64 %t344, ptr %l12, !tbaa !24
  %t345 = load i64, ptr %l12, !tbaa !24
  %t347 = icmp sge i64 %t345, 0
  br i1 %t347, label %bb72, label %bb73
bb72:
  %t349 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t349, ptr %l173
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load i64, ptr %l12, !tbaa !24
  %t354 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t350, i64 %t351)
  store i32 %t354, ptr %l176
  br label %bb74
bb73:
  br label %bb77
bb74:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l8
  %t357 = load i64, ptr %l12, !tbaa !24
  %t361 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t355, %"compiler/source:Span" %t356, i64 %t357)
  store ptr %t361, ptr %l180
  br label %bb75
bb75:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load %"compiler/source:Span", ptr %l8
  %t367 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t362, i32 8, %"compiler/source:Span" %t363)
  store i32 %t367, ptr %l184
  br label %bb76
bb76:
  store { i64, [4 x i64] } zeroinitializer, ptr %t368
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 0
  store i64 6, ptr %t369
  %t370 = load %"compiler/source:Span", ptr %l173
  %t371 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t370, 0
  %t372 = load i32, ptr %l176, !tbaa !23
  %t373 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t371, i32 %t372, 1
  %t374 = load ptr, ptr %l180, !tbaa !29
  %t375 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t373, ptr %t374, 2
  %t376 = load i32, ptr %l184, !tbaa !23
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t375, i32 %t376, 3
  %t378 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t377, ptr %t378
  %t379 = load { i64, [4 x i64] }, ptr %t368
  %t381 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t379, ptr %t381
  store ptr %t381, ptr %rv
  br label %ret
bb77:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load ptr, ptr %l9, !tbaa !29
  %t387 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t383, ptr %t384)
  store ptr %t387, ptr %l189
  br label %bb78
bb78:
  %t388 = load ptr, ptr %l189, !tbaa !29
  store ptr %t388, ptr %l13, !tbaa !29
  %t389 = load ptr, ptr %l13, !tbaa !29
  %t391 = icmp eq ptr %t389, null
  br i1 %t391, label %bb79, label %bb80
bb79:
  store ptr null, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  %t394 = load ptr, ptr %l0, !tbaa !29
  store ptr %t394, ptr %l193, !tbaa !29
  %t395 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t395, ptr %l194
  %t396 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t396, ptr %l195
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load i32, ptr %l10, !tbaa !23
  %t401 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t397, i32 %t398)
  store { i64, ptr } %t401, ptr %l198
  br label %bb82
bb82:
  %t402 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t403 = extractvalue { i64, ptr } %t402, 0
  %t404 = load %"compiler/source:Span", ptr %l195
  %t406 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t404, i64 %t403)
  store %"compiler/source:Span" %t406, ptr %l200
  br label %bb83
bb83:
  %t407 = load ptr, ptr %l13, !tbaa !29
  %t408 = load i32, ptr %l10, !tbaa !23
  %t409 = load ptr, ptr %l193, !tbaa !29
  %t410 = load %"compiler/source:Span", ptr %l194
  %t411 = load %"compiler/source:Span", ptr %l200
  %t414 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %t409, %"compiler/source:Span" %t410, %"compiler/source:Span" %t411, ptr %t407, i32 %t408)
  store ptr %t414, ptr %l203
  br label %bb84
bb84:
  %t415 = load ptr, ptr %l203, !tbaa !29
  store ptr %t415, ptr %rv
  br label %ret
bb85:
  br label %bb129
bb86:
  %t416 = load ptr, ptr %l1, !tbaa !29
  store ptr %t416, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t417 = load ptr, ptr %l204, !tbaa !29
  %t418 = icmp ne ptr %t417, null
  br i1 %t418, label %bb87, label %bb88
bb87:
  %t420 = load ptr, ptr %l204, !tbaa !29
  %t421 = load i64, ptr %t420
  %t423 = icmp eq i64 %t421, 16
  store i1 %t423, ptr %l205, !tbaa !21
  br label %bb88
bb88:
  %t424 = load i1, ptr %l205, !tbaa !21
  br i1 %t424, label %bb89, label %bb90
bb89:
  %t425 = load ptr, ptr %l1, !tbaa !29
  %t427 = getelementptr { i64, [5 x i64] }, ptr %t425, i32 0, i32 1
  %t428 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t427, i32 0, i32 0
  %t429 = load %"compiler/source:Span", ptr %t428
  store %"compiler/source:Span" %t429, ptr %l14
  %t431 = load ptr, ptr %l1, !tbaa !29
  %t433 = getelementptr { i64, [5 x i64] }, ptr %t431, i32 0, i32 1
  %t434 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t433, i32 0, i32 1
  %t435 = load ptr, ptr %t434
  store ptr %t435, ptr %l15, !tbaa !29
  %t437 = load ptr, ptr %l1, !tbaa !29
  %t439 = getelementptr { i64, [5 x i64] }, ptr %t437, i32 0, i32 1
  %t440 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t439, i32 0, i32 2
  %t441 = load { i64, ptr }, ptr %t440
  store { i64, ptr } %t441, ptr %l16, !tbaa !27
  br label %bb91
bb90:
  br label %bb101
bb91:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load ptr, ptr %l15, !tbaa !29
  %t447 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t443, ptr %t444)
  store i32 %t447, ptr %l216
  br label %bb92
bb92:
  %t448 = load i32, ptr %l216, !tbaa !23
  %t449 = icmp slt i32 %t448, 0
  br i1 %t449, label %bb93, label %bb94
bb93:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load ptr, ptr %l15, !tbaa !29
  %t455 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t451, ptr %t452)
  store %"compiler/check:reflList" %t455, ptr %l221
  br label %bb95
bb94:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb96
bb95:
  %t456 = getelementptr %"compiler/check:reflList", ptr %l221, i32 0, i32 0
  %t457 = load i1, ptr %t456, !tbaa !21
  %t459 = xor i1 %t457, true
  store i1 %t459, ptr %l218, !tbaa !21
  br label %bb96
bb96:
  %t461 = load i1, ptr %l218, !tbaa !21
  br i1 %t461, label %bb97, label %bb98
bb97:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load %"compiler/source:Span", ptr %l14
  %t464 = load ptr, ptr %l15, !tbaa !29
  %t465 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t470 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexPlace(ptr %v0, ptr %v1, ptr %v1, ptr %t462, %"compiler/source:Span" %t463, ptr %t464, { i64, ptr } %t465)
  store ptr %t470, ptr %l228
  br label %bb99
bb98:
  br label %bb100
bb99:
  %t471 = load ptr, ptr %l228, !tbaa !29
  store ptr %t471, ptr %rv
  br label %ret
bb100:
  br label %bb129
bb101:
  %t472 = load ptr, ptr %l1, !tbaa !29
  store ptr %t472, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t473 = load ptr, ptr %l229, !tbaa !29
  %t474 = icmp ne ptr %t473, null
  br i1 %t474, label %bb102, label %bb103
bb102:
  %t476 = load ptr, ptr %l229, !tbaa !29
  %t477 = load i64, ptr %t476
  %t479 = icmp eq i64 %t477, 12
  store i1 %t479, ptr %l230, !tbaa !21
  br label %bb103
bb103:
  %t480 = load i1, ptr %l230, !tbaa !21
  br i1 %t480, label %bb104, label %bb105
bb104:
  %t481 = load ptr, ptr %l1, !tbaa !29
  %t483 = getelementptr { i64, [5 x i64] }, ptr %t481, i32 0, i32 1
  %t484 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t483, i32 0, i32 0
  %t485 = load %"compiler/source:Span", ptr %t484
  store %"compiler/source:Span" %t485, ptr %l17
  %t487 = load ptr, ptr %l1, !tbaa !29
  %t489 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 1
  %t490 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t489, i32 0, i32 1
  %t491 = load ptr, ptr %t490
  store ptr %t491, ptr %l18, !tbaa !29
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t495 = getelementptr { i64, [5 x i64] }, ptr %t493, i32 0, i32 1
  %t496 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t495, i32 0, i32 2
  %t497 = load { i64, ptr }, ptr %t496
  store { i64, ptr } %t497, ptr %l19, !tbaa !27
  br label %bb106
bb105:
  br label %bb128
bb106:
  %t499 = load ptr, ptr %l18, !tbaa !29
  store ptr %t499, ptr %l239, !tbaa !29
  store i1 false, ptr %l240, !tbaa !21
  %t500 = load ptr, ptr %l239, !tbaa !29
  %t501 = icmp ne ptr %t500, null
  br i1 %t501, label %bb107, label %bb108
bb107:
  %t503 = load ptr, ptr %l239, !tbaa !29
  %t504 = load i64, ptr %t503
  %t506 = icmp eq i64 %t504, 15
  store i1 %t506, ptr %l240, !tbaa !21
  br label %bb108
bb108:
  %t507 = load i1, ptr %l240, !tbaa !21
  br i1 %t507, label %bb109, label %bb110
bb109:
  %t508 = load ptr, ptr %l18, !tbaa !29
  %t510 = getelementptr { i64, [5 x i64] }, ptr %t508, i32 0, i32 1
  %t511 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t510, i32 0, i32 0
  %t512 = load %"compiler/source:Span", ptr %t511
  store %"compiler/source:Span" %t512, ptr %l20
  %t514 = load ptr, ptr %l18, !tbaa !29
  %t516 = getelementptr { i64, [5 x i64] }, ptr %t514, i32 0, i32 1
  %t517 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t516, i32 0, i32 1
  %t518 = load ptr, ptr %t517
  store ptr %t518, ptr %l21, !tbaa !29
  %t520 = load ptr, ptr %l18, !tbaa !29
  %t522 = getelementptr { i64, [5 x i64] }, ptr %t520, i32 0, i32 1
  %t523 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t522, i32 0, i32 2
  %t524 = load i32, ptr %t523
  store i32 %t524, ptr %l22, !tbaa !23
  br label %bb111
bb110:
  br label %bb126
bb111:
  store %olang.scope zeroinitializer, ptr %s18
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load i32, ptr %l22, !tbaa !23
  %t530 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t526, i32 %t527)
  store { i64, ptr } %t530, ptr %l251
  br label %bb112
bb112:
  %t531 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t532 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s18, { i64, ptr } %t531, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t532, ptr %l252
  br label %bb113
bb113:
  %t533 = load i1, ptr %l252, !tbaa !21
  br i1 %t533, label %bb114, label %bb115
bb114:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t535 = load ptr, ptr %l21, !tbaa !29
  %t538 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t534, ptr %t535)
  store i32 %t538, ptr %l255
  br label %bb116
bb115:
  br label %bb125
bb116:
  %t539 = load i32, ptr %l255, !tbaa !23
  store i32 %t539, ptr %l23, !tbaa !23
  %t540 = load i32, ptr %l23, !tbaa !23
  %t542 = icmp sge i32 %t540, 0
  br i1 %t542, label %bb117, label %bb118
bb117:
  %t544 = load i32, ptr %l23, !tbaa !23
  %t545 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t548 = icmp eq i32 %t544, %t545
  br i1 %t548, label %bb119, label %bb120
bb118:
  br label %bb124
bb119:
  call void @__olang_scope_close(ptr %s18)
  store ptr null, ptr %rv
  br label %ret
bb120:
  br label %bb121
bb121:
  %t551 = load ptr, ptr %l0, !tbaa !29
  store ptr %t551, ptr %l262, !tbaa !29
  %t552 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t552, ptr %l263
  %t553 = load %"compiler/source:Span", ptr %l20
  %t555 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t553, i64 2)
  store %"compiler/source:Span" %t555, ptr %l265
  br label %bb122
bb122:
  %t556 = load i32, ptr %l23, !tbaa !23
  %t557 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t558 = load ptr, ptr %l262, !tbaa !29
  %t559 = load %"compiler/source:Span", ptr %l263
  %t560 = load %"compiler/source:Span", ptr %l265
  %t563 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflOf(ptr %v0, ptr %v1, ptr %t558, %"compiler/source:Span" %t559, %"compiler/source:Span" %t560, i32 %t556, { i64, ptr } %t557)
  store ptr %t563, ptr %l268
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s18)
  %t564 = load ptr, ptr %l268, !tbaa !29
  store ptr %t564, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s18)
  br label %bb127
bb126:
  br label %bb127
bb127:
  br label %bb129
bb128:
  br label %bb129
bb129:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load ptr, ptr %l1, !tbaa !29
  %t568 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t572 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t565, ptr %t566, i32 %t568)
  store ptr %t572, ptr %l273
  br label %bb130
bb130:
  %t573 = load ptr, ptr %l273, !tbaa !29
  store ptr %t573, ptr %l24, !tbaa !29
  %t574 = load ptr, ptr %l24, !tbaa !29
  %t577 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t574)
  store i32 %t577, ptr %l276
  br label %bb131
bb131:
  %t578 = load i32, ptr %l276, !tbaa !23
  store i32 %t578, ptr %l25, !tbaa !23
  %t579 = load i32, ptr %l25, !tbaa !23
  %t580 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t583 = icmp eq i32 %t579, %t580
  br i1 %t583, label %bb132, label %bb133
bb132:
  store ptr null, ptr %rv
  br label %ret
bb133:
  br label %bb134
bb134:
  %t586 = load ptr, ptr %l24, !tbaa !29
  %t588 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t586)
  store ptr %t588, ptr %l282
  br label %bb135
bb135:
  %t589 = load ptr, ptr %l282, !tbaa !29
  store ptr %t589, ptr %l26, !tbaa !29
  %t590 = load ptr, ptr %l26, !tbaa !29
  %t592 = icmp eq ptr %t590, null
  %t594 = xor i1 %t592, true
  br i1 %t594, label %bb136, label %bb137
bb136:
  %t596 = load ptr, ptr %l26, !tbaa !29
  store ptr %t596, ptr %rv
  br label %ret
bb137:
  br label %bb138
bb138:
  %t599 = load ptr, ptr %l1, !tbaa !29
  %t601 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t599)
  store %"compiler/source:Span" %t601, ptr %l289
  br label %bb139
bb139:
  %t602 = load i32, ptr %l25, !tbaa !23
  store i32 %t602, ptr %l290, !tbaa !23
  %t603 = load ptr, ptr %l24, !tbaa !29
  store ptr %t603, ptr %l291, !tbaa !29
  %t604 = load ptr, ptr %l0, !tbaa !29
  store ptr %t604, ptr %l292, !tbaa !29
  store i32 8, ptr %l293
  %t605 = load ptr, ptr %l1, !tbaa !29
  %t607 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t605)
  store %"compiler/source:Span" %t607, ptr %l295
  br label %bb140
bb140:
  %t608 = load ptr, ptr %l292, !tbaa !29
  %t609 = load i32, ptr %l293
  %t610 = load %"compiler/source:Span", ptr %l295
  %t611 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t608, i32 %t609, %"compiler/source:Span" %t610)
  store i32 %t611, ptr %l296
  br label %bb141
bb141:
  store { i64, [4 x i64] } zeroinitializer, ptr %t612
  %t613 = getelementptr { i64, [4 x i64] }, ptr %t612, i32 0, i32 0
  store i64 6, ptr %t613
  %t614 = load %"compiler/source:Span", ptr %l289
  %t615 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t614, 0
  %t616 = load i32, ptr %l290, !tbaa !23
  %t617 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t615, i32 %t616, 1
  %t618 = load ptr, ptr %l291, !tbaa !29
  %t619 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t617, ptr %t618, 2
  %t620 = load i32, ptr %l296, !tbaa !23
  %t621 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t619, i32 %t620, 3
  %t622 = getelementptr { i64, [4 x i64] }, ptr %t612, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t621, ptr %t622
  %t623 = load { i64, [4 x i64] }, ptr %t612
  %t625 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t623, ptr %t625
  store ptr %t625, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/generic:Desc"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i32, { i64, ptr } }
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/check:narrowed"
  %l25 = alloca { i64, ptr }
  %lp27 = alloca ptr
  %l31 = alloca %"compiler/generic:Desc"
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l40 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca %"compiler/msgs:Msg"
  %l46 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/msgs:Msg"
  %l58 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l71 = alloca i32
  %l75 = alloca i64
  %l78 = alloca i64
  %l98 = alloca i1
  %l102 = alloca %"compiler/source:Span"
  %l107 = alloca i32
  %l111 = alloca ptr
  %l118 = alloca i32
  %l130 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l144 = alloca %"compiler/msgs:Msg"
  %l145 = alloca i64
  %l150 = alloca { i32, { i64, ptr } }
  %l154 = alloca i1
  %l162 = alloca { i64, ptr }
  %l164 = alloca i64
  %l166 = alloca ptr
  %l169 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l173 = alloca i32
  %l182 = alloca { i64, ptr }
  %l188 = alloca i1
  %l203 = alloca { i64, ptr }
  %l204 = alloca ptr
  %l205 = alloca { i64, ptr }
  %l207 = alloca %"compiler/source:Span"
  %l210 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l222 = alloca %"compiler/msgs:Msg"
  %l223 = alloca i64
  %l227 = alloca ptr
  %l232 = alloca i32
  %l233 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l237 = alloca %"compiler/source:Span"
  %l238 = alloca i32
  %l242 = alloca %"compiler/typed:Payload"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca ptr
  %t164 = alloca { i64, [4 x i64] }, align 8
  %t279 = alloca { i64, [4 x i64] }, align 8
  %t494 = alloca { i64, [4 x i64] }, align 8
  %t512 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t4, i32 %a3)
  store %"compiler/generic:Desc" %t8, ptr %l31
  br label %bb1
bb1:
  %t9 = load %"compiler/generic:Desc", ptr %l31
  store %"compiler/generic:Desc" %t9, ptr %l5
  %t10 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t15 = icmp ne i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l35, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l36
  %t19 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t24 = icmp eq i64 %t20, %t21
  br i1 %t24, label %bb4, label %bb5
bb3:
  br label %bb13
bb4:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb9
bb5:
  %t26 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t31 = icmp eq i64 %t27, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t33, ptr %l40, !tbaa !27
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %s1, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t34, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t35, ptr %l45
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l35, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l36
  %t38 = load %"compiler/msgs:Msg", ptr %l45
  %t39 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t36, %"compiler/source:Span" %t37, %"compiler/msgs:Msg" %t38)
  store i64 %t39, ptr %l46
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t40, { i64, ptr } %t41)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb13:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp ne i64 %t47, 1
  br i1 %t49, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l53, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t52, ptr %l54
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfArgs(ptr %s2, i64 %t55)
  store %"compiler/msgs:Msg" %t57, ptr %l57
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t58 = load ptr, ptr %l53, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l54
  %t60 = load %"compiler/msgs:Msg", ptr %l57
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t58, %"compiler/source:Span" %t59, %"compiler/msgs:Msg" %t60)
  store i64 %t61, ptr %l58
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t62, { i64, ptr } %t63)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t68, ptr %l63, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr ptr, ptr %t70, i64 0
  %t72 = load ptr, ptr %t71, !tbaa !39
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t67, ptr %t72)
  store ptr %t75, ptr %l65
  br label %bb20
bb20:
  %t76 = load ptr, ptr %l65, !tbaa !29
  store ptr %t76, ptr %l6, !tbaa !29
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l6, !tbaa !29
  store ptr %t82, ptr %l7, !tbaa !29
  %t84 = load ptr, ptr %l7, !tbaa !29
  %t86 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t84)
  store i32 %t86, ptr %l71
  br label %bb24
bb24:
  %t87 = load i32, ptr %l71, !tbaa !23
  store i32 %t87, ptr %l8, !tbaa !23
  store i64 0, ptr %l9, !tbaa !24
  store i64 4, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb25, label %bb26
bb25:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb30
bb27:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l78, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb29
bb29:
  %t114 = load i64, ptr %l78, !tbaa !24
  store i64 %t114, ptr %l75, !tbaa !24
  br label %bb30
bb30:
  %t115 = load i64, ptr %l75, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb33:
  br label %bb34
bb34:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l8, !tbaa !23
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l98
  br label %bb35
bb35:
  %t139 = load i1, ptr %l98, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v0, ptr %t142, ptr %t143)
  br label %bb39
bb39:
  %t146 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t146, ptr %l102
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 2
  %t153 = load i32, ptr %l8, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t156, ptr %l107
  br label %bb40
bb40:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  %t159 = load ptr, ptr %l7, !tbaa !29
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t157, %"compiler/source:Span" %t158, ptr %t159)
  store ptr %t163, ptr %l111
  br label %bb41
bb41:
  store { i64, [4 x i64] } zeroinitializer, ptr %t164
  %t165 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 0
  store i64 2, ptr %t165
  %t166 = load %"compiler/source:Span", ptr %l102
  %t167 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t166, 0
  %t168 = load i32, ptr %l107, !tbaa !23
  %t169 = insertvalue { %"compiler/source:Span", i32, ptr } %t167, i32 %t168, 1
  %t170 = load ptr, ptr %l111, !tbaa !29
  %t171 = insertvalue { %"compiler/source:Span", i32, ptr } %t169, ptr %t170, 2
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t171, ptr %t172
  %t173 = load { i64, [4 x i64] }, ptr %t164
  %t175 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t173, ptr %t175
  store ptr %t175, ptr %l7, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l8, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l118
  br label %bb42
bb42:
  %t187 = load i32, ptr %l118, !tbaa !23
  store i32 %t187, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  %t188 = load i64, ptr %l13, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l13, !tbaa !24
  br label %bb31
bb44:
  %t192 = load i32, ptr %l8, !tbaa !23
  %t193 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t196 = icmp eq i32 %t192, %t193
  br i1 %t196, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  %t205 = load i32, ptr %l8, !tbaa !23
  %t206 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 1
  %t207 = load i32, ptr %t206, !tbaa !23
  %t211 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t204, i32 %t205, i32 %t207)
  store i1 %t211, ptr %l130
  br label %bb48
bb48:
  %t212 = load i1, ptr %l130, !tbaa !21
  %t213 = xor i1 %t212, true
  br i1 %t213, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l132, !tbaa !29
  %t216 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t216, ptr %l133, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr ptr, ptr %t218, i64 0
  %t220 = load ptr, ptr %t219, !tbaa !39
  %t222 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t220)
  store %"compiler/source:Span" %t222, ptr %l135
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 1
  %t225 = load i32, ptr %t224, !tbaa !23
  %t228 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t223, i32 %t225)
  store { i64, ptr } %t228, ptr %l138
  br label %bb52
bb52:
  %t229 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  %t231 = extractvalue { i64, ptr } %t229, 1
  %t232 = mul i64 %t230, 1
  %t233 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t232)
  call void @llvm.memcpy.p0.p0.i64(ptr %t233, ptr %t231, i64 %t232, i1 false)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  store { i64, ptr } %t235, ptr %l139, !tbaa !27
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i32, ptr %l8, !tbaa !23
  %t240 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t236, i32 %t237)
  store { i64, ptr } %t240, ptr %l142
  br label %bb53
bb53:
  %t241 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  %t243 = extractvalue { i64, ptr } %t241, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  %t248 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t250 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfType(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } %t248, { i64, ptr } %t247)
  store %"compiler/msgs:Msg" %t250, ptr %l144
  br label %bb54
bb54:
  %t251 = load ptr, ptr %l132, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l135
  %t253 = load %"compiler/msgs:Msg", ptr %l144
  %t254 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t251, %"compiler/source:Span" %t252, %"compiler/msgs:Msg" %t253)
  store i64 %t254, ptr %l145
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb56:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t260 = load %"compiler/generic:Desc", ptr %l5
  %t263 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %s0, ptr %t259, %"compiler/generic:Desc" %t260)
  store { i32, { i64, ptr } } %t263, ptr %l150
  br label %bb57
bb57:
  %t264 = load { i32, { i64, ptr } }, ptr %l150
  store { i32, { i64, ptr } } %t264, ptr %l15
  %t265 = getelementptr { i32, { i64, ptr } }, ptr %l15, i32 0, i32 0
  %t266 = load i32, ptr %t265, !tbaa !23
  store i32 %t266, ptr %l16, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load i32, ptr %l8, !tbaa !23
  %t272 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t268, i32 %t269)
  store i1 %t272, ptr %l154
  br label %bb58
bb58:
  %t273 = load i1, ptr %l154, !tbaa !21
  br i1 %t273, label %bb59, label %bb60
bb59:
  %t274 = load %"compiler/source:Span", ptr %l1
  %t275 = load i32, ptr %l16, !tbaa !23
  %t276 = load ptr, ptr %l7, !tbaa !29
  %t277 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 3
  %t278 = load i64, ptr %t277, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 0
  store i64 3, ptr %t280
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t274, 0
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t282, i32 %t275, 1
  %t286 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t284, ptr %t276, 2
  %t288 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t286, i64 %t278, 3
  %t289 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t288, ptr %t289
  %t290 = load { i64, [4 x i64] }, ptr %t279
  %t292 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t290, ptr %t292
  call void @__olang_scope_close(ptr %s0)
  store ptr %t292, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t295, ptr %l162, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr ptr, ptr %t297, i64 0
  %t299 = load ptr, ptr %t298, !tbaa !39
  %t302 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowLocal(ptr %v0, ptr %v1, ptr %t294, ptr %t299)
  store i64 %t302, ptr %l164
  br label %bb62
bb62:
  %t303 = load i64, ptr %l164, !tbaa !24
  store i64 %t303, ptr %l17, !tbaa !24
  store i1 false, ptr %l18, !tbaa !21
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t304)
  store ptr %t306, ptr %l166
  br label %bb63
bb63:
  %t307 = load ptr, ptr %l166, !tbaa !29
  %t309 = getelementptr %"compiler/check:frame", ptr %t307, i32 0, i32 43
  store ptr %t309, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s12
  %t311 = load ptr, ptr %l19, !tbaa !29
  %t312 = load i64, ptr %l20, !tbaa !24
  %t315 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eRu_H9d42e7edf572b8740166f4b30b0e5054(ptr %v0, ptr %t311, i64 %t312)
  %t316 = extractvalue { i32, { i64, ptr } } %t315, 1
  %t317 = extractvalue { i32, { i64, ptr } } %t315, 0
  store i32 %t317, ptr %l173
  %t318 = icmp ne i32 %t317, 0
  br i1 %t318, label %bb66, label %ok.319
ok.319:
  store { i64, ptr } %t316, ptr %l172
  br label %bb65
bb65:
  %t320 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t320, ptr %l169, !tbaa !27
  br label %bb70
bb66:
  %t321 = load i32, ptr %l173, !tbaa !23
  %t322 = ashr i32 %t321, 16
  %t324 = icmp eq i32 %t322, 1
  br i1 %t324, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_271de975e94d1c2d_b74be220493c84d1)
  unreachable
bb69:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s12)
  br label %bb84
bb70:
  %t326 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t326, ptr %l21, !tbaa !27
  %t327 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t327, 0
  store i64 %t329, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s13
  %t331 = load i64, ptr %l23, !tbaa !24
  %t332 = load i64, ptr %l22, !tbaa !24
  %t335 = icmp slt i64 %t331, %t332
  %t337 = xor i1 %t335, true
  br i1 %t337, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s13)
  br label %bb82
bb73:
  br label %bb74
bb74:
  %t339 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t339, ptr %l182, !tbaa !27
  %t340 = load i64, ptr %l23, !tbaa !24
  %t342 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr %"compiler/check:narrowed", ptr %t343, i64 %t340
  %t345 = load %"compiler/check:narrowed", ptr %t344
  store %"compiler/check:narrowed" %t345, ptr %l24
  %t347 = getelementptr %"compiler/check:narrowed", ptr %l24, i32 0, i32 0
  %t348 = load i64, ptr %t347, !tbaa !24
  %t349 = load i64, ptr %l17, !tbaa !24
  %t352 = icmp eq i64 %t348, %t349
  br i1 %t352, label %bb75, label %bb76
bb75:
  %t354 = getelementptr %"compiler/check:narrowed", ptr %l24, i32 0, i32 1
  %t355 = load i64, ptr %t354, !tbaa !24
  %t356 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t357 = load i64, ptr %t356, !tbaa !24
  %t360 = icmp eq i64 %t355, %t357
  store i1 %t360, ptr %l188, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb77
bb77:
  %t362 = load i1, ptr %l188, !tbaa !21
  br i1 %t362, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb80
bb79:
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s13)
  br label %bb81
bb81:
  %t363 = load i64, ptr %l23, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l23, !tbaa !24
  br label %bb71
bb82:
  %t367 = load i64, ptr %l20, !tbaa !24
  %t368 = load i64, ptr %l22, !tbaa !24
  %t371 = add i64 %t367, %t368
  store i64 %t371, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb83
bb83:
  br label %bb64
bb84:
  %t373 = load i1, ptr %l18, !tbaa !21
  %t375 = xor i1 %t373, true
  br i1 %t375, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s16
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = getelementptr %"compiler/generic:Program", ptr %t380, i32 0, i32 2
  %t383 = load i32, ptr %l8, !tbaa !23
  %t386 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t382, i32 %t383)
  store { i64, ptr } %t386, ptr %l203
  br label %bb87
bb86:
  br label %bb94
bb87:
  %t387 = load { i64, ptr }, ptr %l203, !tbaa !27
  store { i64, ptr } %t387, ptr %l25, !tbaa !27
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l204, !tbaa !29
  %t389 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t389, ptr %l205, !tbaa !27
  %t390 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr ptr, ptr %t391, i64 0
  %t393 = load ptr, ptr %t392, !tbaa !39
  %t395 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t393)
  store %"compiler/source:Span" %t395, ptr %l207
  br label %bb88
bb88:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load i32, ptr %l8, !tbaa !23
  %t400 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t396, i32 %t397)
  store { i64, ptr } %t400, ptr %l210
  br label %bb89
bb89:
  %t401 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t401, 0
  %t403 = extractvalue { i64, ptr } %t401, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  store { i64, ptr } %t407, ptr %l211, !tbaa !27
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t409, ptr %l213, !tbaa !27
  %t410 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t411 = load i64, ptr %t410, !tbaa !24
  %t413 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = getelementptr i32, ptr %t414, i64 %t411
  %t416 = load i32, ptr %t415, !tbaa !33
  %t419 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t408, i32 %t416)
  store { i64, ptr } %t419, ptr %l216
  br label %bb90
bb90:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load %"compiler/generic:Desc", ptr %l5
  %t424 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %s16, ptr %t420, %"compiler/generic:Desc" %t421)
  store { i64, ptr } %t424, ptr %l219
  br label %bb91
bb91:
  %t425 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t425, 1
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t428 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t429 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t430 = add i64 %t427, %t429
  %t431 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t432 = extractvalue { i64, ptr } %t431, 1
  %t433 = extractvalue { i64, ptr } %t431, 0
  %t434 = add i64 %t430, %t433
  %t435 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t434)
  call void @olang_textcopy(ptr %t435, ptr %t426, i64 %t427)
  %t436 = getelementptr i8, ptr %t435, i64 %t427
  call void @olang_textcopy(ptr %t436, ptr %t428, i64 %t429)
  %t437 = getelementptr i8, ptr %t436, i64 %t429
  call void @olang_textcopy(ptr %t437, ptr %t432, i64 %t433)
  %t438 = insertvalue { i64, ptr } undef, i64 %t434, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t435, 1
  %t441 = extractvalue { i64, ptr } %t439, 0
  %t442 = extractvalue { i64, ptr } %t439, 1
  %t443 = mul i64 %t441, 1
  %t444 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t443)
  call void @llvm.memcpy.p0.p0.i64(ptr %t444, ptr %t442, i64 %t443, i1 false)
  %t445 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr %t444, 1
  %t447 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t449 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %s16, ptr %s16, ptr %s16, { i64, ptr } %t447, { i64, ptr } %t446)
  store %"compiler/msgs:Msg" %t449, ptr %l222
  br label %bb92
bb92:
  %t450 = load ptr, ptr %l204, !tbaa !29
  %t451 = load %"compiler/source:Span", ptr %l207
  %t452 = load %"compiler/msgs:Msg", ptr %l222
  %t453 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t450, %"compiler/source:Span" %t451, %"compiler/msgs:Msg" %t452)
  store i64 %t453, ptr %l223
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb94:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/check:Checker", ptr %t455, i32 0, i32 1
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t460 = getelementptr %"compiler/generic:Program", ptr %t458, i32 0, i32 2
  store ptr %t460, ptr %l227, !tbaa !29
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/check:Checker", ptr %t461, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !29
  %t466 = getelementptr %"compiler/generic:Program", ptr %t464, i32 0, i32 2
  %t467 = load i32, ptr %l8, !tbaa !23
  %t470 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t466, i32 %t467)
  store i32 %t470, ptr %l232
  br label %bb95
bb95:
  %t471 = load ptr, ptr %l227, !tbaa !29
  %t472 = load i32, ptr %l232, !tbaa !23
  %t473 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t471, i32 %t472)
  store { i64, ptr } %t473, ptr %l233
  br label %bb96
bb96:
  %t474 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } %t474, ptr %l234, !tbaa !27
  %t475 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t476 = load i64, ptr %t475, !tbaa !24
  %t478 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !27
  %t480 = getelementptr i32, ptr %t479, i64 %t476
  %t481 = load i32, ptr %t480, !tbaa !33
  %t483 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t483, ptr %l237
  store i32 %t481, ptr %l238, !tbaa !23
  %t485 = load ptr, ptr %l7, !tbaa !29
  %t486 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t487 = load i64, ptr %t486, !tbaa !24
  %t491 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t485, i64 %t487, i32 0)
  store %"compiler/typed:Payload" %t491, ptr %l242
  br label %bb97
bb97:
  %t492 = load %"compiler/typed:Payload", ptr %l242
  %t493 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t492, ptr %t493
  store { i64, [4 x i64] } zeroinitializer, ptr %t494
  %t495 = getelementptr { i64, [4 x i64] }, ptr %t494, i32 0, i32 0
  store i64 5, ptr %t495
  %t496 = load %"compiler/source:Span", ptr %l237
  %t497 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t496, 0
  %t498 = load i32, ptr %l238, !tbaa !23
  %t499 = insertvalue { %"compiler/source:Span", i32, ptr } %t497, i32 %t498, 1
  %t501 = insertvalue { %"compiler/source:Span", i32, ptr } %t499, ptr %t493, 2
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t494, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t501, ptr %t502
  %t503 = load { i64, [4 x i64] }, ptr %t494
  %t504 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t504, ptr %lp27
  %t506 = load ptr, ptr %lp27
  store { i64, [4 x i64] } %t503, ptr %t506
  %t507 = load %"compiler/source:Span", ptr %l1
  %t508 = load i32, ptr %l16, !tbaa !23
  %t509 = load ptr, ptr %lp27
  %t510 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 3
  %t511 = load i64, ptr %t510, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t512
  %t513 = getelementptr { i64, [4 x i64] }, ptr %t512, i32 0, i32 0
  store i64 3, ptr %t513
  %t515 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t507, 0
  %t517 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t515, i32 %t508, 1
  %t519 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t517, ptr %t509, 2
  %t521 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t519, i64 %t511, 3
  %t522 = getelementptr { i64, [4 x i64] }, ptr %t512, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t521, ptr %t522
  %t523 = load { i64, [4 x i64] }, ptr %t512
  %t525 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t523, ptr %t525
  call void @__olang_scope_close(ptr %s0)
  store ptr %t525, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i1
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l32 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca i32
  %l52 = alloca ptr
  %l57 = alloca %"compiler/typed:Elem"
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca i32
  %l77 = alloca ptr
  %l82 = alloca %"compiler/typed:Payload"
  %l86 = alloca ptr
  %l87 = alloca i1
  %rv = alloca ptr
  %t44 = alloca { i64, [4 x i64] }, align 8
  %t112 = alloca { i64, [4 x i64] }, align 8
  %t178 = alloca { i64, [4 x i64] }, align 8
  %t218 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l5, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 3
  %t32 = load i64, ptr %t31
  store i64 %t32, ptr %l6, !tbaa !24
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t34 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t34, ptr %l27
  %t35 = load i32, ptr %l4, !tbaa !23
  store i32 %t35, ptr %l28, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t38 = load i64, ptr %l2, !tbaa !24
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %t36, ptr %t37, i64 %t38)
  store ptr %t42, ptr %l32
  br label %bb6
bb6:
  %t43 = load i64, ptr %l6, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 0
  store i64 3, ptr %t45
  %t46 = load %"compiler/source:Span", ptr %l27
  %t47 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t46, 0
  %t48 = load i32, ptr %l28, !tbaa !23
  %t49 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t47, i32 %t48, 1
  %t50 = load ptr, ptr %l32, !tbaa !29
  %t51 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t49, ptr %t50, 2
  %t53 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t51, i64 %t43, 3
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t53, ptr %t54
  %t55 = load { i64, [4 x i64] }, ptr %t44
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t55, ptr %t57
  store ptr %t57, ptr %rv
  br label %ret
bb7:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t60 = load ptr, ptr %l36, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb8, label %bb9
bb8:
  %t63 = load ptr, ptr %l36, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 4
  store i1 %t66, ptr %l37, !tbaa !21
  br label %bb9
bb9:
  %t67 = load i1, ptr %l37, !tbaa !21
  br i1 %t67, label %bb10, label %bb11
bb10:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 0
  %t72 = load %"compiler/source:Span", ptr %t71
  store %"compiler/source:Span" %t72, ptr %l7
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l8, !tbaa !23
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l9, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t86 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t86, ptr %l46
  %t87 = load i32, ptr %l8, !tbaa !23
  store i32 %t87, ptr %l47, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l9, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Elem", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t93 = load i64, ptr %l2, !tbaa !24
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %t88, ptr %t92, i64 %t93)
  store ptr %t97, ptr %l52
  br label %bb13
bb13:
  %t98 = load ptr, ptr %l9, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Elem", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load ptr, ptr %l9, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Elem", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %t104
  %t106 = load ptr, ptr %l52, !tbaa !29
  %t109 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t106, ptr %t101, i32 %t105)
  store %"compiler/typed:Elem" %t109, ptr %l57
  br label %bb14
bb14:
  %t110 = load %"compiler/typed:Elem", ptr %l57
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t110, ptr %t111
  store { i64, [4 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 0
  store i64 4, ptr %t113
  %t114 = load %"compiler/source:Span", ptr %l46
  %t115 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t114, 0
  %t116 = load i32, ptr %l47, !tbaa !23
  %t117 = insertvalue { %"compiler/source:Span", i32, ptr } %t115, i32 %t116, 1
  %t119 = insertvalue { %"compiler/source:Span", i32, ptr } %t117, ptr %t111, 2
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t119, ptr %t120
  %t121 = load { i64, [4 x i64] }, ptr %t112
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t121, ptr %t123
  store ptr %t123, ptr %rv
  br label %ret
bb15:
  %t125 = load ptr, ptr %l1, !tbaa !29
  store ptr %t125, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t126 = load ptr, ptr %l61, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb16, label %bb17
bb16:
  %t129 = load ptr, ptr %l61, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 5
  store i1 %t132, ptr %l62, !tbaa !21
  br label %bb17
bb17:
  %t133 = load i1, ptr %l62, !tbaa !21
  br i1 %t133, label %bb18, label %bb19
bb18:
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l10
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l11, !tbaa !23
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l12, !tbaa !29
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t152 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t152, ptr %l71
  %t153 = load i32, ptr %l11, !tbaa !23
  store i32 %t153, ptr %l72, !tbaa !23
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l12, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Payload", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i64, ptr %l2, !tbaa !24
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %t154, ptr %t158, i64 %t159)
  store ptr %t163, ptr %l77
  br label %bb21
bb21:
  %t164 = load ptr, ptr %l12, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Payload", ptr %t164, i32 0, i32 1
  %t167 = load i64, ptr %t166, !tbaa !24
  %t168 = load ptr, ptr %l12, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Payload", ptr %t168, i32 0, i32 2
  %t171 = load i32, ptr %t170
  %t172 = load ptr, ptr %l77, !tbaa !29
  %t175 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t172, i64 %t167, i32 %t171)
  store %"compiler/typed:Payload" %t175, ptr %l82
  br label %bb22
bb22:
  %t176 = load %"compiler/typed:Payload", ptr %l82
  %t177 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t176, ptr %t177
  store { i64, [4 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 0
  store i64 5, ptr %t179
  %t180 = load %"compiler/source:Span", ptr %l71
  %t181 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t180, 0
  %t182 = load i32, ptr %l72, !tbaa !23
  %t183 = insertvalue { %"compiler/source:Span", i32, ptr } %t181, i32 %t182, 1
  %t185 = insertvalue { %"compiler/source:Span", i32, ptr } %t183, ptr %t177, 2
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t185, ptr %t186
  %t187 = load { i64, [4 x i64] }, ptr %t178
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t187, ptr %t189
  store ptr %t189, ptr %rv
  br label %ret
bb23:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t192 = load ptr, ptr %l86, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb24, label %bb25
bb24:
  %t195 = load ptr, ptr %l86, !tbaa !29
  %t196 = load i64, ptr %t195
  %t198 = icmp eq i64 %t196, 6
  store i1 %t198, ptr %l87, !tbaa !21
  br label %bb25
bb25:
  %t199 = load i1, ptr %l87, !tbaa !21
  br i1 %t199, label %bb26, label %bb27
bb26:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t202, i32 0, i32 0
  %t204 = load %"compiler/source:Span", ptr %t203
  store %"compiler/source:Span" %t204, ptr %l13
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t208, i32 0, i32 1
  %t210 = load i32, ptr %t209
  store i32 %t210, ptr %l14, !tbaa !23
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t212 = load %"compiler/source:Span", ptr %l13
  %t213 = load i32, ptr %l14, !tbaa !23
  %t214 = load i64, ptr %l2, !tbaa !24
  %t216 = trunc i64 %t214 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t218
  %t219 = getelementptr { i64, [4 x i64] }, ptr %t218, i32 0, i32 0
  store i64 0, ptr %t219
  %t221 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t212, 0
  %t223 = insertvalue { %"compiler/source:Span", i32, i32 } %t221, i32 %t213, 1
  %t225 = insertvalue { %"compiler/source:Span", i32, i32 } %t223, i32 %t216, 2
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t218, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t225, ptr %t226
  %t227 = load { i64, [4 x i64] }, ptr %t218
  %t229 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t227, ptr %t229
  store ptr %t229, ptr %rv
  br label %ret
bb29:
  %t231 = load ptr, ptr %l1, !tbaa !29
  store ptr %t231, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t5, i32 %a2)
  store i32 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t19, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i32 %t21, ptr %l12
  br label %bb2
bb2:
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t23 = load i32, ptr %l7, !tbaa !23
  %t24 = load i32, ptr %l12, !tbaa !23
  %t25 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t22, i32 %t23, i32 %t24)
  store i64 %t25, ptr %l13
  br label %bb3
bb3:
  %t26 = load i64, ptr %l13, !tbaa !24
  %t27 = icmp slt i64 %t26, 0
  br i1 %t27, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t29, ptr %l16, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l17, !tbaa !24
  %t32 = load i64, ptr %l17, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l18, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t43, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t45 = load i32, ptr %l1, !tbaa !23
  %t47 = icmp ne i32 %t45, 0
  br i1 %t47, label %bb7, label %bb8
bb7:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l1, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t49, i32 %t50)
  store { i64, ptr } %t53, ptr %l23
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t54 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t56 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = add i64 %t55, %t58
  %t60 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t54, i64 %t55)
  %t64 = getelementptr i8, ptr %t63, i64 %t55
  call void @olang_textcopy(ptr %t64, ptr %t57, i64 %t58)
  %t65 = getelementptr i8, ptr %t64, i64 %t58
  call void @olang_textcopy(ptr %t65, ptr %t60, i64 %t61)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t67, ptr %rv
  br label %ret
bb10:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t69, ptr %l26, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l27, !tbaa !24
  %t72 = load i64, ptr %l27, !tbaa !24
  %t73 = mul i64 %t72, 1
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l28, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l27, !tbaa !24
  %t82 = mul i64 %t81, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %t80, i64 %t82, i1 false)
  %t83 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t83, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 3
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t26, ptr %l19
  br label %bb9
bb9:
  %t27 = load i1, ptr %l19, !tbaa !21
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb36
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 4
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Elem", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t43, ptr %t47)
  store i1 %t51, ptr %l30
  br label %bb16
bb16:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %l9, !tbaa !21
  br label %bb36
bb17:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 5
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l32, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Payload", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t68, ptr %t72)
  store i1 %t76, ptr %l41
  br label %bb23
bb23:
  %t77 = load i1, ptr %l41, !tbaa !21
  store i1 %t77, ptr %l9, !tbaa !21
  br label %bb36
bb24:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t79 = load ptr, ptr %l42, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb25, label %bb26
bb25:
  %t82 = load ptr, ptr %l42, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 6
  store i1 %t85, ptr %l43, !tbaa !21
  br label %bb26
bb26:
  %t86 = load i1, ptr %l43, !tbaa !21
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t98 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  store i1 %t98, ptr %l51
  br label %bb30
bb30:
  %t99 = load i1, ptr %l51, !tbaa !21
  store i1 %t99, ptr %l9, !tbaa !21
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_19fb235390dd08bf_74b3a6d5c5264653)
  unreachable
bb36:
  %t100 = load i1, ptr %l9, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2escoped(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca %"compiler/msgs:Msg"
  %l29 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i1
  %l38 = alloca i64
  %l41 = alloca i1
  %l43 = alloca ptr
  %l45 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i32
  %l63 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l80 = alloca %"compiler/source:Span"
  %l84 = alloca { i64, ptr }
  %l86 = alloca %"compiler/msgs:Msg"
  %l87 = alloca i64
  %l91 = alloca { i64, [2 x i64] }
  %l97 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l120 = alloca i1
  %l123 = alloca i1
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca i64
  %l142 = alloca %"compiler/msgs:Msg"
  %l143 = alloca i64
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca i32
  %l156 = alloca %"compiler/typed:Call"
  %l160 = alloca ptr
  %l161 = alloca i1
  %l170 = alloca %"compiler/source:Span"
  %l171 = alloca i32
  %l173 = alloca { i64, ptr }
  %l174 = alloca ptr
  %l175 = alloca %"compiler/source:Span"
  %l182 = alloca ptr
  %l184 = alloca %"compiler/typed:Seq"
  %l190 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t1 = alloca { i64, [2 x i64] }, align 8
  %t174 = alloca { i64, [2 x i64] }, align 8
  %t189 = alloca { i64, [2 x i64] }, align 8
  %t324 = alloca { i64, [5 x i64] }, align 8
  %t395 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 4, ptr %t2
  %t3 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t3, ptr %l4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t5, i32 %t6)
  store { i64, ptr } %t9, ptr %l19
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t11, ptr %l20
  br label %bb2
bb2:
  %t12 = load i1, ptr %l20, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t13)
  store ptr %t15, ptr %l23
  br label %bb5
bb4:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l23, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t16, i32 0, i32 20
  %t19 = load i1, ptr %t18, !tbaa !21
  store i1 %t19, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l21, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l26, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t23, ptr %l27
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenReturnScope(ptr %s1)
  store %"compiler/msgs:Msg" %t24, ptr %l28
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t25 = load ptr, ptr %l26, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l27
  %t27 = load %"compiler/msgs:Msg", ptr %l28
  %t28 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t25, %"compiler/source:Span" %t26, %"compiler/msgs:Msg" %t27)
  store i64 %t28, ptr %l29
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l32
  br label %bb12
bb12:
  %t34 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t35, ptr %l33
  br label %bb13
bb13:
  %t36 = load i1, ptr %l33, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l3, !tbaa !23
  %t41 = load %"compiler/source:Span", ptr %l1
  %t45 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %t39, i32 %t40, %"compiler/source:Span" %t41)
  store i64 %t45, ptr %l38
  br label %bb16
bb15:
  br label %bb42
bb16:
  %t46 = load i64, ptr %l38, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t49 = icmp slt i64 %t47, 0
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  store ptr %t54, ptr %l43, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t55)
  store ptr %t57, ptr %l45
  br label %bb19
bb18:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l45, !tbaa !29
  %t60 = getelementptr %"compiler/check:frame", ptr %t58, i32 0, i32 1
  %t61 = load i64, ptr %t60, !tbaa !24
  %t62 = load i32, ptr %l3, !tbaa !23
  %t63 = load ptr, ptr %l43, !tbaa !29
  %t66 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t63, i64 %t61, i32 %t62)
  store ptr %t66, ptr %l49
  br label %bb20
bb20:
  %t67 = load ptr, ptr %l49, !tbaa !29
  %t68 = icmp eq ptr %t67, null
  store i1 %t68, ptr %l41, !tbaa !21
  br label %bb21
bb21:
  %t70 = load i1, ptr %l41, !tbaa !21
  br i1 %t70, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l3, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t71, i32 %t72)
  store { i64, ptr } %t75, ptr %l53
  br label %bb24
bb23:
  br label %bb37
bb24:
  %t76 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t76, ptr %l6, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  %t81 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t77, %"compiler/source:Span" %t78)
  store { i64, ptr } %t81, ptr %l57
  br label %bb25
bb25:
  %t82 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t86 = extractvalue { i64, ptr } %t82, 1
  %t87 = extractvalue { i64, ptr } %t82, 0
  %t88 = add i64 %t84, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t83, i64 %t84)
  %t90 = getelementptr i8, ptr %t89, i64 %t84
  call void @olang_textcopy(ptr %t90, ptr %t86, i64 %t87)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = extractvalue { i64, ptr } %t92, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t102 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s3, { i64, ptr } %t100, { i64, ptr } %t99)
  %t103 = extractvalue { i32, i64 } %t102, 1
  %t104 = extractvalue { i32, i64 } %t102, 0
  store i32 %t104, ptr %l62
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb27, label %ok.106
ok.106:
  store i64 %t103, ptr %l61
  br label %bb26
bb26:
  %t107 = load i64, ptr %l61, !tbaa !24
  store i64 %t107, ptr %l54, !tbaa !24
  br label %bb29
bb27:
  br label %bb28
bb28:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l54, !tbaa !24
  br label %bb29
bb29:
  %t108 = load i64, ptr %l54, !tbaa !24
  store i64 %t108, ptr %l7, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l63, !tbaa !29
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = icmp sge i64 %t110, 0
  br i1 %t112, label %bb30, label %bb31
bb30:
  %t114 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t115 = load i32, ptr %t114, !tbaa !23
  %t116 = load i64, ptr %l7, !tbaa !24
  %t118 = add i64 %t116, 1
  %t120 = trunc i64 %t118 to i32
  %t123 = add i32 %t115, %t120
  %t124 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t125 = load i32, ptr %t124, !tbaa !23
  %t126 = load i64, ptr %l7, !tbaa !24
  %t128 = add i64 %t126, 1
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t134 = add i64 %t128, %t131
  %t136 = trunc i64 %t134 to i32
  %t139 = add i32 %t125, %t136
  %t142 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t123, i32 %t139)
  store %"compiler/source:Span" %t142, ptr %l80
  br label %bb32
bb31:
  %t143 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t143, ptr %l66
  br label %bb33
bb32:
  %t145 = load %"compiler/source:Span", ptr %l80
  store %"compiler/source:Span" %t145, ptr %l66
  br label %bb33
bb33:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l3, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t146, i32 %t147)
  store { i64, ptr } %t150, ptr %l84
  br label %bb34
bb34:
  %t151 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  %t153 = extractvalue { i64, ptr } %t151, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t159 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgUnknown(ptr %s3, ptr %s3, { i64, ptr } %t157)
  store %"compiler/msgs:Msg" %t159, ptr %l86
  br label %bb35
bb35:
  %t160 = load ptr, ptr %l63, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l66
  %t162 = load %"compiler/msgs:Msg", ptr %l86
  %t163 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t160, %"compiler/source:Span" %t161, %"compiler/msgs:Msg" %t162)
  store i64 %t163, ptr %l87
  br label %bb36
bb36:
  %t164 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t164, ptr %rv
  br label %ret
bb37:
  %t166 = load i64, ptr %l5, !tbaa !24
  %t168 = icmp sge i64 %t166, 0
  br i1 %t168, label %bb38, label %bb39
bb38:
  %t170 = load i64, ptr %l5, !tbaa !24
  %t172 = trunc i64 %t170 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t174
  %t175 = getelementptr { i64, [2 x i64] }, ptr %t174, i32 0, i32 0
  store i64 2, ptr %t175
  %t177 = insertvalue { i32 } undef, i32 %t172, 0
  %t178 = getelementptr { i64, [2 x i64] }, ptr %t174, i32 0, i32 1
  store { i32 } %t177, ptr %t178
  %t179 = load { i64, [2 x i64] }, ptr %t174
  store { i64, [2 x i64] } %t179, ptr %l91
  br label %bb41
bb39:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t181)
  store ptr %t183, ptr %l97
  br label %bb40
bb40:
  %t184 = load ptr, ptr %l97, !tbaa !29
  %t186 = getelementptr %"compiler/check:frame", ptr %t184, i32 0, i32 1
  %t187 = load i64, ptr %t186, !tbaa !24
  %t188 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [2 x i64] }, ptr %t189, i32 0, i32 0
  store i64 3, ptr %t190
  %t192 = insertvalue { i64, i32 } undef, i64 %t187, 0
  %t194 = insertvalue { i64, i32 } %t192, i32 %t188, 1
  %t195 = getelementptr { i64, [2 x i64] }, ptr %t189, i32 0, i32 1
  store { i64, i32 } %t194, ptr %t195
  %t196 = load { i64, [2 x i64] }, ptr %t189
  store { i64, [2 x i64] } %t196, ptr %l91
  br label %bb41
bb41:
  %t198 = load { i64, [2 x i64] }, ptr %l91
  store { i64, [2 x i64] } %t198, ptr %l4
  br label %bb42
bb42:
  %t199 = load ptr, ptr %l2, !tbaa !29
  store ptr %t199, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t200 = load ptr, ptr %l102, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb43, label %bb44
bb43:
  %t203 = load ptr, ptr %l102, !tbaa !29
  %t204 = load i64, ptr %t203
  %t206 = icmp eq i64 %t204, 6
  store i1 %t206, ptr %l103, !tbaa !21
  br label %bb44
bb44:
  %t207 = load i1, ptr %l103, !tbaa !21
  br i1 %t207, label %bb45, label %bb46
bb45:
  %t208 = load ptr, ptr %l2, !tbaa !29
  %t210 = getelementptr { i64, [5 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t210, i32 0, i32 0
  %t212 = load %"compiler/source:Span", ptr %t211
  store %"compiler/source:Span" %t212, ptr %l8
  %t214 = load ptr, ptr %l2, !tbaa !29
  %t216 = getelementptr { i64, [5 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t216, i32 0, i32 1
  %t218 = load i32, ptr %t217
  store i32 %t218, ptr %l9, !tbaa !23
  %t220 = load ptr, ptr %l2, !tbaa !29
  %t222 = getelementptr { i64, [5 x i64] }, ptr %t220, i32 0, i32 1
  %t223 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t222, i32 0, i32 2
  %t224 = load ptr, ptr %t223
  store ptr %t224, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb73
bb47:
  %t226 = load i32, ptr %l9, !tbaa !23
  %t227 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t230 = icmp ne i32 %t226, %t227
  br i1 %t230, label %bb48, label %bb49
bb48:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr %l9, !tbaa !23
  %t236 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceable(ptr %v0, ptr %t232, i32 %t233)
  store i1 %t236, ptr %l118
  br label %bb50
bb49:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb51
bb50:
  %t237 = load i1, ptr %l118, !tbaa !21
  %t238 = xor i1 %t237, true
  store i1 %t238, ptr %l115, !tbaa !21
  br label %bb51
bb51:
  %t240 = load i1, ptr %l115, !tbaa !21
  br i1 %t240, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb55
bb53:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l10, !tbaa !29
  %t245 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedResult(ptr %v0, ptr %v0, ptr %t241, ptr %t242)
  store i1 %t245, ptr %l123
  br label %bb54
bb54:
  %t246 = load i1, ptr %l123, !tbaa !21
  store i1 %t246, ptr %l120, !tbaa !21
  br label %bb55
bb55:
  %t247 = load i1, ptr %l120, !tbaa !21
  br i1 %t247, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s6
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load %"compiler/source:Span", ptr %l1
  %t252 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t248, %"compiler/source:Span" %t249)
  store { i64, ptr } %t252, ptr %l126
  br label %bb58
bb57:
  br label %bb71
bb58:
  %t253 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t253, ptr %l11, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t256 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t254, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) })
  %t257 = extractvalue { i32, i64 } %t256, 1
  %t258 = extractvalue { i32, i64 } %t256, 0
  store i32 %t258, ptr %l130
  %t259 = icmp ne i32 %t258, 0
  br i1 %t259, label %bb60, label %ok.260
ok.260:
  store i64 %t257, ptr %l129
  br label %bb59
bb59:
  %t261 = load i64, ptr %l129, !tbaa !24
  store i64 %t261, ptr %l127, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  call void @__olang_ert_req_clear()
  %t262 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 0
  store i64 %t264, ptr %l127, !tbaa !24
  br label %bb62
bb62:
  %t266 = load i64, ptr %l127, !tbaa !24
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l133, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t268, ptr %l134
  %t269 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t269, ptr %l135, !tbaa !27
  store i64 %t266, ptr %l136, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  store i64 %t272, ptr %l137, !tbaa !24
  %t273 = icmp sge i64 0, 0
  br i1 %t273, label %bb63, label %bb64
bb63:
  %t275 = load i64, ptr %l136, !tbaa !24
  %t276 = icmp sle i64 0, %t275
  br i1 %t276, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_205c65d5b195e98c_2c317476e8a14790)
  unreachable
bb65:
  %t278 = load i64, ptr %l136, !tbaa !24
  %t279 = load i64, ptr %l137, !tbaa !24
  %t280 = icmp sle i64 %t278, %t279
  br i1 %t280, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_205c65d5b195e98c_2c317476e8a14790)
  unreachable
bb67:
  %t282 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = load i64, ptr %l136, !tbaa !24
  %t285 = getelementptr i8, ptr %t283, i64 0
  %t286 = sub i64 %t284, 0
  %t287 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t285, 1
  %t290 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgNotAccepted(ptr %v0, ptr %s6, { i64, ptr } %t288)
  store %"compiler/msgs:Msg" %t290, ptr %l142
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_205c65d5b195e98c_2c317476e8a14790)
  unreachable
bb69:
  %t291 = load ptr, ptr %l133, !tbaa !29
  %t292 = load %"compiler/source:Span", ptr %l134
  %t293 = load %"compiler/msgs:Msg", ptr %l142
  %t294 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t291, %"compiler/source:Span" %t292, %"compiler/msgs:Msg" %t293)
  store i64 %t294, ptr %l143
  br label %bb70
bb70:
  %t295 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t295, ptr %rv
  br label %ret
bb71:
  %t297 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t297, ptr %l145
  %t298 = load i32, ptr %l9, !tbaa !23
  store i32 %t298, ptr %l146, !tbaa !23
  %t299 = load ptr, ptr %l10, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Call", ptr %t299, i32 0, i32 0
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t303 = load ptr, ptr %l10, !tbaa !29
  %t305 = getelementptr %"compiler/typed:Call", ptr %t303, i32 0, i32 1
  %t306 = load { i64, ptr }, ptr %t305, !tbaa !27
  %t307 = load { i64, [2 x i64] }, ptr %l4
  %t308 = load ptr, ptr %l10, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Call", ptr %t308, i32 0, i32 3
  %t311 = load i32, ptr %t310, !tbaa !23
  %t312 = load ptr, ptr %l10, !tbaa !29
  %t314 = getelementptr %"compiler/typed:Call", ptr %t312, i32 0, i32 4
  %t315 = load i1, ptr %t314, !tbaa !21
  %t321 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t302, { i64, ptr } %t306, { i64, [2 x i64] } %t307, i32 %t311, i1 %t315)
  store %"compiler/typed:Call" %t321, ptr %l156
  br label %bb72
bb72:
  %t322 = load %"compiler/typed:Call", ptr %l156
  %t323 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t322, ptr %t323
  store { i64, [5 x i64] } zeroinitializer, ptr %t324
  %t325 = getelementptr { i64, [5 x i64] }, ptr %t324, i32 0, i32 0
  store i64 6, ptr %t325
  %t326 = load %"compiler/source:Span", ptr %l145
  %t327 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t326, 0
  %t328 = load i32, ptr %l146, !tbaa !23
  %t329 = insertvalue { %"compiler/source:Span", i32, ptr } %t327, i32 %t328, 1
  %t331 = insertvalue { %"compiler/source:Span", i32, ptr } %t329, ptr %t323, 2
  %t332 = getelementptr { i64, [5 x i64] }, ptr %t324, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t331, ptr %t332
  %t333 = load { i64, [5 x i64] }, ptr %t324
  %t335 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t333, ptr %t335
  call void @__olang_scope_close(ptr %s0)
  store ptr %t335, ptr %rv
  br label %ret
bb73:
  %t337 = load ptr, ptr %l2, !tbaa !29
  store ptr %t337, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t338 = load ptr, ptr %l160, !tbaa !29
  %t339 = icmp ne ptr %t338, null
  br i1 %t339, label %bb74, label %bb75
bb74:
  %t341 = load ptr, ptr %l160, !tbaa !29
  %t342 = load i64, ptr %t341
  %t344 = icmp eq i64 %t342, 12
  store i1 %t344, ptr %l161, !tbaa !21
  br label %bb75
bb75:
  %t345 = load i1, ptr %l161, !tbaa !21
  br i1 %t345, label %bb76, label %bb77
bb76:
  %t346 = load ptr, ptr %l2, !tbaa !29
  %t348 = getelementptr { i64, [5 x i64] }, ptr %t346, i32 0, i32 1
  %t349 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t348, i32 0, i32 0
  %t350 = load %"compiler/source:Span", ptr %t349
  store %"compiler/source:Span" %t350, ptr %l13
  %t352 = load ptr, ptr %l2, !tbaa !29
  %t354 = getelementptr { i64, [5 x i64] }, ptr %t352, i32 0, i32 1
  %t355 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t354, i32 0, i32 1
  %t356 = load i32, ptr %t355
  store i32 %t356, ptr %l14, !tbaa !23
  %t358 = load ptr, ptr %l2, !tbaa !29
  %t360 = getelementptr { i64, [5 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t360, i32 0, i32 2
  %t362 = load ptr, ptr %t361
  store ptr %t362, ptr %l15, !tbaa !29
  br label %bb78
bb77:
  br label %bb84
bb78:
  %t364 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t364, ptr %l170
  %t365 = load i32, ptr %l14, !tbaa !23
  store i32 %t365, ptr %l171, !tbaa !23
  %t366 = load ptr, ptr %l15, !tbaa !29
  %t368 = getelementptr %"compiler/typed:Seq", ptr %t366, i32 0, i32 0
  %t369 = load { i64, ptr }, ptr %t368, !tbaa !27
  store { i64, ptr } %t369, ptr %l173, !tbaa !27
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l174, !tbaa !29
  %t371 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t371, ptr %l175
  %t372 = load ptr, ptr %l15, !tbaa !29
  %t374 = getelementptr %"compiler/typed:Seq", ptr %t372, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t377 = icmp eq ptr %t375, null
  br i1 %t377, label %bb79, label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_31e71959ceb2c563_c3b6512c8fc1b1c7)
  unreachable
bb80:
  br label %bb81
bb81:
  %t379 = load ptr, ptr %l15, !tbaa !29
  %t381 = getelementptr %"compiler/typed:Seq", ptr %t379, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !29
  %t383 = load i32, ptr %l3, !tbaa !23
  %t384 = load ptr, ptr %l174, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l175
  %t388 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2escoped(ptr %v0, ptr %t384, %"compiler/source:Span" %t385, ptr %t382, i32 %t383)
  store ptr %t388, ptr %l182
  br label %bb82
bb82:
  %t389 = load ptr, ptr %l182, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t392 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t390, ptr %t389)
  store %"compiler/typed:Seq" %t392, ptr %l184
  br label %bb83
bb83:
  %t393 = load %"compiler/typed:Seq", ptr %l184
  %t394 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t393, ptr %t394
  store { i64, [5 x i64] } zeroinitializer, ptr %t395
  %t396 = getelementptr { i64, [5 x i64] }, ptr %t395, i32 0, i32 0
  store i64 12, ptr %t396
  %t397 = load %"compiler/source:Span", ptr %l170
  %t398 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t397, 0
  %t399 = load i32, ptr %l171, !tbaa !23
  %t400 = insertvalue { %"compiler/source:Span", i32, ptr } %t398, i32 %t399, 1
  %t402 = insertvalue { %"compiler/source:Span", i32, ptr } %t400, ptr %t394, 2
  %t403 = getelementptr { i64, [5 x i64] }, ptr %t395, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t402, ptr %t403
  %t404 = load { i64, [5 x i64] }, ptr %t395
  %t406 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t404, ptr %t406
  call void @__olang_scope_close(ptr %s0)
  store ptr %t406, ptr %rv
  br label %ret
bb84:
  %t408 = load ptr, ptr %l2, !tbaa !29
  %t411 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t408)
  store i32 %t411, ptr %l190
  br label %bb85
bb85:
  %t412 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t413 = load i32, ptr %l190, !tbaa !23
  %t415 = icmp ne i32 %t413, %t412
  br i1 %t415, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s9
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s9, ptr %t417, %"compiler/source:Span" %t418, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_scope_close(ptr %s9)
  br label %bb89
bb89:
  %t421 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t421, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l33 = alloca { i64, ptr }
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l55 = alloca { i64, ptr }
  %l62 = alloca i32
  %l67 = alloca i32
  %l69 = alloca i64
  %l74 = alloca i64
  %l82 = alloca ptr
  %l87 = alloca i32
  %l89 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store ptr %a1, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v1, ptr %t7, i64 %t8)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l24
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb4, label %ok.15
ok.15:
  store { i64, ptr } %t12, ptr %l23
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t16, ptr %l20, !tbaa !27
  br label %bb8
bb4:
  %t17 = load i32, ptr %l24, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_af79aa682331a71e_538108f01047ae92)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb8:
  %t22 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t22, ptr %l6, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load i64, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb11:
  br label %bb12
bb12:
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t35, ptr %l33, !tbaa !27
  %t36 = load i64, ptr %l8, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 %t36
  %t41 = load i32, ptr %t40, !tbaa !33
  store i32 %t41, ptr %l9, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l9, !tbaa !23
  %t52 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t48, i32 %t49)
  store i64 %t52, ptr %l40
  br label %bb13
bb13:
  %t53 = load i64, ptr %l40, !tbaa !65
  store i64 %t53, ptr %l10, !tbaa !65
  store ptr %a2, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t56 = load ptr, ptr %l11, !tbaa !29
  %t57 = load i64, ptr %l12, !tbaa !24
  %t60 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v2, ptr %t56, i64 %t57)
  %t61 = extractvalue { i32, { i64, ptr } } %t60, 1
  %t62 = extractvalue { i32, { i64, ptr } } %t60, 0
  store i32 %t62, ptr %l46
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb16, label %ok.64
ok.64:
  store { i64, ptr } %t61, ptr %l45
  br label %bb15
bb15:
  %t65 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t65, ptr %l42, !tbaa !27
  br label %bb20
bb16:
  %t66 = load i32, ptr %l46, !tbaa !23
  %t67 = ashr i32 %t66, 16
  %t69 = icmp eq i32 %t67, 1
  br i1 %t69, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_17d8aaff70de119f_90c04534d00fd893)
  unreachable
bb19:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb20:
  %t71 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t71, ptr %l13, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  store i64 %t74, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t76 = load i64, ptr %l15, !tbaa !24
  %t77 = load i64, ptr %l14, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t84 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t84, ptr %l55, !tbaa !27
  %t85 = load i64, ptr %l15, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i32, ptr %t88, i64 %t85
  %t90 = load i32, ptr %t89, !tbaa !33
  store i32 %t90, ptr %l16, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l9, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l62
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l16, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l67
  br label %bb26
bb26:
  %t112 = load i32, ptr %l62, !tbaa !23
  %t113 = load i32, ptr %l67, !tbaa !23
  %t114 = icmp eq i32 %t112, %t113
  br i1 %t114, label %bb27, label %bb28
bb27:
  %t116 = load i64, ptr %l10, !tbaa !65
  store i64 %t116, ptr %l69, !tbaa !65
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l16, !tbaa !23
  %t126 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t122, i32 %t123)
  store i64 %t126, ptr %l74
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t127 = load i64, ptr %l74, !tbaa !65
  %t128 = xor i64 %t127, -1
  %t129 = load i64, ptr %l69, !tbaa !65
  %t131 = and i64 %t129, %t128
  store i64 %t131, ptr %l10, !tbaa !65
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  %t133 = load i64, ptr %l15, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l15, !tbaa !24
  br label %bb21
bb32:
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = load i64, ptr %l14, !tbaa !24
  %t141 = add i64 %t137, %t138
  store i64 %t141, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  br label %bb14
bb34:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l82, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/generic:Program", ptr %t147, i32 0, i32 2
  %t150 = load i32, ptr %l9, !tbaa !23
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t153, ptr %l87
  br label %bb35
bb35:
  %t154 = load i64, ptr %l10, !tbaa !65
  %t155 = load ptr, ptr %l82, !tbaa !29
  %t156 = load i32, ptr %l87, !tbaa !23
  %t158 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t155, i32 %t156, i64 %t154)
  store i32 %t158, ptr %l89
  br label %bb36
bb36:
  %t159 = load i32, ptr %l89, !tbaa !23
  store i32 %t159, ptr %l17, !tbaa !23
  %t160 = load i32, ptr %l17, !tbaa !23
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t164 = icmp ne i32 %t160, %t161
  br i1 %t164, label %bb37, label %bb38
bb37:
  %t166 = load ptr, ptr %lp3
  %t167 = load i32, ptr %l17, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3, ptr %t166, i32 %t167)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  %t170 = load i64, ptr %l8, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l8, !tbaa !24
  br label %bb9
bb42:
  %t174 = load i64, ptr %l5, !tbaa !24
  %t175 = load i64, ptr %l7, !tbaa !24
  %t178 = add i64 %t174, %t175
  store i64 %t178, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  br label %bb2
bb44:
  %t180 = load ptr, ptr %lp3
  %t181 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t180
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t181, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellList(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l17 = alloca { i64, ptr }
  %l21 = alloca i1
  %l23 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i64
  %l60 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a2)
  store { i64, ptr } %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t11, ptr %l5, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t20, ptr %l23
  br label %bb4
bb3:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  %t21 = load i1, ptr %l23, !tbaa !21
  store i1 %t21, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v2, ptr %t23, { i64, ptr } %t24)
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 4
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l6, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 4
  store i1 true, ptr %t34, !tbaa !21
  store i64 0, ptr %l7, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t45 = load i64, ptr %l9, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb15
bb12:
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l9, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l9, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l37, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb14
bb14:
  %t65 = load i64, ptr %l37, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  br label %bb15
bb15:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l11, !tbaa !24
  %t68 = load i64, ptr %l10, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l11, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l12, !tbaa !24
  %t85 = load i64, ptr %l12, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t89, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t93, ptr %l60, !tbaa !27
  %t94 = load i64, ptr %l12, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t94
  %t99 = load i32, ptr %t98, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t91, ptr %t92, i32 %t99, i1 false)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t103 = load i64, ptr %l11, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l11, !tbaa !24
  br label %bb16
bb26:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i1, ptr %l6, !tbaa !21
  %t111 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 4
  store i1 %t108, ptr %t111, !tbaa !21
  %t112 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v3, ptr %t112, { i64, ptr } %a4)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l46 = alloca i32
  %l48 = alloca i1
  %l49 = alloca i1
  %l53 = alloca i1
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/msgs:Msg"
  %l62 = alloca i64
  %l67 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca i1
  %l75 = alloca i1
  %l80 = alloca i1
  %l85 = alloca i64
  %l88 = alloca i32
  %l92 = alloca i32
  %l95 = alloca i32
  %l99 = alloca i32
  %l103 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l106 = alloca i32
  %l107 = alloca i32
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l115 = alloca i1
  %l116 = alloca i1
  %l120 = alloca i1
  %l125 = alloca i1
  %l126 = alloca { i64, ptr }
  %l129 = alloca i64
  %l130 = alloca i64
  %l139 = alloca i32
  %l143 = alloca i1
  %l148 = alloca i1
  %l153 = alloca i64
  %l158 = alloca i64
  %l160 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %l163 = alloca { i64, ptr }
  %l165 = alloca %"compiler/msgs:Msg"
  %l166 = alloca i64
  %l169 = alloca ptr
  %l171 = alloca ptr
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca i32
  %l174 = alloca i32
  %l178 = alloca ptr
  %l179 = alloca ptr
  %l182 = alloca i1
  %l183 = alloca i1
  %l186 = alloca i1
  %l193 = alloca ptr
  %l196 = alloca i1
  %l197 = alloca i1
  %l200 = alloca i32
  %l206 = alloca ptr
  %l207 = alloca %"compiler/source:Span"
  %l210 = alloca %"compiler/msgs:Msg"
  %l211 = alloca i64
  %l216 = alloca ptr
  %l219 = alloca ptr
  %l223 = alloca %"compiler/source:Span"
  %l226 = alloca i32
  %l227 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca i32
  %l231 = alloca %"compiler/source:Span"
  %l232 = alloca i32
  %l235 = alloca ptr
  %l237 = alloca i32
  %l238 = alloca { i64, ptr }
  %l240 = alloca i32
  %l241 = alloca ptr
  %l242 = alloca %"compiler/source:Span"
  %l245 = alloca ptr
  %l246 = alloca { i64, ptr }
  %l247 = alloca i64
  %l254 = alloca ptr
  %l258 = alloca { i64, ptr }
  %l262 = alloca ptr
  %l265 = alloca ptr
  %l269 = alloca i64
  %l270 = alloca ptr
  %l271 = alloca ptr
  %l274 = alloca %"compiler/source:Span"
  %l275 = alloca ptr
  %l276 = alloca %"compiler/source:Span"
  %l277 = alloca ptr
  %l278 = alloca { i64, ptr }
  %l279 = alloca ptr
  %l280 = alloca { i64, ptr }
  %l282 = alloca %"compiler/source:Span"
  %l283 = alloca %"compiler/source:Span"
  %l284 = alloca i32
  %l288 = alloca { i64, ptr }
  %l289 = alloca %"compiler/typed:Seq"
  %l294 = alloca i1
  %l295 = alloca i1
  %l297 = alloca i1
  %l298 = alloca i1
  %l301 = alloca i32
  %l305 = alloca i1
  %l306 = alloca i64
  %l311 = alloca ptr
  %l312 = alloca %"compiler/source:Span"
  %l313 = alloca i64
  %l316 = alloca { i64, ptr }
  %l319 = alloca %"compiler/msgs:Msg"
  %l320 = alloca i64
  %l325 = alloca ptr
  %l328 = alloca ptr
  %l332 = alloca %"compiler/source:Span"
  %l335 = alloca i32
  %l336 = alloca ptr
  %l337 = alloca ptr
  %l338 = alloca i32
  %l340 = alloca %"compiler/source:Span"
  %l341 = alloca i32
  %l344 = alloca ptr
  %l346 = alloca i32
  %l347 = alloca { i64, ptr }
  %l349 = alloca i32
  %l351 = alloca i1
  %l352 = alloca ptr
  %l353 = alloca %"compiler/source:Span"
  %l357 = alloca { i64, ptr }
  %l360 = alloca { i64, ptr }
  %l364 = alloca ptr
  %l366 = alloca ptr
  %l367 = alloca %"compiler/source:Span"
  %l373 = alloca ptr
  %l378 = alloca ptr
  %l383 = alloca ptr
  %l386 = alloca i1
  %l387 = alloca i1
  %l390 = alloca i1
  %l391 = alloca ptr
  %l392 = alloca %"compiler/source:Span"
  %l393 = alloca %"compiler/msgs:Msg"
  %l394 = alloca i64
  %l399 = alloca ptr
  %l402 = alloca i32
  %l410 = alloca i1
  %l412 = alloca ptr
  %l413 = alloca %"compiler/source:Span"
  %l414 = alloca { i64, ptr }
  %l417 = alloca { i64, ptr }
  %l419 = alloca %"compiler/msgs:Msg"
  %l420 = alloca i64
  %l425 = alloca ptr
  %l429 = alloca i1
  %l434 = alloca i64
  %l437 = alloca ptr
  %l438 = alloca %"compiler/source:Span"
  %l441 = alloca { i64, ptr }
  %l442 = alloca { i64, ptr }
  %l447 = alloca i64
  %l448 = alloca %"compiler/msgs:Msg"
  %l449 = alloca i64
  %l454 = alloca ptr
  %l458 = alloca i1
  %l462 = alloca i64
  %l467 = alloca ptr
  %l468 = alloca %"compiler/source:Span"
  %l469 = alloca i64
  %l472 = alloca { i64, ptr }
  %l475 = alloca %"compiler/msgs:Msg"
  %l476 = alloca i64
  %l481 = alloca ptr
  %l486 = alloca ptr
  %l489 = alloca ptr
  %l490 = alloca %"compiler/source:Span"
  %l493 = alloca i32
  %l496 = alloca i32
  %l499 = alloca ptr
  %l501 = alloca ptr
  %l502 = alloca { i64, ptr }
  %l504 = alloca ptr
  %l506 = alloca i32
  %l507 = alloca ptr
  %l510 = alloca i32
  %l516 = alloca ptr
  %l520 = alloca i1
  %l522 = alloca ptr
  %l523 = alloca { i64, ptr }
  %l525 = alloca %"compiler/source:Span"
  %l528 = alloca { i64, ptr }
  %l530 = alloca %"compiler/msgs:Msg"
  %l531 = alloca i64
  %l534 = alloca ptr
  %l538 = alloca i32
  %l540 = alloca i32
  %l542 = alloca ptr
  %l543 = alloca { i64, ptr }
  %l545 = alloca %"compiler/source:Span"
  %l547 = alloca i32
  %l550 = alloca ptr
  %l558 = alloca ptr
  %l561 = alloca i1
  %l562 = alloca i1
  %l566 = alloca i1
  %l569 = alloca i32
  %l572 = alloca i1
  %l576 = alloca ptr
  %l578 = alloca ptr
  %l581 = alloca ptr
  %l587 = alloca ptr
  %l589 = alloca ptr
  %l592 = alloca ptr
  %l594 = alloca ptr
  %l595 = alloca %"compiler/source:Span"
  %l596 = alloca i32
  %l597 = alloca i32
  %l601 = alloca ptr
  %l602 = alloca ptr
  %l605 = alloca i1
  %l606 = alloca i1
  %l610 = alloca i1
  %l611 = alloca ptr
  %l616 = alloca i32
  %l617 = alloca i1
  %l620 = alloca i1
  %l622 = alloca ptr
  %l623 = alloca %"compiler/source:Span"
  %l626 = alloca { i64, ptr }
  %l628 = alloca %"compiler/msgs:Msg"
  %l629 = alloca i64
  %l632 = alloca ptr
  %l635 = alloca ptr
  %l639 = alloca ptr
  %l640 = alloca i1
  %l645 = alloca ptr
  %l648 = alloca %"compiler/source:Span"
  %l649 = alloca %"compiler/msgs:Msg"
  %l650 = alloca i64
  %l653 = alloca ptr
  %l660 = alloca ptr
  %l663 = alloca i1
  %l664 = alloca i1
  %l668 = alloca i1
  %l672 = alloca ptr
  %l674 = alloca ptr
  %l677 = alloca ptr
  %l681 = alloca ptr
  %l684 = alloca i1
  %l687 = alloca i1
  %l689 = alloca ptr
  %l692 = alloca %"compiler/source:Span"
  %l693 = alloca %"compiler/msgs:Msg"
  %l694 = alloca i64
  %l697 = alloca ptr
  %l701 = alloca %"compiler/source:Span"
  %l703 = alloca i32
  %l708 = alloca i1
  %l711 = alloca i1
  %l714 = alloca i1
  %l717 = alloca i1
  %l720 = alloca i1
  %l723 = alloca i1
  %l730 = alloca i1
  %l732 = alloca ptr
  %l733 = alloca %"compiler/source:Span"
  %l736 = alloca { i64, ptr }
  %l738 = alloca %"compiler/msgs:Msg"
  %l739 = alloca i64
  %l742 = alloca ptr
  %l746 = alloca ptr
  %l747 = alloca %"compiler/source:Span"
  %l750 = alloca { i64, ptr }
  %l752 = alloca %"compiler/msgs:Msg"
  %l753 = alloca i64
  %l756 = alloca ptr
  %l759 = alloca ptr
  %l762 = alloca ptr
  %l765 = alloca %"compiler/source:Span"
  %l766 = alloca %"compiler/msgs:Msg"
  %l767 = alloca i64
  %l770 = alloca ptr
  %l780 = alloca i1
  %l783 = alloca i1
  %l785 = alloca ptr
  %l788 = alloca %"compiler/source:Span"
  %l789 = alloca %"compiler/msgs:Msg"
  %l790 = alloca i64
  %l793 = alloca ptr
  %l799 = alloca ptr
  %l800 = alloca %"compiler/source:Span"
  %l801 = alloca i64
  %l804 = alloca { i64, ptr }
  %l807 = alloca %"compiler/msgs:Msg"
  %l808 = alloca i64
  %l811 = alloca ptr
  %l815 = alloca i64
  %l817 = alloca ptr
  %l818 = alloca %"compiler/source:Span"
  %l824 = alloca i32
  %l835 = alloca { i64, ptr }
  %l839 = alloca ptr
  %l843 = alloca ptr
  %l848 = alloca i32
  %l851 = alloca %"compiler/source:Span"
  %l852 = alloca i32
  %l853 = alloca i32
  %l854 = alloca i32
  %l858 = alloca { i64, ptr }
  %l862 = alloca i1
  %l863 = alloca i1
  %l871 = alloca ptr
  %l872 = alloca %"compiler/source:Span"
  %l873 = alloca ptr
  %l874 = alloca %"compiler/source:Span"
  %l876 = alloca i32
  %l880 = alloca ptr
  %l881 = alloca ptr
  %l885 = alloca ptr
  %l886 = alloca { i64, ptr }
  %l887 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %rv = alloca ptr
  %t383 = alloca { i64, [4 x i64] }, align 8
  %t519 = alloca { i64, [5 x i64] }, align 8
  %t618 = alloca { i64, [4 x i64] }, align 8
  %t1358 = alloca { i64, [5 x i64] }, align 8
  %t1601 = alloca { i64, [5 x i64] }, align 8
  %t1673 = alloca { i64, [5 x i64] }, align 8
  %t1721 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l39, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t2)
  store i32 %t5, ptr %l42
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l39, !tbaa !29
  %t7 = load i32, ptr %l42, !tbaa !23
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l43
  br label %bb2
bb2:
  %t9 = load i32, ptr %l43, !tbaa !23
  store i32 %t9, ptr %l7, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l7, !tbaa !23
  %t14 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l46
  br label %bb3
bb3:
  %t15 = load i32, ptr %l46, !tbaa !23
  store i32 %t15, ptr %l8, !tbaa !23
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t18, ptr %l48
  br label %bb4
bb4:
  %t19 = load i1, ptr %l48, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp sgt i64 %t22, 0
  store i1 %t24, ptr %l49, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l49, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l8, !tbaa !23
  %t36 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l58
  br label %bb10
bb9:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb11
bb10:
  %t37 = load i1, ptr %l58, !tbaa !21
  store i1 %t37, ptr %l53, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l53, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l59, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t40, ptr %l60
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %s1, ptr %s1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t41, ptr %l61
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t42 = load ptr, ptr %l59, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l60
  %t44 = load %"compiler/msgs:Msg", ptr %l61
  %t45 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t42, %"compiler/source:Span" %t43, %"compiler/msgs:Msg" %t44)
  store i64 %t45, ptr %l62
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t46, { i64, ptr } %t47)
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t50, %"compiler/source:Span" %t51)
  store ptr %t54, ptr %l67
  br label %bb17
bb17:
  %t55 = load ptr, ptr %l67, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t55, ptr %rv
  br label %ret
bb18:
  %t57 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t57, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t59, ptr %l70
  br label %bb19
bb19:
  %t60 = load i1, ptr %l70, !tbaa !21
  br i1 %t60, label %bb20, label %bb21
bb20:
  %t61 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t65 = icmp eq i64 %t63, 0
  store i1 %t65, ptr %l71, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb22
bb22:
  %t67 = load i1, ptr %l71, !tbaa !21
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l8, !tbaa !23
  %t77 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t73, i32 %t74)
  store i1 %t77, ptr %l80
  br label %bb25
bb24:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb26
bb25:
  %t78 = load i1, ptr %l80, !tbaa !21
  store i1 %t78, ptr %l75, !tbaa !21
  br label %bb26
bb26:
  %t79 = load i1, ptr %l75, !tbaa !21
  br i1 %t79, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %l8, !tbaa !23
  %t89 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t85, i32 %t86)
  store i64 %t89, ptr %l85
  br label %bb29
bb28:
  br label %bb41
bb29:
  %t90 = load i64, ptr %l85, !tbaa !24
  store i64 %t90, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t93 = icmp eq i64 %t91, 64
  br i1 %t93, label %bb30, label %bb31
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 2
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t100, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i32 %t102, ptr %l92
  br label %bb32
bb31:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t105 = icmp eq i64 %t103, 32
  br i1 %t105, label %bb33, label %bb34
bb32:
  %t107 = load i32, ptr %l92, !tbaa !23
  store i32 %t107, ptr %l88, !tbaa !23
  br label %bb38
bb33:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t113, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i32 %t115, ptr %l99
  br label %bb35
bb34:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t121, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i32 %t123, ptr %l103
  br label %bb36
bb35:
  %t124 = load i32, ptr %l99, !tbaa !23
  store i32 %t124, ptr %l95, !tbaa !23
  br label %bb37
bb36:
  %t125 = load i32, ptr %l103, !tbaa !23
  store i32 %t125, ptr %l95, !tbaa !23
  br label %bb37
bb37:
  %t126 = load i32, ptr %l95, !tbaa !23
  store i32 %t126, ptr %l88, !tbaa !23
  br label %bb38
bb38:
  %t127 = load i32, ptr %l88, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l104, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t129, ptr %l105
  store i32 %t127, ptr %l106, !tbaa !23
  store i32 21, ptr %l107
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l4, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l1
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t131, ptr %t132, %"compiler/source:Span" %t133)
  store ptr %t137, ptr %l111
  br label %bb39
bb39:
  %t138 = load ptr, ptr %l104, !tbaa !29
  %t139 = load %"compiler/source:Span", ptr %l105
  %t140 = load i32, ptr %l106, !tbaa !23
  %t141 = load i32, ptr %l107
  %t142 = load ptr, ptr %l111, !tbaa !29
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t138, %"compiler/source:Span" %t139, i32 %t140, i32 %t141, ptr %t142, ptr null)
  store ptr %t143, ptr %l112
  br label %bb40
bb40:
  %t144 = load ptr, ptr %l112, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t144, ptr %rv
  br label %ret
bb41:
  %t146 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s0, { i64, ptr } %t146, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t148, ptr %l115
  br label %bb42
bb42:
  %t149 = load i1, ptr %l115, !tbaa !21
  br i1 %t149, label %bb43, label %bb44
bb43:
  %t150 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t154 = icmp eq i64 %t152, 0
  store i1 %t154, ptr %l116, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb45
bb45:
  %t156 = load i1, ptr %l116, !tbaa !21
  br i1 %t156, label %bb46, label %bb47
bb46:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  %t163 = load i32, ptr %l8, !tbaa !23
  %t166 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t162, i32 %t163)
  store i1 %t166, ptr %l125
  br label %bb48
bb47:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb49
bb48:
  %t167 = load i1, ptr %l125, !tbaa !21
  store i1 %t167, ptr %l120, !tbaa !21
  br label %bb49
bb49:
  %t168 = load i1, ptr %l120, !tbaa !21
  br i1 %t168, label %bb50, label %bb51
bb50:
  %t169 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t169, ptr %l126, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t174 = sub i64 %t172, 8
  store i64 %t174, ptr %l129, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  store i64 %t176, ptr %l130, !tbaa !24
  %t177 = icmp sge i64 0, 0
  br i1 %t177, label %bb52, label %bb53
bb51:
  br label %bb77
bb52:
  %t179 = load i64, ptr %l129, !tbaa !24
  %t180 = icmp sle i64 0, %t179
  br i1 %t180, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_de1861672a449342_6f761fc46447aabe)
  unreachable
bb54:
  %t182 = load i64, ptr %l129, !tbaa !24
  %t183 = load i64, ptr %l130, !tbaa !24
  %t184 = icmp sle i64 %t182, %t183
  br i1 %t184, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_de1861672a449342_6f761fc46447aabe)
  unreachable
bb56:
  %t186 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = load i64, ptr %l129, !tbaa !24
  %t189 = getelementptr i8, ptr %t187, i64 0
  %t190 = sub i64 %t188, 0
  %t191 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t189, 1
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/generic:Program", ptr %t197, i32 0, i32 2
  %t203 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v2, ptr %t199, { i64, ptr } %t192)
  store i32 %t203, ptr %l139
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_de1861672a449342_6f761fc46447aabe)
  unreachable
bb58:
  %t204 = load i32, ptr %l139, !tbaa !23
  store i32 %t204, ptr %l12, !tbaa !23
  %t205 = load i32, ptr %l12, !tbaa !23
  %t206 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t209 = icmp ne i32 %t205, %t206
  br i1 %t209, label %bb59, label %bb60
bb59:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l12, !tbaa !23
  %t220 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t216, i32 %t217)
  store i1 %t220, ptr %l148
  br label %bb61
bb60:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb62
bb61:
  %t221 = load i1, ptr %l148, !tbaa !21
  store i1 %t221, ptr %l143, !tbaa !21
  br label %bb62
bb62:
  %t222 = load i1, ptr %l143, !tbaa !21
  br i1 %t222, label %bb63, label %bb64
bb63:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  %t229 = load i32, ptr %l12, !tbaa !23
  %t232 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t228, i32 %t229)
  store i64 %t232, ptr %l153
  br label %bb65
bb64:
  br label %bb76
bb65:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  %t239 = load i32, ptr %l8, !tbaa !23
  %t242 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t238, i32 %t239)
  store i64 %t242, ptr %l158
  br label %bb66
bb66:
  %t243 = load i64, ptr %l153, !tbaa !24
  %t244 = load i64, ptr %l158, !tbaa !24
  %t245 = icmp ne i64 %t243, %t244
  br i1 %t245, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s5
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l160, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t248, ptr %l161
  %t249 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t251 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v2, ptr %s5, { i64, ptr } %t249)
  store { i64, ptr } %t251, ptr %l163
  br label %bb69
bb68:
  br label %bb73
bb69:
  %t252 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 0
  %t254 = extractvalue { i64, ptr } %t252, 1
  %t255 = mul i64 %t253, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t260 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFromBitsReceiver(ptr %s5, ptr %s5, { i64, ptr } %t258)
  store %"compiler/msgs:Msg" %t260, ptr %l165
  br label %bb70
bb70:
  %t261 = load ptr, ptr %l160, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l161
  %t263 = load %"compiler/msgs:Msg", ptr %l165
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t261, %"compiler/source:Span" %t262, %"compiler/msgs:Msg" %t263)
  store i64 %t264, ptr %l166
  br label %bb71
bb71:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  %t269 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t265, %"compiler/source:Span" %t266)
  store ptr %t269, ptr %l169
  br label %bb72
bb72:
  %t270 = load ptr, ptr %l169, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t270, ptr %rv
  br label %ret
bb73:
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l171, !tbaa !29
  %t273 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t273, ptr %l172
  %t274 = load i32, ptr %l12, !tbaa !23
  store i32 %t274, ptr %l173, !tbaa !23
  store i32 21, ptr %l174
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load ptr, ptr %l4, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l1
  %t281 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t275, ptr %t276, %"compiler/source:Span" %t277)
  store ptr %t281, ptr %l178
  br label %bb74
bb74:
  %t282 = load ptr, ptr %l171, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l172
  %t284 = load i32, ptr %l173, !tbaa !23
  %t285 = load i32, ptr %l174
  %t286 = load ptr, ptr %l178, !tbaa !29
  %t287 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t282, %"compiler/source:Span" %t283, i32 %t284, i32 %t285, ptr %t286, ptr null)
  store ptr %t287, ptr %l179
  br label %bb75
bb75:
  %t288 = load ptr, ptr %l179, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t288, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  %t290 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t292 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t290, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t292, ptr %l182
  br label %bb78
bb78:
  %t293 = load i1, ptr %l182, !tbaa !21
  br i1 %t293, label %bb79, label %bb80
bb79:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i32, ptr %l7, !tbaa !23
  %t298 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t294, i32 %t295)
  store i1 %t298, ptr %l186
  br label %bb81
bb80:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb82
bb81:
  %t299 = load i1, ptr %l186, !tbaa !21
  store i1 %t299, ptr %l183, !tbaa !21
  br label %bb82
bb82:
  %t300 = load i1, ptr %l183, !tbaa !21
  br i1 %t300, label %bb83, label %bb84
bb83:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l1
  %t303 = load %"compiler/source:Span", ptr %l2
  %t304 = load i32, ptr %l7, !tbaa !23
  %t305 = load ptr, ptr %l4, !tbaa !29
  %t306 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t313 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawValue(ptr %v0, ptr %v3, ptr %t301, %"compiler/source:Span" %t302, %"compiler/source:Span" %t303, i32 %t304, ptr %t305, { i64, ptr } %t306)
  store ptr %t313, ptr %l193
  br label %bb85
bb84:
  br label %bb86
bb85:
  %t314 = load ptr, ptr %l193, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t314, ptr %rv
  br label %ret
bb86:
  %t316 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t318 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t316, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t318, ptr %l196
  br label %bb87
bb87:
  %t319 = load i1, ptr %l196, !tbaa !21
  br i1 %t319, label %bb88, label %bb89
bb88:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load i32, ptr %l7, !tbaa !23
  %t324 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t320, i32 %t321)
  store i32 %t324, ptr %l200
  br label %bb90
bb89:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb91
bb90:
  %t325 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t326 = load i32, ptr %l200, !tbaa !23
  %t328 = icmp ne i32 %t326, %t325
  store i1 %t328, ptr %l197, !tbaa !21
  br label %bb91
bb91:
  %t330 = load i1, ptr %l197, !tbaa !21
  br i1 %t330, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s7
  %t331 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t331, 0
  %t335 = icmp ne i64 %t333, 2
  br i1 %t335, label %bb94, label %bb95
bb93:
  br label %bb133
bb94:
  store %olang.scope zeroinitializer, ptr %s8
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l206, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t338, ptr %l207
  %t339 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t339, 0
  %t343 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s8, ptr %s8, i64 2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, i64 %t341)
  store %"compiler/msgs:Msg" %t343, ptr %l210
  br label %bb96
bb95:
  br label %bb100
bb96:
  %t344 = load ptr, ptr %l206, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l207
  %t346 = load %"compiler/msgs:Msg", ptr %l210
  %t347 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t344, %"compiler/source:Span" %t345, %"compiler/msgs:Msg" %t346)
  store i64 %t347, ptr %l211
  br label %bb97
bb97:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t348, { i64, ptr } %t349)
  br label %bb98
bb98:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l1
  %t356 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t352, %"compiler/source:Span" %t353)
  store ptr %t356, ptr %l216
  br label %bb99
bb99:
  %t357 = load ptr, ptr %l216, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t357, ptr %rv
  br label %ret
bb100:
  %t359 = load ptr, ptr %l4, !tbaa !29
  %t361 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t359)
  store ptr %t361, ptr %l219
  br label %bb101
bb101:
  %t362 = load ptr, ptr %l219, !tbaa !29
  store ptr %t362, ptr %l13, !tbaa !29
  %t363 = load ptr, ptr %l13, !tbaa !29
  %t365 = icmp eq ptr %t363, null
  br i1 %t365, label %bb102, label %bb103
bb102:
  %t367 = load ptr, ptr %l3, !tbaa !29
  %t369 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t367)
  store %"compiler/source:Span" %t369, ptr %l223
  br label %bb104
bb103:
  br label %bb108
bb104:
  %t370 = load ptr, ptr %l4, !tbaa !29
  %t373 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t370)
  store i32 %t373, ptr %l226
  br label %bb105
bb105:
  %t374 = load ptr, ptr %l4, !tbaa !29
  store ptr %t374, ptr %l227, !tbaa !29
  %t375 = load ptr, ptr %l0, !tbaa !29
  store ptr %t375, ptr %l228, !tbaa !29
  store i32 8, ptr %l229
  %t376 = load ptr, ptr %l3, !tbaa !29
  %t378 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t376)
  store %"compiler/source:Span" %t378, ptr %l231
  br label %bb106
bb106:
  %t379 = load ptr, ptr %l228, !tbaa !29
  %t380 = load i32, ptr %l229
  %t381 = load %"compiler/source:Span", ptr %l231
  %t382 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t379, i32 %t380, %"compiler/source:Span" %t381)
  store i32 %t382, ptr %l232
  br label %bb107
bb107:
  store { i64, [4 x i64] } zeroinitializer, ptr %t383
  %t384 = getelementptr { i64, [4 x i64] }, ptr %t383, i32 0, i32 0
  store i64 6, ptr %t384
  %t385 = load %"compiler/source:Span", ptr %l223
  %t386 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t385, 0
  %t387 = load i32, ptr %l226, !tbaa !23
  %t388 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t386, i32 %t387, 1
  %t389 = load ptr, ptr %l227, !tbaa !29
  %t390 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t388, ptr %t389, 2
  %t391 = load i32, ptr %l232, !tbaa !23
  %t392 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t390, i32 %t391, 3
  %t393 = getelementptr { i64, [4 x i64] }, ptr %t383, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t392, ptr %t393
  %t394 = load { i64, [4 x i64] }, ptr %t383
  %t396 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t394, ptr %t396
  store ptr %t396, ptr %l13, !tbaa !29
  br label %bb108
bb108:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l235, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoutOfRange(ptr %v0, ptr %t399)
  store i32 %t401, ptr %l237
  br label %bb109
bb109:
  %t402 = mul i64 1, 4
  %t403 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t402)
  %t404 = insertvalue { i64, ptr } undef, i64 1, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  store { i64, ptr } %t405, ptr %l238, !tbaa !27
  %t406 = load i32, ptr %l237, !tbaa !23
  %t407 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr i32, ptr %t408, i64 0
  store i32 %t406, ptr %t409, !tbaa !33
  %t410 = load %"compiler/source:Span", ptr %l2
  %t411 = load ptr, ptr %l235, !tbaa !29
  %t412 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t414 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s7, ptr %t411, { i64, ptr } %t412, %"compiler/source:Span" %t410, i1 false)
  store i32 %t414, ptr %l240
  br label %bb110
bb110:
  %t415 = load i32, ptr %l240
  store i32 %t415, ptr %l14
  %t416 = load ptr, ptr %l0, !tbaa !29
  store ptr %t416, ptr %l241, !tbaa !29
  %t417 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t417, ptr %l242
  %t418 = load ptr, ptr %l13, !tbaa !29
  %t420 = icmp eq ptr %t418, null
  br i1 %t420, label %bb111, label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_c7803a0ae3a7f551_a0a1c1dd70cf568d)
  unreachable
bb112:
  br label %bb113
bb113:
  %t422 = load ptr, ptr %l13, !tbaa !29
  store ptr %t422, ptr %l245, !tbaa !29
  %t423 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t423, ptr %l246, !tbaa !27
  %t424 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 0
  store i64 %t425, ptr %l247, !tbaa !24
  %t426 = icmp sge i64 0, 0
  br i1 %t426, label %bb114, label %bb115
bb114:
  %t428 = icmp sle i64 0, 1
  br i1 %t428, label %bb116, label %bb117
bb115:
  call void @__olang_check_failed(ptr @olang_loc_77737f92dc0fe3d4_2745f5c5195bdf40)
  unreachable
bb116:
  %t430 = load i64, ptr %l247, !tbaa !24
  %t431 = icmp sle i64 1, %t430
  br i1 %t431, label %bb118, label %bb119
bb117:
  call void @__olang_check_failed(ptr @olang_loc_77737f92dc0fe3d4_2745f5c5195bdf40)
  unreachable
bb118:
  %t433 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr ptr, ptr %t434, i64 0
  %t437 = insertvalue { i64, ptr } undef, i64 1, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t435, 1
  %t439 = load i32, ptr %l14
  %t440 = load ptr, ptr %l241, !tbaa !29
  %t441 = load %"compiler/source:Span", ptr %l242
  %t442 = load ptr, ptr %l245, !tbaa !29
  %t445 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v3, ptr %t440, %"compiler/source:Span" %t441, ptr %t442, { i64, ptr } %t438, i32 %t439)
  store ptr %t445, ptr %l254
  br label %bb120
bb119:
  call void @__olang_check_failed(ptr @olang_loc_77737f92dc0fe3d4_2745f5c5195bdf40)
  unreachable
bb120:
  %t446 = load ptr, ptr %l254, !tbaa !29
  store ptr %t446, ptr %l15, !tbaa !29
  %t447 = load ptr, ptr %l15, !tbaa !29
  %t449 = icmp eq ptr %t447, null
  br i1 %t449, label %bb121, label %bb122
bb121:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t452, ptr %l258, !tbaa !27
  %t453 = getelementptr { i64, ptr }, ptr %l258, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !27
  %t455 = getelementptr ptr, ptr %t454, i64 1
  %t456 = load ptr, ptr %t455, !tbaa !39
  %t458 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t462 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v3, ptr %t451, ptr %t456, i32 %t458)
  store ptr %t462, ptr %l262
  br label %bb123
bb122:
  br label %bb125
bb123:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load %"compiler/source:Span", ptr %l1
  %t467 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t463, %"compiler/source:Span" %t464)
  store ptr %t467, ptr %l265
  br label %bb124
bb124:
  %t468 = load ptr, ptr %l265, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t468, ptr %rv
  br label %ret
bb125:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/check:Checker", ptr %t470, i32 0, i32 33
  %t474 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t472)
  store i64 %t474, ptr %l269
  br label %bb126
bb126:
  %t475 = load i64, ptr %l269, !tbaa !24
  store i64 %t475, ptr %l16, !tbaa !24
  %t476 = load ptr, ptr %l0, !tbaa !29
  store ptr %t476, ptr %l270, !tbaa !29
  %t477 = load ptr, ptr %l15, !tbaa !29
  store ptr %t477, ptr %l271, !tbaa !29
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load ptr, ptr %l3, !tbaa !29
  %t482 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteAt(ptr %v0, ptr %v1, ptr %t478, ptr %t479)
  store %"compiler/source:Span" %t482, ptr %l274
  br label %bb127
bb127:
  %t483 = load ptr, ptr %l270, !tbaa !29
  %t484 = load ptr, ptr %l271, !tbaa !29
  %t485 = load %"compiler/source:Span", ptr %l274
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v0, ptr %t483, ptr %t484, %"compiler/source:Span" %t485)
  br label %bb128
bb128:
  %t486 = load ptr, ptr %l0, !tbaa !29
  store ptr %t486, ptr %l275, !tbaa !29
  %t487 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t487, ptr %l276
  %t488 = load ptr, ptr %l15, !tbaa !29
  store ptr %t488, ptr %l277, !tbaa !29
  %t489 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t489, ptr %l278, !tbaa !27
  %t490 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !27
  %t492 = getelementptr ptr, ptr %t491, i64 1
  %t493 = load ptr, ptr %t492, !tbaa !39
  store ptr %t493, ptr %l279, !tbaa !29
  %t494 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t494, ptr %l280, !tbaa !27
  %t495 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !27
  %t497 = getelementptr ptr, ptr %t496, i64 1
  %t498 = load ptr, ptr %t497, !tbaa !39
  %t500 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t498)
  store %"compiler/source:Span" %t500, ptr %l282
  br label %bb129
bb129:
  %t501 = load ptr, ptr %l275, !tbaa !29
  %t502 = load %"compiler/source:Span", ptr %l276
  %t503 = load ptr, ptr %l277, !tbaa !29
  %t504 = load ptr, ptr %l279, !tbaa !29
  %t505 = load %"compiler/source:Span", ptr %l282
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreInto(ptr %v0, ptr %v3, ptr %v0, ptr %t501, %"compiler/source:Span" %t502, ptr %t503, ptr %t504, %"compiler/source:Span" %t505, ptr null)
  br label %bb130
bb130:
  %t506 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t506, ptr %l283
  %t507 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t507, ptr %l284, !tbaa !23
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t510 = getelementptr %"compiler/check:Checker", ptr %t508, i32 0, i32 33
  %t511 = load i64, ptr %l16, !tbaa !24
  %t514 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t510, i64 %t511)
  store { i64, ptr } %t514, ptr %l288
  br label %bb131
bb131:
  %t515 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t516 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t515, ptr null)
  store %"compiler/typed:Seq" %t516, ptr %l289
  br label %bb132
bb132:
  %t517 = load %"compiler/typed:Seq", ptr %l289
  %t518 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t517, ptr %t518
  store { i64, [5 x i64] } zeroinitializer, ptr %t519
  %t520 = getelementptr { i64, [5 x i64] }, ptr %t519, i32 0, i32 0
  store i64 12, ptr %t520
  %t521 = load %"compiler/source:Span", ptr %l283
  %t522 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t521, 0
  %t523 = load i32, ptr %l284, !tbaa !23
  %t524 = insertvalue { %"compiler/source:Span", i32, ptr } %t522, i32 %t523, 1
  %t526 = insertvalue { %"compiler/source:Span", i32, ptr } %t524, ptr %t518, 2
  %t527 = getelementptr { i64, [5 x i64] }, ptr %t519, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t526, ptr %t527
  %t528 = load { i64, [5 x i64] }, ptr %t519
  %t530 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t528, ptr %t530
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t530, ptr %rv
  br label %ret
bb133:
  %t532 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t534 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t532, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t534, ptr %l294
  br label %bb134
bb134:
  %t535 = load i1, ptr %l294, !tbaa !21
  br i1 %t535, label %bb135, label %bb136
bb135:
  store i1 true, ptr %l295, !tbaa !21
  br label %bb138
bb136:
  %t536 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t538 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t536, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t538, ptr %l297
  br label %bb137
bb137:
  %t539 = load i1, ptr %l297, !tbaa !21
  store i1 %t539, ptr %l295, !tbaa !21
  br label %bb138
bb138:
  %t540 = load i1, ptr %l295, !tbaa !21
  br i1 %t540, label %bb139, label %bb140
bb139:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load i32, ptr %l7, !tbaa !23
  %t545 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t541, i32 %t542)
  store i32 %t545, ptr %l301
  br label %bb141
bb140:
  store i1 false, ptr %l298, !tbaa !21
  br label %bb142
bb141:
  %t546 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t547 = load i32, ptr %l301, !tbaa !23
  %t549 = icmp ne i32 %t547, %t546
  store i1 %t549, ptr %l298, !tbaa !21
  br label %bb142
bb142:
  %t551 = load i1, ptr %l298, !tbaa !21
  br i1 %t551, label %bb143, label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s11
  %t552 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t554 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s11, { i64, ptr } %t552, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t554, ptr %l305
  br label %bb145
bb144:
  br label %bb186
bb145:
  %t555 = load i1, ptr %l305, !tbaa !21
  br i1 %t555, label %bb146, label %bb147
bb146:
  store i64 1, ptr %l306, !tbaa !24
  br label %bb148
bb147:
  store i64 2, ptr %l306, !tbaa !24
  br label %bb148
bb148:
  %t556 = load i64, ptr %l306, !tbaa !24
  store i64 %t556, ptr %l17, !tbaa !24
  %t557 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t559 = extractvalue { i64, ptr } %t557, 0
  %t560 = load i64, ptr %l17, !tbaa !24
  %t563 = icmp ne i64 %t559, %t560
  br i1 %t563, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s12
  %t565 = load ptr, ptr %l0, !tbaa !29
  store ptr %t565, ptr %l311, !tbaa !29
  %t566 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t566, ptr %l312
  %t567 = load i64, ptr %l17, !tbaa !24
  store i64 %t567, ptr %l313, !tbaa !24
  %t568 = load i64, ptr %l17, !tbaa !24
  %t570 = icmp eq i64 %t568, 1
  br i1 %t570, label %bb151, label %bb152
bb150:
  br label %bb158
bb151:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l316, !tbaa !27
  br label %bb153
bb152:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l316, !tbaa !27
  br label %bb153
bb153:
  %t572 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t572, 0
  %t575 = load i64, ptr %l313, !tbaa !24
  %t576 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t578 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s12, ptr %s12, i64 %t575, { i64, ptr } %t576, i64 %t574)
  store %"compiler/msgs:Msg" %t578, ptr %l319
  br label %bb154
bb154:
  %t579 = load ptr, ptr %l311, !tbaa !29
  %t580 = load %"compiler/source:Span", ptr %l312
  %t581 = load %"compiler/msgs:Msg", ptr %l319
  %t582 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t579, %"compiler/source:Span" %t580, %"compiler/msgs:Msg" %t581)
  store i64 %t582, ptr %l320
  br label %bb155
bb155:
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t583, { i64, ptr } %t584)
  br label %bb156
bb156:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load %"compiler/source:Span", ptr %l1
  %t591 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t587, %"compiler/source:Span" %t588)
  store ptr %t591, ptr %l325
  br label %bb157
bb157:
  %t592 = load ptr, ptr %l325, !tbaa !29
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t592, ptr %rv
  br label %ret
bb158:
  %t594 = load ptr, ptr %l4, !tbaa !29
  %t596 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t594)
  store ptr %t596, ptr %l328
  br label %bb159
bb159:
  %t597 = load ptr, ptr %l328, !tbaa !29
  store ptr %t597, ptr %l18, !tbaa !29
  %t598 = load ptr, ptr %l18, !tbaa !29
  %t600 = icmp eq ptr %t598, null
  br i1 %t600, label %bb160, label %bb161
bb160:
  %t602 = load ptr, ptr %l3, !tbaa !29
  %t604 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t602)
  store %"compiler/source:Span" %t604, ptr %l332
  br label %bb162
bb161:
  br label %bb166
bb162:
  %t605 = load ptr, ptr %l4, !tbaa !29
  %t608 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t605)
  store i32 %t608, ptr %l335
  br label %bb163
bb163:
  %t609 = load ptr, ptr %l4, !tbaa !29
  store ptr %t609, ptr %l336, !tbaa !29
  %t610 = load ptr, ptr %l0, !tbaa !29
  store ptr %t610, ptr %l337, !tbaa !29
  store i32 8, ptr %l338
  %t611 = load ptr, ptr %l3, !tbaa !29
  %t613 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t611)
  store %"compiler/source:Span" %t613, ptr %l340
  br label %bb164
bb164:
  %t614 = load ptr, ptr %l337, !tbaa !29
  %t615 = load i32, ptr %l338
  %t616 = load %"compiler/source:Span", ptr %l340
  %t617 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t614, i32 %t615, %"compiler/source:Span" %t616)
  store i32 %t617, ptr %l341
  br label %bb165
bb165:
  store { i64, [4 x i64] } zeroinitializer, ptr %t618
  %t619 = getelementptr { i64, [4 x i64] }, ptr %t618, i32 0, i32 0
  store i64 6, ptr %t619
  %t620 = load %"compiler/source:Span", ptr %l332
  %t621 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t620, 0
  %t622 = load i32, ptr %l335, !tbaa !23
  %t623 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t621, i32 %t622, 1
  %t624 = load ptr, ptr %l336, !tbaa !29
  %t625 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t623, ptr %t624, 2
  %t626 = load i32, ptr %l341, !tbaa !23
  %t627 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t625, i32 %t626, 3
  %t628 = getelementptr { i64, [4 x i64] }, ptr %t618, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t627, ptr %t628
  %t629 = load { i64, [4 x i64] }, ptr %t618
  %t631 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t629, ptr %t631
  store ptr %t631, ptr %l18, !tbaa !29
  br label %bb166
bb166:
  %t633 = load ptr, ptr %l0, !tbaa !29
  store ptr %t633, ptr %l344, !tbaa !29
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t636 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoutOfRange(ptr %v0, ptr %t634)
  store i32 %t636, ptr %l346
  br label %bb167
bb167:
  %t637 = mul i64 1, 4
  %t638 = call ptr @__olang_scope_alloc_zeroed(ptr %s11, i64 %t637)
  %t639 = insertvalue { i64, ptr } undef, i64 1, 0
  %t640 = insertvalue { i64, ptr } %t639, ptr %t638, 1
  store { i64, ptr } %t640, ptr %l347, !tbaa !27
  %t641 = load i32, ptr %l346, !tbaa !23
  %t642 = getelementptr { i64, ptr }, ptr %l347, i32 0, i32 1
  %t643 = load ptr, ptr %t642, !tbaa !27
  %t644 = getelementptr i32, ptr %t643, i64 0
  store i32 %t641, ptr %t644, !tbaa !33
  %t645 = load %"compiler/source:Span", ptr %l2
  %t646 = load ptr, ptr %l344, !tbaa !29
  %t647 = load { i64, ptr }, ptr %l347, !tbaa !27
  %t649 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s11, ptr %t646, { i64, ptr } %t647, %"compiler/source:Span" %t645, i1 false)
  store i32 %t649, ptr %l349
  br label %bb168
bb168:
  %t650 = load i32, ptr %l349
  store i32 %t650, ptr %l19
  %t651 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t653 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s11, { i64, ptr } %t651, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t653, ptr %l351
  br label %bb169
bb169:
  %t654 = load i1, ptr %l351, !tbaa !21
  br i1 %t654, label %bb170, label %bb171
bb170:
  %t655 = load ptr, ptr %l0, !tbaa !29
  store ptr %t655, ptr %l352, !tbaa !29
  %t656 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t656, ptr %l353
  %t657 = load ptr, ptr %l18, !tbaa !29
  %t659 = icmp eq ptr %t657, null
  br i1 %t659, label %bb172, label %bb173
bb171:
  br label %bb176
bb172:
  call void @__olang_check_failed(ptr @olang_loc_56b27b3a434e6e4b_829f47044d523297)
  unreachable
bb173:
  br label %bb174
bb174:
  %t661 = load ptr, ptr %l18, !tbaa !29
  %t662 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t662, ptr %l357, !tbaa !27
  %t663 = getelementptr { i64, ptr }, ptr %l357, i32 0, i32 1
  %t664 = load ptr, ptr %t663, !tbaa !27
  %t665 = getelementptr ptr, ptr %t664, i64 0
  %t666 = load ptr, ptr %t665, !tbaa !39
  %t668 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t668, ptr %l360, !tbaa !27
  %t669 = getelementptr { i64, ptr }, ptr %l360, i32 0, i32 1
  %t670 = load ptr, ptr %t669, !tbaa !27
  %t671 = getelementptr ptr, ptr %t670, i64 1
  %t672 = load ptr, ptr %t671, !tbaa !39
  %t674 = load i32, ptr %l19
  %t675 = load ptr, ptr %l352, !tbaa !29
  %t676 = load %"compiler/source:Span", ptr %l353
  %t681 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v3, ptr %v3, ptr %t675, %"compiler/source:Span" %t676, ptr %t661, ptr %t666, ptr %t672, i32 %t674)
  store ptr %t681, ptr %l364
  br label %bb175
bb175:
  %t682 = load ptr, ptr %l364, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t682, ptr %rv
  br label %ret
bb176:
  %t684 = load ptr, ptr %l0, !tbaa !29
  store ptr %t684, ptr %l366, !tbaa !29
  %t685 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t685, ptr %l367
  %t686 = load ptr, ptr %l18, !tbaa !29
  %t688 = icmp eq ptr %t686, null
  br i1 %t688, label %bb177, label %bb178
bb177:
  call void @__olang_check_failed(ptr @olang_loc_612cb7a013386346_141d5cc8e3df5aaa)
  unreachable
bb178:
  br label %bb179
bb179:
  %t690 = load ptr, ptr %l18, !tbaa !29
  %t691 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t692 = load i32, ptr %l19
  %t693 = load ptr, ptr %l366, !tbaa !29
  %t694 = load %"compiler/source:Span", ptr %l367
  %t698 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v3, ptr %t693, %"compiler/source:Span" %t694, ptr %t690, { i64, ptr } %t691, i32 %t692)
  store ptr %t698, ptr %l373
  br label %bb180
bb180:
  %t699 = load ptr, ptr %l373, !tbaa !29
  store ptr %t699, ptr %l20, !tbaa !29
  %t700 = load ptr, ptr %l20, !tbaa !29
  %t702 = icmp eq ptr %t700, null
  br i1 %t702, label %bb181, label %bb182
bb181:
  %t704 = load ptr, ptr %l0, !tbaa !29
  %t705 = load %"compiler/source:Span", ptr %l1
  %t708 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t704, %"compiler/source:Span" %t705)
  store ptr %t708, ptr %l378
  br label %bb183
bb182:
  br label %bb184
bb183:
  %t709 = load ptr, ptr %l378, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t709, ptr %rv
  br label %ret
bb184:
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t712 = load %"compiler/source:Span", ptr %l1
  %t713 = load ptr, ptr %l20, !tbaa !29
  %t717 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t711, %"compiler/source:Span" %t712, ptr %t713)
  store ptr %t717, ptr %l383
  br label %bb185
bb185:
  %t718 = load ptr, ptr %l383, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t718, ptr %rv
  br label %ret
bb186:
  %t720 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t722 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t720, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t722, ptr %l386
  br label %bb187
bb187:
  %t723 = load i1, ptr %l386, !tbaa !21
  br i1 %t723, label %bb188, label %bb189
bb188:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = load i32, ptr %l7, !tbaa !23
  %t728 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t724, i32 %t725)
  store i1 %t728, ptr %l390
  br label %bb190
bb189:
  store i1 false, ptr %l387, !tbaa !21
  br label %bb191
bb190:
  %t729 = load i1, ptr %l390, !tbaa !21
  store i1 %t729, ptr %l387, !tbaa !21
  br label %bb191
bb191:
  %t730 = load i1, ptr %l387, !tbaa !21
  br i1 %t730, label %bb192, label %bb193
bb192:
  store %olang.scope zeroinitializer, ptr %s16
  %t731 = load ptr, ptr %l0, !tbaa !29
  store ptr %t731, ptr %l391, !tbaa !29
  %t732 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t732, ptr %l392
  %t733 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowNeedsType(ptr %s16)
  store %"compiler/msgs:Msg" %t733, ptr %l393
  br label %bb194
bb193:
  br label %bb198
bb194:
  %t734 = load ptr, ptr %l391, !tbaa !29
  %t735 = load %"compiler/source:Span", ptr %l392
  %t736 = load %"compiler/msgs:Msg", ptr %l393
  %t737 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t734, %"compiler/source:Span" %t735, %"compiler/msgs:Msg" %t736)
  store i64 %t737, ptr %l394
  br label %bb195
bb195:
  %t738 = load ptr, ptr %l0, !tbaa !29
  %t739 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t738, { i64, ptr } %t739)
  br label %bb196
bb196:
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t743 = load %"compiler/source:Span", ptr %l1
  %t746 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t742, %"compiler/source:Span" %t743)
  store ptr %t746, ptr %l399
  br label %bb197
bb197:
  %t747 = load ptr, ptr %l399, !tbaa !29
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t747, ptr %rv
  br label %ret
bb198:
  %t749 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t751 = call i32 @compiler_2fcheck_2ebitOp(ptr %v2, { i64, ptr } %t749)
  store i32 %t751, ptr %l402
  br label %bb199
bb199:
  %t752 = load i32, ptr %l402
  store i32 %t752, ptr %l21
  %t753 = load i32, ptr %l21
  %t755 = trunc i64 29 to i32
  %t756 = icmp eq i32 %t753, %t755
  %t758 = xor i1 %t756, true
  br i1 %t758, label %bb200, label %bb201
bb200:
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t762 = getelementptr %"compiler/check:Checker", ptr %t760, i32 0, i32 1
  %t763 = load ptr, ptr %t762, !tbaa !29
  %t765 = getelementptr %"compiler/generic:Program", ptr %t763, i32 0, i32 2
  %t766 = load i32, ptr %l8, !tbaa !23
  %t769 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t765, i32 %t766)
  store i1 %t769, ptr %l410
  br label %bb202
bb201:
  br label %bb274
bb202:
  %t770 = load i1, ptr %l410, !tbaa !21
  %t771 = xor i1 %t770, true
  br i1 %t771, label %bb203, label %bb204
bb203:
  store %olang.scope zeroinitializer, ptr %s18
  %t773 = load ptr, ptr %l0, !tbaa !29
  store ptr %t773, ptr %l412, !tbaa !29
  %t774 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t774, ptr %l413
  %t775 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t775, ptr %l414, !tbaa !27
  %t776 = load ptr, ptr %l0, !tbaa !29
  %t777 = load i32, ptr %l7, !tbaa !23
  %t780 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s18, ptr %t776, i32 %t777)
  store { i64, ptr } %t780, ptr %l417
  br label %bb205
bb204:
  br label %bb210
bb205:
  %t781 = load { i64, ptr }, ptr %l417, !tbaa !27
  %t782 = extractvalue { i64, ptr } %t781, 0
  %t783 = extractvalue { i64, ptr } %t781, 1
  %t784 = mul i64 %t782, 1
  %t785 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t784)
  call void @llvm.memcpy.p0.p0.i64(ptr %t785, ptr %t783, i64 %t784, i1 false)
  %t786 = insertvalue { i64, ptr } undef, i64 %t782, 0
  %t787 = insertvalue { i64, ptr } %t786, ptr %t785, 1
  %t788 = load { i64, ptr }, ptr %l414, !tbaa !27
  %t790 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBitOpNotInteger(ptr %v2, ptr %s18, ptr %s18, { i64, ptr } %t788, { i64, ptr } %t787)
  store %"compiler/msgs:Msg" %t790, ptr %l419
  br label %bb206
bb206:
  %t791 = load ptr, ptr %l412, !tbaa !29
  %t792 = load %"compiler/source:Span", ptr %l413
  %t793 = load %"compiler/msgs:Msg", ptr %l419
  %t794 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t791, %"compiler/source:Span" %t792, %"compiler/msgs:Msg" %t793)
  store i64 %t794, ptr %l420
  br label %bb207
bb207:
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t796 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t795, { i64, ptr } %t796)
  br label %bb208
bb208:
  %t799 = load ptr, ptr %l0, !tbaa !29
  %t800 = load %"compiler/source:Span", ptr %l1
  %t803 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t799, %"compiler/source:Span" %t800)
  store ptr %t803, ptr %l425
  br label %bb209
bb209:
  %t804 = load ptr, ptr %l425, !tbaa !29
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t804, ptr %rv
  br label %ret
bb210:
  %t806 = load i32, ptr %l21
  %t808 = trunc i64 36 to i32
  %t809 = icmp eq i32 %t806, %t808
  br i1 %t809, label %bb211, label %bb212
bb211:
  %t811 = load ptr, ptr %l0, !tbaa !29
  %t813 = getelementptr %"compiler/check:Checker", ptr %t811, i32 0, i32 1
  %t814 = load ptr, ptr %t813, !tbaa !29
  %t816 = getelementptr %"compiler/generic:Program", ptr %t814, i32 0, i32 2
  %t817 = load i32, ptr %l8, !tbaa !23
  %t820 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t816, i32 %t817)
  store i64 %t820, ptr %l434
  br label %bb213
bb212:
  store i1 false, ptr %l429, !tbaa !21
  br label %bb214
bb213:
  %t821 = load i64, ptr %l434, !tbaa !24
  %t822 = srem i64 %t821, 8
  %t824 = icmp ne i64 %t822, 0
  store i1 %t824, ptr %l429, !tbaa !21
  br label %bb214
bb214:
  %t826 = load i1, ptr %l429, !tbaa !21
  br i1 %t826, label %bb215, label %bb216
bb215:
  store %olang.scope zeroinitializer, ptr %s19
  %t827 = load ptr, ptr %l0, !tbaa !29
  store ptr %t827, ptr %l437, !tbaa !29
  %t828 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t828, ptr %l438
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t830 = load i32, ptr %l7, !tbaa !23
  %t833 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s19, ptr %t829, i32 %t830)
  store { i64, ptr } %t833, ptr %l441
  br label %bb217
bb216:
  br label %bb223
bb217:
  %t834 = load { i64, ptr }, ptr %l441, !tbaa !27
  %t835 = extractvalue { i64, ptr } %t834, 0
  %t836 = extractvalue { i64, ptr } %t834, 1
  %t837 = mul i64 %t835, 1
  %t838 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t837)
  call void @llvm.memcpy.p0.p0.i64(ptr %t838, ptr %t836, i64 %t837, i1 false)
  %t839 = insertvalue { i64, ptr } undef, i64 %t835, 0
  %t840 = insertvalue { i64, ptr } %t839, ptr %t838, 1
  store { i64, ptr } %t840, ptr %l442, !tbaa !27
  %t841 = load ptr, ptr %l0, !tbaa !29
  %t843 = getelementptr %"compiler/check:Checker", ptr %t841, i32 0, i32 1
  %t844 = load ptr, ptr %t843, !tbaa !29
  %t846 = getelementptr %"compiler/generic:Program", ptr %t844, i32 0, i32 2
  %t847 = load i32, ptr %l8, !tbaa !23
  %t850 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t846, i32 %t847)
  store i64 %t850, ptr %l447
  br label %bb218
bb218:
  %t851 = load { i64, ptr }, ptr %l442, !tbaa !27
  %t852 = load i64, ptr %l447, !tbaa !24
  %t853 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eByteSwapWidth(ptr %s19, ptr %s19, { i64, ptr } %t851, i64 %t852)
  store %"compiler/msgs:Msg" %t853, ptr %l448
  br label %bb219
bb219:
  %t854 = load ptr, ptr %l437, !tbaa !29
  %t855 = load %"compiler/source:Span", ptr %l438
  %t856 = load %"compiler/msgs:Msg", ptr %l448
  %t857 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t854, %"compiler/source:Span" %t855, %"compiler/msgs:Msg" %t856)
  store i64 %t857, ptr %l449
  br label %bb220
bb220:
  %t858 = load ptr, ptr %l0, !tbaa !29
  %t859 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t858, { i64, ptr } %t859)
  br label %bb221
bb221:
  %t862 = load ptr, ptr %l0, !tbaa !29
  %t863 = load %"compiler/source:Span", ptr %l1
  %t866 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t862, %"compiler/source:Span" %t863)
  store ptr %t866, ptr %l454
  br label %bb222
bb222:
  %t867 = load ptr, ptr %l454, !tbaa !29
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t867, ptr %rv
  br label %ret
bb223:
  %t869 = load i32, ptr %l21
  %t871 = trunc i64 34 to i32
  %t872 = icmp eq i32 %t869, %t871
  br i1 %t872, label %bb224, label %bb225
bb224:
  store i1 true, ptr %l458, !tbaa !21
  br label %bb226
bb225:
  %t874 = load i32, ptr %l21
  %t876 = trunc i64 35 to i32
  %t877 = icmp eq i32 %t874, %t876
  store i1 %t877, ptr %l458, !tbaa !21
  br label %bb226
bb226:
  %t879 = load i1, ptr %l458, !tbaa !21
  store i1 %t879, ptr %l22, !tbaa !21
  %t880 = load i1, ptr %l22, !tbaa !21
  br i1 %t880, label %bb227, label %bb228
bb227:
  store i64 1, ptr %l462, !tbaa !24
  br label %bb229
bb228:
  store i64 0, ptr %l462, !tbaa !24
  br label %bb229
bb229:
  %t882 = load i64, ptr %l462, !tbaa !24
  store i64 %t882, ptr %l23, !tbaa !24
  %t883 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t885 = extractvalue { i64, ptr } %t883, 0
  %t886 = load i64, ptr %l23, !tbaa !24
  %t889 = icmp ne i64 %t885, %t886
  br i1 %t889, label %bb230, label %bb231
bb230:
  store %olang.scope zeroinitializer, ptr %s20
  %t891 = load ptr, ptr %l0, !tbaa !29
  store ptr %t891, ptr %l467, !tbaa !29
  %t892 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t892, ptr %l468
  %t893 = load i64, ptr %l23, !tbaa !24
  store i64 %t893, ptr %l469, !tbaa !24
  %t894 = load i64, ptr %l23, !tbaa !24
  %t896 = icmp eq i64 %t894, 1
  br i1 %t896, label %bb232, label %bb233
bb231:
  br label %bb239
bb232:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l472, !tbaa !27
  br label %bb234
bb233:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l472, !tbaa !27
  br label %bb234
bb234:
  %t898 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t900 = extractvalue { i64, ptr } %t898, 0
  %t901 = load i64, ptr %l469, !tbaa !24
  %t902 = load { i64, ptr }, ptr %l472, !tbaa !27
  %t904 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s20, ptr %s20, i64 %t901, { i64, ptr } %t902, i64 %t900)
  store %"compiler/msgs:Msg" %t904, ptr %l475
  br label %bb235
bb235:
  %t905 = load ptr, ptr %l467, !tbaa !29
  %t906 = load %"compiler/source:Span", ptr %l468
  %t907 = load %"compiler/msgs:Msg", ptr %l475
  %t908 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s20, ptr %t905, %"compiler/source:Span" %t906, %"compiler/msgs:Msg" %t907)
  store i64 %t908, ptr %l476
  br label %bb236
bb236:
  %t909 = load ptr, ptr %l0, !tbaa !29
  %t910 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t909, { i64, ptr } %t910)
  br label %bb237
bb237:
  %t913 = load ptr, ptr %l0, !tbaa !29
  %t914 = load %"compiler/source:Span", ptr %l1
  %t917 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t913, %"compiler/source:Span" %t914)
  store ptr %t917, ptr %l481
  br label %bb238
bb238:
  %t918 = load ptr, ptr %l481, !tbaa !29
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t918, ptr %rv
  br label %ret
bb239:
  %t920 = load ptr, ptr %l0, !tbaa !29
  %t921 = load ptr, ptr %l4, !tbaa !29
  %t922 = load %"compiler/source:Span", ptr %l1
  %t926 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t920, ptr %t921, %"compiler/source:Span" %t922)
  store ptr %t926, ptr %l486
  br label %bb240
bb240:
  %t927 = load ptr, ptr %l486, !tbaa !29
  store ptr %t927, ptr %l24, !tbaa !29
  %t928 = load i1, ptr %l22, !tbaa !21
  %t930 = xor i1 %t928, true
  br i1 %t930, label %bb241, label %bb242
bb241:
  %t932 = load ptr, ptr %l0, !tbaa !29
  store ptr %t932, ptr %l489, !tbaa !29
  %t933 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t933, ptr %l490
  %t934 = load i32, ptr %l21
  %t936 = trunc i64 36 to i32
  %t937 = icmp eq i32 %t934, %t936
  br i1 %t937, label %bb243, label %bb244
bb242:
  br label %bb248
bb243:
  %t939 = load i32, ptr %l7, !tbaa !23
  store i32 %t939, ptr %l493, !tbaa !23
  br label %bb246
bb244:
  %t941 = load ptr, ptr %l0, !tbaa !29
  %t943 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t941)
  store i32 %t943, ptr %l496
  br label %bb245
bb245:
  %t944 = load i32, ptr %l496, !tbaa !23
  store i32 %t944, ptr %l493, !tbaa !23
  br label %bb246
bb246:
  %t945 = load i32, ptr %l21
  %t946 = load ptr, ptr %l24, !tbaa !29
  %t947 = load ptr, ptr %l489, !tbaa !29
  %t948 = load %"compiler/source:Span", ptr %l490
  %t949 = load i32, ptr %l493, !tbaa !23
  %t952 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t947, %"compiler/source:Span" %t948, i32 %t949, i32 %t945, ptr %t946, ptr null)
  store ptr %t952, ptr %l499
  br label %bb247
bb247:
  %t953 = load ptr, ptr %l499, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t953, ptr %rv
  br label %ret
bb248:
  %t955 = load ptr, ptr %l0, !tbaa !29
  store ptr %t955, ptr %l501, !tbaa !29
  %t956 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t956, ptr %l502, !tbaa !27
  %t957 = getelementptr { i64, ptr }, ptr %l502, i32 0, i32 1
  %t958 = load ptr, ptr %t957, !tbaa !27
  %t959 = getelementptr ptr, ptr %t958, i64 0
  %t960 = load ptr, ptr %t959, !tbaa !39
  store ptr %t960, ptr %l504, !tbaa !29
  %t962 = load ptr, ptr %l0, !tbaa !29
  %t964 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t962)
  store i32 %t964, ptr %l506
  br label %bb249
bb249:
  %t965 = load ptr, ptr %l501, !tbaa !29
  %t966 = load ptr, ptr %l504, !tbaa !29
  %t967 = load i32, ptr %l506, !tbaa !23
  %t968 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v3, ptr %t965, ptr %t966, i32 %t967)
  store ptr %t968, ptr %l507
  br label %bb250
bb250:
  %t969 = load ptr, ptr %l507, !tbaa !29
  store ptr %t969, ptr %l25, !tbaa !29
  %t970 = load ptr, ptr %l25, !tbaa !29
  %t973 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t970)
  store i32 %t973, ptr %l510
  br label %bb251
bb251:
  %t974 = load i32, ptr %l510, !tbaa !23
  store i32 %t974, ptr %l26, !tbaa !23
  %t975 = load i32, ptr %l26, !tbaa !23
  %t976 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t979 = icmp eq i32 %t975, %t976
  br i1 %t979, label %bb252, label %bb253
bb252:
  %t981 = load ptr, ptr %l0, !tbaa !29
  %t982 = load %"compiler/source:Span", ptr %l1
  %t985 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t981, %"compiler/source:Span" %t982)
  store ptr %t985, ptr %l516
  br label %bb254
bb253:
  br label %bb255
bb254:
  %t986 = load ptr, ptr %l516, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t986, ptr %rv
  br label %ret
bb255:
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t989 = load i32, ptr %l26, !tbaa !23
  %t992 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t988, i32 %t989)
  store i1 %t992, ptr %l520
  br label %bb256
bb256:
  %t993 = load i1, ptr %l520, !tbaa !21
  %t994 = xor i1 %t993, true
  br i1 %t994, label %bb257, label %bb258
bb257:
  store %olang.scope zeroinitializer, ptr %s23
  %t996 = load ptr, ptr %l0, !tbaa !29
  store ptr %t996, ptr %l522, !tbaa !29
  %t997 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t997, ptr %l523, !tbaa !27
  %t998 = getelementptr { i64, ptr }, ptr %l523, i32 0, i32 1
  %t999 = load ptr, ptr %t998, !tbaa !27
  %t1000 = getelementptr ptr, ptr %t999, i64 0
  %t1001 = load ptr, ptr %t1000, !tbaa !39
  %t1003 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t1001)
  store %"compiler/source:Span" %t1003, ptr %l525
  br label %bb259
bb258:
  br label %bb264
bb259:
  %t1004 = load ptr, ptr %l0, !tbaa !29
  %t1005 = load i32, ptr %l26, !tbaa !23
  %t1008 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s23, ptr %t1004, i32 %t1005)
  store { i64, ptr } %t1008, ptr %l528
  br label %bb260
bb260:
  %t1009 = load { i64, ptr }, ptr %l528, !tbaa !27
  %t1010 = extractvalue { i64, ptr } %t1009, 0
  %t1011 = extractvalue { i64, ptr } %t1009, 1
  %t1012 = mul i64 %t1010, 1
  %t1013 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t1012)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1013, ptr %t1011, i64 %t1012, i1 false)
  %t1014 = insertvalue { i64, ptr } undef, i64 %t1010, 0
  %t1015 = insertvalue { i64, ptr } %t1014, ptr %t1013, 1
  %t1017 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBitOpCount(ptr %s23, ptr %s23, { i64, ptr } %t1015)
  store %"compiler/msgs:Msg" %t1017, ptr %l530
  br label %bb261
bb261:
  %t1018 = load ptr, ptr %l522, !tbaa !29
  %t1019 = load %"compiler/source:Span", ptr %l525
  %t1020 = load %"compiler/msgs:Msg", ptr %l530
  %t1021 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s23, ptr %t1018, %"compiler/source:Span" %t1019, %"compiler/msgs:Msg" %t1020)
  store i64 %t1021, ptr %l531
  br label %bb262
bb262:
  %t1022 = load ptr, ptr %l0, !tbaa !29
  %t1023 = load %"compiler/source:Span", ptr %l1
  %t1026 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1022, %"compiler/source:Span" %t1023)
  store ptr %t1026, ptr %l534
  br label %bb263
bb263:
  %t1027 = load ptr, ptr %l534, !tbaa !29
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1027, ptr %rv
  br label %ret
bb264:
  %t1029 = load ptr, ptr %l0, !tbaa !29
  %t1030 = load i32, ptr %l26, !tbaa !23
  %t1033 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1029, i32 %t1030)
  store i32 %t1033, ptr %l538
  br label %bb265
bb265:
  %t1034 = load ptr, ptr %l0, !tbaa !29
  %t1036 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t1034)
  store i32 %t1036, ptr %l540
  br label %bb266
bb266:
  %t1037 = load i32, ptr %l538, !tbaa !23
  %t1038 = load i32, ptr %l540, !tbaa !23
  %t1039 = icmp ne i32 %t1037, %t1038
  br i1 %t1039, label %bb267, label %bb268
bb267:
  %t1041 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1041, ptr %l542, !tbaa !29
  %t1042 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t1042, ptr %l543, !tbaa !27
  %t1043 = getelementptr { i64, ptr }, ptr %l543, i32 0, i32 1
  %t1044 = load ptr, ptr %t1043, !tbaa !27
  %t1045 = getelementptr ptr, ptr %t1044, i64 0
  %t1046 = load ptr, ptr %t1045, !tbaa !39
  %t1048 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t1046)
  store %"compiler/source:Span" %t1048, ptr %l545
  br label %bb269
bb268:
  br label %bb272
bb269:
  %t1049 = load ptr, ptr %l0, !tbaa !29
  %t1051 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t1049)
  store i32 %t1051, ptr %l547
  br label %bb270
bb270:
  %t1052 = load ptr, ptr %l25, !tbaa !29
  %t1053 = load ptr, ptr %l542, !tbaa !29
  %t1054 = load %"compiler/source:Span", ptr %l545
  %t1055 = load i32, ptr %l547, !tbaa !23
  %t1058 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t1053, %"compiler/source:Span" %t1054, i32 %t1055, i32 20, ptr %t1052, ptr null)
  store ptr %t1058, ptr %l550
  br label %bb271
bb271:
  %t1059 = load ptr, ptr %l550, !tbaa !29
  store ptr %t1059, ptr %l25, !tbaa !29
  br label %bb272
bb272:
  %t1060 = load ptr, ptr %l0, !tbaa !29
  %t1061 = load %"compiler/source:Span", ptr %l1
  %t1062 = load i32, ptr %l7, !tbaa !23
  %t1063 = load i32, ptr %l21
  %t1064 = load ptr, ptr %l24, !tbaa !29
  %t1065 = load ptr, ptr %l25, !tbaa !29
  %t1073 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t1060, %"compiler/source:Span" %t1061, i32 %t1062, i32 %t1063, ptr %t1064, ptr %t1065)
  store ptr %t1073, ptr %l558
  br label %bb273
bb273:
  %t1074 = load ptr, ptr %l558, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1074, ptr %rv
  br label %ret
bb274:
  %t1076 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1078 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1076, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t1078, ptr %l561
  br label %bb275
bb275:
  %t1079 = load i1, ptr %l561, !tbaa !21
  br i1 %t1079, label %bb276, label %bb277
bb276:
  %t1080 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1082 = extractvalue { i64, ptr } %t1080, 0
  %t1084 = icmp eq i64 %t1082, 0
  store i1 %t1084, ptr %l562, !tbaa !21
  br label %bb278
bb277:
  store i1 false, ptr %l562, !tbaa !21
  br label %bb278
bb278:
  %t1086 = load i1, ptr %l562, !tbaa !21
  br i1 %t1086, label %bb279, label %bb280
bb279:
  %t1087 = load ptr, ptr %l0, !tbaa !29
  %t1088 = load i32, ptr %l7, !tbaa !23
  %t1091 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t1087, i32 %t1088)
  store i32 %t1091, ptr %l569
  br label %bb281
bb280:
  store i1 false, ptr %l566, !tbaa !21
  br label %bb282
bb281:
  %t1092 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1093 = load i32, ptr %l569, !tbaa !23
  %t1095 = icmp ne i32 %t1093, %t1092
  store i1 %t1095, ptr %l566, !tbaa !21
  br label %bb282
bb282:
  %t1097 = load i1, ptr %l566, !tbaa !21
  br i1 %t1097, label %bb283, label %bb284
bb283:
  %t1098 = load ptr, ptr %l0, !tbaa !29
  %t1100 = getelementptr %"compiler/check:Checker", ptr %t1098, i32 0, i32 1
  %t1101 = load ptr, ptr %t1100, !tbaa !29
  %t1103 = getelementptr %"compiler/generic:Program", ptr %t1101, i32 0, i32 0
  %t1104 = load ptr, ptr %t1103, !tbaa !29
  %t1106 = getelementptr %"compiler/load:Loader", ptr %t1104, i32 0, i32 5
  store ptr %t1106, ptr %l576, !tbaa !29
  %t1107 = load ptr, ptr %l0, !tbaa !29
  %t1109 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1107)
  store ptr %t1109, ptr %l578
  br label %bb285
bb284:
  store i1 false, ptr %l572, !tbaa !21
  br label %bb287
bb285:
  %t1110 = load ptr, ptr %l578, !tbaa !29
  %t1112 = getelementptr %"compiler/check:frame", ptr %t1110, i32 0, i32 1
  %t1113 = load i64, ptr %t1112, !tbaa !24
  %t1114 = load ptr, ptr %l576, !tbaa !29
  %t1116 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t1114, i64 %t1113)
  store ptr %t1116, ptr %l581
  br label %bb286
bb286:
  %t1117 = load ptr, ptr %l581, !tbaa !29
  %t1119 = getelementptr %"compiler/load:Module", ptr %t1117, i32 0, i32 3
  %t1120 = load i1, ptr %t1119, !tbaa !21
  store i1 %t1120, ptr %l572, !tbaa !21
  br label %bb287
bb287:
  %t1122 = load i1, ptr %l572, !tbaa !21
  br i1 %t1122, label %bb288, label %bb289
bb288:
  %t1123 = load ptr, ptr %l0, !tbaa !29
  %t1125 = getelementptr %"compiler/check:Checker", ptr %t1123, i32 0, i32 1
  %t1126 = load ptr, ptr %t1125, !tbaa !29
  %t1128 = getelementptr %"compiler/generic:Program", ptr %t1126, i32 0, i32 0
  %t1129 = load ptr, ptr %t1128, !tbaa !29
  %t1131 = getelementptr %"compiler/load:Loader", ptr %t1129, i32 0, i32 5
  store ptr %t1131, ptr %l587, !tbaa !29
  %t1132 = load ptr, ptr %l0, !tbaa !29
  %t1134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1132)
  store ptr %t1134, ptr %l589
  br label %bb290
bb289:
  br label %bb294
bb290:
  %t1135 = load ptr, ptr %l589, !tbaa !29
  %t1137 = getelementptr %"compiler/check:frame", ptr %t1135, i32 0, i32 1
  %t1138 = load i64, ptr %t1137, !tbaa !24
  %t1139 = load ptr, ptr %l587, !tbaa !29
  %t1141 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t1139, i64 %t1138)
  store ptr %t1141, ptr %l592
  br label %bb291
bb291:
  %t1142 = load ptr, ptr %l592, !tbaa !29
  %t1144 = getelementptr %"compiler/load:Module", ptr %t1142, i32 0, i32 5
  store i1 true, ptr %t1144, !tbaa !21
  %t1145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1145, ptr %l594, !tbaa !29
  %t1146 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1146, ptr %l595
  %t1147 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t1147, ptr %l596, !tbaa !23
  store i32 29, ptr %l597
  %t1148 = load ptr, ptr %l0, !tbaa !29
  %t1149 = load ptr, ptr %l4, !tbaa !29
  %t1150 = load %"compiler/source:Span", ptr %l1
  %t1154 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t1148, ptr %t1149, %"compiler/source:Span" %t1150)
  store ptr %t1154, ptr %l601
  br label %bb292
bb292:
  %t1155 = load ptr, ptr %l594, !tbaa !29
  %t1156 = load %"compiler/source:Span", ptr %l595
  %t1157 = load i32, ptr %l596, !tbaa !23
  %t1158 = load i32, ptr %l597
  %t1159 = load ptr, ptr %l601, !tbaa !29
  %t1160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t1155, %"compiler/source:Span" %t1156, i32 %t1157, i32 %t1158, ptr %t1159, ptr null)
  store ptr %t1160, ptr %l602
  br label %bb293
bb293:
  %t1161 = load ptr, ptr %l602, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1161, ptr %rv
  br label %ret
bb294:
  %t1163 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1165 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1163, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t1165, ptr %l605
  br label %bb295
bb295:
  %t1166 = load i1, ptr %l605, !tbaa !21
  br i1 %t1166, label %bb296, label %bb297
bb296:
  %t1167 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1169 = extractvalue { i64, ptr } %t1167, 0
  %t1171 = icmp eq i64 %t1169, 0
  store i1 %t1171, ptr %l606, !tbaa !21
  br label %bb298
bb297:
  store i1 false, ptr %l606, !tbaa !21
  br label %bb298
bb298:
  %t1173 = load i1, ptr %l606, !tbaa !21
  br i1 %t1173, label %bb299, label %bb300
bb299:
  %t1174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1174, ptr %l611, !tbaa !29
  %t1175 = load ptr, ptr %l0, !tbaa !29
  %t1177 = getelementptr %"compiler/check:Checker", ptr %t1175, i32 0, i32 1
  %t1178 = load ptr, ptr %t1177, !tbaa !29
  %t1180 = getelementptr %"compiler/generic:Program", ptr %t1178, i32 0, i32 2
  %t1181 = load i32, ptr %l7, !tbaa !23
  %t1184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1180, i32 %t1181)
  store i32 %t1184, ptr %l616
  br label %bb301
bb300:
  store i1 false, ptr %l610, !tbaa !21
  br label %bb303
bb301:
  %t1185 = load ptr, ptr %l611, !tbaa !29
  %t1186 = load i32, ptr %l616, !tbaa !23
  %t1187 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t1185, i32 %t1186)
  store i1 %t1187, ptr %l617
  br label %bb302
bb302:
  %t1188 = load i1, ptr %l617, !tbaa !21
  store i1 %t1188, ptr %l610, !tbaa !21
  br label %bb303
bb303:
  %t1189 = load i1, ptr %l610, !tbaa !21
  br i1 %t1189, label %bb304, label %bb305
bb304:
  %t1190 = load ptr, ptr %l0, !tbaa !29
  %t1191 = load i32, ptr %l7, !tbaa !23
  %t1194 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %t1190, i32 %t1191)
  store i1 %t1194, ptr %l620
  br label %bb306
bb305:
  br label %bb337
bb306:
  %t1195 = load i1, ptr %l620, !tbaa !21
  %t1196 = xor i1 %t1195, true
  br i1 %t1196, label %bb307, label %bb308
bb307:
  store %olang.scope zeroinitializer, ptr %s27
  %t1198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1198, ptr %l622, !tbaa !29
  %t1199 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1199, ptr %l623
  %t1200 = load ptr, ptr %l0, !tbaa !29
  %t1201 = load i32, ptr %l7, !tbaa !23
  %t1204 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s27, ptr %t1200, i32 %t1201)
  store { i64, ptr } %t1204, ptr %l626
  br label %bb309
bb308:
  br label %bb313
bb309:
  %t1205 = load { i64, ptr }, ptr %l626, !tbaa !27
  %t1206 = extractvalue { i64, ptr } %t1205, 0
  %t1207 = extractvalue { i64, ptr } %t1205, 1
  %t1208 = mul i64 %t1206, 1
  %t1209 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t1208)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1209, ptr %t1207, i64 %t1208, i1 false)
  %t1210 = insertvalue { i64, ptr } undef, i64 %t1206, 0
  %t1211 = insertvalue { i64, ptr } %t1210, ptr %t1209, 1
  %t1213 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNoDestructor(ptr %s27, ptr %s27, { i64, ptr } %t1211)
  store %"compiler/msgs:Msg" %t1213, ptr %l628
  br label %bb310
bb310:
  %t1214 = load ptr, ptr %l622, !tbaa !29
  %t1215 = load %"compiler/source:Span", ptr %l623
  %t1216 = load %"compiler/msgs:Msg", ptr %l628
  %t1217 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s27, ptr %t1214, %"compiler/source:Span" %t1215, %"compiler/msgs:Msg" %t1216)
  store i64 %t1217, ptr %l629
  br label %bb311
bb311:
  %t1218 = load ptr, ptr %l0, !tbaa !29
  %t1219 = load %"compiler/source:Span", ptr %l1
  %t1222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1218, %"compiler/source:Span" %t1219)
  store ptr %t1222, ptr %l632
  br label %bb312
bb312:
  %t1223 = load ptr, ptr %l632, !tbaa !29
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1223, ptr %rv
  br label %ret
bb313:
  %t1225 = load ptr, ptr %l4, !tbaa !29
  %t1227 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t1225)
  store ptr %t1227, ptr %l635
  br label %bb314
bb314:
  %t1228 = load ptr, ptr %l635, !tbaa !29
  store ptr %t1228, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t1229 = load ptr, ptr %l27, !tbaa !29
  %t1231 = icmp eq ptr %t1229, null
  %t1233 = xor i1 %t1231, true
  br i1 %t1233, label %bb315, label %bb316
bb315:
  %t1235 = load ptr, ptr %l27, !tbaa !29
  store ptr %t1235, ptr %l639, !tbaa !29
  store i1 false, ptr %l640, !tbaa !21
  %t1236 = load ptr, ptr %l639, !tbaa !29
  %t1237 = icmp ne ptr %t1236, null
  br i1 %t1237, label %bb317, label %bb318
bb316:
  br label %bb328
bb317:
  %t1239 = load ptr, ptr %l639, !tbaa !29
  %t1240 = load i64, ptr %t1239
  %t1242 = icmp eq i64 %t1240, 0
  store i1 %t1242, ptr %l640, !tbaa !21
  br label %bb318
bb318:
  %t1243 = load i1, ptr %l640, !tbaa !21
  br i1 %t1243, label %bb319, label %bb320
bb319:
  br label %bb321
bb320:
  br label %bb322
bb321:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb327
bb322:
  br i1 true, label %bb323, label %bb324
bb323:
  br label %bb325
bb324:
  br label %bb326
bb325:
  br label %bb327
bb326:
  call void @__olang_check_failed(ptr @olang_loc_8b3f489cc69a1bd4_cc212478c27e5838)
  unreachable
bb327:
  br label %bb328
bb328:
  %t1244 = load i1, ptr %l28, !tbaa !21
  %t1246 = xor i1 %t1244, true
  br i1 %t1246, label %bb329, label %bb330
bb329:
  store %olang.scope zeroinitializer, ptr %s31
  %t1248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1248, ptr %l645, !tbaa !29
  %t1249 = load ptr, ptr %l0, !tbaa !29
  %t1250 = load ptr, ptr %l3, !tbaa !29
  %t1253 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t1249, ptr %t1250)
  store %"compiler/source:Span" %t1253, ptr %l648
  br label %bb331
bb330:
  br label %bb335
bb331:
  %t1254 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNotLocal(ptr %s31)
  store %"compiler/msgs:Msg" %t1254, ptr %l649
  br label %bb332
bb332:
  %t1255 = load ptr, ptr %l645, !tbaa !29
  %t1256 = load %"compiler/source:Span", ptr %l648
  %t1257 = load %"compiler/msgs:Msg", ptr %l649
  %t1258 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s31, ptr %t1255, %"compiler/source:Span" %t1256, %"compiler/msgs:Msg" %t1257)
  store i64 %t1258, ptr %l650
  br label %bb333
bb333:
  %t1259 = load ptr, ptr %l0, !tbaa !29
  %t1260 = load %"compiler/source:Span", ptr %l1
  %t1263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1259, %"compiler/source:Span" %t1260)
  store ptr %t1263, ptr %l653
  br label %bb334
bb334:
  %t1264 = load ptr, ptr %l653, !tbaa !29
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1264, ptr %rv
  br label %ret
bb335:
  %t1266 = load ptr, ptr %l0, !tbaa !29
  %t1267 = load %"compiler/source:Span", ptr %l1
  %t1268 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1269 = load ptr, ptr %l4, !tbaa !29
  %t1275 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t1266, %"compiler/source:Span" %t1267, i32 %t1268, i32 30, ptr %t1269, ptr null)
  store ptr %t1275, ptr %l660
  br label %bb336
bb336:
  %t1276 = load ptr, ptr %l660, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1276, ptr %rv
  br label %ret
bb337:
  %t1278 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1280 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1278, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t1280, ptr %l663
  br label %bb338
bb338:
  %t1281 = load i1, ptr %l663, !tbaa !21
  br i1 %t1281, label %bb339, label %bb340
bb339:
  %t1282 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1284 = extractvalue { i64, ptr } %t1282, 0
  %t1286 = icmp eq i64 %t1284, 0
  store i1 %t1286, ptr %l664, !tbaa !21
  br label %bb341
bb340:
  store i1 false, ptr %l664, !tbaa !21
  br label %bb341
bb341:
  %t1288 = load i1, ptr %l664, !tbaa !21
  br i1 %t1288, label %bb342, label %bb343
bb342:
  %t1289 = load ptr, ptr %l0, !tbaa !29
  %t1291 = getelementptr %"compiler/check:Checker", ptr %t1289, i32 0, i32 1
  %t1292 = load ptr, ptr %t1291, !tbaa !29
  %t1294 = getelementptr %"compiler/generic:Program", ptr %t1292, i32 0, i32 0
  %t1295 = load ptr, ptr %t1294, !tbaa !29
  %t1297 = getelementptr %"compiler/load:Loader", ptr %t1295, i32 0, i32 5
  store ptr %t1297, ptr %l672, !tbaa !29
  %t1298 = load ptr, ptr %l0, !tbaa !29
  %t1300 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1298)
  store ptr %t1300, ptr %l674
  br label %bb344
bb343:
  store i1 false, ptr %l668, !tbaa !21
  br label %bb346
bb344:
  %t1301 = load ptr, ptr %l674, !tbaa !29
  %t1303 = getelementptr %"compiler/check:frame", ptr %t1301, i32 0, i32 1
  %t1304 = load i64, ptr %t1303, !tbaa !24
  %t1305 = load ptr, ptr %l672, !tbaa !29
  %t1307 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t1305, i64 %t1304)
  store ptr %t1307, ptr %l677
  br label %bb345
bb345:
  %t1308 = load ptr, ptr %l677, !tbaa !29
  %t1310 = getelementptr %"compiler/load:Module", ptr %t1308, i32 0, i32 3
  %t1311 = load i1, ptr %t1310, !tbaa !21
  store i1 %t1311, ptr %l668, !tbaa !21
  br label %bb346
bb346:
  %t1313 = load i1, ptr %l668, !tbaa !21
  br i1 %t1313, label %bb347, label %bb348
bb347:
  %t1314 = load ptr, ptr %l4, !tbaa !29
  %t1316 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t1314)
  store ptr %t1316, ptr %l681
  br label %bb349
bb348:
  br label %bb363
bb349:
  %t1317 = load ptr, ptr %l681, !tbaa !29
  store ptr %t1317, ptr %l29, !tbaa !29
  %t1318 = load ptr, ptr %l29, !tbaa !29
  %t1320 = icmp eq ptr %t1318, null
  br i1 %t1320, label %bb350, label %bb351
bb350:
  store i1 true, ptr %l684, !tbaa !21
  br label %bb353
bb351:
  %t1322 = load ptr, ptr %l0, !tbaa !29
  %t1323 = load ptr, ptr %l29, !tbaa !29
  %t1326 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v0, ptr %t1322, ptr %t1323)
  store i1 %t1326, ptr %l687
  br label %bb352
bb352:
  %t1327 = load i1, ptr %l687, !tbaa !21
  %t1328 = xor i1 %t1327, true
  store i1 %t1328, ptr %l684, !tbaa !21
  br label %bb353
bb353:
  %t1330 = load i1, ptr %l684, !tbaa !21
  br i1 %t1330, label %bb354, label %bb355
bb354:
  store %olang.scope zeroinitializer, ptr %s33
  %t1331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1331, ptr %l689, !tbaa !29
  %t1332 = load ptr, ptr %l0, !tbaa !29
  %t1333 = load ptr, ptr %l3, !tbaa !29
  %t1336 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t1332, ptr %t1333)
  store %"compiler/source:Span" %t1336, ptr %l692
  br label %bb356
bb355:
  br label %bb360
bb356:
  %t1337 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVacateNotPlace(ptr %s33)
  store %"compiler/msgs:Msg" %t1337, ptr %l693
  br label %bb357
bb357:
  %t1338 = load ptr, ptr %l689, !tbaa !29
  %t1339 = load %"compiler/source:Span", ptr %l692
  %t1340 = load %"compiler/msgs:Msg", ptr %l693
  %t1341 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s33, ptr %t1338, %"compiler/source:Span" %t1339, %"compiler/msgs:Msg" %t1340)
  store i64 %t1341, ptr %l694
  br label %bb358
bb358:
  %t1342 = load ptr, ptr %l0, !tbaa !29
  %t1343 = load %"compiler/source:Span", ptr %l1
  %t1346 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1342, %"compiler/source:Span" %t1343)
  store ptr %t1346, ptr %l697
  br label %bb359
bb359:
  %t1347 = load ptr, ptr %l697, !tbaa !29
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1347, ptr %rv
  br label %ret
bb360:
  %t1349 = load ptr, ptr %l0, !tbaa !29
  %t1350 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v0, ptr %t1349, ptr %t1350)
  br label %bb361
bb361:
  %t1353 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1353, ptr %l701
  %t1354 = load ptr, ptr %l29, !tbaa !29
  %t1356 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t1354)
  store i32 %t1356, ptr %l703
  br label %bb362
bb362:
  %t1357 = load ptr, ptr %l29, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t1358
  %t1359 = getelementptr { i64, [5 x i64] }, ptr %t1358, i32 0, i32 0
  store i64 4, ptr %t1359
  %t1360 = load %"compiler/source:Span", ptr %l701
  %t1361 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1360, 0
  %t1362 = load i32, ptr %l703, !tbaa !23
  %t1363 = insertvalue { %"compiler/source:Span", i32, ptr } %t1361, i32 %t1362, 1
  %t1365 = insertvalue { %"compiler/source:Span", i32, ptr } %t1363, ptr %t1357, 2
  %t1366 = getelementptr { i64, [5 x i64] }, ptr %t1358, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1365, ptr %t1366
  %t1367 = load { i64, [5 x i64] }, ptr %t1358
  %t1369 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1367, ptr %t1369
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1369, ptr %rv
  br label %ret
bb363:
  %t1371 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1373 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t1371, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t1373, ptr %l708
  br label %bb364
bb364:
  %t1374 = load i1, ptr %l708, !tbaa !21
  br i1 %t1374, label %bb365, label %bb366
bb365:
  store %olang.scope zeroinitializer, ptr %s34
  store i32 24, ptr %l30
  store i64 0, ptr %l31, !tbaa !24
  %t1376 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1378 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s34, { i64, ptr } %t1376, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t1378, ptr %l711
  br label %bb367
bb366:
  br label %bb449
bb367:
  %t1379 = load i1, ptr %l711, !tbaa !21
  br i1 %t1379, label %bb368, label %bb369
bb368:
  store i32 25, ptr %l30
  store i64 1, ptr %l31, !tbaa !24
  br label %bb386
bb369:
  store %olang.scope zeroinitializer, ptr %s36
  %t1381 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1383 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s36, { i64, ptr } %t1381, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t1383, ptr %l714
  br label %bb370
bb370:
  %t1384 = load i1, ptr %l714, !tbaa !21
  br i1 %t1384, label %bb371, label %bb372
bb371:
  store i32 26, ptr %l30
  store i64 1, ptr %l31, !tbaa !24
  br label %bb385
bb372:
  store %olang.scope zeroinitializer, ptr %s38
  %t1386 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1388 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s38, { i64, ptr } %t1386, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t1388, ptr %l717
  br label %bb373
bb373:
  %t1389 = load i1, ptr %l717, !tbaa !21
  br i1 %t1389, label %bb374, label %bb375
bb374:
  store i32 27, ptr %l30
  store i64 1, ptr %l31, !tbaa !24
  br label %bb384
bb375:
  store %olang.scope zeroinitializer, ptr %s40
  %t1391 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1393 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s40, { i64, ptr } %t1391, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t1393, ptr %l720
  br label %bb376
bb376:
  %t1394 = load i1, ptr %l720, !tbaa !21
  br i1 %t1394, label %bb377, label %bb378
bb377:
  store i32 28, ptr %l30
  store i64 2, ptr %l31, !tbaa !24
  br label %bb383
bb378:
  store %olang.scope zeroinitializer, ptr %s42
  %t1396 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1398 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s42, { i64, ptr } %t1396, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t1398, ptr %l723
  br label %bb379
bb379:
  %t1399 = load i1, ptr %l723, !tbaa !21
  %t1400 = xor i1 %t1399, true
  br i1 %t1400, label %bb380, label %bb381
bb380:
  call void @__olang_scope_close(ptr %s42)
  call void @__olang_scope_close(ptr %s40)
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s36)
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb381:
  br label %bb382
bb382:
  call void @__olang_scope_close(ptr %s42)
  br label %bb383
bb383:
  call void @__olang_scope_close(ptr %s40)
  br label %bb384
bb384:
  call void @__olang_scope_close(ptr %s38)
  br label %bb385
bb385:
  call void @__olang_scope_close(ptr %s36)
  br label %bb386
bb386:
  %t1403 = load ptr, ptr %l0, !tbaa !29
  %t1405 = getelementptr %"compiler/check:Checker", ptr %t1403, i32 0, i32 1
  %t1406 = load ptr, ptr %t1405, !tbaa !29
  %t1408 = getelementptr %"compiler/generic:Program", ptr %t1406, i32 0, i32 2
  %t1409 = load i32, ptr %l8, !tbaa !23
  %t1412 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t1408, i32 %t1409)
  store i1 %t1412, ptr %l730
  br label %bb387
bb387:
  %t1413 = load i1, ptr %l730, !tbaa !21
  %t1414 = xor i1 %t1413, true
  br i1 %t1414, label %bb388, label %bb389
bb388:
  store %olang.scope zeroinitializer, ptr %s44
  %t1416 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1416, ptr %l732, !tbaa !29
  %t1417 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1417, ptr %l733
  %t1418 = load ptr, ptr %l0, !tbaa !29
  %t1419 = load i32, ptr %l7, !tbaa !23
  %t1422 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s44, ptr %t1418, i32 %t1419)
  store { i64, ptr } %t1422, ptr %l736
  br label %bb390
bb389:
  br label %bb394
bb390:
  %t1423 = load { i64, ptr }, ptr %l736, !tbaa !27
  %t1424 = extractvalue { i64, ptr } %t1423, 0
  %t1425 = extractvalue { i64, ptr } %t1423, 1
  %t1426 = mul i64 %t1424, 1
  %t1427 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1426)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1427, ptr %t1425, i64 %t1426, i1 false)
  %t1428 = insertvalue { i64, ptr } undef, i64 %t1424, 0
  %t1429 = insertvalue { i64, ptr } %t1428, ptr %t1427, 1
  %t1431 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotInteger(ptr %s44, ptr %s44, { i64, ptr } %t1429)
  store %"compiler/msgs:Msg" %t1431, ptr %l738
  br label %bb391
bb391:
  %t1432 = load ptr, ptr %l732, !tbaa !29
  %t1433 = load %"compiler/source:Span", ptr %l733
  %t1434 = load %"compiler/msgs:Msg", ptr %l738
  %t1435 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s44, ptr %t1432, %"compiler/source:Span" %t1433, %"compiler/msgs:Msg" %t1434)
  store i64 %t1435, ptr %l739
  br label %bb392
bb392:
  %t1436 = load ptr, ptr %l0, !tbaa !29
  %t1437 = load %"compiler/source:Span", ptr %l1
  %t1440 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1436, %"compiler/source:Span" %t1437)
  store ptr %t1440, ptr %l742
  br label %bb393
bb393:
  %t1441 = load ptr, ptr %l742, !tbaa !29
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1441, ptr %rv
  br label %ret
bb394:
  %t1443 = load i32, ptr %l8, !tbaa !23
  %t1445 = icmp sgt i32 %t1443, 14
  br i1 %t1445, label %bb395, label %bb396
bb395:
  store %olang.scope zeroinitializer, ptr %s45
  %t1447 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1447, ptr %l746, !tbaa !29
  %t1448 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1448, ptr %l747
  %t1449 = load ptr, ptr %l0, !tbaa !29
  %t1450 = load i32, ptr %l7, !tbaa !23
  %t1453 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s45, ptr %t1449, i32 %t1450)
  store { i64, ptr } %t1453, ptr %l750
  br label %bb397
bb396:
  br label %bb401
bb397:
  %t1454 = load { i64, ptr }, ptr %l750, !tbaa !27
  %t1455 = extractvalue { i64, ptr } %t1454, 0
  %t1456 = extractvalue { i64, ptr } %t1454, 1
  %t1457 = mul i64 %t1455, 1
  %t1458 = call ptr @__olang_scope_alloc(ptr %s45, i64 %t1457)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1458, ptr %t1456, i64 %t1457, i1 false)
  %t1459 = insertvalue { i64, ptr } undef, i64 %t1455, 0
  %t1460 = insertvalue { i64, ptr } %t1459, ptr %t1458, 1
  %t1462 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicWidth(ptr %s45, ptr %s45, { i64, ptr } %t1460)
  store %"compiler/msgs:Msg" %t1462, ptr %l752
  br label %bb398
bb398:
  %t1463 = load ptr, ptr %l746, !tbaa !29
  %t1464 = load %"compiler/source:Span", ptr %l747
  %t1465 = load %"compiler/msgs:Msg", ptr %l752
  %t1466 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s45, ptr %t1463, %"compiler/source:Span" %t1464, %"compiler/msgs:Msg" %t1465)
  store i64 %t1466, ptr %l753
  br label %bb399
bb399:
  %t1467 = load ptr, ptr %l0, !tbaa !29
  %t1468 = load %"compiler/source:Span", ptr %l1
  %t1471 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1467, %"compiler/source:Span" %t1468)
  store ptr %t1471, ptr %l756
  br label %bb400
bb400:
  %t1472 = load ptr, ptr %l756, !tbaa !29
  call void @__olang_scope_close(ptr %s45)
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1472, ptr %rv
  br label %ret
bb401:
  %t1474 = load ptr, ptr %l4, !tbaa !29
  %t1476 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t1474)
  store ptr %t1476, ptr %l759
  br label %bb402
bb402:
  %t1477 = load ptr, ptr %l759, !tbaa !29
  store ptr %t1477, ptr %l32, !tbaa !29
  %t1478 = load ptr, ptr %l32, !tbaa !29
  %t1480 = icmp eq ptr %t1478, null
  br i1 %t1480, label %bb403, label %bb404
bb403:
  store %olang.scope zeroinitializer, ptr %s46
  %t1482 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1482, ptr %l762, !tbaa !29
  %t1483 = load ptr, ptr %l0, !tbaa !29
  %t1484 = load ptr, ptr %l3, !tbaa !29
  %t1487 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t1483, ptr %t1484)
  store %"compiler/source:Span" %t1487, ptr %l765
  br label %bb405
bb404:
  br label %bb409
bb405:
  %t1488 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotPlace(ptr %s46)
  store %"compiler/msgs:Msg" %t1488, ptr %l766
  br label %bb406
bb406:
  %t1489 = load ptr, ptr %l762, !tbaa !29
  %t1490 = load %"compiler/source:Span", ptr %l765
  %t1491 = load %"compiler/msgs:Msg", ptr %l766
  %t1492 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s46, ptr %t1489, %"compiler/source:Span" %t1490, %"compiler/msgs:Msg" %t1491)
  store i64 %t1492, ptr %l767
  br label %bb407
bb407:
  %t1493 = load ptr, ptr %l0, !tbaa !29
  %t1494 = load %"compiler/source:Span", ptr %l1
  %t1497 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1493, %"compiler/source:Span" %t1494)
  store ptr %t1497, ptr %l770
  br label %bb408
bb408:
  %t1498 = load ptr, ptr %l770, !tbaa !29
  call void @__olang_scope_close(ptr %s46)
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1498, ptr %rv
  br label %ret
bb409:
  %t1500 = load i32, ptr %l30
  %t1502 = trunc i64 24 to i32
  %t1503 = icmp eq i32 %t1500, %t1502
  %t1505 = xor i1 %t1503, true
  br i1 %t1505, label %bb410, label %bb411
bb410:
  %t1507 = load ptr, ptr %l0, !tbaa !29
  %t1508 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v0, ptr %t1507, ptr %t1508)
  br label %bb412
bb411:
  br label %bb413
bb412:
  br label %bb413
bb413:
  %t1511 = load i32, ptr %l30
  %t1513 = trunc i64 24 to i32
  %t1514 = icmp eq i32 %t1511, %t1513
  %t1516 = xor i1 %t1514, true
  br i1 %t1516, label %bb414, label %bb415
bb414:
  %t1518 = load ptr, ptr %l0, !tbaa !29
  %t1519 = load ptr, ptr %l32, !tbaa !29
  %t1522 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v0, ptr %t1518, ptr %t1519)
  store i1 %t1522, ptr %l783
  br label %bb416
bb415:
  store i1 false, ptr %l780, !tbaa !21
  br label %bb417
bb416:
  %t1523 = load i1, ptr %l783, !tbaa !21
  %t1524 = xor i1 %t1523, true
  store i1 %t1524, ptr %l780, !tbaa !21
  br label %bb417
bb417:
  %t1526 = load i1, ptr %l780, !tbaa !21
  br i1 %t1526, label %bb418, label %bb419
bb418:
  store %olang.scope zeroinitializer, ptr %s48
  %t1527 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1527, ptr %l785, !tbaa !29
  %t1528 = load ptr, ptr %l0, !tbaa !29
  %t1529 = load ptr, ptr %l3, !tbaa !29
  %t1532 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t1528, ptr %t1529)
  store %"compiler/source:Span" %t1532, ptr %l788
  br label %bb420
bb419:
  br label %bb424
bb420:
  %t1533 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotWritable(ptr %s48)
  store %"compiler/msgs:Msg" %t1533, ptr %l789
  br label %bb421
bb421:
  %t1534 = load ptr, ptr %l785, !tbaa !29
  %t1535 = load %"compiler/source:Span", ptr %l788
  %t1536 = load %"compiler/msgs:Msg", ptr %l789
  %t1537 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s48, ptr %t1534, %"compiler/source:Span" %t1535, %"compiler/msgs:Msg" %t1536)
  store i64 %t1537, ptr %l790
  br label %bb422
bb422:
  %t1538 = load ptr, ptr %l0, !tbaa !29
  %t1539 = load %"compiler/source:Span", ptr %l1
  %t1542 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1538, %"compiler/source:Span" %t1539)
  store ptr %t1542, ptr %l793
  br label %bb423
bb423:
  %t1543 = load ptr, ptr %l793, !tbaa !29
  call void @__olang_scope_close(ptr %s48)
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1543, ptr %rv
  br label %ret
bb424:
  %t1545 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1547 = extractvalue { i64, ptr } %t1545, 0
  %t1548 = load i64, ptr %l31, !tbaa !24
  %t1551 = icmp ne i64 %t1547, %t1548
  br i1 %t1551, label %bb425, label %bb426
bb425:
  store %olang.scope zeroinitializer, ptr %s49
  %t1553 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1553, ptr %l799, !tbaa !29
  %t1554 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1554, ptr %l800
  %t1555 = load i64, ptr %l31, !tbaa !24
  store i64 %t1555, ptr %l801, !tbaa !24
  %t1556 = load i64, ptr %l31, !tbaa !24
  %t1558 = icmp eq i64 %t1556, 1
  br i1 %t1558, label %bb427, label %bb428
bb426:
  br label %bb433
bb427:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l804, !tbaa !27
  br label %bb429
bb428:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l804, !tbaa !27
  br label %bb429
bb429:
  %t1560 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1562 = extractvalue { i64, ptr } %t1560, 0
  %t1563 = load i64, ptr %l801, !tbaa !24
  %t1564 = load { i64, ptr }, ptr %l804, !tbaa !27
  %t1566 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s49, ptr %s49, i64 %t1563, { i64, ptr } %t1564, i64 %t1562)
  store %"compiler/msgs:Msg" %t1566, ptr %l807
  br label %bb430
bb430:
  %t1567 = load ptr, ptr %l799, !tbaa !29
  %t1568 = load %"compiler/source:Span", ptr %l800
  %t1569 = load %"compiler/msgs:Msg", ptr %l807
  %t1570 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s49, ptr %t1567, %"compiler/source:Span" %t1568, %"compiler/msgs:Msg" %t1569)
  store i64 %t1570, ptr %l808
  br label %bb431
bb431:
  %t1571 = load ptr, ptr %l0, !tbaa !29
  %t1572 = load %"compiler/source:Span", ptr %l1
  %t1575 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1571, %"compiler/source:Span" %t1572)
  store ptr %t1575, ptr %l811
  br label %bb432
bb432:
  %t1576 = load ptr, ptr %l811, !tbaa !29
  call void @__olang_scope_close(ptr %s49)
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1576, ptr %rv
  br label %ret
bb433:
  %t1578 = load ptr, ptr %l0, !tbaa !29
  %t1580 = getelementptr %"compiler/check:Checker", ptr %t1578, i32 0, i32 32
  %t1582 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t1580)
  store i64 %t1582, ptr %l815
  br label %bb434
bb434:
  %t1583 = load i64, ptr %l815, !tbaa !24
  store i64 %t1583, ptr %l33, !tbaa !24
  %t1584 = load ptr, ptr %l0, !tbaa !29
  %t1586 = getelementptr %"compiler/check:Checker", ptr %t1584, i32 0, i32 32
  store ptr %t1586, ptr %l817, !tbaa !29
  %t1587 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1587, ptr %l818
  %t1588 = load ptr, ptr %l0, !tbaa !29
  %t1590 = getelementptr %"compiler/check:Checker", ptr %t1588, i32 0, i32 1
  %t1591 = load ptr, ptr %t1590, !tbaa !29
  %t1593 = getelementptr %"compiler/generic:Program", ptr %t1591, i32 0, i32 2
  %t1594 = load i32, ptr %l7, !tbaa !23
  %t1595 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1599 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1593, i32 %t1594, i64 %t1595)
  store i32 %t1599, ptr %l824
  br label %bb435
bb435:
  %t1600 = load ptr, ptr %l32, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t1601
  %t1602 = getelementptr { i64, [5 x i64] }, ptr %t1601, i32 0, i32 0
  store i64 3, ptr %t1602
  %t1603 = load %"compiler/source:Span", ptr %l818
  %t1604 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1603, 0
  %t1605 = load i32, ptr %l824, !tbaa !23
  %t1606 = insertvalue { %"compiler/source:Span", i32, ptr } %t1604, i32 %t1605, 1
  %t1608 = insertvalue { %"compiler/source:Span", i32, ptr } %t1606, ptr %t1600, 2
  %t1609 = getelementptr { i64, [5 x i64] }, ptr %t1601, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1608, ptr %t1609
  %t1610 = load { i64, [5 x i64] }, ptr %t1601
  %t1612 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1610, ptr %t1612
  %t1613 = load ptr, ptr %l817, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t1613, ptr %t1612)
  br label %bb436
bb436:
  %t1615 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t1615, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t1617 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1619 = extractvalue { i64, ptr } %t1617, 0
  store i64 %t1619, ptr %l36, !tbaa !24
  br label %bb437
bb437:
  store %olang.scope zeroinitializer, ptr %s51
  %t1621 = load i64, ptr %l35, !tbaa !24
  %t1622 = load i64, ptr %l36, !tbaa !24
  %t1625 = icmp slt i64 %t1621, %t1622
  %t1627 = xor i1 %t1625, true
  br i1 %t1627, label %bb438, label %bb439
bb438:
  call void @__olang_scope_close(ptr %s51)
  br label %bb444
bb439:
  br label %bb440
bb440:
  %t1629 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t1629, ptr %l835, !tbaa !27
  %t1630 = load i64, ptr %l35, !tbaa !24
  %t1632 = getelementptr { i64, ptr }, ptr %l835, i32 0, i32 1
  %t1633 = load ptr, ptr %t1632, !tbaa !27
  %t1634 = getelementptr ptr, ptr %t1633, i64 %t1630
  %t1635 = load ptr, ptr %t1634, !tbaa !39
  %t1637 = load ptr, ptr %l0, !tbaa !29
  %t1639 = getelementptr %"compiler/check:Checker", ptr %t1637, i32 0, i32 32
  store ptr %t1639, ptr %l839, !tbaa !29
  %t1640 = load ptr, ptr %l0, !tbaa !29
  %t1642 = load i32, ptr %l7, !tbaa !23
  %t1646 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v3, ptr %t1640, ptr %t1635, i32 %t1642)
  store ptr %t1646, ptr %l843
  br label %bb441
bb441:
  %t1647 = load ptr, ptr %l839, !tbaa !29
  %t1648 = load ptr, ptr %l843, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t1647, ptr %t1648)
  br label %bb442
bb442:
  call void @__olang_scope_close(ptr %s51)
  br label %bb443
bb443:
  %t1649 = load i64, ptr %l35, !tbaa !24
  %t1651 = add i64 %t1649, 1
  store i64 %t1651, ptr %l35, !tbaa !24
  br label %bb437
bb444:
  %t1653 = load i32, ptr %l30
  %t1655 = trunc i64 25 to i32
  %t1656 = icmp eq i32 %t1653, %t1655
  br i1 %t1656, label %bb445, label %bb446
bb445:
  %t1658 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t1658, ptr %l848, !tbaa !23
  br label %bb447
bb446:
  %t1660 = load i32, ptr %l7, !tbaa !23
  store i32 %t1660, ptr %l848, !tbaa !23
  br label %bb447
bb447:
  %t1662 = load i32, ptr %l848, !tbaa !23
  %t1663 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1663, ptr %l851
  store i32 %t1662, ptr %l852, !tbaa !23
  %t1665 = load i32, ptr %l30
  store i32 %t1665, ptr %l853
  store i32 0, ptr %l854
  %t1666 = load ptr, ptr %l0, !tbaa !29
  %t1668 = getelementptr %"compiler/check:Checker", ptr %t1666, i32 0, i32 32
  %t1669 = load i64, ptr %l33, !tbaa !24
  %t1672 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t1668, i64 %t1669)
  store { i64, ptr } %t1672, ptr %l858
  br label %bb448
bb448:
  store { i64, [5 x i64] } zeroinitializer, ptr %t1673
  %t1674 = getelementptr { i64, [5 x i64] }, ptr %t1673, i32 0, i32 0
  store i64 9, ptr %t1674
  %t1675 = load %"compiler/source:Span", ptr %l851
  %t1676 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t1675, 0
  %t1677 = load i32, ptr %l852, !tbaa !23
  %t1678 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t1676, i32 %t1677, 1
  %t1679 = load i32, ptr %l853
  %t1680 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t1678, i32 %t1679, 2
  %t1681 = load i32, ptr %l854
  %t1682 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t1680, i32 %t1681, 3
  %t1683 = load { i64, ptr }, ptr %l858, !tbaa !27
  %t1684 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t1682, { i64, ptr } %t1683, 4
  %t1685 = getelementptr { i64, [5 x i64] }, ptr %t1673, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t1684, ptr %t1685
  %t1686 = load { i64, [5 x i64] }, ptr %t1673
  %t1688 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1686, ptr %t1688
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1688, ptr %rv
  br label %ret
bb449:
  %t1690 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1692 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1690, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t1692, ptr %l862
  br label %bb450
bb450:
  %t1693 = load i1, ptr %l862, !tbaa !21
  br i1 %t1693, label %bb451, label %bb452
bb451:
  %t1694 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1696 = extractvalue { i64, ptr } %t1694, 0
  %t1698 = icmp eq i64 %t1696, 0
  store i1 %t1698, ptr %l863, !tbaa !21
  br label %bb453
bb452:
  store i1 false, ptr %l863, !tbaa !21
  br label %bb453
bb453:
  %t1700 = load i1, ptr %l863, !tbaa !21
  br i1 %t1700, label %bb454, label %bb455
bb454:
  store %olang.scope zeroinitializer, ptr %s53
  %t1701 = load ptr, ptr %l0, !tbaa !29
  %t1702 = load %"compiler/source:Span", ptr %l2
  %t1705 = getelementptr %"compiler/check:Checker", ptr %t1701, i32 0, i32 42
  store %"compiler/source:Span" %t1702, ptr %t1705
  %t1706 = load ptr, ptr %l0, !tbaa !29
  %t1707 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartHashes(ptr %v0, ptr %t1706, i32 %t1707, i64 0)
  br label %bb456
bb455:
  br label %bb462
bb456:
  %t1710 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1710, ptr %l871, !tbaa !29
  %t1711 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s53, i32 -1, i32 -1)
  store %"compiler/source:Span" %t1711, ptr %l872
  br label %bb457
bb457:
  %t1712 = load %"compiler/source:Span", ptr %l872
  %t1713 = load ptr, ptr %l871, !tbaa !29
  %t1714 = getelementptr %"compiler/check:Checker", ptr %t1713, i32 0, i32 42
  store %"compiler/source:Span" %t1712, ptr %t1714
  %t1715 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1715, ptr %l873, !tbaa !29
  %t1716 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1716, ptr %l874
  %t1717 = load ptr, ptr %l0, !tbaa !29
  %t1719 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t1717)
  store i32 %t1719, ptr %l876
  br label %bb458
bb458:
  %t1720 = load i32, ptr %l7, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t1721
  %t1722 = getelementptr { i64, [3 x i64] }, ptr %t1721, i32 0, i32 0
  store i64 4, ptr %t1722
  %t1724 = insertvalue { i32, i32 } undef, i32 1, 0
  %t1726 = insertvalue { i32, i32 } %t1724, i32 %t1720, 1
  %t1727 = getelementptr { i64, [3 x i64] }, ptr %t1721, i32 0, i32 1
  store { i32, i32 } %t1726, ptr %t1727
  %t1728 = load { i64, [3 x i64] }, ptr %t1721
  %t1730 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1728, ptr %t1730
  store ptr %t1730, ptr %l880, !tbaa !29
  %t1731 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1731, ptr %l881, !tbaa !29
  %t1732 = load ptr, ptr %l0, !tbaa !29
  %t1733 = load ptr, ptr %l4, !tbaa !29
  %t1734 = load %"compiler/source:Span", ptr %l1
  %t1738 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t1732, ptr %t1733, %"compiler/source:Span" %t1734)
  store ptr %t1738, ptr %l885
  br label %bb459
bb459:
  %t1739 = load ptr, ptr %l881, !tbaa !29
  %t1740 = load ptr, ptr %l885, !tbaa !29
  %t1741 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t1739, ptr %t1740)
  store { i64, ptr } %t1741, ptr %l886
  br label %bb460
bb460:
  %t1742 = load ptr, ptr %l873, !tbaa !29
  %t1743 = load %"compiler/source:Span", ptr %l874
  %t1744 = load i32, ptr %l876, !tbaa !23
  %t1745 = load ptr, ptr %l880, !tbaa !29
  %t1746 = load { i64, ptr }, ptr %l886, !tbaa !27
  %t1747 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %t1742, %"compiler/source:Span" %t1743, i32 %t1744, ptr %t1745, { i64, ptr } %t1746)
  store ptr %t1747, ptr %l887
  br label %bb461
bb461:
  %t1748 = load ptr, ptr %l887, !tbaa !29
  call void @__olang_scope_close(ptr %s53)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1748, ptr %rv
  br label %ret
bb462:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitWritten(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca ptr
  %l7 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca %"compiler/names:Ref"
  %l26 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l37 = alloca %"compiler/names:Ref"
  %l41 = alloca i1
  %l47 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l65 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb31
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l16, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l22
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l22
  store %"compiler/names:Ref" %t42, ptr %l5
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = icmp sgt i64 %t45, 1
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t50 = load i32, ptr %t49
  %t52 = trunc i64 0 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l26, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l31, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t63)
  store ptr %t65, ptr %l33
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t66 = load ptr, ptr %l33, !tbaa !29
  %t68 = getelementptr %"compiler/check:frame", ptr %t66, i32 0, i32 2
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t75 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t72, i64 %t69, i32 %t71)
  store %"compiler/names:Ref" %t75, ptr %l37
  br label %bb14
bb14:
  %t76 = load %"compiler/names:Ref", ptr %l37
  store %"compiler/names:Ref" %t76, ptr %l5
  br label %bb15
bb15:
  %t77 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t78 = load i32, ptr %t77
  %t80 = trunc i64 4 to i32
  %t81 = icmp eq i32 %t78, %t80
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb18
bb17:
  %t85 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 2
  %t86 = load i64, ptr %t85, !tbaa !24
  %t88 = icmp slt i64 %t86, 0
  store i1 %t88, ptr %l41, !tbaa !21
  br label %bb18
bb18:
  %t90 = load i1, ptr %l41, !tbaa !21
  br i1 %t90, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  store ptr %t97, ptr %l47, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 2
  %t105 = load i64, ptr %t104, !tbaa !24
  %t109 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t101, i64 %t103, i64 %t105)
  store i32 %t109, ptr %l52
  br label %bb22
bb22:
  %t110 = load ptr, ptr %l47, !tbaa !29
  %t111 = load i32, ptr %l52, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t112, ptr %l53
  br label %bb23
bb23:
  %t113 = load i32, ptr %l53
  %t115 = trunc i64 3 to i32
  %t116 = icmp eq i32 %t113, %t115
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l58, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t122, ptr %l59
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l60, !tbaa !29
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %a2)
  store %"compiler/source:Span" %t126, ptr %l62
  br label %bb27
bb27:
  %t127 = load ptr, ptr %l60, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l62
  %t129 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t127, %"compiler/source:Span" %t128)
  store { i64, ptr } %t129, ptr %l63
  br label %bb28
bb28:
  %t130 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t131 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitNotAType(ptr %v0, ptr %s1, { i64, ptr } %t130)
  store %"compiler/msgs:Msg" %t131, ptr %l64
  br label %bb29
bb29:
  %t132 = load ptr, ptr %l58, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l59
  %t134 = load %"compiler/msgs:Msg", ptr %l64
  %t135 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t132, %"compiler/source:Span" %t133, %"compiler/msgs:Msg" %t134)
  store i64 %t135, ptr %l65
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb31:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l12 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l25 = alloca i32
  %l30 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca { i64, [2 x i64] }
  %l35 = alloca i32
  %l40 = alloca i64
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca i64
  %l49 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t55 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  %t4 = load i32, ptr %l2, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t9 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t3, i64 %t6)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l3
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 20
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t17 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t13, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14)
  %t18 = extractvalue { i32, i64 } %t17, 1
  %t19 = extractvalue { i32, i64 } %t17, 0
  store i32 %t19, ptr %l17
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb3, label %ok.21
ok.21:
  store i64 %t18, ptr %l16
  br label %bb2
bb2:
  %t22 = load i64, ptr %l16, !tbaa !24
  store i64 %t22, ptr %l12, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l12, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sge i64 %t24, 0
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t28, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l25
  br label %bb9
bb9:
  %t40 = load i32, ptr %l25, !tbaa !23
  store i32 %t40, ptr %l5, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t46 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %t44, i32 %t45, i32 %t46)
  store i32 %t50, ptr %l30
  br label %bb10
bb10:
  %t51 = load i32, ptr %l30, !tbaa !23
  store i32 %t51, ptr %l6, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l31, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t54 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [2 x i64] }, ptr %t55, i32 0, i32 0
  store i64 1, ptr %t56
  %t58 = insertvalue { i32, i32 } undef, i32 %t53, 0
  %t60 = insertvalue { i32, i32 } %t58, i32 %t54, 1
  %t61 = getelementptr { i64, [2 x i64] }, ptr %t55, i32 0, i32 1
  store { i32, i32 } %t60, ptr %t61
  %t62 = load { i64, [2 x i64] }, ptr %t55
  store { i64, [2 x i64] } %t62, ptr %l34
  %t63 = load i32, ptr %l6, !tbaa !23
  store i32 %t63, ptr %l35, !tbaa !23
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t69, i32 %t70)
  store i64 %t73, ptr %l40
  br label %bb11
bb11:
  %t74 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t74, ptr %l41
  br label %bb12
bb12:
  %t75 = load ptr, ptr %l31, !tbaa !29
  %t76 = load { i64, [2 x i64] }, ptr %l34
  %t77 = load i32, ptr %l35, !tbaa !23
  %t78 = load i64, ptr %l40, !tbaa !24
  %t79 = load %"compiler/source:Span", ptr %l41
  %t80 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t75, { i64, [2 x i64] } %t76, i32 %t77, i64 %t78, %"compiler/source:Span" %t79)
  store i64 %t80, ptr %l42
  br label %bb13
bb13:
  %t81 = load i64, ptr %l42, !tbaa !24
  store i64 %t81, ptr %l4, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 20
  %t85 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t86 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t84, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t85, i64 %t86)
  br label %bb14
bb14:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l6, !tbaa !23
  %t94 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l49
  br label %bb15
bb15:
  %t95 = load i1, ptr %l49, !tbaa !21
  br i1 %t95, label %bb16, label %bb17
bb16:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 49
  %t99 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t98, i64 %t99, i1 true)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t102 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t102, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %s0, ptr %a0, ptr %l2, i32 %a1, i1 true)
  br label %bb2
bb2:
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i1
  %l49 = alloca ptr
  %l54 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l82 = alloca %"compiler/check:atRec"
  %l86 = alloca i1
  %l90 = alloca %"compiler/check:atRec"
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l21
  br label %bb6
bb6:
  %t21 = load i64, ptr %l21, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l22, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l23, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store i64 %t44, ptr %l31
  br label %bb13
bb13:
  %t45 = load i64, ptr %l31, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t47 = load ptr, ptr %l32, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l32, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l33, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l33, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store i64 %t68, ptr %l41
  br label %bb20
bb20:
  %t69 = load i64, ptr %l41, !tbaa !24
  store i64 %t69, ptr %rv
  br label %ret
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t71 = load ptr, ptr %l42, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l42, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 6
  store i1 %t77, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l43, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t81, i32 0, i32 3
  %t83 = load i32, ptr %t82
  store i32 %t83, ptr %l5, !tbaa !23
  br label %bb26
bb25:
  br label %bb49
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t85)
  store ptr %t87, ptr %l49
  br label %bb27
bb27:
  %t88 = load ptr, ptr %l49, !tbaa !29
  %t90 = getelementptr %"compiler/check:frame", ptr %t88, i32 0, i32 0
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 34
  %t97 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eLen_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l54
  br label %bb28
bb28:
  %t98 = load i64, ptr %l54, !tbaa !24
  store i64 %t98, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = icmp sgt i64 %t99, %t100
  br i1 %t103, label %bb29, label %bb30
bb29:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb34
bb31:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = sub i64 %t109, %t110
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = sub i64 %t117, 1
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = sdiv i64 %t119, %t120
  store i64 %t123, ptr %l61, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb33
bb33:
  %t125 = load i64, ptr %l61, !tbaa !24
  store i64 %t125, ptr %l58, !tbaa !24
  br label %bb34
bb34:
  %t126 = load i64, ptr %l58, !tbaa !24
  store i64 %t126, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t127 = load i64, ptr %l11, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb37:
  br label %bb38
bb38:
  %t135 = load i64, ptr %l7, !tbaa !24
  %t136 = load i64, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = mul i64 %t136, %t137
  %t143 = add i64 %t135, %t140
  store i64 %t143, ptr %l12, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 34
  %t148 = load i64, ptr %l12, !tbaa !24
  %t151 = call %"compiler/check:atRec" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %s6, ptr %t147, i64 %t148)
  store %"compiler/check:atRec" %t151, ptr %l82
  br label %bb39
bb39:
  %t152 = getelementptr %"compiler/check:atRec", ptr %l82, i32 0, i32 0
  %t153 = load i64, ptr %t152, !tbaa !24
  %t154 = load i64, ptr %l6, !tbaa !24
  %t157 = icmp eq i64 %t153, %t154
  br i1 %t157, label %bb40, label %bb41
bb40:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 34
  %t162 = load i64, ptr %l12, !tbaa !24
  %t165 = call %"compiler/check:atRec" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %s6, ptr %t161, i64 %t162)
  store %"compiler/check:atRec" %t165, ptr %l90
  br label %bb42
bb41:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb43
bb42:
  %t166 = getelementptr %"compiler/check:atRec", ptr %l90, i32 0, i32 1
  %t167 = load i64, ptr %t166, !tbaa !24
  %t168 = load i32, ptr %l5, !tbaa !23
  %t170 = sext i32 %t168 to i64
  %t173 = icmp eq i64 %t167, %t170
  store i1 %t173, ptr %l86, !tbaa !21
  br label %bb43
bb43:
  %t175 = load i1, ptr %l86, !tbaa !21
  br i1 %t175, label %bb44, label %bb45
bb44:
  %t176 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  store i64 %t176, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb47:
  %t178 = load i64, ptr %l11, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l11, !tbaa !24
  br label %bb35
bb48:
  store i64 -1, ptr %rv
  br label %ret
bb49:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i1 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca i32
  %l22 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i32
  %l50 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i1
  %l68 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l90 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l18
  br label %bb4
bb4:
  %t16 = load i32, ptr %l18
  store i32 %t16, ptr %l6
  %t17 = load i32, ptr %l6
  %t19 = trunc i64 25 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb16
bb7:
  br i1 %a4, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load i64, ptr %l27, !tbaa !24
  %t37 = icmp eq i64 %t35, %t34
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t45, i32 %t46)
  store i64 %t49, ptr %l35
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l35, !tbaa !24
  %t53 = icmp eq i64 %t51, %t50
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l30, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
bb16:
  %t56 = load i32, ptr %l6
  %t58 = trunc i64 19 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l40, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l45
  br label %bb20
bb20:
  %t72 = load i64, ptr %l2, !tbaa !24
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t74, 1
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = load i32, ptr %l45, !tbaa !23
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t77, i32 %t78, i64 %t72, i64 %t73, i1 true, i64 %t76)
  store i1 %t82, ptr %l50
  br label %bb21
bb21:
  %t83 = load i1, ptr %l50, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
bb22:
  %t84 = load i32, ptr %l6
  %t86 = trunc i64 20 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l53, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l1, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l58
  br label %bb26
bb26:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = add i64 %t102, 1
  %t105 = load ptr, ptr %l53, !tbaa !29
  %t106 = load i32, ptr %l58, !tbaa !23
  %t110 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t105, i32 %t106, i64 %t100, i64 %t101, i1 false, i64 %t104)
  store i1 %t110, ptr %l63
  br label %bb27
bb27:
  %t111 = load i1, ptr %l63, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
bb28:
  %t112 = load i32, ptr %l6
  %t114 = trunc i64 18 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb44
bb31:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  store ptr %t122, ptr %l68, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l1, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l73
  br label %bb32
bb32:
  %t133 = load ptr, ptr %l68, !tbaa !29
  %t134 = load i32, ptr %l73, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t133, i32 %t134)
  store { i64, ptr } %t135, ptr %l74
  br label %bb33
bb33:
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t136, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l9, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t141 = load i64, ptr %l8, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t149 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t149, ptr %l81, !tbaa !27
  %t150 = load i64, ptr %l8, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l2, !tbaa !24
  %t160 = load i64, ptr %l3, !tbaa !24
  %t161 = load i64, ptr %l5, !tbaa !24
  %t163 = add i64 %t161, 1
  %t169 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t157, i32 %t155, i64 %t159, i64 %t160, i1 true, i64 %t163)
  store i1 %t169, ptr %l90
  br label %bb38
bb38:
  %t170 = load i1, ptr %l90, !tbaa !21
  br i1 %t170, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb42:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l8, !tbaa !24
  br label %bb34
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i1
  %l28 = alloca i32
  %l35 = alloca i64
  %l38 = alloca i1
  %l43 = alloca i64
  %l47 = alloca { i64, ptr }
  %l52 = alloca i64
  %l57 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l88 = alloca i32
  %l97 = alloca i32
  %l99 = alloca ptr
  %l104 = alloca i32
  %l111 = alloca ptr
  %l116 = alloca i32
  %l125 = alloca ptr
  %l130 = alloca i32
  %l131 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l154 = alloca i32
  %l165 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l196 = alloca i32
  %s6 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l20, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l28
  br label %bb7
bb7:
  %t22 = load i32, ptr %l28
  store i32 %t22, ptr %l5
  %t23 = load i32, ptr %l5
  %t25 = trunc i64 25 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t33, i32 %t34)
  store i64 %t37, ptr %l35
  br label %bb11
bb11:
  %t38 = load i64, ptr %l2, !tbaa !24
  %t39 = load i64, ptr %l35, !tbaa !24
  %t41 = icmp eq i64 %t39, %t38
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t48, i32 %t49)
  store i64 %t52, ptr %l43
  br label %bb14
bb13:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb15
bb14:
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = load i64, ptr %l43, !tbaa !24
  %t58 = icmp slt i64 %t56, %t55
  store i1 %t58, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t60 = load i1, ptr %l38, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb16:
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t61, ptr %l47, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l52
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t72 = load i64, ptr %l52, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i1, ptr %t74, i64 %t72
  store i1 true, ptr %t75, !tbaa !31
  br label %bb19
bb19:
  br label %bb88
bb20:
  %t76 = load i32, ptr %l5
  %t78 = trunc i64 18 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb33
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  store ptr %t86, ptr %l57, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l1, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l62
  br label %bb24
bb24:
  %t97 = load ptr, ptr %l57, !tbaa !29
  %t98 = load i32, ptr %l62, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t97, i32 %t98)
  store { i64, ptr } %t99, ptr %l63
  br label %bb25
bb25:
  %t100 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t100, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  store i64 %t103, ptr %l8, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t105 = load i64, ptr %l7, !tbaa !24
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t113 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t113, ptr %l70, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i32, ptr %t117, i64 %t114
  %t119 = load i32, ptr %t118, !tbaa !33
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l2, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = add i64 %t125, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t121, i32 %t119, i64 %t123, { i64, ptr } %t124, i64 %t127)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  %t133 = load i64, ptr %l7, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l7, !tbaa !24
  br label %bb26
bb32:
  br label %bb88
bb33:
  %t137 = load i32, ptr %l5
  %t139 = trunc i64 19 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb45
bb36:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l83, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l1, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l88
  br label %bb37
bb37:
  %t153 = load i64, ptr %l2, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t155 = load i64, ptr %l4, !tbaa !24
  %t157 = add i64 %t155, 1
  %t158 = load ptr, ptr %l83, !tbaa !29
  %t159 = load i32, ptr %l88, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t158, i32 %t159, i64 %t153, { i64, ptr } %t154, i64 %t157)
  br label %bb38
bb38:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 2
  %t169 = load i32, ptr %l1, !tbaa !23
  %t172 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t168, i32 %t169)
  store i32 %t172, ptr %l97
  br label %bb39
bb39:
  %t173 = load i32, ptr %l97, !tbaa !23
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb40, label %bb41
bb40:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l99, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l1, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l104
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t187 = load i64, ptr %l2, !tbaa !24
  %t188 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t189 = load i64, ptr %l4, !tbaa !24
  %t191 = add i64 %t189, 1
  %t192 = load ptr, ptr %l99, !tbaa !29
  %t193 = load i32, ptr %l104, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t192, i32 %t193, i64 %t187, { i64, ptr } %t188, i64 %t191)
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb88
bb45:
  %t197 = load i32, ptr %l5
  %t199 = trunc i64 20 to i32
  %t200 = icmp eq i32 %t197, %t199
  br i1 %t200, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l111, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  %t209 = load i32, ptr %l1, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t208, i32 %t209)
  store i32 %t212, ptr %l116
  br label %bb49
bb49:
  %t213 = load i64, ptr %l2, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t215 = load i64, ptr %l4, !tbaa !24
  %t217 = add i64 %t215, 1
  %t218 = load ptr, ptr %l111, !tbaa !29
  %t219 = load i32, ptr %l116, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t218, i32 %t219, i64 %t213, { i64, ptr } %t214, i64 %t217)
  br label %bb50
bb50:
  br label %bb88
bb51:
  %t223 = load i32, ptr %l5
  %t225 = trunc i64 21 to i32
  %t226 = icmp eq i32 %t223, %t225
  br i1 %t226, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb66
bb54:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  store ptr %t233, ptr %l125, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = getelementptr %"compiler/generic:Program", ptr %t237, i32 0, i32 2
  %t240 = load i32, ptr %l1, !tbaa !23
  %t243 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t243, ptr %l130
  br label %bb55
bb55:
  %t244 = load ptr, ptr %l125, !tbaa !29
  %t245 = load i32, ptr %l130, !tbaa !23
  %t246 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t244, i32 %t245)
  store { i64, ptr } %t246, ptr %l131
  br label %bb56
bb56:
  %t247 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t247, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t248, 0
  store i64 %t250, ptr %l12, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s13
  %t252 = load i64, ptr %l11, !tbaa !24
  %t253 = load i64, ptr %l12, !tbaa !24
  %t256 = icmp slt i64 %t252, %t253
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s13)
  br label %bb63
bb59:
  br label %bb60
bb60:
  %t260 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t260, ptr %l138, !tbaa !27
  %t261 = load i64, ptr %l11, !tbaa !24
  %t263 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i32, ptr %t264, i64 %t261
  %t266 = load i32, ptr %t265, !tbaa !33
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i64, ptr %l2, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t272 = load i64, ptr %l4, !tbaa !24
  %t274 = add i64 %t272, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t268, i32 %t266, i64 %t270, { i64, ptr } %t271, i64 %t274)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb62
bb62:
  %t280 = load i64, ptr %l11, !tbaa !24
  %t282 = add i64 %t280, 1
  store i64 %t282, ptr %l11, !tbaa !24
  br label %bb57
bb63:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l149, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 2
  %t291 = load i32, ptr %l1, !tbaa !23
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t290, i32 %t291)
  store i32 %t294, ptr %l154
  br label %bb64
bb64:
  %t295 = load i64, ptr %l2, !tbaa !24
  %t296 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t297 = load i64, ptr %l4, !tbaa !24
  %t299 = add i64 %t297, 1
  %t300 = load ptr, ptr %l149, !tbaa !29
  %t301 = load i32, ptr %l154, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t300, i32 %t301, i64 %t295, { i64, ptr } %t296, i64 %t299)
  br label %bb65
bb65:
  br label %bb88
bb66:
  %t305 = load i32, ptr %l5
  %t307 = trunc i64 22 to i32
  %t308 = icmp eq i32 %t305, %t307
  br i1 %t308, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  %t310 = load i32, ptr %l5
  %t312 = trunc i64 23 to i32
  %t313 = icmp eq i32 %t310, %t312
  br i1 %t313, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb81
bb71:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Program", ptr %t318, i32 0, i32 2
  store ptr %t320, ptr %l165, !tbaa !29
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/check:Checker", ptr %t321, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = getelementptr %"compiler/generic:Program", ptr %t324, i32 0, i32 2
  %t327 = load i32, ptr %l1, !tbaa !23
  %t330 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t326, i32 %t327)
  store i32 %t330, ptr %l170
  br label %bb72
bb72:
  %t331 = load ptr, ptr %l165, !tbaa !29
  %t332 = load i32, ptr %l170, !tbaa !23
  %t333 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t331, i32 %t332)
  store { i64, ptr } %t333, ptr %l171
  br label %bb73
bb73:
  %t334 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t334, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  store i64 %t337, ptr %l16, !tbaa !24
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s17
  %t339 = load i64, ptr %l15, !tbaa !24
  %t340 = load i64, ptr %l16, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s17)
  br label %bb80
bb76:
  br label %bb77
bb77:
  %t347 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t347, ptr %l178, !tbaa !27
  %t348 = load i64, ptr %l15, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr i32, ptr %t351, i64 %t348
  %t353 = load i32, ptr %t352, !tbaa !33
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i64, ptr %l2, !tbaa !24
  %t358 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t359 = load i64, ptr %l4, !tbaa !24
  %t361 = add i64 %t359, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t355, i32 %t353, i64 %t357, { i64, ptr } %t358, i64 %t361)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s17)
  br label %bb79
bb79:
  %t367 = load i64, ptr %l15, !tbaa !24
  %t369 = add i64 %t367, 1
  store i64 %t369, ptr %l15, !tbaa !24
  br label %bb74
bb80:
  br label %bb88
bb81:
  %t371 = load i32, ptr %l5
  %t373 = trunc i64 29 to i32
  %t374 = icmp eq i32 %t371, %t373
  br i1 %t374, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb87
bb84:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l191, !tbaa !29
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = getelementptr %"compiler/generic:Program", ptr %t380, i32 0, i32 2
  %t383 = load i32, ptr %l1, !tbaa !23
  %t386 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t382, i32 %t383)
  store i32 %t386, ptr %l196
  br label %bb85
bb85:
  %t387 = load i64, ptr %l2, !tbaa !24
  %t388 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t389 = load i64, ptr %l4, !tbaa !24
  %t391 = add i64 %t389, 1
  %t392 = load ptr, ptr %l191, !tbaa !29
  %t393 = load i32, ptr %l196, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t392, i32 %t393, i64 %t387, { i64, ptr } %t388, i64 %t391)
  br label %bb86
bb86:
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, i64, i64 }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l22 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l47 = alloca i32
  %l48 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca { i64, i64, i64 }
  %l62 = alloca ptr
  %l67 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca i64
  %l77 = alloca ptr
  %l81 = alloca ptr
  %l86 = alloca ptr
  %l96 = alloca i64
  %l98 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca i32
  %l103 = alloca i64
  %l105 = alloca ptr
  %l108 = alloca i64
  %l109 = alloca i32
  %l115 = alloca ptr
  %l116 = alloca ptr
  %l117 = alloca %"compiler/source:Span"
  %l118 = alloca ptr
  %l122 = alloca ptr
  %t19 = alloca { i64, [3 x i64] }, align 8
  %t65 = alloca { i64, [3 x i64] }, align 8
  %t220 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2, ptr %l18
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t3)
  store i32 %t6, ptr %l21
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l17, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l18
  %t9 = load i32, ptr %l21, !tbaa !23
  %t10 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t7, %"compiler/source:Span" %t8, i32 %t9)
  store i64 %t10, ptr %l22
  br label %bb2
bb2:
  %t11 = load i64, ptr %l22, !tbaa !24
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  %t14 = load i64, ptr %l7, !tbaa !24
  %t16 = trunc i64 %t14 to i32
  %t18 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 0
  store i64 0, ptr %t20
  %t22 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t13, 0
  %t24 = insertvalue { %"compiler/source:Span", i32, ptr } %t22, i32 %t16, 1
  %t26 = insertvalue { %"compiler/source:Span", i32, ptr } %t24, ptr %t18, 2
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t26, ptr %t27
  %t28 = load { i64, [3 x i64] }, ptr %t19
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t28, ptr %t30
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t12, ptr %t30)
  br label %bb3
bb3:
  store i64 -1, ptr %l8, !tbaa !24
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/ast:ForIn", ptr %t33, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = icmp ne i32 %t36, 0
  br i1 %t38, label %bb4, label %bb5
bb4:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l34, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t41, ptr %l35
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t42)
  store i32 %t44, ptr %l37
  br label %bb6
bb5:
  br label %bb11
bb6:
  %t45 = load ptr, ptr %l34, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l35
  %t47 = load i32, ptr %l37, !tbaa !23
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t45, %"compiler/source:Span" %t46, i32 %t47)
  store i64 %t48, ptr %l38
  br label %bb7
bb7:
  %t49 = load i64, ptr %l38, !tbaa !24
  store i64 %t49, ptr %l8, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l39, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t51, ptr %l40
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = trunc i64 %t52 to i32
  store i32 %t54, ptr %l43, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l44, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t57, ptr %l45
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t58)
  store i32 %t60, ptr %l47
  br label %bb8
bb8:
  %t61 = load ptr, ptr %l44, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l45
  %t63 = load i32, ptr %l47, !tbaa !23
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t61, %"compiler/source:Span" %t62, i32 %t63, i64 0)
  store ptr %t64, ptr %l48
  br label %bb9
bb9:
  store { i64, [3 x i64] } zeroinitializer, ptr %t65
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 0
  store i64 0, ptr %t66
  %t67 = load %"compiler/source:Span", ptr %l40
  %t68 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t67, 0
  %t69 = load i32, ptr %l43, !tbaa !23
  %t70 = insertvalue { %"compiler/source:Span", i32, ptr } %t68, i32 %t69, 1
  %t71 = load ptr, ptr %l48, !tbaa !29
  %t72 = insertvalue { %"compiler/source:Span", i32, ptr } %t70, ptr %t71, 2
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t72, ptr %t73
  %t74 = load { i64, [3 x i64] }, ptr %t65
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t74, ptr %t76
  %t77 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t77, ptr %t76)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 33
  %t83 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l53
  br label %bb12
bb12:
  %t84 = load i64, ptr %l53, !tbaa !24
  store i64 %t84, ptr %l9, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l1
  %t90 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t85, i32 2, %"compiler/source:Span" %t86)
  store { i64, i64, i64 } %t90, ptr %l57
  br label %bb13
bb13:
  %t91 = load { i64, i64, i64 }, ptr %l57
  store { i64, i64, i64 } %t91, ptr %l10
  %t92 = getelementptr { i64, i64, i64 }, ptr %l10, i32 0, i32 0
  %t93 = load i64, ptr %t92, !tbaa !24
  store i64 %t93, ptr %l11, !tbaa !24
  %t95 = getelementptr { i64, i64, i64 }, ptr %l10, i32 0, i32 1
  %t96 = load i64, ptr %t95, !tbaa !24
  store i64 %t96, ptr %l12, !tbaa !24
  %t98 = getelementptr { i64, i64, i64 }, ptr %l10, i32 0, i32 2
  %t99 = load i64, ptr %t98, !tbaa !24
  store i64 %t99, ptr %l13, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t101)
  store ptr %t103, ptr %l62
  br label %bb14
bb14:
  %t104 = load ptr, ptr %l62, !tbaa !29
  %t106 = getelementptr %"compiler/check:frame", ptr %t104, i32 0, i32 10
  %t107 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t106, i64 %t107)
  br label %bb15
bb15:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t110)
  store ptr %t112, ptr %l67
  br label %bb16
bb16:
  %t113 = load ptr, ptr %l67, !tbaa !29
  %t115 = getelementptr %"compiler/check:frame", ptr %t113, i32 0, i32 11
  %t116 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t115, i64 %t116)
  br label %bb17
bb17:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l71, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t120, ptr %l72
  store i64 %a4, ptr %l73, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l1
  %t124 = load i64, ptr %l7, !tbaa !24
  %t128 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t122, %"compiler/source:Span" %t123, i64 %t124)
  store ptr %t128, ptr %l77
  br label %bb18
bb18:
  %t129 = icmp sge i64 0, 0
  br i1 %t129, label %bb19, label %bb20
bb19:
  %t131 = icmp sle i64 0, 1152921504606846975
  br i1 %t131, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_fea4cce0f7542395_82370c360b9a7e9)
  unreachable
bb21:
  %t133 = mul i64 0, 8
  %t134 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t133)
  %t135 = insertvalue { i64, ptr } undef, i64 0, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  %t137 = load ptr, ptr %l71, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l72
  %t139 = load i64, ptr %l73, !tbaa !24
  %t140 = load ptr, ptr %l77, !tbaa !29
  %t142 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %t137, %"compiler/source:Span" %t138, i64 %t139, ptr %t140, { i64, ptr } %t136)
  store ptr %t142, ptr %l81
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_fea4cce0f7542395_82370c360b9a7e9)
  unreachable
bb23:
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l1
  %t147 = load i64, ptr %l11, !tbaa !24
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %t144, %"compiler/source:Span" %t145, ptr %t143, i64 %t147)
  store ptr %t152, ptr %l86
  br label %bb24
bb24:
  %t153 = load ptr, ptr %l86, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l1
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t157 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %t154, %"compiler/source:Span" %t155, ptr %t156, i64 %t157, ptr %t153)
  br label %bb25
bb25:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %t164, ptr %t165, ptr %a5, i32 %a6)
  br label %bb26
bb26:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t172)
  store ptr %t174, ptr %l98
  br label %bb27
bb27:
  %t175 = load ptr, ptr %l98, !tbaa !29
  %t177 = getelementptr %"compiler/check:frame", ptr %t175, i32 0, i32 10
  %t179 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t177)
  %t180 = extractvalue { i32, i64 } %t179, 1
  %t181 = extractvalue { i32, i64 } %t179, 0
  store i32 %t181, ptr %l102
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb29, label %ok.183
ok.183:
  store i64 %t180, ptr %l101
  br label %bb28
bb28:
  %t184 = load i64, ptr %l101, !tbaa !24
  store i64 %t184, ptr %l96, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  call void @__olang_ert_req_clear()
  br label %bb31
bb31:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t185)
  store ptr %t187, ptr %l105
  br label %bb32
bb32:
  %t188 = load ptr, ptr %l105, !tbaa !29
  %t190 = getelementptr %"compiler/check:frame", ptr %t188, i32 0, i32 11
  %t192 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t190)
  %t193 = extractvalue { i32, i64 } %t192, 1
  %t194 = extractvalue { i32, i64 } %t192, 0
  store i32 %t194, ptr %l109
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb34, label %ok.196
ok.196:
  store i64 %t193, ptr %l108
  br label %bb33
bb33:
  %t197 = load i64, ptr %l108, !tbaa !24
  store i64 %t197, ptr %l103, !tbaa !24
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  br label %bb36
bb36:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i64, ptr %l11, !tbaa !24
  %t200 = load i64, ptr %l12, !tbaa !24
  %t201 = load i64, ptr %l13, !tbaa !24
  %t202 = load i64, ptr %l9, !tbaa !24
  %t208 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t198, i64 %t199, i64 %t200, i64 %t201, i64 %t202)
  store ptr %t208, ptr %l115
  br label %bb37
bb37:
  %t209 = load ptr, ptr %l115, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l116, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t211, ptr %l117
  store ptr %t209, ptr %l118, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load %"compiler/source:Span", ptr %l1
  %t215 = load i64, ptr %l8, !tbaa !24
  %t219 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %t213, %"compiler/source:Span" %t214, i64 %t215)
  store ptr %t219, ptr %l122
  br label %bb38
bb38:
  store { i64, [3 x i64] } zeroinitializer, ptr %t220
  %t221 = getelementptr { i64, [3 x i64] }, ptr %t220, i32 0, i32 0
  store i64 4, ptr %t221
  %t222 = load %"compiler/source:Span", ptr %l117
  %t223 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t222, 0
  %t224 = load ptr, ptr %l118, !tbaa !29
  %t225 = insertvalue { %"compiler/source:Span", ptr, ptr } %t223, ptr %t224, 1
  %t226 = load ptr, ptr %l122, !tbaa !29
  %t227 = insertvalue { %"compiler/source:Span", ptr, ptr } %t225, ptr %t226, 2
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t220, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t227, ptr %t228
  %t229 = load { i64, [3 x i64] }, ptr %t220
  %t231 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t229, ptr %t231
  %t232 = load ptr, ptr %l116, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t232, ptr %t231)
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2eisArrayMake(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18
  %t21 = trunc i64 2 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %rv
  br label %ret
bb6:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisTrue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l2, !tbaa !24
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t26 = icmp eq i32 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp eq i64 %t28, 1
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l14, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
bb9:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t1)
  store i1 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i1, ptr %l7, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 %t25
  %t30 = load ptr, ptr %t29, !tbaa !39
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 5
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb5
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2elistIndex(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t5 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFields, !tbaa !24
  store i64 %t5, ptr %l1, !tbaa !24
  br label %bb25
bb5:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t9, ptr %l6
  br label %bb6
bb6:
  %t10 = load i1, ptr %l6, !tbaa !21
  br i1 %t10, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t11 = load i64, ptr @G_2ecompiler_2fgeneric_2eListCases, !tbaa !24
  store i64 %t11, ptr %l1, !tbaa !24
  br label %bb25
bb10:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d67, i32 0, i32 1) })
  store i1 %t15, ptr %l9
  br label %bb11
bb11:
  %t16 = load i1, ptr %l9, !tbaa !21
  br i1 %t16, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t17 = load i64, ptr @G_2ecompiler_2fgeneric_2eListParams, !tbaa !24
  store i64 %t17, ptr %l1, !tbaa !24
  br label %bb25
bb15:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store i1 %t21, ptr %l12
  br label %bb16
bb16:
  %t22 = load i1, ptr %l12, !tbaa !21
  br i1 %t22, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t23 = load i64, ptr @G_2ecompiler_2fgeneric_2eListResults, !tbaa !24
  store i64 %t23, ptr %l1, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i64 -1, ptr %l1, !tbaa !24
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_77a436a5c2d44065_8e586571f5cf09a9)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i64, ptr %l1, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %rv = alloca { i1, i64 }
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 2
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = insertvalue { i1, i64 } undef, i1 false, 0
  %t9 = insertvalue { i1, i64 } %t7, i64 %t5, 1
  store { i1, i64 } %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = icmp slt i64 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t17 = load i64, ptr %t16, !tbaa !24
  %t20 = sub i64 0, %t17
  %t21 = insertvalue { i1, i64 } undef, i1 true, 0
  %t23 = insertvalue { i1, i64 } %t21, i64 %t20, 1
  store { i1, i64 } %t23, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t25 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = insertvalue { i1, i64 } undef, i1 false, 0
  %t30 = insertvalue { i1, i64 } %t28, i64 %t26, 1
  store { i1, i64 } %t30, ptr %rv
  br label %ret
ret:
  %rr = load { i1, i64 }, ptr %rv
  ret { i1, i64 } %rr
}

define dso_local %"compiler/check:reflList" @compiler_2fcheck_2enoList() #0 {
entry:
  %l1 = alloca %"compiler/check:reflList"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflList"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t3 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s0, i1 false, i32 %t1, i64 0, i64 -1)
  store %"compiler/check:reflList" %t3, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:reflList", ptr %l1
  store %"compiler/check:reflList" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflList", ptr %rv
  ret %"compiler/check:reflList" %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/check:reflVal"
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t3 = call %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v0, i1 false, i64 0, i64 0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, i32 %t1)
  store %"compiler/check:reflVal" %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load %"compiler/check:reflVal", ptr %l1
  store %"compiler/check:reflVal" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/check:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:Gap" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/check:Gap" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/check:Gap" %t10, { i64, ptr } %a2, 2
  store %"compiler/check:Gap" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:Gap", ptr %rv
  ret %"compiler/check:Gap" %rr
}

define dso_local %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10) #0 {
entry:
  %rv = alloca %"compiler/check:laneNode"
  br label %start
start:
  br label %bb0
bb0:
  %t24 = insertvalue %"compiler/check:laneNode" undef, i64 %a0, 0
  %t26 = insertvalue %"compiler/check:laneNode" %t24, i32 %a1, 1
  %t28 = insertvalue %"compiler/check:laneNode" %t26, %"compiler/source:Span" %a2, 2
  %t30 = insertvalue %"compiler/check:laneNode" %t28, %"compiler/source:Span" %a3, 3
  %t32 = insertvalue %"compiler/check:laneNode" %t30, i64 %a4, 4
  %t34 = insertvalue %"compiler/check:laneNode" %t32, i64 %a5, 5
  %t36 = insertvalue %"compiler/check:laneNode" %t34, i64 %a6, 6
  %t38 = insertvalue %"compiler/check:laneNode" %t36, ptr %a7, 7
  %t40 = insertvalue %"compiler/check:laneNode" %t38, i32 %a8, 8
  %t42 = insertvalue %"compiler/check:laneNode" %t40, i64 %a9, 9
  %t44 = insertvalue %"compiler/check:laneNode" %t42, i32 %a10, 10
  store %"compiler/check:laneNode" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:laneNode", ptr %rv
  ret %"compiler/check:laneNode" %rr
}

define dso_local %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:roDeepArg"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:roDeepArg" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:roDeepArg" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/check:roDeepArg" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:roDeepArg" %t14, i64 %a3, 3
  store %"compiler/check:roDeepArg" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roDeepArg", ptr %rv
  ret %"compiler/check:roDeepArg" %rr
}

define dso_local %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %rv = alloca %"compiler/check:roOrigin"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:roOrigin" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/check:roOrigin" %t6, i1 %a1, 1
  store %"compiler/check:roOrigin" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roOrigin", ptr %rv
  ret %"compiler/check:roOrigin" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"it introduces a type variable, which no zero binds" }>, align 8
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d2 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"the checker asked for the body of a frame that checks none" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr })
declare void @__olang_ert_req_clear()
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d7 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d9 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"an if the build decides, still undecided (S8b, B9c)" }>, align 8
@.d10 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"an else of this kind" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"join" }>, align 8
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Neg" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitNot" }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"if" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3atypeCase_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3atypeCase_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d15 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Of" }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"case" }>, align 8
@.d17 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"parameter" }>, align 8
@.d18 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"result" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Of" }>, align 8
@.d20 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"its Name and Type" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d22 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Clone" }>, align 8
@.d23 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"from its parts" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"with '" }>, align 8
@.d25 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c".Clone()'" }>, align 8
@.d26 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"with 'Clone()'" }>, align 8
@.d27 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d31 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a scope argument on what is no call (E25)" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d34 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"'Bits'" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d40 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"FromBits" }>, align 8
@.d41 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Value" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Set" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Get" }>, align 8
@.d45 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"SliceOf" }>, align 8
@.d46 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Get" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d49 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"SliceOf" }>, align 8
@.d50 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Narrow" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d53 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"retire" }>, align 8
@.d54 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Destroy" }>, align 8
@.d55 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"vacate" }>, align 8
@.d56 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Atomic" }>, align 8
@.d57 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"AtomicStore" }>, align 8
@.d58 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"AtomicAdd" }>, align 8
@.d59 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"AtomicSwap" }>, align 8
@.d60 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"AtomicCompareSwap" }>, align 8
@.d61 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"AtomicLoad" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d64 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d65 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Fields" }>, align 8
@.d66 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Cases" }>, align 8
@.d67 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Params" }>, align 8
@.d68 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Results" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2fcheck_2eCtEntry = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2ePu_Hf3d190a214b599b1db3fb8bde0778037(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2eTo_H8a5ee0a19875600d5129e9d1ac97555e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2eTruncate_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [3 x i64] } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eUseOf(ptr %v0, ptr %a0, { i64, [3 x i64] } %a1)
declare %"compiler/check:ValueAsk" @compiler_2fcheck_3aValueAsk_2ector(ptr %v0, i32 %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, { i64, [3 x i64] } %a5)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2ePu_Hfa45de49c8c8d06dcd560076652adff8(ptr %v0, ptr %a0, %"compiler/check:ValueAsk" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBangNothingFails(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_77940e7aab679ede_bd13144cbc386012 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNow(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseNever(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtMatchMissing(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, i32 %a5)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
@olang_loc_854899d5724a103b_e7dfb19072d83fa7 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6)
@olang_loc_852b58c2eb82b3cc_e47a0c64d3951188 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eP_Hee51906bde9346e7b7b6808fdce5ba81(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %v0)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %v0)
@olang_loc_20fb2e81a5b7d68a_7759df49ce89a9e = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %v0)
declare i1 @compiler_2fcheck_2elastIsValue(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %v0, i64 %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorContext(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_43d20343d6f566de_136f8b7be912828a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2enoLit()
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %a0, i64 %a1, i1 %a2, i64 %a3)
declare i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9c930588fc11ccad_eb7b13c9402bcb61 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTypeArgsNotInferable(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eToA_H3b732fb6bb2c20fd2f0446a621d56c2c(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_a622476533ee0612_1aeb16e8ac1e1db6 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_319f2f7a6670a39_e028e643a90bcd1d = external constant [0 x i8]
@olang_loc_c3c7b193c2dffac4_485cea4ac45d2600 = external constant [0 x i8]
@olang_loc_6de95c363ba43753_b985f35754c3cc67 = external constant [0 x i8]
@olang_loc_62c8ad0b34d7b82e_8c827e0bb8ee6f7a = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_fdfae68a787e97d5_65790712af8f8e01 = external constant [0 x i8]
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_9bced391e891fdc0_daecba1c3e9b04cc = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropElse(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8beb387543c1195f_db09fb2ec562613b = external constant [0 x i8]
@olang_loc_58a847b11cbe2c6a_cfe1571b02fdc8be = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_52eef6690961319f_3e44ce9e4bd0006b = external constant [0 x i8]
@olang_loc_ccb3ed4617d06259_8e58603f3b63faf5 = external constant [0 x i8]
@olang_loc_c77fa73b8d335132_2d868ec26eb5ab4e = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b9205633ccf2d073_299d3206908c6fff = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_63e876f984926a4_8a5a5385d13272e0 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2925a2ee61841cf5_31e6aa96f1b04059 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/check:Ask" @compiler_2fcheck_3aAsk_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i32 %a2, ptr %a3, i64 %a4, { i64, ptr } %a5)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2ePush_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:Ask" %a1)
@olang_loc_c853d17194d5cd4e_2cb2648c67132f32 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_286b86a66182be45_96c217cd656b05f1 = external constant [0 x i8]
@olang_loc_25279634f75294e0_6b7144c0722904a4 = external constant [0 x i8]
@olang_loc_204174f82b625491_c4a24154dc66de6d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseDropped(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_129174e89ad23b8a_c281ac2402d9bb86 = external constant [0 x i8]
@olang_loc_aaca5398e8f6066a_f405ea46c1055e66 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseHolds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@olang_loc_fca31ed42f743f9f_86b4bf9b48cda613 = external constant [0 x i8]
@olang_loc_6f3b4b685ddeb67c_7b5ce21143ef4c38 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e7da762e638de5eb_7df0529e92f5f857 = external constant [0 x i8]
@olang_loc_59798b902320b6de_8af9bcd9624748ca = external constant [0 x i8]
@olang_loc_4ac5dcd3d6b95a4d_7a015a3c37ae2071 = external constant [0 x i8]
@olang_loc_162a24c06a0f6e38_d46e08b937be947c = external constant [0 x i8]
@olang_loc_18bd954db9161a57_4d0d337f3d6dc3eb = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@olang_loc_f844534d0025e012_1a1d7643daef702e = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eConditionConstant(ptr %v0)
@olang_loc_553bfedf729ee439_b54fafc31e964fd5 = external constant [0 x i8]
@olang_loc_2032043ec708821f_9b3365a6aba1b47b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedBranch(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, ptr %a4, i1 %a5)
@olang_loc_7e262e55150b6580_229faafeaed7320c = external constant [0 x i8]
@olang_loc_2f295e3784570d95_d107a97c68b54b41 = external constant [0 x i8]
@olang_loc_243e81cb3c32d1ee_d10bd76f726657ba = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
@olang_loc_1de170122f32f713_27e6b5ec6f6061a7 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushErrNarrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
@olang_loc_4c9c4b94d2908344_248110c0d01d3388 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H257d83b06934604763b32ef91c51c1d2(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebound(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinWithoutSpawn(ptr %v0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_55f84e4449673261_62da473350726dd5 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCatchNeedsTry(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCannotFail(ptr %v0)
@olang_loc_a0600b9a17fc9cd0_1e19997b248853e4 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, i1 %a3, { i64, ptr } %a4, ptr %a5)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eL_H39694dc3b7c161b4999ab170e8f3fd84(ptr %v0, ptr %a0)
@olang_loc_3aadc4e023da3b64_af78beb3670ebce8 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinClauseMustLeave(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNotTried(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eT_H39fa81f2ad510245a68cbacb663c8d87(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseLoopJump(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgLoopJump(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferLoopJump(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBreakOutsideLoop(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInClauseExit(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fcheck_2eLaneArr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneScalar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eLaneUn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
@olang_loc_a912cbb846bdb4fc_9416d37dc1706d90 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_3e_2ector(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflMatchSubject(ptr %v0)
@olang_loc_775dfd67c7206a52_c2d8bc16e2444876 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordBefore(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchGuard(ptr %v0)
declare i1 @compiler_2fcheck_2eisWildType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3atypeCase_3e_2eRu_H6eb7eaf448ada2c059532340e07086a1(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a7e62a7f9d49e0b0_a2816bf575d66404 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflCaseUnreachable(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %v0, i1 %a0, i1 %a1, i32 %a2, i64 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3atypeCase_3e_2ePu_Hf6291ee8fee32011df4f690a3becde1c(ptr %v0, ptr %a0, %"compiler/check:typeCase" %a1)
declare %"compiler/check:typeCase" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_861e0137122870eb_3ad6276ce475d93f = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseCovers(ptr %v0, ptr %a0, %"compiler/check:typeCase" %a1, %"compiler/check:typeCase" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseHolds(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:typeCase" %a1, i32 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchUncovered(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecasePath(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_Hf9d8b9e9334551fc04613fb711673451(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d8c7da3a96e96ec6_ffec47baa4f6769a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earraysEqual(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumsEqual(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMisused(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfArgs(ptr %v0, i64 %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eRu_H9d42e7edf572b8740166f4b30b0e5054(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_271de975e94d1c2d_b74be220493c84d1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_19fb235390dd08bf_74b3a6d5c5264653 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenReturnScope(ptr %v0)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_205c65d5b195e98c_2c317476e8a14790 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgNotAccepted(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4)
@olang_loc_31e71959ceb2c563_c3b6512c8fc1b1c7 = external constant [0 x i8]
@olang_loc_af79aa682331a71e_538108f01047ae92 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_17d8aaff70de119f_90c04534d00fd893 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_de1861672a449342_6f761fc46447aabe = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFromBitsReceiver(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, { i64, ptr } %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoutOfRange(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
@olang_loc_c7803a0ae3a7f551_a0a1c1dd70cf568d = external constant [0 x i8]
@olang_loc_77737f92dc0fe3d4_2745f5c5195bdf40 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreInto(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, ptr %a5)
@olang_loc_56b27b3a434e6e4b_829f47044d523297 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5)
@olang_loc_612cb7a013386346_141d5cc8e3df5aaa = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowNeedsType(ptr %v0)
declare i32 @compiler_2fcheck_2ebitOp(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBitOpNotInteger(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eByteSwapWidth(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBitOpCount(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNoDestructor(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_8b3f489cc69a1bd4_cc212478c27e5838 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNotLocal(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVacateNotPlace(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotInteger(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicWidth(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotPlace(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotWritable(ptr %v0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartHashes(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitNotAType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eLen_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %a0)
declare %"compiler/check:atRec" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
@olang_loc_fea4cce0f7542395_82370c360b9a7e9 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
@G_2ecompiler_2fgeneric_2eListFields = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListCases = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListParams = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListResults = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_77a436a5c2d44065_8e586571f5cf09a9 = external constant [0 x i8]
declare %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %v0, i1 %a0, i32 %a1, i64 %a2, i64 %a3)
declare %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3atypeCase_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
