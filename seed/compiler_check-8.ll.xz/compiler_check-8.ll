; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:landing" = type { i64, i64, %"compiler/source:Span", i32, i64 }
%"compiler/typed:Item" = type { i32, i64 }
%"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, i1 }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/check:seqOf" = type { i32, i64, i64, i64 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/check:factsCopy" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"compiler/check:litv"
  %l21 = alloca i32
  %l27 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l33 = alloca i64
  %l34 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l56 = alloca ptr
  %l60 = alloca i1
  %l61 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca %"compiler/msgs:Msg"
  %l66 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l77 = alloca i64
  %l78 = alloca %"compiler/source:Span"
  %l82 = alloca i1
  %l83 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i1
  %l92 = alloca i1
  %l94 = alloca i32
  %l95 = alloca i1
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca i32
  %l102 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l109 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l118 = alloca i32
  %l129 = alloca i32
  %l132 = alloca i1
  %l135 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca ptr
  %l143 = alloca ptr
  %l146 = alloca i32
  %l147 = alloca ptr
  %l149 = alloca %"compiler/source:Span"
  %l150 = alloca ptr
  %l151 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca %"compiler/source:Span"
  %l160 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l165 = alloca ptr
  %l170 = alloca ptr
  %l175 = alloca i1
  %l176 = alloca i1
  %l178 = alloca i1
  %l187 = alloca i1
  %l189 = alloca i1
  %l192 = alloca i1
  %l193 = alloca i1
  %l197 = alloca i1
  %l206 = alloca ptr
  %l209 = alloca i1
  %l210 = alloca i1
  %l213 = alloca i1
  %l214 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i32
  %l218 = alloca { i64, ptr }
  %l219 = alloca i64
  %l223 = alloca i32
  %l232 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca %"compiler/source:Span"
  %l237 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l247 = alloca %"compiler/msgs:Msg"
  %l248 = alloca i64
  %l251 = alloca i1
  %l252 = alloca i32
  %l255 = alloca i32
  %l257 = alloca ptr
  %l260 = alloca i32
  %l263 = alloca i32
  %l264 = alloca i32
  %l265 = alloca ptr
  %l266 = alloca %"compiler/source:Span"
  %l269 = alloca { i64, ptr }
  %l270 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l277 = alloca { i64, ptr }
  %l279 = alloca %"compiler/msgs:Msg"
  %l280 = alloca i64
  %l281 = alloca ptr
  %l282 = alloca %"compiler/source:Span"
  %l283 = alloca %"compiler/source:Span"
  %l284 = alloca i32
  %l291 = alloca ptr
  %l293 = alloca ptr
  %l298 = alloca ptr
  %l299 = alloca %"compiler/source:Span"
  %l300 = alloca ptr
  %l305 = alloca ptr
  %l314 = alloca ptr
  %l318 = alloca %"compiler/check:litv"
  %l324 = alloca ptr
  %l326 = alloca ptr
  %l331 = alloca ptr
  %l333 = alloca %"compiler/source:Span"
  %l334 = alloca ptr
  %l337 = alloca i32
  %l340 = alloca i1
  %l343 = alloca i1
  %l344 = alloca ptr
  %l345 = alloca i32
  %l348 = alloca ptr
  %l350 = alloca %"compiler/source:Span"
  %l351 = alloca i1
  %l356 = alloca i1
  %l360 = alloca i1
  %l364 = alloca i1
  %l370 = alloca i1
  %l371 = alloca i1
  %l376 = alloca i1
  %l377 = alloca ptr
  %l379 = alloca %"compiler/source:Span"
  %l384 = alloca ptr
  %l386 = alloca ptr
  %l387 = alloca %"compiler/source:Span"
  %l390 = alloca { i64, ptr }
  %l391 = alloca { i64, ptr }
  %l394 = alloca { i64, ptr }
  %l395 = alloca { i64, ptr }
  %l398 = alloca { i64, ptr }
  %l400 = alloca %"compiler/msgs:Msg"
  %l401 = alloca i64
  %l402 = alloca ptr
  %l403 = alloca %"compiler/source:Span"
  %l404 = alloca ptr
  %l405 = alloca ptr
  %l406 = alloca %"compiler/source:Span"
  %l407 = alloca i32
  %l409 = alloca i32
  %l412 = alloca ptr
  %s4 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %t264 = alloca { i64, [4 x i64] }, align 8
  %t298 = alloca { i64, [3 x i64] }, align 8
  %t571 = alloca { i64, [4 x i64] }, align 8
  %t614 = alloca { i64, [3 x i64] }, align 8
  %t632 = alloca { i64, [4 x i64] }, align 8
  %t848 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t3 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassignAt(ptr %v0, ptr %v1, ptr %v2, ptr %t1, %"compiler/source:Span" %t2, i32 %t3, ptr %t4, ptr %t5)
  store i1 %t11, ptr %l27
  br label %bb1
bb1:
  %t12 = load i1, ptr %l27, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l28, !tbaa !29
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t14)
  store %"compiler/source:Span" %t16, ptr %l30
  br label %bb5
bb5:
  %t17 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t19 = trunc i64 62 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb6, label %bb7
bb6:
  store i64 1, ptr %l33, !tbaa !24
  br label %bb8
bb7:
  store i64 2, ptr %l33, !tbaa !24
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l28, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l30
  %t24 = load i64, ptr %l33, !tbaa !24
  %t25 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t22, %"compiler/source:Span" %t23, i64 %t24)
  store %"compiler/source:Span" %t25, ptr %l34
  br label %bb9
bb9:
  %t26 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t26, ptr %l5
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 48
  %t30 = load %"compiler/source:Span", ptr %t29
  store %"compiler/source:Span" %t30, ptr %l6
  %t32 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t34 = trunc i64 62 to i32
  %t35 = icmp eq i32 %t32, %t34
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l5
  %t43 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 48
  store %"compiler/source:Span" %t40, ptr %t43
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t47 = trunc i64 62 to i32
  %t48 = icmp eq i32 %t45, %t47
  %t51 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 11
  store i1 %t48, ptr %t51, !tbaa !21
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t52, ptr %t53)
  store ptr %t56, ptr %l47
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l47, !tbaa !29
  store ptr %t57, ptr %l7, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l6
  %t62 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 48
  store %"compiler/source:Span" %t59, ptr %t62
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t74 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t67, ptr %t68, i32 %t70)
  store ptr %t74, ptr %l56
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %ret
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t81 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvertedPlace(ptr %v0, ptr %v0, ptr %v1, ptr %t75, ptr %t76, ptr %t77)
  store i1 %t81, ptr %l60
  br label %bb18
bb18:
  %t82 = load i1, ptr %l60, !tbaa !21
  br i1 %t82, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l61, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t88 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t84, ptr %t85)
  store %"compiler/source:Span" %t88, ptr %l64
  br label %bb21
bb20:
  br label %bb25
bb21:
  %t89 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAssignable(ptr %s4)
  store %"compiler/msgs:Msg" %t89, ptr %l65
  br label %bb22
bb22:
  %t90 = load ptr, ptr %l61, !tbaa !29
  %t91 = load %"compiler/source:Span", ptr %l64
  %t92 = load %"compiler/msgs:Msg", ptr %l65
  %t93 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t90, %"compiler/source:Span" %t91, %"compiler/msgs:Msg" %t92)
  store i64 %t93, ptr %l66
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t94, ptr %t95, i32 %t97)
  store ptr %t101, ptr %l71
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb25:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l72, !tbaa !29
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t105 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t103)
  store %"compiler/source:Span" %t105, ptr %l74
  br label %bb26
bb26:
  %t106 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t108 = trunc i64 62 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb27, label %bb28
bb27:
  store i64 1, ptr %l77, !tbaa !24
  br label %bb29
bb28:
  store i64 2, ptr %l77, !tbaa !24
  br label %bb29
bb29:
  %t111 = load ptr, ptr %l72, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l74
  %t113 = load i64, ptr %l77, !tbaa !24
  %t114 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t111, %"compiler/source:Span" %t112, i64 %t113)
  store %"compiler/source:Span" %t114, ptr %l78
  br label %bb30
bb30:
  %t115 = load %"compiler/source:Span", ptr %l78
  store %"compiler/source:Span" %t115, ptr %l8
  %t116 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t118 = trunc i64 62 to i32
  %t119 = icmp eq i32 %t116, %t118
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb31, label %bb32
bb31:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l83, !tbaa !29
  %t124 = load ptr, ptr %l7, !tbaa !29
  %t126 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t124)
  store i32 %t126, ptr %l85
  br label %bb33
bb32:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb35
bb33:
  %t127 = load ptr, ptr %l83, !tbaa !29
  %t128 = load i32, ptr %l85, !tbaa !23
  %t129 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t127, i32 %t128)
  store i1 %t129, ptr %l86
  br label %bb34
bb34:
  %t130 = load i1, ptr %l86, !tbaa !21
  store i1 %t130, ptr %l82, !tbaa !21
  br label %bb35
bb35:
  %t131 = load i1, ptr %l82, !tbaa !21
  br i1 %t131, label %bb36, label %bb37
bb36:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l88, !tbaa !29
  %t133 = load ptr, ptr %l7, !tbaa !29
  %t135 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t133)
  store i32 %t135, ptr %l90
  br label %bb38
bb37:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb40
bb38:
  %t136 = load ptr, ptr %l88, !tbaa !29
  %t137 = load i32, ptr %l90, !tbaa !23
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t138, ptr %l91
  br label %bb39
bb39:
  %t139 = load i1, ptr %l91, !tbaa !21
  store i1 %t139, ptr %l87, !tbaa !21
  br label %bb40
bb40:
  %t140 = load i1, ptr %l87, !tbaa !21
  br i1 %t140, label %bb41, label %bb42
bb41:
  %t141 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t143 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t141)
  store i32 %t143, ptr %l94
  br label %bb43
bb42:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb45
bb43:
  %t144 = load i32, ptr %l94, !range !{i32 0, i32 98}
  %t145 = call i1 @compiler_2fcheck_2elaneTok(i32 %t144)
  store i1 %t145, ptr %l95
  br label %bb44
bb44:
  %t146 = load i1, ptr %l95, !tbaa !21
  store i1 %t146, ptr %l92, !tbaa !21
  br label %bb45
bb45:
  %t147 = load i1, ptr %l92, !tbaa !21
  store i1 %t147, ptr %l9, !tbaa !21
  %t148 = load i1, ptr %l9, !tbaa !21
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb46, label %bb47
bb46:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l99, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l100
  %t154 = load i32, ptr %l2, !range !{i32 0, i32 98}
  store i32 %t154, ptr %l101
  %t155 = load ptr, ptr %l7, !tbaa !29
  store ptr %t155, ptr %l102, !tbaa !29
  %t156 = load ptr, ptr %l4, !tbaa !29
  store ptr %t156, ptr %l104, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t158, ptr %l105
  %t159 = icmp sge i64 0, 0
  br i1 %t159, label %bb48, label %bb49
bb47:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb53
bb48:
  %t161 = icmp sle i64 0, 1152921504606846975
  br i1 %t161, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_d2a4873a2cff0127_7286b996ab1f319b)
  unreachable
bb50:
  %t163 = mul i64 0, 8
  %t164 = insertvalue { i64, ptr } undef, i64 0, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t166 = load ptr, ptr %l99, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l100
  %t168 = load i32, ptr %l101, !range !{i32 0, i32 98}
  %t169 = load ptr, ptr %l102, !tbaa !29
  %t170 = load ptr, ptr %l104, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l105
  %t173 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v0, ptr %v2, ptr %v0, ptr %t166, %"compiler/source:Span" %t167, i32 %t168, ptr %t169, ptr %t170, %"compiler/source:Span" %t171, i64 -1, { i64, ptr } %t165)
  store i1 %t173, ptr %l109
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_d2a4873a2cff0127_7286b996ab1f319b)
  unreachable
bb52:
  %t174 = load i1, ptr %l109, !tbaa !21
  store i1 %t174, ptr %l98, !tbaa !21
  br label %bb53
bb53:
  %t175 = load i1, ptr %l98, !tbaa !21
  br i1 %t175, label %bb54, label %bb55
bb54:
  br label %ret
bb55:
  br label %bb56
bb56:
  %t176 = load i1, ptr %l9, !tbaa !21
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb57, label %bb58
bb57:
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l112, !tbaa !29
  %t181 = load ptr, ptr %l7, !tbaa !29
  store ptr %t181, ptr %l113, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l3, !tbaa !29
  %t186 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteAt(ptr %v0, ptr %v1, ptr %t182, ptr %t183)
  store %"compiler/source:Span" %t186, ptr %l116
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t187 = load ptr, ptr %l112, !tbaa !29
  %t188 = load ptr, ptr %l113, !tbaa !29
  %t189 = load %"compiler/source:Span", ptr %l116
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v0, ptr %t187, ptr %t188, %"compiler/source:Span" %t189)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t190 = load ptr, ptr %l7, !tbaa !29
  %t192 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t190)
  store i32 %t192, ptr %l118
  br label %bb62
bb62:
  %t193 = load i32, ptr %l118, !tbaa !23
  store i32 %t193, ptr %l10, !tbaa !23
  %t194 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t196 = trunc i64 62 to i32
  %t197 = icmp eq i32 %t194, %t196
  br i1 %t197, label %bb63, label %bb64
bb63:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l1
  %t201 = load ptr, ptr %l7, !tbaa !29
  %t202 = load ptr, ptr %l4, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l8
  %t204 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreInto(ptr %v0, ptr %v0, ptr %v2, ptr %v1, ptr %t199, %"compiler/source:Span" %t200, ptr %t201, ptr %t202, %"compiler/source:Span" %t203, ptr %t204, i1 false)
  br label %bb65
bb64:
  br label %bb66
bb65:
  br label %ret
bb66:
  %t212 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t214 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t212)
  store i32 %t214, ptr %l129
  br label %bb67
bb67:
  %t215 = load i32, ptr %l129, !range !{i32 0, i32 98}
  store i32 %t215, ptr %l11
  %t216 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t218 = trunc i64 55 to i32
  %t219 = icmp eq i32 %t216, %t218
  br i1 %t219, label %bb68, label %bb69
bb68:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l10, !tbaa !23
  %t225 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t221, i32 %t222)
  store i1 %t225, ptr %l135
  br label %bb70
bb69:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb71
bb70:
  %t226 = load i1, ptr %l135, !tbaa !21
  %t227 = xor i1 %t226, true
  store i1 %t227, ptr %l132, !tbaa !21
  br label %bb71
bb71:
  %t229 = load i1, ptr %l132, !tbaa !21
  br i1 %t229, label %bb72, label %bb73
bb72:
  %t230 = load i32, ptr %l10, !tbaa !23
  %t231 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t234 = icmp eq i32 %t230, %t231
  br i1 %t234, label %bb74, label %bb75
bb73:
  br label %bb85
bb74:
  br label %ret
bb75:
  br label %bb76
bb76:
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l140, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l141, !tbaa !29
  %t238 = load ptr, ptr %l4, !tbaa !29
  store ptr %t238, ptr %l143, !tbaa !29
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l10, !tbaa !23
  %t244 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %t240, i32 %t241)
  store i32 %t244, ptr %l146
  br label %bb77
bb77:
  %t245 = load ptr, ptr %l141, !tbaa !29
  %t246 = load ptr, ptr %l143, !tbaa !29
  %t247 = load i32, ptr %l146, !tbaa !23
  %t248 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t245, ptr %t246, i32 %t247)
  store ptr %t248, ptr %l147
  br label %bb78
bb78:
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t251 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t249)
  store %"compiler/source:Span" %t251, ptr %l149
  br label %bb79
bb79:
  %t252 = load ptr, ptr %l140, !tbaa !29
  %t253 = load ptr, ptr %l147, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l149
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t252, ptr %t253, %"compiler/source:Span" %t254)
  store ptr %t255, ptr %l150
  br label %bb80
bb80:
  %t256 = load ptr, ptr %l150, !tbaa !29
  store ptr %t256, ptr %l12, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l151, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t258, ptr %l152
  %t259 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t259, ptr %l153
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l1
  %t262 = load %"compiler/source:Span", ptr %l1
  %t263 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t264
  %t265 = getelementptr { i64, [4 x i64] }, ptr %t264, i32 0, i32 0
  store i64 7, ptr %t265
  %t267 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t262, 0
  %t269 = insertvalue { %"compiler/source:Span", i32 } %t267, i32 %t263, 1
  %t270 = getelementptr { i64, [4 x i64] }, ptr %t264, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t269, ptr %t270
  %t271 = load { i64, [4 x i64] }, ptr %t264
  %t273 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t271, ptr %t273
  %t277 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t260, %"compiler/source:Span" %t261, ptr %t273)
  store ptr %t277, ptr %l160
  br label %bb81
bb81:
  %t278 = load ptr, ptr %l12, !tbaa !29
  %t279 = load ptr, ptr %l151, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l152
  %t281 = load %"compiler/source:Span", ptr %l153
  %t282 = load ptr, ptr %l160, !tbaa !29
  %t284 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t279, %"compiler/source:Span" %t280, %"compiler/source:Span" %t281, ptr %t282, ptr %t278)
  store ptr %t284, ptr %l162
  br label %bb82
bb82:
  %t285 = load ptr, ptr %l162, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  store ptr %t286, ptr %l163, !tbaa !29
  %t287 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t287, ptr %l164
  %t288 = load ptr, ptr %l7, !tbaa !29
  store ptr %t288, ptr %l165, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i32, ptr %l10, !tbaa !23
  %t292 = load %"compiler/source:Span", ptr %l1
  %t297 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t289, ptr %t285, i32 %t291, %"compiler/source:Span" %t292)
  store ptr %t297, ptr %l170
  br label %bb83
bb83:
  store { i64, [3 x i64] } zeroinitializer, ptr %t298
  %t299 = getelementptr { i64, [3 x i64] }, ptr %t298, i32 0, i32 0
  store i64 1, ptr %t299
  %t300 = load %"compiler/source:Span", ptr %l164
  %t301 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t300, 0
  %t302 = load ptr, ptr %l165, !tbaa !29
  %t303 = insertvalue { %"compiler/source:Span", ptr, ptr } %t301, ptr %t302, 1
  %t304 = load ptr, ptr %l170, !tbaa !29
  %t305 = insertvalue { %"compiler/source:Span", ptr, ptr } %t303, ptr %t304, 2
  %t306 = getelementptr { i64, [3 x i64] }, ptr %t298, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t305, ptr %t306
  %t307 = load { i64, [3 x i64] }, ptr %t298
  %t309 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t307, ptr %t309
  %t310 = load ptr, ptr %l163, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t310, ptr %t309)
  br label %bb84
bb84:
  br label %ret
bb85:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load i32, ptr %l10, !tbaa !23
  %t316 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t312, i32 %t313)
  store i1 %t316, ptr %l175
  br label %bb86
bb86:
  %t317 = load i1, ptr %l175, !tbaa !21
  br i1 %t317, label %bb87, label %bb88
bb87:
  %t318 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t320 = call i1 @compiler_2fcheck_2elaneTok(i32 %t318)
  store i1 %t320, ptr %l178
  br label %bb89
bb88:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb90
bb89:
  %t321 = load i1, ptr %l178, !tbaa !21
  store i1 %t321, ptr %l176, !tbaa !21
  br label %bb90
bb90:
  %t322 = load i1, ptr %l176, !tbaa !21
  br i1 %t322, label %bb91, label %bb92
bb91:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load %"compiler/source:Span", ptr %l1
  %t325 = load %"compiler/source:Span", ptr %l8
  %t326 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t327 = load ptr, ptr %l7, !tbaa !29
  %t328 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAssign(ptr %v0, ptr %v0, ptr %v2, ptr %t323, %"compiler/source:Span" %t324, %"compiler/source:Span" %t325, i32 %t326, ptr %t327, ptr %t328)
  br label %bb93
bb92:
  br label %bb94
bb93:
  br label %ret
bb94:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load i32, ptr %l10, !tbaa !23
  %t339 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t335, i32 %t336)
  store i1 %t339, ptr %l187
  br label %bb95
bb95:
  %t340 = load i1, ptr %l187, !tbaa !21
  %t341 = xor i1 %t340, true
  br i1 %t341, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l189, !tbaa !21
  br label %bb103
bb97:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l10, !tbaa !23
  %t347 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t343, i32 %t344)
  store i1 %t347, ptr %l192
  br label %bb98
bb98:
  %t348 = load i1, ptr %l192, !tbaa !21
  br i1 %t348, label %bb99, label %bb100
bb99:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/check:Checker", ptr %t349, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t353 = load i32, ptr %l10, !tbaa !23
  %t356 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t352, i32 %t353)
  store i1 %t356, ptr %l197
  br label %bb101
bb100:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb102
bb101:
  %t357 = load i1, ptr %l197, !tbaa !21
  %t358 = xor i1 %t357, true
  store i1 %t358, ptr %l193, !tbaa !21
  br label %bb102
bb102:
  %t360 = load i1, ptr %l193, !tbaa !21
  store i1 %t360, ptr %l189, !tbaa !21
  br label %bb103
bb103:
  %t361 = load i1, ptr %l189, !tbaa !21
  br i1 %t361, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s11
  %t362 = load i32, ptr %l10, !tbaa !23
  %t363 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t366 = icmp eq i32 %t362, %t363
  br i1 %t366, label %bb106, label %bb107
bb105:
  br label %bb158
bb106:
  call void @__olang_scope_close(ptr %s11)
  br label %ret
bb107:
  br label %bb108
bb108:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load ptr, ptr %l4, !tbaa !29
  %t371 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t375 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t368, ptr %t369, i32 %t371)
  store ptr %t375, ptr %l206
  br label %bb109
bb109:
  %t376 = load ptr, ptr %l206, !tbaa !29
  store ptr %t376, ptr %l14, !tbaa !29
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load i32, ptr %l10, !tbaa !23
  %t381 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t377, i32 %t378)
  store i1 %t381, ptr %l209
  br label %bb110
bb110:
  %t382 = load i1, ptr %l209, !tbaa !21
  br i1 %t382, label %bb111, label %bb112
bb111:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load i32, ptr %l10, !tbaa !23
  %t387 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t383, i32 %t384)
  store i1 %t387, ptr %l213
  br label %bb113
bb112:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb114
bb113:
  %t388 = load i1, ptr %l213, !tbaa !21
  store i1 %t388, ptr %l210, !tbaa !21
  br label %bb114
bb114:
  %t389 = load i1, ptr %l210, !tbaa !21
  br i1 %t389, label %bb115, label %bb116
bb115:
  %t390 = load ptr, ptr %l0, !tbaa !29
  store ptr %t390, ptr %l215, !tbaa !29
  %t391 = load i32, ptr %l10, !tbaa !23
  store i32 %t391, ptr %l216, !tbaa !23
  %t392 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t394 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s11, i32 %t392)
  store { i64, ptr } %t394, ptr %l218
  br label %bb117
bb116:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb119
bb117:
  %t395 = load ptr, ptr %l215, !tbaa !29
  %t396 = load i32, ptr %l216, !tbaa !23
  %t397 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t398 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s11, ptr %t395, i32 %t396, { i64, ptr } %t397, i64 1)
  store i64 %t398, ptr %l219
  br label %bb118
bb118:
  %t399 = load i64, ptr %l219, !tbaa !24
  %t400 = icmp slt i64 %t399, 0
  store i1 %t400, ptr %l214, !tbaa !21
  br label %bb119
bb119:
  %t402 = load i1, ptr %l214, !tbaa !21
  br i1 %t402, label %bb120, label %bb121
bb120:
  %t403 = load ptr, ptr %l14, !tbaa !29
  %t406 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t403)
  store i32 %t406, ptr %l223
  br label %bb122
bb121:
  br label %bb149
bb122:
  %t407 = load i32, ptr %l223, !tbaa !23
  store i32 %t407, ptr %l15, !tbaa !23
  %t408 = load i32, ptr %l15, !tbaa !23
  %t409 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t412 = icmp eq i32 %t408, %t409
  br i1 %t412, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s11)
  br label %ret
bb124:
  br label %bb125
bb125:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = getelementptr %"compiler/check:Checker", ptr %t414, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !29
  %t419 = getelementptr %"compiler/generic:Program", ptr %t417, i32 0, i32 2
  %t420 = load i32, ptr %l15, !tbaa !23
  %t421 = load i32, ptr %l10, !tbaa !23
  %t425 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t419, i32 %t420, i32 %t421)
  store i1 %t425, ptr %l232
  br label %bb126
bb126:
  %t426 = load i1, ptr %l232, !tbaa !21
  br i1 %t426, label %bb127, label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s15
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l233, !tbaa !29
  %t428 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t428, ptr %l234
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i32, ptr %l10, !tbaa !23
  %t433 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t429, i32 %t430)
  store { i64, ptr } %t433, ptr %l237
  br label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s17
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load ptr, ptr %l4, !tbaa !29
  %t438 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v2, ptr %t434, ptr %t435)
  store i1 %t438, ptr %l251
  br label %bb135
bb129:
  %t439 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t439, 0
  %t441 = extractvalue { i64, ptr } %t439, 1
  %t442 = mul i64 %t440, 1
  %t443 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t442)
  call void @llvm.memcpy.p0.p0.i64(ptr %t443, ptr %t441, i64 %t442, i1 false)
  %t444 = insertvalue { i64, ptr } undef, i64 %t440, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr %t443, 1
  store { i64, ptr } %t445, ptr %l238, !tbaa !27
  %t446 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t448 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s15, i32 %t446)
  store { i64, ptr } %t448, ptr %l240
  br label %bb130
bb130:
  %t449 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t450 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s15, ptr %s15, { i64, ptr } %t449)
  store { i64, ptr } %t450, ptr %l241
  br label %bb131
bb131:
  %t451 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 0
  %t453 = extractvalue { i64, ptr } %t451, 1
  %t454 = mul i64 %t452, 1
  %t455 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t454)
  call void @llvm.memcpy.p0.p0.i64(ptr %t455, ptr %t453, i64 %t454, i1 false)
  %t456 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t457 = insertvalue { i64, ptr } %t456, ptr %t455, 1
  store { i64, ptr } %t457, ptr %l242, !tbaa !27
  %t458 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t460 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s15, i32 %t458)
  store { i64, ptr } %t460, ptr %l244
  br label %bb132
bb132:
  %t461 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t463 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t463, 1
  %t465 = extractvalue { i64, ptr } %t463, 0
  %t466 = add i64 %t462, %t465
  %t467 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t468 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t469 = add i64 %t466, %t468
  %t470 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t469)
  call void @olang_textcopy(ptr %t470, ptr %t461, i64 %t462)
  %t471 = getelementptr i8, ptr %t470, i64 %t462
  call void @olang_textcopy(ptr %t471, ptr %t464, i64 %t465)
  %t472 = getelementptr i8, ptr %t471, i64 %t465
  call void @olang_textcopy(ptr %t472, ptr %t467, i64 %t468)
  %t473 = insertvalue { i64, ptr } undef, i64 %t469, 0
  %t474 = insertvalue { i64, ptr } %t473, ptr %t470, 1
  %t476 = extractvalue { i64, ptr } %t474, 0
  %t477 = extractvalue { i64, ptr } %t474, 1
  %t478 = mul i64 %t476, 1
  %t479 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t478)
  call void @llvm.memcpy.p0.p0.i64(ptr %t479, ptr %t477, i64 %t478, i1 false)
  %t480 = insertvalue { i64, ptr } undef, i64 %t476, 0
  %t481 = insertvalue { i64, ptr } %t480, ptr %t479, 1
  %t482 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t483 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t485 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %s15, ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t482, { i64, ptr } %t483, { i64, ptr } %t481)
  store %"compiler/msgs:Msg" %t485, ptr %l247
  br label %bb133
bb133:
  %t486 = load ptr, ptr %l233, !tbaa !29
  %t487 = load %"compiler/source:Span", ptr %l234
  %t488 = load %"compiler/msgs:Msg", ptr %l247
  %t489 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t486, %"compiler/source:Span" %t487, %"compiler/msgs:Msg" %t488)
  store i64 %t489, ptr %l248
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s15)
  br label %bb148
bb135:
  %t490 = load i1, ptr %l251, !tbaa !21
  br i1 %t490, label %bb136, label %bb137
bb136:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load i32, ptr %l10, !tbaa !23
  %t495 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t491, i32 %t492)
  store i32 %t495, ptr %l255
  br label %bb138
bb137:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/check:Checker", ptr %t496, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !29
  store ptr %t499, ptr %l257, !tbaa !29
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load i32, ptr %l10, !tbaa !23
  %t504 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t500, i32 %t501)
  store i32 %t504, ptr %l260
  br label %bb139
bb138:
  %t505 = load i32, ptr %l255, !tbaa !23
  store i32 %t505, ptr %l252, !tbaa !23
  br label %bb142
bb139:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load i32, ptr %l15, !tbaa !23
  %t510 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t506, i32 %t507)
  store i32 %t510, ptr %l263
  br label %bb140
bb140:
  %t511 = load ptr, ptr %l257, !tbaa !29
  %t512 = load i32, ptr %l260, !tbaa !23
  %t513 = load i32, ptr %l263, !tbaa !23
  %t514 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t511, i32 %t512, i32 %t513)
  store i32 %t514, ptr %l264
  br label %bb141
bb141:
  %t515 = load i32, ptr %l264, !tbaa !23
  store i32 %t515, ptr %l252, !tbaa !23
  br label %bb142
bb142:
  %t516 = load i32, ptr %l252, !tbaa !23
  %t517 = load ptr, ptr %l0, !tbaa !29
  store ptr %t517, ptr %l265, !tbaa !29
  %t518 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t518, ptr %l266
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t523 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s17, ptr %t519, i32 %t516)
  store { i64, ptr } %t523, ptr %l269
  br label %bb143
bb143:
  %t524 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t525 = extractvalue { i64, ptr } %t524, 0
  %t526 = extractvalue { i64, ptr } %t524, 1
  %t527 = mul i64 %t525, 1
  %t528 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t527)
  call void @llvm.memcpy.p0.p0.i64(ptr %t528, ptr %t526, i64 %t527, i1 false)
  %t529 = insertvalue { i64, ptr } undef, i64 %t525, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t528, 1
  store { i64, ptr } %t530, ptr %l270, !tbaa !27
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t532 = load i32, ptr %l10, !tbaa !23
  %t535 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s17, ptr %t531, i32 %t532)
  store { i64, ptr } %t535, ptr %l273
  br label %bb144
bb144:
  %t536 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t537 = extractvalue { i64, ptr } %t536, 0
  %t538 = extractvalue { i64, ptr } %t536, 1
  %t539 = mul i64 %t537, 1
  %t540 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t539)
  call void @llvm.memcpy.p0.p0.i64(ptr %t540, ptr %t538, i64 %t539, i1 false)
  %t541 = insertvalue { i64, ptr } undef, i64 %t537, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t540, 1
  store { i64, ptr } %t542, ptr %l274, !tbaa !27
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load i32, ptr %l10, !tbaa !23
  %t547 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s17, ptr %t543, i32 %t544)
  store { i64, ptr } %t547, ptr %l277
  br label %bb145
bb145:
  %t548 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t548, 0
  %t550 = extractvalue { i64, ptr } %t548, 1
  %t551 = mul i64 %t549, 1
  %t552 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t551)
  call void @llvm.memcpy.p0.p0.i64(ptr %t552, ptr %t550, i64 %t551, i1 false)
  %t553 = insertvalue { i64, ptr } undef, i64 %t549, 0
  %t554 = insertvalue { i64, ptr } %t553, ptr %t552, 1
  %t555 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t556 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t558 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumberDoesNotFlow(ptr %s17, ptr %s17, ptr %s17, ptr %s17, { i64, ptr } %t555, { i64, ptr } %t556, { i64, ptr } %t554)
  store %"compiler/msgs:Msg" %t558, ptr %l279
  br label %bb146
bb146:
  %t559 = load ptr, ptr %l265, !tbaa !29
  %t560 = load %"compiler/source:Span", ptr %l266
  %t561 = load %"compiler/msgs:Msg", ptr %l279
  %t562 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t559, %"compiler/source:Span" %t560, %"compiler/msgs:Msg" %t561)
  store i64 %t562, ptr %l280
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s17)
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s11)
  br label %ret
bb149:
  %t563 = load ptr, ptr %l0, !tbaa !29
  store ptr %t563, ptr %l281, !tbaa !29
  %t564 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t564, ptr %l282
  %t565 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t565, ptr %l283
  %t566 = load i32, ptr %l11, !range !{i32 0, i32 98}
  store i32 %t566, ptr %l284
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load %"compiler/source:Span", ptr %l1
  %t569 = load %"compiler/source:Span", ptr %l1
  %t570 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t571
  %t572 = getelementptr { i64, [4 x i64] }, ptr %t571, i32 0, i32 0
  store i64 7, ptr %t572
  %t574 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t569, 0
  %t576 = insertvalue { %"compiler/source:Span", i32 } %t574, i32 %t570, 1
  %t577 = getelementptr { i64, [4 x i64] }, ptr %t571, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t576, ptr %t577
  %t578 = load { i64, [4 x i64] }, ptr %t571
  %t580 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t578, ptr %t580
  %t584 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t567, %"compiler/source:Span" %t568, ptr %t580)
  store ptr %t584, ptr %l291
  br label %bb150
bb150:
  %t585 = load ptr, ptr %l14, !tbaa !29
  %t586 = load ptr, ptr %l281, !tbaa !29
  %t587 = load %"compiler/source:Span", ptr %l282
  %t588 = load %"compiler/source:Span", ptr %l283
  %t589 = load i32, ptr %l284, !range !{i32 0, i32 98}
  %t590 = load ptr, ptr %l291, !tbaa !29
  %t592 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t586, %"compiler/source:Span" %t587, %"compiler/source:Span" %t588, i32 %t589, ptr %t590, ptr %t585)
  store ptr %t592, ptr %l293
  br label %bb151
bb151:
  %t593 = load ptr, ptr %l293, !tbaa !29
  store ptr %t593, ptr %l17, !tbaa !29
  %t594 = load ptr, ptr %l17, !tbaa !29
  %t596 = icmp eq ptr %t594, null
  br i1 %t596, label %bb152, label %bb153
bb152:
  store %olang.scope zeroinitializer, ptr %s18
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s18, ptr %t598, %"compiler/source:Span" %t599, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb154
bb153:
  br label %bb155
bb154:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s11)
  br label %ret
bb155:
  %t602 = load ptr, ptr %l0, !tbaa !29
  store ptr %t602, ptr %l298, !tbaa !29
  %t603 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t603, ptr %l299
  %t604 = load ptr, ptr %l7, !tbaa !29
  store ptr %t604, ptr %l300, !tbaa !29
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load ptr, ptr %l17, !tbaa !29
  %t607 = load i32, ptr %l10, !tbaa !23
  %t608 = load %"compiler/source:Span", ptr %l1
  %t613 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t605, ptr %t606, i32 %t607, %"compiler/source:Span" %t608)
  store ptr %t613, ptr %l305
  br label %bb156
bb156:
  store { i64, [3 x i64] } zeroinitializer, ptr %t614
  %t615 = getelementptr { i64, [3 x i64] }, ptr %t614, i32 0, i32 0
  store i64 1, ptr %t615
  %t616 = load %"compiler/source:Span", ptr %l299
  %t617 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t616, 0
  %t618 = load ptr, ptr %l300, !tbaa !29
  %t619 = insertvalue { %"compiler/source:Span", ptr, ptr } %t617, ptr %t618, 1
  %t620 = load ptr, ptr %l305, !tbaa !29
  %t621 = insertvalue { %"compiler/source:Span", ptr, ptr } %t619, ptr %t620, 2
  %t622 = getelementptr { i64, [3 x i64] }, ptr %t614, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t621, ptr %t622
  %t623 = load { i64, [3 x i64] }, ptr %t614
  %t625 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t623, ptr %t625
  %t626 = load ptr, ptr %l298, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t626, ptr %t625)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s11)
  br label %ret
bb158:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load %"compiler/source:Span", ptr %l1
  %t630 = load %"compiler/source:Span", ptr %l1
  %t631 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t632
  %t633 = getelementptr { i64, [4 x i64] }, ptr %t632, i32 0, i32 0
  store i64 7, ptr %t633
  %t635 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t630, 0
  %t637 = insertvalue { %"compiler/source:Span", i32 } %t635, i32 %t631, 1
  %t638 = getelementptr { i64, [4 x i64] }, ptr %t632, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t637, ptr %t638
  %t639 = load { i64, [4 x i64] }, ptr %t632
  %t641 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t639, ptr %t641
  %t645 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t628, %"compiler/source:Span" %t629, ptr %t641)
  store ptr %t645, ptr %l314
  br label %bb159
bb159:
  %t646 = load ptr, ptr %l314, !tbaa !29
  store ptr %t646, ptr %l18, !tbaa !29
  store ptr null, ptr %l19, !tbaa !29
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t648 = load ptr, ptr %l4, !tbaa !29
  %t652 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v2, ptr %t647, ptr %t648)
  store %"compiler/check:litv" %t652, ptr %l318
  br label %bb160
bb160:
  %t653 = load %"compiler/check:litv", ptr %l318
  store %"compiler/check:litv" %t653, ptr %l20
  %t654 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 0
  %t655 = load i1, ptr %t654, !tbaa !21
  br i1 %t655, label %bb161, label %bb162
bb161:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load ptr, ptr %l4, !tbaa !29
  %t659 = load %"compiler/check:litv", ptr %l20
  %t660 = load i32, ptr %l10, !tbaa !23
  %t665 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v2, ptr %v0, ptr %t657, ptr %t658, %"compiler/check:litv" %t659, i32 %t660)
  store ptr %t665, ptr %l324
  br label %bb163
bb162:
  %t666 = load ptr, ptr %l0, !tbaa !29
  store ptr %t666, ptr %l326, !tbaa !29
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t668 = load ptr, ptr %l4, !tbaa !29
  %t670 = load i32, ptr %l10, !tbaa !23
  %t674 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t667, ptr %t668, i32 %t670)
  store ptr %t674, ptr %l331
  br label %bb164
bb163:
  %t675 = load ptr, ptr %l324, !tbaa !29
  store ptr %t675, ptr %l19, !tbaa !29
  br label %bb167
bb164:
  %t677 = load ptr, ptr %l4, !tbaa !29
  %t679 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t677)
  store %"compiler/source:Span" %t679, ptr %l333
  br label %bb165
bb165:
  %t680 = load ptr, ptr %l326, !tbaa !29
  %t681 = load ptr, ptr %l331, !tbaa !29
  %t682 = load %"compiler/source:Span", ptr %l333
  %t683 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t680, ptr %t681, %"compiler/source:Span" %t682)
  store ptr %t683, ptr %l334
  br label %bb166
bb166:
  %t684 = load ptr, ptr %l334, !tbaa !29
  store ptr %t684, ptr %l19, !tbaa !29
  br label %bb167
bb167:
  %t686 = load ptr, ptr %l19, !tbaa !29
  %t688 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t686)
  store i32 %t688, ptr %l337
  br label %bb168
bb168:
  %t689 = load i32, ptr %l337, !tbaa !23
  store i32 %t689, ptr %l21, !tbaa !23
  %t690 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t692 = trunc i64 90 to i32
  %t693 = icmp eq i32 %t690, %t692
  br i1 %t693, label %bb169, label %bb170
bb169:
  store i1 true, ptr %l340, !tbaa !21
  br label %bb171
bb170:
  %t695 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t697 = trunc i64 91 to i32
  %t698 = icmp eq i32 %t695, %t697
  store i1 %t698, ptr %l340, !tbaa !21
  br label %bb171
bb171:
  %t700 = load i1, ptr %l340, !tbaa !21
  br i1 %t700, label %bb172, label %bb173
bb172:
  %t701 = load ptr, ptr %l0, !tbaa !29
  store ptr %t701, ptr %l344, !tbaa !29
  %t702 = load i32, ptr %l10, !tbaa !23
  store i32 %t702, ptr %l345, !tbaa !23
  %t703 = load ptr, ptr %l19, !tbaa !29
  %t705 = icmp eq ptr %t703, null
  br i1 %t705, label %bb174, label %bb175
bb173:
  store i1 false, ptr %l343, !tbaa !21
  br label %bb179
bb174:
  call void @__olang_check_failed(ptr @olang_loc_5957a34f5d629e92_b1985d6017512bae)
  unreachable
bb175:
  br label %bb176
bb176:
  %t707 = load ptr, ptr %l19, !tbaa !29
  store ptr %t707, ptr %l348, !tbaa !29
  %t708 = load ptr, ptr %l4, !tbaa !29
  %t710 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t708)
  store %"compiler/source:Span" %t710, ptr %l350
  br label %bb177
bb177:
  %t711 = load ptr, ptr %l344, !tbaa !29
  %t712 = load i32, ptr %l345, !tbaa !23
  %t713 = load ptr, ptr %l348, !tbaa !29
  %t714 = load %"compiler/source:Span", ptr %l350
  %t715 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftInRange(ptr %v0, ptr %v0, ptr %t711, i32 %t712, ptr %t713, %"compiler/source:Span" %t714)
  store i1 %t715, ptr %l351
  br label %bb178
bb178:
  %t716 = load i1, ptr %l351, !tbaa !21
  %t717 = xor i1 %t716, true
  store i1 %t717, ptr %l343, !tbaa !21
  br label %bb179
bb179:
  %t719 = load i1, ptr %l343, !tbaa !21
  br i1 %t719, label %bb180, label %bb181
bb180:
  br label %ret
bb181:
  br label %bb182
bb182:
  %t720 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t722 = trunc i64 90 to i32
  %t723 = icmp eq i32 %t720, %t722
  %t725 = xor i1 %t723, true
  br i1 %t725, label %bb183, label %bb184
bb183:
  %t727 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t729 = trunc i64 91 to i32
  %t730 = icmp eq i32 %t727, %t729
  %t732 = xor i1 %t730, true
  store i1 %t732, ptr %l356, !tbaa !21
  br label %bb185
bb184:
  store i1 false, ptr %l356, !tbaa !21
  br label %bb185
bb185:
  %t734 = load i1, ptr %l356, !tbaa !21
  br i1 %t734, label %bb186, label %bb187
bb186:
  %t735 = load i32, ptr %l21, !tbaa !23
  %t736 = load i32, ptr %l10, !tbaa !23
  %t739 = icmp ne i32 %t735, %t736
  store i1 %t739, ptr %l360, !tbaa !21
  br label %bb188
bb187:
  store i1 false, ptr %l360, !tbaa !21
  br label %bb188
bb188:
  %t741 = load i1, ptr %l360, !tbaa !21
  br i1 %t741, label %bb189, label %bb190
bb189:
  %t742 = load i32, ptr %l21, !tbaa !23
  %t743 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t746 = icmp ne i32 %t742, %t743
  store i1 %t746, ptr %l364, !tbaa !21
  br label %bb191
bb190:
  store i1 false, ptr %l364, !tbaa !21
  br label %bb191
bb191:
  %t748 = load i1, ptr %l364, !tbaa !21
  br i1 %t748, label %bb192, label %bb193
bb192:
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t750 = load i32, ptr %l21, !tbaa !23
  %t753 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t749, i32 %t750)
  store i1 %t753, ptr %l370
  br label %bb194
bb193:
  br label %bb212
bb194:
  %t754 = load i1, ptr %l370, !tbaa !21
  br i1 %t754, label %bb195, label %bb196
bb195:
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t757 = getelementptr %"compiler/check:Checker", ptr %t755, i32 0, i32 1
  %t758 = load ptr, ptr %t757, !tbaa !29
  %t759 = load i32, ptr %l21, !tbaa !23
  %t760 = load i32, ptr %l10, !tbaa !23
  %t764 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t758, i32 %t759, i32 %t760)
  store i1 %t764, ptr %l376
  br label %bb197
bb196:
  store i1 false, ptr %l371, !tbaa !21
  br label %bb198
bb197:
  %t765 = load i1, ptr %l376, !tbaa !21
  store i1 %t765, ptr %l371, !tbaa !21
  br label %bb198
bb198:
  %t766 = load i1, ptr %l371, !tbaa !21
  br i1 %t766, label %bb199, label %bb200
bb199:
  %t767 = load ptr, ptr %l0, !tbaa !29
  store ptr %t767, ptr %l377, !tbaa !29
  %t768 = load ptr, ptr %l4, !tbaa !29
  %t770 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t768)
  store %"compiler/source:Span" %t770, ptr %l379
  br label %bb201
bb200:
  store %olang.scope zeroinitializer, ptr %s24
  %t771 = load ptr, ptr %l0, !tbaa !29
  store ptr %t771, ptr %l386, !tbaa !29
  %t772 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t772, ptr %l387
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t774 = load i32, ptr %l21, !tbaa !23
  %t777 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s24, ptr %t773, i32 %t774)
  store { i64, ptr } %t777, ptr %l390
  br label %bb206
bb201:
  %t778 = load ptr, ptr %l19, !tbaa !29
  %t780 = icmp eq ptr %t778, null
  br i1 %t780, label %bb202, label %bb203
bb202:
  call void @__olang_check_failed(ptr @olang_loc_211eb8206518cfd3_dabae8ca263a8cdf)
  unreachable
bb203:
  br label %bb204
bb204:
  %t782 = load ptr, ptr %l19, !tbaa !29
  %t783 = load i32, ptr %l10, !tbaa !23
  %t784 = load ptr, ptr %l377, !tbaa !29
  %t785 = load %"compiler/source:Span", ptr %l379
  %t788 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v0, ptr %v0, ptr %t784, %"compiler/source:Span" %t785, ptr %t782, i32 %t783)
  store ptr %t788, ptr %l384
  br label %bb205
bb205:
  %t789 = load ptr, ptr %l384, !tbaa !29
  store ptr %t789, ptr %l19, !tbaa !29
  br label %bb211
bb206:
  %t791 = load { i64, ptr }, ptr %l390, !tbaa !27
  %t792 = extractvalue { i64, ptr } %t791, 0
  %t793 = extractvalue { i64, ptr } %t791, 1
  %t794 = mul i64 %t792, 1
  %t795 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t794)
  call void @llvm.memcpy.p0.p0.i64(ptr %t795, ptr %t793, i64 %t794, i1 false)
  %t796 = insertvalue { i64, ptr } undef, i64 %t792, 0
  %t797 = insertvalue { i64, ptr } %t796, ptr %t795, 1
  store { i64, ptr } %t797, ptr %l391, !tbaa !27
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t799 = load i32, ptr %l10, !tbaa !23
  %t802 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s24, ptr %t798, i32 %t799)
  store { i64, ptr } %t802, ptr %l394
  br label %bb207
bb207:
  %t803 = load { i64, ptr }, ptr %l394, !tbaa !27
  %t804 = extractvalue { i64, ptr } %t803, 0
  %t805 = extractvalue { i64, ptr } %t803, 1
  %t806 = mul i64 %t804, 1
  %t807 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t806)
  call void @llvm.memcpy.p0.p0.i64(ptr %t807, ptr %t805, i64 %t806, i1 false)
  %t808 = insertvalue { i64, ptr } undef, i64 %t804, 0
  %t809 = insertvalue { i64, ptr } %t808, ptr %t807, 1
  store { i64, ptr } %t809, ptr %l395, !tbaa !27
  %t810 = load ptr, ptr %l0, !tbaa !29
  %t811 = load i32, ptr %l10, !tbaa !23
  %t814 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s24, ptr %t810, i32 %t811)
  store { i64, ptr } %t814, ptr %l398
  br label %bb208
bb208:
  %t815 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t816 = extractvalue { i64, ptr } %t815, 0
  %t817 = extractvalue { i64, ptr } %t815, 1
  %t818 = mul i64 %t816, 1
  %t819 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t818)
  call void @llvm.memcpy.p0.p0.i64(ptr %t819, ptr %t817, i64 %t818, i1 false)
  %t820 = insertvalue { i64, ptr } undef, i64 %t816, 0
  %t821 = insertvalue { i64, ptr } %t820, ptr %t819, 1
  %t822 = load { i64, ptr }, ptr %l391, !tbaa !27
  %t823 = load { i64, ptr }, ptr %l395, !tbaa !27
  %t825 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumberDoesNotFlow(ptr %s24, ptr %s24, ptr %s24, ptr %s24, { i64, ptr } %t822, { i64, ptr } %t823, { i64, ptr } %t821)
  store %"compiler/msgs:Msg" %t825, ptr %l400
  br label %bb209
bb209:
  %t826 = load ptr, ptr %l386, !tbaa !29
  %t827 = load %"compiler/source:Span", ptr %l387
  %t828 = load %"compiler/msgs:Msg", ptr %l400
  %t829 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s24, ptr %t826, %"compiler/source:Span" %t827, %"compiler/msgs:Msg" %t828)
  store i64 %t829, ptr %l401
  br label %bb210
bb210:
  call void @__olang_scope_close(ptr %s24)
  br label %bb211
bb211:
  br label %bb212
bb212:
  %t830 = load ptr, ptr %l0, !tbaa !29
  store ptr %t830, ptr %l402, !tbaa !29
  %t831 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t831, ptr %l403
  %t832 = load ptr, ptr %l7, !tbaa !29
  store ptr %t832, ptr %l404, !tbaa !29
  %t833 = load ptr, ptr %l0, !tbaa !29
  store ptr %t833, ptr %l405, !tbaa !29
  %t834 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t834, ptr %l406
  %t835 = load i32, ptr %l10, !tbaa !23
  store i32 %t835, ptr %l407, !tbaa !23
  %t836 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t838 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t836)
  store i32 %t838, ptr %l409
  br label %bb213
bb213:
  %t839 = load ptr, ptr %l18, !tbaa !29
  %t840 = load ptr, ptr %l19, !tbaa !29
  %t841 = load ptr, ptr %l405, !tbaa !29
  %t842 = load %"compiler/source:Span", ptr %l406
  %t843 = load i32, ptr %l407, !tbaa !23
  %t844 = load i32, ptr %l409, !range !{i32 0, i32 44}
  %t847 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t841, %"compiler/source:Span" %t842, i32 %t843, i32 %t844, ptr %t839, ptr %t840)
  store ptr %t847, ptr %l412
  br label %bb214
bb214:
  store { i64, [3 x i64] } zeroinitializer, ptr %t848
  %t849 = getelementptr { i64, [3 x i64] }, ptr %t848, i32 0, i32 0
  store i64 1, ptr %t849
  %t850 = load %"compiler/source:Span", ptr %l403
  %t851 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t850, 0
  %t852 = load ptr, ptr %l404, !tbaa !29
  %t853 = insertvalue { %"compiler/source:Span", ptr, ptr } %t851, ptr %t852, 1
  %t854 = load ptr, ptr %l412, !tbaa !29
  %t855 = insertvalue { %"compiler/source:Span", ptr, ptr } %t853, ptr %t854, 2
  %t856 = getelementptr { i64, [3 x i64] }, ptr %t848, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t855, ptr %t856
  %t857 = load { i64, [3 x i64] }, ptr %t848
  %t859 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t857, ptr %t859
  %t860 = load ptr, ptr %l402, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t860, ptr %t859)
  br label %bb215
bb215:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrRead(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { ptr, { i64, ptr }, %"compiler/source:Span" }
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, i32 }
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca { ptr, { i64, ptr }, %"compiler/source:Span" }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca i1
  %l28 = alloca i32
  %l35 = alloca i1
  %l39 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l49 = alloca %"compiler/msgs:Msg"
  %l50 = alloca i64
  %l55 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l61 = alloca i32
  %l67 = alloca ptr
  %l72 = alloca { i64, i32 }
  %l76 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca i32
  %l82 = alloca i64
  %l83 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca %"compiler/source:Span"
  %l92 = alloca i64
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca i32
  %l103 = alloca ptr
  %l105 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca i1
  %l113 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca %"compiler/source:Span"
  %l121 = alloca i32
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca %"compiler/source:Span"
  %l132 = alloca i64
  %l135 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l141 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t182 = alloca i64
  %t233 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { ptr, { i64, ptr }, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrCallee(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a2)
  store { ptr, { i64, ptr }, %"compiler/source:Span" } %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l17
  store { ptr, { i64, ptr }, %"compiler/source:Span" } %t6, ptr %l5
  %t7 = getelementptr { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l6, !tbaa !29
  %t10 = getelementptr { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l5, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l19, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l20, !tbaa !24
  %t14 = load i64, ptr %l20, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l21, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l20, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t25, ptr %l7, !tbaa !27
  %t26 = getelementptr { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l5, i32 0, i32 2
  %t27 = load %"compiler/source:Span", ptr %t26
  store %"compiler/source:Span" %t27, ptr %l8
  %t29 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t31, ptr %l24
  br label %bb2
bb2:
  %t32 = load i1, ptr %l24, !tbaa !21
  br i1 %t32, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l6, !tbaa !29
  %t38 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrHolder(ptr %v0, ptr %s0, ptr %t34, ptr %t35)
  store i32 %t38, ptr %l28
  br label %bb6
bb6:
  %t39 = load i32, ptr %l28, !tbaa !23
  store i32 %t39, ptr %l9, !tbaa !23
  %t40 = load i32, ptr %l9, !tbaa !23
  %t42 = icmp slt i32 %t40, 0
  br i1 %t42, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t45 = load i32, ptr %l9, !tbaa !23
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t49 = icmp eq i32 %t45, %t46
  br i1 %t49, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb12
bb11:
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t55 = icmp ne i64 %t53, 1
  store i1 %t55, ptr %l35, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb15
bb14:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t62 = icmp ne i64 %t60, 0
  store i1 %t62, ptr %l39, !tbaa !21
  br label %bb15
bb15:
  %t64 = load i1, ptr %l39, !tbaa !21
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t65 = load i32, ptr %l9, !tbaa !23
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t69 = icmp ne i32 %t65, %t66
  br i1 %t69, label %bb18, label %bb19
bb17:
  br label %bb25
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l46, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t72, ptr %l47
  %t73 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t75 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAttrRead(ptr %s0, ptr %s4, { i64, ptr } %t73)
  store %"compiler/msgs:Msg" %t75, ptr %l49
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t76 = load ptr, ptr %l46, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l47
  %t78 = load %"compiler/msgs:Msg", ptr %l49
  %t79 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t76, %"compiler/source:Span" %t77, %"compiler/msgs:Msg" %t78)
  store i64 %t79, ptr %l50
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t80, { i64, ptr } %t81)
  br label %bb23
bb23:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t84, %"compiler/source:Span" %t85)
  store ptr %t88, ptr %l55
  br label %bb24
bb24:
  %t89 = load ptr, ptr %l55, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t89, ptr %rv
  br label %ret
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t92, ptr %l58, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr ptr, ptr %t94, i64 0
  %t96 = load ptr, ptr %t95, !tbaa !39
  %t100 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v2, ptr %t91, ptr %t96)
  store i32 %t100, ptr %l61
  br label %bb26
bb26:
  %t101 = load i32, ptr %l61, !tbaa !23
  store i32 %t101, ptr %l10, !tbaa !23
  %t102 = load i32, ptr %l10, !tbaa !23
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t106 = icmp eq i32 %t102, %t103
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t108, %"compiler/source:Span" %t109)
  store ptr %t112, ptr %l67
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t113 = load ptr, ptr %l67, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t113, ptr %rv
  br label %ret
bb30:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l9, !tbaa !23
  %t117 = load i32, ptr %l10, !tbaa !23
  %t121 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrFound(ptr %v0, ptr %t115, i32 %t116, i32 %t117)
  store { i64, i32 } %t121, ptr %l72
  br label %bb31
bb31:
  %t122 = load { i64, i32 }, ptr %l72
  store { i64, i32 } %t122, ptr %l11
  %t123 = getelementptr { i64, i32 }, ptr %l11, i32 0, i32 0
  %t124 = load i64, ptr %t123, !tbaa !24
  store i64 %t124, ptr %l12, !tbaa !24
  %t126 = getelementptr { i64, i32 }, ptr %l11, i32 0, i32 1
  %t127 = load i32, ptr %t126, !tbaa !23
  store i32 %t127, ptr %l13, !tbaa !23
  %t129 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t129, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t131, ptr %l76
  br label %bb32
bb32:
  %t132 = load i1, ptr %l76, !tbaa !21
  br i1 %t132, label %bb33, label %bb34
bb33:
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l77, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t134, ptr %l78
  %t135 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t135, ptr %l79, !tbaa !23
  %t136 = load i64, ptr %l12, !tbaa !24
  %t138 = icmp sge i64 %t136, 0
  br i1 %t138, label %bb35, label %bb36
bb34:
  br label %bb39
bb35:
  store i64 1, ptr %l82, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb37
bb37:
  %t140 = load ptr, ptr %l77, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l78
  %t142 = load i32, ptr %l79, !tbaa !23
  %t143 = load i64, ptr %l82, !tbaa !24
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t140, %"compiler/source:Span" %t141, i32 %t142, i64 %t143)
  store ptr %t144, ptr %l83
  br label %bb38
bb38:
  %t145 = load ptr, ptr %l83, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t145, ptr %rv
  br label %ret
bb39:
  %t147 = load i64, ptr %l12, !tbaa !24
  %t149 = icmp slt i64 %t147, 0
  br i1 %t149, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l87, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t152, ptr %l88
  %t153 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t153, ptr %l89
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeFn(ptr %v0, ptr %s7, ptr %s7, ptr %t157, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i64 %t159, ptr %l92
  br label %bb42
bb41:
  br label %bb56
bb42:
  %t160 = icmp sge i64 0, 0
  br i1 %t160, label %bb43, label %bb44
bb43:
  %t162 = icmp sle i64 0, 1152921504606846975
  br i1 %t162, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_f2dfd4e2b2620e71_dbe725d38eafc295)
  unreachable
bb45:
  %t164 = mul i64 0, 8
  %t165 = insertvalue { i64, ptr } undef, i64 0, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t166, ptr %l95, !tbaa !27
  %t167 = icmp sge i64 0, 0
  br i1 %t167, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_f2dfd4e2b2620e71_dbe725d38eafc295)
  unreachable
bb47:
  %t169 = icmp sle i64 0, 1152921504606846975
  br i1 %t169, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_f2dfd4e2b2620e71_dbe725d38eafc295)
  unreachable
bb49:
  %t171 = mul i64 0, 8
  %t172 = insertvalue { i64, ptr } undef, i64 0, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t173, ptr %l98, !tbaa !27
  %t174 = load i32, ptr %l10, !tbaa !23
  store i32 %t174, ptr %l99, !tbaa !23
  %t175 = icmp sge i64 1, 0
  br i1 %t175, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_f2dfd4e2b2620e71_dbe725d38eafc295)
  unreachable
bb51:
  %t177 = icmp sle i64 1, 2305843009213693951
  br i1 %t177, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_f2dfd4e2b2620e71_dbe725d38eafc295)
  unreachable
bb53:
  %t179 = mul i64 1, 4
  %t180 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t179)
  %t181 = load i32, ptr %l99, !tbaa !23
  store i64 0, ptr %t182
  br label %fill.183
fill.183:
  %t186 = load i64, ptr %t182
  %t187 = icmp slt i64 %t186, 1
  br i1 %t187, label %fillb.184, label %filld.185
fillb.184:
  %t188 = getelementptr i32, ptr %t180, i64 %t186
  store i32 %t181, ptr %t188
  %t189 = add i64 %t186, 1
  store i64 %t189, ptr %t182
  br label %fill.183
filld.185:
  %t190 = insertvalue { i64, ptr } undef, i64 1, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t180, 1
  %t192 = load ptr, ptr %l87, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l88
  %t194 = load %"compiler/source:Span", ptr %l89
  %t195 = load i64, ptr %l92, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t199 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v4, ptr %v4, ptr %t192, %"compiler/source:Span" %t193, %"compiler/source:Span" %t194, i64 %t195, ptr null, { i64, ptr } %t196, { i64, ptr } %t197, { i64, ptr } %t191)
  store ptr %t199, ptr %l103
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_f2dfd4e2b2620e71_dbe725d38eafc295)
  unreachable
bb55:
  %t200 = load ptr, ptr %l103, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t200, ptr %rv
  br label %ret
bb56:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l105, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i64, ptr %l12, !tbaa !24
  %t205 = load i32, ptr %l13, !tbaa !23
  %t209 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t203, i64 %t204, i32 %t205)
  store i32 %t209, ptr %l109
  br label %bb57
bb57:
  %t210 = load ptr, ptr %l105, !tbaa !29
  %t211 = load i32, ptr %l109, !tbaa !23
  %t212 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t210, i32 %t211)
  store i1 %t212, ptr %l110
  br label %bb58
bb58:
  %t213 = load i1, ptr %l110, !tbaa !21
  br i1 %t213, label %bb59, label %bb60
bb59:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l1
  %t218 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t214, %"compiler/source:Span" %t215)
  store ptr %t218, ptr %l113
  br label %bb61
bb60:
  br label %bb62
bb61:
  %t219 = load ptr, ptr %l113, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t219, ptr %rv
  br label %ret
bb62:
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l115, !tbaa !29
  %t222 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t222, ptr %l116
  %t223 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t223, ptr %l117
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load i64, ptr %l12, !tbaa !24
  %t226 = load i32, ptr %l13, !tbaa !23
  %t230 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t224, i64 %t225, i32 %t226)
  store i32 %t230, ptr %l121
  br label %bb63
bb63:
  %t231 = load i64, ptr %l12, !tbaa !24
  %t232 = load i32, ptr %l13, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t233
  %t234 = getelementptr { i64, [4 x i64] }, ptr %t233, i32 0, i32 0
  store i64 1, ptr %t234
  %t235 = load %"compiler/source:Span", ptr %l117
  %t236 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t235, 0
  %t237 = load i32, ptr %l121, !tbaa !23
  %t238 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t236, i32 %t237, 1
  %t240 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t238, i64 %t231, 2
  %t242 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t240, i32 %t232, 3
  %t243 = getelementptr { i64, [4 x i64] }, ptr %t233, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t242, ptr %t243
  %t244 = load { i64, [4 x i64] }, ptr %t233
  %t246 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store { i64, [4 x i64] } %t244, ptr %t246
  %t247 = load ptr, ptr %l115, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l116
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v4, ptr %v4, ptr %t247, %"compiler/source:Span" %t248, ptr %t246)
  store ptr %t250, ptr %l126
  br label %bb64
bb64:
  %t251 = load ptr, ptr %l126, !tbaa !29
  store ptr %t251, ptr %l14, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l127, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t253, ptr %l128
  %t254 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t254, ptr %l129
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/check:Checker", ptr %t255, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t260 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeFn(ptr %v0, ptr %s0, ptr %s0, ptr %t258, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i64 %t260, ptr %l132
  br label %bb65
bb65:
  %t261 = icmp sge i64 0, 0
  br i1 %t261, label %bb66, label %bb67
bb66:
  %t263 = icmp sle i64 0, 1152921504606846975
  br i1 %t263, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_f2b973fcab239364_d01bf2cd68c3b6a8)
  unreachable
bb68:
  %t265 = mul i64 0, 8
  %t266 = insertvalue { i64, ptr } undef, i64 0, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t267, ptr %l135, !tbaa !27
  %t268 = load ptr, ptr %l14, !tbaa !29
  %t269 = mul i64 1, 8
  %t270 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t269)
  %t271 = insertvalue { i64, ptr } undef, i64 1, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t270, 1
  store { i64, ptr } %t272, ptr %l137, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr ptr, ptr %t275, i64 0
  store ptr %t268, ptr %t276, !tbaa !39
  %t277 = icmp sge i64 0, 0
  br i1 %t277, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_f2b973fcab239364_d01bf2cd68c3b6a8)
  unreachable
bb70:
  %t279 = icmp sle i64 0, 2305843009213693951
  br i1 %t279, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_1778b9e962c2fcc7_ba3812a15af6740b)
  unreachable
bb72:
  %t281 = mul i64 0, 4
  %t282 = insertvalue { i64, ptr } undef, i64 0, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t284 = load ptr, ptr %l127, !tbaa !29
  %t285 = load %"compiler/source:Span", ptr %l128
  %t286 = load %"compiler/source:Span", ptr %l129
  %t287 = load i64, ptr %l132, !tbaa !24
  %t288 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t289 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t291 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v4, ptr %v4, ptr %t284, %"compiler/source:Span" %t285, %"compiler/source:Span" %t286, i64 %t287, ptr null, { i64, ptr } %t288, { i64, ptr } %t289, { i64, ptr } %t283)
  store ptr %t291, ptr %l141
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_1778b9e962c2fcc7_ba3812a15af6740b)
  unreachable
bb74:
  %t292 = load ptr, ptr %l141, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t292, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l66 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l153 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca i1
  %l176 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l190 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca i1
  %l217 = alloca { i64, ptr }
  %l226 = alloca ptr
  %l227 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i1
  %l267 = alloca ptr
  %l268 = alloca i1
  %l281 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l295 = alloca i1
  %l308 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l338 = alloca ptr
  %l339 = alloca i1
  %l356 = alloca { i64, ptr }
  %l371 = alloca { i64, ptr }
  %l382 = alloca ptr
  %l383 = alloca i1
  %l388 = alloca ptr
  %l389 = alloca i1
  %l398 = alloca ptr
  %l399 = alloca i1
  %l417 = alloca { i64, ptr }
  %l427 = alloca ptr
  %l428 = alloca i1
  %l443 = alloca ptr
  %l444 = alloca i1
  %l457 = alloca { i64, ptr }
  %l465 = alloca ptr
  %l466 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t6 = load ptr, ptr %l69, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l69, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l70, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l70, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t20, ptr %t21, ptr %t22)
  br label %bb9
bb9:
  br label %bb239
bb10:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t28 = load ptr, ptr %l79, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l79, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 3
  store i1 %t34, ptr %l80, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l80, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t42, ptr %t43, ptr %t44)
  br label %bb16
bb16:
  br label %bb239
bb17:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t50 = load ptr, ptr %l89, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb18, label %bb19
bb18:
  %t53 = load ptr, ptr %l89, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 18}
  %t56 = icmp eq i64 %t54, 4
  store i1 %t56, ptr %l90, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l90, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t64, ptr %t65, ptr %t66)
  br label %bb23
bb23:
  br label %bb239
bb24:
  %t71 = load ptr, ptr %l2, !tbaa !29
  store ptr %t71, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t72 = load ptr, ptr %l99, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t75 = load ptr, ptr %l99, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 18}
  %t78 = icmp eq i64 %t76, 5
  store i1 %t78, ptr %l100, !tbaa !21
  br label %bb26
bb26:
  %t79 = load i1, ptr %l100, !tbaa !21
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t86, ptr %t87, ptr %t91)
  br label %bb30
bb30:
  br label %bb239
bb31:
  %t96 = load ptr, ptr %l2, !tbaa !29
  store ptr %t96, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t97 = load ptr, ptr %l110, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb32, label %bb33
bb32:
  %t100 = load ptr, ptr %l110, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 18}
  %t103 = icmp eq i64 %t101, 6
  store i1 %t103, ptr %l111, !tbaa !21
  br label %bb33
bb33:
  %t104 = load i1, ptr %l111, !tbaa !21
  br i1 %t104, label %bb34, label %bb35
bb34:
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  br label %bb69
bb36:
  %t111 = load ptr, ptr %l7, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Call", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  store ptr %t114, ptr %l8, !tbaa !29
  %t116 = load ptr, ptr %l8, !tbaa !29
  store ptr %t116, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t117 = load ptr, ptr %l118, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb37, label %bb38
bb37:
  %t120 = load ptr, ptr %l118, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 5}
  %t123 = icmp eq i64 %t121, 0
  store i1 %t123, ptr %l119, !tbaa !21
  br label %bb38
bb38:
  %t124 = load i1, ptr %l119, !tbaa !21
  br i1 %t124, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %l8, !tbaa !29
  %t127 = getelementptr { i64, [3 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { i32 }, ptr %t127, i32 0, i32 0
  %t129 = load i32, ptr %t128
  store i32 %t129, ptr %l9, !tbaa !23
  br label %bb41
bb40:
  br label %bb46
bb41:
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr %"compiler/check:b5aWalk", ptr %t131, i32 0, i32 6
  %t134 = load i1, ptr %t133, !tbaa !21
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb42, label %bb43
bb42:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t140 = load i32, ptr %l9, !tbaa !23
  %t142 = sext i32 %t140 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t138, ptr %t139, i64 %t142)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb61
bb46:
  %t146 = load ptr, ptr %l8, !tbaa !29
  store ptr %t146, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t147 = load ptr, ptr %l131, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb47, label %bb48
bb47:
  %t150 = load ptr, ptr %l131, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 5}
  %t153 = icmp eq i64 %t151, 2
  store i1 %t153, ptr %l132, !tbaa !21
  br label %bb48
bb48:
  %t154 = load i1, ptr %l132, !tbaa !21
  br i1 %t154, label %bb49, label %bb50
bb49:
  %t155 = load ptr, ptr %l8, !tbaa !29
  %t157 = getelementptr { i64, [3 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { ptr }, ptr %t157, i32 0, i32 0
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l10, !tbaa !29
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/check:b5aWalk", ptr %t161, i32 0, i32 6
  %t164 = load i1, ptr %t163, !tbaa !21
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb52, label %bb53
bb52:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/check:b5aWalk", ptr %t168, i32 0, i32 7
  store i1 true, ptr %t170, !tbaa !21
  br label %bb54
bb53:
  br label %bb54
bb54:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t173 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t171, ptr %t172, ptr %t173)
  br label %bb55
bb55:
  br label %bb61
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_94214b31169ec8c4_68c852e51d74cc68)
  unreachable
bb61:
  %t178 = load ptr, ptr %l7, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Call", ptr %t178, i32 0, i32 1
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  store i64 %t185, ptr %l13, !tbaa !24
  br label %bb62
bb62:
  %t187 = load i64, ptr %l12, !tbaa !24
  %t188 = load i64, ptr %l13, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb63, label %bb64
bb63:
  br label %bb68
bb64:
  br label %bb65
bb65:
  %t195 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t195, ptr %l153, !tbaa !27
  %t196 = load i64, ptr %l12, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr ptr, ptr %t199, i64 %t196
  %t201 = load ptr, ptr %t200, !tbaa !39
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t203, ptr %t204, ptr %t201)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t210 = load i64, ptr %l12, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l12, !tbaa !24
  br label %bb62
bb68:
  br label %bb239
bb69:
  %t214 = load ptr, ptr %l2, !tbaa !29
  store ptr %t214, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t215 = load ptr, ptr %l162, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb70, label %bb71
bb70:
  %t218 = load ptr, ptr %l162, !tbaa !29
  %t219 = load i64, ptr %t218, !range !{i64 0, i64 18}
  %t221 = icmp eq i64 %t219, 7
  store i1 %t221, ptr %l163, !tbaa !21
  br label %bb71
bb71:
  %t222 = load i1, ptr %l163, !tbaa !21
  br i1 %t222, label %bb72, label %bb73
bb72:
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t225, i32 0, i32 2
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l15, !tbaa !29
  br label %bb74
bb73:
  br label %bb83
bb74:
  %t229 = load ptr, ptr %l15, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Make", ptr %t229, i32 0, i32 2
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  store { i64, ptr } %t232, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  store i64 %t236, ptr %l18, !tbaa !24
  br label %bb75
bb75:
  %t238 = load i64, ptr %l17, !tbaa !24
  %t239 = load i64, ptr %l18, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb76, label %bb77
bb76:
  br label %bb81
bb77:
  br label %bb78
bb78:
  %t246 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t246, ptr %l176, !tbaa !27
  %t247 = load i64, ptr %l17, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr ptr, ptr %t250, i64 %t247
  %t252 = load ptr, ptr %t251, !tbaa !39
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t254, ptr %t255, ptr %t252)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t261 = load i64, ptr %l17, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l17, !tbaa !24
  br label %bb75
bb81:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t267 = load ptr, ptr %l15, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Make", ptr %t267, i32 0, i32 3
  %t270 = load ptr, ptr %t269, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t265, ptr %t266, ptr %t270)
  br label %bb82
bb82:
  br label %bb239
bb83:
  %t274 = load ptr, ptr %l2, !tbaa !29
  store ptr %t274, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t275 = load ptr, ptr %l189, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb84, label %bb85
bb84:
  %t278 = load ptr, ptr %l189, !tbaa !29
  %t279 = load i64, ptr %t278, !range !{i64 0, i64 18}
  %t281 = icmp eq i64 %t279, 8
  store i1 %t281, ptr %l190, !tbaa !21
  br label %bb85
bb85:
  %t282 = load i1, ptr %l190, !tbaa !21
  br i1 %t282, label %bb86, label %bb87
bb86:
  %t283 = load ptr, ptr %l2, !tbaa !29
  %t285 = getelementptr { i64, [5 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t285, i32 0, i32 2
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l20, !tbaa !29
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t291 = load ptr, ptr %l20, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Collect", ptr %t291, i32 0, i32 0
  %t294 = load ptr, ptr %t293, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t289, ptr %t290, ptr %t294)
  br label %bb89
bb89:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t300 = load ptr, ptr %l20, !tbaa !29
  %t302 = getelementptr %"compiler/typed:Collect", ptr %t300, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t298, ptr %t299, ptr %t303)
  br label %bb90
bb90:
  br label %bb239
bb91:
  %t308 = load ptr, ptr %l2, !tbaa !29
  store ptr %t308, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t309 = load ptr, ptr %l204, !tbaa !29
  %t310 = icmp ne ptr %t309, null
  br i1 %t310, label %bb92, label %bb93
bb92:
  %t312 = load ptr, ptr %l204, !tbaa !29
  %t313 = load i64, ptr %t312, !range !{i64 0, i64 18}
  %t315 = icmp eq i64 %t313, 9
  store i1 %t315, ptr %l205, !tbaa !21
  br label %bb93
bb93:
  %t316 = load i1, ptr %l205, !tbaa !21
  br i1 %t316, label %bb94, label %bb95
bb94:
  %t317 = load ptr, ptr %l2, !tbaa !29
  %t319 = getelementptr { i64, [5 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t319, i32 0, i32 4
  %t321 = load { i64, ptr }, ptr %t320
  store { i64, ptr } %t321, ptr %l21, !tbaa !27
  br label %bb96
bb95:
  br label %bb104
bb96:
  %t323 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t323, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t325 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t325, 0
  store i64 %t327, ptr %l24, !tbaa !24
  br label %bb97
bb97:
  %t329 = load i64, ptr %l23, !tbaa !24
  %t330 = load i64, ptr %l24, !tbaa !24
  %t333 = icmp slt i64 %t329, %t330
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t337 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t337, ptr %l217, !tbaa !27
  %t338 = load i64, ptr %l23, !tbaa !24
  %t340 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr ptr, ptr %t341, i64 %t338
  %t343 = load ptr, ptr %t342, !tbaa !39
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t345, ptr %t346, ptr %t343)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t352 = load i64, ptr %l23, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l23, !tbaa !24
  br label %bb97
bb103:
  br label %bb239
bb104:
  %t356 = load ptr, ptr %l2, !tbaa !29
  store ptr %t356, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t357 = load ptr, ptr %l226, !tbaa !29
  %t358 = icmp ne ptr %t357, null
  br i1 %t358, label %bb105, label %bb106
bb105:
  %t360 = load ptr, ptr %l226, !tbaa !29
  %t361 = load i64, ptr %t360, !range !{i64 0, i64 18}
  %t363 = icmp eq i64 %t361, 10
  store i1 %t363, ptr %l227, !tbaa !21
  br label %bb106
bb106:
  %t364 = load i1, ptr %l227, !tbaa !21
  br i1 %t364, label %bb107, label %bb108
bb107:
  %t365 = load ptr, ptr %l2, !tbaa !29
  %t367 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t367, i32 0, i32 2
  %t369 = load ptr, ptr %t368
  store ptr %t369, ptr %l26, !tbaa !29
  br label %bb109
bb108:
  br label %bb113
bb109:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t373 = load ptr, ptr %l26, !tbaa !29
  %t375 = getelementptr %"compiler/typed:Slice", ptr %t373, i32 0, i32 0
  %t376 = load ptr, ptr %t375, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t371, ptr %t372, ptr %t376)
  br label %bb110
bb110:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t383 = load ptr, ptr %l26, !tbaa !29
  %t385 = getelementptr %"compiler/typed:Slice", ptr %t383, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t381, ptr %t382, ptr %t386)
  br label %bb111
bb111:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t393 = load ptr, ptr %l26, !tbaa !29
  %t395 = getelementptr %"compiler/typed:Slice", ptr %t393, i32 0, i32 2
  %t396 = load ptr, ptr %t395, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t391, ptr %t392, ptr %t396)
  br label %bb112
bb112:
  br label %bb239
bb113:
  %t401 = load ptr, ptr %l2, !tbaa !29
  store ptr %t401, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t402 = load ptr, ptr %l247, !tbaa !29
  %t403 = icmp ne ptr %t402, null
  br i1 %t403, label %bb114, label %bb115
bb114:
  %t405 = load ptr, ptr %l247, !tbaa !29
  %t406 = load i64, ptr %t405, !range !{i64 0, i64 18}
  %t408 = icmp eq i64 %t406, 11
  store i1 %t408, ptr %l248, !tbaa !21
  br label %bb115
bb115:
  %t409 = load i1, ptr %l248, !tbaa !21
  br i1 %t409, label %bb116, label %bb117
bb116:
  %t410 = load ptr, ptr %l2, !tbaa !29
  %t412 = getelementptr { i64, [5 x i64] }, ptr %t410, i32 0, i32 1
  %t413 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t412, i32 0, i32 2
  %t414 = load ptr, ptr %t413
  store ptr %t414, ptr %l27, !tbaa !29
  br label %bb118
bb117:
  br label %bb122
bb118:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t418 = load ptr, ptr %l27, !tbaa !29
  %t420 = getelementptr %"compiler/typed:Cond", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t416, ptr %t417, ptr %t421)
  br label %bb119
bb119:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l1, !tbaa !29
  %t428 = load ptr, ptr %l27, !tbaa !29
  %t430 = getelementptr %"compiler/typed:Cond", ptr %t428, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t426, ptr %t427, ptr %t431)
  br label %bb120
bb120:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t437 = load ptr, ptr %l27, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Cond", ptr %t437, i32 0, i32 2
  %t440 = load ptr, ptr %t439, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t435, ptr %t436, ptr %t440)
  br label %bb121
bb121:
  br label %bb239
bb122:
  %t445 = load ptr, ptr %l2, !tbaa !29
  store ptr %t445, ptr %l267, !tbaa !29
  store i1 false, ptr %l268, !tbaa !21
  %t446 = load ptr, ptr %l267, !tbaa !29
  %t447 = icmp ne ptr %t446, null
  br i1 %t447, label %bb123, label %bb124
bb123:
  %t449 = load ptr, ptr %l267, !tbaa !29
  %t450 = load i64, ptr %t449, !range !{i64 0, i64 18}
  %t452 = icmp eq i64 %t450, 12
  store i1 %t452, ptr %l268, !tbaa !21
  br label %bb124
bb124:
  %t453 = load i1, ptr %l268, !tbaa !21
  br i1 %t453, label %bb125, label %bb126
bb125:
  %t454 = load ptr, ptr %l2, !tbaa !29
  %t456 = getelementptr { i64, [5 x i64] }, ptr %t454, i32 0, i32 1
  %t457 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t456, i32 0, i32 2
  %t458 = load ptr, ptr %t457
  store ptr %t458, ptr %l28, !tbaa !29
  br label %bb127
bb126:
  br label %bb136
bb127:
  %t460 = load ptr, ptr %l28, !tbaa !29
  %t462 = getelementptr %"compiler/typed:Seq", ptr %t460, i32 0, i32 0
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  store { i64, ptr } %t463, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t465 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t465, 0
  store i64 %t467, ptr %l31, !tbaa !24
  br label %bb128
bb128:
  %t469 = load i64, ptr %l30, !tbaa !24
  %t470 = load i64, ptr %l31, !tbaa !24
  %t473 = icmp slt i64 %t469, %t470
  %t475 = xor i1 %t473, true
  br i1 %t475, label %bb129, label %bb130
bb129:
  br label %bb134
bb130:
  br label %bb131
bb131:
  %t477 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t477, ptr %l281, !tbaa !27
  %t478 = load i64, ptr %l30, !tbaa !24
  %t480 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = getelementptr ptr, ptr %t481, i64 %t478
  %t483 = load ptr, ptr %t482, !tbaa !39
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t485, ptr %t486, ptr %t483)
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t492 = load i64, ptr %l30, !tbaa !24
  %t494 = add i64 %t492, 1
  store i64 %t494, ptr %l30, !tbaa !24
  br label %bb128
bb134:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t498 = load ptr, ptr %l28, !tbaa !29
  %t500 = getelementptr %"compiler/typed:Seq", ptr %t498, i32 0, i32 1
  %t501 = load ptr, ptr %t500, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t496, ptr %t497, ptr %t501)
  br label %bb135
bb135:
  br label %bb239
bb136:
  %t505 = load ptr, ptr %l2, !tbaa !29
  store ptr %t505, ptr %l294, !tbaa !29
  store i1 false, ptr %l295, !tbaa !21
  %t506 = load ptr, ptr %l294, !tbaa !29
  %t507 = icmp ne ptr %t506, null
  br i1 %t507, label %bb137, label %bb138
bb137:
  %t509 = load ptr, ptr %l294, !tbaa !29
  %t510 = load i64, ptr %t509, !range !{i64 0, i64 18}
  %t512 = icmp eq i64 %t510, 13
  store i1 %t512, ptr %l295, !tbaa !21
  br label %bb138
bb138:
  %t513 = load i1, ptr %l295, !tbaa !21
  br i1 %t513, label %bb139, label %bb140
bb139:
  %t514 = load ptr, ptr %l2, !tbaa !29
  %t516 = getelementptr { i64, [5 x i64] }, ptr %t514, i32 0, i32 1
  %t517 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t516, i32 0, i32 2
  %t518 = load ptr, ptr %t517
  store ptr %t518, ptr %l33, !tbaa !29
  br label %bb141
bb140:
  br label %bb157
bb141:
  %t520 = load ptr, ptr %l33, !tbaa !29
  %t522 = getelementptr %"compiler/typed:Match", ptr %t520, i32 0, i32 0
  %t523 = load { i64, ptr }, ptr %t522, !tbaa !27
  store { i64, ptr } %t523, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t525 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t527 = extractvalue { i64, ptr } %t525, 0
  store i64 %t527, ptr %l36, !tbaa !24
  br label %bb142
bb142:
  %t529 = load i64, ptr %l35, !tbaa !24
  %t530 = load i64, ptr %l36, !tbaa !24
  %t533 = icmp slt i64 %t529, %t530
  %t535 = xor i1 %t533, true
  br i1 %t535, label %bb143, label %bb144
bb143:
  br label %bb148
bb144:
  br label %bb145
bb145:
  %t537 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t537, ptr %l308, !tbaa !27
  %t538 = load i64, ptr %l35, !tbaa !24
  %t540 = getelementptr { i64, ptr }, ptr %l308, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr ptr, ptr %t541, i64 %t538
  %t543 = load ptr, ptr %t542, !tbaa !39
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t545, ptr %t546, ptr %t543)
  br label %bb146
bb146:
  br label %bb147
bb147:
  %t552 = load i64, ptr %l35, !tbaa !24
  %t554 = add i64 %t552, 1
  store i64 %t554, ptr %l35, !tbaa !24
  br label %bb142
bb148:
  %t556 = load ptr, ptr %l33, !tbaa !29
  %t558 = getelementptr %"compiler/typed:Match", ptr %t556, i32 0, i32 1
  %t559 = load { i64, ptr }, ptr %t558, !tbaa !27
  store { i64, ptr } %t559, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t561 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t563 = extractvalue { i64, ptr } %t561, 0
  store i64 %t563, ptr %l40, !tbaa !24
  br label %bb149
bb149:
  %t565 = load i64, ptr %l39, !tbaa !24
  %t566 = load i64, ptr %l40, !tbaa !24
  %t569 = icmp slt i64 %t565, %t566
  %t571 = xor i1 %t569, true
  br i1 %t571, label %bb150, label %bb151
bb150:
  br label %bb155
bb151:
  br label %bb152
bb152:
  %t573 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t573, ptr %l325, !tbaa !27
  %t574 = load i64, ptr %l39, !tbaa !24
  %t576 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr ptr, ptr %t577, i64 %t574
  %t579 = load ptr, ptr %t578, !tbaa !39
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %t581, ptr %t582, ptr %t579)
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t588 = load i64, ptr %l39, !tbaa !24
  %t590 = add i64 %t588, 1
  store i64 %t590, ptr %l39, !tbaa !24
  br label %bb149
bb155:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load ptr, ptr %l1, !tbaa !29
  %t594 = load ptr, ptr %l33, !tbaa !29
  %t596 = getelementptr %"compiler/typed:Match", ptr %t594, i32 0, i32 2
  %t597 = load ptr, ptr %t596, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %t592, ptr %t593, ptr %t597)
  br label %bb156
bb156:
  br label %bb239
bb157:
  %t601 = load ptr, ptr %l2, !tbaa !29
  store ptr %t601, ptr %l338, !tbaa !29
  store i1 false, ptr %l339, !tbaa !21
  %t602 = load ptr, ptr %l338, !tbaa !29
  %t603 = icmp ne ptr %t602, null
  br i1 %t603, label %bb158, label %bb159
bb158:
  %t605 = load ptr, ptr %l338, !tbaa !29
  %t606 = load i64, ptr %t605, !range !{i64 0, i64 18}
  %t608 = icmp eq i64 %t606, 14
  store i1 %t608, ptr %l339, !tbaa !21
  br label %bb159
bb159:
  %t609 = load i1, ptr %l339, !tbaa !21
  br i1 %t609, label %bb160, label %bb161
bb160:
  %t610 = load ptr, ptr %l2, !tbaa !29
  %t612 = getelementptr { i64, [5 x i64] }, ptr %t610, i32 0, i32 1
  %t613 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t612, i32 0, i32 2
  %t614 = load ptr, ptr %t613
  store ptr %t614, ptr %l42, !tbaa !29
  br label %bb162
bb161:
  br label %bb178
bb162:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t617 = load ptr, ptr %l1, !tbaa !29
  %t618 = load ptr, ptr %l42, !tbaa !29
  %t620 = getelementptr %"compiler/typed:Try", ptr %t618, i32 0, i32 0
  %t621 = load ptr, ptr %t620, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t616, ptr %t617, ptr %t621)
  br label %bb163
bb163:
  %t625 = load ptr, ptr %l42, !tbaa !29
  %t627 = getelementptr %"compiler/typed:Try", ptr %t625, i32 0, i32 1
  %t628 = load { i64, ptr }, ptr %t627, !tbaa !27
  store { i64, ptr } %t628, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t630 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t632 = extractvalue { i64, ptr } %t630, 0
  store i64 %t632, ptr %l45, !tbaa !24
  br label %bb164
bb164:
  %t634 = load i64, ptr %l44, !tbaa !24
  %t635 = load i64, ptr %l45, !tbaa !24
  %t638 = icmp slt i64 %t634, %t635
  %t640 = xor i1 %t638, true
  br i1 %t640, label %bb165, label %bb166
bb165:
  br label %bb177
bb166:
  br label %bb167
bb167:
  %t642 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t642, ptr %l356, !tbaa !27
  %t643 = load i64, ptr %l44, !tbaa !24
  %t645 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t646 = load ptr, ptr %t645, !tbaa !27
  %t647 = getelementptr ptr, ptr %t646, i64 %t643
  %t648 = load ptr, ptr %t647, !tbaa !39
  store ptr %t648, ptr %l46, !tbaa !29
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load ptr, ptr %l1, !tbaa !29
  %t652 = load ptr, ptr %l46, !tbaa !29
  %t654 = getelementptr %"compiler/typed:Clause", ptr %t652, i32 0, i32 3
  %t655 = load ptr, ptr %t654, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t650, ptr %t651, ptr %t655)
  br label %bb168
bb168:
  %t659 = load ptr, ptr %l46, !tbaa !29
  %t661 = getelementptr %"compiler/typed:Clause", ptr %t659, i32 0, i32 4
  %t662 = load { i64, ptr }, ptr %t661, !tbaa !27
  store { i64, ptr } %t662, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  %t664 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t664, 0
  store i64 %t666, ptr %l49, !tbaa !24
  br label %bb169
bb169:
  %t668 = load i64, ptr %l48, !tbaa !24
  %t669 = load i64, ptr %l49, !tbaa !24
  %t672 = icmp slt i64 %t668, %t669
  %t674 = xor i1 %t672, true
  br i1 %t674, label %bb170, label %bb171
bb170:
  br label %bb175
bb171:
  br label %bb172
bb172:
  %t676 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t676, ptr %l371, !tbaa !27
  %t677 = load i64, ptr %l48, !tbaa !24
  %t679 = getelementptr { i64, ptr }, ptr %l371, i32 0, i32 1
  %t680 = load ptr, ptr %t679, !tbaa !27
  %t681 = getelementptr ptr, ptr %t680, i64 %t677
  %t682 = load ptr, ptr %t681, !tbaa !39
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t685 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t684, ptr %t685, ptr %t682)
  br label %bb173
bb173:
  br label %bb174
bb174:
  %t691 = load i64, ptr %l48, !tbaa !24
  %t693 = add i64 %t691, 1
  store i64 %t693, ptr %l48, !tbaa !24
  br label %bb169
bb175:
  br label %bb176
bb176:
  %t695 = load i64, ptr %l44, !tbaa !24
  %t697 = add i64 %t695, 1
  store i64 %t697, ptr %l44, !tbaa !24
  br label %bb164
bb177:
  br label %bb239
bb178:
  %t699 = load ptr, ptr %l2, !tbaa !29
  store ptr %t699, ptr %l382, !tbaa !29
  store i1 false, ptr %l383, !tbaa !21
  %t700 = load ptr, ptr %l382, !tbaa !29
  %t701 = icmp ne ptr %t700, null
  br i1 %t701, label %bb179, label %bb180
bb179:
  %t703 = load ptr, ptr %l382, !tbaa !29
  %t704 = load i64, ptr %t703, !range !{i64 0, i64 18}
  %t706 = icmp eq i64 %t704, 15
  store i1 %t706, ptr %l383, !tbaa !21
  br label %bb180
bb180:
  %t707 = load i1, ptr %l383, !tbaa !21
  br i1 %t707, label %bb181, label %bb182
bb181:
  %t708 = load ptr, ptr %l2, !tbaa !29
  %t710 = getelementptr { i64, [5 x i64] }, ptr %t708, i32 0, i32 1
  %t711 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t710, i32 0, i32 2
  %t712 = load ptr, ptr %t711
  store ptr %t712, ptr %l51, !tbaa !29
  br label %bb183
bb182:
  br label %bb214
bb183:
  %t714 = load ptr, ptr %l51, !tbaa !29
  store ptr %t714, ptr %l388, !tbaa !29
  store i1 false, ptr %l389, !tbaa !21
  %t715 = load ptr, ptr %l388, !tbaa !29
  %t716 = icmp ne ptr %t715, null
  br i1 %t716, label %bb184, label %bb185
bb184:
  %t718 = load ptr, ptr %l388, !tbaa !29
  %t719 = load i64, ptr %t718, !range !{i64 0, i64 3}
  %t721 = icmp eq i64 %t719, 0
  store i1 %t721, ptr %l389, !tbaa !21
  br label %bb185
bb185:
  %t722 = load i1, ptr %l389, !tbaa !21
  br i1 %t722, label %bb186, label %bb187
bb186:
  %t723 = load ptr, ptr %l51, !tbaa !29
  %t725 = getelementptr { i64, [4 x i64] }, ptr %t723, i32 0, i32 1
  %t726 = getelementptr { i32 }, ptr %t725, i32 0, i32 0
  %t727 = load i32, ptr %t726
  store i32 %t727, ptr %l52, !tbaa !23
  br label %bb188
bb187:
  br label %bb190
bb188:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t730 = load ptr, ptr %l1, !tbaa !29
  %t731 = load i32, ptr %l52, !tbaa !23
  %t733 = sext i32 %t731 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t729, ptr %t730, i64 %t733)
  br label %bb189
bb189:
  br label %bb213
bb190:
  %t737 = load ptr, ptr %l51, !tbaa !29
  store ptr %t737, ptr %l398, !tbaa !29
  store i1 false, ptr %l399, !tbaa !21
  %t738 = load ptr, ptr %l398, !tbaa !29
  %t739 = icmp ne ptr %t738, null
  br i1 %t739, label %bb191, label %bb192
bb191:
  %t741 = load ptr, ptr %l398, !tbaa !29
  %t742 = load i64, ptr %t741, !range !{i64 0, i64 3}
  %t744 = icmp eq i64 %t742, 1
  store i1 %t744, ptr %l399, !tbaa !21
  br label %bb192
bb192:
  %t745 = load i1, ptr %l399, !tbaa !21
  br i1 %t745, label %bb193, label %bb194
bb193:
  %t746 = load ptr, ptr %l51, !tbaa !29
  %t748 = getelementptr { i64, [4 x i64] }, ptr %t746, i32 0, i32 1
  %t749 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t748, i32 0, i32 0
  %t750 = load i32, ptr %t749
  store i32 %t750, ptr %l53, !tbaa !23
  %t752 = load ptr, ptr %l51, !tbaa !29
  %t754 = getelementptr { i64, [4 x i64] }, ptr %t752, i32 0, i32 1
  %t755 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t754, i32 0, i32 1
  %t756 = load { i64, ptr }, ptr %t755
  store { i64, ptr } %t756, ptr %l54, !tbaa !27
  br label %bb195
bb194:
  br label %bb204
bb195:
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t759 = load ptr, ptr %l1, !tbaa !29
  %t760 = load i32, ptr %l53, !tbaa !23
  %t762 = sext i32 %t760 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t758, ptr %t759, i64 %t762)
  br label %bb196
bb196:
  %t766 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t766, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t768 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t768, 0
  store i64 %t770, ptr %l57, !tbaa !24
  br label %bb197
bb197:
  %t772 = load i64, ptr %l56, !tbaa !24
  %t773 = load i64, ptr %l57, !tbaa !24
  %t776 = icmp slt i64 %t772, %t773
  %t778 = xor i1 %t776, true
  br i1 %t778, label %bb198, label %bb199
bb198:
  br label %bb203
bb199:
  br label %bb200
bb200:
  %t780 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t780, ptr %l417, !tbaa !27
  %t781 = load i64, ptr %l56, !tbaa !24
  %t783 = getelementptr { i64, ptr }, ptr %l417, i32 0, i32 1
  %t784 = load ptr, ptr %t783, !tbaa !27
  %t785 = getelementptr ptr, ptr %t784, i64 %t781
  %t786 = load ptr, ptr %t785, !tbaa !39
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t789 = load ptr, ptr %l1, !tbaa !29
  %t792 = getelementptr %"compiler/typed:Capture", ptr %t786, i32 0, i32 1
  %t793 = load ptr, ptr %t792, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t788, ptr %t789, ptr %t793)
  br label %bb201
bb201:
  br label %bb202
bb202:
  %t798 = load i64, ptr %l56, !tbaa !24
  %t800 = add i64 %t798, 1
  store i64 %t800, ptr %l56, !tbaa !24
  br label %bb197
bb203:
  br label %bb213
bb204:
  %t802 = load ptr, ptr %l51, !tbaa !29
  store ptr %t802, ptr %l427, !tbaa !29
  store i1 false, ptr %l428, !tbaa !21
  %t803 = load ptr, ptr %l427, !tbaa !29
  %t804 = icmp ne ptr %t803, null
  br i1 %t804, label %bb205, label %bb206
bb205:
  %t806 = load ptr, ptr %l427, !tbaa !29
  %t807 = load i64, ptr %t806, !range !{i64 0, i64 3}
  %t809 = icmp eq i64 %t807, 2
  store i1 %t809, ptr %l428, !tbaa !21
  br label %bb206
bb206:
  %t810 = load i1, ptr %l428, !tbaa !21
  br i1 %t810, label %bb207, label %bb208
bb207:
  %t811 = load ptr, ptr %l51, !tbaa !29
  %t813 = getelementptr { i64, [4 x i64] }, ptr %t811, i32 0, i32 1
  %t814 = getelementptr { i32, ptr, i32 }, ptr %t813, i32 0, i32 0
  %t815 = load i32, ptr %t814
  store i32 %t815, ptr %l59, !tbaa !23
  %t817 = load ptr, ptr %l51, !tbaa !29
  %t819 = getelementptr { i64, [4 x i64] }, ptr %t817, i32 0, i32 1
  %t820 = getelementptr { i32, ptr, i32 }, ptr %t819, i32 0, i32 1
  %t821 = load ptr, ptr %t820
  store ptr %t821, ptr %l60, !tbaa !29
  br label %bb209
bb208:
  br label %bb212
bb209:
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t824 = load ptr, ptr %l1, !tbaa !29
  %t825 = load i32, ptr %l59, !tbaa !23
  %t827 = sext i32 %t825 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t823, ptr %t824, i64 %t827)
  br label %bb210
bb210:
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t832 = load ptr, ptr %l1, !tbaa !29
  %t833 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t831, ptr %t832, ptr %t833)
  br label %bb211
bb211:
  br label %bb213
bb212:
  call void @__olang_check_failed(ptr @olang_loc_d48ba9fb56fa57b5_9836703f13f4bc39)
  unreachable
bb213:
  br label %bb239
bb214:
  %t838 = load ptr, ptr %l2, !tbaa !29
  store ptr %t838, ptr %l443, !tbaa !29
  store i1 false, ptr %l444, !tbaa !21
  %t839 = load ptr, ptr %l443, !tbaa !29
  %t840 = icmp ne ptr %t839, null
  br i1 %t840, label %bb215, label %bb216
bb215:
  %t842 = load ptr, ptr %l443, !tbaa !29
  %t843 = load i64, ptr %t842, !range !{i64 0, i64 18}
  %t845 = icmp eq i64 %t843, 16
  store i1 %t845, ptr %l444, !tbaa !21
  br label %bb216
bb216:
  %t846 = load i1, ptr %l444, !tbaa !21
  br i1 %t846, label %bb217, label %bb218
bb217:
  %t847 = load ptr, ptr %l2, !tbaa !29
  %t849 = getelementptr { i64, [5 x i64] }, ptr %t847, i32 0, i32 1
  %t850 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t849, i32 0, i32 2
  %t851 = load ptr, ptr %t850
  store ptr %t851, ptr %l61, !tbaa !29
  br label %bb219
bb218:
  br label %bb227
bb219:
  %t853 = load ptr, ptr %l61, !tbaa !29
  %t855 = getelementptr %"compiler/typed:Text", ptr %t853, i32 0, i32 0
  %t856 = load { i64, ptr }, ptr %t855, !tbaa !27
  store { i64, ptr } %t856, ptr %l62, !tbaa !27
  store i64 0, ptr %l63, !tbaa !24
  %t858 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t860 = extractvalue { i64, ptr } %t858, 0
  store i64 %t860, ptr %l64, !tbaa !24
  br label %bb220
bb220:
  %t862 = load i64, ptr %l63, !tbaa !24
  %t863 = load i64, ptr %l64, !tbaa !24
  %t866 = icmp slt i64 %t862, %t863
  %t868 = xor i1 %t866, true
  br i1 %t868, label %bb221, label %bb222
bb221:
  br label %bb226
bb222:
  br label %bb223
bb223:
  %t870 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t870, ptr %l457, !tbaa !27
  %t871 = load i64, ptr %l63, !tbaa !24
  %t873 = getelementptr { i64, ptr }, ptr %l457, i32 0, i32 1
  %t874 = load ptr, ptr %t873, !tbaa !27
  %t875 = getelementptr ptr, ptr %t874, i64 %t871
  %t876 = load ptr, ptr %t875, !tbaa !39
  %t878 = load ptr, ptr %l0, !tbaa !29
  %t879 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPiece(ptr %v0, ptr %v1, ptr %v2, ptr %t878, ptr %t879, ptr %t876)
  br label %bb224
bb224:
  br label %bb225
bb225:
  %t884 = load i64, ptr %l63, !tbaa !24
  %t886 = add i64 %t884, 1
  store i64 %t886, ptr %l63, !tbaa !24
  br label %bb220
bb226:
  br label %bb239
bb227:
  %t888 = load ptr, ptr %l2, !tbaa !29
  store ptr %t888, ptr %l465, !tbaa !29
  store i1 false, ptr %l466, !tbaa !21
  %t889 = load ptr, ptr %l465, !tbaa !29
  %t890 = icmp ne ptr %t889, null
  br i1 %t890, label %bb228, label %bb229
bb228:
  %t892 = load ptr, ptr %l465, !tbaa !29
  %t893 = load i64, ptr %t892, !range !{i64 0, i64 18}
  %t895 = icmp eq i64 %t893, 17
  store i1 %t895, ptr %l466, !tbaa !21
  br label %bb229
bb229:
  %t896 = load i1, ptr %l466, !tbaa !21
  br i1 %t896, label %bb230, label %bb231
bb230:
  %t897 = load ptr, ptr %l2, !tbaa !29
  %t899 = getelementptr { i64, [5 x i64] }, ptr %t897, i32 0, i32 1
  %t900 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t899, i32 0, i32 2
  %t901 = load ptr, ptr %t900
  store ptr %t901, ptr %l66, !tbaa !29
  br label %bb232
bb231:
  br label %bb234
bb232:
  %t903 = load ptr, ptr %l0, !tbaa !29
  %t904 = load ptr, ptr %l1, !tbaa !29
  %t905 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t903, ptr %t904, ptr %t905)
  br label %bb233
bb233:
  br label %bb239
bb234:
  br i1 true, label %bb235, label %bb236
bb235:
  br label %bb237
bb236:
  br label %bb238
bb237:
  br label %bb239
bb238:
  call void @__olang_check_failed(ptr @olang_loc_964ce48e3719b9fe_ecf9d1875d849bc2)
  unreachable
bb239:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l17 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l17
  br label %bb9
bb8:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb11
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t32)
  store i32 %t34, ptr %l19
  br label %bb10
bb10:
  %t35 = load i32, ptr %l17, !tbaa !23
  %t36 = load i32, ptr %l19, !tbaa !23
  %t37 = icmp eq i32 %t35, %t36
  store i1 %t37, ptr %l12, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l12, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t40)
  store i32 %t42, ptr %l22
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t43 = load i32, ptr %l22, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb15:
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_2b2e21654e3310f6_a1c2a2453bd05f02)
  unreachable
bb21:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t44)
  store i32 %t47, ptr %l25
  br label %bb22
bb22:
  %t48 = load i32, ptr %l25, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l27 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l28 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t22, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l17
  br label %bb5
bb5:
  %t25 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t25, ptr %l12
  br label %bb17
bb6:
  %t26 = load { i64, [2 x i64] }, ptr %l2
  %t28 = extractvalue { i64, [2 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 1
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t32 = getelementptr { i32, i32 }, ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l4, !tbaa !23
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t36 = getelementptr { i32, i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l5, !tbaa !23
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t39 = load i32, ptr %l4, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t43 = sub i64 -2, %t41
  %t44 = load i32, ptr %l5, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t49 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t43, i64 %t46)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t49, ptr %l27
  br label %bb10
bb10:
  %t50 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l27
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t50, ptr %l12
  br label %bb17
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t51 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t51, ptr %l28
  br label %bb15
bb15:
  %t52 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l28
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t52, ptr %l12
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f6343df54e321530_17a07bfc25de31ec)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t53, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %rv
  ret %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %a1)
  store %"compiler/source:Span" %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l4
  %t7 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t5, %"compiler/source:Span" %t6, i64 1)
  store %"compiler/source:Span" %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t17, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Branch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Branch", ptr %t29, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v2, ptr %t24, { i64, ptr } %t28, i32 1, %"compiler/source:Span" %t32)
  store ptr %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l18, !tbaa !29
  store ptr %t38, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Branch", ptr %t39, i32 0, i32 2
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %t54, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t55)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sge i64 0, 0
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t7 = icmp sle i64 0, 1152921504606846975
  br i1 %t7, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_fa88b19e51866753_1c515c5623826c7f)
  unreachable
bb5:
  %t9 = mul i64 0, 8
  %t10 = insertvalue { i64, ptr } undef, i64 0, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t11, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_fa88b19e51866753_1c515c5623826c7f)
  unreachable
bb7:
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb8, label %bb9
bb8:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i64, ptr %t17, !range !{i64 0, i64 18}
  %t20 = icmp eq i64 %t18, 6
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Call", ptr %t28, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l8, !tbaa !27
  br label %bb22
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb17, label %bb18
bb17:
  %t35 = icmp sle i64 0, 1152921504606846975
  br i1 %t35, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_962a22c7791f971e_263bae1157bb3aaa)
  unreachable
bb19:
  %t37 = mul i64 0, 8
  %t38 = insertvalue { i64, ptr } undef, i64 0, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t39, ptr %l8, !tbaa !27
  br label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_962a22c7791f971e_263bae1157bb3aaa)
  unreachable
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bce8d8bde069702e_ffe04dc686cce872)
  unreachable
bb22:
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t41, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l25 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca %"compiler/typed:Local"
  %l64 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i32
  %l72 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i1
  %l92 = alloca i32
  %l105 = alloca i1
  %l107 = alloca i1
  %l112 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l126 = alloca %"compiler/typed:Local"
  %l127 = alloca i32
  %l134 = alloca ptr
  %l137 = alloca i32
  %l141 = alloca %"compiler/typed:Capture"
  %l145 = alloca i1
  %l146 = alloca i1
  %l151 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t169 = alloca { i64, [5 x i64] }, align 8
  %t192 = alloca { i64, [5 x i64] }, align 8
  %t239 = alloca { i64, [1 x i64] }, align 8
  %t306 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 8
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 19
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t34, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 19
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l3
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t36, i64 %t40, i32 %t41, %"compiler/source:Span" %t42)
  store i64 %t47, ptr %l35
  br label %bb12
bb12:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 14
  store ptr %t56, ptr %l40, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 16
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 19
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t59, i64 %t63)
  store ptr %t66, ptr %l45
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l45, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 0
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t71, i64 %t70)
  store ptr %t73, ptr %l48
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l48, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 7
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/typed:Local" %t80, ptr %l52
  br label %bb18
bb18:
  %t81 = getelementptr %"compiler/typed:Local", ptr %l52, i32 0, i32 2
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr %l3
  %t85 = load i32, ptr %l7, !tbaa !23
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = trunc i64 %t86 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 0, ptr %t91
  %t93 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t84, 0
  %t95 = insertvalue { %"compiler/source:Span", i32, i32 } %t93, i32 %t85, 1
  %t97 = insertvalue { %"compiler/source:Span", i32, i32 } %t95, i32 %t88, 2
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t97, ptr %t98
  %t99 = load { i64, [4 x i64] }, ptr %t90
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t99, ptr %t101
  store ptr %t101, ptr %l8, !tbaa !29
  %t103 = load i32, ptr %l7, !tbaa !23
  store i32 %t103, ptr %l9, !tbaa !23
  store ptr null, ptr %l10, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l7, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l64
  br label %bb19
bb19:
  %t110 = load i1, ptr %l64, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb20, label %bb21
bb20:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l7, !tbaa !23
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l69
  br label %bb22
bb21:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb31
bb22:
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t119 = load i32, ptr %l69, !tbaa !23
  %t121 = icmp ne i32 %t119, %t118
  br i1 %t121, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb26
bb24:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t127 = load i32, ptr %l7, !tbaa !23
  %t130 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t126, i32 %t127)
  store i1 %t130, ptr %l76
  br label %bb25
bb25:
  %t131 = load i1, ptr %l76, !tbaa !21
  store i1 %t131, ptr %l72, !tbaa !21
  br label %bb26
bb26:
  %t132 = load i1, ptr %l72, !tbaa !21
  br i1 %t132, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb30
bb28:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l7, !tbaa !23
  %t142 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t138, i32 %t139)
  store i1 %t142, ptr %l82
  br label %bb29
bb29:
  %t143 = load i1, ptr %l82, !tbaa !21
  store i1 %t143, ptr %l77, !tbaa !21
  br label %bb30
bb30:
  %t144 = load i1, ptr %l77, !tbaa !21
  store i1 %t144, ptr %l66, !tbaa !21
  br label %bb31
bb31:
  %t145 = load i1, ptr %l66, !tbaa !21
  br i1 %t145, label %bb32, label %bb33
bb32:
  %t146 = load ptr, ptr %l4, !tbaa !29
  %t148 = getelementptr %"compiler/check:frame", ptr %t146, i32 0, i32 20
  %t149 = load i1, ptr %t148, !tbaa !21
  %t151 = xor i1 %t149, true
  store i1 %t151, ptr %l83, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb34
bb34:
  %t153 = load i1, ptr %l83, !tbaa !21
  br i1 %t153, label %bb35, label %bb36
bb35:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l7, !tbaa !23
  %t161 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t159, i32 %t160, i64 %t161)
  store i32 %t165, ptr %l92
  br label %bb37
bb36:
  %t166 = load %"compiler/source:Span", ptr %l3
  %t167 = load i32, ptr %l7, !tbaa !23
  %t168 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t169
  %t170 = getelementptr { i64, [5 x i64] }, ptr %t169, i32 0, i32 0
  store i64 2, ptr %t170
  %t172 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t166, 0
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t172, i32 %t167, 1
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t174, ptr %t168, 2
  %t177 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t176, i32 -1, 3
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t169, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t177, ptr %t178
  %t179 = load { i64, [5 x i64] }, ptr %t169
  %t181 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t179, ptr %t181
  store ptr %t181, ptr %l10, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l7, !tbaa !23
  %t187 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t183, i32 %t184)
  store i1 %t187, ptr %l105
  br label %bb38
bb37:
  %t188 = load i32, ptr %l92, !tbaa !23
  store i32 %t188, ptr %l9, !tbaa !23
  %t189 = load %"compiler/source:Span", ptr %l3
  %t190 = load i32, ptr %l9, !tbaa !23
  %t191 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 0
  store i64 3, ptr %t193
  %t195 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t189, 0
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr } %t195, i32 %t190, 1
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } %t197, ptr %t191, 2
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t199, ptr %t200
  %t201 = load { i64, [5 x i64] }, ptr %t192
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t201, ptr %t203
  store ptr %t203, ptr %l10, !tbaa !29
  br label %bb47
bb38:
  %t205 = load i1, ptr %l105, !tbaa !21
  %t206 = xor i1 %t205, true
  br i1 %t206, label %bb39, label %bb40
bb39:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l7, !tbaa !23
  %t217 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t213, i32 %t214)
  store i1 %t217, ptr %l112
  br label %bb41
bb40:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb42
bb41:
  %t218 = load i1, ptr %l112, !tbaa !21
  store i1 %t218, ptr %l107, !tbaa !21
  br label %bb42
bb42:
  %t219 = load i1, ptr %l107, !tbaa !21
  br i1 %t219, label %bb43, label %bb44
bb43:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %t220, i32 %t221, i64 0)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 14
  %t227 = load ptr, ptr %l4, !tbaa !29
  %t229 = getelementptr %"compiler/check:frame", ptr %t227, i32 0, i32 0
  %t230 = load i64, ptr %t229, !tbaa !24
  %t233 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t226, i64 %t230)
  store ptr %t233, ptr %l119
  br label %bb48
bb48:
  %t234 = load ptr, ptr %l119, !tbaa !29
  store ptr %t234, ptr %l11, !tbaa !29
  %t235 = load ptr, ptr %l11, !tbaa !29
  store ptr %t235, ptr %l120, !tbaa !29
  %t236 = load i32, ptr %l2, !tbaa !23
  %t237 = load %"compiler/source:Span", ptr %l3
  %t238 = load i32, ptr %l9, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t239
  %t240 = getelementptr { i64, [1 x i64] }, ptr %t239, i32 0, i32 0
  store i64 4, ptr %t240
  %t241 = load { i64, [1 x i64] }, ptr %t239
  %t247 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t236, %"compiler/source:Span" %t237, i32 %t238, i32 0, i32 5, { i64, [1 x i64] } %t241)
  store %"compiler/typed:Local" %t247, ptr %l126
  br label %bb49
bb49:
  %t248 = load ptr, ptr %l120, !tbaa !29
  %t249 = load %"compiler/typed:Local", ptr %l126
  %t250 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t248, %"compiler/typed:Local" %t249)
  store i32 %t250, ptr %l127
  br label %bb50
bb50:
  %t251 = load i32, ptr %l127, !tbaa !23
  %t252 = sext i32 %t251 to i64
  store i64 %t252, ptr %l12, !tbaa !24
  %t254 = load ptr, ptr %l4, !tbaa !29
  %t256 = getelementptr %"compiler/check:frame", ptr %t254, i32 0, i32 8
  %t257 = load i32, ptr %l2, !tbaa !23
  %t258 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t256, i32 %t257, i64 %t258)
  br label %bb51
bb51:
  %t262 = load ptr, ptr %l4, !tbaa !29
  %t264 = getelementptr %"compiler/check:frame", ptr %t262, i32 0, i32 30
  store ptr %t264, ptr %l134, !tbaa !29
  %t265 = load i64, ptr %l12, !tbaa !24
  %t267 = trunc i64 %t265 to i32
  store i32 %t267, ptr %l137, !tbaa !23
  %t269 = load ptr, ptr %l10, !tbaa !29
  %t271 = icmp eq ptr %t269, null
  br i1 %t271, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af)
  unreachable
bb53:
  br label %bb54
bb54:
  %t273 = load ptr, ptr %l10, !tbaa !29
  %t274 = load i32, ptr %l137, !tbaa !23
  %t276 = call %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v0, i32 %t274, ptr %t273)
  store %"compiler/typed:Capture" %t276, ptr %l141
  br label %bb55
bb55:
  %t277 = load %"compiler/typed:Capture", ptr %l141
  %t278 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Capture" %t277, ptr %t278
  %t279 = load ptr, ptr %l134, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v0, ptr %t279, ptr %t278)
  br label %bb56
bb56:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load i32, ptr %l9, !tbaa !23
  %t285 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t281, i32 %t282)
  store i1 %t285, ptr %l145
  br label %bb57
bb57:
  %t286 = load i1, ptr %l145, !tbaa !21
  br i1 %t286, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l146, !tbaa !21
  br label %bb61
bb59:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/check:Checker", ptr %t287, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !29
  %t292 = getelementptr %"compiler/generic:Program", ptr %t290, i32 0, i32 2
  %t293 = load i32, ptr %l9, !tbaa !23
  %t296 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t292, i32 %t293)
  store i1 %t296, ptr %l151
  br label %bb60
bb60:
  %t297 = load i1, ptr %l151, !tbaa !21
  store i1 %t297, ptr %l146, !tbaa !21
  br label %bb61
bb61:
  %t298 = load i1, ptr %l146, !tbaa !21
  br i1 %t298, label %bb62, label %bb63
bb62:
  %t299 = load ptr, ptr %l11, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Body", ptr %t299, i32 0, i32 6
  %t302 = load i64, ptr %l12, !tbaa !24
  %t304 = trunc i64 %t302 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t306
  %t307 = getelementptr { i64, [1 x i64] }, ptr %t306, i32 0, i32 0
  store i64 4, ptr %t307
  %t309 = insertvalue { i32 } undef, i32 %t304, 0
  %t310 = getelementptr { i64, [1 x i64] }, ptr %t306, i32 0, i32 1
  store { i32 } %t309, ptr %t310
  %t311 = load { i64, [1 x i64] }, ptr %t306
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t301, { i64, [1 x i64] } %t311)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t314 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t314, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseCompare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"compiler/generic:Desc"
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca %"compiler/generic:Desc"
  %l36 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l47 = alloca ptr
  %l51 = alloca i32
  %l53 = alloca i1
  %l55 = alloca ptr
  %l57 = alloca %"compiler/source:Span"
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca %"compiler/msgs:Msg"
  %l67 = alloca i64
  %l70 = alloca ptr
  %l74 = alloca i1
  %l79 = alloca i32
  %l85 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca i32
  %l97 = alloca ptr
  %l98 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l104 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca ptr
  %l112 = alloca i1
  %l115 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca %"compiler/source:Span"
  %l123 = alloca i32
  %l126 = alloca i64
  %l127 = alloca ptr
  %l130 = alloca i1
  %l132 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca %"compiler/source:Span"
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l144 = alloca %"compiler/msgs:Msg"
  %l145 = alloca i64
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l151 = alloca ptr
  %l153 = alloca i64
  %l155 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l158 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l167 = alloca %"compiler/msgs:Msg"
  %l168 = alloca i64
  %l171 = alloca ptr
  %l173 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca i32
  %l178 = alloca ptr
  %l182 = alloca i32
  %l185 = alloca ptr
  %l186 = alloca ptr
  %l191 = alloca ptr
  %l194 = alloca ptr
  %l198 = alloca ptr
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t232 = alloca { i64, [3 x i64] }, align 8
  %t371 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t4, ptr %a3, i32 %t7)
  store ptr %t11, ptr %l17
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l17, !tbaa !29
  store ptr %t12, ptr %l5, !tbaa !29
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t13)
  store i32 %t16, ptr %l20
  br label %bb2
bb2:
  %t17 = load i32, ptr %l20, !tbaa !23
  store i32 %t17, ptr %l6, !tbaa !23
  %t18 = load i32, ptr %l6, !tbaa !23
  %t19 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t22 = icmp eq i32 %t18, %t19
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l1
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t24, %"compiler/source:Span" %t25)
  store ptr %t28, ptr %l26
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t29 = load ptr, ptr %l26, !tbaa !29
  store ptr %t29, ptr %rv
  br label %ret
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l6, !tbaa !23
  %t34 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l29
  br label %bb7
bb7:
  %t35 = load i32, ptr %l29, !tbaa !23
  store i32 %t35, ptr %l7, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t40 = call %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v2, ptr %t36, ptr %t37)
  store %"compiler/generic:Desc" %t40, ptr %l32
  br label %bb8
bb8:
  %t41 = load %"compiler/generic:Desc", ptr %l32
  store %"compiler/generic:Desc" %t41, ptr %l8
  %t42 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 0
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t47 = icmp eq i64 %t43, %t44
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 1
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load i32, ptr %l7, !tbaa !23
  %t61 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t54, i32 %t56, i32 %t57)
  store i1 %t61, ptr %l42
  br label %bb11
bb10:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb12
bb11:
  %t62 = load i1, ptr %l42, !tbaa !21
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l36, !tbaa !21
  br label %bb12
bb12:
  %t65 = load i1, ptr %l36, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  store ptr %t71, ptr %l47, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t80 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %t75, i32 %t77)
  store i32 %t80, ptr %l51
  br label %bb15
bb14:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb17
bb15:
  %t81 = load i32, ptr %l7, !tbaa !23
  %t82 = load ptr, ptr %l47, !tbaa !29
  %t83 = load i32, ptr %l51, !tbaa !23
  %t85 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t82, i32 %t83, i32 %t81)
  store i1 %t85, ptr %l53
  br label %bb16
bb16:
  %t86 = load i1, ptr %l53, !tbaa !21
  %t87 = xor i1 %t86, true
  store i1 %t87, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t89 = load i1, ptr %l44, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l55, !tbaa !29
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t93 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t91)
  store %"compiler/source:Span" %t93, ptr %l57
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 1
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t94, i32 %t96)
  store { i64, ptr } %t99, ptr %l60
  br label %bb21
bb21:
  %t100 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l61, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l7, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l64
  br label %bb22
bb22:
  %t112 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t119 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t121 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflCaseOther(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t119, { i64, ptr } %t118)
  store %"compiler/msgs:Msg" %t121, ptr %l66
  br label %bb23
bb23:
  %t122 = load ptr, ptr %l55, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l57
  %t124 = load %"compiler/msgs:Msg", ptr %l66
  %t125 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t122, %"compiler/source:Span" %t123, %"compiler/msgs:Msg" %t124)
  store i64 %t125, ptr %l67
  br label %bb24
bb24:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l1
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t126, %"compiler/source:Span" %t127)
  store ptr %t130, ptr %l70
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  %t131 = load ptr, ptr %l70, !tbaa !29
  store ptr %t131, ptr %rv
  br label %ret
bb26:
  %t132 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 0
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t137 = icmp eq i64 %t133, %t134
  br i1 %t137, label %bb27, label %bb28
bb27:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l7, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l79
  br label %bb29
bb28:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb30
bb29:
  %t149 = load i32, ptr %l79, !range !{i32 0, i32 33}
  %t151 = trunc i64 32 to i32
  %t152 = icmp eq i32 %t149, %t151
  store i1 %t152, ptr %l74, !tbaa !21
  br label %bb30
bb30:
  %t154 = load i1, ptr %l74, !tbaa !21
  br i1 %t154, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s3
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i32, ptr %l7, !tbaa !23
  %t162 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValCodes(ptr %v0, ptr %s3, ptr %t158, i32 %t159)
  store { i64, ptr } %t162, ptr %l85
  br label %bb33
bb32:
  br label %bb42
bb33:
  %t163 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t163, ptr %l9, !tbaa !27
  %t164 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 2
  %t165 = load i64, ptr %t164, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t171 = icmp sge i64 %t165, %t168
  br i1 %t171, label %bb34, label %bb35
bb34:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  %t177 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t173, %"compiler/source:Span" %t174)
  store ptr %t177, ptr %l92
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s3)
  %t178 = load ptr, ptr %l92, !tbaa !29
  store ptr %t178, ptr %rv
  br label %ret
bb37:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l93, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t180, ptr %l94
  %t181 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t181, ptr %l95
  %t182 = load i32, ptr %l2, !range !{i32 0, i32 98}
  store i32 %t182, ptr %l96
  %t183 = load ptr, ptr %l5, !tbaa !29
  store ptr %t183, ptr %l97, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l98, !tbaa !29
  %t185 = load ptr, ptr %l4, !tbaa !29
  %t187 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t185)
  store %"compiler/source:Span" %t187, ptr %l100
  br label %bb38
bb38:
  %t188 = load i32, ptr %l7, !tbaa !23
  %t189 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 2
  %t190 = load i64, ptr %t189, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i64, ptr %t193, i64 %t190
  %t195 = load i64, ptr %t194, !tbaa !34
  %t196 = load ptr, ptr %l98, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l100
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t196, %"compiler/source:Span" %t197, i32 %t188, i64 %t195)
  store ptr %t200, ptr %l104
  br label %bb39
bb39:
  %t201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t201, ptr %l105
  %t202 = load ptr, ptr %l4, !tbaa !29
  %t204 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t202)
  store %"compiler/source:Span" %t204, ptr %l107
  br label %bb40
bb40:
  %t205 = load ptr, ptr %l93, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l94
  %t207 = load %"compiler/source:Span", ptr %l95
  %t208 = load i32, ptr %l96, !range !{i32 0, i32 98}
  %t209 = load ptr, ptr %l97, !tbaa !29
  %t210 = load ptr, ptr %l104, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l105
  %t212 = load %"compiler/source:Span", ptr %l107
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t205, %"compiler/source:Span" %t206, %"compiler/source:Span" %t207, i32 %t208, ptr %t209, ptr %t210, %"compiler/source:Span" %t211, %"compiler/source:Span" %t212)
  store ptr %t213, ptr %l108
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  %t214 = load ptr, ptr %l108, !tbaa !29
  store ptr %t214, ptr %rv
  br label %ret
bb42:
  %t215 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 0
  %t216 = load i64, ptr %t215, !tbaa !24
  %t217 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t220 = icmp eq i64 %t216, %t217
  br i1 %t220, label %bb43, label %bb44
bb43:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i32, ptr %l7, !tbaa !23
  %t226 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t222, i32 %t223)
  store i1 %t226, ptr %l115
  br label %bb45
bb44:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb46
bb45:
  %t227 = load i1, ptr %l115, !tbaa !21
  store i1 %t227, ptr %l112, !tbaa !21
  br label %bb46
bb46:
  %t228 = load i1, ptr %l112, !tbaa !21
  br i1 %t228, label %bb47, label %bb48
bb47:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l1
  %t231 = load ptr, ptr %l5, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t232
  %t233 = getelementptr { i64, [3 x i64] }, ptr %t232, i32 0, i32 0
  store i64 2, ptr %t233
  %t235 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t230, 0
  %t237 = insertvalue { %"compiler/source:Span", ptr } %t235, ptr %t231, 1
  %t238 = getelementptr { i64, [3 x i64] }, ptr %t232, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t237, ptr %t238
  %t239 = load { i64, [3 x i64] }, ptr %t232
  %t241 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t239, ptr %t241
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t229, ptr %t241)
  br label %bb49
bb48:
  br label %bb54
bb49:
  %t244 = load ptr, ptr %l0, !tbaa !29
  store ptr %t244, ptr %l121, !tbaa !29
  %t245 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t245, ptr %l122
  %t246 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t246, ptr %l123, !tbaa !23
  %t247 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t249 = trunc i64 78 to i32
  %t250 = icmp eq i32 %t247, %t249
  br i1 %t250, label %bb50, label %bb51
bb50:
  store i64 1, ptr %l126, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb52
bb52:
  %t252 = load ptr, ptr %l121, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l122
  %t254 = load i32, ptr %l123, !tbaa !23
  %t255 = load i64, ptr %l126, !tbaa !24
  %t256 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t252, %"compiler/source:Span" %t253, i32 %t254, i64 %t255)
  store ptr %t256, ptr %l127
  br label %bb53
bb53:
  %t257 = load ptr, ptr %l127, !tbaa !29
  store ptr %t257, ptr %rv
  br label %ret
bb54:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i32, ptr %l7, !tbaa !23
  %t262 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t258, i32 %t259)
  store i1 %t262, ptr %l130
  br label %bb55
bb55:
  %t263 = load i1, ptr %l130, !tbaa !21
  %t264 = xor i1 %t263, true
  br i1 %t264, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s6
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l132, !tbaa !29
  %t267 = load ptr, ptr %l4, !tbaa !29
  %t269 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t267)
  store %"compiler/source:Span" %t269, ptr %l134
  br label %bb58
bb57:
  br label %bb66
bb58:
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l135, !tbaa !29
  %t271 = load ptr, ptr %l4, !tbaa !29
  %t273 = call ptr @compiler_2fcheck_2ecasePath(ptr %v2, ptr %v2, ptr %t271)
  store ptr %t273, ptr %l137
  br label %bb59
bb59:
  %t274 = load ptr, ptr %l137, !tbaa !29
  %t275 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t274)
  store %"compiler/source:Span" %t275, ptr %l138
  br label %bb60
bb60:
  %t276 = load ptr, ptr %l135, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l138
  %t278 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t276, %"compiler/source:Span" %t277)
  store { i64, ptr } %t278, ptr %l139
  br label %bb61
bb61:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load i32, ptr %l7, !tbaa !23
  %t283 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t279, i32 %t280)
  store { i64, ptr } %t283, ptr %l142
  br label %bb62
bb62:
  %t284 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  %t286 = extractvalue { i64, ptr } %t284, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  %t291 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t293 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTestNotEnum(ptr %v0, ptr %s6, ptr %s6, { i64, ptr } %t291, { i64, ptr } %t290)
  store %"compiler/msgs:Msg" %t293, ptr %l144
  br label %bb63
bb63:
  %t294 = load ptr, ptr %l132, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l134
  %t296 = load %"compiler/msgs:Msg", ptr %l144
  %t297 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t294, %"compiler/source:Span" %t295, %"compiler/msgs:Msg" %t296)
  store i64 %t297, ptr %l145
  br label %bb64
bb64:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load %"compiler/source:Span", ptr %l1
  %t302 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t298, %"compiler/source:Span" %t299)
  store ptr %t302, ptr %l148
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s6)
  %t303 = load ptr, ptr %l148, !tbaa !29
  store ptr %t303, ptr %rv
  br label %ret
bb66:
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l149, !tbaa !29
  %t305 = load ptr, ptr %l4, !tbaa !29
  %t307 = call ptr @compiler_2fcheck_2ecasePath(ptr %v2, ptr %v2, ptr %t305)
  store ptr %t307, ptr %l151
  br label %bb67
bb67:
  %t308 = load i32, ptr %l7, !tbaa !23
  %t309 = load ptr, ptr %l149, !tbaa !29
  %t310 = load ptr, ptr %l151, !tbaa !29
  %t312 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v2, ptr %t309, ptr %t310, i32 %t308)
  store i64 %t312, ptr %l153
  br label %bb68
bb68:
  %t313 = load i64, ptr %l153, !tbaa !24
  %t314 = icmp slt i64 %t313, 0
  br i1 %t314, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s7
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l155, !tbaa !29
  %t317 = load ptr, ptr %l4, !tbaa !29
  %t319 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t317)
  store %"compiler/source:Span" %t319, ptr %l157
  br label %bb71
bb70:
  br label %bb79
bb71:
  %t320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t320, ptr %l158, !tbaa !29
  %t321 = load ptr, ptr %l4, !tbaa !29
  %t323 = call ptr @compiler_2fcheck_2ecasePath(ptr %v2, ptr %v2, ptr %t321)
  store ptr %t323, ptr %l160
  br label %bb72
bb72:
  %t324 = load ptr, ptr %l160, !tbaa !29
  %t325 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t324)
  store %"compiler/source:Span" %t325, ptr %l161
  br label %bb73
bb73:
  %t326 = load ptr, ptr %l158, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l161
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t326, %"compiler/source:Span" %t327)
  store { i64, ptr } %t328, ptr %l162
  br label %bb74
bb74:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l7, !tbaa !23
  %t333 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t329, i32 %t330)
  store { i64, ptr } %t333, ptr %l165
  br label %bb75
bb75:
  %t334 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 0
  %t336 = extractvalue { i64, ptr } %t334, 1
  %t337 = mul i64 %t335, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t336, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  %t341 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t343 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTestOther(ptr %v0, ptr %s7, ptr %s7, { i64, ptr } %t341, { i64, ptr } %t340)
  store %"compiler/msgs:Msg" %t343, ptr %l167
  br label %bb76
bb76:
  %t344 = load ptr, ptr %l155, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l157
  %t346 = load %"compiler/msgs:Msg", ptr %l167
  %t347 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t344, %"compiler/source:Span" %t345, %"compiler/msgs:Msg" %t346)
  store i64 %t347, ptr %l168
  br label %bb77
bb77:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l1
  %t352 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t348, %"compiler/source:Span" %t349)
  store ptr %t352, ptr %l171
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s7)
  %t353 = load ptr, ptr %l171, !tbaa !29
  store ptr %t353, ptr %rv
  br label %ret
bb79:
  %t354 = load ptr, ptr %l5, !tbaa !29
  %t356 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v3, ptr %v3, ptr %t354)
  store ptr %t356, ptr %l173
  br label %bb80
bb80:
  %t357 = load ptr, ptr %l173, !tbaa !29
  store ptr %t357, ptr %l10, !tbaa !29
  %t358 = load ptr, ptr %l10, !tbaa !29
  %t360 = icmp eq ptr %t358, null
  br i1 %t360, label %bb81, label %bb82
bb81:
  %t362 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t362, ptr %l176
  %t363 = load i32, ptr %l6, !tbaa !23
  store i32 %t363, ptr %l177, !tbaa !23
  %t364 = load ptr, ptr %l5, !tbaa !29
  store ptr %t364, ptr %l178, !tbaa !29
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l1
  %t370 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t365, i32 8, %"compiler/source:Span" %t366)
  store i32 %t370, ptr %l182
  br label %bb83
bb82:
  br label %bb84
bb83:
  store { i64, [4 x i64] } zeroinitializer, ptr %t371
  %t372 = getelementptr { i64, [4 x i64] }, ptr %t371, i32 0, i32 0
  store i64 6, ptr %t372
  %t373 = load %"compiler/source:Span", ptr %l176
  %t374 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t373, 0
  %t375 = load i32, ptr %l177, !tbaa !23
  %t376 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t374, i32 %t375, 1
  %t377 = load ptr, ptr %l178, !tbaa !29
  %t378 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t376, ptr %t377, 2
  %t379 = load i32, ptr %l182, !tbaa !23
  %t380 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t378, i32 %t379, 3
  %t381 = getelementptr { i64, [4 x i64] }, ptr %t371, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t380, ptr %t381
  %t382 = load { i64, [4 x i64] }, ptr %t371
  %t384 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t382, ptr %t384
  store ptr %t384, ptr %l10, !tbaa !29
  br label %bb84
bb84:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l185, !tbaa !29
  %t387 = load ptr, ptr %l4, !tbaa !29
  store ptr %t387, ptr %l186, !tbaa !29
  %t388 = load ptr, ptr %l10, !tbaa !29
  %t390 = icmp eq ptr %t388, null
  br i1 %t390, label %bb85, label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_e1487403b47c0485_2c2fc5ff7a99fd49)
  unreachable
bb86:
  br label %bb87
bb87:
  %t392 = load ptr, ptr %l10, !tbaa !29
  %t393 = load i32, ptr %l6, !tbaa !23
  %t394 = load ptr, ptr %l185, !tbaa !29
  %t395 = load ptr, ptr %l186, !tbaa !29
  %t398 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v2, ptr %v3, ptr %v3, ptr %t394, ptr %t395, ptr %t392, i32 %t393)
  store ptr %t398, ptr %l191
  br label %bb88
bb88:
  %t399 = load ptr, ptr %l191, !tbaa !29
  store ptr %t399, ptr %l11, !tbaa !29
  %t400 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t402 = trunc i64 79 to i32
  %t403 = icmp eq i32 %t400, %t402
  br i1 %t403, label %bb89, label %bb90
bb89:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load %"compiler/source:Span", ptr %l1
  %t407 = load ptr, ptr %l11, !tbaa !29
  %t411 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t405, %"compiler/source:Span" %t406, ptr %t407)
  store ptr %t411, ptr %l198
  br label %bb91
bb90:
  %t412 = load ptr, ptr %l11, !tbaa !29
  store ptr %t412, ptr %l194, !tbaa !29
  br label %bb92
bb91:
  %t414 = load ptr, ptr %l198, !tbaa !29
  store ptr %t414, ptr %l194, !tbaa !29
  br label %bb92
bb92:
  %t415 = load ptr, ptr %l194, !tbaa !29
  store ptr %t415, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l11 = alloca %"compiler/generic:Desc"
  %l15 = alloca %"compiler/generic:Desc"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/generic:Desc"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp sle i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescNone, !tbaa !24
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = call %"compiler/generic:Desc" @compiler_2fgeneric_3aDesc_2ector(ptr %s1, i64 %t13, i32 %t14, i64 0, i64 0)
  store %"compiler/generic:Desc" %t17, ptr %l11
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  %t18 = load %"compiler/generic:Desc", ptr %l11
  store %"compiler/generic:Desc" %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t26 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t22, i32 %t23)
  store %"compiler/generic:Desc" %t26, ptr %l15
  br label %bb6
bb6:
  %t27 = load %"compiler/generic:Desc", ptr %l15
  store %"compiler/generic:Desc" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Desc", ptr %rv
  ret %"compiler/generic:Desc" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l40 = alloca ptr
  %l42 = alloca ptr
  %l46 = alloca %"compiler/names:Ref"
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l53 = alloca { i64, ptr }
  %l55 = alloca %"compiler/msgs:Msg"
  %l56 = alloca i64
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l65 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l69 = alloca i1
  %l72 = alloca i1
  %l75 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t15 = load ptr, ptr %l12, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb7
bb5:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 30}
  %t21 = icmp eq i64 %t19, 0
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", ptr }, ptr %t26, i32 0, i32 1
  %t28 = load ptr, ptr %t27
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32 }, ptr %t30, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  store %"compiler/source:Span" %t32, ptr %l3
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32 }, ptr %t40, i32 0, i32 1
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l4, !tbaa !23
  br label %bb19
bb9:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l22, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 8}
  %t51 = icmp eq i64 %t49, 4
  store i1 %t51, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t52 = load i1, ptr %l23, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", ptr }, ptr %t55, i32 0, i32 1
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t58 = load ptr, ptr %l28, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb16
bb14:
  %t61 = load ptr, ptr %l28, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 30}
  %t64 = icmp eq i64 %t62, 0
  store i1 %t64, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t65 = load i1, ptr %l29, !tbaa !21
  store i1 %t65, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t66 = load i1, ptr %l26, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr }, ptr %t69, i32 0, i32 1
  %t71 = load ptr, ptr %t70
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32 }, ptr %t73, i32 0, i32 0
  %t75 = load %"compiler/source:Span", ptr %t74
  store %"compiler/source:Span" %t75, ptr %l3
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", ptr }, ptr %t79, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32 }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l4, !tbaa !23
  br label %bb19
bb18:
  br label %bb44
bb19:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  store ptr %t93, ptr %l40, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t94)
  store ptr %t96, ptr %l42
  br label %bb20
bb20:
  %t97 = load ptr, ptr %l42, !tbaa !29
  %t99 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 2
  %t100 = load i64, ptr %t99, !tbaa !24
  %t101 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t103 = load ptr, ptr %l40, !tbaa !29
  %t106 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t103, i64 %t100, i32 %t102)
  store %"compiler/names:Ref" %t106, ptr %l46
  br label %bb21
bb21:
  %t107 = load %"compiler/names:Ref", ptr %l46
  store %"compiler/names:Ref" %t107, ptr %l5
  %t108 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t109 = load i32, ptr %t108, !range !{i32 0, i32 9}
  %t111 = trunc i64 0 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s2
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l49, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t115, ptr %l50
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l4, !tbaa !23
  %t120 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s2, ptr %t116, i32 %t117)
  store { i64, ptr } %t120, ptr %l53
  br label %bb24
bb23:
  br label %bb30
bb24:
  %t121 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  %t123 = extractvalue { i64, ptr } %t121, 1
  %t124 = mul i64 %t122, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  %t129 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %s2, ptr %s2, { i64, ptr } %t127)
  store %"compiler/msgs:Msg" %t129, ptr %l55
  br label %bb25
bb25:
  %t130 = load ptr, ptr %l49, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l50
  %t132 = load %"compiler/msgs:Msg", ptr %l55
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t130, %"compiler/source:Span" %t131, %"compiler/msgs:Msg" %t132)
  store i64 %t133, ptr %l56
  br label %bb26
bb26:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 87
  store ptr %t136, ptr %l58, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t137)
  store ptr %t139, ptr %l60
  br label %bb27
bb27:
  %t140 = load ptr, ptr %l60, !tbaa !29
  %t142 = getelementptr %"compiler/check:frame", ptr %t140, i32 0, i32 0
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = load i32, ptr %l4, !tbaa !23
  %t146 = sext i32 %t144 to i64
  %t149 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t143, i64 %t146)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t149, ptr %l65
  br label %bb28
bb28:
  %t150 = load ptr, ptr %l58, !tbaa !29
  %t151 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l65
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t150, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t151, i1 true)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb30:
  %t153 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t154 = load i32, ptr %t153, !range !{i32 0, i32 9}
  %t156 = trunc i64 1 to i32
  %t157 = icmp eq i32 %t154, %t156
  br i1 %t157, label %bb31, label %bb32
bb31:
  %t159 = load i64, ptr %l2, !tbaa !24
  %t161 = icmp sge i64 %t159, 0
  store i1 %t161, ptr %l69, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb33
bb33:
  %t163 = load i1, ptr %l69, !tbaa !21
  br i1 %t163, label %bb34, label %bb35
bb34:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l4, !tbaa !23
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t164, i32 %t165)
  store i64 %t168, ptr %l75
  br label %bb36
bb35:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb37
bb36:
  %t169 = load i64, ptr %l2, !tbaa !24
  %t170 = load i64, ptr %l75, !tbaa !24
  %t172 = icmp eq i64 %t170, %t169
  store i1 %t172, ptr %l72, !tbaa !21
  br label %bb37
bb37:
  %t174 = load i1, ptr %l72, !tbaa !21
  br i1 %t174, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s3
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l78, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t176, ptr %l79
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l4, !tbaa !23
  %t181 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t177, i32 %t178)
  store { i64, ptr } %t181, ptr %l82
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t182 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t190 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %s3, ptr %s3, { i64, ptr } %t188)
  store %"compiler/msgs:Msg" %t190, ptr %l84
  br label %bb41
bb41:
  %t191 = load ptr, ptr %l78, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l79
  %t193 = load %"compiler/msgs:Msg", ptr %l84
  %t194 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t191, %"compiler/source:Span" %t192, %"compiler/msgs:Msg" %t193)
  store i64 %t194, ptr %l85
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_3cf4b7359f29899a_630bdcef83a186)
  unreachable
bb49:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i32
  %l9 = alloca { i64, ptr }
  %l13 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:CaseDecl", ptr %t1, i32 0, i32 0
  %t4 = getelementptr %"compiler/source:Span", ptr %t3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:CaseDecl", ptr %t6, i32 0, i32 0
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/ast:CaseDecl", ptr %t12, i32 0, i32 1
  %t15 = load i32, ptr %t14, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %a0, i32 %t15)
  store { i64, ptr } %t18, ptr %l9
  br label %bb1
bb1:
  %t19 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t22 = trunc i64 %t20 to i32
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = add i32 %t23, %t22
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t26, i32 %t25)
  store %"compiler/source:Span" %t28, ptr %l13
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i8, ptr %t16, i64 0
  %t18 = load i8, ptr %t17, !tbaa !32
  %t20 = zext i8 %t18 to i64
  store i64 %t20, ptr %l10, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i64, ptr %l10, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, { i64, ptr } %a6, i32 %a7, i64 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l8 = alloca i64
  %lp9 = alloca ptr
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l22 = alloca { i64, [3 x i64] }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca %"compiler/typed:ContractInfo"
  %l35 = alloca %"compiler/typed:ContractInfo"
  %l36 = alloca i32
  %l38 = alloca %"compiler/typed:ContractInfo"
  %l41 = alloca i64
  %l43 = alloca i1
  %l45 = alloca ptr
  %l49 = alloca i1
  %l51 = alloca i1
  %l56 = alloca ptr
  %l63 = alloca ptr
  %l67 = alloca i64
  %l68 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca i32
  %l78 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %l81 = alloca %"compiler/typed:ContractInfo"
  %l83 = alloca %"compiler/typed:ContractInfo"
  %l84 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l96 = alloca i1
  %l102 = alloca ptr
  %l113 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l117 = alloca i64
  %l121 = alloca i64
  %l124 = alloca i64
  %l142 = alloca ptr
  %l143 = alloca i64
  %l144 = alloca %"compiler/source:Span"
  %l145 = alloca i64
  %l148 = alloca i64
  %l150 = alloca i64
  %l152 = alloca ptr
  %l153 = alloca i64
  %l154 = alloca i64
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca i64
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l168 = alloca %"compiler/check:ContractAsk"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t295 = alloca %"compiler/check:ContractAsk", align 8
  %t306 = alloca %"compiler/check:ContractAsk", align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  store i64 %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 115
  %t4 = load i64, ptr %l8, !tbaa !24
  %t7 = call { i32, %"compiler/typed:ContractInfo" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H1fc1bd863e6a60d3e5c2aece55d841d1(ptr %v0, ptr %v4, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, %"compiler/typed:ContractInfo" } %t7, 1
  %t9 = extractvalue { i32, %"compiler/typed:ContractInfo" } %t7, 0
  store i32 %t9, ptr %l36
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store %"compiler/typed:ContractInfo" %t8, ptr %l35
  br label %bb1
bb1:
  %t13 = call %"compiler/typed:ContractInfo" @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aContractInfo(ptr %v4, ptr %l35)
  store %"compiler/typed:ContractInfo" %t13, ptr %l38
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t14 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t14, ptr %rv
  br label %ret
bb4:
  %t16 = load %"compiler/typed:ContractInfo", ptr %l38
  store %"compiler/typed:ContractInfo" %t16, ptr %l31
  br label %bb5
bb5:
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 120, i64 8)
  store ptr %t17, ptr %lp9
  %t18 = load %"compiler/typed:ContractInfo", ptr %l31
  %t19 = load ptr, ptr %lp9
  store %"compiler/typed:ContractInfo" %t18, ptr %t19
  %t20 = load ptr, ptr %lp9
  %t21 = getelementptr %"compiler/typed:ContractInfo", ptr %t20, i32 0, i32 2
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v4, ptr %t21)
  store i64 %t23, ptr %l41
  br label %bb6
bb6:
  %t24 = load i64, ptr %l41, !tbaa !24
  %t25 = icmp eq i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb10
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t27)
  store ptr %t29, ptr %l45
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l45, !tbaa !29
  %t32 = getelementptr %"compiler/check:frame", ptr %t30, i32 0, i32 0
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  store i1 %t35, ptr %l43, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l43, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb14
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %t38)
  store i1 %t40, ptr %l51
  br label %bb13
bb13:
  %t41 = load i1, ptr %l51, !tbaa !21
  store i1 %t41, ptr %l49, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l49, !tbaa !21
  br i1 %t42, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t43, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 14
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t47, i64 %t48)
  store ptr %t51, ptr %l56
  br label %bb18
bb18:
  %t52 = load ptr, ptr %l56, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 1
  %t55 = load { i64, [2 x i64] }, ptr %t54
  store { i64, [2 x i64] } %t55, ptr %l10
  %t57 = load { i64, [2 x i64] }, ptr %l10
  %t59 = extractvalue { i64, [2 x i64] } %t57, 0
  %t60 = icmp eq i64 %t59, 0
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t62 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t63 = getelementptr { i64 }, ptr %t62, i32 0, i32 0
  %t64 = load i64, ptr %t63
  store i64 %t64, ptr %l11, !tbaa !24
  br label %bb21
bb20:
  br label %bb27
bb21:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  store ptr %t69, ptr %l63, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t73, i64 %t74)
  store i64 %t77, ptr %l67
  br label %bb22
bb22:
  %t78 = load ptr, ptr %l63, !tbaa !29
  %t79 = load i64, ptr %l67, !tbaa !24
  %t80 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t78, i64 %t79)
  store i1 %t80, ptr %l68
  br label %bb23
bb23:
  %t81 = load i1, ptr %l68, !tbaa !21
  br i1 %t81, label %bb24, label %bb25
bb24:
  %t82 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t82, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_cc784a1e8fddb41e_ee964d456644b6b2)
  unreachable
bb32:
  %t84 = load ptr, ptr %l4, !tbaa !29
  store ptr %t84, ptr %l12, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  store ptr %t86, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t87 = load ptr, ptr %l71, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb33, label %bb34
bb33:
  %t90 = load ptr, ptr %l71, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 5}
  %t93 = icmp eq i64 %t91, 3
  store i1 %t93, ptr %l72, !tbaa !21
  br label %bb34
bb34:
  %t94 = load i1, ptr %l72, !tbaa !21
  br i1 %t94, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l75, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t96, ptr %l76
  store i32 %a3, ptr %l77, !tbaa !23
  %t98 = load ptr, ptr %l5, !tbaa !29
  store ptr %t98, ptr %l78, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t99, ptr %l79, !tbaa !27
  store i32 %a7, ptr %l80, !tbaa !23
  %t101 = load ptr, ptr %lp9
  %t102 = load %"compiler/typed:ContractInfo", ptr %t101
  store %"compiler/typed:ContractInfo" %t102, ptr %l81
  %t104 = call %"compiler/typed:ContractInfo" @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aContractInfo(ptr %v1, ptr %l81)
  store %"compiler/typed:ContractInfo" %t104, ptr %l83
  br label %bb38
bb38:
  %t105 = load ptr, ptr %l75, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l76
  %t107 = load i32, ptr %l77, !tbaa !23
  %t108 = load ptr, ptr %l78, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t110 = load i32, ptr %l80, !tbaa !23
  %t111 = load %"compiler/typed:ContractInfo", ptr %l83
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edispatchChecks(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %v1, ptr %t105, %"compiler/source:Span" %t106, i32 %t107, ptr %t108, { i64, ptr } %t109, i32 %t110, %"compiler/typed:ContractInfo" %t111)
  store ptr %t112, ptr %l84
  br label %bb39
bb39:
  %t113 = load ptr, ptr %l84, !tbaa !29
  store ptr %t113, ptr %l12, !tbaa !29
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_34d74ab5dd8a1e9f_be34dcde3b606033)
  unreachable
bb45:
  %t114 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t114, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l15, !tbaa !24
  br label %bb46
bb46:
  %t120 = load i64, ptr %l14, !tbaa !24
  %t121 = load i64, ptr %l15, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb47, label %bb48
bb47:
  br label %bb55
bb48:
  br label %bb49
bb49:
  %t128 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t128, ptr %l92, !tbaa !27
  %t129 = load i64, ptr %l14, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr ptr, ptr %t132, i64 %t129
  %t134 = load ptr, ptr %t133, !tbaa !39
  %t138 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v3, ptr %t134)
  store i1 %t138, ptr %l96
  br label %bb50
bb50:
  %t139 = load i1, ptr %l96, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb51, label %bb52
bb51:
  %t142 = load ptr, ptr %l12, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t142, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t144 = load i64, ptr %l14, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l14, !tbaa !24
  br label %bb46
bb55:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t148)
  store ptr %t150, ptr %l102
  br label %bb56
bb56:
  %t151 = load ptr, ptr %l102, !tbaa !29
  store ptr %t151, ptr %l17, !tbaa !29
  %t152 = load ptr, ptr %l17, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t152, i32 0, i32 1
  %t155 = load i64, ptr %t154, !tbaa !24
  store i64 %t155, ptr %l18, !tbaa !24
  %t157 = load ptr, ptr %l17, !tbaa !29
  %t159 = getelementptr %"compiler/check:frame", ptr %t157, i32 0, i32 2
  %t160 = load i64, ptr %t159, !tbaa !24
  store i64 %t160, ptr %l19, !tbaa !24
  %t162 = load ptr, ptr %l17, !tbaa !29
  %t164 = getelementptr %"compiler/check:frame", ptr %t162, i32 0, i32 0
  %t165 = load i64, ptr %t164, !tbaa !24
  store i64 %t165, ptr %l20, !tbaa !24
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 0
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/load:Loader", ptr %t173, i32 0, i32 4
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t178 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %s0, ptr %t176)
  store { { i64, [3 x i64] }, { i64, ptr } } %t178, ptr %l113
  br label %bb57
bb57:
  %t179 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l113
  store { { i64, [3 x i64] }, { i64, ptr } } %t179, ptr %l21
  %t180 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l21, i32 0, i32 0
  %t181 = load { i64, [3 x i64] }, ptr %t180
  store { i64, [3 x i64] } %t181, ptr %l22
  %t183 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l21, i32 0, i32 1
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  store { i64, ptr } %t184, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t186 = load ptr, ptr %lp9
  %t187 = getelementptr %"compiler/typed:ContractInfo", ptr %t186, i32 0, i32 2
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v4, ptr %t187)
  store i64 %t189, ptr %l117
  br label %bb58
bb58:
  %t190 = load i64, ptr %l117, !tbaa !24
  store i64 %t190, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t191 = load i64, ptr %l25, !tbaa !24
  %t192 = load i64, ptr %l24, !tbaa !24
  %t195 = icmp sgt i64 %t191, %t192
  br i1 %t195, label %bb59, label %bb60
bb59:
  %t197 = load i64, ptr %l26, !tbaa !24
  %t199 = icmp sgt i64 %t197, 0
  br i1 %t199, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb64
bb61:
  %t201 = load i64, ptr %l25, !tbaa !24
  %t202 = load i64, ptr %l24, !tbaa !24
  %t205 = sub i64 %t201, %t202
  %t206 = load i64, ptr %l26, !tbaa !24
  %t209 = add i64 %t205, %t206
  %t211 = sub i64 %t209, 1
  %t212 = load i64, ptr %l26, !tbaa !24
  %t215 = sdiv i64 %t211, %t212
  store i64 %t215, ptr %l124, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb63
bb63:
  %t217 = load i64, ptr %l124, !tbaa !24
  store i64 %t217, ptr %l121, !tbaa !24
  br label %bb64
bb64:
  %t218 = load i64, ptr %l121, !tbaa !24
  store i64 %t218, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb65
bb65:
  %t219 = load i64, ptr %l28, !tbaa !24
  %t220 = load i64, ptr %l27, !tbaa !24
  %t223 = icmp slt i64 %t219, %t220
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb66, label %bb67
bb66:
  br label %bb77
bb67:
  br label %bb68
bb68:
  %t227 = load i64, ptr %l24, !tbaa !24
  %t228 = load i64, ptr %l28, !tbaa !24
  %t229 = load i64, ptr %l26, !tbaa !24
  %t232 = mul i64 %t228, %t229
  %t235 = add i64 %t227, %t232
  store i64 %t235, ptr %l29, !tbaa !24
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l142, !tbaa !29
  %t238 = load i64, ptr %l18, !tbaa !24
  store i64 %t238, ptr %l143, !tbaa !24
  %t239 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t239, ptr %l144
  %t240 = load i64, ptr %l20, !tbaa !24
  store i64 %t240, ptr %l145, !tbaa !24
  %t241 = load ptr, ptr %lp9
  %t242 = getelementptr %"compiler/typed:ContractInfo", ptr %t241, i32 0, i32 2
  %t243 = load i64, ptr %l29, !tbaa !24
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t242, i64 %t243)
  store i64 %t246, ptr %l148
  br label %bb69
bb69:
  %t247 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t248 = load ptr, ptr %l142, !tbaa !29
  %t249 = load i64, ptr %l143, !tbaa !24
  %t250 = load %"compiler/source:Span", ptr %l144
  %t251 = load i64, ptr %l145, !tbaa !24
  %t252 = load i64, ptr %l148, !tbaa !24
  %t254 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkBody(ptr %v0, ptr %v3, ptr %t248, i64 %t249, %"compiler/source:Span" %t250, i64 %t251, i64 %t252, { i64, ptr } %t247)
  store i64 %t254, ptr %l150
  br label %bb70
bb70:
  %t255 = load i64, ptr %l150, !tbaa !24
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 117
  store ptr %t258, ptr %l152, !tbaa !29
  store i64 %t255, ptr %l153, !tbaa !24
  %t260 = load i64, ptr %l19, !tbaa !24
  store i64 %t260, ptr %l154, !tbaa !24
  store %"compiler/source:Span" %a2, ptr %l155
  %t262 = load ptr, ptr %lp9
  %t263 = getelementptr %"compiler/typed:ContractInfo", ptr %t262, i32 0, i32 1
  %t264 = load i64, ptr %t263, !tbaa !24
  store i64 %t264, ptr %l156, !tbaa !24
  %t265 = load ptr, ptr %lp9
  %t266 = getelementptr %"compiler/typed:ContractInfo", ptr %t265, i32 0, i32 3
  %t267 = load i64, ptr %l29, !tbaa !24
  %t270 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v4, ptr %t266, i64 %t267)
  store %"compiler/source:Span" %t270, ptr %l159
  br label %bb71
bb71:
  %t271 = load ptr, ptr %lp9
  %t272 = getelementptr %"compiler/typed:ContractInfo", ptr %t271, i32 0, i32 0
  %t273 = load { i64, ptr }, ptr %t272, !tbaa !27
  store { i64, ptr } %t273, ptr %l160, !tbaa !27
  %t274 = load ptr, ptr %lp9
  %t275 = getelementptr %"compiler/typed:ContractInfo", ptr %t274, i32 0, i32 4
  %t276 = load i64, ptr %l29, !tbaa !24
  %t279 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v4, ptr %v4, ptr %t275, i64 %t276)
  store { i64, ptr } %t279, ptr %l163
  br label %bb72
bb72:
  %t280 = load { i64, [3 x i64] }, ptr %l22
  %t281 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t281, 1
  %t284 = extractvalue { i64, ptr } %t281, 0
  %t285 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t284)
  call void @olang_textcopy(ptr %t285, ptr %t283, i64 %t284)
  %t286 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t290 = extractvalue { i64, ptr } %t287, 1
  %t291 = mul i64 %t289, 1
  %t292 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t291)
  call void @llvm.memcpy.p0.p0.i64(ptr %t292, ptr %t290, i64 %t291, i1 false)
  %t293 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  %t296 = load i64, ptr %l153, !tbaa !24
  %t297 = load i64, ptr %l154, !tbaa !24
  %t298 = load %"compiler/source:Span", ptr %l155
  %t299 = load i64, ptr %l156, !tbaa !24
  %t300 = load %"compiler/source:Span", ptr %l159
  %t301 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l163, !tbaa !27
  call void @compiler_2fcheck_3aContractAsk_2ector(ptr %t295, ptr %v4, ptr %v4, ptr %v0, ptr %v0, ptr %v0, i64 %t296, i64 %t297, %"compiler/source:Span" %t298, i64 %t299, %"compiler/source:Span" %t300, { i64, ptr } %t301, { i64, ptr } %t302, { i64, [3 x i64] } %t280, { i64, ptr } %t294, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  call void @llvm.memmove.p0.p0.i64(ptr %l168, ptr %t295, i64 136, i1 false)
  br label %bb73
bb73:
  %t305 = load ptr, ptr %l152, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t306, ptr %l168, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ePu_H286c5e5dcd81788bf1de6ef6fc9774a9(ptr %v0, ptr %v0, ptr %t305, ptr %t306)
  br label %bb74
bb74:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 118
  %t310 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t309, i64 %t310)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t313 = load i64, ptr %l28, !tbaa !24
  %t315 = add i64 %t313, 1
  store i64 %t315, ptr %l28, !tbaa !24
  br label %bb65
bb77:
  %t317 = load ptr, ptr %l12, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t317, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %lp6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i32
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l41 = alloca i64
  %l46 = alloca i64
  %l48 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l66 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l77 = alloca i32
  %l83 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %a2)
  store i32 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i32, ptr %l12, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d9, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i32 %t15, ptr %l14
  br label %bb3
bb3:
  %t16 = load i32, ptr %l14, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 0, i64 8)
  store ptr %t17, ptr %lp6
  %t19 = load ptr, ptr %lp6
  store [0 x i32] zeroinitializer, ptr %t19
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l20
  br label %bb4
bb4:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l4, !tbaa !23
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l26
  br label %bb7
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t41 = load i1, ptr %l26, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l21, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %t45, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d12, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d13, i32 0, i32 1) }, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i32 %t47, ptr %l29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = mul i64 2, 4
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 2, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l31, !tbaa !27
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 0
  store i32 %t53, ptr %t56, !tbaa !33
  %t58 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 1
  store i32 %t48, ptr %t60, !tbaa !33
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t71, ptr %l36
  br label %bb13
bb13:
  %t72 = load i1, ptr %l36, !tbaa !21
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l4, !tbaa !23
  %t82 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t78, i32 %t79)
  store i64 %t82, ptr %l41
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l3, !tbaa !23
  %t92 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t88, i32 %t89)
  store i64 %t92, ptr %l46
  br label %bb17
bb17:
  %t93 = load i64, ptr %l41, !tbaa !24
  %t94 = load i64, ptr %l46, !tbaa !24
  %t95 = icmp slt i64 %t93, %t94
  br i1 %t95, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  %t97 = load i32, ptr %l4, !tbaa !23
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = icmp ne i32 %t97, %t98
  store i1 %t101, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t103 = load i1, ptr %l48, !tbaa !21
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t104 = load i32, ptr %l5, !tbaa !23
  %t105 = mul i64 1, 4
  %t106 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 1, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l54, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 0
  store i32 %t104, ptr %t112, !tbaa !33
  %t113 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  br label %bb23
bb22:
  %t114 = load ptr, ptr %lp6
  %t116 = insertvalue { i64, ptr } undef, i64 0, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t114, 1
  store { i64, ptr } %t117, ptr %l52, !tbaa !27
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t119, ptr %rv
  br label %ret
bb24:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l4, !tbaa !23
  %t129 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t125, i32 %t126)
  store i1 %t129, ptr %l61
  br label %bb25
bb25:
  %t130 = load i1, ptr %l61, !tbaa !21
  br i1 %t130, label %bb26, label %bb27
bb26:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l4, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t136, i32 %t137)
  store i64 %t140, ptr %l66
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t141 = load i64, ptr %l66, !tbaa !24
  %t142 = icmp sle i64 %t141, 16
  br i1 %t142, label %bb29, label %bb30
bb29:
  %t144 = load i32, ptr %l5, !tbaa !23
  %t145 = mul i64 1, 4
  %t146 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 1, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l70, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 0
  store i32 %t144, ptr %t152, !tbaa !33
  %t153 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t153, ptr %l68, !tbaa !27
  br label %bb31
bb30:
  %t154 = load ptr, ptr %lp6
  %t156 = insertvalue { i64, ptr } undef, i64 0, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  store { i64, ptr } %t157, ptr %l68, !tbaa !27
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t159 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t159, ptr %rv
  br label %ret
bb32:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t164 = load i32, ptr %l3, !tbaa !23
  %t165 = load i32, ptr %l4, !tbaa !23
  %t169 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t163, i32 %t164, i32 %t165)
  store i32 %t169, ptr %l77
  br label %bb33
bb33:
  %t170 = load i32, ptr %l4, !tbaa !23
  %t171 = load i32, ptr %l77, !tbaa !23
  %t173 = icmp eq i32 %t171, %t170
  br i1 %t173, label %bb34, label %bb35
bb34:
  %t175 = load ptr, ptr %lp6
  %t177 = insertvalue { i64, ptr } undef, i64 0, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t178, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t180 = load i32, ptr %l5, !tbaa !23
  %t181 = mul i64 1, 4
  %t182 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t181)
  %t183 = insertvalue { i64, ptr } undef, i64 1, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l83, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr i32, ptr %t187, i64 0
  store i32 %t180, ptr %t188, !tbaa !33
  call void @__olang_scope_close(ptr %s0)
  %t189 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t189, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountsTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l31 = alloca { i64, ptr }
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 24
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp eq i64 %t18, 1
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 0
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameLen(ptr %v0, ptr %v1, ptr %v2, ptr %t22, ptr %t27, ptr %t28)
  store i1 %t32, ptr %l19
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t33 = load i1, ptr %l19, !tbaa !21
  store i1 %t33, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l14, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb20
bb11:
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t39 = icmp eq i64 %t37, 2
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l26, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr ptr, ptr %t44, i64 0
  %t46 = load ptr, ptr %t45, !tbaa !39
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisZeroLit(ptr %v0, ptr %v1, ptr %t41, ptr %t46)
  store i1 %t49, ptr %l28
  br label %bb14
bb13:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb15
bb14:
  %t50 = load i1, ptr %l28, !tbaa !21
  store i1 %t50, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t51 = load i1, ptr %l24, !tbaa !21
  br i1 %t51, label %bb16, label %bb17
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t53, ptr %l31, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 1
  %t57 = load ptr, ptr %t56, !tbaa !39
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameLen(ptr %v0, ptr %v1, ptr %v2, ptr %t52, ptr %t57, ptr %t58)
  store i1 %t62, ptr %l34
  br label %bb18
bb17:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb19
bb18:
  %t63 = load i1, ptr %l34, !tbaa !21
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb19
bb19:
  %t64 = load i1, ptr %l29, !tbaa !21
  store i1 %t64, ptr %l20, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l20, !tbaa !21
  store i1 %t65, ptr %l4, !tbaa !21
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_d2b428b6a63c5a88_9cb41cac42ab9d54)
  unreachable
bb26:
  %t66 = load i1, ptr %l4, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca ptr
  %l23 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l57 = alloca i64
  %l61 = alloca { i64, ptr }
  %l64 = alloca %"compiler/check:ctSource"
  %l73 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca i1
  %l89 = alloca i64
  %l93 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l98 = alloca i1
  %l106 = alloca i1
  %l130 = alloca %"compiler/check:ctSource"
  %l132 = alloca ptr
  %l133 = alloca i1
  %l140 = alloca i1
  %l158 = alloca %"compiler/check:ctSource"
  %l165 = alloca ptr
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l176 = alloca i1
  %l184 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l192 = alloca i32
  %l198 = alloca %"compiler/source:Span"
  %l202 = alloca ptr
  %l206 = alloca %"compiler/ast:Param"
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l223 = alloca i64
  %l226 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l233 = alloca %"compiler/check:ctSource"
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  %t429 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l23
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l23, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb16
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l32
  br label %bb5
bb5:
  %t30 = load i64, ptr %l32, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l36
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l36, !tbaa !29
  store ptr %t39, ptr %l5, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Func", ptr %t40, i32 0, i32 3
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Sig", ptr %t43, i32 0, i32 5
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Func", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Sig", ptr %t54, i32 0, i32 5
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_700945490095e3ab_b793fb317cfa4b47)
  unreachable
bb11:
  br label %bb12
bb12:
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Func", ptr %t61, i32 0, i32 3
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Sig", ptr %t64, i32 0, i32 5
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l48, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l50, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 3
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Sig", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l53, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l57
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t90 = getelementptr %"compiler/ast:Func", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %t90, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s1, ptr %t87, i32 %t91)
  store { i64, ptr } %t94, ptr %l61
  br label %bb14
bb14:
  %t95 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t96, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t111 = load i64, ptr %l57, !tbaa !24
  %t113 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t108, ptr %t109, { i64, ptr } %t110, i64 %t111, { i64, ptr } %t107)
  store %"compiler/check:ctSource" %t113, ptr %l64
  br label %bb15
bb15:
  %t114 = load %"compiler/check:ctSource", ptr %l64
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/check:ctSource" %t114, ptr %t115
  call void @__olang_scope_close(ptr %s1)
  store ptr %t115, ptr %rv
  br label %ret
bb16:
  %t117 = load { i64, [2 x i64] }, ptr %l2
  %t119 = extractvalue { i64, [2 x i64] } %t117, 0
  %t120 = icmp eq i64 %t119, 1
  br i1 %t120, label %bb17, label %bb18
bb17:
  %t122 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t123 = getelementptr { i32, i32 }, ptr %t122, i32 0, i32 0
  %t124 = load i32, ptr %t123
  store i32 %t124, ptr %l6, !tbaa !23
  br label %bb19
bb18:
  br label %bb72
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l6, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l73
  br label %bb20
bb20:
  %t136 = load i32, ptr %l73, !tbaa !23
  store i32 %t136, ptr %l7, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t141 = load i32, ptr %l7, !tbaa !23
  %t144 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t140, i32 %t141)
  store ptr %t144, ptr %l77
  br label %bb21
bb21:
  %t145 = load ptr, ptr %l77, !tbaa !29
  store ptr %t145, ptr %l8, !tbaa !29
  %t146 = load ptr, ptr %l8, !tbaa !29
  %t148 = icmp eq ptr %t146, null
  br i1 %t148, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb24
bb23:
  %t150 = load ptr, ptr %l8, !tbaa !29
  %t152 = getelementptr %"compiler/ast:TypeDecl", ptr %t150, i32 0, i32 3
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = icmp eq ptr %t153, null
  store i1 %t155, ptr %l80, !tbaa !21
  br label %bb24
bb24:
  %t157 = load i1, ptr %l80, !tbaa !21
  br i1 %t157, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  store ptr null, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/generic:Program", ptr %t162, i32 0, i32 2
  %t165 = load i32, ptr %l7, !tbaa !23
  %t168 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t164, i32 %t165)
  store i64 %t168, ptr %l89
  br label %bb28
bb28:
  %t169 = load i64, ptr %l89, !tbaa !24
  store i64 %t169, ptr %l9, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l8, !tbaa !29
  %t173 = getelementptr %"compiler/ast:TypeDecl", ptr %t171, i32 0, i32 0
  %t174 = load i32, ptr %t173, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s4, ptr %t170, i32 %t174)
  store { i64, ptr } %t177, ptr %l93
  br label %bb29
bb29:
  %t178 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t179, i64 %t180)
  %t182 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t184, ptr %lp10
  %t186 = load ptr, ptr %lp10
  store { i64, ptr } %t183, ptr %t186, !tbaa !27
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t189 = getelementptr %"compiler/ast:TypeDecl", ptr %t187, i32 0, i32 3
  %t190 = load ptr, ptr %t189, !tbaa !29
  store ptr %t190, ptr %l11, !tbaa !29
  %t192 = load ptr, ptr %l11, !tbaa !29
  store ptr %t192, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t193 = load ptr, ptr %l97, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb30, label %bb31
bb30:
  %t196 = load ptr, ptr %l97, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 5}
  %t199 = icmp eq i64 %t197, 0
  store i1 %t199, ptr %l98, !tbaa !21
  br label %bb31
bb31:
  %t200 = load i1, ptr %l98, !tbaa !21
  br i1 %t200, label %bb32, label %bb33
bb32:
  %t201 = load ptr, ptr %l11, !tbaa !29
  %t203 = getelementptr { i64, [6 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { ptr }, ptr %t203, i32 0, i32 0
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l12, !tbaa !29
  br label %bb34
bb33:
  br label %bb51
bb34:
  %t207 = load ptr, ptr %l12, !tbaa !29
  %t209 = getelementptr %"compiler/ast:StructBody", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = icmp eq ptr %t210, null
  br i1 %t212, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb40
bb36:
  %t214 = load ptr, ptr %l12, !tbaa !29
  %t216 = getelementptr %"compiler/ast:StructBody", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = icmp eq ptr %t217, null
  br i1 %t219, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28)
  unreachable
bb38:
  br label %bb39
bb39:
  %t221 = load ptr, ptr %l12, !tbaa !29
  %t223 = getelementptr %"compiler/ast:StructBody", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t227 = getelementptr %"compiler/ast:Sig", ptr %t224, i32 0, i32 5
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = icmp eq ptr %t228, null
  store i1 %t230, ptr %l106, !tbaa !21
  br label %bb40
bb40:
  %t232 = load i1, ptr %l106, !tbaa !21
  br i1 %t232, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  store ptr null, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t234 = load ptr, ptr %l12, !tbaa !29
  %t236 = getelementptr %"compiler/ast:StructBody", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = icmp eq ptr %t237, null
  br i1 %t239, label %bb44, label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_25ec48d7738ec131_33504a893c084afd)
  unreachable
bb45:
  br label %bb46
bb46:
  %t241 = load ptr, ptr %l12, !tbaa !29
  %t243 = getelementptr %"compiler/ast:StructBody", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t247 = getelementptr %"compiler/ast:Sig", ptr %t244, i32 0, i32 5
  %t248 = load ptr, ptr %t247, !tbaa !29
  store ptr %t248, ptr %l13, !tbaa !29
  %t250 = load ptr, ptr %l13, !tbaa !29
  %t252 = icmp eq ptr %t250, null
  br i1 %t252, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_25ec48d7738ec131_33504a893c084afd)
  unreachable
bb48:
  br label %bb49
bb49:
  %t254 = load ptr, ptr %l13, !tbaa !29
  %t255 = load ptr, ptr %l12, !tbaa !29
  %t257 = getelementptr %"compiler/ast:StructBody", ptr %t255, i32 0, i32 0
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  %t259 = load i64, ptr %l9, !tbaa !24
  %t260 = load ptr, ptr %lp10
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  %t266 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t254, ptr null, { i64, ptr } %t258, i64 %t259, { i64, ptr } %t261)
  store %"compiler/check:ctSource" %t266, ptr %l130
  br label %bb50
bb50:
  %t267 = load %"compiler/check:ctSource", ptr %l130
  %t268 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/check:ctSource" %t267, ptr %t268
  call void @__olang_scope_close(ptr %s4)
  store ptr %t268, ptr %rv
  br label %ret
bb51:
  %t270 = load ptr, ptr %l11, !tbaa !29
  store ptr %t270, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t271 = load ptr, ptr %l132, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb52, label %bb53
bb52:
  %t274 = load ptr, ptr %l132, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 5}
  %t277 = icmp eq i64 %t275, 3
  store i1 %t277, ptr %l133, !tbaa !21
  br label %bb53
bb53:
  %t278 = load i1, ptr %l133, !tbaa !21
  br i1 %t278, label %bb54, label %bb55
bb54:
  %t279 = load ptr, ptr %l11, !tbaa !29
  %t281 = getelementptr { i64, [6 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { ptr, ptr }, ptr %t281, i32 0, i32 1
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l14, !tbaa !29
  br label %bb56
bb55:
  br label %bb67
bb56:
  %t285 = load ptr, ptr %l14, !tbaa !29
  %t287 = icmp eq ptr %t285, null
  br i1 %t287, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb59
bb58:
  %t289 = load ptr, ptr %l14, !tbaa !29
  %t291 = getelementptr %"compiler/ast:Func", ptr %t289, i32 0, i32 3
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = getelementptr %"compiler/ast:Sig", ptr %t292, i32 0, i32 5
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = icmp eq ptr %t295, null
  store i1 %t297, ptr %l140, !tbaa !21
  br label %bb59
bb59:
  %t299 = load i1, ptr %l140, !tbaa !21
  br i1 %t299, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s4)
  store ptr null, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t301 = load ptr, ptr %l14, !tbaa !29
  %t303 = getelementptr %"compiler/ast:Func", ptr %t301, i32 0, i32 3
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t306 = getelementptr %"compiler/ast:Sig", ptr %t304, i32 0, i32 5
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t309 = icmp eq ptr %t307, null
  br i1 %t309, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_1c86c4e2a1d4d52a_afb2831c22759b16)
  unreachable
bb64:
  br label %bb65
bb65:
  %t311 = load ptr, ptr %l14, !tbaa !29
  %t313 = getelementptr %"compiler/ast:Func", ptr %t311, i32 0, i32 3
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/ast:Sig", ptr %t314, i32 0, i32 5
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t318 = load ptr, ptr %l14, !tbaa !29
  %t320 = getelementptr %"compiler/ast:Func", ptr %t318, i32 0, i32 3
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = getelementptr %"compiler/ast:Sig", ptr %t321, i32 0, i32 0
  %t324 = load { i64, ptr }, ptr %t323, !tbaa !27
  %t325 = load i64, ptr %l9, !tbaa !24
  %t326 = load ptr, ptr %lp10
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  %t332 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t317, ptr null, { i64, ptr } %t324, i64 %t325, { i64, ptr } %t327)
  store %"compiler/check:ctSource" %t332, ptr %l158
  br label %bb66
bb66:
  %t333 = load %"compiler/check:ctSource", ptr %l158
  %t334 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/check:ctSource" %t333, ptr %t334
  call void @__olang_scope_close(ptr %s4)
  store ptr %t334, ptr %rv
  br label %ret
bb67:
  br i1 true, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_scope_close(ptr %s4)
  store ptr null, ptr %rv
  br label %ret
bb71:
  call void @__olang_check_failed(ptr @olang_loc_34572fc3675c142e_5b9246c98f1fa642)
  unreachable
bb72:
  %t337 = load { i64, [2 x i64] }, ptr %l2
  %t339 = extractvalue { i64, [2 x i64] } %t337, 0
  %t340 = icmp eq i64 %t339, 10
  br i1 %t340, label %bb73, label %bb74
bb73:
  %t342 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t343 = getelementptr { i32, i64 }, ptr %t342, i32 0, i32 0
  %t344 = load i32, ptr %t343
  store i32 %t344, ptr %l15, !tbaa !23
  %t346 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t347 = getelementptr { i32, i64 }, ptr %t346, i32 0, i32 1
  %t348 = load i64, ptr %t347
  store i64 %t348, ptr %l16, !tbaa !24
  br label %bb75
bb74:
  br label %bb101
bb75:
  store %olang.scope zeroinitializer, ptr %s12
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l165, !tbaa !29
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t355 = load i32, ptr %l15, !tbaa !23
  %t358 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t354, i32 %t355)
  store { i64, ptr } %t358, ptr %l169
  br label %bb76
bb76:
  %t359 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t359, ptr %l170, !tbaa !27
  %t360 = load i64, ptr %l16, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr %"compiler/generic:AnySlot", ptr %t363, i64 %t360
  %t365 = load %"compiler/generic:AnySlot", ptr %t364
  %t366 = load ptr, ptr %l165, !tbaa !29
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v1, ptr %t366, %"compiler/generic:AnySlot" %t365)
  store ptr %t368, ptr %l173
  br label %bb77
bb77:
  %t369 = load ptr, ptr %l173, !tbaa !29
  store ptr %t369, ptr %l17, !tbaa !29
  %t370 = load ptr, ptr %l17, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  br i1 %t372, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l176, !tbaa !21
  br label %bb80
bb79:
  %t374 = load ptr, ptr %l17, !tbaa !29
  %t376 = getelementptr %"compiler/ast:Func", ptr %t374, i32 0, i32 3
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = getelementptr %"compiler/ast:Sig", ptr %t377, i32 0, i32 5
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = icmp eq ptr %t380, null
  store i1 %t382, ptr %l176, !tbaa !21
  br label %bb80
bb80:
  %t384 = load i1, ptr %l176, !tbaa !21
  br i1 %t384, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s12)
  store ptr null, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/check:Checker", ptr %t386, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !29
  %t391 = getelementptr %"compiler/generic:Program", ptr %t389, i32 0, i32 2
  store ptr %t391, ptr %l184, !tbaa !29
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/check:Checker", ptr %t392, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !29
  %t396 = load i32, ptr %l15, !tbaa !23
  %t399 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t395, i32 %t396)
  store { i64, ptr } %t399, ptr %l188
  br label %bb84
bb84:
  %t400 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t400, ptr %l189, !tbaa !27
  %t401 = load i64, ptr %l16, !tbaa !24
  %t403 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr %"compiler/generic:AnySlot", ptr %t404, i64 %t401
  %t406 = getelementptr %"compiler/generic:AnySlot", ptr %t405, i32 0, i32 1
  %t407 = load i32, ptr %t406, !tbaa !23
  %t408 = load ptr, ptr %l184, !tbaa !29
  %t410 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t408, i32 %t407)
  store i32 %t410, ptr %l192
  br label %bb85
bb85:
  %t411 = load i32, ptr %l192, !tbaa !23
  store i32 %t411, ptr %l18, !tbaa !23
  %t412 = load ptr, ptr %l17, !tbaa !29
  %t414 = getelementptr %"compiler/ast:Func", ptr %t412, i32 0, i32 1
  %t415 = load ptr, ptr %t414, !tbaa !29
  store ptr %t415, ptr %l19, !tbaa !29
  %t417 = load ptr, ptr %l19, !tbaa !29
  %t419 = icmp eq ptr %t417, null
  br i1 %t419, label %bb86, label %bb87
bb86:
  %t421 = load ptr, ptr %l17, !tbaa !29
  %t423 = getelementptr %"compiler/ast:Func", ptr %t421, i32 0, i32 0
  %t424 = load %"compiler/source:Span", ptr %t423
  store %"compiler/source:Span" %t424, ptr %l198
  %t425 = load ptr, ptr %l17, !tbaa !29
  %t427 = getelementptr %"compiler/ast:Func", ptr %t425, i32 0, i32 0
  %t428 = load %"compiler/source:Span", ptr %t427
  store { i64, [5 x i64] } zeroinitializer, ptr %t429
  %t430 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 0
  store i64 4, ptr %t430
  %t432 = insertvalue { %"compiler/source:Span", ptr, i1 } undef, %"compiler/source:Span" %t428, 0
  %t433 = insertvalue { %"compiler/source:Span", ptr, i1 } %t432, ptr null, 1
  %t434 = insertvalue { %"compiler/source:Span", ptr, i1 } %t433, i1 false, 2
  %t435 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1 } %t434, ptr %t435
  %t436 = load { i64, [5 x i64] }, ptr %t429
  %t438 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t436, ptr %t438
  store ptr %t438, ptr %l202, !tbaa !29
  %t439 = icmp sge i64 0, 0
  br i1 %t439, label %bb88, label %bb89
bb87:
  br label %bb93
bb88:
  %t441 = icmp sle i64 0, 1152921504606846975
  br i1 %t441, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_384cb541f04295b0_3f9ee0143bd9d7ac)
  unreachable
bb90:
  %t443 = mul i64 0, 8
  %t444 = insertvalue { i64, ptr } undef, i64 0, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t446 = load %"compiler/source:Span", ptr %l198
  %t447 = load ptr, ptr %l202, !tbaa !29
  %t449 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t446, i32 0, ptr %t447, ptr null, { i64, ptr } %t445)
  store %"compiler/ast:Param" %t449, ptr %l206
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_384cb541f04295b0_3f9ee0143bd9d7ac)
  unreachable
bb92:
  %t450 = load %"compiler/ast:Param", ptr %l206
  %t451 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store %"compiler/ast:Param" %t450, ptr %t451
  store ptr %t451, ptr %l19, !tbaa !29
  br label %bb93
bb93:
  %t453 = load ptr, ptr %l17, !tbaa !29
  %t455 = getelementptr %"compiler/ast:Func", ptr %t453, i32 0, i32 3
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t458 = getelementptr %"compiler/ast:Sig", ptr %t456, i32 0, i32 5
  %t459 = load ptr, ptr %t458, !tbaa !29
  %t461 = icmp eq ptr %t459, null
  br i1 %t461, label %bb94, label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_a90b29f72ec4d10d_507af4b2e3250de1)
  unreachable
bb95:
  br label %bb96
bb96:
  %t463 = load ptr, ptr %l17, !tbaa !29
  %t465 = getelementptr %"compiler/ast:Func", ptr %t463, i32 0, i32 3
  %t466 = load ptr, ptr %t465, !tbaa !29
  %t468 = getelementptr %"compiler/ast:Sig", ptr %t466, i32 0, i32 5
  %t469 = load ptr, ptr %t468, !tbaa !29
  store ptr %t469, ptr %l214, !tbaa !29
  %t470 = load ptr, ptr %l19, !tbaa !29
  store ptr %t470, ptr %l215, !tbaa !29
  %t471 = load ptr, ptr %l17, !tbaa !29
  %t473 = getelementptr %"compiler/ast:Func", ptr %t471, i32 0, i32 3
  %t474 = load ptr, ptr %t473, !tbaa !29
  %t476 = getelementptr %"compiler/ast:Sig", ptr %t474, i32 0, i32 0
  %t477 = load { i64, ptr }, ptr %t476, !tbaa !27
  store { i64, ptr } %t477, ptr %l218, !tbaa !27
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/check:Checker", ptr %t478, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !29
  %t483 = getelementptr %"compiler/generic:Program", ptr %t481, i32 0, i32 2
  %t484 = load i32, ptr %l18, !tbaa !23
  %t487 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t483, i32 %t484)
  store i64 %t487, ptr %l223
  br label %bb97
bb97:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load i32, ptr %l15, !tbaa !23
  %t492 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t488, i32 %t489)
  store { i64, ptr } %t492, ptr %l226
  br label %bb98
bb98:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load ptr, ptr %l17, !tbaa !29
  %t496 = getelementptr %"compiler/ast:Func", ptr %t494, i32 0, i32 2
  %t497 = load i32, ptr %t496, !tbaa !23
  %t500 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s12, ptr %t493, i32 %t497)
  store { i64, ptr } %t500, ptr %l230
  br label %bb99
bb99:
  %t501 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 1
  %t503 = extractvalue { i64, ptr } %t501, 0
  %t504 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t505 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t506 = add i64 %t503, %t505
  %t507 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t508 = extractvalue { i64, ptr } %t507, 1
  %t509 = extractvalue { i64, ptr } %t507, 0
  %t510 = add i64 %t506, %t509
  %t511 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t510)
  call void @olang_textcopy(ptr %t511, ptr %t502, i64 %t503)
  %t512 = getelementptr i8, ptr %t511, i64 %t503
  call void @olang_textcopy(ptr %t512, ptr %t504, i64 %t505)
  %t513 = getelementptr i8, ptr %t512, i64 %t505
  call void @olang_textcopy(ptr %t513, ptr %t508, i64 %t509)
  %t514 = insertvalue { i64, ptr } undef, i64 %t510, 0
  %t515 = insertvalue { i64, ptr } %t514, ptr %t511, 1
  %t517 = extractvalue { i64, ptr } %t515, 0
  %t518 = extractvalue { i64, ptr } %t515, 1
  %t519 = mul i64 %t517, 1
  %t520 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t519)
  call void @llvm.memcpy.p0.p0.i64(ptr %t520, ptr %t518, i64 %t519, i1 false)
  %t521 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t520, 1
  %t523 = load ptr, ptr %l214, !tbaa !29
  %t524 = load ptr, ptr %l215, !tbaa !29
  %t525 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t526 = load i64, ptr %l223, !tbaa !24
  %t528 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t523, ptr %t524, { i64, ptr } %t525, i64 %t526, { i64, ptr } %t522)
  store %"compiler/check:ctSource" %t528, ptr %l233
  br label %bb100
bb100:
  %t529 = load %"compiler/check:ctSource", ptr %l233
  %t530 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/check:ctSource" %t529, ptr %t530
  call void @__olang_scope_close(ptr %s12)
  store ptr %t530, ptr %rv
  br label %ret
bb101:
  br i1 true, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  store ptr null, ptr %rv
  br label %ret
bb105:
  call void @__olang_check_failed(ptr @olang_loc_8dac41fcc89db5e5_6cee581458fc6b9)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l103 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l126 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l135 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i1
  %l159 = alloca { i64, ptr }
  %l165 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l180 = alloca i1
  %l184 = alloca i1
  %l188 = alloca i1
  %l198 = alloca { i64, ptr }
  %l204 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i1
  %l221 = alloca i1
  %l223 = alloca i1
  %l232 = alloca { i64, ptr }
  %l238 = alloca i1
  %l243 = alloca ptr
  %l244 = alloca i1
  %l252 = alloca i1
  %l256 = alloca i1
  %l257 = alloca i1
  %l262 = alloca i1
  %l263 = alloca i1
  %l268 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca i1
  %l279 = alloca i1
  %l280 = alloca i1
  %l284 = alloca i1
  %l285 = alloca i1
  %l290 = alloca i1
  %l291 = alloca ptr
  %l292 = alloca i1
  %l300 = alloca i1
  %l301 = alloca i1
  %l305 = alloca i1
  %l306 = alloca ptr
  %l307 = alloca i1
  %l315 = alloca i1
  %l325 = alloca { i64, ptr }
  %l330 = alloca i1
  %l338 = alloca i1
  %l339 = alloca ptr
  %l345 = alloca i1
  %l346 = alloca ptr
  %l347 = alloca i1
  %l354 = alloca i1
  %l358 = alloca i1
  %l368 = alloca { i64, ptr }
  %l374 = alloca i1
  %l384 = alloca { i64, ptr }
  %l390 = alloca i1
  %l397 = alloca ptr
  %l398 = alloca i1
  %l406 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t7 = load ptr, ptr %l46, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l46, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l47, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l47, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t16 = load ptr, ptr %l50, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l50, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l51, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l51, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t25 = load ptr, ptr %l54, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l54, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 15
  store i1 %t31, ptr %l55, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l55, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t35 = load ptr, ptr %l59, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb18, label %bb19
bb18:
  %t38 = load ptr, ptr %l59, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l60, !tbaa !21
  br label %bb19
bb19:
  %t42 = load i1, ptr %l60, !tbaa !21
  br i1 %t42, label %bb20, label %bb21
bb20:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l2, !tbaa !29
  br label %bb30
bb21:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t50 = load ptr, ptr %l65, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb22, label %bb23
bb22:
  %t53 = load ptr, ptr %l65, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 18}
  %t56 = icmp eq i64 %t54, 3
  store i1 %t56, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t57 = load i1, ptr %l66, !tbaa !21
  br i1 %t57, label %bb24, label %bb25
bb24:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l2, !tbaa !29
  br label %bb30
bb25:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t65 = load ptr, ptr %l71, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb26, label %bb27
bb26:
  %t68 = load ptr, ptr %l71, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 4
  store i1 %t71, ptr %l72, !tbaa !21
  br label %bb27
bb27:
  %t72 = load i1, ptr %l72, !tbaa !21
  br i1 %t72, label %bb28, label %bb29
bb28:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l2, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t79, ptr %t80, i1 false)
  store i1 %t83, ptr %l79
  br label %bb31
bb31:
  %t84 = load i1, ptr %l79, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb32:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t86 = load ptr, ptr %l80, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t89 = load ptr, ptr %l80, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 5
  store i1 %t92, ptr %l81, !tbaa !21
  br label %bb34
bb34:
  %t93 = load i1, ptr %l81, !tbaa !21
  br i1 %t93, label %bb35, label %bb36
bb35:
  br label %bb45
bb36:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t95 = load ptr, ptr %l84, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb37, label %bb38
bb37:
  %t98 = load ptr, ptr %l84, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 18}
  %t101 = icmp eq i64 %t99, 16
  store i1 %t101, ptr %l85, !tbaa !21
  br label %bb38
bb38:
  %t102 = load i1, ptr %l85, !tbaa !21
  br i1 %t102, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t104 = load ptr, ptr %l88, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb41, label %bb42
bb41:
  %t107 = load ptr, ptr %l88, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 18}
  %t110 = icmp eq i64 %t108, 8
  store i1 %t110, ptr %l89, !tbaa !21
  br label %bb42
bb42:
  %t111 = load i1, ptr %l89, !tbaa !21
  br i1 %t111, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i1 true, ptr %rv
  br label %ret
bb46:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t114 = load ptr, ptr %l93, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb47, label %bb48
bb47:
  %t117 = load ptr, ptr %l93, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 18}
  %t120 = icmp eq i64 %t118, 6
  store i1 %t120, ptr %l94, !tbaa !21
  br label %bb48
bb48:
  %t121 = load i1, ptr %l94, !tbaa !21
  br i1 %t121, label %bb49, label %bb50
bb49:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 1
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l3, !tbaa !23
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t130, i32 0, i32 2
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l4, !tbaa !29
  br label %bb51
bb50:
  br label %bb102
bb51:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l3, !tbaa !23
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l103
  br label %bb52
bb52:
  %t139 = load i1, ptr %l103, !tbaa !21
  br i1 %t139, label %bb53, label %bb54
bb53:
  store i1 true, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t141 = load ptr, ptr %l4, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Call", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  store ptr %t144, ptr %l5, !tbaa !29
  %t146 = load ptr, ptr %l5, !tbaa !29
  store ptr %t146, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t147 = load ptr, ptr %l107, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb56, label %bb57
bb56:
  %t150 = load ptr, ptr %l107, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 5}
  %t153 = icmp eq i64 %t151, 0
  store i1 %t153, ptr %l108, !tbaa !21
  br label %bb57
bb57:
  %t154 = load i1, ptr %l108, !tbaa !21
  br i1 %t154, label %bb58, label %bb59
bb58:
  %t155 = load ptr, ptr %l5, !tbaa !29
  %t157 = getelementptr { i64, [3 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { i32 }, ptr %t157, i32 0, i32 0
  %t159 = load i32, ptr %t158
  store i32 %t159, ptr %l6, !tbaa !23
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 104
  %t164 = load i32, ptr %l6, !tbaa !23
  %t166 = sext i32 %t164 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t163, i64 %t166)
  br label %bb61
bb61:
  br label %bb91
bb62:
  %t169 = load ptr, ptr %l5, !tbaa !29
  store ptr %t169, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t170 = load ptr, ptr %l117, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb63, label %bb64
bb63:
  %t173 = load ptr, ptr %l117, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 5}
  %t176 = icmp eq i64 %t174, 1
  store i1 %t176, ptr %l118, !tbaa !21
  br label %bb64
bb64:
  %t177 = load i1, ptr %l118, !tbaa !21
  br i1 %t177, label %bb65, label %bb66
bb65:
  %t178 = load ptr, ptr %l5, !tbaa !29
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { i64 }, ptr %t180, i32 0, i32 0
  %t182 = load i64, ptr %t181
  store i64 %t182, ptr %l7, !tbaa !24
  br label %bb67
bb66:
  br label %bb74
bb67:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t188 = load i64, ptr %l7, !tbaa !24
  %t191 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t187, i64 %t188)
  store ptr %t191, ptr %l126
  br label %bb68
bb68:
  %t192 = load ptr, ptr %l126, !tbaa !29
  store ptr %t192, ptr %l8, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr %"compiler/ast:Func", ptr %t194, i32 0, i32 2
  %t197 = load i32, ptr %t196, !tbaa !23
  %t200 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t193, i32 %t197)
  store { i64, ptr } %t200, ptr %l130
  br label %bb69
bb69:
  %t201 = load ptr, ptr %l8, !tbaa !29
  %t203 = getelementptr %"compiler/ast:Func", ptr %t201, i32 0, i32 3
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Sig", ptr %t204, i32 0, i32 0
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t212 = call i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %t210, i64 %t209)
  store i1 %t212, ptr %l135
  br label %bb70
bb70:
  %t213 = load i1, ptr %l135, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb71, label %bb72
bb71:
  store i1 true, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  br label %bb91
bb74:
  %t217 = load ptr, ptr %l5, !tbaa !29
  store ptr %t217, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t218 = load ptr, ptr %l138, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb75, label %bb76
bb75:
  %t221 = load ptr, ptr %l138, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 5}
  %t224 = icmp eq i64 %t222, 2
  store i1 %t224, ptr %l139, !tbaa !21
  br label %bb76
bb76:
  %t225 = load i1, ptr %l139, !tbaa !21
  br i1 %t225, label %bb77, label %bb78
bb77:
  br label %bb83
bb78:
  %t226 = load ptr, ptr %l5, !tbaa !29
  store ptr %t226, ptr %l142, !tbaa !29
  store i1 false, ptr %l143, !tbaa !21
  %t227 = load ptr, ptr %l142, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb79, label %bb80
bb79:
  %t230 = load ptr, ptr %l142, !tbaa !29
  %t231 = load i64, ptr %t230, !range !{i64 0, i64 5}
  %t233 = icmp eq i64 %t231, 3
  store i1 %t233, ptr %l143, !tbaa !21
  br label %bb80
bb80:
  %t234 = load i1, ptr %l143, !tbaa !21
  br i1 %t234, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store i1 true, ptr %rv
  br label %ret
bb84:
  %t236 = load ptr, ptr %l5, !tbaa !29
  store ptr %t236, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t237 = load ptr, ptr %l147, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb85, label %bb86
bb85:
  %t240 = load ptr, ptr %l147, !tbaa !29
  %t241 = load i64, ptr %t240, !range !{i64 0, i64 5}
  %t243 = icmp eq i64 %t241, 4
  store i1 %t243, ptr %l148, !tbaa !21
  br label %bb86
bb86:
  %t244 = load i1, ptr %l148, !tbaa !21
  br i1 %t244, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_d97e23b04dcff800_367dc3876d150fb4)
  unreachable
bb91:
  %t245 = load ptr, ptr %l4, !tbaa !29
  %t247 = getelementptr %"compiler/typed:Call", ptr %t245, i32 0, i32 1
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  store i64 %t252, ptr %l11, !tbaa !24
  br label %bb92
bb92:
  %t254 = load i64, ptr %l10, !tbaa !24
  %t255 = load i64, ptr %l11, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb93, label %bb94
bb93:
  br label %bb101
bb94:
  br label %bb95
bb95:
  %t262 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t262, ptr %l159, !tbaa !27
  %t263 = load i64, ptr %l10, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr ptr, ptr %t266, i64 %t263
  %t268 = load ptr, ptr %t267, !tbaa !39
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t275 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t270, ptr %t268)
  store i1 %t275, ptr %l165
  br label %bb96
bb96:
  %t276 = load i1, ptr %l165, !tbaa !21
  br i1 %t276, label %bb97, label %bb98
bb97:
  store i1 true, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t278 = load i64, ptr %l10, !tbaa !24
  %t280 = add i64 %t278, 1
  store i64 %t280, ptr %l10, !tbaa !24
  br label %bb92
bb101:
  store i1 false, ptr %rv
  br label %ret
bb102:
  %t283 = load ptr, ptr %l1, !tbaa !29
  store ptr %t283, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t284 = load ptr, ptr %l170, !tbaa !29
  %t285 = icmp ne ptr %t284, null
  br i1 %t285, label %bb103, label %bb104
bb103:
  %t287 = load ptr, ptr %l170, !tbaa !29
  %t288 = load i64, ptr %t287, !range !{i64 0, i64 18}
  %t290 = icmp eq i64 %t288, 7
  store i1 %t290, ptr %l171, !tbaa !21
  br label %bb104
bb104:
  %t291 = load i1, ptr %l171, !tbaa !21
  br i1 %t291, label %bb105, label %bb106
bb105:
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr { i64, [5 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t294, i32 0, i32 2
  %t296 = load ptr, ptr %t295
  store ptr %t296, ptr %l13, !tbaa !29
  br label %bb107
bb106:
  br label %bb128
bb107:
  %t298 = load ptr, ptr %l13, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Make", ptr %t298, i32 0, i32 4
  %t301 = load i32, ptr %t300, !tbaa !23
  %t303 = sext i32 %t301 to i64
  %t305 = icmp sge i64 %t303, 0
  br i1 %t305, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l180, !tbaa !21
  br label %bb110
bb109:
  %t307 = load ptr, ptr %l13, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Make", ptr %t307, i32 0, i32 5
  %t310 = load i32, ptr %t309, !range !{i32 0, i32 3}
  %t312 = trunc i64 1 to i32
  %t313 = icmp eq i32 %t310, %t312
  store i1 %t313, ptr %l180, !tbaa !21
  br label %bb110
bb110:
  %t315 = load i1, ptr %l180, !tbaa !21
  br i1 %t315, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l184, !tbaa !21
  br label %bb114
bb112:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l13, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Make", ptr %t317, i32 0, i32 3
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t323 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t316, ptr %t320)
  store i1 %t323, ptr %l188
  br label %bb113
bb113:
  %t324 = load i1, ptr %l188, !tbaa !21
  store i1 %t324, ptr %l184, !tbaa !21
  br label %bb114
bb114:
  %t325 = load i1, ptr %l184, !tbaa !21
  br i1 %t325, label %bb115, label %bb116
bb115:
  store i1 true, ptr %rv
  br label %ret
bb116:
  br label %bb117
bb117:
  %t327 = load ptr, ptr %l13, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Make", ptr %t327, i32 0, i32 2
  %t330 = load { i64, ptr }, ptr %t329, !tbaa !27
  store { i64, ptr } %t330, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t332 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t332, 0
  store i64 %t334, ptr %l16, !tbaa !24
  br label %bb118
bb118:
  %t336 = load i64, ptr %l15, !tbaa !24
  %t337 = load i64, ptr %l16, !tbaa !24
  %t340 = icmp slt i64 %t336, %t337
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb119, label %bb120
bb119:
  br label %bb127
bb120:
  br label %bb121
bb121:
  %t344 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t344, ptr %l198, !tbaa !27
  %t345 = load i64, ptr %l15, !tbaa !24
  %t347 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr ptr, ptr %t348, i64 %t345
  %t350 = load ptr, ptr %t349, !tbaa !39
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t357 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t352, ptr %t350)
  store i1 %t357, ptr %l204
  br label %bb122
bb122:
  %t358 = load i1, ptr %l204, !tbaa !21
  br i1 %t358, label %bb123, label %bb124
bb123:
  store i1 true, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  %t360 = load i64, ptr %l15, !tbaa !24
  %t362 = add i64 %t360, 1
  store i64 %t362, ptr %l15, !tbaa !24
  br label %bb118
bb127:
  store i1 false, ptr %rv
  br label %ret
bb128:
  %t365 = load ptr, ptr %l1, !tbaa !29
  store ptr %t365, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t366 = load ptr, ptr %l209, !tbaa !29
  %t367 = icmp ne ptr %t366, null
  br i1 %t367, label %bb129, label %bb130
bb129:
  %t369 = load ptr, ptr %l209, !tbaa !29
  %t370 = load i64, ptr %t369, !range !{i64 0, i64 18}
  %t372 = icmp eq i64 %t370, 9
  store i1 %t372, ptr %l210, !tbaa !21
  br label %bb130
bb130:
  %t373 = load i1, ptr %l210, !tbaa !21
  br i1 %t373, label %bb131, label %bb132
bb131:
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t376 = getelementptr { i64, [5 x i64] }, ptr %t374, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t376, i32 0, i32 2
  %t378 = load i32, ptr %t377, !range !{i32 0, i32 44}
  store i32 %t378, ptr %l18
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t382, i32 0, i32 3
  %t384 = load i32, ptr %t383, !range !{i32 0, i32 3}
  store i32 %t384, ptr %l19
  %t386 = load ptr, ptr %l1, !tbaa !29
  %t388 = getelementptr { i64, [5 x i64] }, ptr %t386, i32 0, i32 1
  %t389 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t388, i32 0, i32 4
  %t390 = load { i64, ptr }, ptr %t389
  store { i64, ptr } %t390, ptr %l20, !tbaa !27
  br label %bb133
bb132:
  br label %bb151
bb133:
  %t392 = load i32, ptr %l19, !range !{i32 0, i32 3}
  %t394 = trunc i64 1 to i32
  %t395 = icmp eq i32 %t392, %t394
  br i1 %t395, label %bb134, label %bb135
bb134:
  store i1 true, ptr %l221, !tbaa !21
  br label %bb137
bb135:
  %t397 = load i32, ptr %l18, !range !{i32 0, i32 44}
  %t399 = call i1 @compiler_2fcheck_2eeffectOp(i32 %t397)
  store i1 %t399, ptr %l223
  br label %bb136
bb136:
  %t400 = load i1, ptr %l223, !tbaa !21
  store i1 %t400, ptr %l221, !tbaa !21
  br label %bb137
bb137:
  %t401 = load i1, ptr %l221, !tbaa !21
  br i1 %t401, label %bb138, label %bb139
bb138:
  store i1 true, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  %t403 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t403, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t405 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t405, 0
  store i64 %t407, ptr %l23, !tbaa !24
  br label %bb141
bb141:
  %t409 = load i64, ptr %l22, !tbaa !24
  %t410 = load i64, ptr %l23, !tbaa !24
  %t413 = icmp slt i64 %t409, %t410
  %t415 = xor i1 %t413, true
  br i1 %t415, label %bb142, label %bb143
bb142:
  br label %bb150
bb143:
  br label %bb144
bb144:
  %t417 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t417, ptr %l232, !tbaa !27
  %t418 = load i64, ptr %l22, !tbaa !24
  %t420 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr ptr, ptr %t421, i64 %t418
  %t423 = load ptr, ptr %t422, !tbaa !39
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t430 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t425, ptr %t423)
  store i1 %t430, ptr %l238
  br label %bb145
bb145:
  %t431 = load i1, ptr %l238, !tbaa !21
  br i1 %t431, label %bb146, label %bb147
bb146:
  store i1 true, ptr %rv
  br label %ret
bb147:
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t433 = load i64, ptr %l22, !tbaa !24
  %t435 = add i64 %t433, 1
  store i64 %t435, ptr %l22, !tbaa !24
  br label %bb141
bb150:
  store i1 false, ptr %rv
  br label %ret
bb151:
  %t438 = load ptr, ptr %l1, !tbaa !29
  store ptr %t438, ptr %l243, !tbaa !29
  store i1 false, ptr %l244, !tbaa !21
  %t439 = load ptr, ptr %l243, !tbaa !29
  %t440 = icmp ne ptr %t439, null
  br i1 %t440, label %bb152, label %bb153
bb152:
  %t442 = load ptr, ptr %l243, !tbaa !29
  %t443 = load i64, ptr %t442, !range !{i64 0, i64 18}
  %t445 = icmp eq i64 %t443, 10
  store i1 %t445, ptr %l244, !tbaa !21
  br label %bb153
bb153:
  %t446 = load i1, ptr %l244, !tbaa !21
  br i1 %t446, label %bb154, label %bb155
bb154:
  %t447 = load ptr, ptr %l1, !tbaa !29
  %t449 = getelementptr { i64, [5 x i64] }, ptr %t447, i32 0, i32 1
  %t450 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t449, i32 0, i32 2
  %t451 = load ptr, ptr %t450
  store ptr %t451, ptr %l25, !tbaa !29
  br label %bb156
bb155:
  br label %bb169
bb156:
  %t453 = load ptr, ptr %l25, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Slice", ptr %t453, i32 0, i32 3
  %t456 = load i32, ptr %t455, !range !{i32 0, i32 3}
  %t458 = trunc i64 1 to i32
  %t459 = icmp eq i32 %t456, %t458
  br i1 %t459, label %bb157, label %bb158
bb157:
  store i1 true, ptr %l252, !tbaa !21
  br label %bb160
bb158:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load ptr, ptr %l25, !tbaa !29
  %t464 = getelementptr %"compiler/typed:Slice", ptr %t462, i32 0, i32 0
  %t465 = load ptr, ptr %t464, !tbaa !29
  %t468 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t461, ptr %t465, i1 false)
  store i1 %t468, ptr %l256
  br label %bb159
bb159:
  %t469 = load i1, ptr %l256, !tbaa !21
  store i1 %t469, ptr %l252, !tbaa !21
  br label %bb160
bb160:
  %t470 = load i1, ptr %l252, !tbaa !21
  br i1 %t470, label %bb161, label %bb162
bb161:
  store i1 true, ptr %l257, !tbaa !21
  br label %bb164
bb162:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load ptr, ptr %l25, !tbaa !29
  %t474 = getelementptr %"compiler/typed:Slice", ptr %t472, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t479 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t471, ptr %t475)
  store i1 %t479, ptr %l262
  br label %bb163
bb163:
  %t480 = load i1, ptr %l262, !tbaa !21
  store i1 %t480, ptr %l257, !tbaa !21
  br label %bb164
bb164:
  %t481 = load i1, ptr %l257, !tbaa !21
  br i1 %t481, label %bb165, label %bb166
bb165:
  store i1 true, ptr %l263, !tbaa !21
  br label %bb168
bb166:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load ptr, ptr %l25, !tbaa !29
  %t485 = getelementptr %"compiler/typed:Slice", ptr %t483, i32 0, i32 2
  %t486 = load ptr, ptr %t485, !tbaa !29
  %t490 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t482, ptr %t486)
  store i1 %t490, ptr %l268
  br label %bb167
bb167:
  %t491 = load i1, ptr %l268, !tbaa !21
  store i1 %t491, ptr %l263, !tbaa !21
  br label %bb168
bb168:
  %t492 = load i1, ptr %l263, !tbaa !21
  store i1 %t492, ptr %rv
  br label %ret
bb169:
  %t493 = load ptr, ptr %l1, !tbaa !29
  store ptr %t493, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t494 = load ptr, ptr %l269, !tbaa !29
  %t495 = icmp ne ptr %t494, null
  br i1 %t495, label %bb170, label %bb171
bb170:
  %t497 = load ptr, ptr %l269, !tbaa !29
  %t498 = load i64, ptr %t497, !range !{i64 0, i64 18}
  %t500 = icmp eq i64 %t498, 11
  store i1 %t500, ptr %l270, !tbaa !21
  br label %bb171
bb171:
  %t501 = load i1, ptr %l270, !tbaa !21
  br i1 %t501, label %bb172, label %bb173
bb172:
  %t502 = load ptr, ptr %l1, !tbaa !29
  %t504 = getelementptr { i64, [5 x i64] }, ptr %t502, i32 0, i32 1
  %t505 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t504, i32 0, i32 2
  %t506 = load ptr, ptr %t505
  store ptr %t506, ptr %l26, !tbaa !29
  br label %bb174
bb173:
  br label %bb184
bb174:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load ptr, ptr %l26, !tbaa !29
  %t511 = getelementptr %"compiler/typed:Cond", ptr %t509, i32 0, i32 0
  %t512 = load ptr, ptr %t511, !tbaa !29
  %t516 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t508, ptr %t512)
  store i1 %t516, ptr %l279
  br label %bb175
bb175:
  %t517 = load i1, ptr %l279, !tbaa !21
  br i1 %t517, label %bb176, label %bb177
bb176:
  store i1 true, ptr %l280, !tbaa !21
  br label %bb179
bb177:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load ptr, ptr %l26, !tbaa !29
  %t521 = getelementptr %"compiler/typed:Cond", ptr %t519, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t525 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t518, ptr %t522)
  store i1 %t525, ptr %l284
  br label %bb178
bb178:
  %t526 = load i1, ptr %l284, !tbaa !21
  store i1 %t526, ptr %l280, !tbaa !21
  br label %bb179
bb179:
  %t527 = load i1, ptr %l280, !tbaa !21
  br i1 %t527, label %bb180, label %bb181
bb180:
  store i1 true, ptr %l285, !tbaa !21
  br label %bb183
bb181:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load ptr, ptr %l26, !tbaa !29
  %t531 = getelementptr %"compiler/typed:Cond", ptr %t529, i32 0, i32 2
  %t532 = load ptr, ptr %t531, !tbaa !29
  %t536 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t528, ptr %t532)
  store i1 %t536, ptr %l290
  br label %bb182
bb182:
  %t537 = load i1, ptr %l290, !tbaa !21
  store i1 %t537, ptr %l285, !tbaa !21
  br label %bb183
bb183:
  %t538 = load i1, ptr %l285, !tbaa !21
  store i1 %t538, ptr %rv
  br label %ret
bb184:
  %t539 = load ptr, ptr %l1, !tbaa !29
  store ptr %t539, ptr %l291, !tbaa !29
  store i1 false, ptr %l292, !tbaa !21
  %t540 = load ptr, ptr %l291, !tbaa !29
  %t541 = icmp ne ptr %t540, null
  br i1 %t541, label %bb185, label %bb186
bb185:
  %t543 = load ptr, ptr %l291, !tbaa !29
  %t544 = load i64, ptr %t543, !range !{i64 0, i64 18}
  %t546 = icmp eq i64 %t544, 12
  store i1 %t546, ptr %l292, !tbaa !21
  br label %bb186
bb186:
  %t547 = load i1, ptr %l292, !tbaa !21
  br i1 %t547, label %bb187, label %bb188
bb187:
  %t548 = load ptr, ptr %l1, !tbaa !29
  %t550 = getelementptr { i64, [5 x i64] }, ptr %t548, i32 0, i32 1
  %t551 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t550, i32 0, i32 2
  %t552 = load ptr, ptr %t551
  store ptr %t552, ptr %l27, !tbaa !29
  br label %bb189
bb188:
  br label %bb195
bb189:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load ptr, ptr %l27, !tbaa !29
  %t557 = getelementptr %"compiler/typed:Seq", ptr %t555, i32 0, i32 0
  %t558 = load { i64, ptr }, ptr %t557, !tbaa !27
  %t561 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %t554, { i64, ptr } %t558)
  store i1 %t561, ptr %l300
  br label %bb190
bb190:
  %t562 = load i1, ptr %l300, !tbaa !21
  br i1 %t562, label %bb191, label %bb192
bb191:
  store i1 true, ptr %l301, !tbaa !21
  br label %bb194
bb192:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load ptr, ptr %l27, !tbaa !29
  %t566 = getelementptr %"compiler/typed:Seq", ptr %t564, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !29
  %t570 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t563, ptr %t567)
  store i1 %t570, ptr %l305
  br label %bb193
bb193:
  %t571 = load i1, ptr %l305, !tbaa !21
  store i1 %t571, ptr %l301, !tbaa !21
  br label %bb194
bb194:
  %t572 = load i1, ptr %l301, !tbaa !21
  store i1 %t572, ptr %rv
  br label %ret
bb195:
  %t573 = load ptr, ptr %l1, !tbaa !29
  store ptr %t573, ptr %l306, !tbaa !29
  store i1 false, ptr %l307, !tbaa !21
  %t574 = load ptr, ptr %l306, !tbaa !29
  %t575 = icmp ne ptr %t574, null
  br i1 %t575, label %bb196, label %bb197
bb196:
  %t577 = load ptr, ptr %l306, !tbaa !29
  %t578 = load i64, ptr %t577, !range !{i64 0, i64 18}
  %t580 = icmp eq i64 %t578, 13
  store i1 %t580, ptr %l307, !tbaa !21
  br label %bb197
bb197:
  %t581 = load i1, ptr %l307, !tbaa !21
  br i1 %t581, label %bb198, label %bb199
bb198:
  %t582 = load ptr, ptr %l1, !tbaa !29
  %t584 = getelementptr { i64, [5 x i64] }, ptr %t582, i32 0, i32 1
  %t585 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t584, i32 0, i32 2
  %t586 = load ptr, ptr %t585
  store ptr %t586, ptr %l28, !tbaa !29
  br label %bb200
bb199:
  br label %bb222
bb200:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load ptr, ptr %l28, !tbaa !29
  %t591 = getelementptr %"compiler/typed:Match", ptr %t589, i32 0, i32 0
  %t592 = load { i64, ptr }, ptr %t591, !tbaa !27
  %t595 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %t588, { i64, ptr } %t592)
  store i1 %t595, ptr %l315
  br label %bb201
bb201:
  %t596 = load i1, ptr %l315, !tbaa !21
  br i1 %t596, label %bb202, label %bb203
bb202:
  store i1 true, ptr %rv
  br label %ret
bb203:
  br label %bb204
bb204:
  %t598 = load ptr, ptr %l28, !tbaa !29
  %t600 = getelementptr %"compiler/typed:Match", ptr %t598, i32 0, i32 1
  %t601 = load { i64, ptr }, ptr %t600, !tbaa !27
  store { i64, ptr } %t601, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t603 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t605 = extractvalue { i64, ptr } %t603, 0
  store i64 %t605, ptr %l31, !tbaa !24
  br label %bb205
bb205:
  %t607 = load i64, ptr %l30, !tbaa !24
  %t608 = load i64, ptr %l31, !tbaa !24
  %t611 = icmp slt i64 %t607, %t608
  %t613 = xor i1 %t611, true
  br i1 %t613, label %bb206, label %bb207
bb206:
  br label %bb214
bb207:
  br label %bb208
bb208:
  %t615 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t615, ptr %l325, !tbaa !27
  %t616 = load i64, ptr %l30, !tbaa !24
  %t618 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t619 = load ptr, ptr %t618, !tbaa !27
  %t620 = getelementptr ptr, ptr %t619, i64 %t616
  %t621 = load ptr, ptr %t620, !tbaa !39
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t627 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %t623, ptr %t621)
  store i1 %t627, ptr %l330
  br label %bb209
bb209:
  %t628 = load i1, ptr %l330, !tbaa !21
  br i1 %t628, label %bb210, label %bb211
bb210:
  store i1 true, ptr %rv
  br label %ret
bb211:
  br label %bb212
bb212:
  br label %bb213
bb213:
  %t630 = load i64, ptr %l30, !tbaa !24
  %t632 = add i64 %t630, 1
  store i64 %t632, ptr %l30, !tbaa !24
  br label %bb205
bb214:
  %t634 = load ptr, ptr %l28, !tbaa !29
  %t636 = getelementptr %"compiler/typed:Match", ptr %t634, i32 0, i32 2
  %t637 = load ptr, ptr %t636, !tbaa !29
  %t639 = icmp eq ptr %t637, null
  %t641 = xor i1 %t639, true
  br i1 %t641, label %bb215, label %bb216
bb215:
  %t643 = load ptr, ptr %l0, !tbaa !29
  store ptr %t643, ptr %l339, !tbaa !29
  %t644 = load ptr, ptr %l28, !tbaa !29
  %t646 = getelementptr %"compiler/typed:Match", ptr %t644, i32 0, i32 2
  %t647 = load ptr, ptr %t646, !tbaa !29
  %t649 = icmp eq ptr %t647, null
  br i1 %t649, label %bb217, label %bb218
bb216:
  store i1 false, ptr %l338, !tbaa !21
  br label %bb221
bb217:
  call void @__olang_check_failed(ptr @olang_loc_ad4dc9fe288360e2_6bae22496d237a26)
  unreachable
bb218:
  br label %bb219
bb219:
  %t651 = load ptr, ptr %l28, !tbaa !29
  %t653 = getelementptr %"compiler/typed:Match", ptr %t651, i32 0, i32 2
  %t654 = load ptr, ptr %t653, !tbaa !29
  %t655 = load ptr, ptr %l339, !tbaa !29
  %t657 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %t655, ptr %t654)
  store i1 %t657, ptr %l345
  br label %bb220
bb220:
  %t658 = load i1, ptr %l345, !tbaa !21
  store i1 %t658, ptr %l338, !tbaa !21
  br label %bb221
bb221:
  %t659 = load i1, ptr %l338, !tbaa !21
  store i1 %t659, ptr %rv
  br label %ret
bb222:
  %t660 = load ptr, ptr %l1, !tbaa !29
  store ptr %t660, ptr %l346, !tbaa !29
  store i1 false, ptr %l347, !tbaa !21
  %t661 = load ptr, ptr %l346, !tbaa !29
  %t662 = icmp ne ptr %t661, null
  br i1 %t662, label %bb223, label %bb224
bb223:
  %t664 = load ptr, ptr %l346, !tbaa !29
  %t665 = load i64, ptr %t664, !range !{i64 0, i64 18}
  %t667 = icmp eq i64 %t665, 14
  store i1 %t667, ptr %l347, !tbaa !21
  br label %bb224
bb224:
  %t668 = load i1, ptr %l347, !tbaa !21
  br i1 %t668, label %bb225, label %bb226
bb225:
  %t669 = load ptr, ptr %l1, !tbaa !29
  %t671 = getelementptr { i64, [5 x i64] }, ptr %t669, i32 0, i32 1
  %t672 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t671, i32 0, i32 2
  %t673 = load ptr, ptr %t672
  store ptr %t673, ptr %l33, !tbaa !29
  br label %bb227
bb226:
  br label %bb255
bb227:
  %t675 = load ptr, ptr %l33, !tbaa !29
  %t677 = getelementptr %"compiler/typed:Try", ptr %t675, i32 0, i32 2
  %t678 = load i1, ptr %t677, !tbaa !21
  br i1 %t678, label %bb228, label %bb229
bb228:
  store i1 true, ptr %l354, !tbaa !21
  br label %bb231
bb229:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load ptr, ptr %l33, !tbaa !29
  %t683 = getelementptr %"compiler/typed:Try", ptr %t681, i32 0, i32 0
  %t684 = load ptr, ptr %t683, !tbaa !29
  %t687 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t680, ptr %t684)
  store i1 %t687, ptr %l358
  br label %bb230
bb230:
  %t688 = load i1, ptr %l358, !tbaa !21
  store i1 %t688, ptr %l354, !tbaa !21
  br label %bb231
bb231:
  %t689 = load i1, ptr %l354, !tbaa !21
  br i1 %t689, label %bb232, label %bb233
bb232:
  store i1 true, ptr %rv
  br label %ret
bb233:
  br label %bb234
bb234:
  %t691 = load ptr, ptr %l33, !tbaa !29
  %t693 = getelementptr %"compiler/typed:Try", ptr %t691, i32 0, i32 1
  %t694 = load { i64, ptr }, ptr %t693, !tbaa !27
  store { i64, ptr } %t694, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t696 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t698 = extractvalue { i64, ptr } %t696, 0
  store i64 %t698, ptr %l36, !tbaa !24
  br label %bb235
bb235:
  %t700 = load i64, ptr %l35, !tbaa !24
  %t701 = load i64, ptr %l36, !tbaa !24
  %t704 = icmp slt i64 %t700, %t701
  %t706 = xor i1 %t704, true
  br i1 %t706, label %bb236, label %bb237
bb236:
  br label %bb254
bb237:
  br label %bb238
bb238:
  %t708 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t708, ptr %l368, !tbaa !27
  %t709 = load i64, ptr %l35, !tbaa !24
  %t711 = getelementptr { i64, ptr }, ptr %l368, i32 0, i32 1
  %t712 = load ptr, ptr %t711, !tbaa !27
  %t713 = getelementptr ptr, ptr %t712, i64 %t709
  %t714 = load ptr, ptr %t713, !tbaa !39
  store ptr %t714, ptr %l37, !tbaa !29
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = load ptr, ptr %l37, !tbaa !29
  %t719 = getelementptr %"compiler/typed:Clause", ptr %t717, i32 0, i32 3
  %t720 = load ptr, ptr %t719, !tbaa !29
  %t723 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %t716, ptr %t720)
  store i1 %t723, ptr %l374
  br label %bb239
bb239:
  %t724 = load i1, ptr %l374, !tbaa !21
  br i1 %t724, label %bb240, label %bb241
bb240:
  store i1 true, ptr %rv
  br label %ret
bb241:
  br label %bb242
bb242:
  %t726 = load ptr, ptr %l37, !tbaa !29
  %t728 = getelementptr %"compiler/typed:Clause", ptr %t726, i32 0, i32 4
  %t729 = load { i64, ptr }, ptr %t728, !tbaa !27
  store { i64, ptr } %t729, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t731 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t733 = extractvalue { i64, ptr } %t731, 0
  store i64 %t733, ptr %l40, !tbaa !24
  br label %bb243
bb243:
  %t735 = load i64, ptr %l39, !tbaa !24
  %t736 = load i64, ptr %l40, !tbaa !24
  %t739 = icmp slt i64 %t735, %t736
  %t741 = xor i1 %t739, true
  br i1 %t741, label %bb244, label %bb245
bb244:
  br label %bb252
bb245:
  br label %bb246
bb246:
  %t743 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t743, ptr %l384, !tbaa !27
  %t744 = load i64, ptr %l39, !tbaa !24
  %t746 = getelementptr { i64, ptr }, ptr %l384, i32 0, i32 1
  %t747 = load ptr, ptr %t746, !tbaa !27
  %t748 = getelementptr ptr, ptr %t747, i64 %t744
  %t749 = load ptr, ptr %t748, !tbaa !39
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t756 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t751, ptr %t749)
  store i1 %t756, ptr %l390
  br label %bb247
bb247:
  %t757 = load i1, ptr %l390, !tbaa !21
  br i1 %t757, label %bb248, label %bb249
bb248:
  store i1 true, ptr %rv
  br label %ret
bb249:
  br label %bb250
bb250:
  br label %bb251
bb251:
  %t759 = load i64, ptr %l39, !tbaa !24
  %t761 = add i64 %t759, 1
  store i64 %t761, ptr %l39, !tbaa !24
  br label %bb243
bb252:
  br label %bb253
bb253:
  %t763 = load i64, ptr %l35, !tbaa !24
  %t765 = add i64 %t763, 1
  store i64 %t765, ptr %l35, !tbaa !24
  br label %bb235
bb254:
  store i1 false, ptr %rv
  br label %ret
bb255:
  %t768 = load ptr, ptr %l1, !tbaa !29
  store ptr %t768, ptr %l397, !tbaa !29
  store i1 false, ptr %l398, !tbaa !21
  %t769 = load ptr, ptr %l397, !tbaa !29
  %t770 = icmp ne ptr %t769, null
  br i1 %t770, label %bb256, label %bb257
bb256:
  %t772 = load ptr, ptr %l397, !tbaa !29
  %t773 = load i64, ptr %t772, !range !{i64 0, i64 18}
  %t775 = icmp eq i64 %t773, 17
  store i1 %t775, ptr %l398, !tbaa !21
  br label %bb257
bb257:
  %t776 = load i1, ptr %l398, !tbaa !21
  br i1 %t776, label %bb258, label %bb259
bb258:
  %t777 = load ptr, ptr %l1, !tbaa !29
  %t779 = getelementptr { i64, [5 x i64] }, ptr %t777, i32 0, i32 1
  %t780 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t779, i32 0, i32 2
  %t781 = load ptr, ptr %t780
  store ptr %t781, ptr %l42, !tbaa !29
  br label %bb260
bb259:
  br label %bb262
bb260:
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load ptr, ptr %l42, !tbaa !29
  %t788 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t783, ptr %t784)
  store i1 %t788, ptr %l406
  br label %bb261
bb261:
  %t789 = load i1, ptr %l406, !tbaa !21
  store i1 %t789, ptr %rv
  br label %ret
bb262:
  call void @__olang_check_failed(ptr @olang_loc_29ea0c7d0dcef6fa_322b22c08f06752e)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrHolds(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l4, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t8, i32 %a2)
  store i32 %t12, ptr %l9
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s0, ptr %t13, i32 %t14)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l10
  br label %bb2
bb2:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t17 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t17
  store ptr %t17, ptr %l11, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t24, i32 %a1)
  store i32 %t28, ptr %l17
  br label %bb3
bb3:
  %t29 = load ptr, ptr %l12, !tbaa !29
  %t30 = load i32, ptr %l17, !tbaa !23
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s0, ptr %t29, i32 %t30)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l18
  br label %bb4
bb4:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  %t33 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %t33
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t35 = load ptr, ptr %l11, !tbaa !29
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t34, ptr %t35, ptr %t33)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l20
  br label %bb5
bb5:
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l20)
  store i64 %t39, ptr %l22
  br label %bb6
bb6:
  %t40 = load i64, ptr %l22, !tbaa !24
  %t41 = icmp eq i64 %t40, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l20, !tbaa !24
  %t21 = load i64, ptr %l20, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t32, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t34 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t35, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t66 = load i64, ptr %l31, !tbaa !24
  store i64 %t66, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l28, !tbaa !24
  store i64 %t67, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l9, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = icmp sgt i64 %t86, 0
  br i1 %t88, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  store ptr %l3, ptr %l52, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t93
  %t98 = load i32, ptr %t97, !tbaa !33
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t91, i32 %t98)
  store { i64, ptr } %t101, ptr %l57
  br label %bb20
bb20:
  %t102 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t109, { i64, ptr } %t108)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb12
bb23:
  %t116 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t116, ptr %l62
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternArray(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l20 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i1
  %l32 = alloca i32
  %l39 = alloca i32
  %l43 = alloca i1
  %l48 = alloca i32
  %l52 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/source:Span"
  %l67 = alloca i32
  %l70 = alloca ptr
  %l73 = alloca ptr
  %l78 = alloca i32
  %l80 = alloca i32
  %l81 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca %"compiler/source:Span"
  %l91 = alloca i32
  %l94 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca ptr
  %l109 = alloca ptr
  %rv = alloca ptr
  %t111 = alloca { i64, [5 x i64] }, align 8
  %t167 = alloca { i64, [5 x i64] }, align 8
  %t202 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_12a7e56ab193c888_f3ea9b5a769b449c)
  unreachable
bb11:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t13 = xor i1 %t10, true
  br i1 %t13, label %bb12, label %bb13
bb12:
  store ptr null, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t16)
  store i32 %t19, ptr %l20
  br label %bb15
bb15:
  %t20 = load i32, ptr %l20, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l23
  br label %bb16
bb16:
  %t26 = load i32, ptr %l23, !tbaa !23
  store i32 %t26, ptr %l7, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  br i1 %t31, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb20
bb18:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l7, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l32
  br label %bb19
bb19:
  %t43 = load i32, ptr %l32, !tbaa !23
  %t44 = icmp ne i32 %t43, 0
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb20
bb20:
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb21, label %bb22
bb21:
  store ptr null, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l6, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l39
  br label %bb24
bb24:
  %t58 = load i32, ptr %l39, !range !{i32 0, i32 33}
  %t60 = trunc i64 19 to i32
  %t61 = icmp eq i32 %t58, %t60
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb28
bb26:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l6, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l48
  br label %bb27
bb27:
  %t75 = load i32, ptr %l48, !tbaa !23
  %t76 = icmp eq i32 %t75, 0
  store i1 %t76, ptr %l43, !tbaa !21
  br label %bb28
bb28:
  %t78 = load i1, ptr %l43, !tbaa !21
  br i1 %t78, label %bb29, label %bb30
bb29:
  store ptr null, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v3, ptr %t80)
  store ptr %t82, ptr %l52
  br label %bb32
bb32:
  %t83 = load ptr, ptr %l52, !tbaa !29
  store ptr %t83, ptr %l8, !tbaa !29
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb33, label %bb34
bb33:
  store ptr null, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l3, !tbaa !23
  %t93 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t89, i32 %t90)
  store i1 %t93, ptr %l58
  br label %bb36
bb36:
  %t94 = load i1, ptr %l58, !tbaa !21
  br i1 %t94, label %bb37, label %bb38
bb37:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l59, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t96, ptr %l60
  %t97 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t97, ptr %l61
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 2
  %t104 = load i32, ptr %l6, !tbaa !23
  %t105 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t103, i32 %t104, i64 %t105)
  store i32 %t109, ptr %l67
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t110 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 0
  store i64 3, ptr %t112
  %t113 = load %"compiler/source:Span", ptr %l61
  %t114 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t113, 0
  %t115 = load i32, ptr %l67, !tbaa !23
  %t116 = insertvalue { %"compiler/source:Span", i32, ptr } %t114, i32 %t115, 1
  %t118 = insertvalue { %"compiler/source:Span", i32, ptr } %t116, ptr %t110, 2
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t118, ptr %t119
  %t120 = load { i64, [5 x i64] }, ptr %t111
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t120, ptr %t122
  store ptr %t122, ptr %l70, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  store ptr %t128, ptr %l73, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 2
  %t135 = load i32, ptr %l3, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t134, i32 %t135)
  store i32 %t138, ptr %l78
  br label %bb40
bb40:
  %t139 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t140 = load ptr, ptr %l73, !tbaa !29
  %t141 = load i32, ptr %l78, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t140, i32 %t141, i64 %t139)
  store i32 %t143, ptr %l80
  br label %bb41
bb41:
  %t144 = load ptr, ptr %l59, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l60
  %t146 = load ptr, ptr %l70, !tbaa !29
  %t147 = load i32, ptr %l80, !tbaa !23
  %t148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v0, ptr %v3, ptr %t144, %"compiler/source:Span" %t145, ptr %t146, i32 %t147)
  store ptr %t148, ptr %l81
  br label %bb42
bb42:
  %t149 = load ptr, ptr %l81, !tbaa !29
  store ptr %t149, ptr %rv
  br label %ret
bb43:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l83, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t152, ptr %l84
  %t153 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t153, ptr %l85
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l6, !tbaa !23
  %t161 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t159, i32 %t160, i64 %t161)
  store i32 %t165, ptr %l91
  br label %bb44
bb44:
  %t166 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t167
  %t168 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 0
  store i64 3, ptr %t168
  %t169 = load %"compiler/source:Span", ptr %l85
  %t170 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t169, 0
  %t171 = load i32, ptr %l91, !tbaa !23
  %t172 = insertvalue { %"compiler/source:Span", i32, ptr } %t170, i32 %t171, 1
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } %t172, ptr %t166, 2
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t174, ptr %t175
  %t176 = load { i64, [5 x i64] }, ptr %t167
  %t178 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t176, ptr %t178
  store ptr %t178, ptr %l94, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l3, !tbaa !23
  %t186 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t190 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t184, i32 %t185, i64 %t186)
  store i32 %t190, ptr %l100
  br label %bb45
bb45:
  %t191 = load ptr, ptr %l83, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l84
  %t193 = load ptr, ptr %l94, !tbaa !29
  %t194 = load i32, ptr %l100, !tbaa !23
  %t195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v0, ptr %v3, ptr %t191, %"compiler/source:Span" %t192, ptr %t193, i32 %t194)
  store ptr %t195, ptr %l101
  br label %bb46
bb46:
  %t196 = load ptr, ptr %l101, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l4
  %t199 = load %"compiler/source:Span", ptr %l4
  %t200 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 0
  store i64 2, ptr %t203
  %t205 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t199, 0
  %t207 = insertvalue { %"compiler/source:Span", i32, ptr } %t205, i32 %t200, 1
  %t209 = insertvalue { %"compiler/source:Span", i32, ptr } %t207, ptr %t196, 2
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t209, ptr %t210
  %t211 = load { i64, [4 x i64] }, ptr %t202
  %t213 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t211, ptr %t213
  %t217 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t197, %"compiler/source:Span" %t198, ptr %t213)
  store ptr %t217, ptr %l109
  br label %bb47
bb47:
  %t218 = load ptr, ptr %l109, !tbaa !29
  store ptr %t218, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeWritten(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l17 = alloca { i64, [3 x i64] }
  %l22 = alloca i1
  %l34 = alloca { i64, ptr }
  %l45 = alloca { i64, [3 x i64] }
  %rv = alloca { i64, [3 x i64] }
  %t87 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/ast:VarDecl", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v2, ptr %t10, i64 %t11, ptr %t15)
  store { i64, [3 x i64] } %t19, ptr %l17
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t20 = load { i64, [3 x i64] }, ptr %l17
  store { i64, [3 x i64] } %t20, ptr %rv
  br label %ret
bb4:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:StructBody", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/ast:VarDecl", ptr %t30, i32 0, i32 4
  %t33 = load i1, ptr %t32, !tbaa !21
  %t35 = xor i1 %t33, true
  store i1 %t35, ptr %l22, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb7
bb7:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/ast:StructBody", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l34, !tbaa !27
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l8, !tbaa !29
  %t63 = load ptr, ptr %l8, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Param", ptr %t63, i32 0, i32 1
  %t66 = load i32, ptr %t65, !tbaa !23
  %t70 = icmp eq i32 %t66, %a4
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Param", ptr %t74, i32 0, i32 2
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t81 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %t72, i64 %t73, ptr %t77)
  store { i64, [3 x i64] } %t81, ptr %l45
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t82 = load { i64, [3 x i64] }, ptr %l45
  store { i64, [3 x i64] } %t82, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l6, !tbaa !24
  br label %bb10
bb19:
  br label %bb20
bb20:
  store { i64, [3 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 0
  store i64 0, ptr %t88
  %t89 = load { i64, [3 x i64] }, ptr %t87
  store { i64, [3 x i64] } %t89, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstUncovered(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca i1
  %l63 = alloca i32
  %l67 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l85 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l105 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l119 = alloca i64
  %l122 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l131 = alloca i1
  %l141 = alloca i64
  %l144 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l159 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l22, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l27
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l22, !tbaa !29
  %t18 = load i32, ptr %l27, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l28
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 0, ptr %l4, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb8
bb5:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l37, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb7
bb7:
  %t51 = load i64, ptr %l37, !tbaa !24
  store i64 %t51, ptr %l34, !tbaa !24
  br label %bb8
bb8:
  %t52 = load i64, ptr %l34, !tbaa !24
  store i64 %t52, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb91
bb11:
  br label %bb12
bb12:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l9, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l2, !tbaa !23
  %t73 = load i64, ptr %l9, !tbaa !24
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoValueCase(ptr %v0, ptr %t71, i32 %t72, i64 %t73)
  store i1 %t77, ptr %l58
  br label %bb13
bb13:
  %t78 = load i1, ptr %l58, !tbaa !21
  br i1 %t78, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb90
bb15:
  br label %bb16
bb16:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  %t84 = load i64, ptr %l9, !tbaa !24
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t82, i32 %t83, i64 %t84)
  store i32 %t88, ptr %l63
  br label %bb17
bb17:
  %t89 = load i32, ptr %l63, !tbaa !23
  store i32 %t89, ptr %l10, !tbaa !23
  %t90 = load i32, ptr %l10, !tbaa !23
  %t91 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t94 = icmp ne i32 %t90, %t91
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l70, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l10, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l75
  br label %bb20
bb19:
  %t112 = icmp sge i64 0, 0
  br i1 %t112, label %bb22, label %bb23
bb20:
  %t114 = load ptr, ptr %l70, !tbaa !29
  %t115 = load i32, ptr %l75, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t114, i32 %t115)
  store { i64, ptr } %t116, ptr %l76
  br label %bb21
bb21:
  %t117 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t117, ptr %l67, !tbaa !27
  br label %bb26
bb22:
  %t118 = icmp sle i64 0, 2305843009213693951
  br i1 %t118, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_3f3d818644d50cc7_38dbc52e232a8b93)
  unreachable
bb24:
  %t120 = mul i64 0, 4
  %t121 = insertvalue { i64, ptr } undef, i64 0, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t122, ptr %l67, !tbaa !27
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_3f3d818644d50cc7_38dbc52e232a8b93)
  unreachable
bb26:
  %t124 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t124, ptr %l11, !tbaa !27
  %t125 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t125, ptr %l80
  br label %bb27
bb27:
  %t126 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  %t127 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %t127
  store ptr %t127, ptr %l12, !tbaa !29
  store ptr %a1, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb28
bb28:
  %t131 = load i64, ptr %l14, !tbaa !24
  store i64 %t131, ptr %l83, !tbaa !24
  %t132 = load ptr, ptr %l13, !tbaa !29
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t132)
  store i64 %t134, ptr %l85
  br label %bb29
bb29:
  %t135 = load i64, ptr %l83, !tbaa !24
  %t136 = load i64, ptr %l85, !tbaa !24
  %t137 = icmp slt i64 %t135, %t136
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb30, label %bb31
bb30:
  br label %bb85
bb31:
  br label %bb32
bb32:
  %t141 = load ptr, ptr %l13, !tbaa !29
  %t142 = load i64, ptr %l14, !tbaa !24
  %t145 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t141, i64 %t142)
  store { i64, ptr } %t145, ptr %l90
  br label %bb33
bb33:
  %t146 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t146, ptr %l15, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t147, ptr %l91, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr ptr, ptr %t149, i64 0
  %t151 = load ptr, ptr %t150, !tbaa !39
  store ptr %t151, ptr %l16, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l16, !tbaa !29
  %t157 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t153, ptr %t154)
  store i1 %t157, ptr %l95
  br label %bb34
bb34:
  %t158 = load i1, ptr %l95, !tbaa !21
  br i1 %t158, label %bb35, label %bb36
bb35:
  %t159 = load ptr, ptr %l12, !tbaa !29
  store ptr %t159, ptr %l96, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t160, ptr %l97, !tbaa !27
  %t161 = icmp sge i64 0, 0
  br i1 %t161, label %bb37, label %bb38
bb36:
  br label %bb43
bb37:
  %t163 = icmp sle i64 0, 1152921504606846975
  br i1 %t163, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_f2fc693d8c32a9d2_b249c5d053dbb65e)
  unreachable
bb39:
  %t165 = mul i64 0, 8
  %t166 = insertvalue { i64, ptr } undef, i64 0, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t168 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t174 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t171, { i64, ptr } %t167, i64 %t170)
  store { i64, ptr } %t174, ptr %l103
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_f2fc693d8c32a9d2_b249c5d053dbb65e)
  unreachable
bb41:
  %t175 = load ptr, ptr %l96, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l103, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %s2, ptr %v1, ptr %t175, { i64, ptr } %t176)
  br label %bb42
bb42:
  br label %bb84
bb43:
  %t177 = load ptr, ptr %l16, !tbaa !29
  store ptr %t177, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t178 = load ptr, ptr %l104, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb44, label %bb45
bb44:
  %t181 = load ptr, ptr %l104, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 8}
  %t184 = icmp eq i64 %t182, 1
  store i1 %t184, ptr %l105, !tbaa !21
  br label %bb45
bb45:
  %t185 = load i1, ptr %l105, !tbaa !21
  br i1 %t185, label %bb46, label %bb47
bb46:
  %t186 = load ptr, ptr %l16, !tbaa !29
  %t188 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", ptr }, ptr %t188, i32 0, i32 1
  %t190 = load ptr, ptr %t189
  store ptr %t190, ptr %l17, !tbaa !29
  br label %bb52
bb47:
  %t192 = load ptr, ptr %l16, !tbaa !29
  store ptr %t192, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t193 = load ptr, ptr %l110, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb48, label %bb49
bb48:
  %t196 = load ptr, ptr %l110, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 8}
  %t199 = icmp eq i64 %t197, 4
  store i1 %t199, ptr %l111, !tbaa !21
  br label %bb49
bb49:
  %t200 = load i1, ptr %l111, !tbaa !21
  br i1 %t200, label %bb50, label %bb51
bb50:
  %t201 = load ptr, ptr %l16, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", ptr }, ptr %t203, i32 0, i32 1
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l17, !tbaa !29
  br label %bb52
bb51:
  br label %bb63
bb52:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load ptr, ptr %l17, !tbaa !29
  %t209 = load i32, ptr %l2, !tbaa !23
  %t213 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t207, ptr %t208, i32 %t209)
  store i64 %t213, ptr %l119
  br label %bb53
bb53:
  %t214 = load i64, ptr %l9, !tbaa !24
  %t215 = load i64, ptr %l119, !tbaa !24
  %t217 = icmp eq i64 %t215, %t214
  br i1 %t217, label %bb54, label %bb55
bb54:
  %t219 = load ptr, ptr %l12, !tbaa !29
  store ptr %t219, ptr %l122, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t220, ptr %l123, !tbaa !27
  %t221 = icmp sge i64 0, 0
  br i1 %t221, label %bb56, label %bb57
bb55:
  br label %bb62
bb56:
  %t223 = icmp sle i64 0, 1152921504606846975
  br i1 %t223, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_1aa49c7f94741e71_4937354175d6cb9d)
  unreachable
bb58:
  %t225 = mul i64 0, 8
  %t226 = insertvalue { i64, ptr } undef, i64 0, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t228 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t231 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t234 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t231, { i64, ptr } %t227, i64 %t230)
  store { i64, ptr } %t234, ptr %l129
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_1aa49c7f94741e71_4937354175d6cb9d)
  unreachable
bb60:
  %t235 = load ptr, ptr %l122, !tbaa !29
  %t236 = load { i64, ptr }, ptr %l129, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %s2, ptr %v1, ptr %t235, { i64, ptr } %t236)
  br label %bb61
bb61:
  br label %bb62
bb62:
  br label %bb83
bb63:
  %t237 = load ptr, ptr %l16, !tbaa !29
  store ptr %t237, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t238 = load ptr, ptr %l130, !tbaa !29
  %t239 = icmp ne ptr %t238, null
  br i1 %t239, label %bb64, label %bb65
bb64:
  %t241 = load ptr, ptr %l130, !tbaa !29
  %t242 = load i64, ptr %t241, !range !{i64 0, i64 8}
  %t244 = icmp eq i64 %t242, 2
  store i1 %t244, ptr %l131, !tbaa !21
  br label %bb65
bb65:
  %t245 = load i1, ptr %l131, !tbaa !21
  br i1 %t245, label %bb66, label %bb67
bb66:
  %t246 = load ptr, ptr %l16, !tbaa !29
  %t248 = getelementptr { i64, [4 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t248, i32 0, i32 1
  %t250 = load ptr, ptr %t249
  store ptr %t250, ptr %l18, !tbaa !29
  %t252 = load ptr, ptr %l16, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t254, i32 0, i32 2
  %t256 = load { i64, ptr }, ptr %t255
  store { i64, ptr } %t256, ptr %l19, !tbaa !27
  br label %bb68
bb67:
  br label %bb78
bb68:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %l18, !tbaa !29
  %t260 = load i32, ptr %l2, !tbaa !23
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t258, ptr %t259, i32 %t260)
  store i64 %t264, ptr %l141
  br label %bb69
bb69:
  %t265 = load i64, ptr %l9, !tbaa !24
  %t266 = load i64, ptr %l141, !tbaa !24
  %t268 = icmp eq i64 %t266, %t265
  br i1 %t268, label %bb70, label %bb71
bb70:
  %t270 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t273 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t278 = icmp eq i64 %t272, %t275
  store i1 %t278, ptr %l144, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb72
bb72:
  %t280 = load i1, ptr %l144, !tbaa !21
  br i1 %t280, label %bb73, label %bb74
bb73:
  %t281 = load ptr, ptr %l12, !tbaa !29
  store ptr %t281, ptr %l150, !tbaa !29
  %t282 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t286 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t282, { i64, ptr } %t283, i64 0)
  store { i64, ptr } %t286, ptr %l153
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t287 = load ptr, ptr %l150, !tbaa !29
  %t288 = load { i64, ptr }, ptr %l153, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %s2, ptr %v1, ptr %t287, { i64, ptr } %t288)
  br label %bb76
bb76:
  br label %bb77
bb77:
  br label %bb83
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_a8287edb9132b4cb_1f129b43d5c83daf)
  unreachable
bb83:
  br label %bb84
bb84:
  %t289 = load i64, ptr %l14, !tbaa !24
  %t291 = add i64 %t289, 1
  store i64 %t291, ptr %l14, !tbaa !24
  br label %bb28
bb85:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l12, !tbaa !29
  %t295 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t299 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %s2, ptr %s2, ptr %t293, ptr %t294, { i64, ptr } %t295, i64 1)
  store i1 %t299, ptr %l159
  br label %bb86
bb86:
  %t300 = load i1, ptr %l159, !tbaa !21
  %t301 = xor i1 %t300, true
  br i1 %t301, label %bb87, label %bb88
bb87:
  %t303 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t303, ptr %rv
  br label %ret
bb88:
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s2)
  br label %bb90
bb90:
  %t305 = load i64, ptr %l8, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l8, !tbaa !24
  br label %bb9
bb91:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenResultMet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l24 = alloca { i64, ptr }
  %l28 = alloca i1
  %l33 = alloca i1
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t36, ptr %l24, !tbaa !27
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 %t37
  %t42 = load ptr, ptr %t41, !tbaa !39
  store ptr %t42, ptr %l7, !tbaa !29
  %t44 = load ptr, ptr %l7, !tbaa !29
  %t46 = call i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v1, ptr %t44)
  store i1 %t46, ptr %l28
  br label %bb13
bb13:
  %t47 = load i1, ptr %l28, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t55 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %t51)
  store i1 %t55, ptr %l33
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb9
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_48c434cc052a730a_3ea1b318a5aaa0d6)
  unreachable
bb25:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0) #0 {
entry:
  %l4 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t6, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i32 %t8, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l4, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/generic:Binding"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i32
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l37 = alloca %"compiler/generic:Binding"
  %l39 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i64
  %l70 = alloca i32
  %l71 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %t5)
  store i32 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i32, ptr %l15, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t10)
  store i64 %t12, ptr %l17
  br label %bb2
bb2:
  %t13 = load i64, ptr %l17, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l21
  br label %bb3
bb3:
  %t22 = load i64, ptr %l21, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l24, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l3, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l29
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l24, !tbaa !29
  %t40 = load i32, ptr %l29, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t39, i32 %t40)
  store { i64, ptr } %t41, ptr %l30
  br label %bb5
bb5:
  %t42 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t42, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = icmp eq i64 %t45, 0
  br i1 %t47, label %bb6, label %bb7
bb6:
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t49, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t51, i64 %t52)
  store %"compiler/generic:Binding" %t55, ptr %l37
  br label %bb9
bb9:
  %t56 = load %"compiler/generic:Binding", ptr %l37
  store %"compiler/generic:Binding" %t56, ptr %l7
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t58, ptr %l39, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 0
  %t62 = load i32, ptr %t61, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t57, i32 %t62, i32 %a2, ptr %l7, i1 false, i1 true)
  br label %bb10
bb10:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t71, ptr %l7)
  br label %bb11
bb11:
  %t74 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  store { i64, ptr } %t75, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  %t81 = load i64, ptr %l9, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb13, label %bb14
bb13:
  br label %bb20
bb14:
  br label %bb15
bb15:
  %t89 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t89, ptr %l53, !tbaa !27
  %t90 = load i64, ptr %l9, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t98 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t101 = icmp eq i32 %t95, %t98
  br i1 %t101, label %bb16, label %bb17
bb16:
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t103, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l9, !tbaa !24
  br label %bb12
bb20:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l63, !tbaa !29
  %t113 = load i32, ptr %l3, !tbaa !23
  store i32 %t113, ptr %l64, !tbaa !23
  %t114 = load i64, ptr %l4, !tbaa !24
  store i64 %t114, ptr %l65, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t120, { i64, ptr } %t122)
  store i32 %t125, ptr %l70
  br label %bb21
bb21:
  %t126 = load ptr, ptr %l63, !tbaa !29
  %t127 = load i32, ptr %l64, !tbaa !23
  %t128 = load i64, ptr %l65, !tbaa !24
  %t129 = load i32, ptr %l70, !tbaa !23
  %t130 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t126, i32 %t127, i64 %t128, i32 %t129)
  store i32 %t130, ptr %l71
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t131 = load i32, ptr %l71, !tbaa !23
  store i32 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportedTypeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/load:Import"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/names:Entry"
  %l8 = alloca { i64, ptr }
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l25 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca %"compiler/load:Import"
  %l43 = alloca ptr
  %l46 = alloca i64
  %l48 = alloca i64
  %l53 = alloca %"compiler/names:Entry"
  %l57 = alloca i1
  %l60 = alloca { i64, ptr }
  %l62 = alloca i1
  %l68 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l74 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @compiler_2fload_2ePublic(ptr %v1, { i64, ptr } %t1)
  store i1 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i1, ptr %l11, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t7, ptr %l14, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l16, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/load:Loader", ptr %t29, i32 0, i32 10
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t32)
  store ptr %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t41 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t39, i64 %t38)
  store ptr %t41, ptr %l25
  br label %bb6
bb6:
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t44 = getelementptr %"compiler/load:Module", ptr %t42, i32 0, i32 11
  store ptr %t44, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l3, !tbaa !24
  store i64 %t46, ptr %l28, !tbaa !24
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t47)
  store i64 %t49, ptr %l30
  br label %bb8
bb8:
  %t50 = load i64, ptr %l28, !tbaa !24
  %t51 = load i64, ptr %l30, !tbaa !24
  %t52 = icmp slt i64 %t50, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb9, label %bb10
bb9:
  br label %bb47
bb10:
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t57 = load i64, ptr %l3, !tbaa !24
  %t60 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store %"compiler/load:Import" %t60, ptr %l35
  br label %bb12
bb12:
  %t61 = load %"compiler/load:Import", ptr %l35
  store %"compiler/load:Import" %t61, ptr %l4
  %t62 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 5
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  br label %bb46
bb14:
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/names:Resolver", ptr %t73, i32 0, i32 1
  %t76 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 5
  %t77 = load i64, ptr %t76, !tbaa !24
  %t80 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t75, i64 %t77)
  store ptr %t80, ptr %l43
  br label %bb16
bb16:
  %t81 = load ptr, ptr %l43, !tbaa !29
  %t83 = getelementptr %"compiler/names:Table", ptr %t81, i32 0, i32 0
  store ptr %t83, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t85 = load i64, ptr %l6, !tbaa !24
  store i64 %t85, ptr %l46, !tbaa !24
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l48
  br label %bb18
bb18:
  %t89 = load i64, ptr %l46, !tbaa !24
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = icmp slt i64 %t89, %t90
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb19, label %bb20
bb19:
  br label %bb45
bb20:
  br label %bb21
bb21:
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t96 = load i64, ptr %l6, !tbaa !24
  %t99 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t95, i64 %t96)
  store %"compiler/names:Entry" %t99, ptr %l53
  br label %bb22
bb22:
  %t100 = load %"compiler/names:Entry", ptr %l53
  store %"compiler/names:Entry" %t100, ptr %l7
  %t101 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 2
  %t102 = load i32, ptr %t101, !range !{i32 0, i32 9}
  %t104 = trunc i64 4 to i32
  %t105 = icmp eq i32 %t102, %t104
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb27
bb24:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 0
  %t111 = load i32, ptr %t110, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t109, i32 %t111)
  store { i64, ptr } %t114, ptr %l60
  br label %bb25
bb25:
  %t115 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t116, { i64, ptr } %t115)
  store i1 %t118, ptr %l62
  br label %bb26
bb26:
  %t119 = load i1, ptr %l62, !tbaa !21
  %t120 = xor i1 %t119, true
  store i1 %t120, ptr %l57, !tbaa !21
  br label %bb27
bb27:
  %t122 = load i1, ptr %l57, !tbaa !21
  br i1 %t122, label %bb28, label %bb29
bb28:
  br label %bb44
bb29:
  br label %bb30
bb30:
  %t123 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l8, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t130 = icmp eq i64 %t128, 0
  br i1 %t130, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  %t132 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 3
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s8, { i64, ptr } %t133, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) })
  %t136 = extractvalue { i32, i64 } %t135, 1
  %t137 = extractvalue { i32, i64 } %t135, 0
  store i32 %t137, ptr %l71
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb34, label %ok.139, !prof !99
ok.139:
  store i64 %t136, ptr %l70
  br label %bb33
bb32:
  br label %bb43
bb33:
  %t140 = load i64, ptr %l70, !tbaa !24
  store i64 %t140, ptr %l68, !tbaa !24
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l68, !tbaa !24
  br label %bb36
bb36:
  %t141 = load i64, ptr %l68, !tbaa !24
  %t142 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 3
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l72, !tbaa !27
  %t146 = add i64 %t141, 1
  store i64 %t146, ptr %l74, !tbaa !24
  %t147 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 3
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t148, 0
  store i64 %t151, ptr %l77, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  store i64 %t153, ptr %l78, !tbaa !24
  %t154 = load i64, ptr %l74, !tbaa !24
  %t155 = icmp sge i64 %t154, 0
  br i1 %t155, label %bb37, label %bb38
bb37:
  %t157 = load i64, ptr %l74, !tbaa !24
  %t158 = load i64, ptr %l77, !tbaa !24
  %t159 = icmp sle i64 %t157, %t158
  br i1 %t159, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_8fffa2dcb89c09a5_7d27f2eeb87e61a1)
  unreachable
bb39:
  %t161 = load i64, ptr %l77, !tbaa !24
  %t162 = load i64, ptr %l78, !tbaa !24
  %t163 = icmp sle i64 %t161, %t162
  br i1 %t163, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_8fffa2dcb89c09a5_7d27f2eeb87e61a1)
  unreachable
bb41:
  %t165 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = load i64, ptr %l74, !tbaa !24
  %t168 = load i64, ptr %l77, !tbaa !24
  %t169 = getelementptr i8, ptr %t166, i64 %t167
  %t170 = sub i64 %t168, %t167
  %t171 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t169, 1
  store { i64, ptr } %t172, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8fffa2dcb89c09a5_7d27f2eeb87e61a1)
  unreachable
bb43:
  %t174 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t174, 1
  %t178 = extractvalue { i64, ptr } %t174, 0
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t183 = extractvalue { i64, ptr } %t175, 1
  %t184 = extractvalue { i64, ptr } %t175, 0
  %t185 = add i64 %t181, %t184
  %t186 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t177, i64 %t178)
  %t187 = getelementptr i8, ptr %t186, i64 %t178
  call void @olang_textcopy(ptr %t187, ptr %t179, i64 %t180)
  %t188 = getelementptr i8, ptr %t187, i64 %t180
  call void @olang_textcopy(ptr %t188, ptr %t183, i64 %t184)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t186, 1
  store { i64, ptr } %t190, ptr %rv
  br label %ret
bb44:
  %t192 = load i64, ptr %l6, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l6, !tbaa !24
  br label %bb17
bb45:
  br label %bb46
bb46:
  %t196 = load i64, ptr %l3, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l3, !tbaa !24
  br label %bb7
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l90, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t200, ptr %l91, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 0
  store i64 %t202, ptr %l92, !tbaa !24
  %t203 = load i64, ptr %l92, !tbaa !24
  %t204 = mul i64 %t203, 1
  %t205 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t204)
  %t206 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  store { i64, ptr } %t207, ptr %l93, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = load i64, ptr %l92, !tbaa !24
  %t213 = mul i64 %t212, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t209, ptr %t211, i64 %t213, i1 false)
  %t214 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t214, ptr %l91, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t215, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/msgs:Msg"
  %l21 = alloca i64
  %l22 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/msgs:Msg"
  %l27 = alloca i64
  %l32 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/msgs:Msg"
  %l36 = alloca i64
  %l41 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %l55 = alloca i32
  %l57 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca i1
  %l64 = alloca i32
  %l69 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1)
  store i32 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i32, ptr %l8, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t13 = load ptr, ptr %l12, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb4, label %bb5
bb3:
  br label %bb20
bb4:
  %t16 = load ptr, ptr %l12, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 30}
  %t19 = icmp eq i64 %t17, 27
  store i1 %t19, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l13, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", ptr }, ptr %t23, i32 0, i32 0
  %t25 = load %"compiler/source:Span", ptr %t24
  store %"compiler/source:Span" %t25, ptr %l5
  br label %bb8
bb7:
  br label %bb11
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t28, ptr %l19
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %s2, ptr %s2, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t29, ptr %l20
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l19
  %t32 = load %"compiler/msgs:Msg", ptr %l20
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t30, %"compiler/source:Span" %t31, %"compiler/msgs:Msg" %t32)
  store i64 %t33, ptr %l21
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb18
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store %"compiler/source:Span" %t39, ptr %l25
  br label %bb15
bb15:
  %t40 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %s3, ptr %s3, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t40, ptr %l26
  br label %bb16
bb16:
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l25
  %t43 = load %"compiler/msgs:Msg", ptr %l26
  %t44 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t41, %"compiler/source:Span" %t42, %"compiler/msgs:Msg" %t43)
  store i64 %t44, ptr %l27
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_343b32e44524bf9e_67b59a3d30ab5452)
  unreachable
bb19:
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t45, ptr %rv
  br label %ret
bb20:
  %t47 = load i32, ptr %l4, !tbaa !23
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t51 = icmp eq i32 %t47, %t48
  br i1 %t51, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t54)
  store %"compiler/source:Span" %t56, ptr %l34
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t57 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %s4)
  store %"compiler/msgs:Msg" %t57, ptr %l35
  br label %bb24
bb24:
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l34
  %t60 = load %"compiler/msgs:Msg", ptr %l35
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t58, %"compiler/source:Span" %t59, %"compiler/msgs:Msg" %t60)
  store i64 %t61, ptr %l36
  br label %bb25
bb25:
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  store i32 %t62, ptr %rv
  br label %ret
bb26:
  %t64 = load i32, ptr %l4, !tbaa !23
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t68 = icmp eq i32 %t64, %t65
  br i1 %t68, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l41, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t71)
  store %"compiler/source:Span" %t73, ptr %l43
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t74 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotInferable(ptr %s5)
  store %"compiler/msgs:Msg" %t74, ptr %l44
  br label %bb30
bb30:
  %t75 = load ptr, ptr %l41, !tbaa !29
  %t76 = load %"compiler/source:Span", ptr %l43
  %t77 = load %"compiler/msgs:Msg", ptr %l44
  %t78 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t75, %"compiler/source:Span" %t76, %"compiler/msgs:Msg" %t77)
  store i64 %t78, ptr %l45
  br label %bb31
bb31:
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  store i32 %t79, ptr %rv
  br label %ret
bb32:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l4, !tbaa !23
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t81, i32 %t82)
  store i1 %t85, ptr %l49
  br label %bb33
bb33:
  %t86 = load i1, ptr %l49, !tbaa !21
  br i1 %t86, label %bb34, label %bb35
bb34:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l4, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l55
  br label %bb36
bb35:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb38
bb36:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t97)
  store i32 %t99, ptr %l57
  br label %bb37
bb37:
  %t100 = load i32, ptr %l55, !tbaa !23
  %t101 = load i32, ptr %l57, !tbaa !23
  %t102 = icmp eq i32 %t100, %t101
  store i1 %t102, ptr %l50, !tbaa !21
  br label %bb38
bb38:
  %t104 = load i1, ptr %l50, !tbaa !21
  br i1 %t104, label %bb39, label %bb40
bb39:
  %t105 = load ptr, ptr %l2, !tbaa !29
  store ptr %t105, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t106 = load ptr, ptr %l59, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb41, label %bb42
bb40:
  br label %bb53
bb41:
  %t109 = load ptr, ptr %l59, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 18}
  %t112 = icmp eq i64 %t110, 1
  store i1 %t112, ptr %l60, !tbaa !21
  br label %bb42
bb42:
  %t113 = load i1, ptr %l60, !tbaa !21
  br i1 %t113, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t114)
  store i32 %t116, ptr %l64
  br label %bb46
bb46:
  %t117 = load i32, ptr %l64, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_9c9a337b92d12a1f_5567ba002875d853)
  unreachable
bb52:
  br label %bb53
bb53:
  %t120 = xor i1 %a3, true
  br i1 %t120, label %bb54, label %bb55
bb54:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l4, !tbaa !23
  %t126 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l69
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t127 = load i32, ptr %l69, !tbaa !23
  store i32 %t127, ptr %rv
  br label %ret
bb57:
  %t128 = load i32, ptr %l4, !tbaa !23
  store i32 %t128, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l15
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l11, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisGlobalBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l6 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  %t15 = extractvalue { i64, [2 x i64] } %t11, 0
  %t16 = icmp eq i64 %t15, 6
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4bb92e4e6aa9fa92_ae49a41c9a1a92ee)
  unreachable
bb10:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t13 = trunc i64 20 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elandedNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l20 = alloca %"compiler/typed:Local"
  %l22 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, [3 x i64] }
  %l30 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca %"compiler/msgs:Msg"
  %l37 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca { i64, [3 x i64] }
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l53 = alloca %"compiler/typed:Local"
  %l55 = alloca { i64, ptr }
  %l56 = alloca %"compiler/msgs:Msg"
  %l57 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t19 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:landing", ptr %t5, i32 0, i32 2
  %t8 = getelementptr %"compiler/source:Span", ptr %t7, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/check:landing", ptr %t12, i32 0, i32 2
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 0
  store i64 3, ptr %t20
  %t22 = insertvalue { i64, i64, i64 } undef, i64 %t4, 0
  %t24 = insertvalue { i64, i64, i64 } %t22, i64 %t11, 1
  %t26 = insertvalue { i64, i64, i64 } %t24, i64 %t18, 2
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 1
  store { i64, i64, i64 } %t26, ptr %t27
  %t28 = load { i64, [3 x i64] }, ptr %t19
  store { i64, [3 x i64] } %t28, ptr %l4
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l15, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Body", ptr %t31, i32 0, i32 7
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/check:landing", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  %t40 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t33, i64 %t37)
  store %"compiler/typed:Local" %t40, ptr %l20
  br label %bb1
bb1:
  %t41 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load ptr, ptr %l15, !tbaa !29
  %t45 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t43, i32 %t42)
  store { i64, ptr } %t45, ptr %l22
  br label %bb2
bb2:
  %t46 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t46, ptr %l5, !tbaa !27
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = icmp slt i64 %t47, 0
  br i1 %t49, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/load:Loader", ptr %t57, i32 0, i32 4
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l28, !tbaa !29
  %t61 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t61, ptr %l29
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t62, ptr %l30, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/check:landing", ptr %t64, i32 0, i32 3
  %t67 = load i32, ptr %t66, !tbaa !23
  %t70 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t63, i32 %t67)
  store { i64, ptr } %t70, ptr %l34
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t71 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t78 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t80 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUniqueLentHere(ptr %v0, ptr %s1, ptr %s1, { i64, ptr } %t78, { i64, ptr } %t77)
  store %"compiler/msgs:Msg" %t80, ptr %l36
  br label %bb6
bb6:
  %t81 = load ptr, ptr %l28, !tbaa !29
  %t82 = load { i64, [3 x i64] }, ptr %l29
  %t83 = load %"compiler/msgs:Msg", ptr %l36
  %t84 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t81, { i64, [3 x i64] } %t82, %"compiler/msgs:Msg" %t83)
  store i64 %t84, ptr %l37
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/load:Loader", ptr %t91, i32 0, i32 4
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l41, !tbaa !29
  %t95 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t95, ptr %l42
  %t96 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t96, ptr %l43, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/check:landing", ptr %t98, i32 0, i32 3
  %t101 = load i32, ptr %t100, !tbaa !23
  %t104 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t97, i32 %t101)
  store { i64, ptr } %t104, ptr %l47
  br label %bb9
bb9:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l48, !tbaa !27
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l49, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Body", ptr %t113, i32 0, i32 7
  %t116 = load i64, ptr %l3, !tbaa !24
  %t119 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t115, i64 %t116)
  store %"compiler/typed:Local" %t119, ptr %l53
  br label %bb10
bb10:
  %t120 = getelementptr %"compiler/typed:Local", ptr %l53, i32 0, i32 0
  %t121 = load i32, ptr %t120, !tbaa !23
  %t122 = load ptr, ptr %l49, !tbaa !29
  %t124 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t122, i32 %t121)
  store { i64, ptr } %t124, ptr %l55
  br label %bb11
bb11:
  %t125 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t128 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUniqueAlias(ptr %v0, ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t125, { i64, ptr } %t126, { i64, ptr } %t127)
  store %"compiler/msgs:Msg" %t128, ptr %l56
  br label %bb12
bb12:
  %t129 = load ptr, ptr %l41, !tbaa !29
  %t130 = load { i64, [3 x i64] }, ptr %l42
  %t131 = load %"compiler/msgs:Msg", ptr %l56
  %t132 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s0, ptr %t129, { i64, [3 x i64] } %t130, %"compiler/msgs:Msg" %t131)
  store i64 %t132, ptr %l57
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l42 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load %"compiler/source:Span", ptr %l1
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = sub i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t23)
  store i1 %t25, ptr %l16
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb13
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb7:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l18, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = sub i64 %t28, 1
  %t32 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t35)
  store i1 %t37, ptr %l22
  br label %bb8
bb8:
  %t38 = load i1, ptr %l22, !tbaa !21
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l24, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t41, 1
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t43
  %t48 = load i8, ptr %t47, !tbaa !32
  %t50 = icmp eq i8 %t48, 95
  store i1 %t50, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l23, !tbaa !21
  store i1 %t52, ptr %l11, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l11, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = sub i64 %t56, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t66 = icmp eq i64 %t60, %t63
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t68, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t70 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = load i64, ptr %l3, !tbaa !24
  %t74 = trunc i64 %t72 to i32
  %t77 = add i32 %t71, %t74
  %t78 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  %t82 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t77, i32 %t79)
  store %"compiler/source:Span" %t82, ptr %l42
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t83 = load %"compiler/source:Span", ptr %l42
  store %"compiler/source:Span" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/typed:Item"
  %l18 = alloca i32
  %l21 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i64
  %l33 = alloca i64
  %l37 = alloca i64
  %l39 = alloca i64
  %l44 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l68 = alloca i64
  %l82 = alloca i32
  %l89 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l18
  br label %bb1
bb1:
  %t11 = load i32, ptr %l18, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %t12, i32 %t13)
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t17 = load i64, ptr %l21, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sge i64 %t18, 64
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = sub i64 0, 1
  store i64 %t22, ptr %l24, !tbaa !65
  br label %bb5
bb4:
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l26, !tbaa !24
  %t25 = load i64, ptr %l26, !tbaa !24
  %t26 = load i64, ptr %l26, !tbaa !24
  %t27 = shl i64 1, %t26
  %t29 = sub i64 %t27, 1
  store i64 %t29, ptr %l24, !tbaa !65
  br label %bb5
bb5:
  %t31 = load i64, ptr %l24, !tbaa !65
  store i64 %t31, ptr %l5, !tbaa !65
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t37, i32 %t38)
  store i64 %t41, ptr %l33
  br label %bb6
bb6:
  %t42 = load i64, ptr %l5, !tbaa !65
  %t43 = load i64, ptr %l33, !tbaa !65
  %t45 = and i64 %t43, %t42
  store i64 %t45, ptr %l6, !tbaa !65
  store ptr %a2, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t49 = load i64, ptr %l8, !tbaa !24
  store i64 %t49, ptr %l37, !tbaa !24
  %t50 = load ptr, ptr %l7, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eLen__H4e51b5ca7b68af485b8486164a690a5f(ptr %v1, ptr %t50)
  store i64 %t52, ptr %l39
  br label %bb8
bb8:
  %t53 = load i64, ptr %l37, !tbaa !24
  %t54 = load i64, ptr %l39, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb9, label %bb10
bb9:
  br label %bb32
bb10:
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l7, !tbaa !29
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v1, ptr %v1, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l44
  br label %bb12
bb12:
  %t64 = load ptr, ptr %l44, !tbaa !29
  store ptr %t64, ptr %l9, !tbaa !29
  %t65 = load ptr, ptr %l9, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Clause", ptr %t65, i32 0, i32 2
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t70, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t72 = load ptr, ptr %l9, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Clause", ptr %t72, i32 0, i32 1
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  store { i64, ptr } %t75, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l12, !tbaa !24
  br label %bb16
bb16:
  %t81 = load i64, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l12, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb17, label %bb18
bb17:
  br label %bb30
bb18:
  br label %bb19
bb19:
  %t89 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t89, ptr %l56, !tbaa !27
  %t90 = load i64, ptr %l11, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr %"compiler/typed:Item", ptr %t93, i64 %t90
  %t95 = load %"compiler/typed:Item", ptr %t94
  store %"compiler/typed:Item" %t95, ptr %l13
  %t97 = getelementptr %"compiler/typed:Item", ptr %l13, i32 0, i32 0
  %t98 = load i32, ptr %t97, !tbaa !23
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = icmp eq i32 %t98, %t99
  br i1 %t102, label %bb20, label %bb21
bb20:
  %t104 = getelementptr %"compiler/typed:Item", ptr %l13, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t107 = icmp slt i64 %t105, 0
  br i1 %t107, label %bb22, label %bb23
bb21:
  br label %bb28
bb22:
  %t109 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t109, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t111 = getelementptr %"compiler/typed:Item", ptr %l13, i32 0, i32 1
  %t112 = load i64, ptr %t111, !tbaa !24
  %t114 = icmp slt i64 %t112, 64
  br i1 %t114, label %bb25, label %bb26
bb25:
  %t116 = load i64, ptr %l6, !tbaa !65
  %t117 = getelementptr %"compiler/typed:Item", ptr %l13, i32 0, i32 1
  %t118 = load i64, ptr %t117, !tbaa !24
  store i64 %t118, ptr %l68, !tbaa !24
  %t119 = load i64, ptr %l68, !tbaa !24
  %t120 = load i64, ptr %l68, !tbaa !24
  %t121 = shl i64 1, %t120
  %t123 = xor i64 %t121, -1
  %t126 = and i64 %t116, %t123
  store i64 %t126, ptr %l6, !tbaa !65
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t128 = load i64, ptr %l11, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l11, !tbaa !24
  br label %bb16
bb30:
  br label %bb31
bb31:
  %t132 = load i64, ptr %l8, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l8, !tbaa !24
  br label %bb7
bb32:
  %t136 = load i64, ptr %l6, !tbaa !65
  %t138 = icmp eq i64 %t136, 0
  br i1 %t138, label %bb33, label %bb34
bb33:
  %t140 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t140, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t142 = load i64, ptr %l6, !tbaa !65
  %t143 = load i64, ptr %l5, !tbaa !65
  %t146 = icmp eq i64 %t142, %t143
  br i1 %t146, label %bb36, label %bb37
bb36:
  %t148 = load i32, ptr %l3, !tbaa !23
  store i32 %t148, ptr %l82, !tbaa !23
  br label %bb39
bb37:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  %t156 = load i32, ptr %l3, !tbaa !23
  %t157 = load i64, ptr %l6, !tbaa !65
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t155, i32 %t156, i64 %t157)
  store i32 %t161, ptr %l89
  br label %bb38
bb38:
  %t162 = load i32, ptr %l89, !tbaa !23
  store i32 %t162, ptr %l82, !tbaa !23
  br label %bb39
bb39:
  %t163 = load i32, ptr %l82, !tbaa !23
  store i32 %t163, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l21 = alloca %"compiler/typed:Local"
  %l22 = alloca i32
  %l26 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i32
  %l41 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l50 = alloca i32
  %l53 = alloca i1
  %l57 = alloca %"compiler/generic:Desc"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t5)
  store ptr %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = load i32, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 7
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = trunc i64 %t14 to i32
  %t26 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t8, %"compiler/source:Span" %a2, i32 %t10, i32 %t16, i32 %a4, { i64, [1 x i64] } %a5)
  store %"compiler/typed:Local" %t26, ptr %l21
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l11, !tbaa !29
  %t28 = load %"compiler/typed:Local", ptr %l21
  %t29 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t27, %"compiler/typed:Local" %t28)
  store i32 %t29, ptr %l22
  br label %bb4
bb4:
  %t30 = load i32, ptr %l22, !tbaa !23
  %t31 = sext i32 %t30 to i64
  store i64 %t31, ptr %l7, !tbaa !24
  %t33 = load i32, ptr %l1, !tbaa !23
  %t35 = icmp ne i32 %t33, 0
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l29
  br label %bb7
bb6:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb9
bb7:
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t42, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t43, ptr %l30
  br label %bb8
bb8:
  %t44 = load i1, ptr %l30, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t47 = load i1, ptr %l26, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t48, i32 0, i32 9
  store ptr %t50, ptr %l33, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  store i32 %t51, ptr %l34, !tbaa !23
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 8
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t54, i32 %t55)
  %t59 = extractvalue { i32, i64 } %t58, 1
  %t60 = extractvalue { i32, i64 } %t58, 0
  store i32 %t60, ptr %l40
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb13, label %ok.62, !prof !99
ok.62:
  store i64 %t59, ptr %l39
  br label %bb12
bb11:
  br label %bb28
bb12:
  %t63 = load i64, ptr %l39, !tbaa !24
  store i64 %t63, ptr %l35, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i32, ptr %l34, !tbaa !23
  %t65 = load i64, ptr %l35, !tbaa !24
  %t66 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s1, i32 %t64, i64 %t65)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t66, ptr %l41
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l41
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %t67, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t68)
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/check:frame", ptr %t69, i32 0, i32 8
  %t72 = load i32, ptr %l1, !tbaa !23
  %t73 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t71, i32 %t72, i64 %t73)
  br label %bb18
bb18:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l3, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l50
  br label %bb19
bb19:
  %t87 = load i32, ptr %l50, !range !{i32 0, i32 33}
  %t89 = trunc i64 18 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb20, label %bb21
bb20:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load i32, ptr %l3, !tbaa !23
  %t99 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t95, i32 %t96)
  store %"compiler/generic:Desc" %t99, ptr %l57
  br label %bb22
bb21:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  %t100 = getelementptr %"compiler/generic:Desc", ptr %l57, i32 0, i32 0
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescNone, !tbaa !24
  %t105 = icmp ne i64 %t101, %t102
  store i1 %t105, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t107 = load i1, ptr %l53, !tbaa !21
  br i1 %t107, label %bb24, label %bb25
bb24:
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/check:frame", ptr %t108, i32 0, i32 4
  %t111 = getelementptr %"compiler/generic:Context", ptr %t110, i32 0, i32 3
  %t112 = load i32, ptr %l1, !tbaa !23
  %t113 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %t111, i32 %t112, i32 %t113)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s1)
  br label %bb28
bb28:
  %t117 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t117, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalCase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:Local"
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l21 = alloca ptr
  %l25 = alloca %"compiler/typed:Local"
  %l29 = alloca i1
  %l33 = alloca i1
  %l40 = alloca i32
  %l43 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca i64
  %l53 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb31
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t27 = insertvalue { i64, i64 } %t26, i64 -1, 1
  store { i64, i64 } %t27, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l21
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 7
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t34, i64 %t35)
  store %"compiler/typed:Local" %t38, ptr %l25
  br label %bb11
bb11:
  %t39 = load %"compiler/typed:Local", ptr %l25
  store %"compiler/typed:Local" %t39, ptr %l5
  %t40 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t41 = load i32, ptr %t40, !range !{i32 0, i32 7}
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t49 = load i32, ptr %t48, !range !{i32 0, i32 7}
  %t51 = trunc i64 1 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  store i1 %t54, ptr %l29, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l29, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t58 = load i32, ptr %t57, !range !{i32 0, i32 7}
  %t60 = trunc i64 4 to i32
  %t61 = icmp eq i32 %t58, %t60
  %t63 = xor i1 %t61, true
  store i1 %t63, ptr %l33, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t66 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t67 = insertvalue { i64, i64 } %t66, i64 -1, 1
  store { i64, i64 } %t67, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t71 = load i32, ptr %t70, !tbaa !23
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t69, i32 %t71)
  store i32 %t74, ptr %l40
  br label %bb21
bb21:
  %t75 = load i32, ptr %l40, !tbaa !23
  store i32 %t75, ptr %l6, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l6, !tbaa !23
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l43
  br label %bb22
bb22:
  %t81 = load i1, ptr %l43, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb23, label %bb24
bb23:
  %t84 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t85 = insertvalue { i64, i64 } %t84, i64 -1, 1
  store { i64, i64 } %t85, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l46, !tbaa !29
  %t90 = call ptr @compiler_2fcheck_2ecasePath(ptr %v2, ptr %v2, ptr %a2)
  store ptr %t90, ptr %l48
  br label %bb26
bb26:
  %t91 = load i32, ptr %l6, !tbaa !23
  %t92 = load ptr, ptr %l46, !tbaa !29
  %t93 = load ptr, ptr %l48, !tbaa !29
  %t95 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v2, ptr %t92, ptr %t93, i32 %t91)
  store i64 %t95, ptr %l50
  br label %bb27
bb27:
  %t96 = load i64, ptr %l50, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t99 = icmp sge i64 %t97, 0
  br i1 %t99, label %bb28, label %bb29
bb28:
  %t101 = load i64, ptr %l4, !tbaa !24
  store i64 %t101, ptr %l53, !tbaa !24
  br label %bb30
bb29:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb30
bb30:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t104 = load i64, ptr %l53, !tbaa !24
  %t105 = insertvalue { i64, i64 } undef, i64 %t104, 0
  %t107 = insertvalue { i64, i64 } %t105, i64 %t103, 1
  store { i64, i64 } %t107, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t109 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t110 = insertvalue { i64, i64 } %t109, i64 -1, 1
  store { i64, i64 } %t110, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_1a7153eaacfdc8_b1c3cf4a1728a65c)
  unreachable
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l22 = alloca i64
  %l26 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l47 = alloca ptr
  %l52 = alloca i64
  %l57 = alloca i64
  %l63 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l79 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l89 = alloca ptr
  %s2 = alloca %olang.scope
  %t77 = alloca { i64, [3 x i64] }, align 8
  %t157 = alloca { i64, [3 x i64] }, align 8
  %t183 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrMatch(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store i1 %t12, ptr %l14
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i1, ptr %l14, !tbaa !21
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatch(ptr %v0, ptr %v1, ptr %t15, %"compiler/source:Span" %t16, ptr %t17)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %ret
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Match", ptr %t21, i32 0, i32 2
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i64 %t30, ptr %l22
  br label %bb11
bb10:
  br label %bb23
bb11:
  %t31 = load i64, ptr %l22, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Match", ptr %t36, i32 0, i32 3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l26, !tbaa !27
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l4, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindCase(ptr %v0, ptr %s2, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l30
  br label %bb15
bb15:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l5
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Case", ptr %t51, i32 0, i32 4
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l35, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l36, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t62, ptr %l37
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Case", ptr %t64, i32 0, i32 4
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Case", ptr %t68, i32 0, i32 0
  %t71 = load %"compiler/source:Span", ptr %t70
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v0, ptr %t63, { i64, ptr } %t67, i32 1, %"compiler/source:Span" %t71)
  store ptr %t76, ptr %l44
  br label %bb18
bb17:
  br label %bb21
bb18:
  store { i64, [3 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 0
  store i64 11, ptr %t78
  %t79 = load %"compiler/source:Span", ptr %l37
  %t80 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t79, 0
  %t81 = load ptr, ptr %l44, !tbaa !29
  %t82 = insertvalue { %"compiler/source:Span", ptr } %t80, ptr %t81, 1
  %t83 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t82, ptr %t83
  %t84 = load { i64, [3 x i64] }, ptr %t77
  %t86 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t84, ptr %t86
  %t87 = load ptr, ptr %l36, !tbaa !29
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecided(ptr %v0, ptr %v0, ptr %v0, ptr %t87, ptr %t86)
  store ptr %t89, ptr %l47
  br label %bb19
bb19:
  %t90 = load ptr, ptr %l35, !tbaa !29
  %t91 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t90, ptr %t91)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunbindCase(ptr %v0, ptr %s2, ptr %t92, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb23:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMatch(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i64 %t100, ptr %l52
  br label %bb24
bb24:
  %t101 = load i64, ptr %l52, !tbaa !24
  store i64 %t101, ptr %l6, !tbaa !24
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = icmp eq i64 %t102, -2
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t110 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %t106, ptr %t107)
  store i64 %t110, ptr %l57
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t111 = load i64, ptr %l57, !tbaa !24
  store i64 %t111, ptr %l6, !tbaa !24
  br label %bb28
bb28:
  %t112 = load i64, ptr %l6, !tbaa !24
  %t114 = icmp ne i64 %t112, -2
  br i1 %t114, label %bb29, label %bb30
bb29:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb31, label %bb32
bb30:
  br label %bb40
bb31:
  br label %ret
bb32:
  br label %bb33
bb33:
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/ast:Match", ptr %t120, i32 0, i32 3
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l63, !tbaa !27
  %t124 = load i64, ptr %l6, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr ptr, ptr %t127, i64 %t124
  %t129 = load ptr, ptr %t128, !tbaa !39
  store ptr %t129, ptr %l7, !tbaa !29
  %t131 = load ptr, ptr %l7, !tbaa !29
  %t133 = getelementptr %"compiler/ast:Case", ptr %t131, i32 0, i32 4
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb34, label %bb35
bb34:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l70, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l71, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t142, ptr %l72
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l7, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 4
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t148 = load ptr, ptr %l7, !tbaa !29
  %t150 = getelementptr %"compiler/ast:Case", ptr %t148, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  %t156 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v0, ptr %t143, { i64, ptr } %t147, i32 1, %"compiler/source:Span" %t151)
  store ptr %t156, ptr %l79
  br label %bb36
bb35:
  br label %bb39
bb36:
  store { i64, [3 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [3 x i64] }, ptr %t157, i32 0, i32 0
  store i64 11, ptr %t158
  %t159 = load %"compiler/source:Span", ptr %l72
  %t160 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t159, 0
  %t161 = load ptr, ptr %l79, !tbaa !29
  %t162 = insertvalue { %"compiler/source:Span", ptr } %t160, ptr %t161, 1
  %t163 = getelementptr { i64, [3 x i64] }, ptr %t157, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t162, ptr %t163
  %t164 = load { i64, [3 x i64] }, ptr %t157
  %t166 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t164, ptr %t166
  %t167 = load ptr, ptr %l71, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecided(ptr %v0, ptr %v0, ptr %v0, ptr %t167, ptr %t166)
  store ptr %t169, ptr %l82
  br label %bb37
bb37:
  %t170 = load ptr, ptr %l70, !tbaa !29
  %t171 = load ptr, ptr %l82, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t170, ptr %t171)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %ret
bb40:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l83, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t173, ptr %l84
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l1
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t177 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t174, %"compiler/source:Span" %t175, ptr %t176, i1 false, i32 %t177)
  store ptr %t182, ptr %l89
  br label %bb41
bb41:
  store { i64, [3 x i64] } zeroinitializer, ptr %t183
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t183, i32 0, i32 0
  store i64 2, ptr %t184
  %t185 = load %"compiler/source:Span", ptr %l84
  %t186 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t185, 0
  %t187 = load ptr, ptr %l89, !tbaa !29
  %t188 = insertvalue { %"compiler/source:Span", ptr } %t186, ptr %t187, 1
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t183, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t188, ptr %t189
  %t190 = load { i64, [3 x i64] }, ptr %t183
  %t192 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t190, ptr %t192
  %t193 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t193, ptr %t192)
  br label %bb42
bb42:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca { i64, ptr }
  %l32 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i32
  %l50 = alloca ptr
  %l52 = alloca i1
  %l55 = alloca i64
  %l57 = alloca i1
  %l60 = alloca i1
  %l63 = alloca { i64, ptr }
  %l66 = alloca i64
  %l68 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca i32
  %l75 = alloca i64
  %l77 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i1
  %l82 = alloca i1
  %l89 = alloca ptr
  %l94 = alloca ptr
  %l97 = alloca i32
  %l99 = alloca i64
  %l103 = alloca ptr
  %l106 = alloca i32
  %l108 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i1
  %l119 = alloca { i64, ptr }
  %l120 = alloca i1
  %l121 = alloca i1
  %l122 = alloca ptr
  %l125 = alloca i32
  %l126 = alloca i1
  %l133 = alloca ptr
  %l136 = alloca i1
  %l139 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca i32
  %l146 = alloca ptr
  %l147 = alloca { i64, ptr }
  %l149 = alloca %"compiler/source:Span"
  %l152 = alloca { i64, ptr }
  %l154 = alloca %"compiler/msgs:Msg"
  %l155 = alloca i64
  %l160 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l179 = alloca i1
  %l181 = alloca i1
  %l185 = alloca i64
  %l187 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca %"compiler/source:Span"
  %l195 = alloca { i64, ptr }
  %l197 = alloca %"compiler/msgs:Msg"
  %l198 = alloca i64
  %l199 = alloca ptr
  %l200 = alloca %"compiler/source:Span"
  %l201 = alloca %"compiler/source:Span"
  %l202 = alloca i64
  %l204 = alloca ptr
  %l205 = alloca { i64, ptr }
  %l210 = alloca ptr
  %l213 = alloca { i64, ptr }
  %l215 = alloca i1
  %l216 = alloca i1
  %l220 = alloca i1
  %l222 = alloca i1
  %l223 = alloca i1
  %l227 = alloca i1
  %l229 = alloca ptr
  %l231 = alloca ptr
  %l234 = alloca i1
  %l237 = alloca ptr
  %l240 = alloca i32
  %l241 = alloca i32
  %l244 = alloca i1
  %l254 = alloca ptr
  %l256 = alloca ptr
  %l259 = alloca i32
  %l261 = alloca i64
  %l265 = alloca ptr
  %l268 = alloca i32
  %l270 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l272 = alloca i64
  %l274 = alloca ptr
  %l275 = alloca %"compiler/source:Span"
  %l276 = alloca ptr
  %l279 = alloca i32
  %l280 = alloca { i64, ptr }
  %l281 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l286 = alloca %"compiler/msgs:Msg"
  %l287 = alloca i64
  %l292 = alloca ptr
  %l294 = alloca i64
  %l297 = alloca i64
  %l300 = alloca i1
  %l303 = alloca i1
  %l304 = alloca i1
  %l309 = alloca i1
  %l310 = alloca i1
  %l313 = alloca ptr
  %l315 = alloca %"compiler/source:Span"
  %l316 = alloca ptr
  %l318 = alloca %"compiler/source:Span"
  %l319 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l323 = alloca { i64, ptr }
  %l324 = alloca ptr
  %l326 = alloca %"compiler/source:Span"
  %l327 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l330 = alloca %"compiler/msgs:Msg"
  %l331 = alloca i64
  %l336 = alloca i32
  %l339 = alloca i1
  %l341 = alloca i1
  %l342 = alloca i1
  %l346 = alloca i1
  %l349 = alloca i32
  %l352 = alloca ptr
  %l353 = alloca %"compiler/source:Span"
  %l355 = alloca i32
  %l358 = alloca ptr
  %l361 = alloca i1
  %l364 = alloca i32
  %l367 = alloca i1
  %l368 = alloca ptr
  %l371 = alloca i32
  %l372 = alloca i1
  %l377 = alloca ptr
  %l380 = alloca i1
  %l382 = alloca i1
  %l384 = alloca i1
  %l385 = alloca ptr
  %l388 = alloca i32
  %l389 = alloca i1
  %l390 = alloca i1
  %l391 = alloca ptr
  %l394 = alloca i32
  %l395 = alloca i1
  %l396 = alloca i1
  %l398 = alloca ptr
  %l401 = alloca i32
  %l402 = alloca i1
  %l404 = alloca i1
  %l405 = alloca ptr
  %l408 = alloca i32
  %l410 = alloca i1
  %l411 = alloca ptr
  %l412 = alloca %"compiler/source:Span"
  %l413 = alloca ptr
  %l416 = alloca i32
  %l417 = alloca { i64, ptr }
  %l418 = alloca { i64, ptr }
  %l421 = alloca { i64, ptr }
  %l423 = alloca %"compiler/msgs:Msg"
  %l424 = alloca i64
  %l429 = alloca ptr
  %l439 = alloca ptr
  %l446 = alloca i32
  %l449 = alloca i1
  %l450 = alloca i1
  %l454 = alloca i64
  %l457 = alloca ptr
  %l461 = alloca %"compiler/source:Span"
  %l462 = alloca i32
  %l463 = alloca ptr
  %l464 = alloca ptr
  %l465 = alloca i32
  %l467 = alloca %"compiler/source:Span"
  %l468 = alloca i32
  %l471 = alloca ptr
  %l472 = alloca %"compiler/source:Span"
  %l473 = alloca %"compiler/source:Span"
  %l478 = alloca ptr
  %l482 = alloca ptr
  %l483 = alloca %"compiler/source:Span"
  %l484 = alloca %"compiler/source:Span"
  %l485 = alloca ptr
  %l487 = alloca %"compiler/source:Span"
  %l490 = alloca %"compiler/source:Span"
  %l492 = alloca ptr
  %l494 = alloca ptr
  %l497 = alloca i1
  %l498 = alloca i1
  %l501 = alloca i32
  %l508 = alloca ptr
  %l510 = alloca i1
  %l511 = alloca i1
  %l513 = alloca i1
  %l516 = alloca i32
  %l518 = alloca i32
  %l520 = alloca i1
  %l522 = alloca i1
  %l523 = alloca i1
  %l525 = alloca i1
  %l526 = alloca ptr
  %l527 = alloca %"compiler/source:Span"
  %l530 = alloca { i64, ptr }
  %l533 = alloca %"compiler/msgs:Msg"
  %l534 = alloca i64
  %l535 = alloca ptr
  %l536 = alloca %"compiler/source:Span"
  %l537 = alloca i32
  %l540 = alloca { i64, ptr }
  %l542 = alloca { i64, ptr }
  %l545 = alloca { i64, ptr }
  %l546 = alloca { i64, ptr }
  %l549 = alloca { i64, ptr }
  %l550 = alloca { i64, ptr }
  %l554 = alloca { i64, ptr }
  %l556 = alloca %"compiler/msgs:Msg"
  %l557 = alloca i64
  %l562 = alloca ptr
  %l563 = alloca { i64, ptr }
  %l565 = alloca i1
  %l567 = alloca i1
  %l571 = alloca i64
  %l573 = alloca ptr
  %l577 = alloca ptr
  %l578 = alloca %"compiler/source:Span"
  %l581 = alloca { i64, ptr }
  %l583 = alloca %"compiler/msgs:Msg"
  %l584 = alloca i64
  %l585 = alloca ptr
  %l586 = alloca %"compiler/source:Span"
  %l587 = alloca ptr
  %l588 = alloca %"compiler/source:Span"
  %l589 = alloca %"compiler/source:Span"
  %l590 = alloca i64
  %l592 = alloca ptr
  %l593 = alloca { i64, ptr }
  %l596 = alloca { i64, ptr }
  %l600 = alloca ptr
  %l601 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %rv = alloca ptr
  %t903 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t7, i32 %t8)
  store { i64, ptr } %t11, ptr %l29
  br label %bb3
bb2:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb5
bb3:
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t17 = call i1 @compiler_2fcheck_2elaneMethodName(ptr %v0, { i64, ptr } %t15, i64 %t14)
  store i1 %t17, ptr %l32
  br label %bb4
bb4:
  %t18 = load i1, ptr %l32, !tbaa !21
  store i1 %t18, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l26, !tbaa !21
  store i1 %t19, ptr %l8, !tbaa !21
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i1, ptr %l8, !tbaa !21
  %t24 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 40
  store i1 %t21, ptr %t24, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v4, ptr %t25, ptr %t26, i32 %t28)
  store ptr %t32, ptr %l39
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l39, !tbaa !29
  store ptr %t33, ptr %l9, !tbaa !29
  %t34 = load ptr, ptr %l9, !tbaa !29
  %t37 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t34)
  store i32 %t37, ptr %l42
  br label %bb7
bb7:
  %t38 = load i32, ptr %l42, !tbaa !23
  store i32 %t38, ptr %l10, !tbaa !23
  %t39 = load i32, ptr %l10, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp eq i32 %t39, %t40
  br i1 %t43, label %bb8, label %bb9
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t45, { i64, ptr } %t46)
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t49, %"compiler/source:Span" %t50)
  store ptr %t53, ptr %l50
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load ptr, ptr %l50, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb12:
  %t55 = load i1, ptr %l8, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l9, !tbaa !29
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v4, ptr %t57, ptr %t58)
  store i64 %t61, ptr %l55
  br label %bb15
bb14:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb20
bb15:
  %t62 = load i64, ptr %l55, !tbaa !24
  %t63 = icmp sge i64 %t62, 0
  br i1 %t63, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb19
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l10, !tbaa !23
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l60
  br label %bb18
bb18:
  %t70 = load i1, ptr %l60, !tbaa !21
  store i1 %t70, ptr %l57, !tbaa !21
  br label %bb19
bb19:
  %t71 = load i1, ptr %l57, !tbaa !21
  store i1 %t71, ptr %l52, !tbaa !21
  br label %bb20
bb20:
  %t72 = load i1, ptr %l52, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l3, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v4, ptr %t73, i32 %t74)
  store { i64, ptr } %t77, ptr %l63
  br label %bb23
bb22:
  br label %bb42
bb23:
  %t78 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t78, ptr %l11, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t83 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v4, ptr %t79, ptr %t80)
  store i64 %t83, ptr %l66
  br label %bb24
bb24:
  %t84 = load i64, ptr %l66, !tbaa !24
  %t85 = icmp sge i64 %t84, 0
  br i1 %t85, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb29
bb26:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  store ptr %t90, ptr %l70, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l10, !tbaa !23
  %t95 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l73
  br label %bb27
bb27:
  %t96 = load i32, ptr %l3, !tbaa !23
  %t97 = load ptr, ptr %l70, !tbaa !29
  %t98 = load i32, ptr %l73, !tbaa !23
  %t100 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t97, i32 %t98, i32 %t96)
  store i64 %t100, ptr %l75
  br label %bb28
bb28:
  %t101 = load i64, ptr %l75, !tbaa !24
  %t102 = icmp slt i64 %t101, 0
  store i1 %t102, ptr %l68, !tbaa !21
  br label %bb29
bb29:
  %t104 = load i1, ptr %l68, !tbaa !21
  br i1 %t104, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb33
bb31:
  %t105 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s2, { i64, ptr } %t105, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t107, ptr %l79
  br label %bb32
bb32:
  %t108 = load i1, ptr %l79, !tbaa !21
  store i1 %t108, ptr %l77, !tbaa !21
  br label %bb33
bb33:
  %t109 = load i1, ptr %l77, !tbaa !21
  br i1 %t109, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb37
bb35:
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t112 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s2, { i64, ptr } %t110, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t112, ptr %l82
  br label %bb36
bb36:
  %t113 = load i1, ptr %l82, !tbaa !21
  store i1 %t113, ptr %l80, !tbaa !21
  br label %bb37
bb37:
  %t114 = load i1, ptr %l80, !tbaa !21
  br i1 %t114, label %bb38, label %bb39
bb38:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l1
  %t117 = load %"compiler/source:Span", ptr %l4
  %t118 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t119 = load ptr, ptr %l9, !tbaa !29
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethod(ptr %v0, ptr %v4, ptr %v4, ptr %v2, ptr %v4, ptr %t115, %"compiler/source:Span" %t116, %"compiler/source:Span" %t117, { i64, ptr } %t118, ptr %t119, { i64, ptr } %t120)
  store ptr %t127, ptr %l89
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t128 = load ptr, ptr %l89, !tbaa !29
  store ptr %t128, ptr %rv
  br label %ret
bb41:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb42:
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t133 = icmp sgt i64 %t131, 0
  br i1 %t133, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s4
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %l94, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l10, !tbaa !23
  %t143 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l97
  br label %bb45
bb44:
  br label %bb109
bb45:
  %t144 = load i32, ptr %l3, !tbaa !23
  %t145 = load ptr, ptr %l94, !tbaa !29
  %t146 = load i32, ptr %l97, !tbaa !23
  %t148 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t145, i32 %t146, i32 %t144)
  store i64 %t148, ptr %l99
  br label %bb46
bb46:
  %t149 = load i64, ptr %l99, !tbaa !24
  store i64 %t149, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l12, !tbaa !24
  %t152 = icmp slt i64 %t150, 0
  br i1 %t152, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s5
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  store ptr %t157, ptr %l103, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l10, !tbaa !23
  %t162 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t158, i32 %t159)
  store i32 %t162, ptr %l106
  br label %bb49
bb48:
  br label %bb56
bb49:
  %t163 = load i32, ptr %l3, !tbaa !23
  %t164 = load ptr, ptr %l103, !tbaa !29
  %t165 = load i32, ptr %l106, !tbaa !23
  %t167 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s5, ptr %t164, i32 %t165, i32 %t163)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167, ptr %l108
  br label %bb50
bb50:
  %t168 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l108
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %l13
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s5, ptr %l13)
  store i64 %t170, ptr %l110
  br label %bb51
bb51:
  %t171 = load i64, ptr %l110, !tbaa !24
  %t172 = icmp eq i64 %t171, 1
  br i1 %t172, label %bb52, label %bb53
bb52:
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s5, ptr %l13, i64 0)
  store i64 %t175, ptr %l113
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t176 = load i64, ptr %l113, !tbaa !24
  store i64 %t176, ptr %l12, !tbaa !24
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s5)
  br label %bb56
bb56:
  %t177 = load i64, ptr %l12, !tbaa !24
  %t179 = icmp slt i64 %t177, 0
  br i1 %t179, label %bb57, label %bb58
bb57:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l3, !tbaa !23
  %t185 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t181, i32 %t182)
  store { i64, ptr } %t185, ptr %l119
  br label %bb59
bb58:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb61
bb59:
  %t186 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t187 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t186, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t187, ptr %l120
  br label %bb60
bb60:
  %t188 = load i1, ptr %l120, !tbaa !21
  store i1 %t188, ptr %l116, !tbaa !21
  br label %bb61
bb61:
  %t189 = load i1, ptr %l116, !tbaa !21
  br i1 %t189, label %bb62, label %bb63
bb62:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l122, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i32, ptr %l10, !tbaa !23
  %t195 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t191, i32 %t192)
  store i32 %t195, ptr %l125
  br label %bb64
bb63:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb66
bb64:
  %t196 = load ptr, ptr %l122, !tbaa !29
  %t197 = load i32, ptr %l125, !tbaa !23
  %t198 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t196, i32 %t197)
  store i1 %t198, ptr %l126
  br label %bb65
bb65:
  %t199 = load i1, ptr %l126, !tbaa !21
  store i1 %t199, ptr %l121, !tbaa !21
  br label %bb66
bb66:
  %t200 = load i1, ptr %l121, !tbaa !21
  br i1 %t200, label %bb67, label %bb68
bb67:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  %t203 = load %"compiler/source:Span", ptr %l4
  %t204 = load ptr, ptr %l9, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v4, ptr %v3, ptr %v2, ptr %v4, ptr %t201, %"compiler/source:Span" %t202, %"compiler/source:Span" %t203, ptr %t204, { i64, ptr } %t205, { i64, ptr } %t206)
  store ptr %t213, ptr %l133
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t214 = load ptr, ptr %l133, !tbaa !29
  store ptr %t214, ptr %rv
  br label %ret
bb70:
  %t215 = load i64, ptr %l12, !tbaa !24
  %t217 = icmp slt i64 %t215, 0
  br i1 %t217, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb75
bb72:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 2
  store ptr %t224, ptr %l139, !tbaa !29
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l10, !tbaa !23
  %t229 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t225, i32 %t226)
  store i32 %t229, ptr %l142
  br label %bb73
bb73:
  %t230 = load ptr, ptr %l139, !tbaa !29
  %t231 = load i32, ptr %l142, !tbaa !23
  %t232 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t230, i32 %t231)
  store i32 %t232, ptr %l143
  br label %bb74
bb74:
  %t233 = load i32, ptr %l143, !range !{i32 0, i32 33}
  %t235 = trunc i64 29 to i32
  %t236 = icmp eq i32 %t233, %t235
  store i1 %t236, ptr %l136, !tbaa !21
  br label %bb75
bb75:
  %t238 = load i1, ptr %l136, !tbaa !21
  br i1 %t238, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s8
  %t239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t239, ptr %l146, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t240, ptr %l147, !tbaa !27
  %t241 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr ptr, ptr %t242, i64 0
  %t244 = load ptr, ptr %t243, !tbaa !39
  %t246 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t244)
  store %"compiler/source:Span" %t246, ptr %l149
  br label %bb78
bb77:
  br label %bb84
bb78:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i32, ptr %l3, !tbaa !23
  %t251 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t247, i32 %t248)
  store { i64, ptr } %t251, ptr %l152
  br label %bb79
bb79:
  %t252 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 0
  %t254 = extractvalue { i64, ptr } %t252, 1
  %t255 = mul i64 %t253, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t260 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %s8, ptr %s8, { i64, ptr } %t258)
  store %"compiler/msgs:Msg" %t260, ptr %l154
  br label %bb80
bb80:
  %t261 = load ptr, ptr %l146, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l149
  %t263 = load %"compiler/msgs:Msg", ptr %l154
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t261, %"compiler/source:Span" %t262, %"compiler/msgs:Msg" %t263)
  store i64 %t264, ptr %l155
  br label %bb81
bb81:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t265, { i64, ptr } %t266)
  br label %bb82
bb82:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  %t273 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t269, %"compiler/source:Span" %t270)
  store ptr %t273, ptr %l160
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t274 = load ptr, ptr %l160, !tbaa !29
  store ptr %t274, ptr %rv
  br label %ret
bb84:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load i64, ptr %l12, !tbaa !24
  %t277 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t283 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v3, ptr %v4, ptr %t275, i64 %t276, { i64, ptr } %t277, %"compiler/source:Span" %a7)
  store { i64, ptr } %t283, ptr %l165
  br label %bb85
bb85:
  %t284 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t284, ptr %l14, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t289 = icmp eq i64 %t287, 0
  br i1 %t289, label %bb86, label %bb87
bb86:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t291, { i64, ptr } %t292)
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l1
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t295, %"compiler/source:Span" %t296)
  store ptr %t299, ptr %l173
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t300 = load ptr, ptr %l173, !tbaa !29
  store ptr %t300, ptr %rv
  br label %ret
bb90:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i32, ptr %l3, !tbaa !23
  %t305 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s4, ptr %t301, i32 %t302)
  store { i64, ptr } %t305, ptr %l176
  br label %bb91
bb91:
  %t306 = load { i64, ptr }, ptr %l176, !tbaa !27
  store { i64, ptr } %t306, ptr %l177, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i8, ptr %t308, i64 0
  %t310 = load i8, ptr %t309, !tbaa !32
  %t312 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t310)
  store i1 %t312, ptr %l179
  br label %bb92
bb92:
  %t313 = load i1, ptr %l179, !tbaa !21
  %t314 = xor i1 %t313, true
  br i1 %t314, label %bb93, label %bb94
bb93:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/check:Checker", ptr %t316, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t320 = load i64, ptr %l12, !tbaa !24
  %t323 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t319, i64 %t320)
  store i64 %t323, ptr %l185
  br label %bb95
bb94:
  store i1 false, ptr %l181, !tbaa !21
  br label %bb97
bb95:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t324)
  store ptr %t326, ptr %l187
  br label %bb96
bb96:
  %t327 = load ptr, ptr %l187, !tbaa !29
  %t329 = getelementptr %"compiler/check:frame", ptr %t327, i32 0, i32 1
  %t330 = load i64, ptr %t329, !tbaa !24
  %t331 = load i64, ptr %l185, !tbaa !24
  %t333 = icmp ne i64 %t331, %t330
  store i1 %t333, ptr %l181, !tbaa !21
  br label %bb97
bb97:
  %t335 = load i1, ptr %l181, !tbaa !21
  br i1 %t335, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s10
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l191, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t337, ptr %l192
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i32, ptr %l3, !tbaa !23
  %t342 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s10, ptr %t338, i32 %t339)
  store { i64, ptr } %t342, ptr %l195
  br label %bb100
bb99:
  br label %bb103
bb100:
  %t343 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  %t345 = extractvalue { i64, ptr } %t343, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  %t351 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %s10, ptr %s10, { i64, ptr } %t349)
  store %"compiler/msgs:Msg" %t351, ptr %l197
  br label %bb101
bb101:
  %t352 = load ptr, ptr %l191, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l192
  %t354 = load %"compiler/msgs:Msg", ptr %l197
  %t355 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t352, %"compiler/source:Span" %t353, %"compiler/msgs:Msg" %t354)
  store i64 %t355, ptr %l198
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s10)
  br label %bb103
bb103:
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l199, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t357, ptr %l200
  %t358 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t358, ptr %l201
  %t359 = load i64, ptr %l12, !tbaa !24
  store i64 %t359, ptr %l202, !tbaa !24
  %t360 = load ptr, ptr %l9, !tbaa !29
  store ptr %t360, ptr %l204, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t362, ptr %l205, !tbaa !27
  %t363 = icmp sge i64 0, 0
  br i1 %t363, label %bb104, label %bb105
bb104:
  %t365 = icmp sle i64 0, 1152921504606846975
  br i1 %t365, label %bb106, label %bb107
bb105:
  call void @__olang_check_failed(ptr @olang_loc_d23330c3ef7ea91b_34477ea00961dc87)
  unreachable
bb106:
  %t367 = mul i64 0, 8
  %t368 = insertvalue { i64, ptr } undef, i64 0, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t370 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t371 = load ptr, ptr %l199, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l200
  %t373 = load %"compiler/source:Span", ptr %l201
  %t374 = load i64, ptr %l202, !tbaa !24
  %t375 = load ptr, ptr %l204, !tbaa !29
  %t376 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t379 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v4, ptr %v2, ptr %v0, ptr %v4, ptr %v4, ptr %t371, %"compiler/source:Span" %t372, %"compiler/source:Span" %t373, i64 %t374, ptr %t375, { i64, ptr } %t376, { i64, ptr } %t369, { i64, ptr } %t370)
  store ptr %t379, ptr %l210
  br label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_d23330c3ef7ea91b_34477ea00961dc87)
  unreachable
bb108:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t380 = load ptr, ptr %l210, !tbaa !29
  store ptr %t380, ptr %rv
  br label %ret
bb109:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load i32, ptr %l3, !tbaa !23
  %t385 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v4, ptr %t381, i32 %t382)
  store { i64, ptr } %t385, ptr %l213
  br label %bb110
bb110:
  %t386 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t386, ptr %l15, !tbaa !27
  %t387 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t389 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t387, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t389, ptr %l215
  br label %bb111
bb111:
  %t390 = load i1, ptr %l215, !tbaa !21
  br i1 %t390, label %bb112, label %bb113
bb112:
  %t391 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t391, 0
  %t395 = icmp eq i64 %t393, 0
  store i1 %t395, ptr %l216, !tbaa !21
  br label %bb114
bb113:
  store i1 false, ptr %l216, !tbaa !21
  br label %bb114
bb114:
  %t397 = load i1, ptr %l216, !tbaa !21
  br i1 %t397, label %bb115, label %bb116
bb115:
  store i1 true, ptr %l220, !tbaa !21
  br label %bb121
bb116:
  %t398 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t400 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t398, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t400, ptr %l222
  br label %bb117
bb117:
  %t401 = load i1, ptr %l222, !tbaa !21
  br i1 %t401, label %bb118, label %bb119
bb118:
  %t402 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t404 = extractvalue { i64, ptr } %t402, 0
  %t406 = icmp eq i64 %t404, 1
  store i1 %t406, ptr %l223, !tbaa !21
  br label %bb120
bb119:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb120
bb120:
  %t408 = load i1, ptr %l223, !tbaa !21
  store i1 %t408, ptr %l220, !tbaa !21
  br label %bb121
bb121:
  %t409 = load i1, ptr %l220, !tbaa !21
  br i1 %t409, label %bb122, label %bb123
bb122:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/check:Checker", ptr %t410, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !29
  store ptr %t413, ptr %l229, !tbaa !29
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t414)
  store ptr %t416, ptr %l231
  br label %bb124
bb123:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb126
bb124:
  %t417 = load ptr, ptr %l231, !tbaa !29
  %t419 = getelementptr %"compiler/check:frame", ptr %t417, i32 0, i32 1
  %t420 = load i64, ptr %t419, !tbaa !24
  %t421 = load ptr, ptr %l229, !tbaa !29
  %t423 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %t421, i64 %t420)
  store i1 %t423, ptr %l234
  br label %bb125
bb125:
  %t424 = load i1, ptr %l234, !tbaa !21
  store i1 %t424, ptr %l227, !tbaa !21
  br label %bb126
bb126:
  %t425 = load i1, ptr %l227, !tbaa !21
  store i1 %t425, ptr %l16, !tbaa !21
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/check:Checker", ptr %t426, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !29
  %t431 = getelementptr %"compiler/generic:Program", ptr %t429, i32 0, i32 2
  store ptr %t431, ptr %l237, !tbaa !29
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load i32, ptr %l10, !tbaa !23
  %t436 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t432, i32 %t433)
  store i32 %t436, ptr %l240
  br label %bb127
bb127:
  %t437 = load ptr, ptr %l237, !tbaa !29
  %t438 = load i32, ptr %l240, !tbaa !23
  %t439 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t437, i32 %t438)
  store i32 %t439, ptr %l241
  br label %bb128
bb128:
  %t440 = load i32, ptr %l241, !range !{i32 0, i32 33}
  %t442 = trunc i64 29 to i32
  %t443 = icmp eq i32 %t440, %t442
  br i1 %t443, label %bb129, label %bb130
bb129:
  %t445 = load i1, ptr %l16, !tbaa !21
  %t447 = xor i1 %t445, true
  store i1 %t447, ptr %l244, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l244, !tbaa !21
  br label %bb131
bb131:
  %t449 = load i1, ptr %l244, !tbaa !21
  br i1 %t449, label %bb132, label %bb133
bb132:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load %"compiler/source:Span", ptr %l1
  %t452 = load ptr, ptr %l2, !tbaa !29
  %t453 = load ptr, ptr %l9, !tbaa !29
  %t454 = load i32, ptr %l3, !tbaa !23
  %t455 = load %"compiler/source:Span", ptr %l4
  %t456 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t464 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v4, ptr %v2, ptr %v4, ptr %t450, %"compiler/source:Span" %t451, ptr %t452, ptr %t453, i32 %t454, %"compiler/source:Span" %t455, { i64, ptr } %t456)
  store ptr %t464, ptr %l254
  br label %bb134
bb133:
  br label %bb135
bb134:
  call void @__olang_scope_close(ptr %s0)
  %t465 = load ptr, ptr %l254, !tbaa !29
  store ptr %t465, ptr %rv
  br label %ret
bb135:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t468 = getelementptr %"compiler/check:Checker", ptr %t466, i32 0, i32 1
  %t469 = load ptr, ptr %t468, !tbaa !29
  store ptr %t469, ptr %l256, !tbaa !29
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load i32, ptr %l10, !tbaa !23
  %t474 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t470, i32 %t471)
  store i32 %t474, ptr %l259
  br label %bb136
bb136:
  %t475 = load i32, ptr %l3, !tbaa !23
  %t476 = load ptr, ptr %l256, !tbaa !29
  %t477 = load i32, ptr %l259, !tbaa !23
  %t479 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t476, i32 %t477, i32 %t475)
  store i64 %t479, ptr %l261
  br label %bb137
bb137:
  %t480 = load i64, ptr %l261, !tbaa !24
  store i64 %t480, ptr %l17, !tbaa !24
  %t481 = load i64, ptr %l17, !tbaa !24
  %t483 = icmp slt i64 %t481, 0
  br i1 %t483, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s12
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/check:Checker", ptr %t485, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !29
  store ptr %t488, ptr %l265, !tbaa !29
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load i32, ptr %l10, !tbaa !23
  %t493 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t489, i32 %t490)
  store i32 %t493, ptr %l268
  br label %bb140
bb139:
  br label %bb158
bb140:
  %t494 = load i32, ptr %l3, !tbaa !23
  %t495 = load ptr, ptr %l265, !tbaa !29
  %t496 = load i32, ptr %l268, !tbaa !23
  %t498 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s12, ptr %t495, i32 %t496, i32 %t494)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t498, ptr %l270
  br label %bb141
bb141:
  %t499 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l270
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t499, ptr %l18
  %t501 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s12, ptr %l18)
  store i64 %t501, ptr %l272
  br label %bb142
bb142:
  %t502 = load i64, ptr %l272, !tbaa !24
  %t503 = icmp sgt i64 %t502, 1
  br i1 %t503, label %bb143, label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s13
  %t505 = load ptr, ptr %l0, !tbaa !29
  store ptr %t505, ptr %l274, !tbaa !29
  %t506 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t506, ptr %l275
  %t507 = load ptr, ptr %l0, !tbaa !29
  store ptr %t507, ptr %l276, !tbaa !29
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load i32, ptr %l10, !tbaa !23
  %t512 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t508, i32 %t509)
  store i32 %t512, ptr %l279
  br label %bb145
bb144:
  br label %bb152
bb145:
  %t513 = load ptr, ptr %l276, !tbaa !29
  %t514 = load i32, ptr %l279, !tbaa !23
  %t515 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s13, ptr %t513, i32 %t514)
  store { i64, ptr } %t515, ptr %l280
  br label %bb146
bb146:
  %t516 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t516, 0
  %t518 = extractvalue { i64, ptr } %t516, 1
  %t519 = mul i64 %t517, 1
  %t520 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t519)
  call void @llvm.memcpy.p0.p0.i64(ptr %t520, ptr %t518, i64 %t519, i1 false)
  %t521 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t520, 1
  store { i64, ptr } %t522, ptr %l281, !tbaa !27
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t524 = load i32, ptr %l3, !tbaa !23
  %t527 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s13, ptr %t523, i32 %t524)
  store { i64, ptr } %t527, ptr %l284
  br label %bb147
bb147:
  %t528 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t528, 0
  %t530 = extractvalue { i64, ptr } %t528, 1
  %t531 = mul i64 %t529, 1
  %t532 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t531)
  call void @llvm.memcpy.p0.p0.i64(ptr %t532, ptr %t530, i64 %t531, i1 false)
  %t533 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t534 = insertvalue { i64, ptr } %t533, ptr %t532, 1
  %t535 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t537 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %s13, ptr %s13, ptr %s13, { i64, ptr } %t535, { i64, ptr } %t534)
  store %"compiler/msgs:Msg" %t537, ptr %l286
  br label %bb148
bb148:
  %t538 = load ptr, ptr %l274, !tbaa !29
  %t539 = load %"compiler/source:Span", ptr %l275
  %t540 = load %"compiler/msgs:Msg", ptr %l286
  %t541 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t538, %"compiler/source:Span" %t539, %"compiler/msgs:Msg" %t540)
  store i64 %t541, ptr %l287
  br label %bb149
bb149:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t542, { i64, ptr } %t543)
  br label %bb150
bb150:
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t547 = load %"compiler/source:Span", ptr %l1
  %t550 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t546, %"compiler/source:Span" %t547)
  store ptr %t550, ptr %l292
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t551 = load ptr, ptr %l292, !tbaa !29
  store ptr %t551, ptr %rv
  br label %ret
bb152:
  %t553 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s12, ptr %l18)
  store i64 %t553, ptr %l294
  br label %bb153
bb153:
  %t554 = load i64, ptr %l294, !tbaa !24
  %t555 = icmp eq i64 %t554, 1
  br i1 %t555, label %bb154, label %bb155
bb154:
  %t558 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s12, ptr %l18, i64 0)
  store i64 %t558, ptr %l297
  br label %bb156
bb155:
  br label %bb157
bb156:
  %t559 = load i64, ptr %l297, !tbaa !24
  store i64 %t559, ptr %l17, !tbaa !24
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s12)
  br label %bb158
bb158:
  %t560 = load i64, ptr %l17, !tbaa !24
  %t562 = icmp slt i64 %t560, 0
  br i1 %t562, label %bb159, label %bb160
bb159:
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t565 = load i32, ptr %l10, !tbaa !23
  %t568 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t564, i32 %t565)
  store i1 %t568, ptr %l303
  br label %bb161
bb160:
  store i1 false, ptr %l300, !tbaa !21
  br label %bb162
bb161:
  %t569 = load i1, ptr %l303, !tbaa !21
  store i1 %t569, ptr %l300, !tbaa !21
  br label %bb162
bb162:
  %t570 = load i1, ptr %l300, !tbaa !21
  br i1 %t570, label %bb163, label %bb164
bb163:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = getelementptr %"compiler/check:Checker", ptr %t571, i32 0, i32 1
  %t574 = load ptr, ptr %t573, !tbaa !29
  %t576 = getelementptr %"compiler/generic:Program", ptr %t574, i32 0, i32 2
  %t577 = load i32, ptr %l10, !tbaa !23
  %t580 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t576, i32 %t577)
  store i1 %t580, ptr %l309
  br label %bb165
bb164:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb166
bb165:
  %t581 = load i1, ptr %l309, !tbaa !21
  store i1 %t581, ptr %l304, !tbaa !21
  br label %bb166
bb166:
  %t582 = load i1, ptr %l304, !tbaa !21
  br i1 %t582, label %bb167, label %bb168
bb167:
  %t583 = load i1, ptr %l16, !tbaa !21
  %t585 = xor i1 %t583, true
  store i1 %t585, ptr %l310, !tbaa !21
  br label %bb169
bb168:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb169
bb169:
  %t587 = load i1, ptr %l310, !tbaa !21
  br i1 %t587, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s15
  %t588 = load ptr, ptr %l0, !tbaa !29
  store ptr %t588, ptr %l313, !tbaa !29
  %t589 = load ptr, ptr %l2, !tbaa !29
  %t591 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t589)
  store %"compiler/source:Span" %t591, ptr %l315
  br label %bb172
bb171:
  br label %bb182
bb172:
  %t592 = load ptr, ptr %l0, !tbaa !29
  store ptr %t592, ptr %l316, !tbaa !29
  %t593 = load ptr, ptr %l2, !tbaa !29
  %t595 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t593)
  store %"compiler/source:Span" %t595, ptr %l318
  br label %bb173
bb173:
  %t596 = load ptr, ptr %l316, !tbaa !29
  %t597 = load %"compiler/source:Span", ptr %l318
  %t598 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t596, %"compiler/source:Span" %t597)
  store { i64, ptr } %t598, ptr %l319
  br label %bb174
bb174:
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t600 = load i32, ptr %l10, !tbaa !23
  %t603 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t599, i32 %t600)
  store { i64, ptr } %t603, ptr %l322
  br label %bb175
bb175:
  %t604 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t605 = extractvalue { i64, ptr } %t604, 0
  %t606 = extractvalue { i64, ptr } %t604, 1
  %t607 = mul i64 %t605, 1
  %t608 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t607)
  call void @llvm.memcpy.p0.p0.i64(ptr %t608, ptr %t606, i64 %t607, i1 false)
  %t609 = insertvalue { i64, ptr } undef, i64 %t605, 0
  %t610 = insertvalue { i64, ptr } %t609, ptr %t608, 1
  store { i64, ptr } %t610, ptr %l323, !tbaa !27
  %t611 = load ptr, ptr %l0, !tbaa !29
  store ptr %t611, ptr %l324, !tbaa !29
  %t612 = load ptr, ptr %l2, !tbaa !29
  %t614 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t612)
  store %"compiler/source:Span" %t614, ptr %l326
  br label %bb176
bb176:
  %t615 = load ptr, ptr %l324, !tbaa !29
  %t616 = load %"compiler/source:Span", ptr %l326
  %t617 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t615, %"compiler/source:Span" %t616)
  store { i64, ptr } %t617, ptr %l327
  br label %bb177
bb177:
  %t618 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t619 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s15, { i64, ptr } %t618)
  store { i64, ptr } %t619, ptr %l328
  br label %bb178
bb178:
  %t620 = load { i64, ptr }, ptr %l328, !tbaa !27
  %t621 = extractvalue { i64, ptr } %t620, 0
  %t622 = extractvalue { i64, ptr } %t620, 1
  %t623 = mul i64 %t621, 1
  %t624 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t623)
  call void @llvm.memcpy.p0.p0.i64(ptr %t624, ptr %t622, i64 %t623, i1 false)
  %t625 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t624, 1
  %t627 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t628 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t630 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t627, { i64, ptr } %t628, { i64, ptr } %t626)
  store %"compiler/msgs:Msg" %t630, ptr %l330
  br label %bb179
bb179:
  %t631 = load ptr, ptr %l313, !tbaa !29
  %t632 = load %"compiler/source:Span", ptr %l315
  %t633 = load %"compiler/msgs:Msg", ptr %l330
  %t634 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t631, %"compiler/source:Span" %t632, %"compiler/msgs:Msg" %t633)
  store i64 %t634, ptr %l331
  br label %bb180
bb180:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/check:Checker", ptr %t635, i32 0, i32 1
  %t638 = load ptr, ptr %t637, !tbaa !29
  %t640 = getelementptr %"compiler/generic:Program", ptr %t638, i32 0, i32 2
  %t641 = load i32, ptr %l10, !tbaa !23
  %t644 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t640, i32 %t641)
  store i32 %t644, ptr %l336
  br label %bb181
bb181:
  %t645 = load i32, ptr %l336, !tbaa !23
  store i32 %t645, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  br label %bb182
bb182:
  %t646 = load i64, ptr %l17, !tbaa !24
  %t648 = icmp slt i64 %t646, 0
  br i1 %t648, label %bb183, label %bb184
bb183:
  %t650 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t652 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t650, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t652, ptr %l341
  br label %bb185
bb184:
  store i1 false, ptr %l339, !tbaa !21
  br label %bb186
bb185:
  %t653 = load i1, ptr %l341, !tbaa !21
  store i1 %t653, ptr %l339, !tbaa !21
  br label %bb186
bb186:
  %t654 = load i1, ptr %l339, !tbaa !21
  br i1 %t654, label %bb187, label %bb188
bb187:
  %t655 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t657 = extractvalue { i64, ptr } %t655, 0
  %t659 = icmp eq i64 %t657, 0
  store i1 %t659, ptr %l342, !tbaa !21
  br label %bb189
bb188:
  store i1 false, ptr %l342, !tbaa !21
  br label %bb189
bb189:
  %t661 = load i1, ptr %l342, !tbaa !21
  br i1 %t661, label %bb190, label %bb191
bb190:
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t663 = load i32, ptr %l10, !tbaa !23
  %t666 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t662, i32 %t663)
  store i32 %t666, ptr %l349
  br label %bb192
bb191:
  store i1 false, ptr %l346, !tbaa !21
  br label %bb193
bb192:
  %t667 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t668 = load i32, ptr %l349, !tbaa !23
  %t670 = icmp ne i32 %t668, %t667
  store i1 %t670, ptr %l346, !tbaa !21
  br label %bb193
bb193:
  %t672 = load i1, ptr %l346, !tbaa !21
  br i1 %t672, label %bb194, label %bb195
bb194:
  %t673 = load ptr, ptr %l0, !tbaa !29
  store ptr %t673, ptr %l352, !tbaa !29
  %t674 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t674, ptr %l353
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t677 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t675)
  store i32 %t677, ptr %l355
  br label %bb196
bb195:
  br label %bb198
bb196:
  %t678 = load ptr, ptr %l9, !tbaa !29
  %t679 = load ptr, ptr %l352, !tbaa !29
  %t680 = load %"compiler/source:Span", ptr %l353
  %t681 = load i32, ptr %l355, !tbaa !23
  %t684 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v4, ptr %v0, ptr %v4, ptr %t679, %"compiler/source:Span" %t680, i32 %t681, i32 22, ptr %t678, ptr null)
  store ptr %t684, ptr %l358
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s0)
  %t685 = load ptr, ptr %l358, !tbaa !29
  store ptr %t685, ptr %rv
  br label %ret
bb198:
  %t686 = load i64, ptr %l17, !tbaa !24
  %t688 = icmp slt i64 %t686, 0
  br i1 %t688, label %bb199, label %bb200
bb199:
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load i32, ptr %l10, !tbaa !23
  %t694 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t690, i32 %t691)
  store i32 %t694, ptr %l364
  br label %bb201
bb200:
  store i1 false, ptr %l361, !tbaa !21
  br label %bb207
bb201:
  %t695 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t696 = load i32, ptr %l364, !tbaa !23
  %t698 = icmp eq i32 %t696, %t695
  br i1 %t698, label %bb202, label %bb203
bb202:
  store i1 true, ptr %l367, !tbaa !21
  br label %bb206
bb203:
  %t700 = load ptr, ptr %l0, !tbaa !29
  store ptr %t700, ptr %l368, !tbaa !29
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t702 = load i32, ptr %l10, !tbaa !23
  %t705 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t701, i32 %t702)
  store i32 %t705, ptr %l371
  br label %bb204
bb204:
  %t706 = load ptr, ptr %l368, !tbaa !29
  %t707 = load i32, ptr %l371, !tbaa !23
  %t708 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %t706, i32 %t707)
  store i1 %t708, ptr %l372
  br label %bb205
bb205:
  %t709 = load i1, ptr %l372, !tbaa !21
  store i1 %t709, ptr %l367, !tbaa !21
  br label %bb206
bb206:
  %t710 = load i1, ptr %l367, !tbaa !21
  store i1 %t710, ptr %l361, !tbaa !21
  br label %bb207
bb207:
  %t711 = load i1, ptr %l361, !tbaa !21
  br i1 %t711, label %bb208, label %bb209
bb208:
  %t712 = load ptr, ptr %l0, !tbaa !29
  %t713 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t712, { i64, ptr } %t713)
  br label %bb210
bb209:
  br label %bb212
bb210:
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = load %"compiler/source:Span", ptr %l1
  %t720 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t716, %"compiler/source:Span" %t717)
  store ptr %t720, ptr %l377
  br label %bb211
bb211:
  call void @__olang_scope_close(ptr %s0)
  %t721 = load ptr, ptr %l377, !tbaa !29
  store ptr %t721, ptr %rv
  br label %ret
bb212:
  %t722 = load i64, ptr %l17, !tbaa !24
  %t724 = icmp slt i64 %t722, 0
  br i1 %t724, label %bb213, label %bb214
bb213:
  %t726 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t728 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t726, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t728, ptr %l382
  br label %bb215
bb214:
  store i1 false, ptr %l380, !tbaa !21
  br label %bb216
bb215:
  %t729 = load i1, ptr %l382, !tbaa !21
  %t730 = xor i1 %t729, true
  store i1 %t730, ptr %l380, !tbaa !21
  br label %bb216
bb216:
  %t732 = load i1, ptr %l380, !tbaa !21
  br i1 %t732, label %bb217, label %bb218
bb217:
  %t733 = load ptr, ptr %l0, !tbaa !29
  store ptr %t733, ptr %l385, !tbaa !29
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t735 = load i32, ptr %l10, !tbaa !23
  %t738 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t734, i32 %t735)
  store i32 %t738, ptr %l388
  br label %bb219
bb218:
  store i1 false, ptr %l384, !tbaa !21
  br label %bb221
bb219:
  %t739 = load ptr, ptr %l385, !tbaa !29
  %t740 = load i32, ptr %l388, !tbaa !23
  %t741 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t739, i32 %t740)
  store i1 %t741, ptr %l389
  br label %bb220
bb220:
  %t742 = load i1, ptr %l389, !tbaa !21
  store i1 %t742, ptr %l384, !tbaa !21
  br label %bb221
bb221:
  %t743 = load i1, ptr %l384, !tbaa !21
  br i1 %t743, label %bb222, label %bb223
bb222:
  %t744 = load ptr, ptr %l0, !tbaa !29
  store ptr %t744, ptr %l391, !tbaa !29
  %t745 = load ptr, ptr %l0, !tbaa !29
  %t746 = load i32, ptr %l10, !tbaa !23
  %t749 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t745, i32 %t746)
  store i32 %t749, ptr %l394
  br label %bb224
bb223:
  store i1 false, ptr %l390, !tbaa !21
  br label %bb226
bb224:
  %t750 = load ptr, ptr %l391, !tbaa !29
  %t751 = load i32, ptr %l394, !tbaa !23
  %t752 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t750, i32 %t751)
  store i1 %t752, ptr %l395
  br label %bb225
bb225:
  %t753 = load i1, ptr %l395, !tbaa !21
  store i1 %t753, ptr %l390, !tbaa !21
  br label %bb226
bb226:
  %t754 = load i1, ptr %l390, !tbaa !21
  br i1 %t754, label %bb227, label %bb228
bb227:
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t757 = getelementptr %"compiler/check:Checker", ptr %t755, i32 0, i32 1
  %t758 = load ptr, ptr %t757, !tbaa !29
  store ptr %t758, ptr %l398, !tbaa !29
  %t759 = load ptr, ptr %l0, !tbaa !29
  %t760 = load i32, ptr %l10, !tbaa !23
  %t763 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t759, i32 %t760)
  store i32 %t763, ptr %l401
  br label %bb229
bb228:
  store i1 false, ptr %l396, !tbaa !21
  br label %bb231
bb229:
  %t764 = load ptr, ptr %l398, !tbaa !29
  %t765 = load i32, ptr %l401, !tbaa !23
  %t766 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t764, i32 %t765)
  store i1 %t766, ptr %l402
  br label %bb230
bb230:
  %t767 = load i1, ptr %l402, !tbaa !21
  %t768 = xor i1 %t767, true
  store i1 %t768, ptr %l396, !tbaa !21
  br label %bb231
bb231:
  %t770 = load i1, ptr %l396, !tbaa !21
  br i1 %t770, label %bb232, label %bb233
bb232:
  %t771 = load ptr, ptr %l0, !tbaa !29
  store ptr %t771, ptr %l405, !tbaa !29
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t773 = load i32, ptr %l10, !tbaa !23
  %t776 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t772, i32 %t773)
  store i32 %t776, ptr %l408
  br label %bb234
bb233:
  store i1 false, ptr %l404, !tbaa !21
  br label %bb236
bb234:
  %t777 = load i32, ptr %l3, !tbaa !23
  %t778 = load ptr, ptr %l405, !tbaa !29
  %t779 = load i32, ptr %l408, !tbaa !23
  %t781 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseHas(ptr %v0, ptr %t778, i32 %t779, i32 %t777)
  store i1 %t781, ptr %l410
  br label %bb235
bb235:
  %t782 = load i1, ptr %l410, !tbaa !21
  store i1 %t782, ptr %l404, !tbaa !21
  br label %bb236
bb236:
  %t783 = load i1, ptr %l404, !tbaa !21
  br i1 %t783, label %bb237, label %bb238
bb237:
  store %olang.scope zeroinitializer, ptr %s18
  %t784 = load ptr, ptr %l0, !tbaa !29
  store ptr %t784, ptr %l411, !tbaa !29
  %t785 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t785, ptr %l412
  %t786 = load ptr, ptr %l0, !tbaa !29
  store ptr %t786, ptr %l413, !tbaa !29
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t788 = load i32, ptr %l10, !tbaa !23
  %t791 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t787, i32 %t788)
  store i32 %t791, ptr %l416
  br label %bb239
bb238:
  br label %bb246
bb239:
  %t792 = load ptr, ptr %l413, !tbaa !29
  %t793 = load i32, ptr %l416, !tbaa !23
  %t794 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s18, ptr %t792, i32 %t793)
  store { i64, ptr } %t794, ptr %l417
  br label %bb240
bb240:
  %t795 = load { i64, ptr }, ptr %l417, !tbaa !27
  %t796 = extractvalue { i64, ptr } %t795, 0
  %t797 = extractvalue { i64, ptr } %t795, 1
  %t798 = mul i64 %t796, 1
  %t799 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t798)
  call void @llvm.memcpy.p0.p0.i64(ptr %t799, ptr %t797, i64 %t798, i1 false)
  %t800 = insertvalue { i64, ptr } undef, i64 %t796, 0
  %t801 = insertvalue { i64, ptr } %t800, ptr %t799, 1
  store { i64, ptr } %t801, ptr %l418, !tbaa !27
  %t802 = load ptr, ptr %l0, !tbaa !29
  %t803 = load i32, ptr %l3, !tbaa !23
  %t806 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t802, i32 %t803)
  store { i64, ptr } %t806, ptr %l421
  br label %bb241
bb241:
  %t807 = load { i64, ptr }, ptr %l421, !tbaa !27
  %t808 = extractvalue { i64, ptr } %t807, 0
  %t809 = extractvalue { i64, ptr } %t807, 1
  %t810 = mul i64 %t808, 1
  %t811 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t810)
  call void @llvm.memcpy.p0.p0.i64(ptr %t811, ptr %t809, i64 %t810, i1 false)
  %t812 = insertvalue { i64, ptr } undef, i64 %t808, 0
  %t813 = insertvalue { i64, ptr } %t812, ptr %t811, 1
  %t814 = load { i64, ptr }, ptr %l418, !tbaa !27
  %t816 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %s18, ptr %s18, ptr %s18, { i64, ptr } %t814, { i64, ptr } %t813)
  store %"compiler/msgs:Msg" %t816, ptr %l423
  br label %bb242
bb242:
  %t817 = load ptr, ptr %l411, !tbaa !29
  %t818 = load %"compiler/source:Span", ptr %l412
  %t819 = load %"compiler/msgs:Msg", ptr %l423
  %t820 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t817, %"compiler/source:Span" %t818, %"compiler/msgs:Msg" %t819)
  store i64 %t820, ptr %l424
  br label %bb243
bb243:
  %t821 = load ptr, ptr %l0, !tbaa !29
  %t822 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t821, { i64, ptr } %t822)
  br label %bb244
bb244:
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t826 = load %"compiler/source:Span", ptr %l1
  %t829 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t825, %"compiler/source:Span" %t826)
  store ptr %t829, ptr %l429
  br label %bb245
bb245:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t830 = load ptr, ptr %l429, !tbaa !29
  store ptr %t830, ptr %rv
  br label %ret
bb246:
  %t831 = load i64, ptr %l17, !tbaa !24
  %t833 = icmp slt i64 %t831, 0
  br i1 %t833, label %bb247, label %bb248
bb247:
  store %olang.scope zeroinitializer, ptr %s19
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t836 = load %"compiler/source:Span", ptr %l1
  %t837 = load %"compiler/source:Span", ptr %l4
  %t838 = load ptr, ptr %l2, !tbaa !29
  %t839 = load ptr, ptr %l9, !tbaa !29
  %t840 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t841 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t849 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v4, ptr %v4, ptr %v2, ptr %v4, ptr %t835, %"compiler/source:Span" %t836, %"compiler/source:Span" %t837, ptr %t838, ptr %t839, { i64, ptr } %t840, { i64, ptr } %t841)
  store ptr %t849, ptr %l439
  br label %bb249
bb248:
  br label %bb322
bb249:
  %t850 = load ptr, ptr %l439, !tbaa !29
  store ptr %t850, ptr %l19, !tbaa !29
  %t851 = load ptr, ptr %l19, !tbaa !29
  %t853 = icmp eq ptr %t851, null
  %t855 = xor i1 %t853, true
  br i1 %t855, label %bb250, label %bb251
bb250:
  %t857 = load ptr, ptr %l19, !tbaa !29
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t857, ptr %rv
  br label %ret
bb251:
  br label %bb252
bb252:
  %t859 = load ptr, ptr %l0, !tbaa !29
  %t860 = load i32, ptr %l10, !tbaa !23
  %t863 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t859, i32 %t860)
  store i32 %t863, ptr %l446
  br label %bb253
bb253:
  %t864 = load i32, ptr %l446, !tbaa !23
  store i32 %t864, ptr %l20, !tbaa !23
  %t865 = load ptr, ptr %l0, !tbaa !29
  %t866 = load i32, ptr %l20, !tbaa !23
  %t869 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t865, i32 %t866)
  store i1 %t869, ptr %l449
  br label %bb254
bb254:
  %t870 = load i1, ptr %l449, !tbaa !21
  br i1 %t870, label %bb255, label %bb256
bb255:
  %t871 = load ptr, ptr %l0, !tbaa !29
  %t872 = load i32, ptr %l20, !tbaa !23
  %t873 = load i32, ptr %l3, !tbaa !23
  %t877 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %t871, i32 %t872, i32 %t873)
  store i64 %t877, ptr %l454
  br label %bb257
bb256:
  store i1 false, ptr %l450, !tbaa !21
  br label %bb258
bb257:
  %t878 = load i64, ptr %l454, !tbaa !24
  %t879 = icmp sge i64 %t878, 0
  store i1 %t879, ptr %l450, !tbaa !21
  br label %bb258
bb258:
  %t881 = load i1, ptr %l450, !tbaa !21
  br i1 %t881, label %bb259, label %bb260
bb259:
  %t882 = load ptr, ptr %l9, !tbaa !29
  %t884 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v4, ptr %v4, ptr %t882)
  store ptr %t884, ptr %l457
  br label %bb261
bb260:
  br label %bb279
bb261:
  %t885 = load ptr, ptr %l457, !tbaa !29
  store ptr %t885, ptr %l21, !tbaa !29
  %t886 = load ptr, ptr %l21, !tbaa !29
  %t888 = icmp eq ptr %t886, null
  br i1 %t888, label %bb262, label %bb263
bb262:
  %t890 = load ptr, ptr %l2, !tbaa !29
  %t892 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t890)
  store %"compiler/source:Span" %t892, ptr %l461
  br label %bb264
bb263:
  br label %bb267
bb264:
  %t893 = load i32, ptr %l10, !tbaa !23
  store i32 %t893, ptr %l462, !tbaa !23
  %t894 = load ptr, ptr %l9, !tbaa !29
  store ptr %t894, ptr %l463, !tbaa !29
  %t895 = load ptr, ptr %l0, !tbaa !29
  store ptr %t895, ptr %l464, !tbaa !29
  store i32 8, ptr %l465
  %t896 = load ptr, ptr %l2, !tbaa !29
  %t898 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t896)
  store %"compiler/source:Span" %t898, ptr %l467
  br label %bb265
bb265:
  %t899 = load ptr, ptr %l464, !tbaa !29
  %t900 = load i32, ptr %l465, !range !{i32 0, i32 9}
  %t901 = load %"compiler/source:Span", ptr %l467
  %t902 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t899, i32 %t900, %"compiler/source:Span" %t901)
  store i32 %t902, ptr %l468
  br label %bb266
bb266:
  store { i64, [4 x i64] } zeroinitializer, ptr %t903
  %t904 = getelementptr { i64, [4 x i64] }, ptr %t903, i32 0, i32 0
  store i64 6, ptr %t904
  %t905 = load %"compiler/source:Span", ptr %l461
  %t906 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t905, 0
  %t907 = load i32, ptr %l462, !tbaa !23
  %t908 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t906, i32 %t907, 1
  %t909 = load ptr, ptr %l463, !tbaa !29
  %t910 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t908, ptr %t909, 2
  %t911 = load i32, ptr %l468, !tbaa !23
  %t912 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t910, i32 %t911, 3
  %t913 = getelementptr { i64, [4 x i64] }, ptr %t903, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t912, ptr %t913
  %t914 = load { i64, [4 x i64] }, ptr %t903
  %t916 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store { i64, [4 x i64] } %t914, ptr %t916
  store ptr %t916, ptr %l21, !tbaa !29
  br label %bb267
bb267:
  %t918 = load ptr, ptr %l0, !tbaa !29
  store ptr %t918, ptr %l471, !tbaa !29
  %t919 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t919, ptr %l472
  %t920 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t920, ptr %l473
  %t921 = load ptr, ptr %l21, !tbaa !29
  %t923 = icmp eq ptr %t921, null
  br i1 %t923, label %bb268, label %bb269
bb268:
  call void @__olang_check_failed(ptr @olang_loc_897998a95b9e5e2e_e7f90bd867c953f2)
  unreachable
bb269:
  br label %bb270
bb270:
  %t925 = load ptr, ptr %l21, !tbaa !29
  %t926 = load i32, ptr %l3, !tbaa !23
  %t927 = load ptr, ptr %l471, !tbaa !29
  %t928 = load %"compiler/source:Span", ptr %l472
  %t929 = load %"compiler/source:Span", ptr %l473
  %t932 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %v4, ptr %v4, ptr %t927, %"compiler/source:Span" %t928, %"compiler/source:Span" %t929, ptr %t925, i32 %t926)
  store ptr %t932, ptr %l478
  br label %bb271
bb271:
  %t933 = load ptr, ptr %l478, !tbaa !29
  store ptr %t933, ptr %l22, !tbaa !29
  %t934 = load ptr, ptr %l22, !tbaa !29
  %t936 = icmp eq ptr %t934, null
  %t938 = xor i1 %t936, true
  br i1 %t938, label %bb272, label %bb273
bb272:
  store %olang.scope zeroinitializer, ptr %s23
  %t940 = load ptr, ptr %l0, !tbaa !29
  store ptr %t940, ptr %l482, !tbaa !29
  %t941 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t941, ptr %l483
  %t942 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t942, ptr %l484
  %t943 = load ptr, ptr %l0, !tbaa !29
  store ptr %t943, ptr %l485, !tbaa !29
  %t944 = load ptr, ptr %l2, !tbaa !29
  %t946 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t944)
  store %"compiler/source:Span" %t946, ptr %l487
  br label %bb274
bb273:
  br label %bb278
bb274:
  %t947 = getelementptr %"compiler/source:Span", ptr %l487, i32 0, i32 0
  %t948 = load i32, ptr %t947, !tbaa !23
  %t949 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t950 = load i32, ptr %t949, !tbaa !23
  %t953 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s23, i32 %t948, i32 %t950)
  store %"compiler/source:Span" %t953, ptr %l490
  br label %bb275
bb275:
  %t954 = load ptr, ptr %l22, !tbaa !29
  %t955 = load ptr, ptr %l485, !tbaa !29
  %t956 = load %"compiler/source:Span", ptr %l490
  %t958 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v4, ptr %v4, ptr %t955, %"compiler/source:Span" %t956, ptr %t954)
  store ptr %t958, ptr %l492
  br label %bb276
bb276:
  %t959 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t960 = load ptr, ptr %l482, !tbaa !29
  %t961 = load %"compiler/source:Span", ptr %l483
  %t962 = load %"compiler/source:Span", ptr %l484
  %t963 = load ptr, ptr %l492, !tbaa !29
  %t965 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v4, ptr %v2, ptr %v4, ptr %t960, %"compiler/source:Span" %t961, %"compiler/source:Span" %t962, ptr %t963, { i64, ptr } %t959)
  store ptr %t965, ptr %l494
  br label %bb277
bb277:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t966 = load ptr, ptr %l494, !tbaa !29
  store ptr %t966, ptr %rv
  br label %ret
bb278:
  br label %bb279
bb279:
  %t967 = load ptr, ptr %l0, !tbaa !29
  %t968 = load i32, ptr %l20, !tbaa !23
  %t971 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t967, i32 %t968)
  store i1 %t971, ptr %l497
  br label %bb280
bb280:
  %t972 = load i1, ptr %l497, !tbaa !21
  br i1 %t972, label %bb281, label %bb282
bb281:
  %t973 = load ptr, ptr %l0, !tbaa !29
  %t974 = load i32, ptr %l20, !tbaa !23
  %t977 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t973, i32 %t974)
  store i32 %t977, ptr %l501
  br label %bb283
bb282:
  store i1 false, ptr %l498, !tbaa !21
  br label %bb284
bb283:
  %t978 = load i32, ptr %l501, !range !{i32 0, i32 6}
  %t980 = trunc i64 3 to i32
  %t981 = icmp eq i32 %t978, %t980
  store i1 %t981, ptr %l498, !tbaa !21
  br label %bb284
bb284:
  %t983 = load i1, ptr %l498, !tbaa !21
  br i1 %t983, label %bb285, label %bb286
bb285:
  %t984 = load ptr, ptr %l0, !tbaa !29
  %t985 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t984, { i64, ptr } %t985)
  br label %bb287
bb286:
  br label %bb289
bb287:
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t989 = load %"compiler/source:Span", ptr %l1
  %t992 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t988, %"compiler/source:Span" %t989)
  store ptr %t992, ptr %l508
  br label %bb288
bb288:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t993 = load ptr, ptr %l508, !tbaa !29
  store ptr %t993, ptr %rv
  br label %ret
bb289:
  %t994 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t996 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s19, { i64, ptr } %t994, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t996, ptr %l510
  br label %bb290
bb290:
  %t997 = load i1, ptr %l510, !tbaa !21
  br i1 %t997, label %bb291, label %bb292
bb291:
  store i1 true, ptr %l511, !tbaa !21
  br label %bb294
bb292:
  %t998 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t1000 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s19, { i64, ptr } %t998, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t1000, ptr %l513
  br label %bb293
bb293:
  %t1001 = load i1, ptr %l513, !tbaa !21
  store i1 %t1001, ptr %l511, !tbaa !21
  br label %bb294
bb294:
  %t1002 = load i1, ptr %l511, !tbaa !21
  br i1 %t1002, label %bb295, label %bb296
bb295:
  store %olang.scope zeroinitializer, ptr %s25
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1004 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s25, ptr %t1003, %"compiler/source:Span" %t1004, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb297
bb296:
  store %olang.scope zeroinitializer, ptr %s26
  %t1007 = load i32, ptr %l20, !tbaa !23
  store i32 %t1007, ptr %l516, !tbaa !23
  %t1008 = load ptr, ptr %l0, !tbaa !29
  %t1010 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %t1008)
  store i32 %t1010, ptr %l518
  br label %bb298
bb297:
  call void @__olang_scope_close(ptr %s25)
  br label %bb319
bb298:
  %t1011 = load i32, ptr %l516, !tbaa !23
  %t1012 = load i32, ptr %l518, !tbaa !23
  %t1013 = icmp eq i32 %t1011, %t1012
  br i1 %t1013, label %bb299, label %bb300
bb299:
  %t1015 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t1017 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s26, { i64, ptr } %t1015, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t1017, ptr %l522
  br label %bb301
bb300:
  store i1 false, ptr %l520, !tbaa !21
  br label %bb306
bb301:
  %t1018 = load i1, ptr %l522, !tbaa !21
  br i1 %t1018, label %bb302, label %bb303
bb302:
  store i1 true, ptr %l523, !tbaa !21
  br label %bb305
bb303:
  %t1019 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t1021 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s26, { i64, ptr } %t1019, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t1021, ptr %l525
  br label %bb304
bb304:
  %t1022 = load i1, ptr %l525, !tbaa !21
  store i1 %t1022, ptr %l523, !tbaa !21
  br label %bb305
bb305:
  %t1023 = load i1, ptr %l523, !tbaa !21
  store i1 %t1023, ptr %l520, !tbaa !21
  br label %bb306
bb306:
  %t1024 = load i1, ptr %l520, !tbaa !21
  br i1 %t1024, label %bb307, label %bb308
bb307:
  store %olang.scope zeroinitializer, ptr %s27
  %t1025 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1025, ptr %l526, !tbaa !29
  %t1026 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1026, ptr %l527
  %t1027 = load ptr, ptr %l0, !tbaa !29
  %t1028 = load i32, ptr %l3, !tbaa !23
  %t1031 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s27, ptr %t1027, i32 %t1028)
  store { i64, ptr } %t1031, ptr %l530
  br label %bb309
bb308:
  store %olang.scope zeroinitializer, ptr %s28
  %t1032 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1032, ptr %l535, !tbaa !29
  %t1033 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1033, ptr %l536
  %t1034 = load i32, ptr %l10, !tbaa !23
  store i32 %t1034, ptr %l537, !tbaa !23
  %t1035 = load ptr, ptr %l0, !tbaa !29
  %t1036 = load i32, ptr %l3, !tbaa !23
  %t1039 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s28, ptr %t1035, i32 %t1036)
  store { i64, ptr } %t1039, ptr %l540
  br label %bb312
bb309:
  %t1040 = load { i64, ptr }, ptr %l530, !tbaa !27
  %t1041 = extractvalue { i64, ptr } %t1040, 0
  %t1042 = extractvalue { i64, ptr } %t1040, 1
  %t1043 = mul i64 %t1041, 1
  %t1044 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t1043)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1044, ptr %t1042, i64 %t1043, i1 false)
  %t1045 = insertvalue { i64, ptr } undef, i64 %t1041, 0
  %t1046 = insertvalue { i64, ptr } %t1045, ptr %t1044, 1
  %t1047 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t1050 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCharNoPad(ptr %s27, ptr %v4, ptr %s27, { i64, ptr } %t1046, { i64, ptr } %t1047)
  store %"compiler/msgs:Msg" %t1050, ptr %l533
  br label %bb310
bb310:
  %t1051 = load ptr, ptr %l526, !tbaa !29
  %t1052 = load %"compiler/source:Span", ptr %l527
  %t1053 = load %"compiler/msgs:Msg", ptr %l533
  %t1054 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s27, ptr %t1051, %"compiler/source:Span" %t1052, %"compiler/msgs:Msg" %t1053)
  store i64 %t1054, ptr %l534
  br label %bb311
bb311:
  call void @__olang_scope_close(ptr %s27)
  br label %bb318
bb312:
  %t1055 = load { i64, ptr }, ptr %l540, !tbaa !27
  %t1056 = extractvalue { i64, ptr } %t1055, 1
  %t1057 = extractvalue { i64, ptr } %t1055, 0
  %t1058 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1057)
  call void @olang_textcopy(ptr %t1058, ptr %t1056, i64 %t1057)
  %t1059 = insertvalue { i64, ptr } undef, i64 %t1057, 0
  %t1060 = insertvalue { i64, ptr } %t1059, ptr %t1058, 1
  %t1062 = extractvalue { i64, ptr } %t1060, 0
  %t1063 = extractvalue { i64, ptr } %t1060, 1
  %t1064 = mul i64 %t1062, 1
  %t1065 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1064)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1065, ptr %t1063, i64 %t1064, i1 false)
  %t1066 = insertvalue { i64, ptr } undef, i64 %t1062, 0
  %t1067 = insertvalue { i64, ptr } %t1066, ptr %t1065, 1
  store { i64, ptr } %t1067, ptr %l542, !tbaa !27
  %t1068 = load ptr, ptr %l0, !tbaa !29
  %t1069 = load i32, ptr %l10, !tbaa !23
  %t1072 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s28, ptr %t1068, i32 %t1069)
  store { i64, ptr } %t1072, ptr %l545
  br label %bb313
bb313:
  %t1073 = load { i64, ptr }, ptr %l545, !tbaa !27
  %t1074 = extractvalue { i64, ptr } %t1073, 0
  %t1075 = extractvalue { i64, ptr } %t1073, 1
  %t1076 = mul i64 %t1074, 1
  %t1077 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1076)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1077, ptr %t1075, i64 %t1076, i1 false)
  %t1078 = insertvalue { i64, ptr } undef, i64 %t1074, 0
  %t1079 = insertvalue { i64, ptr } %t1078, ptr %t1077, 1
  store { i64, ptr } %t1079, ptr %l546, !tbaa !27
  %t1080 = load ptr, ptr %l0, !tbaa !29
  %t1081 = load i32, ptr %l3, !tbaa !23
  %t1084 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s28, ptr %t1080, i32 %t1081)
  store { i64, ptr } %t1084, ptr %l549
  br label %bb314
bb314:
  %t1085 = load { i64, ptr }, ptr %l549, !tbaa !27
  %t1086 = extractvalue { i64, ptr } %t1085, 0
  %t1087 = extractvalue { i64, ptr } %t1085, 1
  %t1088 = mul i64 %t1086, 1
  %t1089 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1088)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1089, ptr %t1087, i64 %t1088, i1 false)
  %t1090 = insertvalue { i64, ptr } undef, i64 %t1086, 0
  %t1091 = insertvalue { i64, ptr } %t1090, ptr %t1089, 1
  store { i64, ptr } %t1091, ptr %l550, !tbaa !27
  %t1092 = load ptr, ptr %l0, !tbaa !29
  %t1093 = load i32, ptr %l10, !tbaa !23
  %t1094 = load i32, ptr %l3, !tbaa !23
  %t1098 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberHint(ptr %v0, ptr %s28, ptr %t1092, i32 %t1093, i32 %t1094, i1 true)
  store { i64, ptr } %t1098, ptr %l554
  br label %bb315
bb315:
  %t1099 = load { i64, ptr }, ptr %l554, !tbaa !27
  %t1100 = extractvalue { i64, ptr } %t1099, 0
  %t1101 = extractvalue { i64, ptr } %t1099, 1
  %t1102 = mul i64 %t1100, 1
  %t1103 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1103, ptr %t1101, i64 %t1102, i1 false)
  %t1104 = insertvalue { i64, ptr } undef, i64 %t1100, 0
  %t1105 = insertvalue { i64, ptr } %t1104, ptr %t1103, 1
  %t1106 = load { i64, ptr }, ptr %l546, !tbaa !27
  %t1107 = load { i64, ptr }, ptr %l550, !tbaa !27
  %t1109 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %s28, ptr %s28, ptr %s28, ptr %s28, { i64, ptr } %t1106, { i64, ptr } %t1107, { i64, ptr } %t1105)
  store %"compiler/msgs:Msg" %t1109, ptr %l556
  br label %bb316
bb316:
  %t1110 = load ptr, ptr %l535, !tbaa !29
  %t1111 = load %"compiler/source:Span", ptr %l536
  %t1112 = load i32, ptr %l537, !tbaa !23
  %t1113 = load { i64, ptr }, ptr %l542, !tbaa !27
  %t1114 = load %"compiler/msgs:Msg", ptr %l556
  %t1115 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s28, ptr %s28, ptr %t1110, %"compiler/source:Span" %t1111, i32 %t1112, { i64, ptr } %t1113, %"compiler/msgs:Msg" %t1114)
  store i64 %t1115, ptr %l557
  br label %bb317
bb317:
  call void @__olang_scope_close(ptr %s28)
  br label %bb318
bb318:
  call void @__olang_scope_close(ptr %s26)
  br label %bb319
bb319:
  %t1116 = load ptr, ptr %l0, !tbaa !29
  %t1117 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t1116, { i64, ptr } %t1117)
  br label %bb320
bb320:
  %t1120 = load ptr, ptr %l0, !tbaa !29
  %t1121 = load %"compiler/source:Span", ptr %l1
  %t1124 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t1120, %"compiler/source:Span" %t1121)
  store ptr %t1124, ptr %l562
  br label %bb321
bb321:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t1125 = load ptr, ptr %l562, !tbaa !29
  store ptr %t1125, ptr %rv
  br label %ret
bb322:
  %t1126 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t1126, ptr %l563, !tbaa !27
  %t1127 = getelementptr { i64, ptr }, ptr %l563, i32 0, i32 1
  %t1128 = load ptr, ptr %t1127, !tbaa !27
  %t1129 = getelementptr i8, ptr %t1128, i64 0
  %t1130 = load i8, ptr %t1129, !tbaa !32
  %t1132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t1130)
  store i1 %t1132, ptr %l565
  br label %bb323
bb323:
  %t1133 = load i1, ptr %l565, !tbaa !21
  %t1134 = xor i1 %t1133, true
  br i1 %t1134, label %bb324, label %bb325
bb324:
  %t1136 = load ptr, ptr %l0, !tbaa !29
  %t1138 = getelementptr %"compiler/check:Checker", ptr %t1136, i32 0, i32 1
  %t1139 = load ptr, ptr %t1138, !tbaa !29
  %t1140 = load i64, ptr %l17, !tbaa !24
  %t1143 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t1139, i64 %t1140)
  store i64 %t1143, ptr %l571
  br label %bb326
bb325:
  store i1 false, ptr %l567, !tbaa !21
  br label %bb328
bb326:
  %t1144 = load ptr, ptr %l0, !tbaa !29
  %t1146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1144)
  store ptr %t1146, ptr %l573
  br label %bb327
bb327:
  %t1147 = load ptr, ptr %l573, !tbaa !29
  %t1149 = getelementptr %"compiler/check:frame", ptr %t1147, i32 0, i32 1
  %t1150 = load i64, ptr %t1149, !tbaa !24
  %t1151 = load i64, ptr %l571, !tbaa !24
  %t1153 = icmp ne i64 %t1151, %t1150
  store i1 %t1153, ptr %l567, !tbaa !21
  br label %bb328
bb328:
  %t1155 = load i1, ptr %l567, !tbaa !21
  br i1 %t1155, label %bb329, label %bb330
bb329:
  store %olang.scope zeroinitializer, ptr %s30
  %t1156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1156, ptr %l577, !tbaa !29
  %t1157 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1157, ptr %l578
  %t1158 = load ptr, ptr %l0, !tbaa !29
  %t1159 = load i32, ptr %l3, !tbaa !23
  %t1162 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s30, ptr %t1158, i32 %t1159)
  store { i64, ptr } %t1162, ptr %l581
  br label %bb331
bb330:
  br label %bb334
bb331:
  %t1163 = load { i64, ptr }, ptr %l581, !tbaa !27
  %t1164 = extractvalue { i64, ptr } %t1163, 0
  %t1165 = extractvalue { i64, ptr } %t1163, 1
  %t1166 = mul i64 %t1164, 1
  %t1167 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t1166)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1167, ptr %t1165, i64 %t1166, i1 false)
  %t1168 = insertvalue { i64, ptr } undef, i64 %t1164, 0
  %t1169 = insertvalue { i64, ptr } %t1168, ptr %t1167, 1
  %t1171 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %s30, ptr %s30, { i64, ptr } %t1169)
  store %"compiler/msgs:Msg" %t1171, ptr %l583
  br label %bb332
bb332:
  %t1172 = load ptr, ptr %l577, !tbaa !29
  %t1173 = load %"compiler/source:Span", ptr %l578
  %t1174 = load %"compiler/msgs:Msg", ptr %l583
  %t1175 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s30, ptr %t1172, %"compiler/source:Span" %t1173, %"compiler/msgs:Msg" %t1174)
  store i64 %t1175, ptr %l584
  br label %bb333
bb333:
  call void @__olang_scope_close(ptr %s30)
  br label %bb334
bb334:
  %t1176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1176, ptr %l585, !tbaa !29
  %t1177 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1177, ptr %l586
  %t1178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1178, ptr %l587, !tbaa !29
  %t1179 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1179, ptr %l588
  %t1180 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1180, ptr %l589
  %t1181 = load i64, ptr %l17, !tbaa !24
  store i64 %t1181, ptr %l590, !tbaa !24
  %t1182 = load ptr, ptr %l9, !tbaa !29
  store ptr %t1182, ptr %l592, !tbaa !29
  %t1184 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1184, ptr %l593, !tbaa !27
  %t1185 = icmp sge i64 0, 0
  br i1 %t1185, label %bb335, label %bb336
bb335:
  %t1187 = icmp sle i64 0, 1152921504606846975
  br i1 %t1187, label %bb337, label %bb338
bb336:
  call void @__olang_check_failed(ptr @olang_loc_97297cf958301a5_897be3a3c1a33231)
  unreachable
bb337:
  %t1189 = mul i64 0, 8
  %t1190 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1191 = insertvalue { i64, ptr } %t1190, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1191, ptr %l596, !tbaa !27
  %t1192 = icmp sge i64 0, 0
  br i1 %t1192, label %bb339, label %bb340
bb338:
  call void @__olang_check_failed(ptr @olang_loc_97297cf958301a5_897be3a3c1a33231)
  unreachable
bb339:
  %t1194 = icmp sle i64 0, 2305843009213693951
  br i1 %t1194, label %bb341, label %bb342
bb340:
  call void @__olang_check_failed(ptr @olang_loc_f4ec2e4bc4870738_831a294d3dfd1224)
  unreachable
bb341:
  %t1196 = mul i64 0, 4
  %t1197 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1198 = insertvalue { i64, ptr } %t1197, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1199 = load ptr, ptr %l587, !tbaa !29
  %t1200 = load %"compiler/source:Span", ptr %l588
  %t1201 = load %"compiler/source:Span", ptr %l589
  %t1202 = load i64, ptr %l590, !tbaa !24
  %t1203 = load ptr, ptr %l592, !tbaa !29
  %t1204 = load { i64, ptr }, ptr %l593, !tbaa !27
  %t1205 = load { i64, ptr }, ptr %l596, !tbaa !27
  %t1207 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v4, ptr %v2, ptr %v0, ptr %v0, ptr %v0, ptr %t1199, %"compiler/source:Span" %t1200, %"compiler/source:Span" %t1201, i64 %t1202, ptr %t1203, { i64, ptr } %t1204, { i64, ptr } %t1205, { i64, ptr } %t1198)
  store ptr %t1207, ptr %l600
  br label %bb343
bb342:
  call void @__olang_check_failed(ptr @olang_loc_f4ec2e4bc4870738_831a294d3dfd1224)
  unreachable
bb343:
  %t1208 = load ptr, ptr %l585, !tbaa !29
  %t1209 = load %"compiler/source:Span", ptr %l586
  %t1210 = load ptr, ptr %l600, !tbaa !29
  %t1211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlaceCall(ptr %v0, ptr %v0, ptr %v4, ptr %t1208, %"compiler/source:Span" %t1209, ptr %t1210)
  store ptr %t1211, ptr %l601
  br label %bb344
bb344:
  call void @__olang_scope_close(ptr %s0)
  %t1212 = load ptr, ptr %l601, !tbaa !29
  store ptr %t1212, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emodOfFile(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l42 = alloca ptr
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l12
  br label %bb1
bb1:
  %t12 = load i64, ptr %l12, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l19, !tbaa !24
  store i64 %t39, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l16, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 10
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l42
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  %t79 = icmp eq i64 %t75, %a1
  br i1 %t79, label %bb13, label %bb14
bb13:
  %t81 = load i64, ptr %l7, !tbaa !24
  store i64 %t81, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca %"compiler/names:Ref"
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t8)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t20 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t17, i64 %t14, i32 %t16)
  store %"compiler/names:Ref" %t20, ptr %l11
  br label %bb2
bb2:
  %t21 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 0
  %t22 = load i32, ptr %t21, !range !{i32 0, i32 9}
  store i32 %t22, ptr %l2
  %t24 = load i32, ptr %l2, !range !{i32 0, i32 9}
  %t26 = trunc i64 1 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  %t29 = load i32, ptr %l2, !range !{i32 0, i32 9}
  %t31 = trunc i64 8 to i32
  %t32 = icmp eq i32 %t29, %t31
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l15, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i1
  %l21 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca %"compiler/names:Ref"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t23, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 2
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp ne i64 %t35, 1
  br i1 %t37, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp sgt i64 %t41, 0
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l28, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t54)
  store ptr %t56, ptr %l30
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 2
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load ptr, ptr %l28, !tbaa !29
  %t66 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t63, i64 %t60, i32 %t62)
  store %"compiler/names:Ref" %t66, ptr %l34
  br label %bb16
bb16:
  %t67 = getelementptr %"compiler/names:Ref", ptr %l34, i32 0, i32 0
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 9}
  %t70 = trunc i64 8 to i32
  %t71 = icmp eq i32 %t68, %t70
  store i1 %t71, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_968ede9ca4457b20_d4cd8e7344b6f50c)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedWrite(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/check:narrowed"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/check:narrowed"
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l24 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca ptr
  %l42 = alloca ptr
  %l46 = alloca %"compiler/typed:Local"
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/msgs:Msg"
  %l51 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 46
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOwner(ptr %v0, ptr %t7, i64 %a2)
  store i64 %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t12, i64 %t13)
  store %"compiler/check:narrowed" %t14, ptr %l14
  br label %bb3
bb3:
  %t15 = load %"compiler/check:narrowed", ptr %l14
  store %"compiler/check:narrowed" %t15, ptr %l3
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t25, i32 %t27)
  store i32 %t30, ptr %l21
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = load i32, ptr %l21, !tbaa !23
  %t33 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t31, i32 %t32)
  store ptr %t33, ptr %l22
  br label %bb5
bb5:
  %t34 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v0, ptr %t36, i64 %t35)
  store ptr %t38, ptr %l24
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l24, !tbaa !29
  store ptr %t39, ptr %l4, !tbaa !29
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t49 = getelementptr %"compiler/ast:CaseDecl", ptr %t47, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t46, i32 %t50)
  store { i64, ptr } %t53, ptr %l32
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l28, !tbaa !27
  br label %bb10
bb9:
  %t54 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t54, ptr %l28, !tbaa !27
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t55, ptr %l5, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 2
  %t58 = load i32, ptr %t57, !tbaa !23
  %t61 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t56, i32 %t58)
  store { i64, ptr } %t61, ptr %l35
  br label %bb11
bb11:
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t70 = extractvalue { i64, ptr } %t62, 1
  %t71 = extractvalue { i64, ptr } %t62, 0
  %t72 = add i64 %t68, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t64, i64 %t65)
  %t74 = getelementptr i8, ptr %t73, i64 %t65
  call void @olang_textcopy(ptr %t74, ptr %t66, i64 %t67)
  %t75 = getelementptr i8, ptr %t74, i64 %t67
  call void @olang_textcopy(ptr %t75, ptr %t70, i64 %t71)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t73, 1
  store { i64, ptr } %t77, ptr %l6, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l38, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l39
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l40, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t82)
  store ptr %t84, ptr %l42
  br label %bb12
bb12:
  %t85 = load ptr, ptr %l42, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 7
  %t88 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 0
  %t89 = load i64, ptr %t88, !tbaa !24
  %t92 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t87, i64 %t89)
  store %"compiler/typed:Local" %t92, ptr %l46
  br label %bb13
bb13:
  %t93 = getelementptr %"compiler/typed:Local", ptr %l46, i32 0, i32 0
  %t94 = load i32, ptr %t93, !tbaa !23
  %t95 = load ptr, ptr %l40, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t95, i32 %t94)
  store { i64, ptr } %t97, ptr %l48
  br label %bb14
bb14:
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t101 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowedWrite(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t99, { i64, ptr } %t98)
  store %"compiler/msgs:Msg" %t101, ptr %l50
  br label %bb15
bb15:
  %t102 = load ptr, ptr %l38, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l39
  %t104 = load %"compiler/msgs:Msg", ptr %l50
  %t105 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t102, %"compiler/source:Span" %t103, %"compiler/msgs:Msg" %t104)
  store i64 %t105, ptr %l51
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca %"compiler/msgs:Nearest"
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca %"compiler/msgs:Msg"
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l17
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t18)
  store %"compiler/msgs:Nearest" %t20, ptr %l19
  br label %bb3
bb3:
  %t21 = load %"compiler/msgs:Nearest", ptr %l19
  %t22 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t21, ptr %t22
  store ptr %t22, ptr %l5, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l8, !tbaa !24
  br label %bb6
bb5:
  br label %bb14
bb6:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i32, ptr %t48, i64 %t45
  %t50 = load i32, ptr %t49, !tbaa !33
  %t52 = load ptr, ptr %l5, !tbaa !29
  store ptr %t52, ptr %l34, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t57 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t53, i32 %t50)
  store { i64, ptr } %t57, ptr %l37
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l34, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t58, { i64, ptr } %t59)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb6
bb13:
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"compiler/msgs:Nearest", ptr %t64, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t73, i32 %t74)
  store { i64, ptr } %t77, ptr %l46
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t78 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l47, !tbaa !27
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l2, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %t85, i32 %t86)
  store { i64, ptr } %t89, ptr %l50
  br label %bb18
bb18:
  %t90 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/msgs:Nearest", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t104 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v1, ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %t101, { i64, ptr } %t96, { i64, ptr } %t100)
  store %"compiler/msgs:Msg" %t104, ptr %l54
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t105 = load %"compiler/msgs:Msg", ptr %l54
  store %"compiler/msgs:Msg" %t105, ptr %rv
  br label %ret
bb20:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l1, !tbaa !23
  %t110 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t106, i32 %t107)
  store { i64, ptr } %t110, ptr %l57
  br label %bb21
bb21:
  %t111 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l58, !tbaa !27
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l2, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %t118, i32 %t119)
  store { i64, ptr } %t122, ptr %l61
  br label %bb22
bb22:
  %t123 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t132 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t130, { i64, ptr } %t129)
  store %"compiler/msgs:Msg" %t132, ptr %l63
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t133 = load %"compiler/msgs:Msg", ptr %l63
  store %"compiler/msgs:Msg" %t133, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 true)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotStmtSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 98}
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t24, i32 0, i32 3
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t29)
  store %"compiler/source:Span" %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l21
  br label %bb7
bb7:
  %t35 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t37 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s1, i32 %t35)
  store { i64, ptr } %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l19
  %t42 = load %"compiler/source:Span", ptr %l21
  %t44 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t40, %"compiler/source:Span" %t41, %"compiler/source:Span" %t42, i64 %t39)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t45 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t45, ptr %rv
  br label %ret
bb10:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 30}
  %t53 = icmp eq i64 %t51, 14
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l5
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t63, i32 0, i32 2
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l6, !tbaa !23
  br label %bb15
bb14:
  br label %bb18
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t67 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t67, ptr %l34
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l6, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l37
  br label %bb16
bb16:
  %t73 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = load %"compiler/source:Span", ptr %l34
  %t77 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t75, i64 %t74)
  store %"compiler/source:Span" %t77, ptr %l39
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t78 = load %"compiler/source:Span", ptr %l39
  store %"compiler/source:Span" %t78, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t79)
  store %"compiler/source:Span" %t81, ptr %l41
  br label %bb22
bb22:
  %t82 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t82, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4d0d10dbd8c28898_8d57e58513238834)
  unreachable
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/msgs:Msg" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca i64
  %l25 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l41 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i32
  %l69 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i64
  %l86 = alloca ptr
  %t188 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l19
  br label %bb2
bb2:
  %t18 = load i64, ptr %l19, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 10
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l25
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 6
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f66b04275832bdf5_49261566e6ebbc09)
  unreachable
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l7, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t47, i32 %t51)
  store { i64, ptr } %t54, ptr %l36
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t55, ptr %l8, !tbaa !27
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Func", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb8, label %bb9
bb8:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb10, label %bb11
bb9:
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 0
  %t75 = getelementptr %"compiler/source:Span", ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  store i64 %t78, ptr %l41, !tbaa !24
  br label %bb13
bb10:
  call void @__olang_check_failed(ptr @olang_loc_959932aa8b846e4e_2c1999e37dfb1a2)
  unreachable
bb11:
  br label %bb12
bb12:
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Param", ptr %t83, i32 0, i32 0
  %t87 = getelementptr %"compiler/source:Span", ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87, !tbaa !23
  %t90 = sext i32 %t88 to i64
  store i64 %t90, ptr %l41, !tbaa !24
  br label %bb13
bb13:
  %t92 = load i64, ptr %l41, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t93, ptr %l54, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  store i64 %t94, ptr %l55, !tbaa !24
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 0
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 1
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  store i64 %t101, ptr %l58, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l59, !tbaa !24
  %t104 = load i64, ptr %l55, !tbaa !24
  %t105 = icmp sge i64 %t104, 0
  br i1 %t105, label %bb14, label %bb15
bb14:
  %t107 = load i64, ptr %l55, !tbaa !24
  %t108 = load i64, ptr %l58, !tbaa !24
  %t109 = icmp sle i64 %t107, %t108
  br i1 %t109, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb16:
  %t111 = load i64, ptr %l58, !tbaa !24
  %t112 = load i64, ptr %l59, !tbaa !24
  %t113 = icmp sle i64 %t111, %t112
  br i1 %t113, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb18:
  %t115 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l55, !tbaa !24
  %t118 = load i64, ptr %l58, !tbaa !24
  %t119 = getelementptr i8, ptr %t116, i64 %t117
  %t120 = sub i64 %t118, %t117
  %t121 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  %t123 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t126 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t122, { i64, ptr } %t123)
  %t127 = extractvalue { i32, i64 } %t126, 1
  %t128 = extractvalue { i32, i64 } %t126, 0
  store i32 %t128, ptr %l66
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb21, label %ok.130, !prof !99
ok.130:
  store i64 %t127, ptr %l65
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb20:
  %t131 = load i64, ptr %l65, !tbaa !24
  store i64 %t131, ptr %l53, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb23
bb23:
  %t132 = load i64, ptr %l53, !tbaa !24
  store i64 %t132, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = icmp slt i64 %t133, 0
  br i1 %t135, label %bb24, label %bb25
bb24:
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Func", ptr %t137, i32 0, i32 0
  %t140 = getelementptr %"compiler/source:Span", ptr %t139, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  store i64 %t143, ptr %l69, !tbaa !24
  br label %bb26
bb25:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = add i64 %t145, %t146
  store i64 %t149, ptr %l69, !tbaa !24
  br label %bb26
bb26:
  %t151 = load i64, ptr %l69, !tbaa !24
  store i64 %t151, ptr %l11, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/load:Loader", ptr %t158, i32 0, i32 4
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l79, !tbaa !29
  store i64 %a1, ptr %l80, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/load:Loader", ptr %t169, i32 0, i32 10
  %t172 = load i64, ptr %l5, !tbaa !24
  %t175 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t171, i64 %t172)
  store ptr %t175, ptr %l86
  br label %bb27
bb27:
  %t176 = load ptr, ptr %l86, !tbaa !29
  %t178 = getelementptr %"compiler/load:Module", ptr %t176, i32 0, i32 4
  %t179 = load i64, ptr %t178, !tbaa !24
  %t180 = load i64, ptr %l11, !tbaa !24
  %t181 = load i64, ptr %l11, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t187 = add i64 %t181, %t184
  store { i64, [3 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 0
  store i64 3, ptr %t189
  %t191 = insertvalue { i64, i64, i64 } undef, i64 %t179, 0
  %t193 = insertvalue { i64, i64, i64 } %t191, i64 %t180, 1
  %t195 = insertvalue { i64, i64, i64 } %t193, i64 %t187, 2
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  store { i64, i64, i64 } %t195, ptr %t196
  %t197 = load { i64, [3 x i64] }, ptr %t188
  %t199 = load ptr, ptr %l79, !tbaa !29
  %t200 = load i64, ptr %l80, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %t199, i64 %t200, { i64, [3 x i64] } %t197, %"compiler/msgs:Msg" %a3)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb9
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 129
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t19)
  store ptr %t21, ptr %l12
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i32, ptr %l2, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s1, i64 %t25, i64 %t28)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, ptr %l17
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l10, !tbaa !29
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33, i1 true)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_bb9360f661a84828_a83eb458d7764d44)
  unreachable
bb14:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonce(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l36 = alloca i32
  %l37 = alloca i64
  %l49 = alloca ptr
  %rv = alloca ptr
  %t78 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %rv
  br label %ret
bb6:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 18}
  %t19 = icmp eq i64 %t17, 2
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb12, label %bb13
bb12:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 8}
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb14:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t38, i32 0, i32 0
  %t40 = load %"compiler/source:Span", ptr %t39
  store %"compiler/source:Span" %t40, ptr %l3
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t44, i32 0, i32 1
  %t46 = load i32, ptr %t45
  store i32 %t46, ptr %l4, !tbaa !23
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t50, i32 0, i32 2
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l5, !tbaa !23
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9e3e60c51c241998_753bf57c496fa07c)
  unreachable
bb22:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t56)
  store %"compiler/source:Span" %t58, ptr %l31
  br label %bb23
bb23:
  %t59 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t59, ptr %l6
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l32, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t61, ptr %l33
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t65 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t62)
  store i32 %t65, ptr %l36
  br label %bb24
bb24:
  %t66 = load ptr, ptr %l32, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l33
  %t68 = load i32, ptr %l36, !tbaa !23
  %t69 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t66, %"compiler/source:Span" %t67, i32 %t68)
  store i64 %t69, ptr %l37
  br label %bb25
bb25:
  %t70 = load i64, ptr %l37, !tbaa !24
  store i64 %t70, ptr %l7, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l6
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = trunc i64 %t73 to i32
  %t77 = load ptr, ptr %l1, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t81 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t72, 0
  %t83 = insertvalue { %"compiler/source:Span", i32, ptr } %t81, i32 %t75, 1
  %t85 = insertvalue { %"compiler/source:Span", i32, ptr } %t83, ptr %t77, 2
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t85, ptr %t86
  %t87 = load { i64, [3 x i64] }, ptr %t78
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t87, ptr %t89
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t71, ptr %t89)
  br label %bb26
bb26:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l6
  %t94 = load i64, ptr %l7, !tbaa !24
  %t98 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t92, %"compiler/source:Span" %t93, i64 %t94)
  store ptr %t98, ptr %l49
  br label %bb27
bb27:
  %t99 = load ptr, ptr %l49, !tbaa !29
  store ptr %t99, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverflowsF64(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/check:litv"
  %l7 = alloca %"compiler/check:litv"
  %l8 = alloca { ptr, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l34 = alloca %"compiler/check:litv"
  %l38 = alloca %"compiler/check:litv"
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverflowsF64(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l17
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i1, ptr %l17, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 30}
  %t29 = icmp eq i64 %t27, 5
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 98}
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb23
bb12:
  %t49 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t51 = trunc i64 56 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t60 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t55, ptr %t56)
  store %"compiler/check:litv" %t60, ptr %l34
  br label %bb16
bb16:
  %t61 = load %"compiler/check:litv", ptr %l34
  store %"compiler/check:litv" %t61, ptr %l6
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t67 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store %"compiler/check:litv" %t67, ptr %l38
  br label %bb17
bb17:
  %t68 = load %"compiler/check:litv", ptr %l38
  store %"compiler/check:litv" %t68, ptr %l7
  %t69 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_40, 0
  %t70 = insertvalue { ptr, ptr } %t69, ptr null, 1
  store { ptr, ptr } %t70, ptr %l8
  %t72 = load { ptr, ptr }, ptr %l8
  %t73 = load %"compiler/check:litv", ptr %l6
  %t75 = extractvalue { ptr, ptr } %t72, 0
  %t76 = extractvalue { ptr, ptr } %t72, 1
  %t78 = call i1 %t75(ptr %t76, %"compiler/check:litv" %t73)
  store i1 %t78, ptr %l42
  br label %bb18
bb18:
  %t79 = load i1, ptr %l42, !tbaa !21
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t80 = load { ptr, ptr }, ptr %l8
  %t81 = load %"compiler/check:litv", ptr %l7
  %t83 = extractvalue { ptr, ptr } %t80, 0
  %t84 = extractvalue { ptr, ptr } %t80, 1
  %t86 = call i1 %t83(ptr %t84, %"compiler/check:litv" %t81)
  store i1 %t86, ptr %l46
  br label %bb21
bb20:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb22
bb21:
  %t87 = load i1, ptr %l46, !tbaa !21
  store i1 %t87, ptr %l43, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load i1, ptr %l43, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @olang_loc_2c067c0920238e9c_6231d620e5a2e328)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:Local"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca %"compiler/typed:Local"
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l63 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = trunc i64 %t4 to i32
  %t8 = load ptr, ptr %l11, !tbaa !29
  %t10 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t8, i32 %t6)
  store %"compiler/typed:Local" %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load %"compiler/typed:Local", ptr %l15
  store %"compiler/typed:Local" %t11, ptr %l2
  %t12 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t13 = load i32, ptr %t12, !range !{i32 0, i32 7}
  %t15 = trunc i64 0 to i32
  %t16 = icmp eq i32 %t13, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t22)
  store i1 %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load i1, ptr %l22, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t30 = load i32, ptr %t29, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t28, i32 %t30)
  store i1 %t33, ptr %l26
  br label %bb9
bb9:
  %t34 = load i1, ptr %l26, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t39)
  store ptr %t41, ptr %l30
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l30, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Body", ptr %t42, i32 0, i32 5
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l32
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l34
  br label %bb15
bb15:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t50, ptr %l36
  br label %bb16
bb16:
  %t51 = load i64, ptr %l36, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = icmp sgt i64 %t52, %t53
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t60 = icmp sgt i64 %t58, 0
  br i1 %t60, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb22
bb19:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = add i64 %t66, %t67
  %t72 = sub i64 %t70, 1
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = sdiv i64 %t72, %t73
  store i64 %t76, ptr %l43, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb21
bb21:
  %t78 = load i64, ptr %l43, !tbaa !24
  store i64 %t78, ptr %l40, !tbaa !24
  br label %bb22
bb22:
  %t79 = load i64, ptr %l40, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb23
bb23:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb24, label %bb25
bb24:
  br label %bb32
bb25:
  br label %bb26
bb26:
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = mul i64 %t89, %t90
  %t96 = add i64 %t88, %t93
  store i64 %t96, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 %t98)
  store i32 %t101, ptr %l63
  br label %bb27
bb27:
  %t102 = load i32, ptr %l63, !tbaa !23
  %t103 = sext i32 %t102 to i64
  %t104 = load i64, ptr %l1, !tbaa !24
  %t107 = icmp eq i64 %t103, %t104
  br i1 %t107, label %bb28, label %bb29
bb28:
  %t109 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t109, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb23
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca %"compiler/names:Ref"
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l45 = alloca %"compiler/names:Ref"
  %l48 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca %"compiler/source:Span"
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca %"compiler/msgs:Msg"
  %l67 = alloca i64
  %l72 = alloca i1
  %l75 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i1
  %l89 = alloca ptr
  %l96 = alloca ptr
  %l100 = alloca i64
  %l103 = alloca i64
  %l105 = alloca %"compiler/source:Span"
  %l108 = alloca i32
  %l112 = alloca ptr
  %l116 = alloca i32
  %l120 = alloca %"compiler/source:Span"
  %l123 = alloca i32
  %l132 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l140 = alloca i32
  %l145 = alloca ptr
  %l146 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca ptr
  %l155 = alloca i1
  %l166 = alloca ptr
  %l168 = alloca ptr
  %l172 = alloca %"compiler/names:Ref"
  %l175 = alloca %"compiler/source:Span"
  %l179 = alloca i32
  %l186 = alloca i1
  %l189 = alloca i32
  %l194 = alloca i64
  %l197 = alloca %"compiler/source:Span"
  %l200 = alloca i32
  %l204 = alloca ptr
  %l208 = alloca i32
  %l213 = alloca ptr
  %l217 = alloca ptr
  %l218 = alloca %"compiler/source:Span"
  %l219 = alloca %"compiler/source:Span"
  %l222 = alloca { i64, ptr }
  %l224 = alloca %"compiler/source:Span"
  %l227 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca i1
  %l240 = alloca i32
  %l242 = alloca i1
  %l245 = alloca %"compiler/check:reflList"
  %l252 = alloca ptr
  %l253 = alloca ptr
  %l254 = alloca i1
  %l257 = alloca i1
  %l259 = alloca ptr
  %l260 = alloca i1
  %l278 = alloca { i64, ptr }
  %l279 = alloca i1
  %l282 = alloca i32
  %l289 = alloca ptr
  %l290 = alloca %"compiler/source:Span"
  %l292 = alloca %"compiler/source:Span"
  %l295 = alloca ptr
  %l300 = alloca ptr
  %l303 = alloca i32
  %l309 = alloca ptr
  %l316 = alloca %"compiler/source:Span"
  %l317 = alloca i32
  %l318 = alloca ptr
  %l319 = alloca ptr
  %l320 = alloca i32
  %l322 = alloca %"compiler/source:Span"
  %l323 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  %t189 = alloca { i64, [4 x i64] }, align 8
  %t216 = alloca { i64, [4 x i64] }, align 8
  %t256 = alloca { i64, [4 x i64] }, align 8
  %t358 = alloca { i64, [4 x i64] }, align 8
  %t419 = alloca { i64, [4 x i64] }, align 8
  %t674 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 11
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 11
  store i1 false, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t10 = load ptr, ptr %l29, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l29, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 30}
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l30, !tbaa !21
  br label %bb2
bb2:
  %t17 = load i1, ptr %l30, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32 }, ptr %t20, i32 0, i32 0
  %t22 = load %"compiler/source:Span", ptr %t21
  store %"compiler/source:Span" %t22, ptr %l3
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32 }, ptr %t26, i32 0, i32 1
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb62
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l39, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t37)
  store ptr %t39, ptr %l41
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l41, !tbaa !29
  %t42 = getelementptr %"compiler/check:frame", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = load ptr, ptr %l39, !tbaa !29
  %t49 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t46, i64 %t43, i32 %t45)
  store %"compiler/names:Ref" %t49, ptr %l45
  br label %bb7
bb7:
  %t50 = load %"compiler/names:Ref", ptr %l45
  store %"compiler/names:Ref" %t50, ptr %l5
  %t51 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t52 = load i32, ptr %t51, !range !{i32 0, i32 9}
  %t54 = trunc i64 1 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb8, label %bb9
bb8:
  %t57 = load i1, ptr %l2, !tbaa !21
  store i1 %t57, ptr %l48, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb10
bb10:
  %t59 = load i1, ptr %l48, !tbaa !21
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l4, !tbaa !23
  %t64 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %t60, i32 %t61)
  store i64 %t64, ptr %l53
  br label %bb13
bb12:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb14
bb13:
  %t65 = load i64, ptr %l53, !tbaa !24
  %t66 = icmp sge i64 %t65, 0
  store i1 %t66, ptr %l50, !tbaa !21
  br label %bb14
bb14:
  %t68 = load i1, ptr %l50, !tbaa !21
  br i1 %t68, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %t69, i32 %t70)
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l57, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t74, ptr %l58
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l4, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s2, ptr %t75, i32 %t76)
  store { i64, ptr } %t79, ptr %l61
  br label %bb18
bb18:
  %t80 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l62, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l4, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t87, i32 %t88)
  store { i64, ptr } %t91, ptr %l65
  br label %bb19
bb19:
  %t92 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t94 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtAssigned(ptr %s2, ptr %v0, ptr %s2, { i64, ptr } %t92, { i64, ptr } %t93)
  store %"compiler/msgs:Msg" %t94, ptr %l66
  br label %bb20
bb20:
  %t95 = load ptr, ptr %l57, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l58
  %t97 = load %"compiler/msgs:Msg", ptr %l66
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t95, %"compiler/source:Span" %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l67
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb22:
  %t100 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t101 = load i32, ptr %t100, !range !{i32 0, i32 9}
  %t103 = trunc i64 1 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load i1, ptr %l2, !tbaa !21
  br i1 %t106, label %bb25, label %bb26
bb24:
  br label %bb57
bb25:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l4, !tbaa !23
  %t112 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t108, i32 %t109)
  store i64 %t112, ptr %l75
  br label %bb27
bb26:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb28
bb27:
  %t113 = load i64, ptr %l75, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  store i1 %t114, ptr %l72, !tbaa !21
  br label %bb28
bb28:
  %t116 = load i1, ptr %l72, !tbaa !21
  br i1 %t116, label %bb29, label %bb30
bb29:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l4, !tbaa !23
  %t121 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t117, i32 %t118)
  store i64 %t121, ptr %l80
  br label %bb31
bb30:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l4, !tbaa !23
  %t124 = load %"compiler/source:Span", ptr %l3
  %t128 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %t122, i32 %t123, %"compiler/source:Span" %t124)
  store i64 %t128, ptr %l84
  br label %bb32
bb31:
  %t129 = load i64, ptr %l80, !tbaa !24
  store i64 %t129, ptr %l77, !tbaa !24
  br label %bb33
bb32:
  %t130 = load i64, ptr %l84, !tbaa !24
  store i64 %t130, ptr %l77, !tbaa !24
  br label %bb33
bb33:
  %t131 = load i64, ptr %l77, !tbaa !24
  store i64 %t131, ptr %l6, !tbaa !24
  %t132 = load i64, ptr %l6, !tbaa !24
  %t134 = icmp slt i64 %t132, 0
  br i1 %t134, label %bb34, label %bb35
bb34:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t136)
  store ptr %t138, ptr %l89
  br label %bb36
bb35:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb37
bb36:
  %t139 = load ptr, ptr %l89, !tbaa !29
  %t141 = getelementptr %"compiler/check:frame", ptr %t139, i32 0, i32 31
  %t142 = load i64, ptr %t141, !tbaa !24
  %t144 = icmp sge i64 %t142, 0
  store i1 %t144, ptr %l87, !tbaa !21
  br label %bb37
bb37:
  %t146 = load i1, ptr %l87, !tbaa !21
  br i1 %t146, label %bb38, label %bb39
bb38:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l3
  %t149 = load i32, ptr %l4, !tbaa !23
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %v2, ptr %t147, %"compiler/source:Span" %t148, i32 %t149)
  store ptr %t153, ptr %l96
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t154 = load ptr, ptr %l96, !tbaa !29
  store ptr %t154, ptr %rv
  br label %ret
bb41:
  %t155 = load i64, ptr %l6, !tbaa !24
  %t157 = icmp slt i64 %t155, 0
  br i1 %t157, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t160 = load i64, ptr %l6, !tbaa !24
  store i64 %t160, ptr %l100, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l4, !tbaa !23
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t161, i32 %t162)
  store i64 %t165, ptr %l103
  br label %bb45
bb45:
  %t166 = load i64, ptr %l100, !tbaa !24
  %t167 = load i64, ptr %l103, !tbaa !24
  %t168 = icmp ne i64 %t166, %t167
  br i1 %t168, label %bb46, label %bb47
bb46:
  %t170 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t170, ptr %l105
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i64, ptr %l6, !tbaa !24
  %t175 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t171, i64 %t172)
  store i32 %t175, ptr %l108
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l3
  %t178 = load i64, ptr %l6, !tbaa !24
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t176, %"compiler/source:Span" %t177, i64 %t178)
  store ptr %t182, ptr %l112
  br label %bb49
bb49:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l3
  %t188 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t183, i32 8, %"compiler/source:Span" %t184)
  store i32 %t188, ptr %l116
  br label %bb50
bb50:
  store { i64, [4 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 0
  store i64 6, ptr %t190
  %t191 = load %"compiler/source:Span", ptr %l105
  %t192 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t191, 0
  %t193 = load i32, ptr %l108, !tbaa !23
  %t194 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t192, i32 %t193, 1
  %t195 = load ptr, ptr %l112, !tbaa !29
  %t196 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t194, ptr %t195, 2
  %t197 = load i32, ptr %l116, !tbaa !23
  %t198 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t196, i32 %t197, 3
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t198, ptr %t199
  %t200 = load { i64, [4 x i64] }, ptr %t189
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t200, ptr %t202
  call void @__olang_scope_close(ptr %s0)
  store ptr %t202, ptr %rv
  br label %ret
bb51:
  %t204 = load i1, ptr %l2, !tbaa !21
  br i1 %t204, label %bb52, label %bb53
bb52:
  %t206 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t206, ptr %l120
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i64, ptr %l6, !tbaa !24
  %t211 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t207, i64 %t208)
  store i32 %t211, ptr %l123
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t212 = load i64, ptr %l6, !tbaa !24
  %t214 = trunc i64 %t212 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 0
  store i64 0, ptr %t217
  %t218 = load %"compiler/source:Span", ptr %l120
  %t219 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t218, 0
  %t220 = load i32, ptr %l123, !tbaa !23
  %t221 = insertvalue { %"compiler/source:Span", i32, i32 } %t219, i32 %t220, 1
  %t223 = insertvalue { %"compiler/source:Span", i32, i32 } %t221, i32 %t214, 2
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t223, ptr %t224
  %t225 = load { i64, [4 x i64] }, ptr %t216
  %t227 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t225, ptr %t227
  call void @__olang_scope_close(ptr %s0)
  store ptr %t227, ptr %rv
  br label %ret
bb55:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l3
  %t231 = load i64, ptr %l6, !tbaa !24
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %v2, ptr %t229, %"compiler/source:Span" %t230, i64 %t231)
  store ptr %t235, ptr %l132
  br label %bb56
bb56:
  %t236 = load ptr, ptr %l132, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t236, ptr %rv
  br label %ret
bb57:
  %t238 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t239 = load i32, ptr %t238, !range !{i32 0, i32 9}
  %t241 = trunc i64 2 to i32
  %t242 = icmp eq i32 %t239, %t241
  br i1 %t242, label %bb58, label %bb59
bb58:
  %t244 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t244, ptr %l136
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t247 = load i64, ptr %t246, !tbaa !24
  %t248 = load i32, ptr %l4, !tbaa !23
  %t252 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t245, i64 %t247, i32 %t248)
  store i32 %t252, ptr %l140
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t253 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t254 = load i64, ptr %t253, !tbaa !24
  %t255 = load i32, ptr %l4, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t256
  %t257 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 0
  store i64 1, ptr %t257
  %t258 = load %"compiler/source:Span", ptr %l136
  %t259 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t258, 0
  %t260 = load i32, ptr %l140, !tbaa !23
  %t261 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t259, i32 %t260, 1
  %t263 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t261, i64 %t254, 2
  %t265 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t263, i32 %t255, 3
  %t266 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t265, ptr %t266
  %t267 = load { i64, [4 x i64] }, ptr %t256
  %t269 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t267, ptr %t269
  call void @__olang_scope_close(ptr %s0)
  store ptr %t269, ptr %rv
  br label %ret
bb61:
  br label %bb146
bb62:
  %t271 = load ptr, ptr %l1, !tbaa !29
  store ptr %t271, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t272 = load ptr, ptr %l145, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb63, label %bb64
bb63:
  %t275 = load ptr, ptr %l145, !tbaa !29
  %t276 = load i64, ptr %t275, !range !{i64 0, i64 30}
  %t278 = icmp eq i64 %t276, 2
  store i1 %t278, ptr %l146, !tbaa !21
  br label %bb64
bb64:
  %t279 = load i1, ptr %l146, !tbaa !21
  br i1 %t279, label %bb65, label %bb66
bb65:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t282 = getelementptr { i64, [4 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", ptr }, ptr %t282, i32 0, i32 1
  %t284 = load ptr, ptr %t283
  store ptr %t284, ptr %l7, !tbaa !29
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load ptr, ptr %l7, !tbaa !29
  %t290 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t286, ptr %t287)
  store ptr %t290, ptr %l153
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t291 = load ptr, ptr %l153, !tbaa !29
  store ptr %t291, ptr %rv
  br label %ret
bb69:
  %t292 = load ptr, ptr %l1, !tbaa !29
  store ptr %t292, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t293 = load ptr, ptr %l154, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb70, label %bb71
bb70:
  %t296 = load ptr, ptr %l154, !tbaa !29
  %t297 = load i64, ptr %t296, !range !{i64 0, i64 30}
  %t299 = icmp eq i64 %t297, 14
  store i1 %t299, ptr %l155, !tbaa !21
  br label %bb71
bb71:
  %t300 = load i1, ptr %l155, !tbaa !21
  br i1 %t300, label %bb72, label %bb73
bb72:
  %t301 = load ptr, ptr %l1, !tbaa !29
  %t303 = getelementptr { i64, [4 x i64] }, ptr %t301, i32 0, i32 1
  %t304 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t303, i32 0, i32 0
  %t305 = load %"compiler/source:Span", ptr %t304
  store %"compiler/source:Span" %t305, ptr %l8
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t309 = getelementptr { i64, [4 x i64] }, ptr %t307, i32 0, i32 1
  %t310 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t309, i32 0, i32 1
  %t311 = load ptr, ptr %t310
  store ptr %t311, ptr %l9, !tbaa !29
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t315, i32 0, i32 2
  %t317 = load i32, ptr %t316
  store i32 %t317, ptr %l10, !tbaa !23
  br label %bb74
bb73:
  br label %bb102
bb74:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = getelementptr %"compiler/generic:Program", ptr %t322, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  store ptr %t325, ptr %l166, !tbaa !29
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t326)
  store ptr %t328, ptr %l168
  br label %bb75
bb75:
  %t329 = load ptr, ptr %l168, !tbaa !29
  %t331 = getelementptr %"compiler/check:frame", ptr %t329, i32 0, i32 2
  %t332 = load i64, ptr %t331, !tbaa !24
  %t333 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t334 = load i32, ptr %t333, !tbaa !23
  %t335 = load ptr, ptr %l166, !tbaa !29
  %t338 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t335, i64 %t332, i32 %t334)
  store %"compiler/names:Ref" %t338, ptr %l172
  br label %bb76
bb76:
  %t339 = load %"compiler/names:Ref", ptr %l172
  store %"compiler/names:Ref" %t339, ptr %l11
  %t340 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 0
  %t341 = load i32, ptr %t340, !range !{i32 0, i32 9}
  %t343 = trunc i64 2 to i32
  %t344 = icmp eq i32 %t341, %t343
  br i1 %t344, label %bb77, label %bb78
bb77:
  %t346 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t346, ptr %l175
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 1
  %t349 = load i64, ptr %t348, !tbaa !24
  %t350 = load i32, ptr %l10, !tbaa !23
  %t354 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t347, i64 %t349, i32 %t350)
  store i32 %t354, ptr %l179
  br label %bb79
bb78:
  br label %bb80
bb79:
  %t355 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 1
  %t356 = load i64, ptr %t355, !tbaa !24
  %t357 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t358
  %t359 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 0
  store i64 1, ptr %t359
  %t360 = load %"compiler/source:Span", ptr %l175
  %t361 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t360, 0
  %t362 = load i32, ptr %l179, !tbaa !23
  %t363 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t361, i32 %t362, 1
  %t365 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t363, i64 %t356, 2
  %t367 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t365, i32 %t357, 3
  %t368 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t367, ptr %t368
  %t369 = load { i64, [4 x i64] }, ptr %t358
  %t371 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t369, ptr %t371
  call void @__olang_scope_close(ptr %s0)
  store ptr %t371, ptr %rv
  br label %ret
bb80:
  %t373 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 0
  %t374 = load i32, ptr %t373, !range !{i32 0, i32 9}
  %t376 = trunc i64 0 to i32
  %t377 = icmp eq i32 %t374, %t376
  br i1 %t377, label %bb81, label %bb82
bb81:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load ptr, ptr %l9, !tbaa !29
  %t383 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t379, ptr %t380)
  store i32 %t383, ptr %l189
  br label %bb83
bb82:
  store i1 false, ptr %l186, !tbaa !21
  br label %bb84
bb83:
  %t384 = load i32, ptr %l189, !tbaa !23
  %t385 = icmp slt i32 %t384, 0
  store i1 %t385, ptr %l186, !tbaa !21
  br label %bb84
bb84:
  %t387 = load i1, ptr %l186, !tbaa !21
  br i1 %t387, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s12
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load ptr, ptr %l9, !tbaa !29
  %t390 = load i32, ptr %l10, !tbaa !23
  %t394 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedName(ptr %v0, ptr %v1, ptr %t388, ptr %t389, i32 %t390)
  store i64 %t394, ptr %l194
  br label %bb87
bb86:
  br label %bb101
bb87:
  %t395 = load i64, ptr %l194, !tbaa !24
  store i64 %t395, ptr %l12, !tbaa !24
  %t396 = load i64, ptr %l12, !tbaa !24
  %t398 = icmp sge i64 %t396, 0
  br i1 %t398, label %bb88, label %bb89
bb88:
  %t400 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t400, ptr %l197
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load i64, ptr %l12, !tbaa !24
  %t405 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t401, i64 %t402)
  store i32 %t405, ptr %l200
  br label %bb90
bb89:
  br label %bb93
bb90:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l8
  %t408 = load i64, ptr %l12, !tbaa !24
  %t412 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t406, %"compiler/source:Span" %t407, i64 %t408)
  store ptr %t412, ptr %l204
  br label %bb91
bb91:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load %"compiler/source:Span", ptr %l8
  %t418 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t413, i32 8, %"compiler/source:Span" %t414)
  store i32 %t418, ptr %l208
  br label %bb92
bb92:
  store { i64, [4 x i64] } zeroinitializer, ptr %t419
  %t420 = getelementptr { i64, [4 x i64] }, ptr %t419, i32 0, i32 0
  store i64 6, ptr %t420
  %t421 = load %"compiler/source:Span", ptr %l197
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t421, 0
  %t423 = load i32, ptr %l200, !tbaa !23
  %t424 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t422, i32 %t423, 1
  %t425 = load ptr, ptr %l204, !tbaa !29
  %t426 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t424, ptr %t425, 2
  %t427 = load i32, ptr %l208, !tbaa !23
  %t428 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t426, i32 %t427, 3
  %t429 = getelementptr { i64, [4 x i64] }, ptr %t419, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t428, ptr %t429
  %t430 = load { i64, [4 x i64] }, ptr %t419
  %t432 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t430, ptr %t432
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t432, ptr %rv
  br label %ret
bb93:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load ptr, ptr %l9, !tbaa !29
  %t438 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t434, ptr %t435)
  store ptr %t438, ptr %l213
  br label %bb94
bb94:
  %t439 = load ptr, ptr %l213, !tbaa !29
  store ptr %t439, ptr %l13, !tbaa !29
  %t440 = load ptr, ptr %l13, !tbaa !29
  %t442 = icmp eq ptr %t440, null
  br i1 %t442, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb96:
  br label %bb97
bb97:
  %t445 = load ptr, ptr %l0, !tbaa !29
  store ptr %t445, ptr %l217, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t446, ptr %l218
  %t447 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t447, ptr %l219
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load i32, ptr %l10, !tbaa !23
  %t452 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s12, ptr %t448, i32 %t449)
  store { i64, ptr } %t452, ptr %l222
  br label %bb98
bb98:
  %t453 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t453, 0
  %t455 = load %"compiler/source:Span", ptr %l219
  %t457 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t455, i64 %t454)
  store %"compiler/source:Span" %t457, ptr %l224
  br label %bb99
bb99:
  %t458 = load ptr, ptr %l13, !tbaa !29
  %t459 = load i32, ptr %l10, !tbaa !23
  %t460 = load ptr, ptr %l217, !tbaa !29
  %t461 = load %"compiler/source:Span", ptr %l218
  %t462 = load %"compiler/source:Span", ptr %l224
  %t465 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %v2, ptr %v2, ptr %t460, %"compiler/source:Span" %t461, %"compiler/source:Span" %t462, ptr %t458, i32 %t459)
  store ptr %t465, ptr %l227
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t466 = load ptr, ptr %l227, !tbaa !29
  store ptr %t466, ptr %rv
  br label %ret
bb101:
  br label %bb146
bb102:
  %t467 = load ptr, ptr %l1, !tbaa !29
  store ptr %t467, ptr %l228, !tbaa !29
  store i1 false, ptr %l229, !tbaa !21
  %t468 = load ptr, ptr %l228, !tbaa !29
  %t469 = icmp ne ptr %t468, null
  br i1 %t469, label %bb103, label %bb104
bb103:
  %t471 = load ptr, ptr %l228, !tbaa !29
  %t472 = load i64, ptr %t471, !range !{i64 0, i64 30}
  %t474 = icmp eq i64 %t472, 15
  store i1 %t474, ptr %l229, !tbaa !21
  br label %bb104
bb104:
  %t475 = load i1, ptr %l229, !tbaa !21
  br i1 %t475, label %bb105, label %bb106
bb105:
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr { i64, [4 x i64] }, ptr %t476, i32 0, i32 1
  %t479 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t478, i32 0, i32 0
  %t480 = load %"compiler/source:Span", ptr %t479
  store %"compiler/source:Span" %t480, ptr %l14
  %t482 = load ptr, ptr %l1, !tbaa !29
  %t484 = getelementptr { i64, [4 x i64] }, ptr %t482, i32 0, i32 1
  %t485 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t484, i32 0, i32 1
  %t486 = load ptr, ptr %t485
  store ptr %t486, ptr %l15, !tbaa !29
  %t488 = load ptr, ptr %l1, !tbaa !29
  %t490 = getelementptr { i64, [4 x i64] }, ptr %t488, i32 0, i32 1
  %t491 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t490, i32 0, i32 2
  %t492 = load { i64, ptr }, ptr %t491
  store { i64, ptr } %t492, ptr %l16, !tbaa !27
  br label %bb107
bb106:
  br label %bb117
bb107:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load ptr, ptr %l15, !tbaa !29
  %t498 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t494, ptr %t495)
  store i32 %t498, ptr %l240
  br label %bb108
bb108:
  %t499 = load i32, ptr %l240, !tbaa !23
  %t500 = icmp slt i32 %t499, 0
  br i1 %t500, label %bb109, label %bb110
bb109:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load ptr, ptr %l15, !tbaa !29
  %t506 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t502, ptr %t503)
  store %"compiler/check:reflList" %t506, ptr %l245
  br label %bb111
bb110:
  store i1 false, ptr %l242, !tbaa !21
  br label %bb112
bb111:
  %t507 = getelementptr %"compiler/check:reflList", ptr %l245, i32 0, i32 0
  %t508 = load i1, ptr %t507, !tbaa !21
  %t510 = xor i1 %t508, true
  store i1 %t510, ptr %l242, !tbaa !21
  br label %bb112
bb112:
  %t512 = load i1, ptr %l242, !tbaa !21
  br i1 %t512, label %bb113, label %bb114
bb113:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load %"compiler/source:Span", ptr %l14
  %t515 = load ptr, ptr %l15, !tbaa !29
  %t516 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t521 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexPlace(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t513, %"compiler/source:Span" %t514, ptr %t515, { i64, ptr } %t516)
  store ptr %t521, ptr %l252
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s0)
  %t522 = load ptr, ptr %l252, !tbaa !29
  store ptr %t522, ptr %rv
  br label %ret
bb116:
  br label %bb146
bb117:
  %t523 = load ptr, ptr %l1, !tbaa !29
  store ptr %t523, ptr %l253, !tbaa !29
  store i1 false, ptr %l254, !tbaa !21
  %t524 = load ptr, ptr %l253, !tbaa !29
  %t525 = icmp ne ptr %t524, null
  br i1 %t525, label %bb118, label %bb119
bb118:
  %t527 = load ptr, ptr %l253, !tbaa !29
  %t528 = load i64, ptr %t527, !range !{i64 0, i64 30}
  %t530 = icmp eq i64 %t528, 12
  store i1 %t530, ptr %l254, !tbaa !21
  br label %bb119
bb119:
  %t531 = load i1, ptr %l254, !tbaa !21
  br i1 %t531, label %bb120, label %bb121
bb120:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr { i64, [4 x i64] }, ptr %t532, i32 0, i32 1
  %t535 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t534, i32 0, i32 1
  %t536 = load ptr, ptr %t535
  store ptr %t536, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t537 = load ptr, ptr %l259, !tbaa !29
  %t538 = icmp ne ptr %t537, null
  br i1 %t538, label %bb122, label %bb123
bb121:
  store i1 false, ptr %l257, !tbaa !21
  br label %bb124
bb122:
  %t540 = load ptr, ptr %l259, !tbaa !29
  %t541 = load i64, ptr %t540, !range !{i64 0, i64 30}
  %t543 = icmp eq i64 %t541, 14
  store i1 %t543, ptr %l260, !tbaa !21
  br label %bb123
bb123:
  %t544 = load i1, ptr %l260, !tbaa !21
  store i1 %t544, ptr %l257, !tbaa !21
  br label %bb124
bb124:
  %t545 = load i1, ptr %l257, !tbaa !21
  br i1 %t545, label %bb125, label %bb126
bb125:
  %t546 = load ptr, ptr %l1, !tbaa !29
  %t548 = getelementptr { i64, [4 x i64] }, ptr %t546, i32 0, i32 1
  %t549 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t548, i32 0, i32 0
  %t550 = load %"compiler/source:Span", ptr %t549
  store %"compiler/source:Span" %t550, ptr %l17
  %t552 = load ptr, ptr %l1, !tbaa !29
  %t554 = getelementptr { i64, [4 x i64] }, ptr %t552, i32 0, i32 1
  %t555 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t554, i32 0, i32 1
  %t556 = load ptr, ptr %t555
  %t558 = getelementptr { i64, [4 x i64] }, ptr %t556, i32 0, i32 1
  %t559 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t558, i32 0, i32 0
  %t560 = load %"compiler/source:Span", ptr %t559
  store %"compiler/source:Span" %t560, ptr %l18
  %t562 = load ptr, ptr %l1, !tbaa !29
  %t564 = getelementptr { i64, [4 x i64] }, ptr %t562, i32 0, i32 1
  %t565 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t564, i32 0, i32 1
  %t566 = load ptr, ptr %t565
  %t568 = getelementptr { i64, [4 x i64] }, ptr %t566, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t568, i32 0, i32 1
  %t570 = load ptr, ptr %t569
  store ptr %t570, ptr %l19, !tbaa !29
  %t572 = load ptr, ptr %l1, !tbaa !29
  %t574 = getelementptr { i64, [4 x i64] }, ptr %t572, i32 0, i32 1
  %t575 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t574, i32 0, i32 1
  %t576 = load ptr, ptr %t575
  %t578 = getelementptr { i64, [4 x i64] }, ptr %t576, i32 0, i32 1
  %t579 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t578, i32 0, i32 2
  %t580 = load i32, ptr %t579
  store i32 %t580, ptr %l20, !tbaa !23
  %t582 = load ptr, ptr %l1, !tbaa !29
  %t584 = getelementptr { i64, [4 x i64] }, ptr %t582, i32 0, i32 1
  %t585 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t584, i32 0, i32 2
  %t586 = load { i64, ptr }, ptr %t585
  store { i64, ptr } %t586, ptr %l21, !tbaa !27
  br label %bb127
bb126:
  br label %bb141
bb127:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load i32, ptr %l20, !tbaa !23
  %t592 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t588, i32 %t589)
  store { i64, ptr } %t592, ptr %l278
  br label %bb128
bb128:
  %t593 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t594 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t593, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t594, ptr %l279
  br label %bb129
bb129:
  %t595 = load i1, ptr %l279, !tbaa !21
  br i1 %t595, label %bb130, label %bb131
bb130:
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t597 = load ptr, ptr %l19, !tbaa !29
  %t600 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t596, ptr %t597)
  store i32 %t600, ptr %l282
  br label %bb132
bb131:
  br label %bb141
bb132:
  %t601 = load i32, ptr %l282, !tbaa !23
  store i32 %t601, ptr %l22, !tbaa !23
  %t602 = load i32, ptr %l22, !tbaa !23
  %t604 = icmp sge i32 %t602, 0
  br i1 %t604, label %bb133, label %bb134
bb133:
  %t606 = load i32, ptr %l22, !tbaa !23
  %t607 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t610 = icmp eq i32 %t606, %t607
  br i1 %t610, label %bb135, label %bb136
bb134:
  br label %bb140
bb135:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb136:
  br label %bb137
bb137:
  %t613 = load ptr, ptr %l0, !tbaa !29
  store ptr %t613, ptr %l289, !tbaa !29
  %t614 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t614, ptr %l290
  %t615 = load %"compiler/source:Span", ptr %l18
  %t617 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t615, i64 2)
  store %"compiler/source:Span" %t617, ptr %l292
  br label %bb138
bb138:
  %t618 = load i32, ptr %l22, !tbaa !23
  %t619 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t620 = load ptr, ptr %l289, !tbaa !29
  %t621 = load %"compiler/source:Span", ptr %l290
  %t622 = load %"compiler/source:Span", ptr %l292
  %t625 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflOf(ptr %v0, ptr %v1, ptr %v2, ptr %t620, %"compiler/source:Span" %t621, %"compiler/source:Span" %t622, i32 %t618, { i64, ptr } %t619)
  store ptr %t625, ptr %l295
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s0)
  %t626 = load ptr, ptr %l295, !tbaa !29
  store ptr %t626, ptr %rv
  br label %ret
bb140:
  br label %bb146
bb141:
  br i1 true, label %bb142, label %bb143
bb142:
  br label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb146
bb145:
  call void @__olang_check_failed(ptr @olang_loc_c89e58dd43b8c5a0_98fae7e2dc40ed34)
  unreachable
bb146:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load ptr, ptr %l1, !tbaa !29
  %t630 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t634 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t627, ptr %t628, i32 %t630)
  store ptr %t634, ptr %l300
  br label %bb147
bb147:
  %t635 = load ptr, ptr %l300, !tbaa !29
  store ptr %t635, ptr %l23, !tbaa !29
  %t636 = load ptr, ptr %l23, !tbaa !29
  %t639 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t636)
  store i32 %t639, ptr %l303
  br label %bb148
bb148:
  %t640 = load i32, ptr %l303, !tbaa !23
  store i32 %t640, ptr %l24, !tbaa !23
  %t641 = load i32, ptr %l24, !tbaa !23
  %t642 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t645 = icmp eq i32 %t641, %t642
  br i1 %t645, label %bb149, label %bb150
bb149:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb150:
  br label %bb151
bb151:
  %t648 = load ptr, ptr %l23, !tbaa !29
  %t650 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v2, ptr %t648)
  store ptr %t650, ptr %l309
  br label %bb152
bb152:
  %t651 = load ptr, ptr %l309, !tbaa !29
  store ptr %t651, ptr %l25, !tbaa !29
  %t652 = load ptr, ptr %l25, !tbaa !29
  %t654 = icmp eq ptr %t652, null
  %t656 = xor i1 %t654, true
  br i1 %t656, label %bb153, label %bb154
bb153:
  %t658 = load ptr, ptr %l25, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t658, ptr %rv
  br label %ret
bb154:
  br label %bb155
bb155:
  %t661 = load ptr, ptr %l1, !tbaa !29
  %t663 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t661)
  store %"compiler/source:Span" %t663, ptr %l316
  br label %bb156
bb156:
  %t664 = load i32, ptr %l24, !tbaa !23
  store i32 %t664, ptr %l317, !tbaa !23
  %t665 = load ptr, ptr %l23, !tbaa !29
  store ptr %t665, ptr %l318, !tbaa !29
  %t666 = load ptr, ptr %l0, !tbaa !29
  store ptr %t666, ptr %l319, !tbaa !29
  store i32 8, ptr %l320
  %t667 = load ptr, ptr %l1, !tbaa !29
  %t669 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t667)
  store %"compiler/source:Span" %t669, ptr %l322
  br label %bb157
bb157:
  %t670 = load ptr, ptr %l319, !tbaa !29
  %t671 = load i32, ptr %l320, !range !{i32 0, i32 9}
  %t672 = load %"compiler/source:Span", ptr %l322
  %t673 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t670, i32 %t671, %"compiler/source:Span" %t672)
  store i32 %t673, ptr %l323
  br label %bb158
bb158:
  store { i64, [4 x i64] } zeroinitializer, ptr %t674
  %t675 = getelementptr { i64, [4 x i64] }, ptr %t674, i32 0, i32 0
  store i64 6, ptr %t675
  %t676 = load %"compiler/source:Span", ptr %l316
  %t677 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t676, 0
  %t678 = load i32, ptr %l317, !tbaa !23
  %t679 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t677, i32 %t678, 1
  %t680 = load ptr, ptr %l318, !tbaa !29
  %t681 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t679, ptr %t680, 2
  %t682 = load i32, ptr %l323, !tbaa !23
  %t683 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t681, i32 %t682, 3
  %t684 = getelementptr { i64, [4 x i64] }, ptr %t674, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t683, ptr %t684
  %t685 = load { i64, [4 x i64] }, ptr %t674
  %t687 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t685, ptr %t687
  call void @__olang_scope_close(ptr %s0)
  store ptr %t687, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i32
  %l42 = alloca i32
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i1, ptr %l11, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb10
bb5:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l20
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t27 = load i1, ptr %l20, !tbaa !21
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l16, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l12, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = icmp sge i32 %t33, 0
  br i1 %t35, label %bb13, label %bb14
bb12:
  br label %bb21
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t39 = load %"compiler/source:Span", ptr %l2
  %t43 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s1, ptr %s1, ptr %t37, i32 %t38, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t39, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i64 %t43, ptr %l28
  br label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s1, ptr %t44, i32 %t45, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, i64 1)
  store i64 %t48, ptr %l31
  br label %bb16
bb15:
  %t49 = load i64, ptr %l28, !tbaa !24
  store i64 %t49, ptr %l24, !tbaa !24
  br label %bb17
bb16:
  %t50 = load i64, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l24, !tbaa !24
  br label %bb17
bb17:
  %t51 = load i64, ptr %l24, !tbaa !24
  store i64 %t51, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp sge i64 %t52, 0
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t56 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t56, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb21:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l36, !tbaa !29
  %t62 = load i32, ptr %l3, !tbaa !23
  store i32 %t62, ptr %l37, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/load:Loader", ptr %t69, i32 0, i32 3
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t72, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i32 %t74, ptr %l42
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l36, !tbaa !29
  %t76 = load i32, ptr %l37, !tbaa !23
  %t77 = load i32, ptr %l42, !tbaa !23
  %t78 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s0, ptr %t75, i32 %t76, i32 %t77)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l43
  br label %bb23
bb23:
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l5
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t81, ptr %l45
  br label %bb24
bb24:
  %t82 = load i64, ptr %l45, !tbaa !24
  %t83 = icmp eq i64 %t82, 1
  br i1 %t83, label %bb25, label %bb26
bb25:
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 0)
  store i64 %t86, ptr %l49
  br label %bb27
bb26:
  store i64 -1, ptr %l47, !tbaa !24
  br label %bb28
bb27:
  %t87 = load i64, ptr %l49, !tbaa !24
  store i64 %t87, ptr %l47, !tbaa !24
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load i64, ptr %l47, !tbaa !24
  store i64 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l14 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca i32
  %l37 = alloca i32
  %l46 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtended(ptr %v0, ptr %s2, ptr %t9, i32 %a2)
  store { i64, ptr } %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 4
  %t18 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb22
bb7:
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %l22, !tbaa !27
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i32, ptr %t38, i64 %t35
  %t40 = load i32, ptr %t39, !tbaa !33
  store i32 %t40, ptr %l7, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l7, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l29
  br label %bb9
bb9:
  %t52 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t54 = trunc i64 18 to i32
  %t55 = icmp eq i32 %t52, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb10, label %bb11
bb10:
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l7, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l37
  br label %bb13
bb13:
  %t69 = load i32, ptr %l1, !tbaa !23
  %t70 = load i32, ptr %l37, !tbaa !23
  %t72 = icmp eq i32 %t70, %t69
  br i1 %t72, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t77 = load i32, ptr %l7, !tbaa !23
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = add i64 %t78, 1
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %t75, i32 %t76, i32 %t77, i64 %t80)
  store i1 %t85, ptr %l46
  br label %bb17
bb17:
  %t86 = load i1, ptr %l46, !tbaa !21
  br i1 %t86, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l5, !tbaa !24
  br label %bb5
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflKeeps(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:reflList" %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l10 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l30 = alloca i64
  %l41 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/msgs:Msg"
  %l49 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Compr", ptr %t2, i32 0, i32 3
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l10, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t6, %"compiler/check:reflList" %a2, i64 %a3)
  store i32 %t12, ptr %l14
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t13, i32 %t14, i32 %t15)
  store i32 %t16, ptr %l15
  br label %bb2
bb2:
  %t17 = load i32, ptr %l15, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l16, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:Compr", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  store i32 %t22, ptr %l18, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t29)
  store i32 %t31, ptr %l23
  br label %bb3
bb3:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i32, ptr %l23, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t33, i32 %t34, i64 %a4)
  store i32 %t36, ptr %l25
  br label %bb4
bb4:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load i32, ptr %l18, !tbaa !23
  %t39 = load i32, ptr %l25, !tbaa !23
  %t40 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t37, i32 %t38, i32 %t39)
  store i32 %t40, ptr %l26
  br label %bb5
bb5:
  %t41 = load i32, ptr %l26, !tbaa !23
  store i32 %t41, ptr %l6, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Compr", ptr %t43, i32 0, i32 5
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t42, ptr %t46)
  store i64 %t49, ptr %l30
  br label %bb6
bb6:
  %t50 = load i64, ptr %l30, !tbaa !24
  store i64 %t50, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/ast:Compr", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t51, i32 %t55, i32 %t56)
  br label %bb7
bb7:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Compr", ptr %t61, i32 0, i32 3
  %t64 = load i32, ptr %t63, !tbaa !23
  %t65 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t60, i32 %t64, i32 %t65)
  br label %bb8
bb8:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = icmp slt i64 %t69, 0
  br i1 %t71, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Compr", ptr %t74, i32 0, i32 5
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb11, label %bb12
bb10:
  br label %bb17
bb11:
  call void @__olang_check_failed(ptr @olang_loc_320f9d8592ce2991_bf25bbc6142ecf8d)
  unreachable
bb12:
  br label %bb13
bb13:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Compr", ptr %t81, i32 0, i32 5
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t84)
  store %"compiler/source:Span" %t86, ptr %l47
  br label %bb14
bb14:
  %t87 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %s1)
  store %"compiler/msgs:Msg" %t87, ptr %l48
  br label %bb15
bb15:
  %t88 = load ptr, ptr %l41, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l47
  %t90 = load %"compiler/msgs:Msg", ptr %l48
  %t91 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t88, %"compiler/source:Span" %t89, %"compiler/msgs:Msg" %t90)
  store i64 %t91, ptr %l49
  br label %bb16
bb16:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 138
  store i1 true, ptr %t94, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = icmp eq i64 %t95, 1
  store i1 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereset(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca ptr
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca ptr
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca ptr
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca ptr
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca ptr
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca ptr
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca ptr
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l33 = alloca ptr
  %l34 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca ptr
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l39 = alloca ptr
  %l40 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l41 = alloca ptr
  %l42 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca ptr
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca ptr
  %l46 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l47 = alloca ptr
  %l48 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l49 = alloca ptr
  %l50 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l51 = alloca ptr
  %l52 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l53 = alloca ptr
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca ptr
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca ptr
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca ptr
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca ptr
  %l63 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l64 = alloca ptr
  %l65 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l66 = alloca ptr
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca ptr
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca ptr
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca ptr
  %l73 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l74 = alloca ptr
  %l75 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l76 = alloca ptr
  %l77 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l78 = alloca ptr
  %l79 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l80 = alloca ptr
  %l81 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l82 = alloca ptr
  %l83 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l84 = alloca ptr
  %l85 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l86 = alloca ptr
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca ptr
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca ptr
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca ptr
  %l93 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l94 = alloca ptr
  %l95 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l96 = alloca ptr
  %l97 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca ptr
  %l99 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l100 = alloca ptr
  %l101 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca ptr
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l104 = alloca ptr
  %l105 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l106 = alloca ptr
  %l107 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l108 = alloca ptr
  %l109 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca ptr
  %l111 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l112 = alloca ptr
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca ptr
  %l115 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l116 = alloca ptr
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l118 = alloca ptr
  %l119 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l120 = alloca ptr
  %l121 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l122 = alloca ptr
  %l123 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l124 = alloca ptr
  %l125 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l126 = alloca ptr
  %l127 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l128 = alloca ptr
  %l129 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l130 = alloca ptr
  %l131 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l132 = alloca ptr
  %l133 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l134 = alloca ptr
  %l135 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l136 = alloca ptr
  %l137 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l138 = alloca ptr
  %l139 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l140 = alloca ptr
  %l141 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l142 = alloca ptr
  %l143 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l144 = alloca ptr
  %l145 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l146 = alloca ptr
  %l147 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  br label %bb1
bb1:
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l3, !tbaa !29
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l4
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 65
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t10
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l5, !tbaa !29
  %t12 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l6
  br label %bb3
bb3:
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %t15
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l7, !tbaa !29
  %t17 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t17, ptr %l8
  br label %bb4
bb4:
  %t18 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  %t19 = load ptr, ptr %l7, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 66
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t18, ptr %t20
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l9, !tbaa !29
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l10
  br label %bb5
bb5:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t24 = load ptr, ptr %l9, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %t25
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l11, !tbaa !29
  %t27 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t27, ptr %l12
  br label %bb6
bb6:
  %t28 = load %"std/prelude/text:StringBuilder", ptr %l12
  %t29 = load ptr, ptr %l11, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 139
  store %"std/prelude/text:StringBuilder" %t28, ptr %t30
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 9
  store ptr null, ptr %t33, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l14, !tbaa !29
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l15
  br label %bb7
bb7:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t37 = load ptr, ptr %l14, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %t38
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l16, !tbaa !29
  %t40 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t40, ptr %l17
  br label %bb8
bb8:
  %t41 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  %t42 = load ptr, ptr %l16, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 133
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t41, ptr %t43
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l18, !tbaa !29
  %t45 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t45, ptr %l19
  br label %bb9
bb9:
  %t46 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  %t47 = load ptr, ptr %l18, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 143
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t46, ptr %t48
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l20, !tbaa !29
  %t50 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l21
  br label %bb10
bb10:
  %t51 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 144
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %t53
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResetAny(ptr %v0, ptr %t57)
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l24, !tbaa !29
  %t60 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l25
  br label %bb12
bb12:
  %t61 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  %t62 = load ptr, ptr %l24, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %t63
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l26, !tbaa !29
  %t65 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l27
  br label %bb13
bb13:
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  %t67 = load ptr, ptr %l26, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %t68
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 18
  store i64 0, ptr %t71, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l29, !tbaa !29
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l30
  br label %bb14
bb14:
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  %t75 = load ptr, ptr %l29, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %t76
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l31, !tbaa !29
  %t78 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t78, ptr %l32
  br label %bb15
bb15:
  %t79 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  %t80 = load ptr, ptr %l31, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t79, ptr %t81
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l33, !tbaa !29
  %t83 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t83, ptr %l34
  br label %bb16
bb16:
  %t84 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l34
  %t85 = load ptr, ptr %l33, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 21
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t84, ptr %t86
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l35, !tbaa !29
  %t88 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t88, ptr %l36
  br label %bb17
bb17:
  %t89 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  %t90 = load ptr, ptr %l35, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 22
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t89, ptr %t91
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t96 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 23
  store i32 %t93, ptr %t96, !tbaa !23
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l39, !tbaa !29
  %t98 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t98, ptr %l40
  br label %bb18
bb18:
  %t99 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40
  %t100 = load ptr, ptr %l39, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 27
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t99, ptr %t101
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l41, !tbaa !29
  %t103 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t103, ptr %l42
  br label %bb19
bb19:
  %t104 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l42
  %t105 = load ptr, ptr %l41, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 28
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t104, ptr %t106
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l43, !tbaa !29
  %t108 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l44
  br label %bb20
bb20:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t110 = load ptr, ptr %l43, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %t111
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l45, !tbaa !29
  %t113 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t113, ptr %l46
  br label %bb21
bb21:
  %t114 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l46
  %t115 = load ptr, ptr %l45, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 30
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t114, ptr %t116
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l47, !tbaa !29
  %t118 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t118, ptr %l48
  br label %bb22
bb22:
  %t119 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l48
  %t120 = load ptr, ptr %l47, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 31
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t119, ptr %t121
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l49, !tbaa !29
  %t123 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t123, ptr %l50
  br label %bb23
bb23:
  %t124 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50
  %t125 = load ptr, ptr %l49, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t124, ptr %t126
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l51, !tbaa !29
  %t128 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t128, ptr %l52
  br label %bb24
bb24:
  %t129 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l52
  %t130 = load ptr, ptr %l51, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 33
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t129, ptr %t131
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l53, !tbaa !29
  %t133 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %l54
  br label %bb25
bb25:
  %t134 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  %t135 = load ptr, ptr %l53, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %t136
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l55, !tbaa !29
  %t138 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l56
  br label %bb26
bb26:
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  %t140 = load ptr, ptr %l55, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %t141
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l57, !tbaa !29
  %t143 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %l58
  br label %bb27
bb27:
  %t144 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  %t145 = load ptr, ptr %l57, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %t146
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l59, !tbaa !29
  %t148 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t148, ptr %l60
  br label %bb28
bb28:
  %t149 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  %t150 = load ptr, ptr %l59, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t149, ptr %t151
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 42
  store i32 0, ptr %t154, !tbaa !23
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l62, !tbaa !29
  %t156 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t156, ptr %l63
  br label %bb29
bb29:
  %t157 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l63
  %t158 = load ptr, ptr %l62, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 54
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t157, ptr %t159
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l64, !tbaa !29
  %t161 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t161, ptr %l65
  br label %bb30
bb30:
  %t162 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65
  %t163 = load ptr, ptr %l64, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 55
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t162, ptr %t164
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l66, !tbaa !29
  %t166 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t166, ptr %l67
  br label %bb31
bb31:
  %t167 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  %t168 = load ptr, ptr %l66, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167, ptr %t169
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l68, !tbaa !29
  %t171 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t171, ptr %l69
  br label %bb32
bb32:
  %t172 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  %t173 = load ptr, ptr %l68, !tbaa !29
  %t174 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172, ptr %t174
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l70, !tbaa !29
  %t176 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3ainPlaceRead_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t176, ptr %l71
  br label %bb33
bb33:
  %t177 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  %t178 = load ptr, ptr %l70, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t177, ptr %t179
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l72, !tbaa !29
  %t181 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t181, ptr %l73
  br label %bb34
bb34:
  %t182 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l73
  %t183 = load ptr, ptr %l72, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 57
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t182, ptr %t184
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l74, !tbaa !29
  %t186 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t186, ptr %l75
  br label %bb35
bb35:
  %t187 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l75
  %t188 = load ptr, ptr %l74, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 59
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t187, ptr %t189
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l76, !tbaa !29
  %t191 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t191, ptr %l77
  br label %bb36
bb36:
  %t192 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l77
  %t193 = load ptr, ptr %l76, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 72
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t192, ptr %t194
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l78, !tbaa !29
  %t196 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t196, ptr %l79
  br label %bb37
bb37:
  %t197 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l79
  %t198 = load ptr, ptr %l78, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 73
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t197, ptr %t199
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l80, !tbaa !29
  %t201 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t201, ptr %l81
  br label %bb38
bb38:
  %t202 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81
  %t203 = load ptr, ptr %l80, !tbaa !29
  %t204 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 74
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t202, ptr %t204
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l82, !tbaa !29
  %t206 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t206, ptr %l83
  br label %bb39
bb39:
  %t207 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l83
  %t208 = load ptr, ptr %l82, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 75
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t207, ptr %t209
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l84, !tbaa !29
  %t211 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t211, ptr %l85
  br label %bb40
bb40:
  %t212 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l85
  %t213 = load ptr, ptr %l84, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 76
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t212, ptr %t214
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l86, !tbaa !29
  %t216 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_2_Hedf46d61a7b7e16110f4585b041de150(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t216, ptr %l87
  br label %bb41
bb41:
  %t217 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  %t218 = load ptr, ptr %l86, !tbaa !29
  %t219 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 77
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t217, ptr %t219
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l88, !tbaa !29
  %t221 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t221, ptr %l89
  br label %bb42
bb42:
  %t222 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  %t223 = load ptr, ptr %l88, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 78
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t222, ptr %t224
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l90, !tbaa !29
  %t226 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroFn_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t226, ptr %l91
  br label %bb43
bb43:
  %t227 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91
  %t228 = load ptr, ptr %l90, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 79
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %t229
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l92, !tbaa !29
  %t231 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2fvec_H2e44743f10bee47c9f5386f757b87bf0(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t231, ptr %l93
  br label %bb44
bb44:
  %t232 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l93
  %t233 = load ptr, ptr %l92, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 80
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t232, ptr %t234
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l94, !tbaa !29
  %t236 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t236, ptr %l95
  br label %bb45
bb45:
  %t237 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l95
  %t238 = load ptr, ptr %l94, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 81
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t237, ptr %t239
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l96, !tbaa !29
  %t241 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t241, ptr %l97
  br label %bb46
bb46:
  %t242 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l97
  %t243 = load ptr, ptr %l96, !tbaa !29
  %t244 = getelementptr %"compiler/check:Checker", ptr %t243, i32 0, i32 82
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t242, ptr %t244
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l98, !tbaa !29
  %t246 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t246, ptr %l99
  br label %bb47
bb47:
  %t247 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l99
  %t248 = load ptr, ptr %l98, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t248, i32 0, i32 83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t247, ptr %t249
  %t250 = load ptr, ptr %l0, !tbaa !29
  store ptr %t250, ptr %l100, !tbaa !29
  %t251 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t251, ptr %l101
  br label %bb48
bb48:
  %t252 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l101
  %t253 = load ptr, ptr %l100, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t252, ptr %t254
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l102, !tbaa !29
  %t256 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t256, ptr %l103
  br label %bb49
bb49:
  %t257 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  %t258 = load ptr, ptr %l102, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t258, i32 0, i32 85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t257, ptr %t259
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l104, !tbaa !29
  %t261 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t261, ptr %l105
  br label %bb50
bb50:
  %t262 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l105
  %t263 = load ptr, ptr %l104, !tbaa !29
  %t264 = getelementptr %"compiler/check:Checker", ptr %t263, i32 0, i32 86
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t262, ptr %t264
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l106, !tbaa !29
  %t266 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t266, ptr %l107
  br label %bb51
bb51:
  %t267 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l107
  %t268 = load ptr, ptr %l106, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 87
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t267, ptr %t269
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l108, !tbaa !29
  %t271 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t271, ptr %l109
  br label %bb52
bb52:
  %t272 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l109
  %t273 = load ptr, ptr %l108, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 95
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t272, ptr %t274
  %t275 = load ptr, ptr %l0, !tbaa !29
  store ptr %t275, ptr %l110, !tbaa !29
  %t276 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t276, ptr %l111
  br label %bb53
bb53:
  %t277 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l111
  %t278 = load ptr, ptr %l110, !tbaa !29
  %t279 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 96
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %t279
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l112, !tbaa !29
  %t281 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t281, ptr %l113
  br label %bb54
bb54:
  %t282 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113
  %t283 = load ptr, ptr %l112, !tbaa !29
  %t284 = getelementptr %"compiler/check:Checker", ptr %t283, i32 0, i32 124
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t282, ptr %t284
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l114, !tbaa !29
  %t286 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t286, ptr %l115
  br label %bb55
bb55:
  %t287 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l115
  %t288 = load ptr, ptr %l114, !tbaa !29
  %t289 = getelementptr %"compiler/check:Checker", ptr %t288, i32 0, i32 123
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t287, ptr %t289
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l116, !tbaa !29
  %t291 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t291, ptr %l117
  br label %bb56
bb56:
  %t292 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117
  %t293 = load ptr, ptr %l116, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 97
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t292, ptr %t294
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l118, !tbaa !29
  %t296 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t296, ptr %l119
  br label %bb57
bb57:
  %t297 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l119
  %t298 = load ptr, ptr %l118, !tbaa !29
  %t299 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 98
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t297, ptr %t299
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l120, !tbaa !29
  %t301 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atailAsk_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t301, ptr %l121
  br label %bb58
bb58:
  %t302 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l121
  %t303 = load ptr, ptr %l120, !tbaa !29
  %t304 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 99
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t302, ptr %t304
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l122, !tbaa !29
  %t306 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t306, ptr %l123
  br label %bb59
bb59:
  %t307 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l123
  %t308 = load ptr, ptr %l122, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t308, i32 0, i32 100
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t307, ptr %t309
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l124, !tbaa !29
  %t311 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t311, ptr %l125
  br label %bb60
bb60:
  %t312 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125
  %t313 = load ptr, ptr %l124, !tbaa !29
  %t314 = getelementptr %"compiler/check:Checker", ptr %t313, i32 0, i32 101
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t312, ptr %t314
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l126, !tbaa !29
  %t316 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t316, ptr %l127
  br label %bb61
bb61:
  %t317 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l127
  %t318 = load ptr, ptr %l126, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t318, i32 0, i32 102
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t317, ptr %t319
  %t320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t320, ptr %l128, !tbaa !29
  %t321 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t321, ptr %l129
  br label %bb62
bb62:
  %t322 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129
  %t323 = load ptr, ptr %l128, !tbaa !29
  %t324 = getelementptr %"compiler/check:Checker", ptr %t323, i32 0, i32 103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t322, ptr %t324
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l130, !tbaa !29
  %t326 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t326, ptr %l131
  br label %bb63
bb63:
  %t327 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l131
  %t328 = load ptr, ptr %l130, !tbaa !29
  %t329 = getelementptr %"compiler/check:Checker", ptr %t328, i32 0, i32 115
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t327, ptr %t329
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l132, !tbaa !29
  %t331 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t331, ptr %l133
  br label %bb64
bb64:
  %t332 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l133
  %t333 = load ptr, ptr %l132, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t333, i32 0, i32 116
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t332, ptr %t334
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l134, !tbaa !29
  %t336 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t336, ptr %l135
  br label %bb65
bb65:
  %t337 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l135
  %t338 = load ptr, ptr %l134, !tbaa !29
  %t339 = getelementptr %"compiler/check:Checker", ptr %t338, i32 0, i32 117
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t337, ptr %t339
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l136, !tbaa !29
  %t341 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t341, ptr %l137
  br label %bb66
bb66:
  %t342 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l137
  %t343 = load ptr, ptr %l136, !tbaa !29
  %t344 = getelementptr %"compiler/check:Checker", ptr %t343, i32 0, i32 118
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t342, ptr %t344
  %t345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t345, ptr %l138, !tbaa !29
  %t346 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t346, ptr %l139
  br label %bb67
bb67:
  %t347 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l139
  %t348 = load ptr, ptr %l138, !tbaa !29
  %t349 = getelementptr %"compiler/check:Checker", ptr %t348, i32 0, i32 119
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t347, ptr %t349
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l140, !tbaa !29
  %t351 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t351, ptr %l141
  br label %bb68
bb68:
  %t352 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l141
  %t353 = load ptr, ptr %l140, !tbaa !29
  %t354 = getelementptr %"compiler/check:Checker", ptr %t353, i32 0, i32 127
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t352, ptr %t354
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l142, !tbaa !29
  %t356 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t356, ptr %l143
  br label %bb69
bb69:
  %t357 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l143
  %t358 = load ptr, ptr %l142, !tbaa !29
  %t359 = getelementptr %"compiler/check:Checker", ptr %t358, i32 0, i32 128
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t357, ptr %t359
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l144, !tbaa !29
  %t361 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t361, ptr %l145
  br label %bb70
bb70:
  %t362 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l145
  %t363 = load ptr, ptr %l144, !tbaa !29
  %t364 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 129
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t362, ptr %t364
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l146, !tbaa !29
  %t366 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t366, ptr %l147
  br label %bb71
bb71:
  %t367 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l147
  %t368 = load ptr, ptr %l146, !tbaa !29
  %t369 = getelementptr %"compiler/check:Checker", ptr %t368, i32 0, i32 130
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t367, ptr %t369
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i32
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i1
  %l33 = alloca i32
  %l38 = alloca i32
  %l41 = alloca i1
  %l46 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t13 = trunc i64 19 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = icmp ne i32 %t26, 0
  store i1 %t27, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l10, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = load i32, ptr %l24, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t46, i32 %t47, i32 0)
  store i32 %t48, ptr %l25
  br label %bb9
bb9:
  %t49 = load i32, ptr %l25, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l28
  br label %bb11
bb11:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l33
  br label %bb14
bb13:
  br label %bb27
bb14:
  %t66 = load i32, ptr %l33, !tbaa !23
  store i32 %t66, ptr %l2, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l38
  br label %bb15
bb15:
  %t77 = load i32, ptr %l38, !range !{i32 0, i32 33}
  %t79 = trunc i64 19 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l46
  br label %bb18
bb17:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb19
bb18:
  %t92 = load i32, ptr %l46, !tbaa !23
  %t93 = icmp ne i32 %t92, 0
  store i1 %t93, ptr %l41, !tbaa !21
  br label %bb19
bb19:
  %t95 = load i1, ptr %l41, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l50, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  store ptr %t107, ptr %l53, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l2, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l58
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t118 = load ptr, ptr %l53, !tbaa !29
  %t119 = load i32, ptr %l58, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t118, i32 %t119, i32 0)
  store i32 %t120, ptr %l59
  br label %bb23
bb23:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l1, !tbaa !23
  %t130 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t126, i32 %t127)
  store i64 %t130, ptr %l64
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l50, !tbaa !29
  %t132 = load i32, ptr %l59, !tbaa !23
  %t133 = load i64, ptr %l64, !tbaa !24
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t131, i32 %t132, i64 %t133)
  store i32 %t134, ptr %l65
  br label %bb25
bb25:
  %t135 = load i32, ptr %l65, !tbaa !23
  store i32 %t135, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t136 = load i32, ptr %l1, !tbaa !23
  store i32 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"compiler/check:seqOf" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i32
  %l11 = alloca i32
  %l19 = alloca i32
  %l20 = alloca %"compiler/check:seqOf"
  %l23 = alloca i1
  %l28 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i1
  %l41 = alloca i32
  %l42 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l47 = alloca %"compiler/check:seqOf"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/check:seqOf" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i32, ptr %l11, !tbaa !23
  store i32 %t12, ptr %l3, !tbaa !23
  %t13 = load i32, ptr %l3, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = icmp ne i32 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l19
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t29 = load i32, ptr %l19, !tbaa !23
  %t30 = call %"compiler/check:seqOf" @compiler_2fcheck_3aseqOf_2ector(ptr %s1, i32 %t29, i64 -1, i64 -1, i64 -1)
  store %"compiler/check:seqOf" %t30, ptr %l20
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/check:seqOf", ptr %l20
  %t32 = insertvalue { i32, %"compiler/check:seqOf" } zeroinitializer, %"compiler/check:seqOf" %t31, 1
  store { i32, %"compiler/check:seqOf" } %t32, ptr %rv
  br label %ret
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load i1, ptr %l23, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t42 = insertvalue { i32, %"compiler/check:seqOf" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/check:seqOf" } %t42, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t43, i32 %t44, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d46, i32 0, i32 1) }, i64 1)
  store i64 %t47, ptr %l28
  br label %bb12
bb12:
  %t48 = load i64, ptr %l28, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t49, i32 %t50, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d47, i32 0, i32 1) }, i64 0)
  store i64 %t53, ptr %l31
  br label %bb13
bb13:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l4, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  br i1 %t57, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb16
bb15:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = icmp slt i64 %t59, 0
  store i1 %t61, ptr %l34, !tbaa !21
  br label %bb16
bb16:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t65 = insertvalue { i32, %"compiler/check:seqOf" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/check:seqOf" } %t65, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l4, !tbaa !24
  %t68 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %t66, i64 %t67, i32 %t68)
  store i32 %t72, ptr %l41
  br label %bb20
bb20:
  %t73 = load i64, ptr %l4, !tbaa !24
  store i64 %t73, ptr %l42, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  store i64 %t74, ptr %l43, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l2, !tbaa !23
  %t79 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t75, i32 %t76, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d48, i32 0, i32 1) }, i64 2)
  store i64 %t79, ptr %l46
  br label %bb21
bb21:
  %t80 = load i32, ptr %l41, !tbaa !23
  %t81 = load i64, ptr %l42, !tbaa !24
  %t82 = load i64, ptr %l43, !tbaa !24
  %t83 = load i64, ptr %l46, !tbaa !24
  %t84 = call %"compiler/check:seqOf" @compiler_2fcheck_3aseqOf_2ector(ptr %s0, i32 %t80, i64 %t81, i64 %t82, i64 %t83)
  store %"compiler/check:seqOf" %t84, ptr %l47
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t85 = load %"compiler/check:seqOf", ptr %l47
  %t86 = insertvalue { i32, %"compiler/check:seqOf" } zeroinitializer, %"compiler/check:seqOf" %t85, 1
  store { i32, %"compiler/check:seqOf" } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/check:seqOf" }, ptr %rv
  ret { i32, %"compiler/check:seqOf" } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i32
  %l34 = alloca i32
  %l39 = alloca i32
  %l41 = alloca ptr
  %l46 = alloca i32
  %l51 = alloca i64
  %l56 = alloca i64
  %l58 = alloca i32
  %l68 = alloca ptr
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  store ptr %a1, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l13, !tbaa !24
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l15
  br label %bb3
bb3:
  %t9 = load i64, ptr %l13, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb30
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t15, i64 %t16)
  store i32 %t19, ptr %l20
  br label %bb7
bb7:
  %t20 = load i32, ptr %l20, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  store ptr %a2, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t23 = load i64, ptr %l8, !tbaa !24
  store i64 %t23, ptr %l22, !tbaa !24
  %t24 = load ptr, ptr %l7, !tbaa !29
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t24)
  store i64 %t26, ptr %l24
  br label %bb9
bb9:
  %t27 = load i64, ptr %l22, !tbaa !24
  %t28 = load i64, ptr %l24, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  br label %bb28
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l7, !tbaa !29
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t33, i64 %t34)
  store i32 %t37, ptr %l29
  br label %bb13
bb13:
  %t38 = load i32, ptr %l29, !tbaa !23
  store i32 %t38, ptr %l9, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l6, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l34
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l9, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l39
  br label %bb15
bb15:
  %t59 = load i32, ptr %l34, !tbaa !23
  %t60 = load i32, ptr %l39, !tbaa !23
  %t61 = icmp ne i32 %t59, %t60
  br i1 %t61, label %bb16, label %bb17
bb16:
  br label %bb27
bb17:
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l41, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l6, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l46
  br label %bb19
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l6, !tbaa !23
  %t83 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t79, i32 %t80)
  store i64 %t83, ptr %l51
  br label %bb20
bb20:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l9, !tbaa !23
  %t93 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t89, i32 %t90)
  store i64 %t93, ptr %l56
  br label %bb21
bb21:
  %t94 = load i64, ptr %l51, !tbaa !65
  %t95 = load i64, ptr %l56, !tbaa !65
  %t96 = and i64 %t94, %t95
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i32, ptr %l46, !tbaa !23
  %t100 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t97, i32 %t98, i64 %t96)
  store i32 %t100, ptr %l58
  br label %bb22
bb22:
  %t101 = load i32, ptr %l58, !tbaa !23
  store i32 %t101, ptr %l10, !tbaa !23
  %t102 = load i32, ptr %l10, !tbaa !23
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t106 = icmp ne i32 %t102, %t103
  br i1 %t106, label %bb23, label %bb24
bb23:
  %t108 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3, i32 %t108)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb8
bb28:
  br label %bb29
bb29:
  %t115 = load i64, ptr %l5, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l5, !tbaa !24
  br label %bb2
bb30:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l68, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t123 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s0, ptr %v3, ptr %t120, ptr %l3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t123, ptr %l71
  br label %bb31
bb31:
  %t124 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  %t125 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t124, ptr %t125
  %t126 = load ptr, ptr %l68, !tbaa !29
  %t128 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v3, ptr %v3, ptr %t126, ptr %t125)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %l73
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t129 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l4 = alloca ptr
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t9 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %t6, i32 %a1, %"compiler/source:Span" %a2)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, ptr %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, [3 x i64] }
  %l13 = alloca i32
  %l16 = alloca i64
  %l19 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca i32
  %l41 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l55 = alloca i1
  %l60 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l72 = alloca { i64, [3 x i64] }
  %l80 = alloca ptr
  %l86 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i1
  %l91 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca i1
  %l103 = alloca ptr
  %l106 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i64
  %l114 = alloca ptr
  %l116 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l120 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca ptr
  %l128 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca ptr
  %l137 = alloca ptr
  %t171 = alloca { i64, [4 x i64] }, align 8
  %t230 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i32, ptr %l13, !tbaa !23
  store i32 %t4, ptr %l7, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 10
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load i64, ptr %l16, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l7, !tbaa !23
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l19
  br label %bb3
bb3:
  %t16 = load i1, ptr %l19, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l7, !tbaa !23
  %t28 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l26
  br label %bb6
bb5:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb7
bb6:
  %t29 = load i1, ptr %l26, !tbaa !21
  store i1 %t29, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 10
  %t34 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = load i32, ptr %l7, !tbaa !23
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t37, ptr %t38, i32 %t40)
  store ptr %t44, ptr %l34
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l34, !tbaa !29
  store ptr %t45, ptr %l9, !tbaa !29
  %t46 = load ptr, ptr %l9, !tbaa !29
  %t49 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t46)
  store i32 %t49, ptr %l37
  br label %bb13
bb13:
  %t50 = load i32, ptr %l37, !tbaa !23
  store i32 %t50, ptr %l10, !tbaa !23
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l7, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l46
  br label %bb16
bb15:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb17
bb16:
  %t67 = load i1, ptr %l46, !tbaa !21
  store i1 %t67, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t68 = load i1, ptr %l41, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t69 = load i32, ptr %l10, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  store i1 %t73, ptr %l47, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l47, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = load i32, ptr %l10, !tbaa !23
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t80 = icmp ne i32 %t76, %t77
  store i1 %t80, ptr %l51, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t82 = load i1, ptr %l51, !tbaa !21
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l10, !tbaa !23
  %t92 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t88, i32 %t89)
  store i1 %t92, ptr %l60
  br label %bb26
bb25:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb27
bb26:
  %t93 = load i1, ptr %l60, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l55, !tbaa !21
  br label %bb27
bb27:
  %t96 = load i1, ptr %l55, !tbaa !21
  br i1 %t96, label %bb28, label %bb29
bb28:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t97)
  store ptr %t99, ptr %l63
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t100 = load ptr, ptr %l63, !tbaa !29
  store ptr %t100, ptr %l64, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v3, ptr %v0, ptr %t101)
  store { i64, ptr } %t103, ptr %l66
  br label %bb31
bb31:
  %t104 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t105 = load ptr, ptr %l64, !tbaa !29
  %t106 = getelementptr %"compiler/check:frame", ptr %t105, i32 0, i32 48
  store { i64, ptr } %t104, ptr %t106, !tbaa !27
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 13
  %t110 = load { i64, [3 x i64] }, ptr %t109
  store { i64, [3 x i64] } %t110, ptr %l11
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l69, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t117 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %t113, ptr %t114)
  store { i64, [3 x i64] } %t117, ptr %l72
  br label %bb33
bb33:
  %t118 = load { i64, [3 x i64] }, ptr %l72
  %t119 = load ptr, ptr %l69, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 13
  store { i64, [3 x i64] } %t118, ptr %t120
  %t121 = load i32, ptr %l7, !tbaa !23
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t125 = icmp ne i32 %t121, %t122
  br i1 %t125, label %bb34, label %bb35
bb34:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l9, !tbaa !29
  %t129 = load i32, ptr %l7, !tbaa !23
  %t135 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t127, ptr %t128, i32 %t129, %"compiler/source:Span" %a4)
  store ptr %t135, ptr %l80
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t136 = load ptr, ptr %l80, !tbaa !29
  store ptr %t136, ptr %l9, !tbaa !29
  br label %bb37
bb37:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load { i64, [3 x i64] }, ptr %l11
  %t141 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 13
  store { i64, [3 x i64] } %t138, ptr %t141
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 10
  %t145 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eTrun_Haa7c8ccc08c8123d0b87c9688e5d351e(ptr %v0, ptr %t144, i64 %t145)
  br label %bb38
bb38:
  %t148 = load i32, ptr %l7, !tbaa !23
  store i32 %t148, ptr %l86, !tbaa !23
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t149)
  store i32 %t151, ptr %l88
  br label %bb39
bb39:
  %t152 = load i32, ptr %l86, !tbaa !23
  %t153 = load i32, ptr %l88, !tbaa !23
  %t154 = icmp eq i32 %t152, %t153
  br i1 %t154, label %bb40, label %bb41
bb40:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l91, !tbaa !29
  %t157 = load ptr, ptr %l9, !tbaa !29
  %t160 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t157)
  store i32 %t160, ptr %l94
  br label %bb42
bb41:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb44
bb42:
  %t161 = load ptr, ptr %l91, !tbaa !29
  %t162 = load i32, ptr %l94, !tbaa !23
  %t163 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t161, i32 %t162)
  store i1 %t163, ptr %l95
  br label %bb43
bb43:
  %t164 = load i1, ptr %l95, !tbaa !21
  store i1 %t164, ptr %l90, !tbaa !21
  br label %bb44
bb44:
  %t165 = load i1, ptr %l90, !tbaa !21
  br i1 %t165, label %bb45, label %bb46
bb45:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t168 = load %"compiler/source:Span", ptr %l1
  %t169 = load i32, ptr %l7, !tbaa !23
  %t170 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t171, i32 0, i32 0
  store i64 2, ptr %t172
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t168, 0
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } %t174, i32 %t169, 1
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, ptr %t170, 2
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t171, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t178, ptr %t179
  %t180 = load { i64, [4 x i64] }, ptr %t171
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t180, ptr %t182
  %t186 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t166, %"compiler/source:Span" %t167, ptr %t182)
  store ptr %t186, ptr %l103
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t187 = load ptr, ptr %l103, !tbaa !29
  store ptr %t187, ptr %l9, !tbaa !29
  br label %bb48
bb48:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l7, !tbaa !23
  %t192 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t188, i32 %t189)
  store i1 %t192, ptr %l106
  br label %bb49
bb49:
  %t193 = load i1, ptr %l106, !tbaa !21
  %t194 = xor i1 %t193, true
  br i1 %t194, label %bb50, label %bb51
bb50:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l2, !tbaa !29
  %t201 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %t196, ptr %t197)
  store i64 %t201, ptr %l112
  br label %bb52
bb51:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb53
bb52:
  %t202 = load i64, ptr %l112, !tbaa !24
  %t203 = icmp slt i64 %t202, 0
  store i1 %t203, ptr %l108, !tbaa !21
  br label %bb53
bb53:
  %t205 = load i1, ptr %l108, !tbaa !21
  br i1 %t205, label %bb54, label %bb55
bb54:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l114, !tbaa !29
  %t207 = load ptr, ptr %l9, !tbaa !29
  store ptr %t207, ptr %l116, !tbaa !29
  %t209 = load ptr, ptr %l3, !tbaa !29
  %t211 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t209)
  store %"compiler/source:Span" %t211, ptr %l118
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t212 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t213 = load ptr, ptr %l114, !tbaa !29
  %t214 = load ptr, ptr %l116, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l118
  %t217 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t213, ptr %t214, %"compiler/source:Span" %t215, i64 %t212)
  store i1 %t217, ptr %l120
  br label %bb57
bb57:
  br label %bb58
bb58:
  br i1 %a6, label %bb59, label %bb60
bb59:
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l122, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l123
  %t222 = load ptr, ptr %l2, !tbaa !29
  store ptr %t222, ptr %l124, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l2, !tbaa !29
  %t225 = load ptr, ptr %l9, !tbaa !29
  %t229 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreCopy(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %t223, ptr %t224, ptr %t225)
  store ptr %t229, ptr %l128
  br label %bb61
bb60:
  br label %bb63
bb61:
  store { i64, [3 x i64] } zeroinitializer, ptr %t230
  %t231 = getelementptr { i64, [3 x i64] }, ptr %t230, i32 0, i32 0
  store i64 1, ptr %t231
  %t232 = load %"compiler/source:Span", ptr %l123
  %t233 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t232, 0
  %t234 = load ptr, ptr %l124, !tbaa !29
  %t235 = insertvalue { %"compiler/source:Span", ptr, ptr } %t233, ptr %t234, 1
  %t236 = load ptr, ptr %l128, !tbaa !29
  %t237 = insertvalue { %"compiler/source:Span", ptr, ptr } %t235, ptr %t236, 2
  %t238 = getelementptr { i64, [3 x i64] }, ptr %t230, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t237, ptr %t238
  %t239 = load { i64, [3 x i64] }, ptr %t230
  %t241 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t239, ptr %t241
  %t242 = load ptr, ptr %l122, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t242, ptr %t241)
  br label %bb62
bb62:
  br label %ret
bb63:
  %t244 = load ptr, ptr %l0, !tbaa !29
  store ptr %t244, ptr %l131, !tbaa !29
  %t245 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t245, ptr %l132
  %t246 = load ptr, ptr %l2, !tbaa !29
  store ptr %t246, ptr %l133, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l2, !tbaa !29
  %t249 = load ptr, ptr %l9, !tbaa !29
  %t253 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreCopy(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %t247, ptr %t248, ptr %t249)
  store ptr %t253, ptr %l137
  br label %bb64
bb64:
  %t254 = load ptr, ptr %l131, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l132
  %t256 = load ptr, ptr %l133, !tbaa !29
  %t257 = load ptr, ptr %l137, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreOver(ptr %v0, ptr %v1, ptr %v0, ptr %t254, %"compiler/source:Span" %t255, ptr %t256, ptr %t257)
  br label %bb65
bb65:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreOver(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i1
  %l35 = alloca ptr
  %l44 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca i64
  %l65 = alloca ptr
  %l70 = alloca i64
  %l71 = alloca i32
  %l72 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca ptr
  %l90 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l103 = alloca ptr
  %l107 = alloca ptr
  %s2 = alloca %olang.scope
  %t36 = alloca { i64, [3 x i64] }, align 8
  %t81 = alloca { i64, [3 x i64] }, align 8
  %t163 = alloca { i64, [4 x i64] }, align 8
  %t179 = alloca { i64, [3 x i64] }, align 8
  %t205 = alloca { i64, [4 x i64] }, align 8
  %t224 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load i32, ptr %l12, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l4, !tbaa !23
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l19
  br label %bb4
bb4:
  %t16 = load i1, ptr %l19, !tbaa !21
  store i1 %t16, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l16, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l25
  br label %bb8
bb8:
  %t28 = load i1, ptr %l25, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t35 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 0
  store i64 1, ptr %t37
  %t39 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t33, 0
  %t41 = insertvalue { %"compiler/source:Span", ptr, ptr } %t39, ptr %t34, 1
  %t43 = insertvalue { %"compiler/source:Span", ptr, ptr } %t41, ptr %t35, 2
  %t44 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t43, ptr %t44
  %t45 = load { i64, [3 x i64] }, ptr %t36
  %t47 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t45, ptr %t47
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t32, ptr %t47)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %ret
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estable(ptr %v0, ptr %v1, ptr %v1, ptr %t50, ptr %t51)
  store ptr %t54, ptr %l35
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l35, !tbaa !29
  store ptr %t55, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s2, ptr %t60, %"compiler/source:Span" %t61, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb18:
  %t64 = load ptr, ptr %l5, !tbaa !29
  store ptr %t64, ptr %l2, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  %t68 = load i32, ptr %l4, !tbaa !23
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t66, %"compiler/source:Span" %t67, i32 %t68)
  store i64 %t72, ptr %l44
  br label %bb19
bb19:
  %t73 = load i64, ptr %l44, !tbaa !24
  store i64 %t73, ptr %l6, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l1
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = trunc i64 %t76 to i32
  %t80 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [3 x i64] }, ptr %t81, i32 0, i32 0
  store i64 0, ptr %t82
  %t84 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t75, 0
  %t86 = insertvalue { %"compiler/source:Span", i32, ptr } %t84, i32 %t78, 1
  %t88 = insertvalue { %"compiler/source:Span", i32, ptr } %t86, ptr %t80, 2
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t81, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t88, ptr %t89
  %t90 = load { i64, [3 x i64] }, ptr %t81
  %t92 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t90, ptr %t92
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t74, ptr %t92)
  br label %bb20
bb20:
  store i64 -1, ptr %l7, !tbaa !24
  %t95 = load ptr, ptr %l2, !tbaa !29
  store ptr %t95, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t96 = load ptr, ptr %l53, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb21, label %bb22
bb21:
  %t99 = load ptr, ptr %l53, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 8}
  %t102 = icmp eq i64 %t100, 0
  store i1 %t102, ptr %l54, !tbaa !21
  br label %bb22
bb22:
  %t103 = load i1, ptr %l54, !tbaa !21
  br i1 %t103, label %bb23, label %bb24
bb23:
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t106, i32 0, i32 0
  %t108 = load %"compiler/source:Span", ptr %t107
  store %"compiler/source:Span" %t108, ptr %l8
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t112, i32 0, i32 1
  %t114 = load i32, ptr %t113
  store i32 %t114, ptr %l9, !tbaa !23
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t118, i32 0, i32 2
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l10, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t122)
  store ptr %t124, ptr %l65
  br label %bb25
bb24:
  br label %bb30
bb25:
  %t125 = load ptr, ptr %l65, !tbaa !29
  %t127 = getelementptr %"compiler/check:frame", ptr %t125, i32 0, i32 23
  %t128 = load i32, ptr %l10, !tbaa !23
  %t130 = sext i32 %t128 to i64
  %t133 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t127, i64 %t130)
  %t134 = extractvalue { i32, i64 } %t133, 1
  %t135 = extractvalue { i32, i64 } %t133, 0
  store i32 %t135, ptr %l71
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb27, label %ok.137, !prof !99
ok.137:
  store i64 %t134, ptr %l70
  br label %bb26
bb26:
  %t138 = load i64, ptr %l70, !tbaa !24
  store i64 %t138, ptr %l63, !tbaa !24
  br label %bb29
bb27:
  br label %bb28
bb28:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l63, !tbaa !24
  br label %bb29
bb29:
  %t139 = load i64, ptr %l63, !tbaa !24
  store i64 %t139, ptr %l7, !tbaa !24
  br label %bb30
bb30:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l72, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l1
  %t143 = load ptr, ptr %l2, !tbaa !29
  %t144 = load i64, ptr %l7, !tbaa !24
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v1, ptr %v0, ptr %t141, %"compiler/source:Span" %t142, ptr %t143, i64 %t144)
  store ptr %t149, ptr %l77
  br label %bb31
bb31:
  %t150 = load ptr, ptr %l72, !tbaa !29
  %t151 = load ptr, ptr %l77, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t150, ptr %t151)
  br label %bb32
bb32:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l78, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l79
  %t154 = load ptr, ptr %l2, !tbaa !29
  store ptr %t154, ptr %l80, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l1
  %t157 = load %"compiler/source:Span", ptr %l1
  %t158 = load i32, ptr %l4, !tbaa !23
  %t159 = load i64, ptr %l6, !tbaa !24
  %t161 = trunc i64 %t159 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t163, i32 0, i32 0
  store i64 0, ptr %t164
  %t166 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t157, 0
  %t168 = insertvalue { %"compiler/source:Span", i32, i32 } %t166, i32 %t158, 1
  %t170 = insertvalue { %"compiler/source:Span", i32, i32 } %t168, i32 %t161, 2
  %t171 = getelementptr { i64, [4 x i64] }, ptr %t163, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t170, ptr %t171
  %t172 = load { i64, [4 x i64] }, ptr %t163
  %t174 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t172, ptr %t174
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t155, %"compiler/source:Span" %t156, ptr %t174)
  store ptr %t178, ptr %l90
  br label %bb33
bb33:
  store { i64, [3 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 0
  store i64 1, ptr %t180
  %t181 = load %"compiler/source:Span", ptr %l79
  %t182 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t181, 0
  %t183 = load ptr, ptr %l80, !tbaa !29
  %t184 = insertvalue { %"compiler/source:Span", ptr, ptr } %t182, ptr %t183, 1
  %t185 = load ptr, ptr %l90, !tbaa !29
  %t186 = insertvalue { %"compiler/source:Span", ptr, ptr } %t184, ptr %t185, 2
  %t187 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t186, ptr %t187
  %t188 = load { i64, [3 x i64] }, ptr %t179
  %t190 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t188, ptr %t190
  %t191 = load ptr, ptr %l78, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t191, ptr %t190)
  br label %bb34
bb34:
  %t193 = load i64, ptr %l7, !tbaa !24
  %t195 = icmp sge i64 %t193, 0
  br i1 %t195, label %bb35, label %bb36
bb35:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l95, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t198, ptr %l96
  %t199 = load %"compiler/source:Span", ptr %l1
  %t200 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t201 = load i64, ptr %l7, !tbaa !24
  %t203 = trunc i64 %t201 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t205, i32 0, i32 0
  store i64 0, ptr %t206
  %t208 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t199, 0
  %t210 = insertvalue { %"compiler/source:Span", i32, i32 } %t208, i32 %t200, 1
  %t212 = insertvalue { %"compiler/source:Span", i32, i32 } %t210, i32 %t203, 2
  %t213 = getelementptr { i64, [4 x i64] }, ptr %t205, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t212, ptr %t213
  %t214 = load { i64, [4 x i64] }, ptr %t205
  %t216 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t214, ptr %t216
  store ptr %t216, ptr %l103, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l1
  %t219 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t223 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t217, %"compiler/source:Span" %t218, i32 %t219, i64 1)
  store ptr %t223, ptr %l107
  br label %bb37
bb36:
  br label %bb39
bb37:
  store { i64, [3 x i64] } zeroinitializer, ptr %t224
  %t225 = getelementptr { i64, [3 x i64] }, ptr %t224, i32 0, i32 0
  store i64 1, ptr %t225
  %t226 = load %"compiler/source:Span", ptr %l96
  %t227 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t226, 0
  %t228 = load ptr, ptr %l103, !tbaa !29
  %t229 = insertvalue { %"compiler/source:Span", ptr, ptr } %t227, ptr %t228, 1
  %t230 = load ptr, ptr %l107, !tbaa !29
  %t231 = insertvalue { %"compiler/source:Span", ptr, ptr } %t229, ptr %t230, 2
  %t232 = getelementptr { i64, [3 x i64] }, ptr %t224, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t231, ptr %t232
  %t233 = load { i64, [3 x i64] }, ptr %t224
  %t235 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t233, ptr %t235
  %t236 = load ptr, ptr %l95, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t236, ptr %t235)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etargetHoldsRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t18 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l14
  br label %bb6
bb6:
  %t26 = load i1, ptr %l14, !tbaa !21
  store i1 %t26, ptr %l3, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_5f447d0cb8af3524_fdbf87197f7ceb70)
  unreachable
bb12:
  %t27 = load i1, ptr %l3, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %s0, ptr %a0, ptr %l2, i32 %a1, i1 true)
  br label %bb2
bb2:
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i32
  %l20 = alloca i64
  %l25 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l39 = alloca i32
  %l42 = alloca i64
  %l47 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i64
  %l71 = alloca i32
  %l78 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load i32, ptr %l15, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l20
  br label %bb2
bb2:
  %t22 = load i64, ptr %l20, !tbaa !65
  store i64 %t22, ptr %l4, !tbaa !65
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t32 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t28, i32 %a1)
  store { i64, ptr } %t32, ptr %l25
  br label %bb3
bb3:
  %t33 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb5, label %bb6
bb5:
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t46, ptr %l32, !tbaa !27
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 %t47
  %t52 = load i32, ptr %t51, !tbaa !33
  store i32 %t52, ptr %l8, !tbaa !23
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l8, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l39
  br label %bb8
bb8:
  %t64 = load i32, ptr %l3, !tbaa !23
  %t65 = load i32, ptr %l39, !tbaa !23
  %t67 = icmp eq i32 %t65, %t64
  br i1 %t67, label %bb9, label %bb10
bb9:
  %t69 = load i64, ptr %l4, !tbaa !65
  store i64 %t69, ptr %l42, !tbaa !65
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l8, !tbaa !23
  %t79 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l47
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t80 = load i64, ptr %l47, !tbaa !65
  %t81 = xor i64 %t80, -1
  %t82 = load i64, ptr %l42, !tbaa !65
  %t84 = and i64 %t82, %t81
  store i64 %t84, ptr %l4, !tbaa !65
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l6, !tbaa !24
  br label %bb4
bb14:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %t90, i32 %t91)
  store i64 %t94, ptr %l54
  br label %bb15
bb15:
  %t95 = load i64, ptr %l54, !tbaa !24
  store i64 %t95, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t98 = icmp sge i64 %t96, 64
  br i1 %t98, label %bb16, label %bb17
bb16:
  %t100 = sub i64 0, 1
  store i64 %t100, ptr %l57, !tbaa !65
  br label %bb18
bb17:
  %t102 = load i64, ptr %l9, !tbaa !24
  store i64 %t102, ptr %l59, !tbaa !24
  %t103 = load i64, ptr %l59, !tbaa !24
  %t104 = load i64, ptr %l59, !tbaa !24
  %t105 = shl i64 1, %t104
  %t107 = sub i64 %t105, 1
  store i64 %t107, ptr %l57, !tbaa !65
  br label %bb18
bb18:
  %t109 = load i64, ptr %l57, !tbaa !65
  store i64 %t109, ptr %l10, !tbaa !65
  %t110 = load i64, ptr %l4, !tbaa !65
  %t111 = load i64, ptr %l10, !tbaa !65
  %t114 = and i64 %t110, %t111
  store i64 %t114, ptr %l4, !tbaa !65
  %t116 = load i64, ptr %l4, !tbaa !65
  %t118 = icmp eq i64 %t116, 0
  br i1 %t118, label %bb19, label %bb20
bb19:
  %t120 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t120, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t122 = load i64, ptr %l4, !tbaa !65
  %t123 = load i64, ptr %l10, !tbaa !65
  %t126 = icmp eq i64 %t122, %t123
  br i1 %t126, label %bb22, label %bb23
bb22:
  %t128 = load i32, ptr %l3, !tbaa !23
  store i32 %t128, ptr %l71, !tbaa !23
  br label %bb25
bb23:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  %t136 = load i32, ptr %l3, !tbaa !23
  %t137 = load i64, ptr %l4, !tbaa !65
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t135, i32 %t136, i64 %t137)
  store i32 %t141, ptr %l78
  br label %bb24
bb24:
  %t142 = load i32, ptr %l78, !tbaa !23
  store i32 %t142, ptr %l71, !tbaa !23
  br label %bb25
bb25:
  %t143 = load i32, ptr %l71, !tbaa !23
  store i32 %t143, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l22 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i32
  %l44 = alloca i32
  %l52 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l6, !tbaa !23
  store i32 %a2, ptr %l7, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l6, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l12
  br label %bb1
bb1:
  %t10 = load i1, ptr %l12, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l7, !tbaa !23
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l16
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i1, ptr %l16, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l13, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l6, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t30 = load i32, ptr %l22, !tbaa !23
  store i32 %t30, ptr %l6, !tbaa !23
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l7, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l25
  br label %bb10
bb10:
  %t36 = load i1, ptr %l25, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l29
  br label %bb13
bb12:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  %t42 = load i1, ptr %l29, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l6, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l36
  br label %bb17
bb16:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb18
bb17:
  %t56 = load i32, ptr %l36, !range !{i32 0, i32 33}
  %t58 = trunc i64 25 to i32
  %t59 = icmp eq i32 %t56, %t58
  %t61 = xor i1 %t59, true
  store i1 %t61, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l31, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l7, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l44
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t74 = load i32, ptr %l44, !tbaa !23
  store i32 %t74, ptr %l7, !tbaa !23
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l6, !tbaa !23
  %t80 = load i32, ptr %l7, !tbaa !23
  %t90 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %t78, i32 %t79, i32 %t80, ptr %a3, i1 %a4, i1 %a5)
  store i32 %t90, ptr %l52
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb24, label %ok.92, !prof !99
ok.92:
  br label %bb23
bb23:
  br label %bb26
bb24:
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:litv"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l13 = alloca %"compiler/check:litv"
  %l16 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i32
  %l29 = alloca i1
  %l32 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i32
  %l43 = alloca ptr
  %l48 = alloca ptr
  %l51 = alloca i32
  %l60 = alloca i32
  %l65 = alloca i32
  %l70 = alloca i1
  %l75 = alloca i64
  %l78 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca ptr
  %l89 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l100 = alloca %"compiler/msgs:Msg"
  %l101 = alloca i64
  %l102 = alloca ptr
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l108 = alloca i1
  %l111 = alloca i1
  %l114 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca ptr
  %l122 = alloca i1
  %l123 = alloca i32
  %l127 = alloca i32
  %l129 = alloca i32
  %l130 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca ptr
  %l137 = alloca %"compiler/source:Span"
  %l140 = alloca ptr
  %l146 = alloca i1
  %l150 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l168 = alloca ptr
  %l172 = alloca i1
  %l173 = alloca i32
  %l178 = alloca i32
  %l182 = alloca i1
  %l183 = alloca i1
  %l186 = alloca ptr
  %l191 = alloca i32
  %l192 = alloca i32
  %l196 = alloca ptr
  %l199 = alloca %"compiler/source:Span"
  %l202 = alloca { i64, ptr }
  %l204 = alloca %"compiler/msgs:Msg"
  %l205 = alloca i64
  %l206 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/check:litv" %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load %"compiler/check:litv", ptr %l13
  store %"compiler/check:litv" %t7, ptr %l2
  %t8 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 1
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb3:
  br label %bb21
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i32 %t21, ptr %l20
  br label %bb6
bb5:
  %t22 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 2
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb6:
  %t25 = load i32, ptr %l20, !tbaa !23
  store i32 %t25, ptr %l16, !tbaa !23
  br label %bb19
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t31, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i32 %t33, ptr %l26
  br label %bb9
bb8:
  %t34 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sge i64 %t35, -2147483648
  br i1 %t37, label %bb10, label %bb11
bb9:
  %t39 = load i32, ptr %l26, !tbaa !23
  store i32 %t39, ptr %l22, !tbaa !23
  br label %bb18
bb10:
  %t40 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = icmp sle i64 %t41, 2147483647
  store i1 %t43, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l29, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t51, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i32 %t53, ptr %l36
  br label %bb15
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t54)
  store i32 %t56, ptr %l38
  br label %bb16
bb15:
  %t57 = load i32, ptr %l36, !tbaa !23
  store i32 %t57, ptr %l32, !tbaa !23
  br label %bb17
bb16:
  %t58 = load i32, ptr %l38, !tbaa !23
  store i32 %t58, ptr %l32, !tbaa !23
  br label %bb17
bb17:
  %t59 = load i32, ptr %l32, !tbaa !23
  store i32 %t59, ptr %l22, !tbaa !23
  br label %bb18
bb18:
  %t60 = load i32, ptr %l22, !tbaa !23
  store i32 %t60, ptr %l16, !tbaa !23
  br label %bb19
bb19:
  %t61 = load i32, ptr %l16, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t62, ptr %t63, i32 %t61)
  store ptr %t69, ptr %l43
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t70 = load ptr, ptr %l43, !tbaa !29
  store ptr %t70, ptr %rv
  br label %ret
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t71, ptr %t72, i32 %t74)
  store ptr %t78, ptr %l48
  br label %bb22
bb22:
  %t79 = load ptr, ptr %l48, !tbaa !29
  store ptr %t79, ptr %l4, !tbaa !29
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t83 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t80)
  store i32 %t83, ptr %l51
  br label %bb23
bb23:
  %t84 = load i32, ptr %l51, !tbaa !23
  store i32 %t84, ptr %l5, !tbaa !23
  %t85 = load i32, ptr %l5, !tbaa !23
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t89 = icmp eq i32 %t85, %t86
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t91, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l5, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l60
  br label %bb27
bb27:
  %t103 = load i32, ptr %l60, !tbaa !23
  store i32 %t103, ptr %l6, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l6, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l65
  br label %bb28
bb28:
  %t114 = load i32, ptr %l65, !range !{i32 0, i32 33}
  store i32 %t114, ptr %l7
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l6, !tbaa !23
  %t124 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l70
  br label %bb29
bb29:
  %t125 = load i1, ptr %l70, !tbaa !21
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l6, !tbaa !23
  %t135 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t131, i32 %t132)
  store i64 %t135, ptr %l75
  br label %bb32
bb31:
  br label %bb73
bb32:
  %t136 = load i64, ptr %l75, !tbaa !24
  store i64 %t136, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = icmp slt i64 %t137, 32
  br i1 %t139, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l78, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t142)
  store %"compiler/source:Span" %t144, ptr %l80
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t145 = load ptr, ptr %l4, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s4, ptr %t151, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i32 %t153, ptr %l85
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l78, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l80
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load i32, ptr %l85, !tbaa !23
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t154, %"compiler/source:Span" %t155, ptr %t156, i32 %t157)
  store ptr %t158, ptr %l86
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t159 = load ptr, ptr %l86, !tbaa !29
  store ptr %t159, ptr %rv
  br label %ret
bb38:
  %t160 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t162 = trunc i64 31 to i32
  %t163 = icmp eq i32 %t160, %t162
  br i1 %t163, label %bb39, label %bb40
bb39:
  %t165 = load i64, ptr %l8, !tbaa !24
  %t167 = icmp sgt i64 %t165, 64
  store i1 %t167, ptr %l89, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb41
bb41:
  %t169 = load i1, ptr %l89, !tbaa !21
  br i1 %t169, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s5
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l92, !tbaa !29
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t175 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t171, ptr %t172)
  store %"compiler/source:Span" %t175, ptr %l95
  br label %bb44
bb43:
  br label %bb50
bb44:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l5, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l98
  br label %bb45
bb45:
  %t181 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgWide(ptr %s5, ptr %s5, { i64, ptr } %t187)
  store %"compiler/msgs:Msg" %t189, ptr %l100
  br label %bb46
bb46:
  %t190 = load ptr, ptr %l92, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l95
  %t192 = load %"compiler/msgs:Msg", ptr %l100
  %t193 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t190, %"compiler/source:Span" %t191, %"compiler/msgs:Msg" %t192)
  store i64 %t193, ptr %l101
  br label %bb47
bb47:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l102, !tbaa !29
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t195)
  store %"compiler/source:Span" %t197, ptr %l104
  br label %bb48
bb48:
  %t198 = load ptr, ptr %l102, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l104
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t198, %"compiler/source:Span" %t199)
  store ptr %t200, ptr %l105
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t201 = load ptr, ptr %l105, !tbaa !29
  store ptr %t201, ptr %rv
  br label %ret
bb50:
  %t202 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t204 = trunc i64 31 to i32
  %t205 = icmp eq i32 %t202, %t204
  br i1 %t205, label %bb51, label %bb52
bb51:
  %t207 = load i64, ptr %l8, !tbaa !24
  %t209 = icmp ne i64 %t207, 32
  store i1 %t209, ptr %l108, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb53
bb53:
  %t211 = load i1, ptr %l108, !tbaa !21
  br i1 %t211, label %bb54, label %bb55
bb54:
  %t212 = load i64, ptr %l8, !tbaa !24
  %t214 = icmp ne i64 %t212, 64
  store i1 %t214, ptr %l111, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb56
bb56:
  %t216 = load i1, ptr %l111, !tbaa !21
  br i1 %t216, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s6
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l114, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t218)
  store %"compiler/source:Span" %t220, ptr %l116
  br label %bb59
bb58:
  br label %bb67
bb59:
  %t221 = load ptr, ptr %l4, !tbaa !29
  store ptr %t221, ptr %l117, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  %t228 = load i32, ptr %l6, !tbaa !23
  %t231 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t227, i32 %t228)
  store i1 %t231, ptr %l122
  br label %bb60
bb60:
  %t232 = load i1, ptr %l122, !tbaa !21
  br i1 %t232, label %bb61, label %bb62
bb61:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s6, ptr %t238, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i32 %t240, ptr %l127
  br label %bb63
bb62:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t241)
  store i32 %t243, ptr %l129
  br label %bb64
bb63:
  %t244 = load i32, ptr %l127, !tbaa !23
  store i32 %t244, ptr %l123, !tbaa !23
  br label %bb65
bb64:
  %t245 = load i32, ptr %l129, !tbaa !23
  store i32 %t245, ptr %l123, !tbaa !23
  br label %bb65
bb65:
  %t246 = load ptr, ptr %l114, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l116
  %t248 = load ptr, ptr %l117, !tbaa !29
  %t249 = load i32, ptr %l123, !tbaa !23
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t246, %"compiler/source:Span" %t247, ptr %t248, i32 %t249)
  store ptr %t250, ptr %l130
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t251 = load ptr, ptr %l130, !tbaa !29
  store ptr %t251, ptr %rv
  br label %ret
bb67:
  %t252 = load i32, ptr %l6, !tbaa !23
  %t253 = load i32, ptr %l5, !tbaa !23
  %t256 = icmp ne i32 %t252, %t253
  br i1 %t256, label %bb68, label %bb69
bb68:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l135, !tbaa !29
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t259)
  store %"compiler/source:Span" %t261, ptr %l137
  br label %bb70
bb69:
  %t262 = load ptr, ptr %l4, !tbaa !29
  store ptr %t262, ptr %l134, !tbaa !29
  br label %bb72
bb70:
  %t264 = load ptr, ptr %l4, !tbaa !29
  %t265 = load i32, ptr %l6, !tbaa !23
  %t266 = load ptr, ptr %l135, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l137
  %t270 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t266, %"compiler/source:Span" %t267, ptr %t264, i32 %t265)
  store ptr %t270, ptr %l140
  br label %bb71
bb71:
  %t271 = load ptr, ptr %l140, !tbaa !29
  store ptr %t271, ptr %l134, !tbaa !29
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t272 = load ptr, ptr %l134, !tbaa !29
  store ptr %t272, ptr %rv
  br label %ret
bb73:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  %t279 = load i32, ptr %l6, !tbaa !23
  %t282 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t278, i32 %t279)
  store i1 %t282, ptr %l146
  br label %bb74
bb74:
  %t283 = load i1, ptr %l146, !tbaa !21
  br i1 %t283, label %bb75, label %bb76
bb75:
  %t284 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t286 = trunc i64 14 to i32
  %t287 = icmp eq i32 %t284, %t286
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb77, label %bb78
bb76:
  br label %bb88
bb77:
  store %olang.scope zeroinitializer, ptr %s8
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l150, !tbaa !29
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t292)
  store %"compiler/source:Span" %t294, ptr %l152
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t295 = load ptr, ptr %l4, !tbaa !29
  store ptr %t295, ptr %l153, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/check:Checker", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = getelementptr %"compiler/generic:Program", ptr %t299, i32 0, i32 2
  %t303 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s8, ptr %t301, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i32 %t303, ptr %l157
  br label %bb80
bb80:
  %t304 = load ptr, ptr %l150, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l152
  %t306 = load ptr, ptr %l153, !tbaa !29
  %t307 = load i32, ptr %l157, !tbaa !23
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t304, %"compiler/source:Span" %t305, ptr %t306, i32 %t307)
  store ptr %t308, ptr %l158
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t309 = load ptr, ptr %l158, !tbaa !29
  store ptr %t309, ptr %rv
  br label %ret
bb82:
  %t310 = load i32, ptr %l6, !tbaa !23
  %t311 = load i32, ptr %l5, !tbaa !23
  %t314 = icmp ne i32 %t310, %t311
  br i1 %t314, label %bb83, label %bb84
bb83:
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l163, !tbaa !29
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t317)
  store %"compiler/source:Span" %t319, ptr %l165
  br label %bb85
bb84:
  %t320 = load ptr, ptr %l4, !tbaa !29
  store ptr %t320, ptr %l162, !tbaa !29
  br label %bb87
bb85:
  %t322 = load ptr, ptr %l4, !tbaa !29
  %t323 = load i32, ptr %l6, !tbaa !23
  %t324 = load ptr, ptr %l163, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l165
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t324, %"compiler/source:Span" %t325, ptr %t322, i32 %t323)
  store ptr %t328, ptr %l168
  br label %bb86
bb86:
  %t329 = load ptr, ptr %l168, !tbaa !29
  store ptr %t329, ptr %l162, !tbaa !29
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  %t330 = load ptr, ptr %l162, !tbaa !29
  store ptr %t330, ptr %rv
  br label %ret
bb88:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i32, ptr %l6, !tbaa !23
  %t335 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t331, i32 %t332)
  store i1 %t335, ptr %l172
  br label %bb89
bb89:
  %t336 = load i1, ptr %l172, !tbaa !21
  br i1 %t336, label %bb90, label %bb91
bb90:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/check:Checker", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  %t342 = getelementptr %"compiler/generic:Program", ptr %t340, i32 0, i32 2
  %t343 = load i32, ptr %l6, !tbaa !23
  %t346 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t342, i32 %t343)
  store i32 %t346, ptr %l178
  br label %bb92
bb91:
  %t347 = load i32, ptr %l6, !tbaa !23
  store i32 %t347, ptr %l173, !tbaa !23
  br label %bb93
bb92:
  %t349 = load i32, ptr %l178, !tbaa !23
  store i32 %t349, ptr %l173, !tbaa !23
  br label %bb93
bb93:
  %t350 = load i32, ptr %l173, !tbaa !23
  store i32 %t350, ptr %l9, !tbaa !23
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load i32, ptr %l6, !tbaa !23
  %t355 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t351, i32 %t352)
  store i1 %t355, ptr %l182
  br label %bb94
bb94:
  %t356 = load i1, ptr %l182, !tbaa !21
  br i1 %t356, label %bb95, label %bb96
bb95:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb99
bb96:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/check:Checker", ptr %t357, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = getelementptr %"compiler/generic:Program", ptr %t360, i32 0, i32 2
  store ptr %t362, ptr %l186, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t368 = getelementptr %"compiler/generic:Program", ptr %t366, i32 0, i32 2
  %t369 = load i32, ptr %l9, !tbaa !23
  %t372 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t368, i32 %t369)
  store i32 %t372, ptr %l191
  br label %bb97
bb97:
  %t373 = load ptr, ptr %l186, !tbaa !29
  %t374 = load i32, ptr %l191, !tbaa !23
  %t375 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t373, i32 %t374)
  store i32 %t375, ptr %l192
  br label %bb98
bb98:
  %t376 = load i32, ptr %l192, !range !{i32 0, i32 33}
  %t378 = trunc i64 19 to i32
  %t379 = icmp eq i32 %t376, %t378
  store i1 %t379, ptr %l183, !tbaa !21
  br label %bb99
bb99:
  %t381 = load i1, ptr %l183, !tbaa !21
  br i1 %t381, label %bb100, label %bb101
bb100:
  %t382 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t382, ptr %rv
  br label %ret
bb101:
  br label %bb102
bb102:
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l196, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l1, !tbaa !29
  %t389 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t385, ptr %t386)
  store %"compiler/source:Span" %t389, ptr %l199
  br label %bb103
bb103:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i32, ptr %l5, !tbaa !23
  %t394 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t390, i32 %t391)
  store { i64, ptr } %t394, ptr %l202
  br label %bb104
bb104:
  %t395 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  %t397 = extractvalue { i64, ptr } %t395, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  %t403 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgType(ptr %s0, ptr %s0, { i64, ptr } %t401)
  store %"compiler/msgs:Msg" %t403, ptr %l204
  br label %bb105
bb105:
  %t404 = load ptr, ptr %l196, !tbaa !29
  %t405 = load %"compiler/source:Span", ptr %l199
  %t406 = load %"compiler/msgs:Msg", ptr %l204
  %t407 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t404, %"compiler/source:Span" %t405, %"compiler/msgs:Msg" %t406)
  store i64 %t407, ptr %l205
  br label %bb106
bb106:
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l206, !tbaa !29
  %t409 = load ptr, ptr %l1, !tbaa !29
  %t411 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t409)
  store %"compiler/source:Span" %t411, ptr %l208
  br label %bb107
bb107:
  %t412 = load ptr, ptr %l206, !tbaa !29
  %t413 = load %"compiler/source:Span", ptr %l208
  %t414 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t412, %"compiler/source:Span" %t413)
  store ptr %t414, ptr %l209
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s0)
  %t415 = load ptr, ptr %l209, !tbaa !29
  store ptr %t415, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaMemoryJump(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l32 = alloca i1
  %l39 = alloca i32
  %l43 = alloca i1
  %l50 = alloca i1
  %l55 = alloca i1
  %l61 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l18
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = load i32, ptr %l18, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l19
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 %t34
  %t39 = load i32, ptr %t38, !tbaa !33
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t48 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t44, i32 %t39)
  store i1 %t48, ptr %l32
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = add i64 %t49, 1
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb3
bb9:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l39
  br label %bb10
bb10:
  %t63 = load i32, ptr %l39, !tbaa !23
  store i32 %t63, ptr %l6, !tbaa !23
  %t64 = load i32, ptr %l6, !tbaa !23
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t68 = icmp ne i32 %t64, %t65
  br i1 %t68, label %bb11, label %bb12
bb11:
  %t70 = load i32, ptr %l6, !tbaa !23
  %t71 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t74 = icmp ne i32 %t70, %t71
  store i1 %t74, ptr %l43, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb13
bb13:
  %t76 = load i1, ptr %l43, !tbaa !21
  br i1 %t76, label %bb14, label %bb15
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i32, ptr %l6, !tbaa !23
  %t84 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t80, i32 %t81)
  store i1 %t84, ptr %l50
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l6, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l55
  br label %bb17
bb17:
  %t95 = load i1, ptr %l55, !tbaa !21
  br i1 %t95, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l1, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s6, ptr %t102, i32 %t103)
  store { i64, ptr } %t106, ptr %l61
  br label %bb22
bb22:
  %t107 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  %t109 = extractvalue { i64, ptr } %t107, 1
  %t110 = mul i64 %t108, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t111, ptr %t109, i64 %t110, i1 false)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb24, label %bb25
bb24:
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t127, ptr %l69, !tbaa !27
  %t128 = load i64, ptr %l8, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i8, ptr %t131, i64 %t128
  %t133 = load i8, ptr %t132, !tbaa !32
  %t137 = icmp eq i8 %t133, 109
  br i1 %t137, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t140 = load i64, ptr %l8, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l8, !tbaa !24
  br label %bb23
bb31:
  call void @__olang_scope_close(ptr %s6)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l17 = alloca %"compiler/names:Ref"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l11, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l13
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 2
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load ptr, ptr %l11, !tbaa !29
  %t35 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t32, i64 %t29, i32 %t31)
  store %"compiler/names:Ref" %t35, ptr %l17
  br label %bb7
bb7:
  %t36 = getelementptr %"compiler/names:Ref", ptr %l17, i32 0, i32 0
  %t37 = load i32, ptr %t36, !range !{i32 0, i32 9}
  %t39 = trunc i64 8 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %rv
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_a23f531a57510fcc_ca69a351a39efde8)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca i32
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca i32
  %l53 = alloca ptr
  %l57 = alloca ptr
  %l59 = alloca %"compiler/typed:Elem"
  %l63 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca ptr
  %l70 = alloca ptr
  %l81 = alloca ptr
  %l87 = alloca ptr
  %l90 = alloca i64
  %l98 = alloca ptr
  %l102 = alloca i32
  %l106 = alloca { i64, ptr }
  %l107 = alloca %"compiler/typed:Block"
  %l109 = alloca ptr
  %l115 = alloca %"compiler/source:Span"
  %l118 = alloca %"compiler/typed:If"
  %t79 = alloca { i64, [4 x i64] }, align 8
  %t104 = alloca { i64, [4 x i64] }, align 8
  %t129 = alloca { i64, [3 x i64] }, align 8
  %t153 = alloca { i64, [3 x i64] }, align 8
  %t192 = alloca { i64, [3 x i64] }, align 8
  %t248 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:ForIn", ptr %t5, i32 0, i32 4
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:ForIn", ptr %t15, i32 0, i32 4
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t14, { i64, ptr } %t18)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  br label %ret
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Compr", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t24)
  store %"compiler/source:Span" %t26, ptr %l24
  br label %bb8
bb8:
  %t27 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t27, ptr %l4
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 111
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 112
  %t36 = load i64, ptr %t35, !tbaa !24
  store i64 %t36, ptr %l6, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l29, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Compr", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load i32, ptr %l3, !tbaa !23
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %v0, ptr %t39, ptr %t43, i32 %t44)
  store ptr %t48, ptr %l34
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l29, !tbaa !29
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartCopy(ptr %v0, ptr %v0, ptr %v0, ptr %t49, ptr %t50)
  store ptr %t51, ptr %l35
  br label %bb10
bb10:
  %t52 = load ptr, ptr %l35, !tbaa !29
  store ptr %t52, ptr %l7, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Compr", ptr %t53, i32 0, i32 5
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb11, label %bb12
bb11:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp sge i64 %t60, 0
  store i1 %t62, ptr %l39, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t64 = load i1, ptr %l39, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t65, i64 %t66)
  store i32 %t69, ptr %l44
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t70 = load i32, ptr %l44, !tbaa !23
  %t71 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t71, ptr %l45
  %t72 = load i32, ptr %l3, !tbaa !23
  store i32 %t72, ptr %l46, !tbaa !23
  %t73 = load %"compiler/source:Span", ptr %l4
  %t75 = load i64, ptr %l5, !tbaa !24
  %t77 = trunc i64 %t75 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 0
  store i64 0, ptr %t80
  %t82 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t73, 0
  %t84 = insertvalue { %"compiler/source:Span", i32, i32 } %t82, i32 %t70, 1
  %t86 = insertvalue { %"compiler/source:Span", i32, i32 } %t84, i32 %t77, 2
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t86, ptr %t87
  %t88 = load { i64, [4 x i64] }, ptr %t79
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t88, ptr %t90
  store ptr %t90, ptr %l53, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l4
  %t93 = load i64, ptr %l6, !tbaa !24
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t91, %"compiler/source:Span" %t92, i64 %t93)
  store ptr %t97, ptr %l57
  br label %bb17
bb17:
  %t98 = load ptr, ptr %l53, !tbaa !29
  %t99 = load ptr, ptr %l57, !tbaa !29
  %t101 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t98, ptr %t99, i32 0)
  store %"compiler/typed:Elem" %t101, ptr %l59
  br label %bb18
bb18:
  %t102 = load %"compiler/typed:Elem", ptr %l59
  %t103 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t102, ptr %t103
  store { i64, [4 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 0
  store i64 4, ptr %t105
  %t106 = load %"compiler/source:Span", ptr %l45
  %t107 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t106, 0
  %t108 = load i32, ptr %l46, !tbaa !23
  %t109 = insertvalue { %"compiler/source:Span", i32, ptr } %t107, i32 %t108, 1
  %t111 = insertvalue { %"compiler/source:Span", i32, ptr } %t109, ptr %t103, 2
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t111, ptr %t112
  %t113 = load { i64, [4 x i64] }, ptr %t104
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t113, ptr %t115
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t118, ptr %l64
  store ptr %t115, ptr %l65, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l7, !tbaa !29
  %t122 = load i32, ptr %l3, !tbaa !23
  %t123 = load %"compiler/source:Span", ptr %l4
  %t128 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t120, ptr %t121, i32 %t122, %"compiler/source:Span" %t123)
  store ptr %t128, ptr %l70
  br label %bb19
bb19:
  store { i64, [3 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 0
  store i64 1, ptr %t130
  %t131 = load %"compiler/source:Span", ptr %l64
  %t132 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t131, 0
  %t133 = load ptr, ptr %l65, !tbaa !29
  %t134 = insertvalue { %"compiler/source:Span", ptr, ptr } %t132, ptr %t133, 1
  %t135 = load ptr, ptr %l70, !tbaa !29
  %t136 = insertvalue { %"compiler/source:Span", ptr, ptr } %t134, ptr %t135, 2
  %t137 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t136, ptr %t137
  %t138 = load { i64, [3 x i64] }, ptr %t129
  %t140 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t138, ptr %t140
  %t141 = load ptr, ptr %l63, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t141, ptr %t140)
  br label %bb20
bb20:
  br label %ret
bb21:
  %t143 = load ptr, ptr %l2, !tbaa !29
  %t145 = getelementptr %"compiler/ast:Compr", ptr %t143, i32 0, i32 5
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = icmp eq ptr %t146, null
  br i1 %t148, label %bb22, label %bb23
bb22:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l4
  %t152 = load ptr, ptr %l7, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 0
  store i64 15, ptr %t154
  %t156 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t151, 0
  %t158 = insertvalue { %"compiler/source:Span", ptr } %t156, ptr %t152, 1
  %t159 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t158, ptr %t159
  %t160 = load { i64, [3 x i64] }, ptr %t153
  %t162 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t160, ptr %t162
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t150, ptr %t162)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %ret
bb25:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l81, !tbaa !29
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t168 = getelementptr %"compiler/ast:Compr", ptr %t166, i32 0, i32 5
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = icmp eq ptr %t169, null
  br i1 %t171, label %bb26, label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_61f61c7eea085c49_e2109341212ff245)
  unreachable
bb27:
  br label %bb28
bb28:
  %t173 = load ptr, ptr %l2, !tbaa !29
  %t175 = getelementptr %"compiler/ast:Compr", ptr %t173, i32 0, i32 5
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t177 = load ptr, ptr %l81, !tbaa !29
  %t179 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v2, ptr %v0, ptr %t177, ptr %t176)
  store ptr %t179, ptr %l87
  br label %bb29
bb29:
  %t180 = load ptr, ptr %l87, !tbaa !29
  store ptr %t180, ptr %l10, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/check:Checker", ptr %t181, i32 0, i32 37
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t183)
  store i64 %t185, ptr %l90
  br label %bb30
bb30:
  %t186 = load i64, ptr %l90, !tbaa !24
  store i64 %t186, ptr %l11, !tbaa !24
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 37
  %t190 = load %"compiler/source:Span", ptr %l4
  %t191 = load ptr, ptr %l7, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 0
  store i64 15, ptr %t193
  %t195 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t190, 0
  %t197 = insertvalue { %"compiler/source:Span", ptr } %t195, ptr %t191, 1
  %t198 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t197, ptr %t198
  %t199 = load { i64, [3 x i64] }, ptr %t192
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t199, ptr %t201
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t189, ptr %t201)
  br label %bb31
bb31:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t204)
  store ptr %t206, ptr %l98
  br label %bb32
bb32:
  %t207 = load ptr, ptr %l98, !tbaa !29
  %t209 = getelementptr %"compiler/check:frame", ptr %t207, i32 0, i32 7
  %t210 = load i64, ptr %t209, !tbaa !24
  %t212 = trunc i64 %t210 to i32
  store i32 %t212, ptr %l102, !tbaa !23
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 37
  %t217 = load i64, ptr %l11, !tbaa !24
  %t220 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t216, i64 %t217)
  store { i64, ptr } %t220, ptr %l106
  br label %bb33
bb33:
  %t221 = load i32, ptr %l102, !tbaa !23
  %t222 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t223 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t221, { i64, ptr } %t222)
  store %"compiler/typed:Block" %t223, ptr %l107
  br label %bb34
bb34:
  %t224 = load %"compiler/typed:Block", ptr %l107
  %t225 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t224, ptr %t225
  store ptr %t225, ptr %l12, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l109, !tbaa !29
  %t228 = load ptr, ptr %l2, !tbaa !29
  %t230 = getelementptr %"compiler/ast:Compr", ptr %t228, i32 0, i32 5
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = icmp eq ptr %t231, null
  br i1 %t233, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_5688429828d7ebe2_8ea9fe01fea3ad9e)
  unreachable
bb36:
  br label %bb37
bb37:
  %t235 = load ptr, ptr %l2, !tbaa !29
  %t237 = getelementptr %"compiler/ast:Compr", ptr %t235, i32 0, i32 5
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t238)
  store %"compiler/source:Span" %t240, ptr %l115
  br label %bb38
bb38:
  %t241 = load ptr, ptr %l10, !tbaa !29
  %t242 = load ptr, ptr %l12, !tbaa !29
  %t245 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t241, ptr %t242, ptr null)
  store %"compiler/typed:If" %t245, ptr %l118
  br label %bb39
bb39:
  %t246 = load %"compiler/typed:If", ptr %l118
  %t247 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t246, ptr %t247
  store { i64, [3 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [3 x i64] }, ptr %t248, i32 0, i32 0
  store i64 3, ptr %t249
  %t250 = load %"compiler/source:Span", ptr %l115
  %t251 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t250, 0
  %t253 = insertvalue { %"compiler/source:Span", ptr } %t251, ptr %t247, 1
  %t254 = getelementptr { i64, [3 x i64] }, ptr %t248, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t253, ptr %t254
  %t255 = load { i64, [3 x i64] }, ptr %t248
  %t257 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t255, ptr %t257
  %t258 = load ptr, ptr %l109, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t258, ptr %t257)
  br label %bb40
bb40:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l28 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l12, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_922ae0a799ba69ce_f9cc72ab99b0ec2)
  unreachable
bb16:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb17, label %bb18
bb17:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 18}
  %t39 = icmp eq i64 %t37, 12
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb18
bb18:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb19, label %bb20
bb19:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb29
bb21:
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Seq", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb22, label %bb23
bb22:
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Seq", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  br i1 %t61, label %bb24, label %bb25
bb23:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb28
bb24:
  call void @__olang_check_failed(ptr @olang_loc_46a0e749826cef18_3e2809181fcd5dac)
  unreachable
bb25:
  br label %bb26
bb26:
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Seq", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %t66)
  store i1 %t68, ptr %l34
  br label %bb27
bb27:
  %t69 = load i1, ptr %l34, !tbaa !21
  store i1 %t69, ptr %l28, !tbaa !21
  br label %bb28
bb28:
  %t70 = load i1, ptr %l28, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i1 false, ptr %rv
  br label %ret
bb33:
  call void @__olang_check_failed(ptr @olang_loc_2f12767f94a228d4_8b6b4888798b3f68)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca double
  %l2 = alloca double
  %l5 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load double, ptr %l1, !tbaa !26
  %t3 = fcmp ogt double %t1, 0x7fefffffffffffff
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load double, ptr %l1, !tbaa !26
  %t7 = fcmp olt double %t5, 0xffefffffffffffff
  store i1 %t7, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load double, ptr %l1, !tbaa !26
  store double %t11, ptr %l2, !tbaa !26
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, 13
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t17 = load double, ptr %l1, !tbaa !26
  %t19 = fptrunc double %t17 to float
  %t21 = fpext float %t19 to double
  store double %t21, ptr %l2, !tbaa !26
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t23 = load i32, ptr %l0, !tbaa !23
  %t25 = icmp eq i32 %t23, 11
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = load double, ptr %l1, !tbaa !26
  %t29 = fptrunc double %t27 to half
  %t31 = fpext half %t29 to double
  store double %t31, ptr %l2, !tbaa !26
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t33 = load i32, ptr %l0, !tbaa !23
  %t35 = icmp eq i32 %t33, 12
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load double, ptr %l1, !tbaa !26
  %t39 = fptrunc double %t37 to bfloat
  %t41 = bitcast bfloat %t39 to i16
  %t42 = zext i16 %t41 to i32
  %t43 = shl i32 %t42, 16
  %t44 = bitcast i32 %t43 to float
  %t45 = fpext float %t44 to double
  store double %t45, ptr %l2, !tbaa !26
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t47 = load double, ptr %l2, !tbaa !26
  %t49 = fcmp ogt double %t47, 0x7fefffffffffffff
  br i1 %t49, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb18
bb17:
  %t51 = load double, ptr %l2, !tbaa !26
  %t53 = fcmp olt double %t51, 0xffefffffffffffff
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t55 = load i1, ptr %l27, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ehasName(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t13, i64 %t14)
  store i32 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i32, ptr %l13, !tbaa !23
  %t23 = icmp eq i32 %t18, %a1
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisFuncTypeRef(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eIsFunc(ptr %v0, ptr %a0)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  store i1 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2elastIsValue(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t6 = sub i64 %t4, 1
  %t8 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr ptr, ptr %t9, i64 %t6
  %t11 = load ptr, ptr %t10, !tbaa !39
  store ptr %t11, ptr %l1, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i64, ptr %t17, !range !{i64 0, i64 22}
  %t20 = icmp eq i64 %t18, 0
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr }, ptr %t24, i32 0, i32 1
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %t28)
  store i1 %t30, ptr %l16
  br label %bb6
bb6:
  %t31 = load i1, ptr %l16, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l8, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_696a437f6b67e70a_247b6a7ce30931f6)
  unreachable
bb12:
  %t34 = load i1, ptr %l8, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  %t33 = call i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %t29)
  store i1 %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t1)
  store i1 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i1, ptr %l7, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb21
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 %t25
  %t30 = load ptr, ptr %t29, !tbaa !39
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 17}
  %t39 = icmp eq i64 %t37, 5
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f65b5445e0db363a_c2ab951bd73e6226)
  unreachable
bb19:
  br label %bb20
bb20:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb5
bb21:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 52 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb4:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t8 = trunc i64 53 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb8:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t13 = trunc i64 54 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb12:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t18 = trunc i64 56 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb16:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t23 = trunc i64 57 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb20:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t28 = trunc i64 58 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb24:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t33 = trunc i64 81 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb25, label %bb26
bb25:
  br label %bb33
bb26:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t38 = trunc i64 83 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t41 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t43 = trunc i64 82 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  %t46 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t48 = trunc i64 84 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb34:
  %t51 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t53 = trunc i64 85 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb38:
  %t56 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t58 = trunc i64 86 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb42:
  %t61 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t63 = trunc i64 87 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb46:
  %t66 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t68 = trunc i64 90 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb50:
  %t71 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t73 = trunc i64 91 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb54:
  %t76 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t78 = trunc i64 55 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_445c35e7b454dfb2_9156676d88e8071e)
  unreachable
bb63:
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t81, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"compiler/source:Span"
  %l77 = alloca i64
  %l80 = alloca i64
  %l99 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t97 = alloca { i64, [4 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l3, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l6, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l8, !tbaa !24
  store i64 %a2, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l8, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb11, label %bb12
bb4:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l32, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v1, ptr %t41, ptr %t39)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l5, !tbaa !24
  br label %bb4
bb10:
  br label %bb25
bb11:
  %t49 = load i64, ptr %l10, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb16
bb13:
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l10, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l10, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l46, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb15
bb15:
  %t69 = load i64, ptr %l46, !tbaa !24
  store i64 %t69, ptr %l43, !tbaa !24
  br label %bb16
bb16:
  %t70 = load i64, ptr %l43, !tbaa !24
  store i64 %t70, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb17
bb17:
  %t71 = load i64, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l12, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l13, !tbaa !24
  %t89 = load ptr, ptr %l3, !tbaa !29
  store ptr %t89, ptr %l64, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t90, ptr %l65, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr ptr, ptr %t92, i64 0
  %t94 = load ptr, ptr %t93, !tbaa !39
  %t96 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %t94)
  store %"compiler/source:Span" %t96, ptr %l67
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t99 = load %"compiler/source:Span", ptr %l67
  %t100 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t99, 0
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  store { %"compiler/source:Span" } %t100, ptr %t101
  %t102 = load { i64, [4 x i64] }, ptr %t97
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t102, ptr %t104
  %t105 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v2, ptr %t105, ptr %t104)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l12, !tbaa !24
  br label %bb17
bb24:
  br label %bb25
bb25:
  store i64 1, ptr %l14, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t115 = load i64, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb26, label %bb27
bb26:
  %t121 = load i64, ptr %l16, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb31
bb28:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l16, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l16, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l80, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb30
bb30:
  %t141 = load i64, ptr %l80, !tbaa !24
  store i64 %t141, ptr %l77, !tbaa !24
  br label %bb31
bb31:
  %t142 = load i64, ptr %l77, !tbaa !24
  store i64 %t142, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb32
bb32:
  %t143 = load i64, ptr %l18, !tbaa !24
  %t144 = load i64, ptr %l17, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb33, label %bb34
bb33:
  br label %bb38
bb34:
  br label %bb35
bb35:
  %t151 = load i64, ptr %l14, !tbaa !24
  %t152 = load i64, ptr %l18, !tbaa !24
  %t153 = load i64, ptr %l16, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  %t161 = load ptr, ptr %l3, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t162, ptr %l99, !tbaa !27
  %t165 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t159
  %t168 = load ptr, ptr %t167, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v0, ptr %t161, ptr %t168)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t171 = load i64, ptr %l18, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l18, !tbaa !24
  br label %bb32
bb38:
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t177 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eToArr_H3d785ef7fade1f29078b6e80f1d617ba(ptr %v2, ptr %v2, ptr %t175)
  store { i64, ptr } %t177, ptr %l105
  br label %bb39
bb39:
  %t178 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t178, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l2, !tbaa !23
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 0, ptr %l2, !tbaa !23
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_524a47ae64dd06b8_5def175755840fac)
  unreachable
bb11:
  %t18 = load i32, ptr %l2, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l32 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 30}
  %t17 = icmp eq i64 %t15, 21
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 30}
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb35
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 30}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr }, ptr %t39, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l1, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = call i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %t43)
  store i1 %t45, ptr %l23
  br label %bb20
bb20:
  %t46 = load i1, ptr %l23, !tbaa !21
  store i1 %t46, ptr %l3, !tbaa !21
  br label %bb35
bb21:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t48 = load ptr, ptr %l24, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb22, label %bb23
bb22:
  %t51 = load ptr, ptr %l24, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 30}
  %t54 = icmp eq i64 %t52, 3
  store i1 %t54, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t55 = load i1, ptr %l25, !tbaa !21
  br i1 %t55, label %bb24, label %bb25
bb24:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 1
  %t60 = load i32, ptr %t59, !range !{i32 0, i32 98}
  store i32 %t60, ptr %l2
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t62 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t64 = trunc i64 76 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb29
bb28:
  %t67 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t69 = trunc i64 77 to i32
  %t70 = icmp eq i32 %t67, %t69
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb29
bb29:
  %t72 = load i1, ptr %l32, !tbaa !21
  store i1 %t72, ptr %l3, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d195b38137e2d30_7d67c1d5e7f3802c)
  unreachable
bb35:
  %t73 = load i1, ptr %l3, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l70 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i1
  %l201 = alloca ptr
  %l202 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca i1
  %l231 = alloca ptr
  %l232 = alloca i1
  %l249 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l260 = alloca i1
  %l271 = alloca ptr
  %l272 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t6 = load ptr, ptr %l35, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l35, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l36, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l36, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t22)
  br label %bb9
bb9:
  br label %bb172
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t26 = load ptr, ptr %l44, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l44, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 22}
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l45, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l45, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"compiler/ast:VarDecl", ptr %t40, i32 0, i32 3
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t43, ptr %t44)
  br label %bb16
bb16:
  br label %bb172
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t48 = load ptr, ptr %l53, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb18, label %bb19
bb18:
  %t51 = load ptr, ptr %l53, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 22}
  %t54 = icmp eq i64 %t52, 2
  store i1 %t54, ptr %l54, !tbaa !21
  br label %bb19
bb19:
  %t55 = load i1, ptr %l54, !tbaa !21
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb34
bb22:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Multi", ptr %t62, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Multi", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  store i64 %t76, ptr %l7, !tbaa !24
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t86, ptr %l70, !tbaa !27
  %t87 = load i64, ptr %l6, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr ptr, ptr %t90, i64 %t87
  %t92 = load ptr, ptr %t91, !tbaa !39
  %t95 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t92, ptr %t95)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t98 = load i64, ptr %l6, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l6, !tbaa !24
  br label %bb25
bb31:
  br label %bb32
bb32:
  %t102 = load ptr, ptr %l4, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Multi", ptr %t102, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  %t106 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t105, ptr %t106)
  br label %bb33
bb33:
  br label %bb172
bb34:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t110 = load ptr, ptr %l80, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb35, label %bb36
bb35:
  %t113 = load ptr, ptr %l80, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 22}
  %t116 = icmp eq i64 %t114, 3
  store i1 %t116, ptr %l81, !tbaa !21
  br label %bb36
bb36:
  %t117 = load i1, ptr %l81, !tbaa !21
  br i1 %t117, label %bb37, label %bb38
bb37:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l9, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t126, i32 0, i32 3
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l10, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t130 = load ptr, ptr %l9, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  br label %bb40
bb40:
  %t134 = load ptr, ptr %l10, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t134, ptr %t136)
  br label %bb41
bb41:
  br label %bb172
bb42:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t140 = load ptr, ptr %l93, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb43, label %bb44
bb43:
  %t143 = load ptr, ptr %l93, !tbaa !29
  %t144 = load i64, ptr %t143, !range !{i64 0, i64 22}
  %t146 = icmp eq i64 %t144, 4
  store i1 %t146, ptr %l94, !tbaa !21
  br label %bb44
bb44:
  %t147 = load i1, ptr %l94, !tbaa !21
  br i1 %t147, label %bb45, label %bb46
bb45:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t150, i32 0, i32 1
  %t152 = load ptr, ptr %t151
  store ptr %t152, ptr %l11, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t156, i32 0, i32 2
  %t158 = load { i64, ptr }, ptr %t157
  store { i64, ptr } %t158, ptr %l12, !tbaa !27
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t160 = load ptr, ptr %l11, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t160, ptr %t162)
  br label %bb48
bb48:
  %t165 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t166 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t165, ptr %t166)
  br label %bb49
bb49:
  br label %bb172
bb50:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t170 = load ptr, ptr %l106, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb51, label %bb52
bb51:
  %t173 = load ptr, ptr %l106, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 22}
  %t176 = icmp eq i64 %t174, 5
  store i1 %t176, ptr %l107, !tbaa !21
  br label %bb52
bb52:
  %t177 = load i1, ptr %l107, !tbaa !21
  br i1 %t177, label %bb53, label %bb54
bb53:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", ptr }, ptr %t180, i32 0, i32 1
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l13, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t184 = load ptr, ptr %l13, !tbaa !29
  %t185 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIf(ptr %v0, ptr %v1, ptr %t184, ptr %t185)
  br label %bb56
bb56:
  br label %bb172
bb57:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t189 = load ptr, ptr %l114, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb58, label %bb59
bb58:
  %t192 = load ptr, ptr %l114, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 22}
  %t195 = icmp eq i64 %t193, 6
  store i1 %t195, ptr %l115, !tbaa !21
  br label %bb59
bb59:
  %t196 = load i1, ptr %l115, !tbaa !21
  br i1 %t196, label %bb60, label %bb61
bb60:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t199, i32 0, i32 1
  %t201 = load { i64, ptr }, ptr %t200
  store { i64, ptr } %t201, ptr %l14, !tbaa !27
  br label %bb66
bb61:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t204 = load ptr, ptr %l120, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb62, label %bb63
bb62:
  %t207 = load ptr, ptr %l120, !tbaa !29
  %t208 = load i64, ptr %t207, !range !{i64 0, i64 22}
  %t210 = icmp eq i64 %t208, 20
  store i1 %t210, ptr %l121, !tbaa !21
  br label %bb63
bb63:
  %t211 = load i1, ptr %l121, !tbaa !21
  br i1 %t211, label %bb64, label %bb65
bb64:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t214, i32 0, i32 1
  %t216 = load { i64, ptr }, ptr %t215
  store { i64, ptr } %t216, ptr %l14, !tbaa !27
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t218 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t219 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t218, ptr %t219)
  br label %bb67
bb67:
  br label %bb172
bb68:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t223 = load ptr, ptr %l128, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  br i1 %t224, label %bb69, label %bb70
bb69:
  %t226 = load ptr, ptr %l128, !tbaa !29
  %t227 = load i64, ptr %t226, !range !{i64 0, i64 22}
  %t229 = icmp eq i64 %t227, 7
  store i1 %t229, ptr %l129, !tbaa !21
  br label %bb70
bb70:
  %t230 = load i1, ptr %l129, !tbaa !21
  br i1 %t230, label %bb71, label %bb72
bb71:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t233, i32 0, i32 1
  %t235 = load ptr, ptr %t234
  store ptr %t235, ptr %l15, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t239, i32 0, i32 2
  %t241 = load { i64, ptr }, ptr %t240
  store { i64, ptr } %t241, ptr %l16, !tbaa !27
  br label %bb77
bb72:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t244 = load ptr, ptr %l136, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb73, label %bb74
bb73:
  %t247 = load ptr, ptr %l136, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 22}
  %t250 = icmp eq i64 %t248, 10
  store i1 %t250, ptr %l137, !tbaa !21
  br label %bb74
bb74:
  %t251 = load i1, ptr %l137, !tbaa !21
  br i1 %t251, label %bb75, label %bb76
bb75:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t254, i32 0, i32 1
  %t256 = load { i64, ptr }, ptr %t255
  store { i64, ptr } %t256, ptr %l16, !tbaa !27
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t260, i32 0, i32 2
  %t262 = load ptr, ptr %t261
  store ptr %t262, ptr %l15, !tbaa !29
  br label %bb77
bb76:
  br label %bb80
bb77:
  %t264 = load ptr, ptr %l15, !tbaa !29
  %t266 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t264, ptr %t266)
  br label %bb78
bb78:
  %t269 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t270 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t269, ptr %t270)
  br label %bb79
bb79:
  br label %bb172
bb80:
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t274 = load ptr, ptr %l149, !tbaa !29
  %t275 = icmp ne ptr %t274, null
  br i1 %t275, label %bb81, label %bb82
bb81:
  %t277 = load ptr, ptr %l149, !tbaa !29
  %t278 = load i64, ptr %t277, !range !{i64 0, i64 22}
  %t280 = icmp eq i64 %t278, 8
  store i1 %t280, ptr %l150, !tbaa !21
  br label %bb82
bb82:
  %t281 = load i1, ptr %l150, !tbaa !21
  br i1 %t281, label %bb83, label %bb84
bb83:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr { i64, [4 x i64] }, ptr %t282, i32 0, i32 1
  %t285 = getelementptr { %"compiler/source:Span", ptr }, ptr %t284, i32 0, i32 1
  %t286 = load ptr, ptr %t285
  store ptr %t286, ptr %l17, !tbaa !29
  br label %bb85
bb84:
  br label %bb90
bb85:
  %t288 = load ptr, ptr %l17, !tbaa !29
  %t290 = getelementptr %"compiler/ast:For3", ptr %t288, i32 0, i32 0
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t293 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t291, ptr %t293)
  br label %bb86
bb86:
  %t296 = load ptr, ptr %l17, !tbaa !29
  %t298 = getelementptr %"compiler/ast:For3", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t300 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t299, ptr %t300)
  br label %bb87
bb87:
  %t303 = load ptr, ptr %l17, !tbaa !29
  %t305 = getelementptr %"compiler/ast:For3", ptr %t303, i32 0, i32 2
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t306, ptr %t308)
  br label %bb88
bb88:
  %t311 = load ptr, ptr %l17, !tbaa !29
  %t313 = getelementptr %"compiler/ast:For3", ptr %t311, i32 0, i32 3
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  %t315 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t314, ptr %t315)
  br label %bb89
bb89:
  br label %bb172
bb90:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t319 = load ptr, ptr %l169, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb91, label %bb92
bb91:
  %t322 = load ptr, ptr %l169, !tbaa !29
  %t323 = load i64, ptr %t322, !range !{i64 0, i64 22}
  %t325 = icmp eq i64 %t323, 9
  store i1 %t325, ptr %l170, !tbaa !21
  br label %bb92
bb92:
  %t326 = load i1, ptr %l170, !tbaa !21
  br i1 %t326, label %bb93, label %bb94
bb93:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr { i64, [4 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", ptr }, ptr %t329, i32 0, i32 1
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l18, !tbaa !29
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t333 = load ptr, ptr %l18, !tbaa !29
  %t335 = getelementptr %"compiler/ast:ForIn", ptr %t333, i32 0, i32 2
  %t336 = load ptr, ptr %t335, !tbaa !29
  %t338 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t336, ptr %t338)
  br label %bb96
bb96:
  %t341 = load ptr, ptr %l18, !tbaa !29
  %t343 = getelementptr %"compiler/ast:ForIn", ptr %t341, i32 0, i32 4
  %t344 = load { i64, ptr }, ptr %t343, !tbaa !27
  %t345 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t344, ptr %t345)
  br label %bb97
bb97:
  %t348 = load ptr, ptr %l18, !tbaa !29
  %t350 = getelementptr %"compiler/ast:ForIn", ptr %t348, i32 0, i32 5
  %t351 = load { i64, ptr }, ptr %t350, !tbaa !27
  %t352 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t351, ptr %t352)
  br label %bb98
bb98:
  br label %bb172
bb99:
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t356 = load ptr, ptr %l185, !tbaa !29
  %t357 = icmp ne ptr %t356, null
  br i1 %t357, label %bb100, label %bb101
bb100:
  %t359 = load ptr, ptr %l185, !tbaa !29
  %t360 = load i64, ptr %t359, !range !{i64 0, i64 22}
  %t362 = icmp eq i64 %t360, 11
  store i1 %t362, ptr %l186, !tbaa !21
  br label %bb101
bb101:
  %t363 = load i1, ptr %l186, !tbaa !21
  br i1 %t363, label %bb102, label %bb103
bb102:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr { i64, [4 x i64] }, ptr %t364, i32 0, i32 1
  %t367 = getelementptr { %"compiler/source:Span", ptr }, ptr %t366, i32 0, i32 1
  %t368 = load ptr, ptr %t367
  store ptr %t368, ptr %l19, !tbaa !29
  br label %bb104
bb103:
  br label %bb106
bb104:
  %t370 = load ptr, ptr %l19, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %t370, ptr %t371)
  br label %bb105
bb105:
  br label %bb172
bb106:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t375 = load ptr, ptr %l193, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb107, label %bb108
bb107:
  %t378 = load ptr, ptr %l193, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 22}
  %t381 = icmp eq i64 %t379, 12
  store i1 %t381, ptr %l194, !tbaa !21
  br label %bb108
bb108:
  %t382 = load i1, ptr %l194, !tbaa !21
  br i1 %t382, label %bb109, label %bb110
bb109:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr { i64, [4 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t385, i32 0, i32 1
  %t387 = load { i64, ptr }, ptr %t386
  store { i64, ptr } %t387, ptr %l20, !tbaa !27
  br label %bb111
bb110:
  br label %bb113
bb111:
  %t389 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t390 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t389, ptr %t390)
  br label %bb112
bb112:
  br label %bb172
bb113:
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l201, !tbaa !29
  store i1 false, ptr %l202, !tbaa !21
  %t394 = load ptr, ptr %l201, !tbaa !29
  %t395 = icmp ne ptr %t394, null
  br i1 %t395, label %bb114, label %bb115
bb114:
  %t397 = load ptr, ptr %l201, !tbaa !29
  %t398 = load i64, ptr %t397, !range !{i64 0, i64 22}
  %t400 = icmp eq i64 %t398, 15
  store i1 %t400, ptr %l202, !tbaa !21
  br label %bb115
bb115:
  %t401 = load i1, ptr %l202, !tbaa !21
  br i1 %t401, label %bb116, label %bb117
bb116:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr { i64, [4 x i64] }, ptr %t402, i32 0, i32 1
  %t405 = getelementptr { %"compiler/source:Span", ptr }, ptr %t404, i32 0, i32 1
  %t406 = load ptr, ptr %t405
  store ptr %t406, ptr %l21, !tbaa !29
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t408 = load ptr, ptr %l21, !tbaa !29
  %t410 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t408, ptr %t410)
  br label %bb119
bb119:
  br label %bb172
bb120:
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t414 = load ptr, ptr %l210, !tbaa !29
  %t415 = icmp ne ptr %t414, null
  br i1 %t415, label %bb121, label %bb122
bb121:
  %t417 = load ptr, ptr %l210, !tbaa !29
  %t418 = load i64, ptr %t417, !range !{i64 0, i64 22}
  %t420 = icmp eq i64 %t418, 14
  store i1 %t420, ptr %l211, !tbaa !21
  br label %bb122
bb122:
  %t421 = load i1, ptr %l211, !tbaa !21
  br i1 %t421, label %bb123, label %bb124
bb123:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr { i64, [4 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t424, i32 0, i32 1
  %t426 = load ptr, ptr %t425
  store ptr %t426, ptr %l22, !tbaa !29
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr { i64, [4 x i64] }, ptr %t428, i32 0, i32 1
  %t431 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t430, i32 0, i32 2
  %t432 = load ptr, ptr %t431
  store ptr %t432, ptr %l23, !tbaa !29
  br label %bb125
bb124:
  br label %bb128
bb125:
  %t434 = load ptr, ptr %l22, !tbaa !29
  %t436 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t434, ptr %t436)
  br label %bb126
bb126:
  %t439 = load ptr, ptr %l23, !tbaa !29
  %t440 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t439, ptr %t440)
  br label %bb127
bb127:
  br label %bb172
bb128:
  %t443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t443, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t444 = load ptr, ptr %l223, !tbaa !29
  %t445 = icmp ne ptr %t444, null
  br i1 %t445, label %bb129, label %bb130
bb129:
  %t447 = load ptr, ptr %l223, !tbaa !29
  %t448 = load i64, ptr %t447, !range !{i64 0, i64 22}
  %t450 = icmp eq i64 %t448, 13
  store i1 %t450, ptr %l224, !tbaa !21
  br label %bb130
bb130:
  %t451 = load i1, ptr %l224, !tbaa !21
  br i1 %t451, label %bb131, label %bb132
bb131:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t454 = getelementptr { i64, [4 x i64] }, ptr %t452, i32 0, i32 1
  %t455 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t454, i32 0, i32 2
  %t456 = load ptr, ptr %t455
  store ptr %t456, ptr %l24, !tbaa !29
  br label %bb133
bb132:
  br label %bb135
bb133:
  %t458 = load ptr, ptr %l24, !tbaa !29
  %t459 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t458, ptr %t459)
  br label %bb134
bb134:
  br label %bb172
bb135:
  %t462 = load ptr, ptr %l0, !tbaa !29
  store ptr %t462, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t463 = load ptr, ptr %l231, !tbaa !29
  %t464 = icmp ne ptr %t463, null
  br i1 %t464, label %bb136, label %bb137
bb136:
  %t466 = load ptr, ptr %l231, !tbaa !29
  %t467 = load i64, ptr %t466, !range !{i64 0, i64 22}
  %t469 = icmp eq i64 %t467, 17
  store i1 %t469, ptr %l232, !tbaa !21
  br label %bb137
bb137:
  %t470 = load i1, ptr %l232, !tbaa !21
  br i1 %t470, label %bb138, label %bb139
bb138:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr { i64, [4 x i64] }, ptr %t471, i32 0, i32 1
  %t474 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t473, i32 0, i32 1
  %t475 = load { i64, ptr }, ptr %t474
  store { i64, ptr } %t475, ptr %l25, !tbaa !27
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr { i64, [4 x i64] }, ptr %t477, i32 0, i32 1
  %t480 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t479, i32 0, i32 2
  %t481 = load ptr, ptr %t480
  store ptr %t481, ptr %l26, !tbaa !29
  br label %bb140
bb139:
  br label %bb152
bb140:
  %t483 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t483, 0
  %t487 = icmp sgt i64 %t485, 0
  br i1 %t487, label %bb141, label %bb142
bb141:
  %t489 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t489, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 0
  store i64 %t493, ptr %l29, !tbaa !24
  br label %bb143
bb142:
  br label %bb150
bb143:
  %t495 = load i64, ptr %l28, !tbaa !24
  %t496 = load i64, ptr %l29, !tbaa !24
  %t499 = icmp slt i64 %t495, %t496
  %t501 = xor i1 %t499, true
  br i1 %t501, label %bb144, label %bb145
bb144:
  br label %bb149
bb145:
  br label %bb146
bb146:
  %t503 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t503, ptr %l249, !tbaa !27
  %t504 = load i64, ptr %l28, !tbaa !24
  %t506 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr ptr, ptr %t507, i64 %t504
  %t509 = load ptr, ptr %t508, !tbaa !39
  %t512 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t509, ptr %t512)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t515 = load i64, ptr %l28, !tbaa !24
  %t517 = add i64 %t515, 1
  store i64 %t517, ptr %l28, !tbaa !24
  br label %bb143
bb149:
  br label %bb150
bb150:
  %t519 = load ptr, ptr %l26, !tbaa !29
  %t521 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t519, ptr %t521)
  br label %bb151
bb151:
  br label %bb172
bb152:
  %t524 = load ptr, ptr %l0, !tbaa !29
  store ptr %t524, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t525 = load ptr, ptr %l259, !tbaa !29
  %t526 = icmp ne ptr %t525, null
  br i1 %t526, label %bb153, label %bb154
bb153:
  %t528 = load ptr, ptr %l259, !tbaa !29
  %t529 = load i64, ptr %t528, !range !{i64 0, i64 22}
  %t531 = icmp eq i64 %t529, 18
  store i1 %t531, ptr %l260, !tbaa !21
  br label %bb154
bb154:
  %t532 = load i1, ptr %l260, !tbaa !21
  br i1 %t532, label %bb155, label %bb156
bb155:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t535 = getelementptr { i64, [4 x i64] }, ptr %t533, i32 0, i32 1
  %t536 = getelementptr { %"compiler/source:Span", ptr }, ptr %t535, i32 0, i32 1
  %t537 = load ptr, ptr %t536
  store ptr %t537, ptr %l31, !tbaa !29
  br label %bb157
bb156:
  br label %bb160
bb157:
  %t539 = load ptr, ptr %l31, !tbaa !29
  %t541 = getelementptr %"compiler/ast:JoinS", ptr %t539, i32 0, i32 1
  %t542 = load { i64, ptr }, ptr %t541, !tbaa !27
  %t543 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t542, ptr %t543)
  br label %bb158
bb158:
  %t546 = load ptr, ptr %l31, !tbaa !29
  %t548 = getelementptr %"compiler/ast:JoinS", ptr %t546, i32 0, i32 2
  %t549 = load { i64, ptr }, ptr %t548, !tbaa !27
  %t550 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t549, ptr %t550)
  br label %bb159
bb159:
  br label %bb172
bb160:
  %t553 = load ptr, ptr %l0, !tbaa !29
  store ptr %t553, ptr %l271, !tbaa !29
  store i1 false, ptr %l272, !tbaa !21
  %t554 = load ptr, ptr %l271, !tbaa !29
  %t555 = icmp ne ptr %t554, null
  br i1 %t555, label %bb161, label %bb162
bb161:
  %t557 = load ptr, ptr %l271, !tbaa !29
  %t558 = load i64, ptr %t557, !range !{i64 0, i64 22}
  %t560 = icmp eq i64 %t558, 19
  store i1 %t560, ptr %l272, !tbaa !21
  br label %bb162
bb162:
  %t561 = load i1, ptr %l272, !tbaa !21
  br i1 %t561, label %bb163, label %bb164
bb163:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr { i64, [4 x i64] }, ptr %t562, i32 0, i32 1
  %t565 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t564, i32 0, i32 1
  %t566 = load ptr, ptr %t565
  store ptr %t566, ptr %l32, !tbaa !29
  br label %bb165
bb164:
  br label %bb167
bb165:
  %t568 = load ptr, ptr %l32, !tbaa !29
  %t570 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t568, ptr %t570)
  br label %bb166
bb166:
  br label %bb172
bb167:
  br i1 true, label %bb168, label %bb169
bb168:
  br label %bb170
bb169:
  br label %bb171
bb170:
  br label %bb172
bb171:
  call void @__olang_check_failed(ptr @olang_loc_129627029b1e0c70_26637847123ec4fc)
  unreachable
bb172:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:factsCopy" @compiler_2fcheck_3afactsCopy_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %rv = alloca %"compiler/check:factsCopy"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:factsCopy" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, 0
  %t10 = insertvalue %"compiler/check:factsCopy" %t8, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, 1
  %t12 = insertvalue %"compiler/check:factsCopy" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, 2
  store %"compiler/check:factsCopy" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factsCopy", ptr %rv
  ret %"compiler/check:factsCopy" %rr
}

define dso_local %"compiler/check:seqOf" @compiler_2fcheck_3aseqOf_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:seqOf"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:seqOf" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/check:seqOf" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:seqOf" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:seqOf" %t14, i64 %a3, 3
  store %"compiler/check:seqOf" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:seqOf", ptr %rv
  ret %"compiler/check:seqOf" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a compound assignment to what has no operator method (E31)" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"HasAttr" }>, align 8
@.d4 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"std/prelude/reflect" }>, align 8
@.d5 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"attrMissing" }>, align 8
@.d6 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"std/prelude/reflect" }>, align 8
@.d7 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"attrGot" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_ert_req_clear()
define linkonce_odr %"compiler/typed:ContractInfo" @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aContractInfo(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:ContractInfo"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/typed:ContractInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/typed:ContractInfo", ptr %a0
  store %"compiler/typed:ContractInfo" %t2, ptr %l1
  %t3 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 3
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l5
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t12 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %t12
  %t13 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 4
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l7
  br label %bb3
bb3:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t17 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t17
  %t18 = load %"compiler/typed:ContractInfo", ptr %l1
  store %"compiler/typed:ContractInfo" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:ContractInfo", ptr %rv
  ret %"compiler/typed:ContractInfo" %rr
}

@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d10 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d11 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Overflow" }>, align 8
@.d12 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d13 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d14 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Invalid" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d16 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"nothing" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"'unreachable'" }>, align 8
@.d24 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"a 'noreturn' call" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d26 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d27 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Every" }>, align 8
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Narrow" }>, align 8
@.d29 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"vacate" }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"occupy" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d35 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"a method the compiler supplies (E10b, E11c)" }>, align 8
@.d36 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"PadStart" }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"PadEnd" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define internal i1 @olang_lambda_40(ptr %env, %"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l3 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 1
  %t2 = load i1, ptr %t1, !tbaa !21
  %t4 = xor i1 %t2, true
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb6
bb2:
  %t6 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 4
  %t7 = load double, ptr %t6, !tbaa !26
  %t9 = fcmp ole double %t7, 0x7fefffffffffffff
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 4
  %t12 = load double, ptr %t11, !tbaa !26
  %t14 = fcmp oge double %t12, 0xffefffffffffffff
  store i1 %t14, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t16 = load i1, ptr %l6, !tbaa !21
  store i1 %t16, ptr %l3, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l3, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d41 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Of" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Pow" }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'**'" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Pow" }>, align 8
@.d45 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Pow" }>, align 8
@.d46 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d47 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d48 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d49 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"a store over a value with destructors to run, reached through what a call gives (O15)" }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d51 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d52 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d53 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d54 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d57 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d58 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d59 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Div" }>, align 8
@.d60 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Rem" }>, align 8
@.d61 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"MatMul" }>, align 8
@.d62 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Less" }>, align 8
@.d63 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d64 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d65 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitXor" }>, align 8
@.d66 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ShiftLeft" }>, align 8
@.d67 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ShiftRight" }>, align 8
@.d68 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Pow" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassignAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvertedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAssignable(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompoundOp(i32 %a0)
declare i1 @compiler_2fcheck_2elaneTok(i32 %a0)
@olang_loc_d2a4873a2cff0127_7286b996ab1f319b = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, i64 %a6, { i64, ptr } %a7)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAssign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumberDoesNotFlow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, i32 %a3)
@olang_loc_5957a34f5d629e92_b1985d6017512bae = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftInRange(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_211eb8206518cfd3_dabae8ca263a8cdf = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2fcheck_2ebinaryOp(i32 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare { ptr, { i64, ptr }, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrCallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAttrRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrFound(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeFn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_f2dfd4e2b2620e71_dbe725d38eafc295 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f2b973fcab239364_d01bf2cd68c3b6a8 = external constant [0 x i8]
@olang_loc_1778b9e962c2fcc7_ba3812a15af6740b = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_94214b31169ec8c4_68c852e51d74cc68 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_d48ba9fb56fa57b5_9836703f13f4bc39 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPiece(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_964ce48e3719b9fe_ecf9d1875d849bc2 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@olang_loc_2b2e21654e3310f6_a1c2a2453bd05f02 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_f6343df54e321530_17a07bfc25de31ec = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
@olang_loc_fa88b19e51866753_1c515c5623826c7f = external constant [0 x i8]
@olang_loc_962a22c7791f971e_263bae1157bb3aaa = external constant [0 x i8]
@olang_loc_bce8d8bde069702e_ffe04dc686cce872 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af = external constant [0 x i8]
declare %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflCaseOther(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValCodes(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecasePath(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTestNotEnum(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTestOther(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_e1487403b47c0485_2c2fc5ff7a99fd49 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fgeneric_2eDescNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/generic:Desc" @compiler_2fgeneric_3aDesc_2ector(ptr %v0, i64 %a0, i32 %a1, i64 %a2, i64 %a3)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3cf4b7359f29899a_630bdcef83a186 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"compiler/typed:ContractInfo" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H1fc1bd863e6a60d3e5c2aece55d841d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cc784a1e8fddb41e_ee964d456644b6b2 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edispatchChecks(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4, i32 %a5, %"compiler/typed:ContractInfo" %a6)
@olang_loc_34d74ab5dd8a1e9f_be34dcde3b606033 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %a0)
declare { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4, { i64, ptr } %a5)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_3aContractAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, { i64, ptr } %a9)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ePu_H286c5e5dcd81788bf1de6ef6fc9774a9(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameLen(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisZeroLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d2b428b6a63c5a88_9cb41cac42ab9d54 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_700945490095e3ab_b793fb317cfa4b47 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28 = external constant [0 x i8]
@olang_loc_25ec48d7738ec131_33504a893c084afd = external constant [0 x i8]
@olang_loc_1c86c4e2a1d4d52a_afb2831c22759b16 = external constant [0 x i8]
@olang_loc_34572fc3675c142e_5b9246c98f1fa642 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:AnySlot" %a1)
@olang_loc_384cb541f04295b0_3f9ee0143bd9d7ac = external constant [0 x i8]
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3, { i64, ptr } %a4)
@olang_loc_a90b29f72ec4d10d_507af4b2e3250de1 = external constant [0 x i8]
@olang_loc_8dac41fcc89db5e5_6cee581458fc6b9 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_d97e23b04dcff800_367dc3876d150fb4 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eeffectOp(i32 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ad4dc9fe288360e2_6bae22496d237a26 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_29ea0c7d0dcef6fa_322b22c08f06752e = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_12a7e56ab193c888_f3ea9b5a769b449c = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoValueCase(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3f3d818644d50cc7_38dbc52e232a8b93 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f2fc693d8c32a9d2_b249c5d053dbb65e = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_1aa49c7f94741e71_4937354175d6cb9d = external constant [0 x i8]
@olang_loc_a8287edb9132b4cb_1f129b43d5c83daf = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3)
declare i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_48c434cc052a730a_3ea1b318a5aaa0d6 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8fffa2dcb89c09a5_7d27f2eeb87e61a1 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_343b32e44524bf9e_67b59a3d30ab5452 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %v0)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotInferable(ptr %v0)
@olang_loc_9c9a337b92d12a1f_5567ba002875d853 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4bb92e4e6aa9fa92_ae49a41c9a1a92ee = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUniqueLentHere(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUniqueAlias(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eLen__H4e51b5ca7b68af485b8486164a690a5f(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %a0, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_1a7153eaacfdc8_b1c3cf4a1728a65c = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatch(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindCase(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecided(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunbindCase(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3, i32 %a4)
declare i1 @compiler_2fcheck_2elaneMethodName(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, ptr %a4, { i64, ptr } %a5)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d23330c3ef7ea91b_34477ea00961dc87 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, { i64, ptr } %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseHas(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_897998a95b9e5e2e_e7f90bd867c953f2 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCharNoPad(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberHint(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/msgs:Msg" %a4)
@olang_loc_97297cf958301a5_897be3a3c1a33231 = external constant [0 x i8]
@olang_loc_f4ec2e4bc4870738_831a294d3dfd1224 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlaceCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
@olang_loc_968ede9ca4457b20_d4cd8e7344b6f50c = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOwner(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowedWrite(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
@olang_loc_4d0d10dbd8c28898_8d57e58513238834 = external constant [0 x i8]
@olang_loc_f66b04275832bdf5_49261566e6ebbc09 = external constant [0 x i8]
@olang_loc_959932aa8b846e4e_2c1999e37dfb1a2 = external constant [0 x i8]
@olang_loc_f94ac378888081c5_5f597351c4418bf9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
@olang_loc_bb9360f661a84828_a83eb458d7764d44 = external constant [0 x i8]
@olang_loc_9e3e60c51c241998_753bf57c496fa07c = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_2c067c0920238e9c_6231d620e5a2e328 = external constant [0 x i8]
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtAssigned(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
@olang_loc_c89e58dd43b8c5a0_98fae7e2dc40ed34 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtended(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_320f9d8592ce2991_bf25bbc6142ecf8d = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2ector(ptr %v0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResetAny(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3ainPlaceRead_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_2_Hedf46d61a7b7e16110f4585b041de150(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroFn_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2fvec_H2e44743f10bee47c9f5386f757b87bf0(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atailAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %v1, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eTrun_Haa7c8ccc08c8123d0b87c9688e5d351e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estable(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
@olang_loc_5f447d0cb8af3524_fdbf87197f7ceb70 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgWide(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_a23f531a57510fcc_ca69a351a39efde8 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_61f61c7eea085c49_e2109341212ff245 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
@olang_loc_5688429828d7ebe2_8ea9fe01fea3ad9e = external constant [0 x i8]
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_922ae0a799ba69ce_f9cc72ab99b0ec2 = external constant [0 x i8]
@olang_loc_46a0e749826cef18_3e2809181fcd5dac = external constant [0 x i8]
@olang_loc_2f12767f94a228d4_8b6b4888798b3f68 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eIsFunc(ptr %v0, ptr %a0)
@olang_loc_696a437f6b67e70a_247b6a7ce30931f6 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %a0)
@olang_loc_f65b5445e0db363a_c2ab951bd73e6226 = external constant [0 x i8]
@olang_loc_445c35e7b454dfb2_9156676d88e8071e = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eToArr_H3d785ef7fade1f29078b6e80f1d617ba(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_524a47ae64dd06b8_5def175755840fac = external constant [0 x i8]
@olang_loc_d195b38137e2d30_7d67c1d5e7f3802c = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_129627029b1e0c70_26637847123ec4fc = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
