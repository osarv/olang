; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/cond:Value" = type { i32, i64, double, i64, i64, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/check:opShape" = type { { i64, ptr }, i64, i1, i1 }
define dso_local void @compiler_2fcheck_2eCtEntry_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2fcheck_2eCtEntry, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2eallBuilt(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t32 = call i1 @compiler_2fcheck_2ebuiltAst(ptr %v0, ptr %t28)
  store i1 %t32, ptr %l20
  br label %bb8
bb8:
  %t33 = load i1, ptr %l20, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l2, !tbaa !24
  br label %bb4
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecasePath(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtNames(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i32
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i32
  %l60 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l68 = alloca %"compiler/typed:Local"
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i32
  %l91 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca i32
  %l115 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l122 = alloca %"compiler/typed:Local"
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i32
  %l138 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l153 = alloca ptr
  %l156 = alloca %"compiler/typed:Local"
  %l157 = alloca %"compiler/source:Span"
  %l158 = alloca %"compiler/msgs:Msg"
  %l159 = alloca i64
  %l166 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l170 = alloca i32
  %l179 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l187 = alloca i32
  %l196 = alloca { i64, ptr }
  %l209 = alloca ptr
  %l211 = alloca %"compiler/source:Span"
  %l212 = alloca %"compiler/msgs:Msg"
  %l213 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l45
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l5
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %l7, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBind_26_3e_2eRun_H6780729b4f4c1d3e21064ca0ba41c437(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l51
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l50
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t14, ptr %l47, !tbaa !27
  br label %bb8
bb4:
  %t15 = load i32, ptr %l51, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_7630015a1eabc80_a7cefd5c2ca62e84)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb8:
  %t20 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t20, ptr %l8, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l10, !tbaa !24
  %t26 = load i64, ptr %l9, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t33 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t33, ptr %l60, !tbaa !27
  %t34 = load i64, ptr %l10, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  store ptr %t39, ptr %l11, !tbaa !29
  store ptr %l5, ptr %l63, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t41)
  store ptr %t43, ptr %l65
  br label %bb13
bb13:
  %t44 = load ptr, ptr %l11, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Bind", ptr %t44, i32 0, i32 0
  %t47 = load i32, ptr %t46, !tbaa !23
  %t48 = load ptr, ptr %l65, !tbaa !29
  %t50 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t48, i32 %t47)
  store %"compiler/typed:Local" %t50, ptr %l68
  br label %bb14
bb14:
  %t51 = getelementptr %"compiler/typed:Local", ptr %l68, i32 0, i32 0
  %t52 = load i32, ptr %t51, !tbaa !23
  %t53 = load ptr, ptr %l63, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %s0, ptr %t53, i32 %t52)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t55 = load i64, ptr %l10, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l10, !tbaa !24
  br label %bb9
bb17:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l9, !tbaa !24
  %t63 = add i64 %t59, %t60
  store i64 %t63, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb2
bb19:
  %t67 = icmp eq i64 %a3, 0
  br i1 %t67, label %bb20, label %bb21
bb20:
  store ptr %l5, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb22
bb21:
  br label %bb38
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t70 = load ptr, ptr %l12, !tbaa !29
  %t71 = load i64, ptr %l13, !tbaa !24
  %t74 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %s0, ptr %t70, i64 %t71)
  %t75 = extractvalue { i32, { i64, ptr } } %t74, 1
  %t76 = extractvalue { i32, { i64, ptr } } %t74, 0
  store i32 %t76, ptr %l82
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb24, label %ok.78
ok.78:
  store { i64, ptr } %t75, ptr %l81
  br label %bb23
bb23:
  %t79 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t79, ptr %l78, !tbaa !27
  br label %bb28
bb24:
  %t80 = load i32, ptr %l82, !tbaa !23
  %t81 = ashr i32 %t80, 16
  %t83 = icmp eq i32 %t81, 1
  br i1 %t83, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_895a5b373a859d11_d91bb98a2d8e9a75)
  unreachable
bb27:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb28:
  %t85 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t85, ptr %l14, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  %t90 = load i64, ptr %l16, !tbaa !24
  %t91 = load i64, ptr %l15, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t98 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t98, ptr %l91, !tbaa !27
  %t99 = load i64, ptr %l16, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i32, ptr %t102, i64 %t99
  %t104 = load i32, ptr %t103, !tbaa !33
  %t106 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v2, ptr %t106, i32 %t104)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb34:
  %t110 = load i64, ptr %l16, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l16, !tbaa !24
  br label %bb29
bb35:
  %t114 = load i64, ptr %l13, !tbaa !24
  %t115 = load i64, ptr %l15, !tbaa !24
  %t118 = add i64 %t114, %t115
  store i64 %t118, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  br label %bb22
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb38:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t122 = load ptr, ptr %l18, !tbaa !29
  %t123 = load i64, ptr %l19, !tbaa !24
  %t126 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBind_26_3e_2eRun_H6780729b4f4c1d3e21064ca0ba41c437(ptr %v1, ptr %t122, i64 %t123)
  %t127 = extractvalue { i32, { i64, ptr } } %t126, 1
  %t128 = extractvalue { i32, { i64, ptr } } %t126, 0
  store i32 %t128, ptr %l106
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb41, label %ok.130
ok.130:
  store { i64, ptr } %t127, ptr %l105
  br label %bb40
bb40:
  %t131 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t131, ptr %l102, !tbaa !27
  br label %bb45
bb41:
  %t132 = load i32, ptr %l106, !tbaa !23
  %t133 = ashr i32 %t132, 16
  %t135 = icmp eq i32 %t133, 1
  br i1 %t135, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_57cee8e261e9bb7a_a117945682ceb0be)
  unreachable
bb44:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb45:
  %t137 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t137, ptr %l20, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s12
  %t142 = load i64, ptr %l22, !tbaa !24
  %t143 = load i64, ptr %l21, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s12)
  br label %bb78
bb48:
  br label %bb49
bb49:
  %t150 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t150, ptr %l115, !tbaa !27
  %t151 = load i64, ptr %l22, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr ptr, ptr %t154, i64 %t151
  %t156 = load ptr, ptr %t155, !tbaa !39
  store ptr %t156, ptr %l23, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t158)
  store ptr %t160, ptr %l119
  br label %bb50
bb50:
  %t161 = load ptr, ptr %l23, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Bind", ptr %t161, i32 0, i32 0
  %t164 = load i32, ptr %t163, !tbaa !23
  %t165 = load ptr, ptr %l119, !tbaa !29
  %t167 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t165, i32 %t164)
  store %"compiler/typed:Local" %t167, ptr %l122
  br label %bb51
bb51:
  %t168 = getelementptr %"compiler/typed:Local", ptr %l122, i32 0, i32 0
  %t169 = load i32, ptr %t168, !tbaa !23
  store i32 %t169, ptr %l24, !tbaa !23
  store i1 false, ptr %l25, !tbaa !21
  %t171 = load ptr, ptr %l2, !tbaa !29
  store ptr %t171, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s14
  %t173 = load ptr, ptr %l26, !tbaa !29
  %t174 = load i64, ptr %l27, !tbaa !24
  %t177 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v2, ptr %t173, i64 %t174)
  %t178 = extractvalue { i32, { i64, ptr } } %t177, 1
  %t179 = extractvalue { i32, { i64, ptr } } %t177, 0
  store i32 %t179, ptr %l129
  %t180 = icmp ne i32 %t179, 0
  br i1 %t180, label %bb54, label %ok.181
ok.181:
  store { i64, ptr } %t178, ptr %l128
  br label %bb53
bb53:
  %t182 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t182, ptr %l125, !tbaa !27
  br label %bb58
bb54:
  %t183 = load i32, ptr %l129, !tbaa !23
  %t184 = ashr i32 %t183, 16
  %t186 = icmp eq i32 %t184, 1
  br i1 %t186, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_66d51bf767fdffb_4023b8d39b45a3bf)
  unreachable
bb57:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s14)
  br label %bb69
bb58:
  %t188 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t188, ptr %l28, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  store i64 %t191, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s15
  %t193 = load i64, ptr %l30, !tbaa !24
  %t194 = load i64, ptr %l29, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s15)
  br label %bb67
bb61:
  br label %bb62
bb62:
  %t201 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t201, ptr %l138, !tbaa !27
  %t202 = load i64, ptr %l30, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 %t202
  %t207 = load i32, ptr %t206, !tbaa !33
  %t210 = load i32, ptr %l24, !tbaa !23
  %t213 = icmp eq i32 %t207, %t210
  br i1 %t213, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb65
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s15)
  br label %bb66
bb66:
  %t215 = load i64, ptr %l30, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l30, !tbaa !24
  br label %bb59
bb67:
  %t219 = load i64, ptr %l27, !tbaa !24
  %t220 = load i64, ptr %l29, !tbaa !24
  %t223 = add i64 %t219, %t220
  store i64 %t223, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb68
bb68:
  br label %bb52
bb69:
  %t225 = load i1, ptr %l25, !tbaa !21
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s18
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l151, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t230)
  store ptr %t232, ptr %l153
  br label %bb72
bb71:
  br label %bb76
bb72:
  %t233 = load ptr, ptr %l23, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Bind", ptr %t233, i32 0, i32 0
  %t236 = load i32, ptr %t235, !tbaa !23
  %t237 = load ptr, ptr %l153, !tbaa !29
  %t239 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t237, i32 %t236)
  store %"compiler/typed:Local" %t239, ptr %l156
  br label %bb73
bb73:
  %t240 = getelementptr %"compiler/typed:Local", ptr %l156, i32 0, i32 1
  %t241 = load %"compiler/source:Span", ptr %t240
  store %"compiler/source:Span" %t241, ptr %l157
  %t242 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %s18)
  store %"compiler/msgs:Msg" %t242, ptr %l158
  br label %bb74
bb74:
  %t243 = load ptr, ptr %l151, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l157
  %t245 = load %"compiler/msgs:Msg", ptr %l158
  %t246 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t243, %"compiler/source:Span" %t244, %"compiler/msgs:Msg" %t245)
  store i64 %t246, ptr %l159
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb76:
  call void @__olang_scope_close(ptr %s12)
  br label %bb77
bb77:
  %t247 = load i64, ptr %l22, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l22, !tbaa !24
  br label %bb46
bb78:
  %t251 = load i64, ptr %l19, !tbaa !24
  %t252 = load i64, ptr %l21, !tbaa !24
  %t255 = add i64 %t251, %t252
  store i64 %t255, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb79
bb79:
  br label %bb39
bb80:
  %t257 = load ptr, ptr %l2, !tbaa !29
  store ptr %t257, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s21
  %t259 = load ptr, ptr %l32, !tbaa !29
  %t260 = load i64, ptr %l33, !tbaa !24
  %t263 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v2, ptr %t259, i64 %t260)
  %t264 = extractvalue { i32, { i64, ptr } } %t263, 1
  %t265 = extractvalue { i32, { i64, ptr } } %t263, 0
  store i32 %t265, ptr %l170
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb83, label %ok.267
ok.267:
  store { i64, ptr } %t264, ptr %l169
  br label %bb82
bb82:
  %t268 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t268, ptr %l166, !tbaa !27
  br label %bb87
bb83:
  %t269 = load i32, ptr %l170, !tbaa !23
  %t270 = ashr i32 %t269, 16
  %t272 = icmp eq i32 %t270, 1
  br i1 %t272, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_2d4bbb6497aa425c_2f833b8e3e06fbc8)
  unreachable
bb86:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s21)
  br label %bb119
bb87:
  %t274 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t274, ptr %l34, !tbaa !27
  %t275 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  store i64 %t277, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s22
  %t279 = load i64, ptr %l36, !tbaa !24
  %t280 = load i64, ptr %l35, !tbaa !24
  %t283 = icmp slt i64 %t279, %t280
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s22)
  br label %bb117
bb90:
  br label %bb91
bb91:
  %t287 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t287, ptr %l179, !tbaa !27
  %t288 = load i64, ptr %l36, !tbaa !24
  %t290 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr i32, ptr %t291, i64 %t288
  %t293 = load i32, ptr %t292, !tbaa !33
  store i32 %t293, ptr %l37, !tbaa !23
  store i1 false, ptr %l38, !tbaa !21
  store ptr %l5, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb92
bb92:
  store %olang.scope zeroinitializer, ptr %s24
  %t296 = load ptr, ptr %l39, !tbaa !29
  %t297 = load i64, ptr %l40, !tbaa !24
  %t300 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %s0, ptr %t296, i64 %t297)
  %t301 = extractvalue { i32, { i64, ptr } } %t300, 1
  %t302 = extractvalue { i32, { i64, ptr } } %t300, 0
  store i32 %t302, ptr %l187
  %t303 = icmp ne i32 %t302, 0
  br i1 %t303, label %bb94, label %ok.304
ok.304:
  store { i64, ptr } %t301, ptr %l186
  br label %bb93
bb93:
  %t305 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t305, ptr %l183, !tbaa !27
  br label %bb98
bb94:
  %t306 = load i32, ptr %l187, !tbaa !23
  %t307 = ashr i32 %t306, 16
  %t309 = icmp eq i32 %t307, 1
  br i1 %t309, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  call void @__olang_check_failed(ptr @olang_loc_c46ca745ccc2db8d_58407427ebe5099)
  unreachable
bb97:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s24)
  br label %bb109
bb98:
  %t311 = load { i64, ptr }, ptr %l183, !tbaa !27
  store { i64, ptr } %t311, ptr %l41, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t312, 0
  store i64 %t314, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb99
bb99:
  store %olang.scope zeroinitializer, ptr %s25
  %t316 = load i64, ptr %l43, !tbaa !24
  %t317 = load i64, ptr %l42, !tbaa !24
  %t320 = icmp slt i64 %t316, %t317
  %t322 = xor i1 %t320, true
  br i1 %t322, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s25)
  br label %bb107
bb101:
  br label %bb102
bb102:
  %t324 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t324, ptr %l196, !tbaa !27
  %t325 = load i64, ptr %l43, !tbaa !24
  %t327 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr i32, ptr %t328, i64 %t325
  %t330 = load i32, ptr %t329, !tbaa !33
  %t333 = load i32, ptr %l37, !tbaa !23
  %t336 = icmp eq i32 %t330, %t333
  br i1 %t336, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb105
bb104:
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s25)
  br label %bb106
bb106:
  %t338 = load i64, ptr %l43, !tbaa !24
  %t340 = add i64 %t338, 1
  store i64 %t340, ptr %l43, !tbaa !24
  br label %bb99
bb107:
  %t342 = load i64, ptr %l40, !tbaa !24
  %t343 = load i64, ptr %l42, !tbaa !24
  %t346 = add i64 %t342, %t343
  store i64 %t346, ptr %l40, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb108
bb108:
  br label %bb92
bb109:
  %t348 = load i1, ptr %l38, !tbaa !21
  %t350 = xor i1 %t348, true
  br i1 %t350, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s28
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l209, !tbaa !29
  %t355 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v3, ptr %a4)
  store %"compiler/source:Span" %t355, ptr %l211
  br label %bb112
bb111:
  br label %bb115
bb112:
  %t356 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %s28)
  store %"compiler/msgs:Msg" %t356, ptr %l212
  br label %bb113
bb113:
  %t357 = load ptr, ptr %l209, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l211
  %t359 = load %"compiler/msgs:Msg", ptr %l212
  %t360 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s28, ptr %t357, %"compiler/source:Span" %t358, %"compiler/msgs:Msg" %t359)
  store i64 %t360, ptr %l213
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb115:
  call void @__olang_scope_close(ptr %s22)
  br label %bb116
bb116:
  %t361 = load i64, ptr %l36, !tbaa !24
  %t363 = add i64 %t361, 1
  store i64 %t363, ptr %l36, !tbaa !24
  br label %bb88
bb117:
  %t365 = load i64, ptr %l33, !tbaa !24
  %t366 = load i64, ptr %l35, !tbaa !24
  %t369 = add i64 %t365, %t366
  store i64 %t369, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s21)
  br label %bb118
bb118:
  br label %bb81
bb119:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCopies(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  store ptr %t14, ptr %l9, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = load i32, ptr %l12, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t22, ptr %l13
  br label %bb5
bb5:
  %t23 = load i32, ptr %l13
  %t25 = trunc i64 19 to i32
  %t26 = icmp eq i32 %t23, %t25
  store i1 %t26, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l6, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/load:Import"
  %l12 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l36 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i1, ptr %l12, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t7, i64 %t8, i1 true)
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 5
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l20
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 11
  store ptr %t26, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t28, i64 %t29)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l27
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb9, label %ok.36
ok.36:
  store { i64, ptr } %t33, ptr %l26
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  br label %bb13
bb9:
  %t38 = load i32, ptr %l27, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8144c9e107914b58_42c61ae8c534985c)
  unreachable
bb12:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb13:
  %t43 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t43, ptr %l6, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb16:
  br label %bb17
bb17:
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t56, ptr %l36, !tbaa !27
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/load:Import", ptr %t60, i64 %t57
  %t62 = load %"compiler/load:Import", ptr %t61
  store %"compiler/load:Import" %t62, ptr %l9
  %t64 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp sge i64 %t65, 0
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %t69, i64 %t71, ptr %t72, ptr %t73)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l8, !tbaa !24
  br label %bb14
bb23:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t82, %t83
  store i64 %t86, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  br label %bb7
bb25:
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t88, i64 %t89)
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l35 = alloca i1
  %l43 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l52 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca i32
  %l75 = alloca i32
  %l76 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l84 = alloca i64
  %l90 = alloca i1
  %l94 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l150 = alloca i32
  %l159 = alloca ptr
  %l164 = alloca i32
  %l165 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l24, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l24, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l2, !tbaa !23
  %t14 = icmp eq i32 %t12, 0
  store i1 %t14, ptr %l28, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l28, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb10
bb8:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/check:b5aWalk", ptr %t17, i32 0, i32 5
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v1, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l35
  br label %bb9
bb9:
  %t24 = load i1, ptr %l35, !tbaa !21
  store i1 %t24, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t25 = load i1, ptr %l31, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/check:b5aWalk", ptr %t26, i32 0, i32 5
  %t29 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v1, ptr %t28, i32 %t29, i1 true)
  br label %bb14
bb14:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l43
  br label %bb15
bb15:
  %t42 = load i32, ptr %l43
  store i32 %t42, ptr %l4
  %t43 = load i32, ptr %l4
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l46, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l47, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l52
  br label %bb19
bb19:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t62 = add i64 %t60, 1
  %t63 = load ptr, ptr %l46, !tbaa !29
  %t64 = load ptr, ptr %l47, !tbaa !29
  %t65 = load i32, ptr %l52, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i32 %t65, i64 %t62)
  br label %bb20
bb20:
  br label %bb82
bb21:
  %t67 = load i32, ptr %l4
  %t69 = trunc i64 18 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb60
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d0 }, 0
  %t73 = insertvalue [2 x { i64, ptr }] %t72, { i64, ptr } { i64 3, ptr @.d1 }, 1
  %t75 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store [2 x { i64, ptr }] %t73, ptr %t75
  store ptr %t75, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t77 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t80 = load i64, ptr %l6, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb27:
  br label %bb28
bb28:
  %t88 = load ptr, ptr %l5
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = getelementptr [2 x { i64, ptr }], ptr %t88, i64 0, i64 %t89
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !37
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l69, !tbaa !29
  %t99 = load i32, ptr %l2, !tbaa !23
  store i32 %t99, ptr %l70, !tbaa !23
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = getelementptr %"compiler/types:Table", ptr %t105, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = load ptr, ptr @__olang_prog_scope
  %t112 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %t109, ptr %t107, { i64, ptr } %t93)
  store i32 %t112, ptr %l75
  br label %bb29
bb29:
  %t113 = load ptr, ptr %l69, !tbaa !29
  %t114 = load i32, ptr %l70, !tbaa !23
  %t115 = load i32, ptr %l75, !tbaa !23
  %t116 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t113, i32 %t114, i32 %t115)
  store i64 %t116, ptr %l76
  br label %bb30
bb30:
  %t117 = load i64, ptr %l76, !tbaa !24
  store i64 %t117, ptr %l9, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t120 = icmp sge i64 %t118, 0
  br i1 %t120, label %bb31, label %bb32
bb31:
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l79, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l80, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i64, ptr %l9, !tbaa !24
  %t126 = load i32, ptr %l2, !tbaa !23
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStrBody(ptr %v0, ptr %t124, i64 %t125, i32 %t126)
  store i64 %t130, ptr %l84
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t131 = load ptr, ptr %l79, !tbaa !29
  %t132 = load ptr, ptr %l80, !tbaa !29
  %t133 = load i64, ptr %l84, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t131, ptr %t132, i64 %t133)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  %t134 = load i64, ptr %l6, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l6, !tbaa !24
  br label %bb25
bb37:
  call void @__olang_scope_close(ptr %s4)
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t142 = load i32, ptr %l2, !tbaa !23
  %t145 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t141, i32 %t142)
  store i1 %t145, ptr %l90
  br label %bb38
bb38:
  %t146 = load i1, ptr %l90, !tbaa !21
  %t147 = xor i1 %t146, true
  br i1 %t147, label %bb39, label %bb40
bb39:
  br label %ret
bb40:
  br label %bb41
bb41:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  store ptr %t154, ptr %l94, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/generic:Program", ptr %t158, i32 0, i32 2
  %t161 = load i32, ptr %l2, !tbaa !23
  %t164 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t160, i32 %t161)
  store i32 %t164, ptr %l99
  br label %bb42
bb42:
  %t165 = load ptr, ptr %l94, !tbaa !29
  %t166 = load i32, ptr %l99, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t165, i32 %t166)
  store { i64, ptr } %t167, ptr %l100
  br label %bb43
bb43:
  %t168 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t168, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  store i64 %t171, ptr %l12, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t173 = load i64, ptr %l11, !tbaa !24
  %t174 = load i64, ptr %l12, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t181 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t181, ptr %l107, !tbaa !27
  %t182 = load i64, ptr %l11, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 %t182
  %t187 = load i32, ptr %t186, !tbaa !33
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = load i64, ptr %l3, !tbaa !24
  %t194 = add i64 %t192, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t189, ptr %t190, i32 %t187, i64 %t194)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  %t199 = load i64, ptr %l11, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l11, !tbaa !24
  br label %bb44
bb50:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  store ptr %t208, ptr %l119, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/generic:Program", ptr %t212, i32 0, i32 2
  %t215 = load i32, ptr %l2, !tbaa !23
  %t218 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t214, i32 %t215)
  store i32 %t218, ptr %l124
  br label %bb51
bb51:
  %t219 = load ptr, ptr %l119, !tbaa !29
  %t220 = load i32, ptr %l124, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t219, i32 %t220)
  store { i64, ptr } %t221, ptr %l125
  br label %bb52
bb52:
  %t222 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t222, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t223, 0
  store i64 %t225, ptr %l16, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s13
  %t227 = load i64, ptr %l15, !tbaa !24
  %t228 = load i64, ptr %l16, !tbaa !24
  %t231 = icmp slt i64 %t227, %t228
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s13)
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t235 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t235, ptr %l132, !tbaa !27
  %t236 = load i64, ptr %l15, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr i32, ptr %t239, i64 %t236
  %t241 = load i32, ptr %t240, !tbaa !33
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = load i64, ptr %l3, !tbaa !24
  %t248 = add i64 %t246, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t243, ptr %t244, i32 %t241, i64 %t248)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s13)
  br label %bb58
bb58:
  %t253 = load i64, ptr %l15, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l15, !tbaa !24
  br label %bb53
bb59:
  br label %bb82
bb60:
  %t257 = load i32, ptr %l4
  %t259 = trunc i64 19 to i32
  %t260 = icmp eq i32 %t257, %t259
  br i1 %t260, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l144, !tbaa !29
  %t263 = load ptr, ptr %l1, !tbaa !29
  store ptr %t263, ptr %l145, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 2
  %t270 = load i32, ptr %l2, !tbaa !23
  %t273 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t269, i32 %t270)
  store i32 %t273, ptr %l150
  br label %bb64
bb64:
  %t274 = load i64, ptr %l3, !tbaa !24
  %t276 = add i64 %t274, 1
  %t277 = load ptr, ptr %l144, !tbaa !29
  %t278 = load ptr, ptr %l145, !tbaa !29
  %t279 = load i32, ptr %l150, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t277, ptr %t278, i32 %t279, i64 %t276)
  br label %bb65
bb65:
  br label %bb82
bb66:
  %t281 = load i32, ptr %l4
  %t283 = trunc i64 22 to i32
  %t284 = icmp eq i32 %t281, %t283
  br i1 %t284, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  %t286 = load i32, ptr %l4
  %t288 = trunc i64 23 to i32
  %t289 = icmp eq i32 %t286, %t288
  br i1 %t289, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb81
bb71:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 2
  store ptr %t296, ptr %l159, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/check:Checker", ptr %t297, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t302 = getelementptr %"compiler/generic:Program", ptr %t300, i32 0, i32 2
  %t303 = load i32, ptr %l2, !tbaa !23
  %t306 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t302, i32 %t303)
  store i32 %t306, ptr %l164
  br label %bb72
bb72:
  %t307 = load ptr, ptr %l159, !tbaa !29
  %t308 = load i32, ptr %l164, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t307, i32 %t308)
  store { i64, ptr } %t309, ptr %l165
  br label %bb73
bb73:
  %t310 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t310, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t311 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t311, 0
  store i64 %t313, ptr %l20, !tbaa !24
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s18
  %t315 = load i64, ptr %l19, !tbaa !24
  %t316 = load i64, ptr %l20, !tbaa !24
  %t319 = icmp slt i64 %t315, %t316
  %t321 = xor i1 %t319, true
  br i1 %t321, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s18)
  br label %bb80
bb76:
  br label %bb77
bb77:
  %t323 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t323, ptr %l172, !tbaa !27
  %t324 = load i64, ptr %l19, !tbaa !24
  %t326 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr i32, ptr %t327, i64 %t324
  %t329 = load i32, ptr %t328, !tbaa !33
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l1, !tbaa !29
  %t334 = load i64, ptr %l3, !tbaa !24
  %t336 = add i64 %t334, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t331, ptr %t332, i32 %t329, i64 %t336)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s18)
  br label %bb79
bb79:
  %t341 = load i64, ptr %l19, !tbaa !24
  %t343 = add i64 %t341, 1
  store i64 %t343, ptr %l19, !tbaa !24
  br label %bb74
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebraceAfter(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l10 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l22 = alloca i32
  %l24 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca ptr
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l69 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Case", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Case", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb3:
  call void @__olang_check_failed(ptr @olang_loc_6eddca2d598ce6fb_9d8bffc2796cf667)
  unreachable
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Case", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t29)
  store %"compiler/source:Span" %t31, ptr %l16
  br label %bb6
bb6:
  %t32 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 1
  %t33 = load i32, ptr %t32, !tbaa !23
  store i32 %t33, ptr %l10, !tbaa !23
  br label %bb11
bb7:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Case", ptr %t35, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l24, !tbaa !27
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Case", ptr %t39, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = sub i64 %t44, 1
  %t48 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t53 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t51)
  store %"compiler/source:Span" %t53, ptr %l30
  br label %bb9
bb8:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Case", ptr %t54, i32 0, i32 0
  %t57 = getelementptr %"compiler/source:Span", ptr %t56, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  store i32 %t58, ptr %l22, !tbaa !23
  br label %bb10
bb9:
  %t60 = getelementptr %"compiler/source:Span", ptr %l30, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l22, !tbaa !23
  br label %bb10
bb10:
  %t63 = load i32, ptr %l22, !tbaa !23
  store i32 %t63, ptr %l10, !tbaa !23
  br label %bb11
bb11:
  %t64 = load i32, ptr %l10, !tbaa !23
  store i32 %t64, ptr %l2, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 5
  store ptr %t73, ptr %l37, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t74)
  store ptr %t76, ptr %l39
  br label %bb12
bb12:
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t79 = getelementptr %"compiler/check:frame", ptr %t77, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = load ptr, ptr %l37, !tbaa !29
  %t83 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t81, i64 %t80)
  store ptr %t83, ptr %l42
  br label %bb13
bb13:
  %t84 = load ptr, ptr %l42, !tbaa !29
  %t86 = getelementptr %"compiler/load:Module", ptr %t84, i32 0, i32 6
  %t87 = load ptr, ptr %t86, !tbaa !29
  store ptr %t87, ptr %l3, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f64a0f855cc2648c_4038adf1240cd248)
  unreachable
bb15:
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t96 = getelementptr %"compiler/source:Source", ptr %t93, i32 0, i32 1
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l4, !tbaa !27
  %t99 = load i32, ptr %l2, !tbaa !23
  %t101 = sext i32 %t99 to i64
  store i64 %t101, ptr %l5, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  %t103 = load i64, ptr %l5, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t109 = icmp slt i64 %t103, %t106
  br i1 %t109, label %bb18, label %bb19
bb18:
  %t111 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t111, ptr %l57, !tbaa !27
  %t112 = load i64, ptr %l5, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i8, ptr %t115, i64 %t112
  %t117 = load i8, ptr %t116, !tbaa !32
  %t119 = icmp ne i8 %t117, 123
  store i1 %t119, ptr %l56, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t121 = load i1, ptr %l56, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb22:
  br label %bb23
bb23:
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb24
bb24:
  br label %bb17
bb25:
  %t128 = load i64, ptr %l5, !tbaa !24
  %t130 = trunc i64 %t128 to i32
  %t131 = load i64, ptr %l5, !tbaa !24
  %t133 = add i64 %t131, 1
  %t135 = trunc i64 %t133 to i32
  %t138 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t130, i32 %t135)
  store %"compiler/source:Span" %t138, ptr %l69
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t139 = load %"compiler/source:Span", ptr %l69
  store %"compiler/source:Span" %t139, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t17, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Branch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Branch", ptr %t29, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %t28, i32 1, %"compiler/source:Span" %t32)
  store ptr %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l18, !tbaa !29
  store ptr %t38, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Branch", ptr %t39, i32 0, i32 2
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %t54, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t55)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { %"compiler/cond:Value", i1 }
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i1
  %lp6 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca { %"compiler/cond:Value", i1 }
  %l17 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { %"compiler/cond:Value", i1 }
  %l22 = alloca i32
  %l27 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l37 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i32
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l64 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l74 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l79 = alloca i32
  %l81 = alloca i32
  %l83 = alloca ptr
  %l96 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  %t182 = alloca { i64, [2 x i64] }, align 8
  %t190 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 88
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t4)
  store ptr %t6, ptr %l10
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t9 = getelementptr %"compiler/check:frame", ptr %t7, i32 0, i32 0
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = load ptr, ptr %l8, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t11, i64 %t10, i1 true)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t23, i32 %a2)
  store { i64, ptr } %t27, ptr %l20
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t30 = call { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v0, ptr %t28, { i64, ptr } %t29)
  %t31 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t30, 1
  %t32 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t30, 0
  store i32 %t32, ptr %l22
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb5, label %ok.34
ok.34:
  store { %"compiler/cond:Value", i1 } %t31, ptr %l21
  br label %bb4
bb4:
  %t35 = load { %"compiler/cond:Value", i1 }, ptr %l21
  store { %"compiler/cond:Value", i1 } %t35, ptr %l13
  br label %bb9
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t36, %"compiler/source:Span" %t37, { i64, ptr } { i64 32, ptr @.d2 })
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t40, %"compiler/source:Span" %t41)
  store ptr %t44, ptr %l27
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load ptr, ptr %l27, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load { %"compiler/cond:Value", i1 }, ptr %l13
  store { %"compiler/cond:Value", i1 } %t46, ptr %l3
  %t47 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l3, i32 0, i32 0
  %t48 = load %"compiler/cond:Value", ptr %t47
  store %"compiler/cond:Value" %t48, ptr %l4
  %t50 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l3, i32 0, i32 1
  %t51 = load i1, ptr %t50, !tbaa !21
  store i1 %t51, ptr %l5, !tbaa !21
  %t53 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t54 = load i32, ptr %t53
  %t56 = trunc i64 1 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l32, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t60, ptr %l33
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t61, ptr %l34, !tbaa !23
  %t62 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = icmp ne i64 %t63, 0
  br i1 %t65, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  store i64 1, ptr %l37, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb14
bb14:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l33
  %t69 = load i32, ptr %l34, !tbaa !23
  %t70 = load i64, ptr %l37, !tbaa !24
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t67, %"compiler/source:Span" %t68, i32 %t69, i64 %t70)
  store ptr %t71, ptr %l38
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load ptr, ptr %l38, !tbaa !29
  store ptr %t72, ptr %rv
  br label %ret
bb16:
  %t73 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t74 = load i32, ptr %t73
  %t76 = trunc i64 2 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l41, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t80, ptr %l42
  %t81 = load i1, ptr %l5, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb18:
  br label %bb25
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s3, ptr %t88, { i64, ptr } { i64 3, ptr @.d3 })
  store i32 %t90, ptr %l48
  br label %bb21
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t91)
  store i32 %t93, ptr %l50
  br label %bb22
bb21:
  %t94 = load i32, ptr %l48, !tbaa !23
  store i32 %t94, ptr %l44, !tbaa !23
  br label %bb23
bb22:
  %t95 = load i32, ptr %l50, !tbaa !23
  store i32 %t95, ptr %l44, !tbaa !23
  br label %bb23
bb23:
  %t96 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t97 = load i64, ptr %t96, !tbaa !24
  %t98 = load ptr, ptr %l41, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l42
  %t100 = load i32, ptr %l44, !tbaa !23
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t100, i64 %t97)
  store ptr %t102, ptr %l52
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t103 = load ptr, ptr %l52, !tbaa !29
  store ptr %t103, ptr %rv
  br label %ret
bb25:
  %t104 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t105 = load i32, ptr %t104
  %t107 = trunc i64 3 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l55, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t111, ptr %l56
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s4, ptr %t117, { i64, ptr } { i64 3, ptr @.d4 })
  store i32 %t119, ptr %l60
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t120 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 2
  %t121 = load double, ptr %t120, !tbaa !26
  %t123 = bitcast double %t121 to i64
  %t125 = load ptr, ptr %l55, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l56
  %t127 = load i32, ptr %l60, !tbaa !23
  %t129 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t125, %"compiler/source:Span" %t126, i32 %t127, i64 %t123)
  store ptr %t129, ptr %l64
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load ptr, ptr %l64, !tbaa !29
  store ptr %t130, ptr %rv
  br label %ret
bb30:
  %t131 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t132 = load i32, ptr %t131
  %t134 = trunc i64 4 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb31, label %bb32
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/load:Loader", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/cond:Consts", ptr %t146, i32 0, i32 6
  %t149 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 3
  %t150 = load i64, ptr %t149, !tbaa !24
  %t153 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t148, i64 %t150)
  store { i64, ptr } %t153, ptr %l73
  br label %bb33
bb32:
  br label %bb37
bb33:
  %t154 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t154, ptr %lp6
  %t155 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t156 = load ptr, ptr %lp6
  store { i64, ptr } %t155, ptr %t156, !tbaa !27
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l74
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  store ptr %t163, ptr %l77, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t164)
  store i32 %t166, ptr %l79
  br label %bb34
bb34:
  %t167 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t168 = load ptr, ptr %l77, !tbaa !29
  %t169 = load i32, ptr %l79, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t168, i32 %t169, i64 %t167)
  store i32 %t171, ptr %l81
  br label %bb35
bb35:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t172)
  store ptr %t174, ptr %l83
  br label %bb36
bb36:
  %t175 = load ptr, ptr %l83, !tbaa !29
  %t177 = getelementptr %"compiler/check:frame", ptr %t175, i32 0, i32 2
  %t178 = load i64, ptr %t177, !tbaa !24
  %t179 = load ptr, ptr %lp6
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [2 x i64] }, ptr %t182, i32 0, i32 0
  store i64 1, ptr %t183
  %t185 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t180, 0
  %t186 = getelementptr { i64, [2 x i64] }, ptr %t182, i32 0, i32 1
  store { { i64, ptr } } %t185, ptr %t186
  %t187 = load { i64, [2 x i64] }, ptr %t182
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t187, ptr %t189
  store { i64, [5 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 0
  store i64 1, ptr %t191
  %t192 = load %"compiler/source:Span", ptr %l74
  %t193 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t192, 0
  %t194 = load i32, ptr %l81, !tbaa !23
  %t195 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t193, i32 %t194, 1
  %t197 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t195, i64 %t178, 2
  %t199 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t197, ptr %t189, 3
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t199, ptr %t200
  %t201 = load { i64, [5 x i64] }, ptr %t190
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t201, ptr %t203
  call void @__olang_scope_close(ptr %s0)
  store ptr %t203, ptr %rv
  br label %ret
bb37:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t205, %"compiler/source:Span" %t206, { i64, ptr } { i64 35, ptr @.d5 })
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l1
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t209, %"compiler/source:Span" %t210)
  store ptr %t213, ptr %l96
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t214 = load ptr, ptr %l96, !tbaa !29
  store ptr %t214, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 4, ptr @.d6 })
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t11, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 5, ptr @.d7 })
  store i1 %t15, ptr %l10
  br label %bb6
bb6:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t17, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v0, ptr %t24, { i64, ptr } %t25)
  store i32 %t28, ptr %l16
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l16, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sge i64 0, 0
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t7 = icmp sle i64 0, 1152921504606846975
  br i1 %t7, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_fa88b19e51866753_1c515c5623826c7f)
  unreachable
bb5:
  %t9 = mul i64 0, 8
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 0, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_fa88b19e51866753_1c515c5623826c7f)
  unreachable
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = load i64, ptr %t18
  %t21 = icmp eq i64 %t19, 6
  store i1 %t21, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr { i64, [5 x i64] }, ptr %t23, i32 0, i32 1
  %t26 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t25, i32 0, i32 2
  %t27 = load ptr, ptr %t26
  store ptr %t27, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Call", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l8, !tbaa !27
  br label %bb22
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t34 = icmp sge i64 0, 0
  br i1 %t34, label %bb17, label %bb18
bb17:
  %t36 = icmp sle i64 0, 1152921504606846975
  br i1 %t36, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_962a22c7791f971e_263bae1157bb3aaa)
  unreachable
bb19:
  %t38 = mul i64 0, 8
  %t39 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 0, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  br label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_962a22c7791f971e_263bae1157bb3aaa)
  unreachable
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bce8d8bde069702e_ffe04dc686cce872)
  unreachable
bb22:
  %t43 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeErrors(ptr %v0, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l14 = alloca i32
  %l19 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t16, i64 %t19)
  store i32 %t22, ptr %l14
  br label %bb6
bb6:
  %t23 = load i32, ptr %l14, !tbaa !23
  store i32 %t23, ptr %l4, !tbaa !23
  br label %bb13
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t29, i32 %a2)
  store i32 %t33, ptr %l19
  br label %bb11
bb11:
  %t34 = load i32, ptr %l19, !tbaa !23
  store i32 %t34, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_27c62905650ee804_ddef4b1ccc198ce0)
  unreachable
bb13:
  %t35 = load i32, ptr %l4, !tbaa !23
  store i32 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatch(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i1, i1 }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca { i1, i1 }
  %l29 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/ast:Branch"
  %l46 = alloca %"compiler/ast:If"
  %l53 = alloca i64
  %l62 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca %"compiler/msgs:Msg"
  %l73 = alloca i64
  %l78 = alloca %"compiler/ast:Branch"
  %l84 = alloca %"compiler/source:Span"
  %l87 = alloca %"compiler/ast:If"
  %l92 = alloca %"compiler/source:Span"
  %l96 = alloca ptr
  %l101 = alloca %"compiler/ast:If"
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t82 = alloca { i64, [4 x i64] }, align 8
  %t176 = alloca { i64, [4 x i64] }, align 8
  %t208 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = call { i1, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %t1, %"compiler/source:Span" %a1, ptr %t3)
  store { i1, i1 } %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load { i1, i1 }, ptr %l14
  store { i1, i1 } %t8, ptr %l3
  %t9 = getelementptr { i1, i1 }, ptr %l3, i32 0, i32 0
  %t10 = load i1, ptr %t9, !tbaa !21
  %t12 = getelementptr { i1, i1 }, ptr %l3, i32 0, i32 1
  %t13 = load i1, ptr %t12, !tbaa !21
  store i1 %t13, ptr %l5, !tbaa !21
  %t17 = xor i1 %t10, true
  br i1 %t17, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr null, ptr %l6, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:Match", ptr %t19, i32 0, i32 4
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Match", ptr %t28, i32 0, i32 4
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb7, label %bb8
bb6:
  br label %bb18
bb7:
  call void @__olang_check_failed(ptr @olang_loc_35d0274d34665ca7_d8b5deabc24f5253)
  unreachable
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Match", ptr %t35, i32 0, i32 4
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Case", ptr %t38, i32 0, i32 0
  %t42 = load %"compiler/source:Span", ptr %t41
  store %"compiler/source:Span" %t42, ptr %l29
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Match", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_35d0274d34665ca7_d8b5deabc24f5253)
  unreachable
bb11:
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Match", ptr %t50, i32 0, i32 4
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Case", ptr %t53, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l36
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Match", ptr %t58, i32 0, i32 4
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  br i1 %t63, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_35d0274d34665ca7_d8b5deabc24f5253)
  unreachable
bb14:
  br label %bb15
bb15:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Match", ptr %t65, i32 0, i32 4
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Case", ptr %t68, i32 0, i32 4
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t73 = load %"compiler/source:Span", ptr %l36
  %t75 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t73, { i64, ptr } %t72, i64 -1)
  store %"compiler/ast:Branch" %t75, ptr %l44
  br label %bb16
bb16:
  %t76 = load %"compiler/ast:Branch", ptr %l44
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Branch" %t76, ptr %t77
  %t79 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr null, ptr %t77, ptr null)
  store %"compiler/ast:If" %t79, ptr %l46
  br label %bb17
bb17:
  %t80 = load %"compiler/ast:If", ptr %l46
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:If" %t80, ptr %t81
  store { i64, [4 x i64] } zeroinitializer, ptr %t82
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 0
  store i64 5, ptr %t83
  %t84 = load %"compiler/source:Span", ptr %l29
  %t85 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t84, 0
  %t87 = insertvalue { %"compiler/source:Span", ptr } %t85, ptr %t81, 1
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t87, ptr %t88
  %t89 = load { i64, [4 x i64] }, ptr %t82
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t89, ptr %t91
  store ptr %t91, ptr %l6, !tbaa !29
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t95 = load i1, ptr %l5, !tbaa !21
  %t99 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtLast(ptr %v0, ptr %v1, ptr %t93, ptr %t94, i1 %t95)
  store i64 %t99, ptr %l53
  br label %bb19
bb19:
  %t100 = load i64, ptr %l53, !tbaa !24
  store i64 %t100, ptr %l7, !tbaa !24
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/ast:Match", ptr %t101, i32 0, i32 3
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = sub i64 %t106, 1
  store i64 %t108, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t110 = load i64, ptr %l8, !tbaa !24
  %t112 = icmp sge i64 %t110, 0
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb22:
  br label %bb23
bb23:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr %"compiler/ast:Match", ptr %t116, i32 0, i32 3
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l62, !tbaa !27
  %t120 = load i64, ptr %l8, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr ptr, ptr %t123, i64 %t120
  %t125 = load ptr, ptr %t124, !tbaa !39
  store ptr %t125, ptr %l9, !tbaa !29
  %t127 = load ptr, ptr %l9, !tbaa !29
  %t129 = getelementptr %"compiler/ast:Case", ptr %t127, i32 0, i32 5
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = icmp eq ptr %t130, null
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l69, !tbaa !29
  %t137 = load ptr, ptr %l9, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Case", ptr %t137, i32 0, i32 0
  %t140 = load %"compiler/source:Span", ptr %t139
  store %"compiler/source:Span" %t140, ptr %l71
  %t141 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowInStatement(ptr %s5)
  store %"compiler/msgs:Msg" %t141, ptr %l72
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t142 = load ptr, ptr %l69, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l71
  %t144 = load %"compiler/msgs:Msg", ptr %l72
  %t145 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t142, %"compiler/source:Span" %t143, %"compiler/msgs:Msg" %t144)
  store i64 %t145, ptr %l73
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t146 = load ptr, ptr %l9, !tbaa !29
  %t148 = getelementptr %"compiler/ast:Case", ptr %t146, i32 0, i32 0
  %t149 = load %"compiler/source:Span", ptr %t148
  %t150 = load ptr, ptr %l9, !tbaa !29
  %t152 = getelementptr %"compiler/ast:Case", ptr %t150, i32 0, i32 4
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t156 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t149, { i64, ptr } %t153, i64 -1)
  store %"compiler/ast:Branch" %t156, ptr %l78
  br label %bb29
bb29:
  %t157 = load %"compiler/ast:Branch", ptr %l78
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Branch" %t157, ptr %t158
  store ptr %t158, ptr %l10, !tbaa !29
  %t160 = load i64, ptr %l8, !tbaa !24
  %t161 = load i64, ptr %l7, !tbaa !24
  %t164 = icmp eq i64 %t160, %t161
  br i1 %t164, label %bb30, label %bb31
bb30:
  %t166 = load ptr, ptr %l9, !tbaa !29
  %t168 = getelementptr %"compiler/ast:Case", ptr %t166, i32 0, i32 0
  %t169 = load %"compiler/source:Span", ptr %t168
  store %"compiler/source:Span" %t169, ptr %l84
  %t170 = load ptr, ptr %l10, !tbaa !29
  %t173 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr null, ptr %t170, ptr null)
  store %"compiler/ast:If" %t173, ptr %l87
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t174 = load %"compiler/ast:If", ptr %l87
  %t175 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:If" %t174, ptr %t175
  store { i64, [4 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 0
  store i64 5, ptr %t177
  %t178 = load %"compiler/source:Span", ptr %l84
  %t179 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t178, 0
  %t181 = insertvalue { %"compiler/source:Span", ptr } %t179, ptr %t175, 1
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t181, ptr %t182
  %t183 = load { i64, [4 x i64] }, ptr %t176
  %t185 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t183, ptr %t185
  store ptr %t185, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb33:
  %t187 = load ptr, ptr %l9, !tbaa !29
  %t189 = getelementptr %"compiler/ast:Case", ptr %t187, i32 0, i32 0
  %t190 = load %"compiler/source:Span", ptr %t189
  store %"compiler/source:Span" %t190, ptr %l92
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l2, !tbaa !29
  %t193 = load ptr, ptr %l9, !tbaa !29
  %t197 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCaseTest(ptr %v0, ptr %v1, ptr %v1, ptr %t191, ptr %t192, ptr %t193)
  store ptr %t197, ptr %l96
  br label %bb34
bb34:
  %t198 = load ptr, ptr %l96, !tbaa !29
  %t199 = load ptr, ptr %l10, !tbaa !29
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t205 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t198, ptr %t199, ptr %t201)
  store %"compiler/ast:If" %t205, ptr %l101
  br label %bb35
bb35:
  %t206 = load %"compiler/ast:If", ptr %l101
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:If" %t206, ptr %t207
  store { i64, [4 x i64] } zeroinitializer, ptr %t208
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 0
  store i64 5, ptr %t209
  %t210 = load %"compiler/source:Span", ptr %l92
  %t211 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t210, 0
  %t213 = insertvalue { %"compiler/source:Span", ptr } %t211, ptr %t207, 1
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t213, ptr %t214
  %t215 = load { i64, [4 x i64] }, ptr %t208
  %t217 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t215, ptr %t217
  store ptr %t217, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb36:
  %t219 = load i64, ptr %l8, !tbaa !24
  %t221 = sub i64 %t219, 1
  store i64 %t221, ptr %l8, !tbaa !24
  br label %bb20
bb37:
  %t223 = load ptr, ptr %l6, !tbaa !29
  %t225 = icmp eq ptr %t223, null
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb38, label %bb39
bb38:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t229, ptr %t230)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i1
  %l31 = alloca i64
  %l34 = alloca i64
  %l38 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1
  %t3 = trunc i64 72 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l1
  %t8 = trunc i64 74 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %t12, ptr %t13)
  store i64 %t16, ptr %l13
  br label %bb6
bb5:
  br label %bb11
bb6:
  %t17 = load i64, ptr %l13, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sge i64 %t18, 0
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %l16, !tbaa !24
  br label %bb10
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t28 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v2, ptr %t24, ptr %t25)
  store i64 %t28, ptr %l20
  br label %bb9
bb9:
  %t29 = load i64, ptr %l20, !tbaa !24
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb10
bb10:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %rv
  br label %ret
bb11:
  %t31 = load i32, ptr %l1
  %t33 = trunc i64 44 to i32
  %t34 = icmp eq i32 %t31, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load i32, ptr %l1
  %t40 = trunc i64 45 to i32
  %t41 = icmp eq i32 %t38, %t40
  %t43 = xor i1 %t41, true
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t51 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  store i64 %t51, ptr %l31
  br label %bb18
bb18:
  %t52 = load i64, ptr %l31, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = icmp sge i64 %t53, 0
  br i1 %t55, label %bb19, label %bb20
bb19:
  %t57 = load i64, ptr %l5, !tbaa !24
  store i64 %t57, ptr %l34, !tbaa !24
  br label %bb22
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v2, ptr %t59, ptr %t60)
  store i64 %t63, ptr %l38
  br label %bb21
bb21:
  %t64 = load i64, ptr %l38, !tbaa !24
  store i64 %t64, ptr %l34, !tbaa !24
  br label %bb22
bb22:
  %t65 = load i64, ptr %l34, !tbaa !24
  store i64 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echain(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca i64
  %l45 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l73 = alloca i64
  %l76 = alloca { i64, ptr }
  %l80 = alloca %"compiler/check:litv"
  %l84 = alloca i64
  %l91 = alloca i64
  %l94 = alloca i64
  %l112 = alloca i64
  %l115 = alloca { i64, ptr }
  %l118 = alloca i1
  %l122 = alloca ptr
  %l125 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l141 = alloca %"compiler/source:Span"
  %l142 = alloca ptr
  %l149 = alloca i64
  %l152 = alloca i64
  %l173 = alloca i1
  %l180 = alloca i64
  %l183 = alloca i64
  %l205 = alloca i1
  %l219 = alloca i1
  %l231 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l240 = alloca i64
  %l241 = alloca ptr
  %l246 = alloca ptr
  %l248 = alloca %"compiler/source:Span"
  %l249 = alloca ptr
  %l255 = alloca ptr
  %l257 = alloca i32
  %l260 = alloca i1
  %l261 = alloca i32
  %l264 = alloca i32
  %l269 = alloca i1
  %l270 = alloca ptr
  %l271 = alloca ptr
  %l273 = alloca ptr
  %l275 = alloca i32
  %l278 = alloca ptr
  %l280 = alloca %"compiler/source:Span"
  %l281 = alloca ptr
  %l285 = alloca i64
  %l290 = alloca ptr
  %l291 = alloca ptr
  %l293 = alloca { i64, ptr }
  %l296 = alloca %"compiler/source:Span"
  %l298 = alloca { i64, ptr }
  %l302 = alloca %"compiler/source:Span"
  %l304 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l309 = alloca %"compiler/source:Span"
  %l310 = alloca i32
  %l313 = alloca i32
  %l314 = alloca i1
  %l323 = alloca ptr
  %l324 = alloca %"compiler/source:Span"
  %l325 = alloca ptr
  %l326 = alloca i64
  %l327 = alloca { i64, ptr }
  %l329 = alloca ptr
  %l333 = alloca ptr
  %l335 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 32
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l41
  br label %bb1
bb1:
  %t6 = load i64, ptr %l41, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Chain", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %l45, !tbaa !24
  %t15 = load i64, ptr %l45, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l45, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t23, ptr %lp5
  %t25 = load ptr, ptr %lp5
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  store i64 %t26, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_514ceade83978a4d_1843f44cd2570191)
  unreachable
bb4:
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb9
bb6:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l55, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb8
bb8:
  %t54 = load i64, ptr %l55, !tbaa !24
  store i64 %t54, ptr %l52, !tbaa !24
  br label %bb9
bb9:
  %t55 = load i64, ptr %l52, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l11, !tbaa !24
  store i64 %t74, ptr %l73, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Chain", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l76, !tbaa !27
  %t80 = load i64, ptr %l11, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 %t80
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t89 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t75, ptr %t85)
  store %"compiler/check:litv" %t89, ptr %l80
  br label %bb14
bb14:
  %t90 = getelementptr %"compiler/check:litv", ptr %l80, i32 0, i32 0
  %t91 = load i1, ptr %t90, !tbaa !21
  %t93 = load ptr, ptr %lp5
  %t94 = load i64, ptr %l73, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i1, ptr %t96, i64 %t94
  store i1 %t91, ptr %t97, !tbaa !31
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l10, !tbaa !24
  br label %bb10
bb16:
  %t102 = load i64, ptr %l4, !tbaa !24
  store i64 %t102, ptr %l84, !tbaa !24
  %t103 = load i64, ptr %l84, !tbaa !24
  %t104 = icmp sge i64 %t103, 0
  br i1 %t104, label %bb17, label %bb18
bb17:
  %t106 = load i64, ptr %l84, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l4, !tbaa !24
  store i64 %t112, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t114 = load i64, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8bbd92ac148fb220_5a9ba8c1b178084)
  unreachable
bb19:
  %t120 = load i64, ptr %l15, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb24
bb21:
  %t124 = load i64, ptr %l14, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l15, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l15, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l94, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb23
bb23:
  %t140 = load i64, ptr %l94, !tbaa !24
  store i64 %t140, ptr %l91, !tbaa !24
  br label %bb24
bb24:
  %t141 = load i64, ptr %l91, !tbaa !24
  store i64 %t141, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t142 = load i64, ptr %l17, !tbaa !24
  %t143 = load i64, ptr %l16, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t150 = load i64, ptr %l13, !tbaa !24
  %t151 = load i64, ptr %l17, !tbaa !24
  %t152 = load i64, ptr %l15, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l18, !tbaa !24
  %t160 = load i64, ptr %l18, !tbaa !24
  store i64 %t160, ptr %l112, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t164 = getelementptr %"compiler/ast:Chain", ptr %t162, i32 0, i32 1
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l115, !tbaa !27
  %t166 = load i64, ptr %l18, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr ptr, ptr %t169, i64 %t166
  %t171 = load ptr, ptr %t170, !tbaa !39
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t161, ptr %t171)
  store i1 %t174, ptr %l118
  br label %bb29
bb29:
  %t175 = load i1, ptr %l118, !tbaa !21
  %t176 = load i64, ptr %l112, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i1, ptr %t178, i64 %t176
  store i1 %t175, ptr %t179, !tbaa !31
  %t180 = load i64, ptr %l18, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i1, ptr %t183, i64 %t180
  %t185 = load i1, ptr %t184, !tbaa !31
  br i1 %t185, label %bb30, label %bb31
bb30:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 32
  store ptr %t189, ptr %l122, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t194 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t190, %"compiler/source:Span" %t191)
  store ptr %t194, ptr %l125
  br label %bb32
bb31:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 32
  store ptr %t197, ptr %l127, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l128, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l2, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Chain", ptr %t200, i32 0, i32 1
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  store { i64, ptr } %t203, ptr %l131, !tbaa !27
  %t204 = load i64, ptr %l18, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr ptr, ptr %t207, i64 %t204
  %t209 = load ptr, ptr %t208, !tbaa !39
  %t211 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t199, ptr %t209, i32 %t211)
  store ptr %t215, ptr %l136
  br label %bb34
bb32:
  %t216 = load ptr, ptr %l122, !tbaa !29
  %t217 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t216, ptr %t217)
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t220 = getelementptr %"compiler/ast:Chain", ptr %t218, i32 0, i32 1
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  store { i64, ptr } %t221, ptr %l138, !tbaa !27
  %t222 = load i64, ptr %l18, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 %t222
  %t227 = load ptr, ptr %t226, !tbaa !39
  %t229 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t227)
  store %"compiler/source:Span" %t229, ptr %l141
  br label %bb35
bb35:
  %t230 = load ptr, ptr %l128, !tbaa !29
  %t231 = load ptr, ptr %l136, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l141
  %t233 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t230, ptr %t231, %"compiler/source:Span" %t232)
  store ptr %t233, ptr %l142
  br label %bb36
bb36:
  %t234 = load ptr, ptr %l127, !tbaa !29
  %t235 = load ptr, ptr %l142, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t234, ptr %t235)
  br label %bb37
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t236 = load i64, ptr %l17, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l17, !tbaa !24
  br label %bb25
bb40:
  store i64 0, ptr %l19, !tbaa !24
  %t240 = load i64, ptr %l4, !tbaa !24
  store i64 %t240, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t242 = load i64, ptr %l20, !tbaa !24
  %t243 = load i64, ptr %l19, !tbaa !24
  %t246 = icmp sgt i64 %t242, %t243
  br i1 %t246, label %bb41, label %bb42
bb41:
  %t248 = load i64, ptr %l21, !tbaa !24
  %t250 = icmp sgt i64 %t248, 0
  br i1 %t250, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb46
bb43:
  %t252 = load i64, ptr %l20, !tbaa !24
  %t253 = load i64, ptr %l19, !tbaa !24
  %t256 = sub i64 %t252, %t253
  %t257 = load i64, ptr %l21, !tbaa !24
  %t260 = add i64 %t256, %t257
  %t262 = sub i64 %t260, 1
  %t263 = load i64, ptr %l21, !tbaa !24
  %t266 = sdiv i64 %t262, %t263
  store i64 %t266, ptr %l152, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb45
bb45:
  %t268 = load i64, ptr %l152, !tbaa !24
  store i64 %t268, ptr %l149, !tbaa !24
  br label %bb46
bb46:
  %t269 = load i64, ptr %l149, !tbaa !24
  store i64 %t269, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t270 = load i64, ptr %l23, !tbaa !24
  %t271 = load i64, ptr %l22, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb116
bb49:
  br label %bb50
bb50:
  %t278 = load i64, ptr %l19, !tbaa !24
  %t279 = load i64, ptr %l23, !tbaa !24
  %t280 = load i64, ptr %l21, !tbaa !24
  %t283 = mul i64 %t279, %t280
  %t286 = add i64 %t278, %t283
  store i64 %t286, ptr %l24, !tbaa !24
  %t288 = load i64, ptr %l24, !tbaa !24
  %t290 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr i1, ptr %t291, i64 %t288
  %t293 = load i1, ptr %t292, !tbaa !31
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb53
bb52:
  %t297 = load i64, ptr %l24, !tbaa !24
  %t298 = load ptr, ptr %lp5
  %t300 = getelementptr { i64, ptr }, ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr i1, ptr %t301, i64 %t297
  %t303 = load i1, ptr %t302, !tbaa !31
  store i1 %t303, ptr %l173, !tbaa !21
  br label %bb53
bb53:
  %t305 = load i1, ptr %l173, !tbaa !21
  br i1 %t305, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb55:
  br label %bb56
bb56:
  store i64 -1, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t306 = load i64, ptr %l4, !tbaa !24
  store i64 %t306, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t308 = load i64, ptr %l27, !tbaa !24
  %t309 = load i64, ptr %l26, !tbaa !24
  %t312 = icmp sgt i64 %t308, %t309
  br i1 %t312, label %bb57, label %bb58
bb57:
  %t314 = load i64, ptr %l28, !tbaa !24
  %t316 = icmp sgt i64 %t314, 0
  br i1 %t316, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb62
bb59:
  %t318 = load i64, ptr %l27, !tbaa !24
  %t319 = load i64, ptr %l26, !tbaa !24
  %t322 = sub i64 %t318, %t319
  %t323 = load i64, ptr %l28, !tbaa !24
  %t326 = add i64 %t322, %t323
  %t328 = sub i64 %t326, 1
  %t329 = load i64, ptr %l28, !tbaa !24
  %t332 = sdiv i64 %t328, %t329
  store i64 %t332, ptr %l183, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb61
bb61:
  %t334 = load i64, ptr %l183, !tbaa !24
  store i64 %t334, ptr %l180, !tbaa !24
  br label %bb62
bb62:
  %t335 = load i64, ptr %l180, !tbaa !24
  store i64 %t335, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s13
  %t336 = load i64, ptr %l30, !tbaa !24
  %t337 = load i64, ptr %l29, !tbaa !24
  %t340 = icmp slt i64 %t336, %t337
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s13)
  br label %bb80
bb65:
  br label %bb66
bb66:
  %t344 = load i64, ptr %l26, !tbaa !24
  %t345 = load i64, ptr %l30, !tbaa !24
  %t346 = load i64, ptr %l28, !tbaa !24
  %t349 = mul i64 %t345, %t346
  %t352 = add i64 %t344, %t349
  store i64 %t352, ptr %l31, !tbaa !24
  %t354 = load i64, ptr %l24, !tbaa !24
  %t355 = load i64, ptr %l31, !tbaa !24
  %t358 = sub i64 %t354, %t355
  %t360 = icmp sge i64 %t358, 0
  br i1 %t360, label %bb67, label %bb68
bb67:
  %t362 = load i64, ptr %l24, !tbaa !24
  %t363 = load i64, ptr %l31, !tbaa !24
  %t366 = sub i64 %t362, %t363
  %t368 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr i1, ptr %t369, i64 %t366
  %t371 = load i1, ptr %t370, !tbaa !31
  %t373 = xor i1 %t371, true
  store i1 %t373, ptr %l205, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb69
bb69:
  %t375 = load i1, ptr %l205, !tbaa !21
  br i1 %t375, label %bb70, label %bb71
bb70:
  %t376 = load i64, ptr %l24, !tbaa !24
  %t377 = load i64, ptr %l31, !tbaa !24
  %t380 = sub i64 %t376, %t377
  store i64 %t380, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb80
bb71:
  br label %bb72
bb72:
  %t382 = load i64, ptr %l24, !tbaa !24
  %t383 = load i64, ptr %l31, !tbaa !24
  %t386 = add i64 %t382, %t383
  %t387 = load i64, ptr %l4, !tbaa !24
  %t390 = icmp slt i64 %t386, %t387
  br i1 %t390, label %bb73, label %bb74
bb73:
  %t392 = load i64, ptr %l24, !tbaa !24
  %t393 = load i64, ptr %l31, !tbaa !24
  %t396 = add i64 %t392, %t393
  %t398 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i1, ptr %t399, i64 %t396
  %t401 = load i1, ptr %t400, !tbaa !31
  %t403 = xor i1 %t401, true
  store i1 %t403, ptr %l219, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb75
bb75:
  %t405 = load i1, ptr %l219, !tbaa !21
  br i1 %t405, label %bb76, label %bb77
bb76:
  %t406 = load i64, ptr %l24, !tbaa !24
  %t407 = load i64, ptr %l31, !tbaa !24
  %t410 = add i64 %t406, %t407
  store i64 %t410, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb80
bb77:
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb79:
  %t412 = load i64, ptr %l30, !tbaa !24
  %t414 = add i64 %t412, 1
  store i64 %t414, ptr %l30, !tbaa !24
  br label %bb63
bb80:
  %t416 = load ptr, ptr %l2, !tbaa !29
  %t418 = getelementptr %"compiler/ast:Chain", ptr %t416, i32 0, i32 1
  %t419 = load { i64, ptr }, ptr %t418, !tbaa !27
  store { i64, ptr } %t419, ptr %l231, !tbaa !27
  %t420 = load i64, ptr %l24, !tbaa !24
  %t422 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr ptr, ptr %t423, i64 %t420
  %t425 = load ptr, ptr %t424, !tbaa !39
  store ptr %t425, ptr %l32, !tbaa !29
  %t427 = load i64, ptr %l25, !tbaa !24
  %t429 = icmp slt i64 %t427, 0
  br i1 %t429, label %bb81, label %bb82
bb81:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/check:Checker", ptr %t431, i32 0, i32 32
  store ptr %t433, ptr %l237, !tbaa !29
  %t434 = load i64, ptr %l3, !tbaa !24
  %t435 = load i64, ptr %l24, !tbaa !24
  %t438 = add i64 %t434, %t435
  store i64 %t438, ptr %l240, !tbaa !24
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l241, !tbaa !29
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load ptr, ptr %l32, !tbaa !29
  %t443 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t447 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t440, ptr %t441, i32 %t443)
  store ptr %t447, ptr %l246
  br label %bb83
bb82:
  br label %bb87
bb83:
  %t448 = load ptr, ptr %l32, !tbaa !29
  %t450 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t448)
  store %"compiler/source:Span" %t450, ptr %l248
  br label %bb84
bb84:
  %t451 = load ptr, ptr %l241, !tbaa !29
  %t452 = load ptr, ptr %l246, !tbaa !29
  %t453 = load %"compiler/source:Span", ptr %l248
  %t454 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t451, ptr %t452, %"compiler/source:Span" %t453)
  store ptr %t454, ptr %l249
  br label %bb85
bb85:
  %t455 = load ptr, ptr %l237, !tbaa !29
  %t456 = load i64, ptr %l240, !tbaa !24
  %t457 = load ptr, ptr %l249, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eSet_H7eb7f72699477ff6ed0f03fe599574de(ptr %v0, ptr %v0, ptr %t455, i64 %t456, ptr %t457)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb87:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/check:Checker", ptr %t458, i32 0, i32 32
  %t461 = load i64, ptr %l3, !tbaa !24
  %t462 = load i64, ptr %l25, !tbaa !24
  %t465 = add i64 %t461, %t462
  %t468 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s10, ptr %t460, i64 %t465)
  store ptr %t468, ptr %l255
  br label %bb88
bb88:
  %t469 = load ptr, ptr %l255, !tbaa !29
  %t471 = call i32 @compiler_2fcheck_2etypeOf(ptr %s10, ptr %t469)
  store i32 %t471, ptr %l257
  br label %bb89
bb89:
  %t472 = load i32, ptr %l257, !tbaa !23
  store i32 %t472, ptr %l33, !tbaa !23
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load i32, ptr %l33, !tbaa !23
  %t477 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t473, i32 %t474)
  store i1 %t477, ptr %l260
  br label %bb90
bb90:
  %t478 = load i1, ptr %l260, !tbaa !21
  br i1 %t478, label %bb91, label %bb92
bb91:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load i32, ptr %l33, !tbaa !23
  %t483 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t479, i32 %t480)
  store i32 %t483, ptr %l264
  br label %bb93
bb92:
  %t484 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t484, ptr %l261, !tbaa !23
  br label %bb94
bb93:
  %t486 = load i32, ptr %l264, !tbaa !23
  store i32 %t486, ptr %l261, !tbaa !23
  br label %bb94
bb94:
  %t487 = load i32, ptr %l261, !tbaa !23
  store i32 %t487, ptr %l34, !tbaa !23
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l32, !tbaa !29
  %t490 = load i32, ptr %l34, !tbaa !23
  %t494 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t488, ptr %t489, i32 %t490)
  store i1 %t494, ptr %l269
  br label %bb95
bb95:
  %t495 = load i1, ptr %l269, !tbaa !21
  store i1 %t495, ptr %l35, !tbaa !21
  %t496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t496, ptr %l270, !tbaa !29
  %t497 = load ptr, ptr %l0, !tbaa !29
  store ptr %t497, ptr %l271, !tbaa !29
  %t498 = load ptr, ptr %l32, !tbaa !29
  store ptr %t498, ptr %l273, !tbaa !29
  %t500 = load i1, ptr %l35, !tbaa !21
  br i1 %t500, label %bb96, label %bb97
bb96:
  %t502 = load i32, ptr %l34, !tbaa !23
  store i32 %t502, ptr %l275, !tbaa !23
  br label %bb98
bb97:
  %t504 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t504, ptr %l275, !tbaa !23
  br label %bb98
bb98:
  %t506 = load ptr, ptr %l271, !tbaa !29
  %t507 = load ptr, ptr %l273, !tbaa !29
  %t508 = load i32, ptr %l275, !tbaa !23
  %t509 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t506, ptr %t507, i32 %t508)
  store ptr %t509, ptr %l278
  br label %bb99
bb99:
  %t510 = load ptr, ptr %l32, !tbaa !29
  %t512 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t510)
  store %"compiler/source:Span" %t512, ptr %l280
  br label %bb100
bb100:
  %t513 = load ptr, ptr %l270, !tbaa !29
  %t514 = load ptr, ptr %l278, !tbaa !29
  %t515 = load %"compiler/source:Span", ptr %l280
  %t516 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t513, ptr %t514, %"compiler/source:Span" %t515)
  store ptr %t516, ptr %l281
  br label %bb101
bb101:
  %t517 = load ptr, ptr %l281, !tbaa !29
  store ptr %t517, ptr %l36, !tbaa !29
  %t518 = load i64, ptr %l24, !tbaa !24
  %t519 = load i64, ptr %l25, !tbaa !24
  %t522 = icmp slt i64 %t518, %t519
  br i1 %t522, label %bb102, label %bb103
bb102:
  %t524 = load i64, ptr %l24, !tbaa !24
  store i64 %t524, ptr %l285, !tbaa !24
  br label %bb104
bb103:
  %t526 = load i64, ptr %l25, !tbaa !24
  store i64 %t526, ptr %l285, !tbaa !24
  br label %bb104
bb104:
  %t528 = load i64, ptr %l285, !tbaa !24
  store i64 %t528, ptr %l37, !tbaa !24
  %t529 = load i1, ptr %l35, !tbaa !21
  %t531 = xor i1 %t529, true
  br i1 %t531, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s18
  %t533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t533, ptr %l290, !tbaa !29
  %t534 = load ptr, ptr %l0, !tbaa !29
  store ptr %t534, ptr %l291, !tbaa !29
  %t535 = load ptr, ptr %l2, !tbaa !29
  %t537 = getelementptr %"compiler/ast:Chain", ptr %t535, i32 0, i32 1
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  store { i64, ptr } %t538, ptr %l293, !tbaa !27
  %t539 = load i64, ptr %l37, !tbaa !24
  %t541 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr ptr, ptr %t542, i64 %t539
  %t544 = load ptr, ptr %t543, !tbaa !39
  %t546 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t544)
  store %"compiler/source:Span" %t546, ptr %l296
  br label %bb107
bb106:
  br label %bb113
bb107:
  %t547 = load ptr, ptr %l2, !tbaa !29
  %t549 = getelementptr %"compiler/ast:Chain", ptr %t547, i32 0, i32 1
  %t550 = load { i64, ptr }, ptr %t549, !tbaa !27
  store { i64, ptr } %t550, ptr %l298, !tbaa !27
  %t551 = load i64, ptr %l37, !tbaa !24
  %t553 = add i64 %t551, 1
  %t555 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr ptr, ptr %t556, i64 %t553
  %t558 = load ptr, ptr %t557, !tbaa !39
  %t560 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t558)
  store %"compiler/source:Span" %t560, ptr %l302
  br label %bb108
bb108:
  %t561 = load ptr, ptr %l2, !tbaa !29
  %t563 = getelementptr %"compiler/ast:Chain", ptr %t561, i32 0, i32 0
  %t564 = load { i64, ptr }, ptr %t563, !tbaa !27
  store { i64, ptr } %t564, ptr %l304, !tbaa !27
  %t565 = load i64, ptr %l37, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr i32, ptr %t568, i64 %t565
  %t570 = load i32, ptr %t569
  %t572 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s18, i32 %t570)
  store { i64, ptr } %t572, ptr %l307
  br label %bb109
bb109:
  %t573 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t573, 0
  %t575 = load ptr, ptr %l291, !tbaa !29
  %t576 = load %"compiler/source:Span", ptr %l296
  %t577 = load %"compiler/source:Span", ptr %l302
  %t579 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t575, %"compiler/source:Span" %t576, %"compiler/source:Span" %t577, i64 %t574)
  store %"compiler/source:Span" %t579, ptr %l309
  br label %bb110
bb110:
  %t580 = load i32, ptr %l33, !tbaa !23
  store i32 %t580, ptr %l310, !tbaa !23
  %t581 = load ptr, ptr %l36, !tbaa !29
  %t584 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t581)
  store i32 %t584, ptr %l313
  br label %bb111
bb111:
  %t585 = load ptr, ptr %l290, !tbaa !29
  %t586 = load %"compiler/source:Span", ptr %l309
  %t587 = load i32, ptr %l310, !tbaa !23
  %t588 = load i32, ptr %l313, !tbaa !23
  %t589 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t585, %"compiler/source:Span" %t586, i32 %t587, i32 %t588)
  store i1 %t589, ptr %l314
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s18)
  br label %bb113
bb113:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t592 = getelementptr %"compiler/check:Checker", ptr %t590, i32 0, i32 32
  %t593 = load i64, ptr %l3, !tbaa !24
  %t594 = load i64, ptr %l24, !tbaa !24
  %t597 = add i64 %t593, %t594
  %t598 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eSet_H7eb7f72699477ff6ed0f03fe599574de(ptr %v0, ptr %v0, ptr %t592, i64 %t597, ptr %t598)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb115:
  %t602 = load i64, ptr %l23, !tbaa !24
  %t604 = add i64 %t602, 1
  store i64 %t604, ptr %l23, !tbaa !24
  br label %bb47
bb116:
  %t606 = load ptr, ptr %l0, !tbaa !29
  store ptr %t606, ptr %l323, !tbaa !29
  %t607 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t607, ptr %l324
  %t608 = load ptr, ptr %l2, !tbaa !29
  store ptr %t608, ptr %l325, !tbaa !29
  %t609 = load i64, ptr %l3, !tbaa !24
  store i64 %t609, ptr %l326, !tbaa !24
  %t610 = load ptr, ptr %lp5
  %t611 = load { i64, ptr }, ptr %t610, !tbaa !27
  store { i64, ptr } %t611, ptr %l327, !tbaa !27
  %t612 = load ptr, ptr %lp5
  %t613 = getelementptr { i64, ptr }, ptr %t612, i32 0, i32 1
  %t614 = load ptr, ptr %t613, !tbaa !27
  %t615 = getelementptr i1, ptr %t614, i64 0
  %t616 = load i1, ptr %t615, !tbaa !31
  br i1 %t616, label %bb117, label %bb118
bb117:
  store ptr null, ptr %l329, !tbaa !29
  br label %bb120
bb118:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/check:Checker", ptr %t618, i32 0, i32 32
  %t621 = load i64, ptr %l3, !tbaa !24
  %t624 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t620, i64 %t621)
  store ptr %t624, ptr %l333
  br label %bb119
bb119:
  %t625 = load ptr, ptr %l333, !tbaa !29
  store ptr %t625, ptr %l329, !tbaa !29
  br label %bb120
bb120:
  %t627 = load ptr, ptr %l323, !tbaa !29
  %t628 = load %"compiler/source:Span", ptr %l324
  %t629 = load ptr, ptr %l325, !tbaa !29
  %t630 = load i64, ptr %l326, !tbaa !24
  %t631 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t632 = load ptr, ptr %l329, !tbaa !29
  %t633 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v0, ptr %t627, %"compiler/source:Span" %t628, ptr %t629, i64 %t630, { i64, ptr } %t631, i64 0, ptr %t632)
  store ptr %t633, ptr %l335
  br label %bb121
bb121:
  %t634 = load ptr, ptr %l335, !tbaa !29
  store ptr %t634, ptr %l38, !tbaa !29
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/check:Checker", ptr %t635, i32 0, i32 32
  %t638 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eTru_H381e973120335535f017a290d5069d76(ptr %v0, ptr %t637, i64 %t638)
  br label %bb122
bb122:
  %t641 = load ptr, ptr %l38, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t641, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckGlobal(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca %"compiler/generic:Context"
  %l37 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l57 = alloca %"compiler/typed:Block"
  %l66 = alloca i64
  %l69 = alloca i64
  %l88 = alloca { i64, ptr }
  %l104 = alloca i32
  %l109 = alloca ptr
  %l111 = alloca %"compiler/generic:Context"
  %l115 = alloca i32
  %l118 = alloca i64
  %l126 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l141 = alloca i32
  %l146 = alloca i1
  %l147 = alloca i1
  %l155 = alloca ptr
  %l163 = alloca i1
  %l164 = alloca i1
  %l167 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca ptr
  %l172 = alloca { i64, ptr }
  %l175 = alloca %"compiler/source:Span"
  %l177 = alloca i1
  %l182 = alloca i1
  %l192 = alloca ptr
  %l205 = alloca i32
  %l207 = alloca i32
  %l209 = alloca i1
  %l210 = alloca ptr
  %l214 = alloca i32
  %l215 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca %"compiler/source:Span"
  %l218 = alloca %"compiler/source:Span"
  %l219 = alloca i32
  %l225 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca %"compiler/source:Span"
  %l235 = alloca ptr
  %l242 = alloca ptr
  %l243 = alloca ptr
  %l247 = alloca { i64, ptr }
  %l248 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t417 = alloca { i64, [4 x i64] }, align 8
  %t443 = alloca { i64, [4 x i64] }, align 8
  %t462 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i32, ptr %l3, !tbaa !23
  %t10 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t4, i64 %t5, i32 %t6)
  store ptr %t10, ptr %l23
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l23, !tbaa !29
  store ptr %t11, ptr %l4, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load i32, ptr %l3, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t18 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t12, i64 %t15)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t18, ptr %l27
  br label %bb2
bb2:
  %t19 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l27
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t19, ptr %l5
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t20, i64 %a1, i64 %t22, i32 %t23, i32 0)
  store ptr %t28, ptr %l32
  br label %bb3
bb3:
  %t29 = load ptr, ptr %l32, !tbaa !29
  store ptr %t29, ptr %l33, !tbaa !29
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %t31, i64 -1)
  store %"compiler/generic:Context" %t33, ptr %l35
  br label %bb4
bb4:
  %t34 = load %"compiler/generic:Context", ptr %l35
  %t35 = load ptr, ptr %l33, !tbaa !29
  %t36 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 4
  store %"compiler/generic:Context" %t34, ptr %t36
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t37)
  store ptr %t39, ptr %l37
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l37, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Body", ptr %t40, i32 0, i32 4
  %t43 = load %"compiler/source:Span", ptr %t42
  store %"compiler/source:Span" %t43, ptr %l7
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t45)
  store ptr %t47, ptr %l41
  br label %bb6
bb6:
  %t48 = load %"compiler/source:Span", ptr %l7
  %t49 = load ptr, ptr %l41, !tbaa !29
  %t52 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t49, i32 -1, i32 0, %"compiler/source:Span" %t48)
  store i32 %t52, ptr %l44
  br label %bb7
bb7:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb8, label %bb9
bb8:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 24
  %t60 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H66d61cdd994b442644a8ee2ce6a8bf73(ptr %v0, ptr %t59, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t60, i32 %t61)
  br label %bb10
bb9:
  br label %bb18
bb10:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t65)
  store ptr %t67, ptr %l52
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l52, !tbaa !29
  store ptr %t68, ptr %l53, !tbaa !29
  %t69 = icmp sge i64 0, 0
  br i1 %t69, label %bb12, label %bb13
bb12:
  %t71 = icmp sle i64 0, 1152921504606846975
  br i1 %t71, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_27b76e5e144937_92b9984f1a7672bb)
  unreachable
bb14:
  %t73 = mul i64 0, 8
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 0, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t78 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t76)
  store %"compiler/typed:Block" %t78, ptr %l57
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_27b76e5e144937_92b9984f1a7672bb)
  unreachable
bb16:
  %t79 = load %"compiler/typed:Block", ptr %l57
  %t80 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t79, ptr %t80
  %t82 = load ptr, ptr %l53, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Body", ptr %t82, i32 0, i32 11
  store ptr %t80, ptr %t83, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t84)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/ast:VarDecl", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb19, label %bb20
bb19:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb24
bb21:
  %t103 = load i64, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l11, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l69, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l69, !tbaa !24
  store i64 %t119, ptr %l66, !tbaa !24
  br label %bb24
bb24:
  %t120 = load i64, ptr %l66, !tbaa !24
  store i64 %t120, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t121 = load i64, ptr %l13, !tbaa !24
  %t122 = load i64, ptr %l12, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb27:
  br label %bb28
bb28:
  %t129 = load i64, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l13, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = mul i64 %t130, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l14, !tbaa !24
  %t139 = load ptr, ptr %l4, !tbaa !29
  %t141 = getelementptr %"compiler/ast:VarDecl", ptr %t139, i32 0, i32 0
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l88, !tbaa !27
  %t143 = load i64, ptr %l14, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i32, ptr %t146, i64 %t143
  %t148 = load i32, ptr %t147, !tbaa !33
  %t149 = load i32, ptr %l3, !tbaa !23
  %t152 = icmp eq i32 %t148, %t149
  br i1 %t152, label %bb29, label %bb30
bb29:
  %t154 = load i64, ptr %l14, !tbaa !24
  store i64 %t154, ptr %l8, !tbaa !24
  br label %bb31
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  %t156 = load i64, ptr %l13, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l13, !tbaa !24
  br label %bb25
bb33:
  %t160 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t160, ptr %l15, !tbaa !23
  %t162 = load ptr, ptr %l4, !tbaa !29
  %t164 = getelementptr %"compiler/ast:VarDecl", ptr %t162, i32 0, i32 2
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = icmp eq ptr %t165, null
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb34, label %bb35
bb34:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l4, !tbaa !29
  %t174 = getelementptr %"compiler/ast:VarDecl", ptr %t172, i32 0, i32 2
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t178 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v0, ptr %t171, ptr %t175)
  store i32 %t178, ptr %l104
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t179 = load i32, ptr %l104, !tbaa !23
  store i32 %t179, ptr %l15, !tbaa !23
  %t180 = load i32, ptr %l15, !tbaa !23
  %t181 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t184 = icmp ne i32 %t180, %t181
  br i1 %t184, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !29
  store ptr %t189, ptr %l109, !tbaa !29
  %t190 = load i64, ptr %l2, !tbaa !24
  %t192 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %s7, i64 %t190, i64 -1)
  store %"compiler/generic:Context" %t192, ptr %l111
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t193 = load %"compiler/generic:Context", ptr %l111
  %t194 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 24, i64 8)
  store %"compiler/generic:Context" %t193, ptr %t194
  %t195 = load ptr, ptr %l4, !tbaa !29
  %t196 = load i32, ptr %l3, !tbaa !23
  %t197 = load ptr, ptr %l109, !tbaa !29
  %t201 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %s7, ptr %v0, ptr %t197, ptr %t194, ptr %t195, i32 %t196)
  store i32 %t201, ptr %l115
  br label %bb40
bb40:
  %t202 = load i32, ptr %l115, !tbaa !23
  store i32 %t202, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 33
  %t207 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t205)
  store i64 %t207, ptr %l118
  br label %bb43
bb43:
  %t208 = load i64, ptr %l118, !tbaa !24
  store i64 %t208, ptr %l16, !tbaa !24
  store ptr null, ptr %l17, !tbaa !29
  %t209 = load i64, ptr %l8, !tbaa !24
  %t210 = load ptr, ptr %l4, !tbaa !29
  %t212 = getelementptr %"compiler/ast:VarDecl", ptr %t210, i32 0, i32 3
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t218 = icmp slt i64 %t209, %t215
  br i1 %t218, label %bb44, label %bb45
bb44:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l4, !tbaa !29
  %t223 = getelementptr %"compiler/ast:VarDecl", ptr %t221, i32 0, i32 3
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  store { i64, ptr } %t224, ptr %l126, !tbaa !27
  %t225 = load i64, ptr %l8, !tbaa !24
  %t227 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr ptr, ptr %t228, i64 %t225
  %t230 = load ptr, ptr %t229, !tbaa !39
  %t231 = load i32, ptr %l15, !tbaa !23
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v0, ptr %t220, ptr %t230, i32 %t231)
  store ptr %t235, ptr %l130
  br label %bb46
bb45:
  %t236 = load ptr, ptr %l4, !tbaa !29
  %t238 = getelementptr %"compiler/ast:VarDecl", ptr %t236, i32 0, i32 3
  %t239 = load { i64, ptr }, ptr %t238, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t243 = icmp eq i64 %t241, 1
  br i1 %t243, label %bb72, label %bb73
bb46:
  %t245 = load ptr, ptr %l130, !tbaa !29
  store ptr %t245, ptr %l17, !tbaa !29
  %t247 = load ptr, ptr %l4, !tbaa !29
  %t249 = getelementptr %"compiler/ast:VarDecl", ptr %t247, i32 0, i32 2
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = icmp eq ptr %t250, null
  br i1 %t252, label %bb47, label %bb48
bb47:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l4, !tbaa !29
  %t257 = getelementptr %"compiler/ast:VarDecl", ptr %t255, i32 0, i32 3
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  store { i64, ptr } %t258, ptr %l137, !tbaa !27
  %t259 = load i64, ptr %l8, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr ptr, ptr %t262, i64 %t259
  %t264 = load ptr, ptr %t263, !tbaa !39
  %t265 = load ptr, ptr %l17, !tbaa !29
  %t269 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v0, ptr %v0, ptr %t254, ptr %t264, ptr %t265, i1 true)
  store i32 %t269, ptr %l141
  br label %bb49
bb48:
  br label %bb50
bb49:
  %t270 = load i32, ptr %l141, !tbaa !23
  store i32 %t270, ptr %l15, !tbaa !23
  br label %bb50
bb50:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load i64, ptr %l2, !tbaa !24
  %t273 = load i32, ptr %l3, !tbaa !23
  %t274 = load ptr, ptr %l4, !tbaa !29
  %t279 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildDefaulted(ptr %v0, ptr %v0, ptr %t271, i64 %t272, i32 %t273, ptr %t274)
  store i1 %t279, ptr %l146
  br label %bb51
bb51:
  %t280 = load i1, ptr %l146, !tbaa !21
  br i1 %t280, label %bb52, label %bb53
bb52:
  %t281 = load i32, ptr %l15, !tbaa !23
  %t282 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t285 = icmp ne i32 %t281, %t282
  store i1 %t285, ptr %l147, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb54
bb54:
  %t287 = load i1, ptr %l147, !tbaa !21
  br i1 %t287, label %bb55, label %bb56
bb55:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load %"compiler/source:Span", ptr %l7
  %t290 = load i32, ptr %l3, !tbaa !23
  %t291 = load i32, ptr %l15, !tbaa !23
  %t296 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefineValue(ptr %v0, ptr %t288, %"compiler/source:Span" %t289, i32 %t290, i32 %t291)
  store ptr %t296, ptr %l155
  br label %bb57
bb56:
  br label %bb61
bb57:
  %t297 = load ptr, ptr %l155, !tbaa !29
  store ptr %t297, ptr %l18, !tbaa !29
  %t298 = load ptr, ptr %l18, !tbaa !29
  %t300 = icmp eq ptr %t298, null
  %t302 = xor i1 %t300, true
  br i1 %t302, label %bb58, label %bb59
bb58:
  %t304 = load ptr, ptr %l18, !tbaa !29
  store ptr %t304, ptr %l17, !tbaa !29
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t307 = load ptr, ptr %l4, !tbaa !29
  %t309 = getelementptr %"compiler/ast:VarDecl", ptr %t307, i32 0, i32 2
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t312 = call i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %t310)
  store i1 %t312, ptr %l163
  br label %bb62
bb62:
  %t313 = load i1, ptr %l163, !tbaa !21
  br i1 %t313, label %bb63, label %bb64
bb63:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load i32, ptr %l15, !tbaa !23
  %t318 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t314, i32 %t315)
  store i1 %t318, ptr %l167
  br label %bb65
bb64:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb66
bb65:
  %t319 = load i1, ptr %l167, !tbaa !21
  %t320 = xor i1 %t319, true
  store i1 %t320, ptr %l164, !tbaa !21
  br label %bb66
bb66:
  %t322 = load i1, ptr %l164, !tbaa !21
  br i1 %t322, label %bb67, label %bb68
bb67:
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l169, !tbaa !29
  %t324 = load ptr, ptr %l17, !tbaa !29
  store ptr %t324, ptr %l170, !tbaa !29
  %t325 = load ptr, ptr %l4, !tbaa !29
  %t327 = getelementptr %"compiler/ast:VarDecl", ptr %t325, i32 0, i32 3
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  store { i64, ptr } %t328, ptr %l172, !tbaa !27
  %t329 = load i64, ptr %l8, !tbaa !24
  %t331 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr ptr, ptr %t332, i64 %t329
  %t334 = load ptr, ptr %t333, !tbaa !39
  %t336 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t334)
  store %"compiler/source:Span" %t336, ptr %l175
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t337 = load i64, ptr @G_2ecompiler_2fcheck_2eRoGlobal, !tbaa !24
  %t338 = load ptr, ptr %l169, !tbaa !29
  %t339 = load ptr, ptr %l170, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l175
  %t342 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t338, ptr %t339, %"compiler/source:Span" %t340, i64 %t337)
  store i1 %t342, ptr %l177
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb81
bb72:
  %t343 = load ptr, ptr %l4, !tbaa !29
  %t345 = getelementptr %"compiler/ast:VarDecl", ptr %t343, i32 0, i32 0
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t350 = icmp sgt i64 %t348, 1
  store i1 %t350, ptr %l182, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb74
bb74:
  %t352 = load i1, ptr %l182, !tbaa !21
  br i1 %t352, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s14
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s14, ptr %t353, %"compiler/source:Span" %t354, { i64, ptr } { i64 37, ptr @.d8 })
  br label %bb77
bb76:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l7
  %t359 = load i32, ptr %l15, !tbaa !23
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %t357, %"compiler/source:Span" %t358, i32 %t359)
  store ptr %t363, ptr %l192
  br label %bb78
bb77:
  call void @__olang_scope_close(ptr %s14)
  br label %bb80
bb78:
  %t364 = load ptr, ptr %l192, !tbaa !29
  store ptr %t364, ptr %l17, !tbaa !29
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load %"compiler/source:Span", ptr %l7
  %t368 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v0, ptr %t366, i32 1, %"compiler/source:Span" %t367, i32 %t368, ptr null)
  br label %bb79
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/check:Checker", ptr %t373, i32 0, i32 24
  %t376 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t377 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H66d61cdd994b442644a8ee2ce6a8bf73(ptr %v0, ptr %t375, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t376, i32 %t377)
  br label %bb82
bb82:
  %t381 = load ptr, ptr %l17, !tbaa !29
  %t383 = icmp eq ptr %t381, null
  %t385 = xor i1 %t383, true
  br i1 %t385, label %bb83, label %bb84
bb83:
  %t387 = load i32, ptr %l15, !tbaa !23
  store i32 %t387, ptr %l205, !tbaa !23
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t388)
  store i32 %t390, ptr %l207
  br label %bb85
bb84:
  br label %bb105
bb85:
  %t391 = load i32, ptr %l205, !tbaa !23
  %t392 = load i32, ptr %l207, !tbaa !23
  %t393 = icmp eq i32 %t391, %t392
  br i1 %t393, label %bb86, label %bb87
bb86:
  %t395 = load ptr, ptr %l0, !tbaa !29
  store ptr %t395, ptr %l210, !tbaa !29
  %t396 = load ptr, ptr %l17, !tbaa !29
  %t398 = icmp eq ptr %t396, null
  br i1 %t398, label %bb88, label %bb89
bb87:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb93
bb88:
  call void @__olang_check_failed(ptr @olang_loc_6495b6dfee4ecee2_6e1c2cfd4a22a64e)
  unreachable
bb89:
  br label %bb90
bb90:
  %t400 = load ptr, ptr %l17, !tbaa !29
  %t402 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t400)
  store i32 %t402, ptr %l214
  br label %bb91
bb91:
  %t403 = load ptr, ptr %l210, !tbaa !29
  %t404 = load i32, ptr %l214, !tbaa !23
  %t405 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t403, i32 %t404)
  store i1 %t405, ptr %l215
  br label %bb92
bb92:
  %t406 = load i1, ptr %l215, !tbaa !21
  store i1 %t406, ptr %l209, !tbaa !21
  br label %bb93
bb93:
  %t407 = load i1, ptr %l209, !tbaa !21
  br i1 %t407, label %bb94, label %bb95
bb94:
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l216, !tbaa !29
  %t409 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t409, ptr %l217
  %t410 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t410, ptr %l218
  %t411 = load i32, ptr %l15, !tbaa !23
  store i32 %t411, ptr %l219, !tbaa !23
  %t412 = load ptr, ptr %l17, !tbaa !29
  %t414 = icmp eq ptr %t412, null
  br i1 %t414, label %bb96, label %bb97
bb95:
  br label %bb100
bb96:
  call void @__olang_check_failed(ptr @olang_loc_6495b6dfee4ecee2_6e1c2cfd4a22a64e)
  unreachable
bb97:
  br label %bb98
bb98:
  %t416 = load ptr, ptr %l17, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t417
  %t418 = getelementptr { i64, [4 x i64] }, ptr %t417, i32 0, i32 0
  store i64 2, ptr %t418
  %t419 = load %"compiler/source:Span", ptr %l218
  %t420 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t419, 0
  %t421 = load i32, ptr %l219, !tbaa !23
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr } %t420, i32 %t421, 1
  %t424 = insertvalue { %"compiler/source:Span", i32, ptr } %t422, ptr %t416, 2
  %t425 = getelementptr { i64, [4 x i64] }, ptr %t417, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t424, ptr %t425
  %t426 = load { i64, [4 x i64] }, ptr %t417
  %t428 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t426, ptr %t428
  %t429 = load ptr, ptr %l216, !tbaa !29
  %t430 = load %"compiler/source:Span", ptr %l217
  %t432 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t429, %"compiler/source:Span" %t430, ptr %t428)
  store ptr %t432, ptr %l225
  br label %bb99
bb99:
  %t433 = load ptr, ptr %l225, !tbaa !29
  store ptr %t433, ptr %l17, !tbaa !29
  br label %bb100
bb100:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/check:Checker", ptr %t435, i32 0, i32 33
  store ptr %t437, ptr %l228, !tbaa !29
  %t438 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t438, ptr %l229
  %t439 = load %"compiler/source:Span", ptr %l7
  %t440 = load i32, ptr %l15, !tbaa !23
  %t441 = load i64, ptr %l2, !tbaa !24
  %t442 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t443
  %t444 = getelementptr { i64, [4 x i64] }, ptr %t443, i32 0, i32 0
  store i64 1, ptr %t444
  %t446 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t439, 0
  %t448 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t446, i32 %t440, 1
  %t450 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t448, i64 %t441, 2
  %t452 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t450, i32 %t442, 3
  %t453 = getelementptr { i64, [4 x i64] }, ptr %t443, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t452, ptr %t453
  %t454 = load { i64, [4 x i64] }, ptr %t443
  %t456 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t454, ptr %t456
  store ptr %t456, ptr %l235, !tbaa !29
  %t457 = load ptr, ptr %l17, !tbaa !29
  %t459 = icmp eq ptr %t457, null
  br i1 %t459, label %bb101, label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_8d548c3c72e36863_6a32d0416bf96aff)
  unreachable
bb102:
  br label %bb103
bb103:
  %t461 = load ptr, ptr %l17, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [3 x i64] }, ptr %t462, i32 0, i32 0
  store i64 1, ptr %t463
  %t464 = load %"compiler/source:Span", ptr %l229
  %t465 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t464, 0
  %t466 = load ptr, ptr %l235, !tbaa !29
  %t467 = insertvalue { %"compiler/source:Span", ptr, ptr } %t465, ptr %t466, 1
  %t469 = insertvalue { %"compiler/source:Span", ptr, ptr } %t467, ptr %t461, 2
  %t470 = getelementptr { i64, [3 x i64] }, ptr %t462, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t469, ptr %t470
  %t471 = load { i64, [3 x i64] }, ptr %t462
  %t473 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t471, ptr %t473
  %t474 = load ptr, ptr %l228, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t474, ptr %t473)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t476)
  store ptr %t478, ptr %l242
  br label %bb106
bb106:
  %t479 = load ptr, ptr %l242, !tbaa !29
  store ptr %t479, ptr %l243, !tbaa !29
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = getelementptr %"compiler/check:Checker", ptr %t480, i32 0, i32 33
  %t483 = load i64, ptr %l16, !tbaa !24
  %t486 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t482, i64 %t483)
  store { i64, ptr } %t486, ptr %l247
  br label %bb107
bb107:
  %t487 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t488 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t487)
  store %"compiler/typed:Block" %t488, ptr %l248
  br label %bb108
bb108:
  %t489 = load %"compiler/typed:Block", ptr %l248
  %t490 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t489, ptr %t490
  %t492 = load ptr, ptr %l243, !tbaa !29
  %t493 = getelementptr %"compiler/typed:Body", ptr %t492, i32 0, i32 11
  store ptr %t490, ptr %t493, !tbaa !29
  %t494 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t494)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l23 = alloca { i64, ptr }
  %rv = alloca ptr
  %t29 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 32
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t9, ptr %a4)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t15, ptr %a5)
  br label %bb3
bb3:
  store %"compiler/source:Span" %a1, ptr %l16
  store i32 %a2, ptr %l17, !tbaa !23
  store i32 %a3, ptr %l18
  store i32 0, ptr %l19
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 32
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t24, i64 %t25)
  store { i64, ptr } %t28, ptr %l23
  br label %bb4
bb4:
  store { i64, [5 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 0
  store i64 9, ptr %t30
  %t31 = load %"compiler/source:Span", ptr %l16
  %t32 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t31, 0
  %t33 = load i32, ptr %l17, !tbaa !23
  %t34 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t32, i32 %t33, 1
  %t35 = load i32, ptr %l18
  %t36 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t34, i32 %t35, 2
  %t37 = load i32, ptr %l19
  %t38 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t36, i32 %t37, 3
  %t39 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t40 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t38, { i64, ptr } %t39, 4
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t40, ptr %t41
  %t42 = load { i64, [5 x i64] }, ptr %t29
  %t44 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t42, ptr %t44
  store ptr %t44, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l15 = alloca i32
  %l19 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, ptr }
  %l30 = alloca %"compiler/msgs:Msg"
  %l31 = alloca i64
  %l32 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t2, ptr %t3, i32 %t5)
  store ptr %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t10)
  store %"compiler/source:Span" %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l11
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t13, ptr %t14, %"compiler/source:Span" %t15)
  store ptr %t16, ptr %l12
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l12, !tbaa !29
  store ptr %t17, ptr %l2, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t18)
  store i32 %t21, ptr %l15
  br label %bb4
bb4:
  %t22 = load i32, ptr %l15, !tbaa !23
  store i32 %t22, ptr %l3, !tbaa !23
  %t23 = load i32, ptr %l3, !tbaa !23
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t27 = icmp ne i32 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t33 = icmp ne i32 %t29, %t30
  store i1 %t33, ptr %l19, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t37)
  store %"compiler/source:Span" %t39, ptr %l25
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l28
  br label %bb11
bb11:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %s1, ptr %s1, { i64, ptr } %t51)
  store %"compiler/msgs:Msg" %t53, ptr %l30
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l23, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l25
  %t56 = load %"compiler/msgs:Msg", ptr %l30
  %t57 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t54, %"compiler/source:Span" %t55, %"compiler/msgs:Msg" %t56)
  store i64 %t57, ptr %l31
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l32, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t59)
  store %"compiler/source:Span" %t61, ptr %l34
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l34
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t62, %"compiler/source:Span" %t63)
  store ptr %t64, ptr %l35
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  %t65 = load ptr, ptr %l35, !tbaa !29
  store ptr %t65, ptr %rv
  br label %ret
bb16:
  %t66 = load ptr, ptr %l2, !tbaa !29
  store ptr %t66, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractChecked(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:ContractInfo"
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l15 = alloca i1
  %l19 = alloca i1
  %l20 = alloca %"compiler/typed:ContractInfo"
  %l24 = alloca %"compiler/typed:ContractInfo"
  %l25 = alloca i32
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %l48 = alloca i1
  %l58 = alloca ptr
  %l73 = alloca i1
  %l77 = alloca i1
  %l81 = alloca i1
  %l85 = alloca ptr
  %l90 = alloca i1
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 78
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load i1, ptr %l15, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l19
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %ret
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 77
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call { i32, %"compiler/typed:ContractInfo" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H1fc1bd863e6a60d3e5c2aece55d841d1(ptr %v0, ptr %v0, ptr %t18, i64 %t19)
  %t23 = extractvalue { i32, %"compiler/typed:ContractInfo" } %t22, 1
  %t24 = extractvalue { i32, %"compiler/typed:ContractInfo" } %t22, 0
  store i32 %t24, ptr %l25
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb7, label %ok.26
ok.26:
  store %"compiler/typed:ContractInfo" %t23, ptr %l24
  br label %bb6
bb6:
  %t27 = load %"compiler/typed:ContractInfo", ptr %l24
  store %"compiler/typed:ContractInfo" %t27, ptr %l20
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  br label %ret
bb9:
  %t28 = load %"compiler/typed:ContractInfo", ptr %l20
  store %"compiler/typed:ContractInfo" %t28, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t29 = getelementptr %"compiler/typed:ContractInfo", ptr %l2, i32 0, i32 2
  store ptr %t29, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t31, i64 %t32)
  %t36 = extractvalue { i32, { i64, ptr } } %t35, 1
  %t37 = extractvalue { i32, { i64, ptr } } %t35, 0
  store i32 %t37, ptr %l31
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39
ok.39:
  store { i64, ptr } %t36, ptr %l30
  br label %bb11
bb11:
  %t40 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  br label %bb16
bb12:
  %t41 = load i32, ptr %l31, !tbaa !23
  %t42 = ashr i32 %t41, 16
  %t44 = icmp eq i32 %t42, 1
  br i1 %t44, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_46400974b7d00480_e2373b052a0b959c)
  unreachable
bb15:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb16:
  %t46 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t46, ptr %l6, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb19:
  br label %bb20
bb20:
  %t59 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t59, ptr %l40, !tbaa !27
  %t60 = load i64, ptr %l8, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i64, ptr %t63, i64 %t60
  %t65 = load i64, ptr %t64, !tbaa !34
  store i64 %t65, ptr %l9, !tbaa !24
  %t67 = load i1, ptr %l3, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb24
bb22:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 84
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t71, i64 %t72)
  store i1 %t75, ptr %l48
  br label %bb23
bb23:
  %t76 = load i1, ptr %l48, !tbaa !21
  store i1 %t76, ptr %l44, !tbaa !21
  br label %bb24
bb24:
  %t77 = load i1, ptr %l44, !tbaa !21
  store i1 %t77, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l8, !tbaa !24
  br label %bb17
bb26:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t82, %t83
  store i64 %t86, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  br label %bb10
bb28:
  %t88 = load i1, ptr %l3, !tbaa !21
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb29, label %bb30
bb29:
  br label %ret
bb30:
  br label %bb31
bb31:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i64, ptr %l1, !tbaa !24
  %t96 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %t92, i64 %t93)
  store ptr %t96, ptr %l58
  br label %bb32
bb32:
  %t97 = load ptr, ptr %l58, !tbaa !29
  store ptr %t97, ptr %l10, !tbaa !29
  %t98 = load ptr, ptr %l10, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb33, label %bb34
bb33:
  br label %ret
bb34:
  br label %bb35
bb35:
  %t102 = load ptr, ptr %l10, !tbaa !29
  %t104 = getelementptr %"compiler/check:ctSource", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/ast:ContractBlock", ptr %t105, i32 0, i32 0
  %t108 = load %"compiler/source:Span", ptr %t107
  store %"compiler/source:Span" %t108, ptr %l11
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/load:Loader", ptr %t116, i32 0, i32 4
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = getelementptr %"compiler/typed:ContractInfo", ptr %l2, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t122 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t123 = load i32, ptr %t122, !tbaa !23
  %t125 = sext i32 %t123 to i64
  %t126 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 1
  %t127 = load i32, ptr %t126, !tbaa !23
  %t129 = sext i32 %t127 to i64
  %t134 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %t119, i64 %t121, i64 %t125, i64 %t129, i64 0)
  store i1 %t134, ptr %l73
  br label %bb36
bb36:
  %t135 = load i1, ptr %l73, !tbaa !21
  br i1 %t135, label %bb37, label %bb38
bb37:
  br label %ret
bb38:
  br label %bb39
bb39:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 78
  %t139 = load i64, ptr %l1, !tbaa !24
  %t142 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eRemove_3cI64_2c_20Bool_3e(ptr %v0, ptr %t138, i64 %t139)
  store i1 %t142, ptr %l77
  br label %bb40
bb40:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 77
  %t146 = load i64, ptr %l1, !tbaa !24
  %t149 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H044304b59760c17b661e6227d2ca1ac9(ptr %v0, ptr %t145, i64 %t146)
  store i1 %t149, ptr %l81
  br label %bb41
bb41:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 11
  %t153 = load i64, ptr %l1, !tbaa !24
  %t156 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t152, i64 %t153)
  store ptr %t156, ptr %l85
  br label %bb42
bb42:
  %t157 = load ptr, ptr %l85, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Body", ptr %t157, i32 0, i32 12
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeRel_3e_2eCl_H61e34197f63b762a003a73c4f2bf0624(ptr %v0, ptr %t159)
  br label %bb43
bb43:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i64, ptr %l1, !tbaa !24
  %t165 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t161, i64 %t162)
  store i1 %t165, ptr %l90
  br label %bb44
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectItems(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %t22 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 33
  store ptr %t8, ptr %l6, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t9)
  store %"compiler/source:Span" %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t13)
  store %"compiler/source:Span" %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l11
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t17, %"compiler/source:Span" %t18, i32 %t16, i64 1)
  store ptr %t20, ptr %l13
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 6, ptr %t23
  %t24 = load %"compiler/source:Span", ptr %l8
  %t25 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t24, 0
  %t27 = insertvalue { %"compiler/source:Span", ptr } %t25, ptr %t21, 1
  %t28 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t27, ptr %t28
  %t29 = load { i64, [3 x i64] }, ptr %t22
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t29, ptr %t31
  %t32 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t32, ptr %t31)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l24 = alloca ptr
  %l33 = alloca i64
  %l37 = alloca ptr
  %l49 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca %"compiler/check:ctSource"
  %l75 = alloca i32
  %l79 = alloca ptr
  %l82 = alloca i1
  %l91 = alloca i64
  %l95 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l108 = alloca i1
  %l132 = alloca %"compiler/check:ctSource"
  %l134 = alloca ptr
  %l135 = alloca i1
  %l142 = alloca i1
  %l160 = alloca %"compiler/check:ctSource"
  %l167 = alloca ptr
  %l171 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l178 = alloca i1
  %l186 = alloca ptr
  %l190 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l194 = alloca i32
  %l205 = alloca %"compiler/ast:Param"
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l217 = alloca { i64, ptr }
  %l222 = alloca i64
  %l225 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l232 = alloca %"compiler/check:ctSource"
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  %t433 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 11
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l24
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l24, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb16
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l33
  br label %bb5
bb5:
  %t30 = load i64, ptr %l33, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l37
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l37, !tbaa !29
  store ptr %t39, ptr %l5, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Func", ptr %t40, i32 0, i32 3
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Sig", ptr %t43, i32 0, i32 5
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb7, label %bb8
bb7:
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Func", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Sig", ptr %t54, i32 0, i32 5
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_700945490095e3ab_b793fb317cfa4b47)
  unreachable
bb11:
  br label %bb12
bb12:
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Func", ptr %t61, i32 0, i32 3
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Sig", ptr %t64, i32 0, i32 5
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l49, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l51, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 3
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Sig", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l54, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l58
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t90 = getelementptr %"compiler/ast:Func", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %t90, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t87, i32 %t91)
  store { i64, ptr } %t94, ptr %l62
  br label %bb14
bb14:
  %t95 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t96, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l49, !tbaa !29
  %t109 = load ptr, ptr %l51, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t111 = load i64, ptr %l58, !tbaa !24
  %t113 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t108, ptr %t109, { i64, ptr } %t110, i64 %t111, { i64, ptr } %t107)
  store %"compiler/check:ctSource" %t113, ptr %l65
  br label %bb15
bb15:
  %t114 = load %"compiler/check:ctSource", ptr %l65
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t114, ptr %t115
  store ptr %t115, ptr %rv
  br label %ret
bb16:
  %t117 = load { i64, [2 x i64] }, ptr %l2
  %t119 = extractvalue { i64, [2 x i64] } %t117, 0
  %t120 = icmp eq i64 %t119, 1
  br i1 %t120, label %bb17, label %bb18
bb17:
  %t122 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t123 = getelementptr { i32, i32 }, ptr %t122, i32 0, i32 0
  %t124 = load i32, ptr %t123
  store i32 %t124, ptr %l6, !tbaa !23
  %t126 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t127 = getelementptr { i32, i32 }, ptr %t126, i32 0, i32 1
  %t128 = load i32, ptr %t127
  store i32 %t128, ptr %l7, !tbaa !23
  br label %bb19
bb18:
  br label %bb68
bb19:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  %t136 = load i32, ptr %l6, !tbaa !23
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t139, ptr %l75
  br label %bb20
bb20:
  %t140 = load i32, ptr %l75, !tbaa !23
  store i32 %t140, ptr %l8, !tbaa !23
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t145 = load i32, ptr %l8, !tbaa !23
  %t148 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t144, i32 %t145)
  store ptr %t148, ptr %l79
  br label %bb21
bb21:
  %t149 = load ptr, ptr %l79, !tbaa !29
  store ptr %t149, ptr %l9, !tbaa !29
  %t150 = load ptr, ptr %l9, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb24
bb23:
  %t154 = load ptr, ptr %l9, !tbaa !29
  %t156 = getelementptr %"compiler/ast:TypeDecl", ptr %t154, i32 0, i32 3
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  store i1 %t159, ptr %l82, !tbaa !21
  br label %bb24
bb24:
  %t161 = load i1, ptr %l82, !tbaa !21
  br i1 %t161, label %bb25, label %bb26
bb25:
  store ptr null, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 2
  %t169 = load i32, ptr %l8, !tbaa !23
  %t172 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t168, i32 %t169)
  store i64 %t172, ptr %l91
  br label %bb28
bb28:
  %t173 = load i64, ptr %l91, !tbaa !24
  store i64 %t173, ptr %l10, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l9, !tbaa !29
  %t177 = getelementptr %"compiler/ast:TypeDecl", ptr %t175, i32 0, i32 0
  %t178 = load i32, ptr %t177, !tbaa !23
  %t181 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t174, i32 %t178)
  store { i64, ptr } %t181, ptr %l95
  br label %bb29
bb29:
  %t182 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t183, i64 %t184)
  %t186 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t188 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t188, ptr %lp11
  %t190 = load ptr, ptr %lp11
  store { i64, ptr } %t187, ptr %t190, !tbaa !27
  %t191 = load ptr, ptr %l9, !tbaa !29
  %t193 = getelementptr %"compiler/ast:TypeDecl", ptr %t191, i32 0, i32 3
  %t194 = load ptr, ptr %t193, !tbaa !29
  store ptr %t194, ptr %l12, !tbaa !29
  %t196 = load ptr, ptr %l12, !tbaa !29
  store ptr %t196, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t197 = load ptr, ptr %l99, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb30, label %bb31
bb30:
  %t200 = load ptr, ptr %l99, !tbaa !29
  %t201 = load i64, ptr %t200
  %t203 = icmp eq i64 %t201, 0
  store i1 %t203, ptr %l100, !tbaa !21
  br label %bb31
bb31:
  %t204 = load i1, ptr %l100, !tbaa !21
  br i1 %t204, label %bb32, label %bb33
bb32:
  %t205 = load ptr, ptr %l12, !tbaa !29
  %t207 = getelementptr { i64, [6 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { ptr }, ptr %t207, i32 0, i32 0
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l13, !tbaa !29
  br label %bb34
bb33:
  br label %bb51
bb34:
  %t211 = load ptr, ptr %l13, !tbaa !29
  %t213 = getelementptr %"compiler/ast:StructBody", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = icmp eq ptr %t214, null
  br i1 %t216, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb40
bb36:
  %t218 = load ptr, ptr %l13, !tbaa !29
  %t220 = getelementptr %"compiler/ast:StructBody", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = icmp eq ptr %t221, null
  br i1 %t223, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28)
  unreachable
bb38:
  br label %bb39
bb39:
  %t225 = load ptr, ptr %l13, !tbaa !29
  %t227 = getelementptr %"compiler/ast:StructBody", ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t231 = getelementptr %"compiler/ast:Sig", ptr %t228, i32 0, i32 5
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t234 = icmp eq ptr %t232, null
  store i1 %t234, ptr %l108, !tbaa !21
  br label %bb40
bb40:
  %t236 = load i1, ptr %l108, !tbaa !21
  br i1 %t236, label %bb41, label %bb42
bb41:
  store ptr null, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t238 = load ptr, ptr %l13, !tbaa !29
  %t240 = getelementptr %"compiler/ast:StructBody", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = icmp eq ptr %t241, null
  br i1 %t243, label %bb44, label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_25ec48d7738ec131_33504a893c084afd)
  unreachable
bb45:
  br label %bb46
bb46:
  %t245 = load ptr, ptr %l13, !tbaa !29
  %t247 = getelementptr %"compiler/ast:StructBody", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t251 = getelementptr %"compiler/ast:Sig", ptr %t248, i32 0, i32 5
  %t252 = load ptr, ptr %t251, !tbaa !29
  store ptr %t252, ptr %l14, !tbaa !29
  %t254 = load ptr, ptr %l14, !tbaa !29
  %t256 = icmp eq ptr %t254, null
  br i1 %t256, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_25ec48d7738ec131_33504a893c084afd)
  unreachable
bb48:
  br label %bb49
bb49:
  %t258 = load ptr, ptr %l14, !tbaa !29
  %t259 = load ptr, ptr %l13, !tbaa !29
  %t261 = getelementptr %"compiler/ast:StructBody", ptr %t259, i32 0, i32 0
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t263 = load i64, ptr %l10, !tbaa !24
  %t264 = load ptr, ptr %lp11
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  %t270 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t258, ptr null, { i64, ptr } %t262, i64 %t263, { i64, ptr } %t265)
  store %"compiler/check:ctSource" %t270, ptr %l132
  br label %bb50
bb50:
  %t271 = load %"compiler/check:ctSource", ptr %l132
  %t272 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t271, ptr %t272
  store ptr %t272, ptr %rv
  br label %ret
bb51:
  %t274 = load ptr, ptr %l12, !tbaa !29
  store ptr %t274, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t275 = load ptr, ptr %l134, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb52, label %bb53
bb52:
  %t278 = load ptr, ptr %l134, !tbaa !29
  %t279 = load i64, ptr %t278
  %t281 = icmp eq i64 %t279, 3
  store i1 %t281, ptr %l135, !tbaa !21
  br label %bb53
bb53:
  %t282 = load i1, ptr %l135, !tbaa !21
  br i1 %t282, label %bb54, label %bb55
bb54:
  %t283 = load ptr, ptr %l12, !tbaa !29
  %t285 = getelementptr { i64, [6 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { ptr, ptr }, ptr %t285, i32 0, i32 1
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l15, !tbaa !29
  br label %bb56
bb55:
  br label %bb67
bb56:
  %t289 = load ptr, ptr %l15, !tbaa !29
  %t291 = icmp eq ptr %t289, null
  br i1 %t291, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb59
bb58:
  %t293 = load ptr, ptr %l15, !tbaa !29
  %t295 = getelementptr %"compiler/ast:Func", ptr %t293, i32 0, i32 3
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/ast:Sig", ptr %t296, i32 0, i32 5
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = icmp eq ptr %t299, null
  store i1 %t301, ptr %l142, !tbaa !21
  br label %bb59
bb59:
  %t303 = load i1, ptr %l142, !tbaa !21
  br i1 %t303, label %bb60, label %bb61
bb60:
  store ptr null, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t305 = load ptr, ptr %l15, !tbaa !29
  %t307 = getelementptr %"compiler/ast:Func", ptr %t305, i32 0, i32 3
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t310 = getelementptr %"compiler/ast:Sig", ptr %t308, i32 0, i32 5
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = icmp eq ptr %t311, null
  br i1 %t313, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_1c86c4e2a1d4d52a_afb2831c22759b16)
  unreachable
bb64:
  br label %bb65
bb65:
  %t315 = load ptr, ptr %l15, !tbaa !29
  %t317 = getelementptr %"compiler/ast:Func", ptr %t315, i32 0, i32 3
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = getelementptr %"compiler/ast:Sig", ptr %t318, i32 0, i32 5
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t322 = load ptr, ptr %l15, !tbaa !29
  %t324 = getelementptr %"compiler/ast:Func", ptr %t322, i32 0, i32 3
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t327 = getelementptr %"compiler/ast:Sig", ptr %t325, i32 0, i32 0
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  %t329 = load i64, ptr %l10, !tbaa !24
  %t330 = load ptr, ptr %lp11
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  %t336 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t321, ptr null, { i64, ptr } %t328, i64 %t329, { i64, ptr } %t331)
  store %"compiler/check:ctSource" %t336, ptr %l160
  br label %bb66
bb66:
  %t337 = load %"compiler/check:ctSource", ptr %l160
  %t338 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t337, ptr %t338
  store ptr %t338, ptr %rv
  br label %ret
bb67:
  store ptr null, ptr %rv
  br label %ret
bb68:
  %t341 = load { i64, [2 x i64] }, ptr %l2
  %t343 = extractvalue { i64, [2 x i64] } %t341, 0
  %t344 = icmp eq i64 %t343, 10
  br i1 %t344, label %bb69, label %bb70
bb69:
  %t346 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t347 = getelementptr { i32, i64 }, ptr %t346, i32 0, i32 0
  %t348 = load i32, ptr %t347
  store i32 %t348, ptr %l16, !tbaa !23
  %t350 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t351 = getelementptr { i32, i64 }, ptr %t350, i32 0, i32 1
  %t352 = load i64, ptr %t351
  store i64 %t352, ptr %l17, !tbaa !24
  br label %bb71
bb70:
  br label %bb93
bb71:
  store %olang.scope zeroinitializer, ptr %s12
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l167, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/check:Checker", ptr %t355, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !29
  %t359 = load i32, ptr %l16, !tbaa !23
  %t362 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t358, i32 %t359)
  store { i64, ptr } %t362, ptr %l171
  br label %bb72
bb72:
  %t363 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t363, ptr %l172, !tbaa !27
  %t364 = load i64, ptr %l17, !tbaa !24
  %t366 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = getelementptr %"compiler/generic:AnySlot", ptr %t367, i64 %t364
  %t369 = load %"compiler/generic:AnySlot", ptr %t368
  %t370 = load ptr, ptr %l167, !tbaa !29
  %t372 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %t370, %"compiler/generic:AnySlot" %t369)
  store ptr %t372, ptr %l175
  br label %bb73
bb73:
  %t373 = load ptr, ptr %l175, !tbaa !29
  store ptr %t373, ptr %l18, !tbaa !29
  %t374 = load ptr, ptr %l18, !tbaa !29
  %t376 = icmp eq ptr %t374, null
  br i1 %t376, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb76
bb75:
  %t378 = load ptr, ptr %l18, !tbaa !29
  %t380 = getelementptr %"compiler/ast:Func", ptr %t378, i32 0, i32 3
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = getelementptr %"compiler/ast:Sig", ptr %t381, i32 0, i32 5
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t386 = icmp eq ptr %t384, null
  store i1 %t386, ptr %l178, !tbaa !21
  br label %bb76
bb76:
  %t388 = load i1, ptr %l178, !tbaa !21
  br i1 %t388, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s12)
  store ptr null, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/check:Checker", ptr %t390, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = getelementptr %"compiler/generic:Program", ptr %t393, i32 0, i32 2
  store ptr %t395, ptr %l186, !tbaa !29
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/check:Checker", ptr %t396, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !29
  %t400 = load i32, ptr %l16, !tbaa !23
  %t403 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t399, i32 %t400)
  store { i64, ptr } %t403, ptr %l190
  br label %bb80
bb80:
  %t404 = load { i64, ptr }, ptr %l190, !tbaa !27
  store { i64, ptr } %t404, ptr %l191, !tbaa !27
  %t405 = load i64, ptr %l17, !tbaa !24
  %t407 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr %"compiler/generic:AnySlot", ptr %t408, i64 %t405
  %t410 = getelementptr %"compiler/generic:AnySlot", ptr %t409, i32 0, i32 1
  %t411 = load i32, ptr %t410, !tbaa !23
  %t412 = load ptr, ptr %l186, !tbaa !29
  %t414 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t412, i32 %t411)
  store i32 %t414, ptr %l194
  br label %bb81
bb81:
  %t415 = load i32, ptr %l194, !tbaa !23
  store i32 %t415, ptr %l19, !tbaa !23
  %t416 = load ptr, ptr %l18, !tbaa !29
  %t418 = getelementptr %"compiler/ast:Func", ptr %t416, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !29
  store ptr %t419, ptr %l20, !tbaa !29
  %t421 = load ptr, ptr %l20, !tbaa !29
  %t423 = icmp eq ptr %t421, null
  br i1 %t423, label %bb82, label %bb83
bb82:
  %t425 = load ptr, ptr %l18, !tbaa !29
  %t427 = getelementptr %"compiler/ast:Func", ptr %t425, i32 0, i32 0
  %t428 = load %"compiler/source:Span", ptr %t427
  %t429 = load ptr, ptr %l18, !tbaa !29
  %t431 = getelementptr %"compiler/ast:Func", ptr %t429, i32 0, i32 0
  %t432 = load %"compiler/source:Span", ptr %t431
  store { i64, [5 x i64] } zeroinitializer, ptr %t433
  %t434 = getelementptr { i64, [5 x i64] }, ptr %t433, i32 0, i32 0
  store i64 4, ptr %t434
  %t436 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t432, 0
  %t437 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t436, ptr null, 1
  %t438 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t437, i1 false, 2
  %t439 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t438, i1 false, 3
  %t440 = getelementptr { i64, [5 x i64] }, ptr %t433, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t439, ptr %t440
  %t441 = load { i64, [5 x i64] }, ptr %t433
  %t443 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t441, ptr %t443
  %t446 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t428, i32 0, ptr %t443, ptr null)
  store %"compiler/ast:Param" %t446, ptr %l205
  br label %bb84
bb83:
  br label %bb85
bb84:
  %t447 = load %"compiler/ast:Param", ptr %l205
  %t448 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Param" %t447, ptr %t448
  store ptr %t448, ptr %l20, !tbaa !29
  br label %bb85
bb85:
  %t450 = load ptr, ptr %l18, !tbaa !29
  %t452 = getelementptr %"compiler/ast:Func", ptr %t450, i32 0, i32 3
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t455 = getelementptr %"compiler/ast:Sig", ptr %t453, i32 0, i32 5
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t458 = icmp eq ptr %t456, null
  br i1 %t458, label %bb86, label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_8b08af1e0b47ad17_714e6cc493d1321b)
  unreachable
bb87:
  br label %bb88
bb88:
  %t460 = load ptr, ptr %l18, !tbaa !29
  %t462 = getelementptr %"compiler/ast:Func", ptr %t460, i32 0, i32 3
  %t463 = load ptr, ptr %t462, !tbaa !29
  %t465 = getelementptr %"compiler/ast:Sig", ptr %t463, i32 0, i32 5
  %t466 = load ptr, ptr %t465, !tbaa !29
  store ptr %t466, ptr %l213, !tbaa !29
  %t467 = load ptr, ptr %l20, !tbaa !29
  store ptr %t467, ptr %l214, !tbaa !29
  %t468 = load ptr, ptr %l18, !tbaa !29
  %t470 = getelementptr %"compiler/ast:Func", ptr %t468, i32 0, i32 3
  %t471 = load ptr, ptr %t470, !tbaa !29
  %t473 = getelementptr %"compiler/ast:Sig", ptr %t471, i32 0, i32 0
  %t474 = load { i64, ptr }, ptr %t473, !tbaa !27
  store { i64, ptr } %t474, ptr %l217, !tbaa !27
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/check:Checker", ptr %t475, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !29
  %t480 = getelementptr %"compiler/generic:Program", ptr %t478, i32 0, i32 2
  %t481 = load i32, ptr %l19, !tbaa !23
  %t484 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t480, i32 %t481)
  store i64 %t484, ptr %l222
  br label %bb89
bb89:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load i32, ptr %l16, !tbaa !23
  %t489 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t485, i32 %t486)
  store { i64, ptr } %t489, ptr %l225
  br label %bb90
bb90:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load ptr, ptr %l18, !tbaa !29
  %t493 = getelementptr %"compiler/ast:Func", ptr %t491, i32 0, i32 2
  %t494 = load i32, ptr %t493, !tbaa !23
  %t497 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t490, i32 %t494)
  store { i64, ptr } %t497, ptr %l229
  br label %bb91
bb91:
  %t498 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t498, 1
  %t500 = extractvalue { i64, ptr } %t498, 0
  %t501 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 1
  %t502 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 0
  %t503 = add i64 %t500, %t502
  %t504 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t505 = extractvalue { i64, ptr } %t504, 1
  %t506 = extractvalue { i64, ptr } %t504, 0
  %t507 = add i64 %t503, %t506
  %t508 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t507)
  call void @olang_textcopy(ptr %t508, ptr %t499, i64 %t500)
  %t509 = getelementptr i8, ptr %t508, i64 %t500
  call void @olang_textcopy(ptr %t509, ptr %t501, i64 %t502)
  %t510 = getelementptr i8, ptr %t509, i64 %t502
  call void @olang_textcopy(ptr %t510, ptr %t505, i64 %t506)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t508, 1
  %t514 = extractvalue { i64, ptr } %t512, 0
  %t515 = extractvalue { i64, ptr } %t512, 1
  %t516 = mul i64 %t514, 1
  %t517 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t516)
  call void @llvm.memcpy.p0.p0.i64(ptr %t517, ptr %t515, i64 %t516, i1 false)
  %t518 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t517, 1
  %t520 = load ptr, ptr %l213, !tbaa !29
  %t521 = load ptr, ptr %l214, !tbaa !29
  %t522 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t523 = load i64, ptr %l222, !tbaa !24
  %t525 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t520, ptr %t521, { i64, ptr } %t522, i64 %t523, { i64, ptr } %t519)
  store %"compiler/check:ctSource" %t525, ptr %l232
  br label %bb92
bb92:
  %t526 = load %"compiler/check:ctSource", ptr %l232
  %t527 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t526, ptr %t527
  call void @__olang_scope_close(ptr %s12)
  store ptr %t527, ptr %rv
  br label %ret
bb93:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryChecks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca %"compiler/typed:ContractInfo"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i64
  %l36 = alloca i64
  %l37 = alloca { i64, i64, i64 }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l43 = alloca ptr
  %l49 = alloca ptr
  %l58 = alloca i1
  %l60 = alloca %"compiler/typed:ContractInfo"
  %l64 = alloca %"compiler/typed:ContractInfo"
  %l65 = alloca i32
  %l67 = alloca i64
  %l70 = alloca ptr
  %l73 = alloca i32
  %l78 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca { i64, ptr }
  %l90 = alloca i64
  %l93 = alloca i64
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l116 = alloca i1
  %l124 = alloca i64
  %l126 = alloca i32
  %l129 = alloca ptr
  %l133 = alloca i1
  %l137 = alloca i1
  %l142 = alloca i32
  %l145 = alloca i1
  %l149 = alloca ptr
  %l151 = alloca i64
  %l154 = alloca %"compiler/source:Span"
  %l156 = alloca %"compiler/msgs:Msg"
  %l157 = alloca i64
  %l159 = alloca i64
  %l163 = alloca i64
  %l166 = alloca i64
  %l186 = alloca %"compiler/source:Span"
  %l189 = alloca i64
  %l191 = alloca ptr
  %l194 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l198 = alloca i32
  %l207 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l216 = alloca ptr
  %l224 = alloca i64
  %l228 = alloca %"compiler/source:Span"
  %l229 = alloca ptr
  %l230 = alloca %"compiler/source:Span"
  %l231 = alloca i32
  %l236 = alloca ptr
  %l240 = alloca { i64, ptr }
  %l241 = alloca ptr
  %l244 = alloca i32
  %l249 = alloca { i64, ptr }
  %l254 = alloca i64
  %l255 = alloca ptr
  %l260 = alloca ptr
  %l263 = alloca ptr
  %l266 = alloca ptr
  %l267 = alloca i64
  %l270 = alloca i64
  %l271 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l273 = alloca i64
  %l278 = alloca %"compiler/source:Span"
  %l279 = alloca i32
  %l281 = alloca ptr
  %l285 = alloca %"compiler/typed:Try"
  %l291 = alloca i64
  %l295 = alloca { i64, i64, i64 }
  %l313 = alloca ptr
  %l314 = alloca ptr
  %l315 = alloca %"compiler/source:Span"
  %l319 = alloca ptr
  %l321 = alloca %"compiler/typed:If"
  %l326 = alloca ptr
  %l331 = alloca ptr
  %l333 = alloca ptr
  %l334 = alloca { i64, ptr }
  %l337 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %t396 = alloca { i64, [3 x i64] }, align 8
  %t517 = alloca { i64, [5 x i64] }, align 8
  %t562 = alloca { i64, [3 x i64] }, align 8
  %t603 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l43
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l43, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l1, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t13)
  store ptr %t15, ptr %l49
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l49, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 1
  %t19 = load { i64, [2 x i64] }, ptr %t18
  store { i64, [2 x i64] } %t19, ptr %l2
  %t21 = load { i64, [2 x i64] }, ptr %l2
  %t23 = extractvalue { i64, [2 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  %t26 = load { i64, [2 x i64] }, ptr %l2
  %t28 = extractvalue { i64, [2 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 1
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t31, i64 %t32)
  store i1 %t35, ptr %l58
  br label %bb13
bb13:
  %t36 = load i1, ptr %l58, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  br label %bb16
bb16:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 77
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call { i32, %"compiler/typed:ContractInfo" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H1fc1bd863e6a60d3e5c2aece55d841d1(ptr %v0, ptr %v0, ptr %t41, i64 %t42)
  %t46 = extractvalue { i32, %"compiler/typed:ContractInfo" } %t45, 1
  %t47 = extractvalue { i32, %"compiler/typed:ContractInfo" } %t45, 0
  store i32 %t47, ptr %l65
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb18, label %ok.49
ok.49:
  store %"compiler/typed:ContractInfo" %t46, ptr %l64
  br label %bb17
bb17:
  %t50 = load %"compiler/typed:ContractInfo", ptr %l64
  store %"compiler/typed:ContractInfo" %t50, ptr %l60
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t51 = load %"compiler/typed:ContractInfo", ptr %l60
  store %"compiler/typed:ContractInfo" %t51, ptr %l3
  %t52 = getelementptr %"compiler/typed:ContractInfo", ptr %l3, i32 0, i32 2
  %t54 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t52)
  store i64 %t54, ptr %l67
  br label %bb21
bb21:
  %t55 = load i64, ptr %l67, !tbaa !24
  %t56 = icmp eq i64 %t55, 0
  br i1 %t56, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t58)
  store ptr %t60, ptr %l70
  br label %bb25
bb25:
  %t61 = load ptr, ptr %l70, !tbaa !29
  store ptr %t61, ptr %l4, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t65, { i64, ptr } { i64 20, ptr @.d10 }, { i64, ptr } { i64 13, ptr @.d11 })
  store i32 %t67, ptr %l73
  br label %bb26
bb26:
  %t68 = load i32, ptr %l73, !tbaa !23
  store i32 %t68, ptr %l5, !tbaa !23
  %t69 = load i32, ptr %l5, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp eq i32 %t69, %t70
  br i1 %t73, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb28:
  br label %bb29
bb29:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  store ptr %t78, ptr %l78, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l5, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l83
  br label %bb30
bb30:
  %t89 = load ptr, ptr %l78, !tbaa !29
  %t90 = load i32, ptr %l83, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t89, i32 %t90)
  store { i64, ptr } %t91, ptr %l84
  br label %bb31
bb31:
  %t92 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t92, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb32, label %bb33
bb32:
  %t103 = load i64, ptr %l10, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb37
bb34:
  %t107 = load i64, ptr %l9, !tbaa !24
  %t108 = load i64, ptr %l8, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l10, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l93, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb36
bb36:
  %t123 = load i64, ptr %l93, !tbaa !24
  store i64 %t123, ptr %l90, !tbaa !24
  br label %bb37
bb37:
  %t124 = load i64, ptr %l90, !tbaa !24
  store i64 %t124, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  %t125 = load i64, ptr %l12, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s9)
  br label %bb48
bb40:
  br label %bb41
bb41:
  %t133 = load i64, ptr %l8, !tbaa !24
  %t134 = load i64, ptr %l12, !tbaa !24
  %t135 = load i64, ptr %l10, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l13, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t144, ptr %l112, !tbaa !27
  %t145 = load i64, ptr %l13, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i32, ptr %t148, i64 %t145
  %t150 = load i32, ptr %t149, !tbaa !33
  %t153 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t143, i32 %t150)
  store { i64, ptr } %t153, ptr %l115
  br label %bb42
bb42:
  %t154 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t155 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s9, { i64, ptr } %t154, { i64, ptr } { i64 7, ptr @.d12 })
  store i1 %t155, ptr %l116
  br label %bb43
bb43:
  %t156 = load i1, ptr %l116, !tbaa !21
  br i1 %t156, label %bb44, label %bb45
bb44:
  %t157 = load i64, ptr %l13, !tbaa !24
  store i64 %t157, ptr %l7, !tbaa !24
  br label %bb46
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb47
bb47:
  %t159 = load i64, ptr %l12, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l12, !tbaa !24
  br label %bb38
bb48:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 2
  %t169 = load i32, ptr %l5, !tbaa !23
  %t170 = load i64, ptr %l7, !tbaa !24
  store i64 %t170, ptr %l124, !tbaa !24
  %t171 = load i64, ptr %l124, !tbaa !24
  %t172 = load i64, ptr %l124, !tbaa !24
  %t173 = shl i64 1, %t172
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t168, i32 %t169, i64 %t173)
  store i32 %t177, ptr %l126
  br label %bb49
bb49:
  %t178 = load i32, ptr %l126, !tbaa !23
  store i32 %t178, ptr %l14, !tbaa !23
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l1, !tbaa !24
  %t183 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %t179, i64 %t180)
  store ptr %t183, ptr %l129
  br label %bb50
bb50:
  %t184 = load ptr, ptr %l129, !tbaa !29
  store ptr %t184, ptr %l15, !tbaa !29
  %t185 = load ptr, ptr %l4, !tbaa !29
  %t187 = getelementptr %"compiler/check:frame", ptr %t185, i32 0, i32 21
  %t188 = load i1, ptr %t187, !tbaa !21
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb51, label %bb52
bb51:
  %t192 = load ptr, ptr %l4, !tbaa !29
  %t194 = getelementptr %"compiler/check:frame", ptr %t192, i32 0, i32 12
  %t195 = load i1, ptr %t194, !tbaa !21
  %t197 = xor i1 %t195, true
  store i1 %t197, ptr %l133, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb53
bb53:
  %t199 = load i1, ptr %l133, !tbaa !21
  br i1 %t199, label %bb54, label %bb55
bb54:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l4, !tbaa !29
  %t203 = getelementptr %"compiler/check:frame", ptr %t201, i32 0, i32 6
  %t204 = load i32, ptr %t203, !tbaa !23
  %t205 = load i32, ptr %l14, !tbaa !23
  %t209 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t200, i32 %t204, i32 %t205)
  store i32 %t209, ptr %l142
  br label %bb56
bb55:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb57
bb56:
  %t210 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t211 = load i32, ptr %l142, !tbaa !23
  %t213 = icmp ne i32 %t211, %t210
  store i1 %t213, ptr %l137, !tbaa !21
  br label %bb57
bb57:
  %t215 = load i1, ptr %l137, !tbaa !21
  br i1 %t215, label %bb58, label %bb59
bb58:
  %t216 = load ptr, ptr %l15, !tbaa !29
  %t218 = icmp eq ptr %t216, null
  %t220 = xor i1 %t218, true
  store i1 %t220, ptr %l145, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb60
bb60:
  %t222 = load i1, ptr %l145, !tbaa !21
  br i1 %t222, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s12
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l149, !tbaa !29
  %t224 = load ptr, ptr %l15, !tbaa !29
  %t226 = getelementptr %"compiler/check:ctSource", ptr %t224, i32 0, i32 3
  %t227 = load i64, ptr %t226, !tbaa !24
  store i64 %t227, ptr %l151, !tbaa !24
  %t228 = load ptr, ptr %l15, !tbaa !29
  %t230 = getelementptr %"compiler/check:ctSource", ptr %t228, i32 0, i32 0
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/ast:ContractBlock", ptr %t231, i32 0, i32 0
  %t234 = load %"compiler/source:Span", ptr %t233
  store %"compiler/source:Span" %t234, ptr %l154
  %t235 = getelementptr %"compiler/typed:ContractInfo", ptr %l3, i32 0, i32 0
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  %t238 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractNeedsArgumentError(ptr %v0, ptr %s12, { i64, ptr } %t236)
  store %"compiler/msgs:Msg" %t238, ptr %l156
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t239 = load ptr, ptr %l149, !tbaa !29
  %t240 = load i64, ptr %l151, !tbaa !24
  %t241 = load %"compiler/source:Span", ptr %l154
  %t242 = load %"compiler/msgs:Msg", ptr %l156
  %t243 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectErr(ptr %v0, ptr %s12, ptr %t239, i64 %t240, %"compiler/source:Span" %t241, %"compiler/msgs:Msg" %t242)
  store i64 %t243, ptr %l157
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s12)
  br label %bb65
bb65:
  store i64 0, ptr %l16, !tbaa !24
  %t244 = getelementptr %"compiler/typed:ContractInfo", ptr %l3, i32 0, i32 2
  %t246 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t244)
  store i64 %t246, ptr %l159
  br label %bb66
bb66:
  %t247 = load i64, ptr %l159, !tbaa !24
  store i64 %t247, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t248 = load i64, ptr %l17, !tbaa !24
  %t249 = load i64, ptr %l16, !tbaa !24
  %t252 = icmp sgt i64 %t248, %t249
  br i1 %t252, label %bb67, label %bb68
bb67:
  %t254 = load i64, ptr %l18, !tbaa !24
  %t256 = icmp sgt i64 %t254, 0
  br i1 %t256, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb72
bb69:
  %t258 = load i64, ptr %l17, !tbaa !24
  %t259 = load i64, ptr %l16, !tbaa !24
  %t262 = sub i64 %t258, %t259
  %t263 = load i64, ptr %l18, !tbaa !24
  %t266 = add i64 %t262, %t263
  %t268 = sub i64 %t266, 1
  %t269 = load i64, ptr %l18, !tbaa !24
  %t272 = sdiv i64 %t268, %t269
  store i64 %t272, ptr %l166, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb71
bb71:
  %t274 = load i64, ptr %l166, !tbaa !24
  store i64 %t274, ptr %l163, !tbaa !24
  br label %bb72
bb72:
  %t275 = load i64, ptr %l163, !tbaa !24
  store i64 %t275, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s14
  %t276 = load i64, ptr %l20, !tbaa !24
  %t277 = load i64, ptr %l19, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s14)
  br label %bb131
bb75:
  br label %bb76
bb76:
  %t284 = load i64, ptr %l16, !tbaa !24
  %t285 = load i64, ptr %l20, !tbaa !24
  %t286 = load i64, ptr %l18, !tbaa !24
  %t289 = mul i64 %t285, %t286
  %t292 = add i64 %t284, %t289
  store i64 %t292, ptr %l21, !tbaa !24
  %t294 = getelementptr %"compiler/typed:ContractInfo", ptr %l3, i32 0, i32 3
  %t295 = load i64, ptr %l21, !tbaa !24
  %t298 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t294, i64 %t295)
  store %"compiler/source:Span" %t298, ptr %l186
  br label %bb77
bb77:
  %t299 = load %"compiler/source:Span", ptr %l186
  store %"compiler/source:Span" %t299, ptr %l22
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/check:Checker", ptr %t300, i32 0, i32 32
  %t304 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t302)
  store i64 %t304, ptr %l189
  br label %bb78
bb78:
  %t305 = load i64, ptr %l189, !tbaa !24
  store i64 %t305, ptr %l23, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t306)
  store ptr %t308, ptr %l191
  br label %bb79
bb79:
  %t309 = load ptr, ptr %l191, !tbaa !29
  %t311 = getelementptr %"compiler/typed:Body", ptr %t309, i32 0, i32 5
  store ptr %t311, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s16
  %t313 = load ptr, ptr %l24, !tbaa !29
  %t314 = load i64, ptr %l25, !tbaa !24
  %t317 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %t313, i64 %t314)
  %t318 = extractvalue { i32, { i64, ptr } } %t317, 1
  %t319 = extractvalue { i32, { i64, ptr } } %t317, 0
  store i32 %t319, ptr %l198
  %t320 = icmp ne i32 %t319, 0
  br i1 %t320, label %bb82, label %ok.321
ok.321:
  store { i64, ptr } %t318, ptr %l197
  br label %bb81
bb81:
  %t322 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t322, ptr %l194, !tbaa !27
  br label %bb86
bb82:
  %t323 = load i32, ptr %l198, !tbaa !23
  %t324 = ashr i32 %t323, 16
  %t326 = icmp eq i32 %t324, 1
  br i1 %t326, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_c7b5cbd58e58cb02_20344cc1e983d9b6)
  unreachable
bb85:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s16)
  br label %bb96
bb86:
  %t328 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t328, ptr %l26, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t329, 0
  store i64 %t331, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb87
bb87:
  store %olang.scope zeroinitializer, ptr %s17
  %t333 = load i64, ptr %l28, !tbaa !24
  %t334 = load i64, ptr %l27, !tbaa !24
  %t337 = icmp slt i64 %t333, %t334
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s17)
  br label %bb94
bb89:
  br label %bb90
bb90:
  %t341 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t341, ptr %l207, !tbaa !27
  %t342 = load i64, ptr %l28, !tbaa !24
  %t344 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = getelementptr i32, ptr %t345, i64 %t342
  %t347 = load i32, ptr %t346, !tbaa !33
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/check:Checker", ptr %t349, i32 0, i32 32
  store ptr %t351, ptr %l211, !tbaa !29
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l22
  %t356 = sext i32 %t347 to i64
  %t360 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t352, %"compiler/source:Span" %t353, i64 %t356)
  store ptr %t360, ptr %l216
  br label %bb91
bb91:
  %t361 = load ptr, ptr %l211, !tbaa !29
  %t362 = load ptr, ptr %l216, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t361, ptr %t362)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s17)
  br label %bb93
bb93:
  %t363 = load i64, ptr %l28, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l28, !tbaa !24
  br label %bb87
bb94:
  %t367 = load i64, ptr %l25, !tbaa !24
  %t368 = load i64, ptr %l27, !tbaa !24
  %t371 = add i64 %t367, %t368
  store i64 %t371, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb95
bb95:
  br label %bb80
bb96:
  %t373 = getelementptr %"compiler/typed:ContractInfo", ptr %l3, i32 0, i32 2
  %t374 = load i64, ptr %l21, !tbaa !24
  %t377 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t373, i64 %t374)
  store i64 %t377, ptr %l224
  br label %bb97
bb97:
  %t378 = load i64, ptr %l224, !tbaa !24
  store i64 %t378, ptr %l30, !tbaa !24
  %t379 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 1
  %t380 = load i32, ptr %t379, !tbaa !23
  %t382 = sub i32 %t380, 1
  %t383 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 1
  %t384 = load i32, ptr %t383, !tbaa !23
  %t387 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s14, i32 %t382, i32 %t384)
  store %"compiler/source:Span" %t387, ptr %l228
  br label %bb98
bb98:
  %t388 = load %"compiler/source:Span", ptr %l228
  store %"compiler/source:Span" %t388, ptr %l31
  %t389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t389, ptr %l229, !tbaa !29
  %t390 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t390, ptr %l230
  %t391 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t391, ptr %l231, !tbaa !23
  %t392 = load i64, ptr %l30, !tbaa !24
  %t394 = trunc i64 %t392 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t396
  %t397 = getelementptr { i64, [3 x i64] }, ptr %t396, i32 0, i32 0
  store i64 0, ptr %t397
  %t399 = insertvalue { i32 } undef, i32 %t394, 0
  %t400 = getelementptr { i64, [3 x i64] }, ptr %t396, i32 0, i32 1
  store { i32 } %t399, ptr %t400
  %t401 = load { i64, [3 x i64] }, ptr %t396
  %t403 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t401, ptr %t403
  store ptr %t403, ptr %l236, !tbaa !29
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/check:Checker", ptr %t404, i32 0, i32 32
  %t407 = load i64, ptr %l23, !tbaa !24
  %t410 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t406, i64 %t407)
  store { i64, ptr } %t410, ptr %l240
  br label %bb99
bb99:
  %t411 = load ptr, ptr %l229, !tbaa !29
  %t412 = load %"compiler/source:Span", ptr %l230
  %t413 = load i32, ptr %l231, !tbaa !23
  %t414 = load ptr, ptr %l236, !tbaa !29
  %t415 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t416 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %t411, %"compiler/source:Span" %t412, i32 %t413, ptr %t414, { i64, ptr } %t415)
  store ptr %t416, ptr %l241
  br label %bb100
bb100:
  %t417 = load ptr, ptr %l241, !tbaa !29
  store ptr %t417, ptr %l32, !tbaa !29
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load i64, ptr %l30, !tbaa !24
  %t422 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t418, i64 %t419)
  store i32 %t422, ptr %l244
  br label %bb101
bb101:
  %t423 = load i32, ptr %l244, !tbaa !23
  store i32 %t423, ptr %l33, !tbaa !23
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/check:Checker", ptr %t424, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !29
  %t429 = getelementptr %"compiler/generic:Program", ptr %t427, i32 0, i32 2
  %t430 = load i32, ptr %l33, !tbaa !23
  %t433 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t429, i32 %t430)
  store { i64, ptr } %t433, ptr %l249
  br label %bb102
bb102:
  %t434 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t434, 0
  %t437 = icmp sgt i64 %t435, 0
  br i1 %t437, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s19
  %t439 = load ptr, ptr %l4, !tbaa !29
  %t441 = getelementptr %"compiler/check:frame", ptr %t439, i32 0, i32 23
  %t443 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t441)
  store i64 %t443, ptr %l254
  br label %bb105
bb104:
  br label %bb116
bb105:
  %t444 = load i64, ptr %l254, !tbaa !24
  store i64 %t444, ptr %l34, !tbaa !24
  %t445 = load ptr, ptr %l4, !tbaa !29
  store ptr %t445, ptr %l255, !tbaa !29
  %t446 = load ptr, ptr %l255, !tbaa !29
  %t447 = getelementptr %"compiler/check:frame", ptr %t446, i32 0, i32 15
  %t448 = load i64, ptr %t447, !tbaa !24
  %t450 = add i64 %t448, 1
  %t452 = load ptr, ptr %l255, !tbaa !29
  %t453 = getelementptr %"compiler/check:frame", ptr %t452, i32 0, i32 15
  store i64 %t450, ptr %t453, !tbaa !24
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load i32, ptr %l33, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %t454, i32 %t455)
  br label %bb106
bb106:
  %t458 = load ptr, ptr %l4, !tbaa !29
  store ptr %t458, ptr %l260, !tbaa !29
  %t459 = load ptr, ptr %l260, !tbaa !29
  %t460 = getelementptr %"compiler/check:frame", ptr %t459, i32 0, i32 16
  %t461 = load i64, ptr %t460, !tbaa !24
  %t463 = add i64 %t461, 1
  %t465 = load ptr, ptr %l260, !tbaa !29
  %t466 = getelementptr %"compiler/check:frame", ptr %t465, i32 0, i32 16
  store i64 %t463, ptr %t466, !tbaa !24
  %t467 = load ptr, ptr %l4, !tbaa !29
  store ptr %t467, ptr %l263, !tbaa !29
  %t468 = load ptr, ptr %l263, !tbaa !29
  %t469 = getelementptr %"compiler/check:frame", ptr %t468, i32 0, i32 15
  %t470 = load i64, ptr %t469, !tbaa !24
  %t472 = sub i64 %t470, 1
  %t474 = load ptr, ptr %l263, !tbaa !29
  %t475 = getelementptr %"compiler/check:frame", ptr %t474, i32 0, i32 15
  store i64 %t472, ptr %t475, !tbaa !24
  %t476 = load ptr, ptr %l0, !tbaa !29
  store ptr %t476, ptr %l266, !tbaa !29
  %t477 = load i64, ptr %l34, !tbaa !24
  store i64 %t477, ptr %l267, !tbaa !24
  %t478 = load ptr, ptr %l4, !tbaa !29
  %t480 = getelementptr %"compiler/check:frame", ptr %t478, i32 0, i32 23
  %t482 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t480)
  store i64 %t482, ptr %l270
  br label %bb107
bb107:
  %t483 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %s19)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t483, ptr %l271
  br label %bb108
bb108:
  %t484 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l271
  %t485 = call ptr @__olang_scope_alloc_a(ptr %s19, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t484, ptr %t485
  %t486 = load ptr, ptr %l266, !tbaa !29
  %t487 = load i64, ptr %l267, !tbaa !24
  %t488 = load i64, ptr %l270, !tbaa !24
  %t490 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %s19, ptr %t486, i64 %t487, i64 %t488, ptr %t485)
  store i64 %t490, ptr %l273
  br label %bb109
bb109:
  %t491 = load i64, ptr %l273, !tbaa !24
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load %"compiler/source:Span", ptr %l22
  %t494 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %t492, %"compiler/source:Span" %t493, i64 %t494, i64 %t491)
  br label %bb110
bb110:
  %t500 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t500, ptr %l278
  %t501 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t501, ptr %l279, !tbaa !23
  %t502 = load ptr, ptr %l32, !tbaa !29
  store ptr %t502, ptr %l281, !tbaa !29
  %t504 = icmp sge i64 0, 0
  br i1 %t504, label %bb111, label %bb112
bb111:
  %t506 = icmp sle i64 0, 1152921504606846975
  br i1 %t506, label %bb113, label %bb114
bb112:
  call void @__olang_check_failed(ptr @olang_loc_b7234c2f48bf29ec_30c1ec6e3fb60508)
  unreachable
bb113:
  %t508 = mul i64 0, 8
  %t509 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t508)
  %t510 = insertvalue { i64, ptr } undef, i64 0, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t509, 1
  %t512 = load ptr, ptr %l281, !tbaa !29
  %t514 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t512, { i64, ptr } %t511, i1 false, i1 false)
  store %"compiler/typed:Try" %t514, ptr %l285
  br label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_b7234c2f48bf29ec_30c1ec6e3fb60508)
  unreachable
bb115:
  %t515 = load %"compiler/typed:Try", ptr %l285
  %t516 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t515, ptr %t516
  store { i64, [5 x i64] } zeroinitializer, ptr %t517
  %t518 = getelementptr { i64, [5 x i64] }, ptr %t517, i32 0, i32 0
  store i64 14, ptr %t518
  %t519 = load %"compiler/source:Span", ptr %l278
  %t520 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t519, 0
  %t521 = load i32, ptr %l279, !tbaa !23
  %t522 = insertvalue { %"compiler/source:Span", i32, ptr } %t520, i32 %t521, 1
  %t524 = insertvalue { %"compiler/source:Span", i32, ptr } %t522, ptr %t516, 2
  %t525 = getelementptr { i64, [5 x i64] }, ptr %t517, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t524, ptr %t525
  %t526 = load { i64, [5 x i64] }, ptr %t517
  %t528 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t526, ptr %t528
  store ptr %t528, ptr %l32, !tbaa !29
  call void @__olang_scope_close(ptr %s19)
  br label %bb116
bb116:
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t532 = getelementptr %"compiler/check:Checker", ptr %t530, i32 0, i32 33
  %t534 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t532)
  store i64 %t534, ptr %l291
  br label %bb117
bb117:
  %t535 = load i64, ptr %l291, !tbaa !24
  store i64 %t535, ptr %l36, !tbaa !24
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load %"compiler/source:Span", ptr %l22
  %t541 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t536, i32 1, %"compiler/source:Span" %t537)
  store { i64, i64, i64 } %t541, ptr %l295
  br label %bb118
bb118:
  %t542 = load { i64, i64, i64 }, ptr %l295
  store { i64, i64, i64 } %t542, ptr %l37
  %t543 = getelementptr { i64, i64, i64 }, ptr %l37, i32 0, i32 0
  %t544 = load i64, ptr %t543, !tbaa !24
  store i64 %t544, ptr %l38, !tbaa !24
  %t546 = getelementptr { i64, i64, i64 }, ptr %l37, i32 0, i32 1
  %t547 = load i64, ptr %t546, !tbaa !24
  store i64 %t547, ptr %l39, !tbaa !24
  %t549 = getelementptr { i64, i64, i64 }, ptr %l37, i32 0, i32 2
  %t550 = load i64, ptr %t549, !tbaa !24
  store i64 %t550, ptr %l40, !tbaa !24
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t552, i32 %t553)
  br label %bb119
bb119:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/check:Checker", ptr %t556, i32 0, i32 33
  %t559 = load %"compiler/source:Span", ptr %l22
  %t560 = load i32, ptr %l5, !tbaa !23
  %t561 = load i64, ptr %l7, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t562
  %t563 = getelementptr { i64, [3 x i64] }, ptr %t562, i32 0, i32 0
  store i64 7, ptr %t563
  %t565 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t559, 0
  %t567 = insertvalue { %"compiler/source:Span", i32, i64 } %t565, i32 %t560, 1
  %t569 = insertvalue { %"compiler/source:Span", i32, i64 } %t567, i64 %t561, 2
  %t570 = getelementptr { i64, [3 x i64] }, ptr %t562, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t569, ptr %t570
  %t571 = load { i64, [3 x i64] }, ptr %t562
  %t573 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t571, ptr %t573
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t558, ptr %t573)
  br label %bb120
bb120:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load i64, ptr %l38, !tbaa !24
  %t578 = load i64, ptr %l39, !tbaa !24
  %t579 = load i64, ptr %l40, !tbaa !24
  %t580 = load i64, ptr %l36, !tbaa !24
  %t586 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t576, i64 %t577, i64 %t578, i64 %t579, i64 %t580)
  store ptr %t586, ptr %l313
  br label %bb121
bb121:
  %t587 = load ptr, ptr %l313, !tbaa !29
  store ptr %t587, ptr %l41, !tbaa !29
  %t588 = load ptr, ptr %l0, !tbaa !29
  store ptr %t588, ptr %l314, !tbaa !29
  %t589 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t589, ptr %l315
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load %"compiler/source:Span", ptr %l22
  %t592 = load ptr, ptr %l32, !tbaa !29
  %t596 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t590, %"compiler/source:Span" %t591, ptr %t592)
  store ptr %t596, ptr %l319
  br label %bb122
bb122:
  %t597 = load ptr, ptr %l41, !tbaa !29
  %t598 = load ptr, ptr %l319, !tbaa !29
  %t600 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t598, ptr %t597, ptr null)
  store %"compiler/typed:If" %t600, ptr %l321
  br label %bb123
bb123:
  %t601 = load %"compiler/typed:If", ptr %l321
  %t602 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t601, ptr %t602
  store { i64, [3 x i64] } zeroinitializer, ptr %t603
  %t604 = getelementptr { i64, [3 x i64] }, ptr %t603, i32 0, i32 0
  store i64 3, ptr %t604
  %t605 = load %"compiler/source:Span", ptr %l315
  %t606 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t605, 0
  %t608 = insertvalue { %"compiler/source:Span", ptr } %t606, ptr %t602, 1
  %t609 = getelementptr { i64, [3 x i64] }, ptr %t603, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t608, ptr %t609
  %t610 = load { i64, [3 x i64] }, ptr %t603
  %t612 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t610, ptr %t612
  %t613 = load ptr, ptr %l314, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t613, ptr %t612)
  br label %bb124
bb124:
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t615)
  store ptr %t617, ptr %l326
  br label %bb125
bb125:
  %t618 = load ptr, ptr %l326, !tbaa !29
  %t620 = getelementptr %"compiler/typed:Body", ptr %t618, i32 0, i32 13
  %t621 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 0
  %t622 = load i32, ptr %t621, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t620, i32 %t622)
  br label %bb126
bb126:
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t625)
  store ptr %t627, ptr %l331
  br label %bb127
bb127:
  %t628 = load ptr, ptr %l331, !tbaa !29
  %t630 = getelementptr %"compiler/typed:Body", ptr %t628, i32 0, i32 14
  store ptr %t630, ptr %l333, !tbaa !29
  %t631 = getelementptr %"compiler/typed:ContractInfo", ptr %l3, i32 0, i32 0
  %t632 = load { i64, ptr }, ptr %t631, !tbaa !27
  store { i64, ptr } %t632, ptr %l334, !tbaa !27
  %t633 = getelementptr %"compiler/typed:ContractInfo", ptr %l3, i32 0, i32 4
  %t634 = load i64, ptr %l21, !tbaa !24
  %t637 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s14, ptr %t633, i64 %t634)
  store { i64, ptr } %t637, ptr %l337
  br label %bb128
bb128:
  %t638 = load { i64, ptr }, ptr %l334, !tbaa !27
  %t639 = extractvalue { i64, ptr } %t638, 1
  %t640 = extractvalue { i64, ptr } %t638, 0
  %t641 = extractvalue { i64, ptr } { i64 2, ptr @.d13 }, 1
  %t642 = extractvalue { i64, ptr } { i64 2, ptr @.d13 }, 0
  %t643 = add i64 %t640, %t642
  %t644 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t645 = extractvalue { i64, ptr } %t644, 1
  %t646 = extractvalue { i64, ptr } %t644, 0
  %t647 = add i64 %t643, %t646
  %t648 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t647)
  call void @olang_textcopy(ptr %t648, ptr %t639, i64 %t640)
  %t649 = getelementptr i8, ptr %t648, i64 %t640
  call void @olang_textcopy(ptr %t649, ptr %t641, i64 %t642)
  %t650 = getelementptr i8, ptr %t649, i64 %t642
  call void @olang_textcopy(ptr %t650, ptr %t645, i64 %t646)
  %t651 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t652 = insertvalue { i64, ptr } %t651, ptr %t648, 1
  %t654 = extractvalue { i64, ptr } %t652, 0
  %t655 = extractvalue { i64, ptr } %t652, 1
  %t656 = mul i64 %t654, 1
  %t657 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t656)
  call void @llvm.memcpy.p0.p0.i64(ptr %t657, ptr %t655, i64 %t656, i1 false)
  %t658 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t659 = insertvalue { i64, ptr } %t658, ptr %t657, 1
  %t660 = load ptr, ptr %l333, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t660, { i64, ptr } %t659)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s14)
  br label %bb130
bb130:
  %t662 = load i64, ptr %l20, !tbaa !24
  %t664 = add i64 %t662, 1
  store i64 %t664, ptr %l20, !tbaa !24
  br label %bb73
bb131:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqShaped(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca i32
  %l41 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i32
  %l61 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %a2)
  store i32 %t20, ptr %l13
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l14
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l15
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp eq i64 %t30, 2
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l24, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i32, ptr %t43, i64 1
  %t45 = load i32, ptr %t44, !tbaa !33
  %t48 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t40, i32 %t45)
  store i32 %t48, ptr %l26
  br label %bb6
bb5:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb21
bb6:
  %t49 = load ptr, ptr %l22, !tbaa !29
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l27
  br label %bb7
bb7:
  %t52 = load i32, ptr %l27
  %t54 = trunc i64 25 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb9:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l33, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l36, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l38, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 1
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t69, i32 %t74)
  store i32 %t77, ptr %l40
  br label %bb10
bb10:
  %t78 = load ptr, ptr %l36, !tbaa !29
  %t79 = load i32, ptr %l40, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t80, ptr %l41
  br label %bb11
bb11:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l1, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l46
  br label %bb12
bb12:
  %t91 = load ptr, ptr %l33, !tbaa !29
  %t92 = load i32, ptr %l41, !tbaa !23
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t91, i32 %t92, i32 %t93)
  store i1 %t94, ptr %l47
  br label %bb13
bb13:
  %t95 = load i1, ptr %l47, !tbaa !21
  store i1 %t95, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t96 = load i1, ptr %l30, !tbaa !21
  br i1 %t96, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb16:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l51, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t104, ptr %l53, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i32, ptr %t106, i64 1
  %t108 = load i32, ptr %t107, !tbaa !33
  %t111 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t103, i32 %t108)
  store i32 %t111, ptr %l55
  br label %bb17
bb17:
  %t112 = load ptr, ptr %l51, !tbaa !29
  %t113 = load i32, ptr %l55, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t114, ptr %l56
  br label %bb18
bb18:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l1, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l61
  br label %bb19
bb19:
  %t125 = load i32, ptr %l56, !tbaa !23
  %t126 = load i32, ptr %l61, !tbaa !23
  %t127 = icmp eq i32 %t125, %t126
  store i1 %t127, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t129 = load i1, ptr %l48, !tbaa !21
  store i1 %t129, ptr %l19, !tbaa !21
  br label %bb21
bb21:
  %t130 = load i1, ptr %l19, !tbaa !21
  store i1 %t130, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsCover(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l24 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a2)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t38 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t32, i32 %a1, i32 %t30)
  store i32 %t38, ptr %l24
  br label %bb6
bb6:
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = load i32, ptr %l24, !tbaa !23
  %t42 = icmp ne i32 %t40, %t39
  br i1 %t42, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb2
bb11:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %lp8 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i64
  %l25 = alloca ptr
  %l29 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"compiler/typed:Block"
  %l35 = alloca %"compiler/typed:Item"
  %l37 = alloca %"compiler/typed:Item"
  %l41 = alloca { i64, ptr }
  %l43 = alloca %"compiler/typed:Item"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l50 = alloca %"compiler/typed:Clause"
  %l53 = alloca %"compiler/source:Span"
  %l56 = alloca i32
  %l61 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t22 = alloca { i64, [3 x i64] }, align 8
  %t70 = alloca i64
  %t128 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 20, ptr @.d14 }, { i64, ptr } { i64 9, ptr @.d15 })
  store i32 %t6, ptr %l11
  br label %bb1
bb1:
  %t7 = load i32, ptr %l11, !tbaa !23
  store i32 %t7, ptr %l4, !tbaa !23
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 33
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l14
  br label %bb2
bb2:
  %t13 = load i64, ptr %l14, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 33
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = trunc i64 %a3 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 5, ptr %t23
  %t25 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t17, 0
  %t27 = insertvalue { %"compiler/source:Span", i32, i32 } %t25, i32 0, 1
  %t29 = insertvalue { %"compiler/source:Span", i32, i32 } %t27, i32 %t20, 2
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t29, ptr %t30
  %t31 = load { i64, [3 x i64] }, ptr %t22
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t31, ptr %t33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t16, ptr %t33)
  br label %bb3
bb3:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t36)
  store ptr %t38, ptr %l25
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 7
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = trunc i64 %t42 to i32
  store i32 %t44, ptr %l29, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 33
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t48, i64 %t49)
  store { i64, ptr } %t52, ptr %l33
  br label %bb5
bb5:
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t55 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t53, { i64, ptr } %t54)
  store %"compiler/typed:Block" %t55, ptr %l34
  br label %bb6
bb6:
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t56, ptr %lp6
  %t57 = load %"compiler/typed:Block", ptr %l34
  %t58 = load ptr, ptr %lp6
  store %"compiler/typed:Block" %t57, ptr %t58
  store %"compiler/typed:Item" zeroinitializer, ptr %l35
  %t59 = icmp sgt i64 1, 0
  br i1 %t59, label %bb7, label %bb8
bb7:
  %t61 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 0, i64 0)
  store %"compiler/typed:Item" %t61, ptr %l37
  br label %bb9
bb8:
  %t62 = icmp sge i64 1, 0
  br i1 %t62, label %bb10, label %bb11
bb9:
  %t64 = load %"compiler/typed:Item", ptr %l37
  store %"compiler/typed:Item" %t64, ptr %l35
  br label %bb8
bb10:
  %t65 = icmp sle i64 1, 576460752303423487
  br i1 %t65, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8e26fbb1c5557eef_13e6cc5de085742b)
  unreachable
bb12:
  %t67 = mul i64 1, 16
  %t68 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t67)
  %t69 = load %"compiler/typed:Item", ptr %l35
  store i64 0, ptr %t70
  br label %fill.71
fill.71:
  %t74 = load i64, ptr %t70
  %t75 = icmp slt i64 %t74, 1
  br i1 %t75, label %fillb.72, label %filld.73
fillb.72:
  %t76 = getelementptr %"compiler/typed:Item", ptr %t68, i64 %t74
  store %"compiler/typed:Item" %t69, ptr %t76
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %t70
  br label %fill.71
filld.73:
  %t78 = insertvalue { i64, ptr } undef, i64 1, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t68, 1
  store { i64, ptr } %t79, ptr %l7, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = load i32, ptr %l4, !tbaa !23
  %t84 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s0, i32 %t82, i64 -1)
  store %"compiler/typed:Item" %t84, ptr %l43
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8e26fbb1c5557eef_13e6cc5de085742b)
  unreachable
bb14:
  %t85 = load %"compiler/typed:Item", ptr %l43
  %t86 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr %"compiler/typed:Item", ptr %t87, i64 0
  store %"compiler/typed:Item" %t85, ptr %t88
  %t89 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t89, ptr %l44
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l45, !tbaa !27
  %t91 = load ptr, ptr %lp6
  store ptr %t91, ptr %l46, !tbaa !29
  %t92 = icmp sge i64 0, 0
  br i1 %t92, label %bb15, label %bb16
bb15:
  %t94 = icmp sle i64 0, 1152921504606846975
  br i1 %t94, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_6d702b04e725ae1a_71c02c55b3dfc416)
  unreachable
bb17:
  %t96 = mul i64 0, 8
  %t97 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t96)
  %t98 = insertvalue { i64, ptr } undef, i64 0, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load %"compiler/source:Span", ptr %l44
  %t101 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t102 = load ptr, ptr %l46, !tbaa !29
  %t104 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t100, { i64, ptr } %t101, i1 false, ptr %t102, { i64, ptr } %t99, i64 -1, i32 0)
  store %"compiler/typed:Clause" %t104, ptr %l50
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_6d702b04e725ae1a_71c02c55b3dfc416)
  unreachable
bb19:
  %t105 = load %"compiler/typed:Clause", ptr %l50
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/typed:Clause" %t105, ptr %t106
  %t108 = insertvalue [1 x ptr] undef, ptr %t106, 0
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t109, ptr %lp8
  %t111 = load ptr, ptr %lp8
  store [1 x ptr] %t108, ptr %t111
  %t112 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t112, ptr %l53
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t116 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t113)
  store i32 %t116, ptr %l56
  br label %bb20
bb20:
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t119 = load ptr, ptr %lp8
  %t121 = insertvalue { i64, ptr } undef, i64 1, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  %t125 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t117, { i64, ptr } %t122, i1 false, i1 true)
  store %"compiler/typed:Try" %t125, ptr %l61
  br label %bb21
bb21:
  %t126 = load %"compiler/typed:Try", ptr %l61
  %t127 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t126, ptr %t127
  store { i64, [5 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 0
  store i64 14, ptr %t129
  %t130 = load %"compiler/source:Span", ptr %l53
  %t131 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t130, 0
  %t132 = load i32, ptr %l56, !tbaa !23
  %t133 = insertvalue { %"compiler/source:Span", i32, ptr } %t131, i32 %t132, 1
  %t135 = insertvalue { %"compiler/source:Span", i32, ptr } %t133, ptr %t127, 2
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t135, ptr %t136
  %t137 = load { i64, [5 x i64] }, ptr %t128
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t137, ptr %t139
  call void @__olang_scope_close(ptr %s0)
  store ptr %t139, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportParam(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l10 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l24 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i1
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t8, i32 %t9)
  store i1 %t12, ptr %l10
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb9
bb9:
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %l2, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t28, i32 %t29, i64 0)
  store i1 %t32, ptr %l20
  br label %bb10
bb10:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l24
  br label %bb14
bb14:
  %t40 = load i32, ptr %l24, !tbaa !23
  store i32 %t40, ptr %l3, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l29
  br label %bb15
bb15:
  %t51 = load i32, ptr %l29
  %t53 = trunc i64 19 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l38
  br label %bb18
bb17:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb20
bb18:
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = load i32, ptr %l38, !tbaa !23
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t69, ptr %l39
  br label %bb19
bb19:
  %t70 = load i1, ptr %l39, !tbaa !21
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l32, !tbaa !21
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprPattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %lp19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %lp26 = alloca ptr
  %l29 = alloca i32
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca i1
  %l49 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i1
  %l67 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i1
  %l86 = alloca i64
  %l93 = alloca ptr
  %l96 = alloca ptr
  %l99 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca i32
  %l106 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca i64
  %l119 = alloca { i64, ptr }
  %l122 = alloca %"compiler/msgs:Msg"
  %l123 = alloca i64
  %l127 = alloca ptr
  %l131 = alloca i1
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l137 = alloca ptr
  %l142 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca i32
  %l157 = alloca %"compiler/typed:Payload"
  %l165 = alloca i64
  %l168 = alloca i64
  %l186 = alloca { i64, ptr }
  %l189 = alloca %"compiler/source:Span"
  %l190 = alloca { i64, ptr }
  %l196 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca ptr
  %l200 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l209 = alloca ptr
  %l210 = alloca ptr
  %l219 = alloca ptr
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca ptr
  %t55 = alloca { i64, [4 x i64] }, align 8
  %t237 = alloca { i64, [4 x i64] }, align 8
  %t287 = alloca { i64, [4 x i64] }, align 8
  %t368 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l29
  br label %bb1
bb1:
  %t6 = load i32, ptr %l29, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l31
  br label %bb2
bb2:
  %t10 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t10, ptr %l8
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t12 = load ptr, ptr %l32, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l32, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l33, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l33, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32 }, ptr %t22, i32 0, i32 0
  %t24 = load %"compiler/source:Span", ptr %t23
  store %"compiler/source:Span" %t24, ptr %l9
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32 }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l10, !tbaa !23
  br label %bb7
bb6:
  br label %bb18
bb7:
  %t34 = xor i1 %a6, true
  br i1 %t34, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l10, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t40, ptr %l44
  br label %bb10
bb9:
  br label %bb17
bb10:
  %t41 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 1, ptr @.d16 })
  store i1 %t42, ptr %l45
  br label %bb11
bb11:
  %t43 = load i1, ptr %l45, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l9
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t44, %"compiler/source:Span" %t45, i32 %t46, i64 1)
  store ptr %t50, ptr %l49
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  %t51 = load ptr, ptr %l49, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l9
  %t54 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 0
  store i64 3, ptr %t56
  %t58 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t53, 0
  %t60 = insertvalue { %"compiler/source:Span", i32 } %t58, i32 %t54, 1
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t60, ptr %t61
  %t62 = load { i64, [4 x i64] }, ptr %t55
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t62, ptr %t64
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t68 = load i64, ptr %l5, !tbaa !24
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v0, ptr %t52, ptr %t64, ptr %t65, i32 %t66, ptr %t67, i64 %t68)
  store ptr %t75, ptr %l59
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  %t76 = load ptr, ptr %l59, !tbaa !29
  store ptr %t76, ptr %rv
  br label %ret
bb17:
  br label %bb76
bb18:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t78 = load ptr, ptr %l60, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t81 = load ptr, ptr %l60, !tbaa !29
  %t82 = load i64, ptr %t81
  %t84 = icmp eq i64 %t82, 15
  store i1 %t84, ptr %l61, !tbaa !21
  br label %bb20
bb20:
  %t85 = load i1, ptr %l61, !tbaa !21
  br i1 %t85, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb29
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t88 = load i32, ptr %l7, !tbaa !23
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t86, ptr %t87, i32 %t88)
  store i64 %t92, ptr %l67
  br label %bb24
bb24:
  %t93 = load i64, ptr %l67, !tbaa !24
  store i64 %t93, ptr %l11, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sge i64 %t94, 0
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l8
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load i64, ptr %l11, !tbaa !24
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, ptr %t100, i64 %t101)
  store ptr %t106, ptr %l74
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t107 = load ptr, ptr %l74, !tbaa !29
  store ptr %t107, ptr %rv
  br label %ret
bb28:
  br label %bb76
bb29:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t109 = load ptr, ptr %l75, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t112 = load ptr, ptr %l75, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 12
  store i1 %t115, ptr %l76, !tbaa !21
  br label %bb31
bb31:
  %t116 = load i1, ptr %l76, !tbaa !21
  br i1 %t116, label %bb32, label %bb33
bb32:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l12, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t125, i32 0, i32 2
  %t127 = load { i64, ptr }, ptr %t126
  store { i64, ptr } %t127, ptr %l13, !tbaa !27
  br label %bb34
bb33:
  br label %bb75
bb34:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l12, !tbaa !29
  %t131 = load i32, ptr %l7, !tbaa !23
  %t135 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t129, ptr %t130, i32 %t131)
  store i64 %t135, ptr %l86
  br label %bb35
bb35:
  %t136 = load i64, ptr %l86, !tbaa !24
  store i64 %t136, ptr %l14, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l8
  %t143 = load ptr, ptr %l2, !tbaa !29
  %t144 = load i64, ptr %l14, !tbaa !24
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t141, %"compiler/source:Span" %t142, ptr %t143, i64 %t144)
  store ptr %t149, ptr %l93
  br label %bb38
bb37:
  br label %bb74
bb38:
  %t150 = load ptr, ptr %l93, !tbaa !29
  store ptr %t150, ptr %l15, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  store ptr %t156, ptr %l96, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  store ptr %t162, ptr %l99, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load i32, ptr %l7, !tbaa !23
  %t168 = load i64, ptr %l14, !tbaa !24
  %t172 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t166, i32 %t167, i64 %t168)
  store i32 %t172, ptr %l104
  br label %bb39
bb39:
  %t173 = load ptr, ptr %l99, !tbaa !29
  %t174 = load i32, ptr %l104, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t175, ptr %l105
  br label %bb40
bb40:
  %t176 = load ptr, ptr %l96, !tbaa !29
  %t177 = load i32, ptr %l105, !tbaa !23
  %t178 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t176, i32 %t177)
  store { i64, ptr } %t178, ptr %l106
  br label %bb41
bb41:
  %t179 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t179, ptr %l16, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t188 = icmp ne i64 %t182, %t185
  br i1 %t188, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l112, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t191, ptr %l113
  %t192 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t192, 0
  store i64 %t194, ptr %l115, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t199 = icmp eq i64 %t197, 1
  br i1 %t199, label %bb44, label %bb45
bb43:
  br label %bb50
bb44:
  store { i64, ptr } { i64 0, ptr @.d17 }, ptr %l119, !tbaa !27
  br label %bb46
bb45:
  store { i64, ptr } { i64 1, ptr @.d18 }, ptr %l119, !tbaa !27
  br label %bb46
bb46:
  %t201 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = load i64, ptr %l115, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t207 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s8, ptr %s8, i64 %t204, { i64, ptr } %t205, i64 %t203)
  store %"compiler/msgs:Msg" %t207, ptr %l122
  br label %bb47
bb47:
  %t208 = load ptr, ptr %l112, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l113
  %t210 = load %"compiler/msgs:Msg", ptr %l122
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t208, %"compiler/source:Span" %t209, %"compiler/msgs:Msg" %t210)
  store i64 %t211, ptr %l123
  br label %bb48
bb48:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l8
  %t214 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t218 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t212, %"compiler/source:Span" %t213, i32 %t214, i64 0)
  store ptr %t218, ptr %l127
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  %t219 = load ptr, ptr %l127, !tbaa !29
  store ptr %t219, ptr %rv
  br label %ret
bb50:
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l17, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i32, ptr %l3, !tbaa !23
  %t226 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t222, i32 %t223)
  store i1 %t226, ptr %l131
  br label %bb51
bb51:
  %t227 = load i1, ptr %l131, !tbaa !21
  br i1 %t227, label %bb52, label %bb53
bb52:
  %t228 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t228, ptr %l132
  %t229 = load i32, ptr %l7, !tbaa !23
  store i32 %t229, ptr %l133, !tbaa !23
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l8
  %t232 = load ptr, ptr %l2, !tbaa !29
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t230, %"compiler/source:Span" %t231, ptr %t232)
  store ptr %t236, ptr %l137
  br label %bb54
bb53:
  br label %bb55
bb54:
  store { i64, [4 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 0
  store i64 2, ptr %t238
  %t239 = load %"compiler/source:Span", ptr %l132
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t239, 0
  %t241 = load i32, ptr %l133, !tbaa !23
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, i32 %t241, 1
  %t243 = load ptr, ptr %l137, !tbaa !29
  %t244 = insertvalue { %"compiler/source:Span", i32, ptr } %t242, ptr %t243, 2
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t244, ptr %t245
  %t246 = load { i64, [4 x i64] }, ptr %t237
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t246, ptr %t248
  store ptr %t248, ptr %l17, !tbaa !29
  br label %bb55
bb55:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 2
  store ptr %t255, ptr %l142, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/generic:Program", ptr %t259, i32 0, i32 2
  %t262 = load i32, ptr %l7, !tbaa !23
  %t265 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t261, i32 %t262)
  store i32 %t265, ptr %l147
  br label %bb56
bb56:
  %t266 = load ptr, ptr %l142, !tbaa !29
  %t267 = load i32, ptr %l147, !tbaa !23
  %t268 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t266, i32 %t267)
  store { i64, ptr } %t268, ptr %l148
  br label %bb57
bb57:
  %t269 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t269, ptr %l149, !tbaa !27
  %t270 = load i64, ptr %l14, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i32, ptr %t273, i64 %t270
  %t275 = load i32, ptr %t274, !tbaa !33
  %t277 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t277, ptr %l152
  store i32 %t275, ptr %l153, !tbaa !23
  %t279 = load ptr, ptr %l17, !tbaa !29
  %t280 = load i64, ptr %l14, !tbaa !24
  %t284 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t279, i64 %t280, i32 0)
  store %"compiler/typed:Payload" %t284, ptr %l157
  br label %bb58
bb58:
  %t285 = load %"compiler/typed:Payload", ptr %l157
  %t286 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t285, ptr %t286
  store { i64, [4 x i64] } zeroinitializer, ptr %t287
  %t288 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 0
  store i64 5, ptr %t288
  %t289 = load %"compiler/source:Span", ptr %l152
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t289, 0
  %t291 = load i32, ptr %l153, !tbaa !23
  %t292 = insertvalue { %"compiler/source:Span", i32, ptr } %t290, i32 %t291, 1
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr } %t292, ptr %t286, 2
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t294, ptr %t295
  %t296 = load { i64, [4 x i64] }, ptr %t287
  %t297 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t297, ptr %lp19
  %t299 = load ptr, ptr %lp19
  store { i64, [4 x i64] } %t296, ptr %t299
  store i64 0, ptr %l20, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  store i64 %t302, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t304 = load i64, ptr %l21, !tbaa !24
  %t305 = load i64, ptr %l20, !tbaa !24
  %t308 = icmp sgt i64 %t304, %t305
  br i1 %t308, label %bb59, label %bb60
bb59:
  %t310 = load i64, ptr %l22, !tbaa !24
  %t312 = icmp sgt i64 %t310, 0
  br i1 %t312, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l165, !tbaa !24
  br label %bb64
bb61:
  %t314 = load i64, ptr %l21, !tbaa !24
  %t315 = load i64, ptr %l20, !tbaa !24
  %t318 = sub i64 %t314, %t315
  %t319 = load i64, ptr %l22, !tbaa !24
  %t322 = add i64 %t318, %t319
  %t324 = sub i64 %t322, 1
  %t325 = load i64, ptr %l22, !tbaa !24
  %t328 = sdiv i64 %t324, %t325
  store i64 %t328, ptr %l168, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb63
bb63:
  %t330 = load i64, ptr %l168, !tbaa !24
  store i64 %t330, ptr %l165, !tbaa !24
  br label %bb64
bb64:
  %t331 = load i64, ptr %l165, !tbaa !24
  store i64 %t331, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb65
bb65:
  store %olang.scope zeroinitializer, ptr %s11
  %t332 = load i64, ptr %l24, !tbaa !24
  %t333 = load i64, ptr %l23, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb67:
  br label %bb68
bb68:
  %t340 = load i64, ptr %l20, !tbaa !24
  %t341 = load i64, ptr %l24, !tbaa !24
  %t342 = load i64, ptr %l22, !tbaa !24
  %t345 = mul i64 %t341, %t342
  %t348 = add i64 %t340, %t345
  store i64 %t348, ptr %l25, !tbaa !24
  %t350 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t350, ptr %l186, !tbaa !27
  %t351 = load i64, ptr %l25, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 %t351
  %t356 = load ptr, ptr %t355, !tbaa !39
  %t358 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t356)
  store %"compiler/source:Span" %t358, ptr %l189
  br label %bb69
bb69:
  %t359 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t359, ptr %l190, !tbaa !27
  %t360 = load i64, ptr %l25, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr i32, ptr %t363, i64 %t360
  %t365 = load i32, ptr %t364, !tbaa !33
  %t366 = load ptr, ptr %lp19
  %t367 = load i64, ptr %l25, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t368
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 0
  store i64 3, ptr %t369
  %t370 = load %"compiler/source:Span", ptr %l189
  %t371 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t370, 0
  %t373 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t371, i32 %t365, 1
  %t375 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t373, ptr %t366, 2
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t375, i64 %t367, 3
  %t378 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t377, ptr %t378
  %t379 = load { i64, [4 x i64] }, ptr %t368
  %t380 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t380, ptr %lp26
  %t382 = load ptr, ptr %lp26
  store { i64, [4 x i64] } %t379, ptr %t382
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l196, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t384, ptr %l197
  %t385 = load ptr, ptr %l15, !tbaa !29
  store ptr %t385, ptr %l198, !tbaa !29
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t387, ptr %l200, !tbaa !27
  %t388 = load i64, ptr %l25, !tbaa !24
  %t390 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr ptr, ptr %t391, i64 %t388
  %t393 = load ptr, ptr %t392, !tbaa !39
  %t394 = load ptr, ptr %lp26
  %t395 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t395, ptr %l204, !tbaa !27
  %t396 = load i64, ptr %l25, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i32, ptr %t399, i64 %t396
  %t401 = load i32, ptr %t400, !tbaa !33
  %t402 = load ptr, ptr %l4, !tbaa !29
  %t403 = load i64, ptr %l5, !tbaa !24
  %t410 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprPattern(ptr %v0, ptr %v1, ptr %t386, ptr %t393, ptr %t394, i32 %t401, ptr %t402, i64 %t403, i1 false)
  store ptr %t410, ptr %l209
  br label %bb70
bb70:
  %t411 = load ptr, ptr %l196, !tbaa !29
  %t412 = load %"compiler/source:Span", ptr %l197
  %t413 = load ptr, ptr %l198, !tbaa !29
  %t414 = load ptr, ptr %l209, !tbaa !29
  %t415 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %t411, %"compiler/source:Span" %t412, ptr %t413, ptr %t414)
  store ptr %t415, ptr %l210
  br label %bb71
bb71:
  %t416 = load ptr, ptr %l210, !tbaa !29
  store ptr %t416, ptr %l15, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb72:
  %t417 = load i64, ptr %l24, !tbaa !24
  %t419 = add i64 %t417, 1
  store i64 %t419, ptr %l24, !tbaa !24
  br label %bb65
bb73:
  %t421 = load ptr, ptr %l15, !tbaa !29
  store ptr %t421, ptr %rv
  br label %ret
bb74:
  br label %bb76
bb75:
  br label %bb76
bb76:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load %"compiler/source:Span", ptr %l8
  %t425 = load ptr, ptr %l2, !tbaa !29
  %t426 = load ptr, ptr %l1, !tbaa !29
  %t427 = load i32, ptr %l3, !tbaa !23
  %t433 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %t423, %"compiler/source:Span" %t424, ptr %t425, ptr %t426, i32 %t427)
  store ptr %t433, ptr %l219
  br label %bb77
bb77:
  %t434 = load ptr, ptr %l219, !tbaa !29
  store ptr %t434, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l56 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i1
  %l81 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca %"compiler/msgs:Msg"
  %l86 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l103 = alloca ptr
  %l111 = alloca ptr
  %l114 = alloca i32
  %l117 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l130 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l135 = alloca %"compiler/msgs:Msg"
  %l136 = alloca %"compiler/msgs:Msg"
  %l137 = alloca %"compiler/msgs:Msg"
  %l138 = alloca i64
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %t101 = alloca { i64, [3 x i64] }, align 8
  %t176 = alloca { i64, [3 x i64] }, align 8
  %t210 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t18 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %t16, %"compiler/source:Span" %t17, ptr %t18)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l22, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l23, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l4
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb20
bb12:
  %t43 = load i32, ptr %l4
  %t45 = trunc i64 70 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb15
bb14:
  %t48 = load i32, ptr %l4
  %t50 = trunc i64 71 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l32, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t57 = load i32, ptr %l4
  %t59 = trunc i64 70 to i32
  %t60 = icmp eq i32 %t57, %t59
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %t54, %"compiler/source:Span" %t55, ptr %t56, i1 %t60)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb62
bb20:
  %t65 = load ptr, ptr %l2, !tbaa !29
  store ptr %t65, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l40, !tbaa !29
  %t70 = load i64, ptr %t69
  %t72 = icmp eq i64 %t70, 4
  store i1 %t72, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t73 = load i1, ptr %l41, !tbaa !21
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l6
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l7, !tbaa !29
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t86 = load i32, ptr %l6
  %t88 = trunc i64 75 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l50, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t92, ptr %l51
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t96 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t100 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t93, ptr %t94, i32 %t96)
  store ptr %t100, ptr %l56
  br label %bb28
bb27:
  br label %bb30
bb28:
  store { i64, [3 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 0
  store i64 2, ptr %t102
  %t103 = load %"compiler/source:Span", ptr %l51
  %t104 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t103, 0
  %t105 = load ptr, ptr %l56, !tbaa !29
  %t106 = insertvalue { %"compiler/source:Span", ptr } %t104, ptr %t105, 1
  %t107 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t106, ptr %t107
  %t108 = load { i64, [3 x i64] }, ptr %t101
  %t110 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t108, ptr %t110
  %t111 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t111, ptr %t110)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load %"compiler/source:Span", ptr %l1
  %t115 = load ptr, ptr %l7, !tbaa !29
  %t116 = load i32, ptr %l6
  %t118 = trunc i64 70 to i32
  %t119 = icmp eq i32 %t116, %t118
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %t113, %"compiler/source:Span" %t114, ptr %t115, i1 %t119)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t124 = load ptr, ptr %l2, !tbaa !29
  store ptr %t124, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t125 = load ptr, ptr %l64, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb33, label %bb34
bb33:
  %t128 = load ptr, ptr %l64, !tbaa !29
  %t129 = load i64, ptr %t128
  %t131 = icmp eq i64 %t129, 12
  store i1 %t131, ptr %l65, !tbaa !21
  br label %bb34
bb34:
  %t132 = load i1, ptr %l65, !tbaa !21
  br i1 %t132, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb53
bb37:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l2, !tbaa !29
  %t136 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t140 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t133, ptr %t134, i32 %t136)
  store ptr %t140, ptr %l72
  br label %bb38
bb38:
  %t141 = load ptr, ptr %l72, !tbaa !29
  store ptr %t141, ptr %l8, !tbaa !29
  %t142 = load ptr, ptr %l8, !tbaa !29
  store ptr %t142, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t143 = load ptr, ptr %l73, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb39, label %bb40
bb39:
  %t146 = load ptr, ptr %l73, !tbaa !29
  %t147 = load i64, ptr %t146
  %t149 = icmp eq i64 %t147, 9
  store i1 %t149, ptr %l74, !tbaa !21
  br label %bb40
bb40:
  %t150 = load i1, ptr %l74, !tbaa !21
  br i1 %t150, label %bb41, label %bb42
bb41:
  %t151 = load ptr, ptr %l8, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t153, i32 0, i32 2
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l9
  br label %bb43
bb42:
  br label %bb50
bb43:
  %t157 = load i32, ptr %l9
  %t159 = trunc i64 24 to i32
  %t160 = icmp eq i32 %t157, %t159
  br i1 %t160, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l81, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l2, !tbaa !29
  %t167 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  store %"compiler/source:Span" %t167, ptr %l84
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t168 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %s8)
  store %"compiler/msgs:Msg" %t168, ptr %l85
  br label %bb47
bb47:
  %t169 = load ptr, ptr %l81, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l84
  %t171 = load %"compiler/msgs:Msg", ptr %l85
  %t172 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t169, %"compiler/source:Span" %t170, %"compiler/msgs:Msg" %t171)
  store i64 %t172, ptr %l86
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  %t175 = load ptr, ptr %l8, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 0
  store i64 2, ptr %t177
  %t179 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t174, 0
  %t181 = insertvalue { %"compiler/source:Span", ptr } %t179, ptr %t175, 1
  %t182 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t181, ptr %t182
  %t183 = load { i64, [3 x i64] }, ptr %t176
  %t185 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t183, ptr %t185
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t173, ptr %t185)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb53:
  %t188 = load ptr, ptr %l2, !tbaa !29
  store ptr %t188, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t189 = load ptr, ptr %l92, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb54, label %bb55
bb54:
  %t192 = load ptr, ptr %l92, !tbaa !29
  %t193 = load i64, ptr %t192
  %t195 = icmp eq i64 %t193, 22
  store i1 %t195, ptr %l93, !tbaa !21
  br label %bb55
bb55:
  %t196 = load i1, ptr %l93, !tbaa !21
  br i1 %t196, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 36
  store i1 true, ptr %t199, !tbaa !21
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l97, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t201, ptr %l98
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l2, !tbaa !29
  %t205 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t202, ptr %t203, i32 %t205)
  store ptr %t209, ptr %l103
  br label %bb59
bb59:
  store { i64, [3 x i64] } zeroinitializer, ptr %t210
  %t211 = getelementptr { i64, [3 x i64] }, ptr %t210, i32 0, i32 0
  store i64 2, ptr %t211
  %t212 = load %"compiler/source:Span", ptr %l98
  %t213 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t212, 0
  %t214 = load ptr, ptr %l103, !tbaa !29
  %t215 = insertvalue { %"compiler/source:Span", ptr } %t213, ptr %t214, 1
  %t216 = getelementptr { i64, [3 x i64] }, ptr %t210, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t215, ptr %t216
  %t217 = load { i64, [3 x i64] }, ptr %t210
  %t219 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t217, ptr %t219
  %t220 = load ptr, ptr %l97, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t220, ptr %t219)
  br label %bb60
bb60:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 36
  store i1 false, ptr %t224, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb61:
  br label %bb62
bb62:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l2, !tbaa !29
  %t228 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t225, ptr %t226, i32 %t228)
  store ptr %t232, ptr %l111
  br label %bb63
bb63:
  %t233 = load ptr, ptr %l111, !tbaa !29
  %t237 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t233)
  store i32 %t237, ptr %l114
  br label %bb64
bb64:
  %t238 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t239 = load i32, ptr %l114, !tbaa !23
  %t241 = icmp eq i32 %t239, %t238
  br i1 %t241, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb66:
  br label %bb67
bb67:
  %t243 = load ptr, ptr %l2, !tbaa !29
  store ptr %t243, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t244 = load ptr, ptr %l118, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb68, label %bb69
bb68:
  %t247 = load ptr, ptr %l118, !tbaa !29
  %t248 = load i64, ptr %t247
  %t250 = icmp eq i64 %t248, 1
  store i1 %t250, ptr %l119, !tbaa !21
  br label %bb69
bb69:
  %t251 = load i1, ptr %l119, !tbaa !21
  br i1 %t251, label %bb70, label %bb71
bb70:
  %t252 = load ptr, ptr %l2, !tbaa !29
  %t254 = getelementptr { i64, [5 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", i32 }, ptr %t254, i32 0, i32 1
  %t256 = load i32, ptr %t255
  store i32 %t256, ptr %l11
  br label %bb72
bb71:
  br label %bb73
bb72:
  %t258 = load i32, ptr %l11
  %t260 = trunc i64 5 to i32
  %t261 = icmp eq i32 %t258, %t260
  store i1 %t261, ptr %l117, !tbaa !21
  br label %bb84
bb73:
  %t263 = load ptr, ptr %l2, !tbaa !29
  store ptr %t263, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t264 = load ptr, ptr %l126, !tbaa !29
  %t265 = icmp ne ptr %t264, null
  br i1 %t265, label %bb74, label %bb75
bb74:
  %t267 = load ptr, ptr %l126, !tbaa !29
  %t268 = load i64, ptr %t267
  %t270 = icmp eq i64 %t268, 21
  store i1 %t270, ptr %l127, !tbaa !21
  br label %bb75
bb75:
  %t271 = load i1, ptr %l127, !tbaa !21
  br i1 %t271, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb84
bb79:
  br i1 true, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_602058b5bbdc5ba4_407e96c83aaf1680)
  unreachable
bb84:
  %t272 = load i1, ptr %l117, !tbaa !21
  store i1 %t272, ptr %l12, !tbaa !21
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l130, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l2, !tbaa !29
  %t278 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotStmtSpan(ptr %v0, ptr %v1, ptr %t274, ptr %t275)
  store %"compiler/source:Span" %t278, ptr %l133
  br label %bb85
bb85:
  %t279 = load i1, ptr %l12, !tbaa !21
  br i1 %t279, label %bb86, label %bb87
bb86:
  %t281 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNextLine(ptr %s0)
  store %"compiler/msgs:Msg" %t281, ptr %l136
  br label %bb88
bb87:
  %t282 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %s0)
  store %"compiler/msgs:Msg" %t282, ptr %l137
  br label %bb89
bb88:
  %t283 = load %"compiler/msgs:Msg", ptr %l136
  store %"compiler/msgs:Msg" %t283, ptr %l135
  br label %bb90
bb89:
  %t284 = load %"compiler/msgs:Msg", ptr %l137
  store %"compiler/msgs:Msg" %t284, ptr %l135
  br label %bb90
bb90:
  %t285 = load ptr, ptr %l130, !tbaa !29
  %t286 = load %"compiler/source:Span", ptr %l133
  %t287 = load %"compiler/msgs:Msg", ptr %l135
  %t288 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t285, %"compiler/source:Span" %t286, %"compiler/msgs:Msg" %t287)
  store i64 %t288, ptr %l138
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l6 = alloca i1
  %l11 = alloca i1
  %l16 = alloca i32
  %l19 = alloca i1
  %l25 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load i32, ptr %l1, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l11
  br label %bb5
bb5:
  %t15 = load i1, ptr %l11, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l16
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l2, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t27, i32 %t28, i64 0)
  store i1 %t31, ptr %l19
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l25
  br label %bb14
bb14:
  %t44 = load i32, ptr %l25
  %t46 = trunc i64 19 to i32
  %t47 = icmp eq i32 %t44, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l34
  br label %bb18
bb18:
  %t62 = load i32, ptr %l34, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t63, i32 %t62)
  store i1 %t67, ptr %l37
  br label %bb19
bb19:
  %t68 = load i1, ptr %l37, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldDeclAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l26 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l63 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca i1
  %l83 = alloca { i64, ptr }
  %l97 = alloca { i64, [3 x i64] }
  %l102 = alloca i1
  %l114 = alloca { i64, ptr }
  %l125 = alloca { i64, [3 x i64] }
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, [3 x i64] }
  %t33 = alloca { i64, [3 x i64] }, align 8
  %t75 = alloca { i64, [3 x i64] }, align 8
  %t243 = alloca { i64, [3 x i64] }, align 8
  %t259 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l26
  br label %bb1
bb1:
  %t11 = load i32, ptr %l26, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t15, i32 %t16)
  store ptr %t19, ptr %l30
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l30, !tbaa !29
  store ptr %t20, ptr %l4, !tbaa !29
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb5
bb4:
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TypeDecl", ptr %t25, i32 0, i32 3
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  store i1 %t30, ptr %l33, !tbaa !21
  br label %bb5
bb5:
  %t32 = load i1, ptr %l33, !tbaa !21
  br i1 %t32, label %bb6, label %bb7
bb6:
  store { i64, [3 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [3 x i64] }, ptr %t33, i32 0, i32 0
  store i64 0, ptr %t34
  %t35 = load { i64, [3 x i64] }, ptr %t33
  store { i64, [3 x i64] } %t35, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t40, i32 %t41)
  store i64 %t44, ptr %l41
  br label %bb9
bb9:
  %t45 = load i64, ptr %l41, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TypeDecl", ptr %t46, i32 0, i32 3
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l6, !tbaa !29
  %t51 = load ptr, ptr %l6, !tbaa !29
  store ptr %t51, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t52 = load ptr, ptr %l44, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb10, label %bb11
bb10:
  %t55 = load ptr, ptr %l44, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 0
  store i1 %t58, ptr %l45, !tbaa !21
  br label %bb11
bb11:
  %t59 = load i1, ptr %l45, !tbaa !21
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = getelementptr { i64, [6 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { ptr }, ptr %t62, i32 0, i32 0
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l7, !tbaa !29
  br label %bb14
bb13:
  br label %bb63
bb14:
  %t66 = load ptr, ptr %l7, !tbaa !29
  %t68 = getelementptr %"compiler/ast:StructBody", ptr %t66, i32 0, i32 2
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t73 = icmp eq i64 %t71, 0
  br i1 %t73, label %bb15, label %bb16
bb15:
  store { i64, [3 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t75, i32 0, i32 0
  store i64 0, ptr %t76
  %t77 = load { i64, [3 x i64] }, ptr %t75
  store { i64, [3 x i64] } %t77, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l8, !tbaa !24
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t81 = getelementptr %"compiler/ast:StructBody", ptr %t79, i32 0, i32 2
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l11, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb20:
  br label %bb21
bb21:
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t96, ptr %l63, !tbaa !27
  %t97 = load i64, ptr %l10, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  store ptr %t102, ptr %l12, !tbaa !29
  %t104 = load ptr, ptr %l12, !tbaa !29
  store ptr %t104, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t105 = load ptr, ptr %l66, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb22, label %bb23
bb22:
  %t108 = load ptr, ptr %l66, !tbaa !29
  %t109 = load i64, ptr %t108
  %t111 = icmp eq i64 %t109, 1
  store i1 %t111, ptr %l67, !tbaa !21
  br label %bb23
bb23:
  %t112 = load i1, ptr %l67, !tbaa !21
  br i1 %t112, label %bb24, label %bb25
bb24:
  %t113 = load ptr, ptr %l12, !tbaa !29
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", ptr }, ptr %t115, i32 0, i32 1
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l13, !tbaa !29
  br label %bb26
bb25:
  br label %bb59
bb26:
  %t119 = load ptr, ptr %l13, !tbaa !29
  %t121 = getelementptr %"compiler/ast:VarDecl", ptr %t119, i32 0, i32 5
  %t122 = load i1, ptr %t121, !tbaa !21
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb28:
  br label %bb29
bb29:
  %t126 = load ptr, ptr %l13, !tbaa !29
  %t128 = getelementptr %"compiler/ast:VarDecl", ptr %t126, i32 0, i32 0
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l16, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t135 = load i64, ptr %l15, !tbaa !24
  %t136 = load i64, ptr %l16, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb32:
  br label %bb33
bb33:
  %t143 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t143, ptr %l83, !tbaa !27
  %t144 = load i64, ptr %l15, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 %t144
  %t149 = load i32, ptr %t148, !tbaa !33
  store i32 %t149, ptr %l17, !tbaa !23
  %t151 = load i64, ptr %l8, !tbaa !24
  %t155 = icmp eq i64 %t151, %a2
  br i1 %t155, label %bb34, label %bb35
bb34:
  %t157 = load ptr, ptr %l13, !tbaa !29
  %t159 = getelementptr %"compiler/ast:VarDecl", ptr %t157, i32 0, i32 2
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb36, label %bb37
bb35:
  br label %bb56
bb36:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i64, ptr %l5, !tbaa !24
  %t168 = load ptr, ptr %l13, !tbaa !29
  %t170 = getelementptr %"compiler/ast:VarDecl", ptr %t168, i32 0, i32 2
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t175 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t166, i64 %t167, ptr %t171)
  store { i64, [3 x i64] } %t175, ptr %l97
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  %t176 = load { i64, [3 x i64] }, ptr %l97
  store { i64, [3 x i64] } %t176, ptr %rv
  br label %ret
bb39:
  %t177 = load ptr, ptr %l7, !tbaa !29
  %t179 = getelementptr %"compiler/ast:StructBody", ptr %t177, i32 0, i32 0
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t184 = icmp sgt i64 %t182, 0
  br i1 %t184, label %bb40, label %bb41
bb40:
  %t186 = load ptr, ptr %l13, !tbaa !29
  %t188 = getelementptr %"compiler/ast:VarDecl", ptr %t186, i32 0, i32 4
  %t189 = load i1, ptr %t188, !tbaa !21
  %t191 = xor i1 %t189, true
  store i1 %t191, ptr %l102, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb42
bb42:
  %t193 = load i1, ptr %l102, !tbaa !21
  br i1 %t193, label %bb43, label %bb44
bb43:
  %t194 = load ptr, ptr %l7, !tbaa !29
  %t196 = getelementptr %"compiler/ast:StructBody", ptr %t194, i32 0, i32 0
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t199, 0
  store i64 %t201, ptr %l20, !tbaa !24
  br label %bb45
bb44:
  br label %bb55
bb45:
  store %olang.scope zeroinitializer, ptr %s14
  %t203 = load i64, ptr %l19, !tbaa !24
  %t204 = load i64, ptr %l20, !tbaa !24
  %t207 = icmp slt i64 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s14)
  br label %bb54
bb47:
  br label %bb48
bb48:
  %t211 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t211, ptr %l114, !tbaa !27
  %t212 = load i64, ptr %l19, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr ptr, ptr %t215, i64 %t212
  %t217 = load ptr, ptr %t216, !tbaa !39
  store ptr %t217, ptr %l21, !tbaa !29
  %t219 = load ptr, ptr %l21, !tbaa !29
  %t221 = getelementptr %"compiler/ast:Param", ptr %t219, i32 0, i32 1
  %t222 = load i32, ptr %t221, !tbaa !23
  %t223 = load i32, ptr %l17, !tbaa !23
  %t226 = icmp eq i32 %t222, %t223
  br i1 %t226, label %bb49, label %bb50
bb49:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i64, ptr %l5, !tbaa !24
  %t230 = load ptr, ptr %l21, !tbaa !29
  %t232 = getelementptr %"compiler/ast:Param", ptr %t230, i32 0, i32 2
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t237 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t228, i64 %t229, ptr %t233)
  store { i64, [3 x i64] } %t237, ptr %l125
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  %t238 = load { i64, [3 x i64] }, ptr %l125
  store { i64, [3 x i64] } %t238, ptr %rv
  br label %ret
bb52:
  call void @__olang_scope_close(ptr %s14)
  br label %bb53
bb53:
  %t239 = load i64, ptr %l19, !tbaa !24
  %t241 = add i64 %t239, 1
  store i64 %t241, ptr %l19, !tbaa !24
  br label %bb45
bb54:
  br label %bb55
bb55:
  store { i64, [3 x i64] } zeroinitializer, ptr %t243
  %t244 = getelementptr { i64, [3 x i64] }, ptr %t243, i32 0, i32 0
  store i64 0, ptr %t244
  %t245 = load { i64, [3 x i64] }, ptr %t243
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  store { i64, [3 x i64] } %t245, ptr %rv
  br label %ret
bb56:
  %t247 = load i64, ptr %l8, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb57:
  %t251 = load i64, ptr %l15, !tbaa !24
  %t253 = add i64 %t251, 1
  store i64 %t253, ptr %l15, !tbaa !24
  br label %bb30
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb61:
  %t255 = load i64, ptr %l10, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l10, !tbaa !24
  br label %bb18
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  store { i64, [3 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t259, i32 0, i32 0
  store i64 0, ptr %t260
  %t261 = load { i64, [3 x i64] }, ptr %t259
  store { i64, [3 x i64] } %t261, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local { ptr, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitQuiet(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca i64
  %l17 = alloca i64
  %l22 = alloca ptr
  %l31 = alloca i64
  %rv = alloca { ptr, i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/load:Loader", ptr %t20, i32 0, i32 4
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l17
  br label %bb2
bb2:
  %t26 = load i64, ptr %l17, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t27, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
  store ptr %t35, ptr %l22
  br label %bb3
bb3:
  %t36 = load ptr, ptr %l22, !tbaa !29
  store ptr %t36, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/load:Loader", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t46)
  br label %bb4
bb4:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/load:Loader", ptr %t54, i32 0, i32 4
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l31
  br label %bb5
bb5:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l31, !tbaa !24
  %t63 = icmp eq i64 %t61, %t60
  store i1 %t63, ptr %l7, !tbaa !21
  %t65 = load i1, ptr %l7, !tbaa !21
  br i1 %t65, label %bb6, label %bb7
bb6:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/load:Loader", ptr %t73, i32 0, i32 4
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t76, i64 %t77)
  br label %bb8
bb7:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/load:Loader", ptr %t86, i32 0, i32 4
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t89, i64 %t90)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t94 = load i1, ptr %l7, !tbaa !21
  %t96 = insertvalue { ptr, i1 } undef, ptr %t93, 0
  %t98 = insertvalue { ptr, i1 } %t96, i1 %t94, 1
  store { ptr, i1 } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { ptr, i1 }, ptr %rv
  ret { ptr, i1 } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l17 = alloca i32
  %l24 = alloca i32
  %l31 = alloca i1
  %l36 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca i1
  %l61 = alloca ptr
  %l66 = alloca i32
  %l70 = alloca i1
  %l78 = alloca i32
  %l81 = alloca ptr
  %l86 = alloca i32
  %l90 = alloca i1
  %l95 = alloca ptr
  %l100 = alloca i32
  %l103 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l17
  br label %bb7
bb7:
  %t23 = load i32, ptr %l17
  store i32 %t23, ptr %l4
  %t24 = load i32, ptr %l4
  %t26 = trunc i64 18 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb35
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l24
  br label %bb11
bb11:
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = load i32, ptr %l24, !tbaa !23
  %t42 = icmp eq i32 %t40, %t39
  br i1 %t42, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l31
  br label %bb15
bb15:
  %t53 = load i1, ptr %l31, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l36
  br label %bb19
bb19:
  %t62 = load i32, ptr %l36
  store i32 %t62, ptr %l5
  %t63 = load i32, ptr %l5
  %t65 = trunc i64 0 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l39, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l1, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l44
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load i32, ptr %l2, !tbaa !23
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load ptr, ptr %l39, !tbaa !29
  %t82 = load i32, ptr %l44, !tbaa !23
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t81, i32 %t82, i32 %t79, i64 %t80)
  store i1 %t85, ptr %l47
  br label %bb23
bb23:
  %t86 = load i1, ptr %l47, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb24:
  %t87 = load i32, ptr %l5
  %t89 = trunc i64 1 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l50, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l1, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l55
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t103 = load i32, ptr %l2, !tbaa !23
  %t104 = load i64, ptr %l3, !tbaa !24
  %t105 = load ptr, ptr %l50, !tbaa !29
  %t106 = load i32, ptr %l55, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t105, i32 %t106, i32 %t103, i64 %t104)
  store i1 %t109, ptr %l58
  br label %bb28
bb28:
  %t110 = load i1, ptr %l58, !tbaa !21
  store i1 %t110, ptr %rv
  br label %ret
bb29:
  %t111 = load i32, ptr %l5
  %t113 = trunc i64 4 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb30, label %bb31
bb30:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l61, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l1, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l66
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t127 = load i32, ptr %l2, !tbaa !23
  %t128 = load i64, ptr %l3, !tbaa !24
  %t130 = add i64 %t128, 1
  %t131 = load ptr, ptr %l61, !tbaa !29
  %t132 = load i32, ptr %l66, !tbaa !23
  %t135 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t131, i32 %t132, i32 %t127, i64 %t130)
  store i1 %t135, ptr %l70
  br label %bb33
bb33:
  %t136 = load i1, ptr %l70, !tbaa !21
  store i1 %t136, ptr %rv
  br label %ret
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  %t138 = load i32, ptr %l4
  %t140 = trunc i64 19 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb45
bb38:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l1, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l78
  br label %bb39
bb39:
  %t153 = load i32, ptr %l78, !tbaa !23
  %t154 = icmp eq i32 %t153, 0
  br i1 %t154, label %bb40, label %bb41
bb40:
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l81, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l1, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l86
  br label %bb43
bb43:
  %t168 = load i32, ptr %l2, !tbaa !23
  %t169 = load i64, ptr %l3, !tbaa !24
  %t171 = add i64 %t169, 1
  %t172 = load ptr, ptr %l81, !tbaa !29
  %t173 = load i32, ptr %l86, !tbaa !23
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t172, i32 %t173, i32 %t168, i64 %t171)
  store i1 %t176, ptr %l90
  br label %bb44
bb44:
  %t177 = load i1, ptr %l90, !tbaa !21
  store i1 %t177, ptr %rv
  br label %ret
bb45:
  %t178 = load i32, ptr %l4
  %t180 = trunc i64 22 to i32
  %t181 = icmp eq i32 %t178, %t180
  br i1 %t181, label %bb46, label %bb47
bb46:
  br label %bb50
bb47:
  %t183 = load i32, ptr %l4
  %t185 = trunc i64 23 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l95, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l100
  br label %bb51
bb51:
  %t199 = load i32, ptr %l2, !tbaa !23
  %t200 = load i64, ptr %l3, !tbaa !24
  %t201 = load ptr, ptr %l95, !tbaa !29
  %t202 = load i32, ptr %l100, !tbaa !23
  %t205 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t201, i32 %t202, i32 %t199, i64 %t200)
  store i1 %t205, ptr %l103
  br label %bb52
bb52:
  %t206 = load i1, ptr %l103, !tbaa !21
  store i1 %t206, ptr %rv
  br label %ret
bb53:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimmutableGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t4, i64 %a1, i32 %a2)
  store ptr %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l8, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/ast:VarDecl", ptr %t18, i32 0, i32 2
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = call i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %t21)
  store i1 %t23, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t24 = load i1, ptr %l15, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l12, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/generic:Binding"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i32
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l37 = alloca %"compiler/generic:Binding"
  %l39 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i64
  %l70 = alloca i32
  %l71 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %t5)
  store i32 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i32, ptr %l15, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t10)
  store i64 %t12, ptr %l17
  br label %bb2
bb2:
  %t13 = load i64, ptr %l17, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l21
  br label %bb3
bb3:
  %t22 = load i64, ptr %l21, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l24, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l3, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l29
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l24, !tbaa !29
  %t40 = load i32, ptr %l29, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t39, i32 %t40)
  store { i64, ptr } %t41, ptr %l30
  br label %bb5
bb5:
  %t42 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t42, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = icmp eq i64 %t45, 0
  br i1 %t47, label %bb6, label %bb7
bb6:
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t49, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t51, i64 %t52)
  store %"compiler/generic:Binding" %t55, ptr %l37
  br label %bb9
bb9:
  %t56 = load %"compiler/generic:Binding", ptr %l37
  store %"compiler/generic:Binding" %t56, ptr %l7
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t58, ptr %l39, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 0
  %t62 = load i32, ptr %t61, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t57, i32 %t62, i32 %a2, ptr %l7, i1 false, i1 true)
  br label %bb10
bb10:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t71, ptr %l7)
  br label %bb11
bb11:
  %t74 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  store { i64, ptr } %t75, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t81 = load i64, ptr %l9, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb14:
  br label %bb15
bb15:
  %t89 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t89, ptr %l53, !tbaa !27
  %t90 = load i64, ptr %l9, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t98 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t101 = icmp eq i32 %t95, %t98
  br i1 %t101, label %bb16, label %bb17
bb16:
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t103, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l9, !tbaa !24
  br label %bb12
bb20:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l63, !tbaa !29
  %t113 = load i32, ptr %l3, !tbaa !23
  store i32 %t113, ptr %l64, !tbaa !23
  %t114 = load i64, ptr %l4, !tbaa !24
  store i64 %t114, ptr %l65, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t120, { i64, ptr } %t122)
  store i32 %t125, ptr %l70
  br label %bb21
bb21:
  %t126 = load ptr, ptr %l63, !tbaa !29
  %t127 = load i32, ptr %l64, !tbaa !23
  %t128 = load i64, ptr %l65, !tbaa !24
  %t129 = load i32, ptr %l70, !tbaa !23
  %t130 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t126, i32 %t127, i64 %t128, i32 %t129)
  store i32 %t130, ptr %l71
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t131 = load i32, ptr %l71, !tbaa !23
  store i32 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/msgs:Msg"
  %l16 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/msgs:Msg"
  %l25 = alloca i64
  %l30 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/msgs:Msg"
  %l34 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i1
  %l44 = alloca i32
  %l46 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i1
  %l53 = alloca i32
  %l58 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i32, ptr %l7, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store %"compiler/source:Span" %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %s1)
  store %"compiler/msgs:Msg" %t18, ptr %l15
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l14
  %t21 = load %"compiler/msgs:Msg", ptr %l15
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t19, %"compiler/source:Span" %t20, %"compiler/msgs:Msg" %t21)
  store i64 %t22, ptr %l16
  br label %bb6
bb6:
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t23, ptr %rv
  br label %ret
bb7:
  %t25 = load i32, ptr %l4, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t29 = icmp eq i32 %t25, %t26
  br i1 %t29, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l23
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %s2)
  store %"compiler/msgs:Msg" %t35, ptr %l24
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l23
  %t38 = load %"compiler/msgs:Msg", ptr %l24
  %t39 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t36, %"compiler/source:Span" %t37, %"compiler/msgs:Msg" %t38)
  store i64 %t39, ptr %l25
  br label %bb12
bb12:
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t40, ptr %rv
  br label %ret
bb13:
  %t42 = load i32, ptr %l4, !tbaa !23
  %t43 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t46 = icmp eq i32 %t42, %t43
  br i1 %t46, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l30, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t49)
  store %"compiler/source:Span" %t51, ptr %l32
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t52 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotInferable(ptr %s3)
  store %"compiler/msgs:Msg" %t52, ptr %l33
  br label %bb17
bb17:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l32
  %t55 = load %"compiler/msgs:Msg", ptr %l33
  %t56 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t53, %"compiler/source:Span" %t54, %"compiler/msgs:Msg" %t55)
  store i64 %t56, ptr %l34
  br label %bb18
bb18:
  %t57 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  store i32 %t57, ptr %rv
  br label %ret
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l4, !tbaa !23
  %t63 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t63, ptr %l38
  br label %bb20
bb20:
  %t64 = load i1, ptr %l38, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l4, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l44
  br label %bb23
bb22:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb25
bb23:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t75)
  store i32 %t77, ptr %l46
  br label %bb24
bb24:
  %t78 = load i32, ptr %l44, !tbaa !23
  %t79 = load i32, ptr %l46, !tbaa !23
  %t80 = icmp eq i32 %t78, %t79
  store i1 %t80, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l39, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l2, !tbaa !29
  store ptr %t83, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t84 = load ptr, ptr %l48, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb28, label %bb29
bb27:
  br label %bb36
bb28:
  %t87 = load ptr, ptr %l48, !tbaa !29
  %t88 = load i64, ptr %t87
  %t90 = icmp eq i64 %t88, 1
  store i1 %t90, ptr %l49, !tbaa !21
  br label %bb29
bb29:
  %t91 = load i1, ptr %l49, !tbaa !21
  br i1 %t91, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t92)
  store i32 %t94, ptr %l53
  br label %bb33
bb33:
  %t95 = load i32, ptr %l53, !tbaa !23
  store i32 %t95, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t98 = xor i1 %a3, true
  br i1 %t98, label %bb37, label %bb38
bb37:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l4, !tbaa !23
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l58
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t105 = load i32, ptr %l58, !tbaa !23
  store i32 %t105, ptr %rv
  br label %ret
bb40:
  %t106 = load i32, ptr %l4, !tbaa !23
  store i32 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l8
  br label %bb2
bb2:
  %t15 = load i1, ptr %l8, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6
  %t13 = trunc i64 20 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l3 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t6, i32 %a1)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elimit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca i32
  %l20 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca { i64, ptr }
  %l29 = alloca %"compiler/msgs:Msg"
  %l30 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l54 = alloca { i64, ptr }
  %l57 = alloca %"compiler/msgs:Msg"
  %l58 = alloca i64
  %l61 = alloca ptr
  %l66 = alloca i1
  %l68 = alloca i64
  %l71 = alloca i1
  %l74 = alloca i1
  %l78 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l83 = alloca { i64, ptr }
  %l89 = alloca %"compiler/msgs:Msg"
  %l90 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca i32
  %l102 = alloca i64
  %l103 = alloca ptr
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %a4)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i32, ptr %l15, !tbaa !23
  store i32 %t12, ptr %l6, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l6, !tbaa !23
  %t22 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l20
  br label %bb3
bb3:
  %t23 = load i1, ptr %l20, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l22, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t27, ptr %l23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l26
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t33 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t43 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoLimit(ptr %s1, ptr %v0, ptr %s1, ptr %s1, { i64, ptr } %t39, { i64, ptr } %t40, { i64, ptr } { i64 27, ptr @.d19 })
  store %"compiler/msgs:Msg" %t43, ptr %l29
  br label %bb7
bb7:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l23
  %t46 = load %"compiler/msgs:Msg", ptr %l29
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t44, %"compiler/source:Span" %t45, %"compiler/msgs:Msg" %t46)
  store i64 %t47, ptr %l30
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l1
  %t52 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t48, %"compiler/source:Span" %t49)
  store ptr %t52, ptr %l33
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t53 = load ptr, ptr %l33, !tbaa !29
  store ptr %t53, ptr %rv
  br label %ret
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t54, i32 %t55)
  store i1 %t58, ptr %l36
  br label %bb11
bb11:
  %t59 = load i1, ptr %l36, !tbaa !21
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i32, ptr %l3, !tbaa !23
  %t67 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t63, i32 %t64)
  store i1 %t67, ptr %l41
  br label %bb14
bb13:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb19
bb14:
  %t68 = load i1, ptr %l41, !tbaa !21
  %t69 = xor i1 %t68, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb18
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i32, ptr %l3, !tbaa !23
  %t78 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l47
  br label %bb17
bb17:
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t80 = load i32, ptr %l47, !tbaa !23
  %t82 = icmp ne i32 %t80, %t79
  store i1 %t82, ptr %l43, !tbaa !21
  br label %bb18
bb18:
  %t84 = load i1, ptr %l43, !tbaa !21
  store i1 %t84, ptr %l37, !tbaa !21
  br label %bb19
bb19:
  %t85 = load i1, ptr %l37, !tbaa !21
  br i1 %t85, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s2
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l50, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t87, ptr %l51
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l3, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t88, i32 %t89)
  store { i64, ptr } %t92, ptr %l54
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t93 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t103 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoLimit(ptr %s2, ptr %v0, ptr %s2, ptr %s2, { i64, ptr } %t99, { i64, ptr } %t100, { i64, ptr } { i64 93, ptr @.d20 })
  store %"compiler/msgs:Msg" %t103, ptr %l57
  br label %bb23
bb23:
  %t104 = load ptr, ptr %l50, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l51
  %t106 = load %"compiler/msgs:Msg", ptr %l57
  %t107 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t104, %"compiler/source:Span" %t105, %"compiler/msgs:Msg" %t106)
  store i64 %t107, ptr %l58
  br label %bb24
bb24:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t108, %"compiler/source:Span" %t109)
  store ptr %t112, ptr %l61
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  %t113 = load ptr, ptr %l61, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb26:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %l6, !tbaa !23
  %t123 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t119, i32 %t120)
  store i1 %t123, ptr %l66
  br label %bb27
bb27:
  %t124 = load i1, ptr %l66, !tbaa !21
  store i1 %t124, ptr %l7, !tbaa !21
  %t125 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t127 = call i64 @compiler_2fcheck_2elimitIndex(ptr %v0, { i64, ptr } %t125)
  store i64 %t127, ptr %l68
  br label %bb28
bb28:
  %t128 = load i64, ptr %l68, !tbaa !24
  store i64 %t128, ptr %l8, !tbaa !24
  %t129 = load i64, ptr %l8, !tbaa !24
  %t131 = icmp slt i64 %t129, 0
  br i1 %t131, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb34
bb30:
  %t133 = load i64, ptr %l8, !tbaa !24
  %t135 = icmp sgt i64 %t133, 1
  br i1 %t135, label %bb31, label %bb32
bb31:
  %t137 = load i1, ptr %l7, !tbaa !21
  %t139 = xor i1 %t137, true
  store i1 %t139, ptr %l74, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb33
bb33:
  %t141 = load i1, ptr %l74, !tbaa !21
  store i1 %t141, ptr %l71, !tbaa !21
  br label %bb34
bb34:
  %t142 = load i1, ptr %l71, !tbaa !21
  br i1 %t142, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s3
  %t143 = load i1, ptr %l7, !tbaa !21
  br i1 %t143, label %bb37, label %bb38
bb36:
  br label %bb44
bb37:
  store { i64, ptr } { i64 46, ptr @.d21 }, ptr %l78, !tbaa !27
  br label %bb39
bb38:
  store { i64, ptr } { i64 11, ptr @.d22 }, ptr %l78, !tbaa !27
  br label %bb39
bb39:
  %t145 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t145, ptr %l9, !tbaa !27
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l79, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t147, ptr %l80
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l3, !tbaa !23
  %t152 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t148, i32 %t149)
  store { i64, ptr } %t152, ptr %l83
  br label %bb40
bb40:
  %t153 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t160 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t162 = extractvalue { i64, ptr } { i64 18, ptr @.d23 }, 1
  %t163 = extractvalue { i64, ptr } { i64 18, ptr @.d23 }, 0
  %t165 = extractvalue { i64, ptr } %t161, 1
  %t166 = extractvalue { i64, ptr } %t161, 0
  %t167 = add i64 %t163, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t162, i64 %t163)
  %t169 = getelementptr i8, ptr %t168, i64 %t163
  call void @olang_textcopy(ptr %t169, ptr %t165, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t168, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = extractvalue { i64, ptr } %t171, 1
  %t175 = mul i64 %t173, 1
  %t176 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t174, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  %t182 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoLimit(ptr %s3, ptr %v0, ptr %s3, ptr %s3, { i64, ptr } %t159, { i64, ptr } %t160, { i64, ptr } %t178)
  store %"compiler/msgs:Msg" %t182, ptr %l89
  br label %bb41
bb41:
  %t183 = load ptr, ptr %l79, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l80
  %t185 = load %"compiler/msgs:Msg", ptr %l89
  %t186 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t183, %"compiler/source:Span" %t184, %"compiler/msgs:Msg" %t185)
  store i64 %t186, ptr %l90
  br label %bb42
bb42:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l1
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t187, %"compiler/source:Span" %t188)
  store ptr %t191, ptr %l93
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s3)
  %t192 = load ptr, ptr %l93, !tbaa !29
  store ptr %t192, ptr %rv
  br label %ret
bb44:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l94, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t194, ptr %l95
  %t195 = load i32, ptr %l3, !tbaa !23
  store i32 %t195, ptr %l96, !tbaa !23
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 2
  %t202 = load i32, ptr %l6, !tbaa !23
  %t203 = load i64, ptr %l8, !tbaa !24
  %t207 = call i64 @compiler_2fcheck_2elimitBits(ptr %v0, ptr %t201, i32 %t202, i64 %t203)
  store i64 %t207, ptr %l102
  br label %bb45
bb45:
  %t208 = load ptr, ptr %l94, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l95
  %t210 = load i32, ptr %l96, !tbaa !23
  %t211 = load i64, ptr %l102, !tbaa !24
  %t212 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t208, %"compiler/source:Span" %t209, i32 %t210, i64 %t211)
  store ptr %t212, ptr %l103
  br label %bb46
bb46:
  %t213 = load ptr, ptr %l103, !tbaa !29
  store ptr %t213, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:litv"
  %l4 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca i32
  %l15 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i32
  %l28 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i32
  %l40 = alloca i1
  %l41 = alloca ptr
  %l46 = alloca ptr
  %l51 = alloca ptr
  %l55 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/check:litv" %a2, ptr %l2
  store i32 %a4, ptr %l4
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a3)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l12, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l7, !tbaa !23
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load i32, ptr %l15, !tbaa !23
  store i32 %t11, ptr %l8, !tbaa !23
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l8, !tbaa !23
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l20
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t19 = load i1, ptr %l20, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l17, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l7, !tbaa !23
  %t25 = load i32, ptr %l4
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %t23, i32 %t24, i32 %t25)
  store i32 %t29, ptr %l25
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t30 = load i32, ptr %l25, !tbaa !23
  store i32 %t30, ptr %l8, !tbaa !23
  br label %bb10
bb10:
  %t31 = load i1, ptr %l6, !tbaa !21
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l8, !tbaa !23
  %t39 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l31
  br label %bb13
bb12:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb14
bb13:
  %t40 = load i1, ptr %l31, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l28, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l28, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l7, !tbaa !23
  %t46 = load i32, ptr %l4
  %t50 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuteParam(ptr %v0, ptr %t44, i32 %t45, i32 %t46)
  store i32 %t50, ptr %l36
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t51 = load i32, ptr %l36, !tbaa !23
  store i32 %t51, ptr %l8, !tbaa !23
  br label %bb18
bb18:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"compiler/check:litv", ptr %l2
  %t54 = load i32, ptr %l8, !tbaa !23
  %t58 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t52, %"compiler/check:litv" %t53, i32 %t54)
  store i1 %t58, ptr %l40
  br label %bb19
bb19:
  %t59 = load i1, ptr %l40, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load %"compiler/check:litv", ptr %l2
  %t63 = load i32, ptr %l8, !tbaa !23
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %t60, ptr %t61, %"compiler/check:litv" %t62, i32 %t63)
  store ptr %t68, ptr %l46
  br label %bb22
bb21:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t71 = load %"compiler/check:litv", ptr %l2
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %t69, ptr %t70, %"compiler/check:litv" %t71, i32 %t72)
  store ptr %t77, ptr %l51
  br label %bb23
bb22:
  %t78 = load ptr, ptr %l46, !tbaa !29
  store ptr %t78, ptr %l41, !tbaa !29
  br label %bb24
bb23:
  %t79 = load ptr, ptr %l51, !tbaa !29
  store ptr %t79, ptr %l41, !tbaa !29
  br label %bb24
bb24:
  %t80 = load ptr, ptr %l41, !tbaa !29
  store ptr %t80, ptr %l9, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load %"compiler/check:litv", ptr %l2
  %t83 = load i32, ptr %l8, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t81, %"compiler/check:litv" %t82, i32 %t83)
  store i1 %t87, ptr %l55
  br label %bb25
bb25:
  %t88 = load i1, ptr %l55, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l58, !tbaa !29
  store %"compiler/source:Span" %a5, ptr %l59
  %t93 = load i32, ptr %l7, !tbaa !23
  store i32 %t93, ptr %l60, !tbaa !23
  %t94 = load ptr, ptr %l9, !tbaa !29
  %t97 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t94)
  store i32 %t97, ptr %l63
  br label %bb28
bb27:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb30
bb28:
  %t98 = load ptr, ptr %l58, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l59
  %t100 = load i32, ptr %l60, !tbaa !23
  %t101 = load i32, ptr %l63, !tbaa !23
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t100, i32 %t101)
  store i1 %t102, ptr %l64
  br label %bb29
bb29:
  %t103 = load i1, ptr %l64, !tbaa !21
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb30
bb30:
  %t104 = load i1, ptr %l57, !tbaa !21
  br i1 %t104, label %bb31, label %bb32
bb31:
  store ptr null, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t106 = load ptr, ptr %l9, !tbaa !29
  store ptr %t106, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteral(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l47 = alloca i32
  %l50 = alloca i64
  %l51 = alloca ptr
  %l56 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca %"compiler/source:Span"
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca %"compiler/msgs:Msg"
  %l72 = alloca i64
  %l75 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca %"compiler/msgs:Msg"
  %l86 = alloca i64
  %l89 = alloca ptr
  %l94 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  %t3 = trunc i64 6 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t7, ptr %l8
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t8, ptr %l9, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  %t13 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t9, %"compiler/source:Span" %t10)
  store { i64, ptr } %t13, ptr %l12
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t14, { i64, ptr } { i64 4, ptr @.d24 })
  store i1 %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i64 1, ptr %l14, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l8
  %t19 = load i32, ptr %l9, !tbaa !23
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t17, %"compiler/source:Span" %t18, i32 %t19, i64 %t20)
  store ptr %t21, ptr %l15
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t22 = load ptr, ptr %l15, !tbaa !29
  store ptr %t22, ptr %rv
  br label %ret
bb9:
  %t23 = load i32, ptr %l2
  %t25 = trunc i64 7 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l22
  br label %bb12
bb11:
  br label %bb25
bb12:
  %t38 = load i32, ptr %l22
  store i32 %t38, ptr %l4
  %t39 = load i32, ptr %l4
  %t41 = trunc i64 20 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l30
  br label %bb15
bb14:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb16
bb15:
  %t54 = load i1, ptr %l30, !tbaa !21
  store i1 %t54, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t55 = load i1, ptr %l25, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t56 = load i32, ptr %l4
  %t58 = trunc i64 21 to i32
  %t59 = icmp eq i32 %t56, %t58
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l31, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l1
  %t64 = load i32, ptr %l3, !tbaa !23
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t62, %"compiler/source:Span" %t63, i32 %t64, i64 0)
  store ptr %t68, ptr %l37
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load ptr, ptr %l37, !tbaa !29
  store ptr %t69, ptr %rv
  br label %ret
bb23:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l1
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t70, %"compiler/source:Span" %t71, i32 %t72, i64 0)
  store ptr %t76, ptr %l41
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load ptr, ptr %l41, !tbaa !29
  store ptr %t77, ptr %rv
  br label %ret
bb25:
  %t78 = load i32, ptr %l2
  %t80 = trunc i64 4 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l44, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t84, ptr %l45
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %t85)
  store i32 %t87, ptr %l47
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l1
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %t88, %"compiler/source:Span" %t89)
  store i64 %t92, ptr %l50
  br label %bb29
bb29:
  %t93 = load ptr, ptr %l44, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l45
  %t95 = load i32, ptr %l47, !tbaa !23
  %t96 = load i64, ptr %l50, !tbaa !24
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t93, %"compiler/source:Span" %t94, i32 %t95, i64 %t96)
  store ptr %t97, ptr %l51
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t98 = load ptr, ptr %l51, !tbaa !29
  store ptr %t98, ptr %rv
  br label %ret
bb31:
  %t99 = load i32, ptr %l2
  %t101 = trunc i64 5 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l1
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextLit(ptr %v0, ptr %t104, %"compiler/source:Span" %t105)
  store ptr %t108, ptr %l56
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load ptr, ptr %l56, !tbaa !29
  store ptr %t109, ptr %rv
  br label %ret
bb35:
  %t110 = load i32, ptr %l2
  %t112 = trunc i64 2 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb36, label %bb37
bb36:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l1
  %t119 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t115, %"compiler/source:Span" %t116)
  store { i64, ptr } %t119, ptr %l61
  br label %bb38
bb37:
  br label %bb48
bb38:
  %t120 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t121 = call i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %t120)
  store i1 %t121, ptr %l62
  br label %bb39
bb39:
  %t122 = load i1, ptr %l62, !tbaa !21
  %t123 = xor i1 %t122, true
  br i1 %t123, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l64, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t126, ptr %l65
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t127, %"compiler/source:Span" %t128)
  store { i64, ptr } %t131, ptr %l68
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t132 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t133 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s7, { i64, ptr } %t132)
  store { i64, ptr } %t133, ptr %l69
  br label %bb43
bb43:
  %t134 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 0
  %t136 = extractvalue { i64, ptr } %t134, 1
  %t137 = mul i64 %t135, 1
  %t138 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t138, ptr %t136, i64 %t137, i1 false)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  %t142 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIntLiteralTooLarge(ptr %s7, ptr %s7, { i64, ptr } %t140)
  store %"compiler/msgs:Msg" %t142, ptr %l71
  br label %bb44
bb44:
  %t143 = load ptr, ptr %l64, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l65
  %t145 = load %"compiler/msgs:Msg", ptr %l71
  %t146 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t143, %"compiler/source:Span" %t144, %"compiler/msgs:Msg" %t145)
  store i64 %t146, ptr %l72
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t147, %"compiler/source:Span" %t148)
  store ptr %t151, ptr %l75
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  %t152 = load ptr, ptr %l75, !tbaa !29
  store ptr %t152, ptr %rv
  br label %ret
bb48:
  %t153 = load i32, ptr %l2
  %t155 = trunc i64 3 to i32
  %t156 = icmp eq i32 %t153, %t155
  br i1 %t156, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l78, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t159, ptr %l79
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l1
  %t164 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t160, %"compiler/source:Span" %t161)
  store { i64, ptr } %t164, ptr %l82
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t165 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t166 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s8, { i64, ptr } %t165)
  store { i64, ptr } %t166, ptr %l83
  br label %bb52
bb52:
  %t167 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  %t169 = extractvalue { i64, ptr } %t167, 1
  %t170 = mul i64 %t168, 1
  %t171 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t170)
  call void @llvm.memcpy.p0.p0.i64(ptr %t171, ptr %t169, i64 %t170, i1 false)
  %t172 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  %t175 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFloatLiteralRange(ptr %s8, ptr %s8, { i64, ptr } %t173)
  store %"compiler/msgs:Msg" %t175, ptr %l85
  br label %bb53
bb53:
  %t176 = load ptr, ptr %l78, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l79
  %t178 = load %"compiler/msgs:Msg", ptr %l85
  %t179 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t176, %"compiler/source:Span" %t177, %"compiler/msgs:Msg" %t178)
  store i64 %t179, ptr %l86
  br label %bb54
bb54:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load %"compiler/source:Span", ptr %l1
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t180, %"compiler/source:Span" %t181)
  store ptr %t184, ptr %l89
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t185 = load ptr, ptr %l89, !tbaa !29
  store ptr %t185, ptr %rv
  br label %ret
bb56:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t186, %"compiler/source:Span" %t187, { i64, ptr } { i64 22, ptr @.d25 })
  br label %bb57
bb57:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t194 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t190, %"compiler/source:Span" %t191)
  store ptr %t194, ptr %l94
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t195 = load ptr, ptr %l94, !tbaa !29
  store ptr %t195, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/msgs:Msg"
  %l17 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %t1, ptr %a1, i32 %t3)
  store %"compiler/source:Span" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t8, ptr %l3
  %t9 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  %t12 = icmp sge i32 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t15, ptr %l11
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l14
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueParam(ptr %s1, ptr %s1, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t29, ptr %l16
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l10, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l11
  %t32 = load %"compiler/msgs:Msg", ptr %l16
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t30, %"compiler/source:Span" %t31, %"compiler/msgs:Msg" %t32)
  store i64 %t33, ptr %l17
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ename(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/names:Ref"
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l9 = alloca i32
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca %"compiler/names:Ref"
  %l22 = alloca i1
  %l26 = alloca i1
  %l29 = alloca ptr
  %l34 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca i64
  %l41 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i32
  %l47 = alloca %"compiler/check:fixedInit"
  %l49 = alloca ptr
  %l51 = alloca ptr
  %l55 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l56 = alloca %"compiler/check:fixedInit"
  %l57 = alloca i32
  %l60 = alloca ptr
  %l65 = alloca ptr
  %l70 = alloca i64
  %l73 = alloca i1
  %l75 = alloca ptr
  %l82 = alloca ptr
  %l89 = alloca ptr
  %l97 = alloca ptr
  %l99 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l112 = alloca i32
  %l121 = alloca ptr
  %l128 = alloca ptr
  %l133 = alloca ptr
  %l135 = alloca ptr
  %l140 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l141 = alloca i1
  %l143 = alloca i1
  %l145 = alloca ptr
  %l147 = alloca ptr
  %l152 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l153 = alloca i1
  %l155 = alloca ptr
  %l156 = alloca %"compiler/source:Span"
  %l159 = alloca { i64, ptr }
  %l161 = alloca %"compiler/msgs:Msg"
  %l162 = alloca i64
  %l164 = alloca ptr
  %l166 = alloca ptr
  %l171 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l174 = alloca ptr
  %l178 = alloca ptr
  %l179 = alloca %"compiler/source:Span"
  %l182 = alloca { i64, ptr }
  %l184 = alloca %"compiler/msgs:Msg"
  %l185 = alloca i64
  %l188 = alloca ptr
  %l197 = alloca i32
  %l200 = alloca i1
  %l203 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca %"compiler/source:Span"
  %l209 = alloca { i64, ptr }
  %l211 = alloca %"compiler/msgs:Msg"
  %l212 = alloca i64
  %l215 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca %"compiler/source:Span"
  %l225 = alloca i64
  %l229 = alloca ptr
  %l233 = alloca i32
  %l235 = alloca ptr
  %l239 = alloca i32
  %l240 = alloca i32
  %l245 = alloca ptr
  %l246 = alloca %"compiler/source:Span"
  %l249 = alloca { i64, ptr }
  %l250 = alloca %"compiler/msgs:Msg"
  %l251 = alloca i64
  %l254 = alloca ptr
  %l260 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca ptr
  %t220 = alloca { i64, [4 x i64] }, align 8
  %t393 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t8)
  store ptr %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l15, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t20 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t17, i64 %t14, i32 %t16)
  store %"compiler/names:Ref" %t20, ptr %l19
  br label %bb2
bb2:
  %t21 = load %"compiler/names:Ref", ptr %l19
  store %"compiler/names:Ref" %t21, ptr %l3
  %t22 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22
  %t25 = trunc i64 1 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  %t30 = load i32, ptr %l2, !tbaa !23
  %t34 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMisused(ptr %v0, ptr %t28, %"compiler/source:Span" %t29, i32 %t30)
  store i1 %t34, ptr %l26
  br label %bb5
bb4:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb6
bb5:
  %t35 = load i1, ptr %l26, !tbaa !21
  store i1 %t35, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t37, %"compiler/source:Span" %t38)
  store ptr %t41, ptr %l29
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t42 = load ptr, ptr %l29, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t42, ptr %rv
  br label %ret
bb10:
  %t44 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44
  %t47 = trunc i64 1 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t50)
  store ptr %t52, ptr %l34
  br label %bb13
bb12:
  br label %bb51
bb13:
  %t53 = load ptr, ptr %l34, !tbaa !29
  %t55 = getelementptr %"compiler/check:frame", ptr %t53, i32 0, i32 39
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l38
  br label %bb14
bb14:
  %t60 = load i1, ptr %l38, !tbaa !21
  br i1 %t60, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t61)
  store ptr %t63, ptr %l41
  br label %bb17
bb16:
  br label %bb30
bb17:
  %t64 = load ptr, ptr %l41, !tbaa !29
  %t66 = getelementptr %"compiler/check:frame", ptr %t64, i32 0, i32 39
  %t67 = load i32, ptr %l2, !tbaa !23
  %t70 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t66, i32 %t67)
  %t71 = extractvalue { i32, i64 } %t70, 1
  %t72 = extractvalue { i32, i64 } %t70, 0
  store i32 %t72, ptr %l46
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb19, label %ok.74
ok.74:
  store i64 %t71, ptr %l45
  br label %bb18
bb18:
  %t75 = load i64, ptr %l45, !tbaa !24
  store i64 %t75, ptr %l39, !tbaa !24
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l39, !tbaa !24
  br label %bb21
bb21:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l4, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 85
  store ptr %t79, ptr %l49, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t80)
  store ptr %t82, ptr %l51
  br label %bb22
bb22:
  %t83 = load ptr, ptr %l51, !tbaa !29
  %t85 = getelementptr %"compiler/check:frame", ptr %t83, i32 0, i32 40
  %t86 = load i64, ptr %t85, !tbaa !24
  %t87 = load i64, ptr %l4, !tbaa !24
  %t90 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t86, i64 %t87)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t90, ptr %l55
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l55
  %t93 = call { i32, %"compiler/check:fixedInit" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6f2dcaa3b3ff2363ea7964270c7a6b31(ptr %v0, ptr %v0, ptr %t91, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t92)
  %t94 = extractvalue { i32, %"compiler/check:fixedInit" } %t93, 1
  %t95 = extractvalue { i32, %"compiler/check:fixedInit" } %t93, 0
  store i32 %t95, ptr %l57
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb25, label %ok.97
ok.97:
  store %"compiler/check:fixedInit" %t94, ptr %l56
  br label %bb24
bb24:
  %t98 = load %"compiler/check:fixedInit", ptr %l56
  store %"compiler/check:fixedInit" %t98, ptr %l47
  br label %bb28
bb25:
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l1
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t99, %"compiler/source:Span" %t100)
  store ptr %t103, ptr %l60
  br label %bb27
bb27:
  %t104 = load ptr, ptr %l60, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t104, ptr %rv
  br label %ret
bb28:
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t106, ptr %lp5
  %t107 = load %"compiler/check:fixedInit", ptr %l47
  %t108 = load ptr, ptr %lp5
  store %"compiler/check:fixedInit" %t107, ptr %t108
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %lp5
  %t111 = getelementptr %"compiler/check:fixedInit", ptr %t110, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load ptr, ptr %lp5
  %t114 = getelementptr %"compiler/check:fixedInit", ptr %t113, i32 0, i32 1
  %t115 = load i32, ptr %t114, !tbaa !23
  %t119 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v0, ptr %t109, ptr %t112, i32 %t115)
  store ptr %t119, ptr %l65
  br label %bb29
bb29:
  %t120 = load ptr, ptr %l65, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t120, ptr %rv
  br label %ret
bb30:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l2, !tbaa !23
  %t124 = load %"compiler/source:Span", ptr %l1
  %t128 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %t122, i32 %t123, %"compiler/source:Span" %t124)
  store i64 %t128, ptr %l70
  br label %bb31
bb31:
  %t129 = load i64, ptr %l70, !tbaa !24
  store i64 %t129, ptr %l6, !tbaa !24
  %t130 = load i64, ptr %l6, !tbaa !24
  %t132 = icmp slt i64 %t130, 0
  br i1 %t132, label %bb32, label %bb33
bb32:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t134)
  store ptr %t136, ptr %l75
  br label %bb34
bb33:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb35
bb34:
  %t137 = load ptr, ptr %l75, !tbaa !29
  %t139 = getelementptr %"compiler/check:frame", ptr %t137, i32 0, i32 26
  %t140 = load i64, ptr %t139, !tbaa !24
  %t142 = icmp sge i64 %t140, 0
  store i1 %t142, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  %t144 = load i1, ptr %l73, !tbaa !21
  br i1 %t144, label %bb36, label %bb37
bb36:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l1
  %t147 = load i32, ptr %l2, !tbaa !23
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %t145, %"compiler/source:Span" %t146, i32 %t147)
  store ptr %t151, ptr %l82
  br label %bb38
bb37:
  br label %bb43
bb38:
  %t152 = load ptr, ptr %l82, !tbaa !29
  store ptr %t152, ptr %l7, !tbaa !29
  %t153 = load ptr, ptr %l7, !tbaa !29
  %t155 = icmp eq ptr %t153, null
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb39, label %bb40
bb39:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load ptr, ptr %l7, !tbaa !29
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t159, %"compiler/source:Span" %t160, ptr %t161)
  store ptr %t165, ptr %l89
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t166 = load ptr, ptr %l89, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t166, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t168 = load i64, ptr %l6, !tbaa !24
  %t170 = icmp slt i64 %t168, 0
  br i1 %t170, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s7, ptr %t172, %"compiler/source:Span" %t173, { i64, ptr } { i64 33, ptr @.d26 })
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l1
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t176, %"compiler/source:Span" %t177)
  store ptr %t180, ptr %l97
  br label %bb47
bb47:
  %t181 = load ptr, ptr %l97, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t181, ptr %rv
  br label %ret
bb48:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l99, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t184, ptr %l100
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  %t187 = load i64, ptr %l6, !tbaa !24
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %t185, %"compiler/source:Span" %t186, i64 %t187)
  store ptr %t191, ptr %l104
  br label %bb49
bb49:
  %t192 = load ptr, ptr %l99, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l100
  %t194 = load ptr, ptr %l104, !tbaa !29
  %t195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t192, %"compiler/source:Span" %t193, ptr %t194)
  store ptr %t195, ptr %l105
  br label %bb50
bb50:
  %t196 = load ptr, ptr %l105, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t196, ptr %rv
  br label %ret
bb51:
  %t198 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t199 = load i32, ptr %t198
  %t201 = trunc i64 2 to i32
  %t202 = icmp eq i32 %t199, %t201
  br i1 %t202, label %bb52, label %bb53
bb52:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t206 = load i64, ptr %t205, !tbaa !24
  %t207 = load i32, ptr %l2, !tbaa !23
  %t211 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t204, i64 %t206, i32 %t207)
  store i32 %t211, ptr %l112
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t212 = load i32, ptr %l112, !tbaa !23
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load %"compiler/source:Span", ptr %l1
  %t215 = load %"compiler/source:Span", ptr %l1
  %t217 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t218 = load i64, ptr %t217, !tbaa !24
  %t219 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t220
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t220, i32 0, i32 0
  store i64 1, ptr %t221
  %t223 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t215, 0
  %t225 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t223, i32 %t212, 1
  %t227 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t225, i64 %t218, 2
  %t229 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t227, i32 %t219, 3
  %t230 = getelementptr { i64, [4 x i64] }, ptr %t220, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t229, ptr %t230
  %t231 = load { i64, [4 x i64] }, ptr %t220
  %t233 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t231, ptr %t233
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t213, %"compiler/source:Span" %t214, ptr %t233)
  store ptr %t237, ptr %l121
  br label %bb55
bb55:
  %t238 = load ptr, ptr %l121, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t238, ptr %rv
  br label %ret
bb56:
  %t240 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t241 = load i32, ptr %t240
  %t243 = trunc i64 6 to i32
  %t244 = icmp eq i32 %t241, %t243
  br i1 %t244, label %bb57, label %bb58
bb57:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l1
  %t248 = load i32, ptr %l2, !tbaa !23
  %t252 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %t246, %"compiler/source:Span" %t247, i32 %t248)
  store ptr %t252, ptr %l128
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t253 = load ptr, ptr %l128, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t253, ptr %rv
  br label %ret
bb60:
  %t255 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t256 = load i32, ptr %t255
  %t258 = trunc i64 0 to i32
  %t259 = icmp eq i32 %t256, %t258
  br i1 %t259, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s10
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 69
  store ptr %t263, ptr %l133, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t264)
  store ptr %t266, ptr %l135
  br label %bb63
bb62:
  br label %bb82
bb63:
  %t267 = load ptr, ptr %l135, !tbaa !29
  %t269 = getelementptr %"compiler/check:frame", ptr %t267, i32 0, i32 0
  %t270 = load i64, ptr %t269, !tbaa !24
  %t271 = load i32, ptr %l2, !tbaa !23
  %t273 = sext i32 %t271 to i64
  %t276 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s10, i64 %t270, i64 %t273)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t276, ptr %l140
  br label %bb64
bb64:
  %t277 = load ptr, ptr %l133, !tbaa !29
  %t278 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l140
  %t279 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t277, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t278)
  store i1 %t279, ptr %l141
  br label %bb65
bb65:
  %t280 = load i1, ptr %l141, !tbaa !21
  %t281 = xor i1 %t280, true
  br i1 %t281, label %bb66, label %bb67
bb66:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/check:Checker", ptr %t283, i32 0, i32 68
  store ptr %t285, ptr %l145, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t286)
  store ptr %t288, ptr %l147
  br label %bb68
bb67:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb71
bb68:
  %t289 = load ptr, ptr %l147, !tbaa !29
  %t291 = getelementptr %"compiler/check:frame", ptr %t289, i32 0, i32 1
  %t292 = load i64, ptr %t291, !tbaa !24
  %t293 = load i32, ptr %l2, !tbaa !23
  %t295 = sext i32 %t293 to i64
  %t298 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s10, i64 %t292, i64 %t295)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t298, ptr %l152
  br label %bb69
bb69:
  %t299 = load ptr, ptr %l145, !tbaa !29
  %t300 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l152
  %t301 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t299, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t300)
  store i1 %t301, ptr %l153
  br label %bb70
bb70:
  %t302 = load i1, ptr %l153, !tbaa !21
  %t303 = xor i1 %t302, true
  store i1 %t303, ptr %l143, !tbaa !21
  br label %bb71
bb71:
  %t305 = load i1, ptr %l143, !tbaa !21
  br i1 %t305, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s11
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l155, !tbaa !29
  %t307 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t307, ptr %l156
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load i32, ptr %l2, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s11, ptr %t308, i32 %t309)
  store { i64, ptr } %t312, ptr %l159
  br label %bb74
bb73:
  br label %bb80
bb74:
  %t313 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 0
  %t315 = extractvalue { i64, ptr } %t313, 1
  %t316 = mul i64 %t314, 1
  %t317 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t316)
  call void @llvm.memcpy.p0.p0.i64(ptr %t317, ptr %t315, i64 %t316, i1 false)
  %t318 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t317, 1
  %t321 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownName(ptr %s11, ptr %s11, { i64, ptr } %t319)
  store %"compiler/msgs:Msg" %t321, ptr %l161
  br label %bb75
bb75:
  %t322 = load ptr, ptr %l155, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l156
  %t324 = load %"compiler/msgs:Msg", ptr %l161
  %t325 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t322, %"compiler/source:Span" %t323, %"compiler/msgs:Msg" %t324)
  store i64 %t325, ptr %l162
  br label %bb76
bb76:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/check:Checker", ptr %t326, i32 0, i32 69
  store ptr %t328, ptr %l164, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t329)
  store ptr %t331, ptr %l166
  br label %bb77
bb77:
  %t332 = load ptr, ptr %l166, !tbaa !29
  %t334 = getelementptr %"compiler/check:frame", ptr %t332, i32 0, i32 0
  %t335 = load i64, ptr %t334, !tbaa !24
  %t336 = load i32, ptr %l2, !tbaa !23
  %t338 = sext i32 %t336 to i64
  %t341 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s11, i64 %t335, i64 %t338)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t341, ptr %l171
  br label %bb78
bb78:
  %t342 = load ptr, ptr %l164, !tbaa !29
  %t343 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l171
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t342, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t343, i1 true)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb80:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l1
  %t348 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t344, %"compiler/source:Span" %t345)
  store ptr %t348, ptr %l174
  br label %bb81
bb81:
  %t349 = load ptr, ptr %l174, !tbaa !29
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t349, ptr %rv
  br label %ret
bb82:
  %t351 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t352 = load i32, ptr %t351
  %t354 = trunc i64 7 to i32
  %t355 = icmp eq i32 %t352, %t354
  br i1 %t355, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s12
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l178, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t358, ptr %l179
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l2, !tbaa !23
  %t363 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s12, ptr %t359, i32 %t360)
  store { i64, ptr } %t363, ptr %l182
  br label %bb85
bb84:
  br label %bb89
bb85:
  %t364 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = extractvalue { i64, ptr } %t364, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  %t372 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotAValue(ptr %s12, ptr %s12, { i64, ptr } %t370)
  store %"compiler/msgs:Msg" %t372, ptr %l184
  br label %bb86
bb86:
  %t373 = load ptr, ptr %l178, !tbaa !29
  %t374 = load %"compiler/source:Span", ptr %l179
  %t375 = load %"compiler/msgs:Msg", ptr %l184
  %t376 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t373, %"compiler/source:Span" %t374, %"compiler/msgs:Msg" %t375)
  store i64 %t376, ptr %l185
  br label %bb87
bb87:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load %"compiler/source:Span", ptr %l1
  %t381 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t377, %"compiler/source:Span" %t378)
  store ptr %t381, ptr %l188
  br label %bb88
bb88:
  %t382 = load ptr, ptr %l188, !tbaa !29
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t382, ptr %rv
  br label %ret
bb89:
  %t384 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t385 = load i32, ptr %t384
  %t387 = trunc i64 4 to i32
  %t388 = icmp eq i32 %t385, %t387
  br i1 %t388, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s13
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load %"compiler/source:Span", ptr %l1
  %t392 = load i32, ptr %l2, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t393
  %t394 = getelementptr { i64, [5 x i64] }, ptr %t393, i32 0, i32 0
  store i64 0, ptr %t394
  %t396 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t391, 0
  %t398 = insertvalue { %"compiler/source:Span", i32 } %t396, i32 %t392, 1
  %t399 = getelementptr { i64, [5 x i64] }, ptr %t393, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t398, ptr %t399
  %t400 = load { i64, [5 x i64] }, ptr %t393
  %t402 = call ptr @__olang_scope_alloc_a(ptr %s13, i64 48, i64 8)
  store { i64, [5 x i64] } %t400, ptr %t402
  %t405 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %s13, ptr %t390, ptr %t402)
  store i32 %t405, ptr %l197
  br label %bb92
bb91:
  br label %bb104
bb92:
  %t406 = load i32, ptr %l197, !tbaa !23
  store i32 %t406, ptr %l9, !tbaa !23
  %t407 = load i32, ptr %l9, !tbaa !23
  %t409 = icmp sge i32 %t407, 0
  br i1 %t409, label %bb93, label %bb94
bb93:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load i32, ptr %l9, !tbaa !23
  %t415 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t411, i32 %t412)
  store i1 %t415, ptr %l203
  br label %bb95
bb94:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb96
bb95:
  %t416 = load i1, ptr %l203, !tbaa !21
  %t417 = xor i1 %t416, true
  store i1 %t417, ptr %l200, !tbaa !21
  br label %bb96
bb96:
  %t419 = load i1, ptr %l200, !tbaa !21
  br i1 %t419, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s14
  %t420 = load ptr, ptr %l0, !tbaa !29
  store ptr %t420, ptr %l205, !tbaa !29
  %t421 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t421, ptr %l206
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load i32, ptr %l2, !tbaa !23
  %t426 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s14, ptr %t422, i32 %t423)
  store { i64, ptr } %t426, ptr %l209
  br label %bb99
bb98:
  br label %bb102
bb99:
  %t427 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t427, 0
  %t429 = extractvalue { i64, ptr } %t427, 1
  %t430 = mul i64 %t428, 1
  %t431 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t430)
  call void @llvm.memcpy.p0.p0.i64(ptr %t431, ptr %t429, i64 %t430, i1 false)
  %t432 = insertvalue { i64, ptr } undef, i64 %t428, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr %t431, 1
  %t435 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotAValue(ptr %s14, ptr %s14, { i64, ptr } %t433)
  store %"compiler/msgs:Msg" %t435, ptr %l211
  br label %bb100
bb100:
  %t436 = load ptr, ptr %l205, !tbaa !29
  %t437 = load %"compiler/source:Span", ptr %l206
  %t438 = load %"compiler/msgs:Msg", ptr %l211
  %t439 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t436, %"compiler/source:Span" %t437, %"compiler/msgs:Msg" %t438)
  store i64 %t439, ptr %l212
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s14)
  br label %bb102
bb102:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load %"compiler/source:Span", ptr %l1
  %t444 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t440, %"compiler/source:Span" %t441)
  store ptr %t444, ptr %l215
  br label %bb103
bb103:
  %t445 = load ptr, ptr %l215, !tbaa !29
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t445, ptr %rv
  br label %ret
bb104:
  %t447 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t448 = load i32, ptr %t447
  %t450 = trunc i64 3 to i32
  %t451 = icmp eq i32 %t448, %t450
  br i1 %t451, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s15
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l219, !tbaa !29
  %t454 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t454, ptr %l220
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/check:Checker", ptr %t455, i32 0, i32 1
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t459 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t460 = load i64, ptr %t459, !tbaa !24
  %t461 = load i32, ptr %l2, !tbaa !23
  %t465 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t458, i64 %t460, i32 %t461)
  store i64 %t465, ptr %l225
  br label %bb107
bb106:
  br label %bb113
bb107:
  %t466 = icmp sge i64 0, 0
  br i1 %t466, label %bb108, label %bb109
bb108:
  %t468 = icmp sle i64 0, 2305843009213693951
  br i1 %t468, label %bb110, label %bb111
bb109:
  call void @__olang_check_failed(ptr @olang_loc_d573417cd970c31d_c74d35b0202ac379)
  unreachable
bb110:
  %t470 = mul i64 0, 4
  %t471 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t470)
  %t472 = insertvalue { i64, ptr } undef, i64 0, 0
  %t473 = insertvalue { i64, ptr } %t472, ptr %t471, 1
  %t474 = load ptr, ptr %l219, !tbaa !29
  %t475 = load %"compiler/source:Span", ptr %l220
  %t476 = load i64, ptr %l225, !tbaa !24
  %t478 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %s15, ptr %t474, %"compiler/source:Span" %t475, i64 %t476, { i64, ptr } %t473)
  store ptr %t478, ptr %l229
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_d573417cd970c31d_c74d35b0202ac379)
  unreachable
bb112:
  %t479 = load ptr, ptr %l229, !tbaa !29
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t479, ptr %rv
  br label %ret
bb113:
  %t481 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t482 = load i32, ptr %t481
  %t484 = trunc i64 8 to i32
  %t485 = icmp eq i32 %t482, %t484
  br i1 %t485, label %bb114, label %bb115
bb114:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t489 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t487)
  store ptr %t489, ptr %l235
  br label %bb116
bb115:
  br label %bb128
bb116:
  %t490 = load ptr, ptr %l235, !tbaa !29
  %t492 = getelementptr %"compiler/check:frame", ptr %t490, i32 0, i32 4
  %t493 = getelementptr %"compiler/generic:Context", ptr %t492, i32 0, i32 2
  %t494 = load i32, ptr %l2, !tbaa !23
  %t497 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t493, i32 %t494)
  %t498 = extractvalue { i32, i32 } %t497, 1
  %t499 = extractvalue { i32, i32 } %t497, 0
  store i32 %t499, ptr %l240
  %t500 = icmp ne i32 %t499, 0
  br i1 %t500, label %bb118, label %ok.501
ok.501:
  store i32 %t498, ptr %l239
  br label %bb117
bb117:
  %t502 = load i32, ptr %l239, !tbaa !23
  store i32 %t502, ptr %l233, !tbaa !23
  br label %bb120
bb118:
  br label %bb119
bb119:
  call void @__olang_ert_req_clear()
  %t503 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t503, ptr %l233, !tbaa !23
  br label %bb120
bb120:
  %t505 = load i32, ptr %l233, !tbaa !23
  %t507 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t510 = icmp ne i32 %t505, %t507
  br i1 %t510, label %bb121, label %bb122
bb121:
  store %olang.scope zeroinitializer, ptr %s17
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l245, !tbaa !29
  %t513 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t513, ptr %l246
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i32, ptr %l2, !tbaa !23
  %t518 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t514, i32 %t515)
  store { i64, ptr } %t518, ptr %l249
  br label %bb123
bb122:
  br label %bb127
bb123:
  %t519 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t520 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarAsValue(ptr %v0, ptr %s17, { i64, ptr } %t519)
  store %"compiler/msgs:Msg" %t520, ptr %l250
  br label %bb124
bb124:
  %t521 = load ptr, ptr %l245, !tbaa !29
  %t522 = load %"compiler/source:Span", ptr %l246
  %t523 = load %"compiler/msgs:Msg", ptr %l250
  %t524 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t521, %"compiler/source:Span" %t522, %"compiler/msgs:Msg" %t523)
  store i64 %t524, ptr %l251
  br label %bb125
bb125:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load %"compiler/source:Span", ptr %l1
  %t529 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t525, %"compiler/source:Span" %t526)
  store ptr %t529, ptr %l254
  br label %bb126
bb126:
  %t530 = load ptr, ptr %l254, !tbaa !29
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t530, ptr %rv
  br label %ret
bb127:
  br label %bb128
bb128:
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t532, %"compiler/source:Span" %t533, { i64, ptr } { i64 30, ptr @.d27 })
  br label %bb129
bb129:
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load %"compiler/source:Span", ptr %l1
  %t540 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t536, %"compiler/source:Span" %t537)
  store ptr %t540, ptr %l260
  br label %bb130
bb130:
  %t541 = load ptr, ptr %l260, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t541, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l27 = alloca i64
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l55 = alloca i64
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l82 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l19
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d28 }, ptr %l20, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t18, ptr %l21, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l22, !tbaa !24
  %t21 = load i64, ptr %l22, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l23, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l22, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t32, ptr %l5, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp sle i64 %t35, 4
  br i1 %t37, label %bb3, label %bb4
bb3:
  store i64 2, ptr %l27, !tbaa !24
  br label %bb5
bb4:
  store i64 3, ptr %l27, !tbaa !24
  br label %bb5
bb5:
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l9, !tbaa !24
  br label %bb8
bb7:
  br label %bb23
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t60 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t60, ptr %l38, !tbaa !27
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i32, ptr %t64, i64 %t61
  %t66 = load i32, ptr %t65, !tbaa !33
  store i32 %t66, ptr %l10, !tbaa !23
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l41, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l10, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l44
  br label %bb12
bb12:
  %t74 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t76 = call i64 @compiler_2fcheck_2enameDistance(ptr %v0, ptr %v0, { i64, ptr } %t74, { i64, ptr } %t75)
  store i64 %t76, ptr %l45
  br label %bb13
bb13:
  %t77 = load i64, ptr %l45, !tbaa !24
  store i64 %t77, ptr %l11, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  br i1 %t82, label %bb14, label %bb15
bb14:
  %t84 = load i64, ptr %l11, !tbaa !24
  store i64 %t84, ptr %l6, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l10, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t86, i32 %t87)
  store { i64, ptr } %t90, ptr %l52
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t91 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t94 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l55, !tbaa !24
  %t97 = load i64, ptr %l55, !tbaa !24
  %t98 = icmp eq i64 %t93, %t97
  br i1 %t98, label %bb17, label %bb18
bb17:
  %t100 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l55, !tbaa !24
  %t105 = mul i64 %t104, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t101, ptr %t103, i64 %t105, i1 false)
  br label %bb19
bb18:
  %t106 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l57, !tbaa !24
  %t108 = load i64, ptr %l57, !tbaa !24
  %t109 = mul i64 %t108, 1
  %t110 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l58, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l57, !tbaa !24
  %t118 = mul i64 %t117, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t114, ptr %t116, i64 %t118, i1 false)
  %t119 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t119, ptr %l5, !tbaa !27
  br label %bb19
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l8, !tbaa !24
  br label %bb8
bb22:
  br label %bb23
bb23:
  %t124 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb24, label %bb25
bb24:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l1, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t130, i32 %t131)
  store { i64, ptr } %t134, ptr %l66
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t135 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = mul i64 %t136, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l67, !tbaa !27
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l2, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %t142, i32 %t143)
  store { i64, ptr } %t146, ptr %l70
  br label %bb27
bb27:
  %t147 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = mul i64 %t148, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t150)
  call void @llvm.memcpy.p0.p0.i64(ptr %t151, ptr %t149, i64 %t150, i1 false)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  %t154 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t158 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v1, ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %t155, { i64, ptr } %t153, { i64, ptr } %t154)
  store %"compiler/msgs:Msg" %t158, ptr %l73
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t159 = load %"compiler/msgs:Msg", ptr %l73
  store %"compiler/msgs:Msg" %t159, ptr %rv
  br label %ret
bb29:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l1, !tbaa !23
  %t164 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t160, i32 %t161)
  store { i64, ptr } %t164, ptr %l76
  br label %bb30
bb30:
  %t165 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 0
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = mul i64 %t166, 1
  %t169 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t168)
  call void @llvm.memcpy.p0.p0.i64(ptr %t169, ptr %t167, i64 %t168, i1 false)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l77, !tbaa !27
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l2, !tbaa !23
  %t176 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %t172, i32 %t173)
  store { i64, ptr } %t176, ptr %l80
  br label %bb31
bb31:
  %t177 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = extractvalue { i64, ptr } %t177, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t184 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t186 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t184, { i64, ptr } %t183)
  store %"compiler/msgs:Msg" %t186, ptr %l82
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t187 = load %"compiler/msgs:Msg", ptr %l82
  store %"compiler/msgs:Msg" %t187, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoreturnSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l24 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load %"compiler/source:Span", ptr %l1
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 10, ptr @.d29 })
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l10
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store i64 %t10, ptr %l9
  br label %bb2
bb2:
  %t14 = load i64, ptr %l9, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t15 = load i64, ptr %l7, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t16, 0
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t20, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t24, 2
  %t28 = trunc i64 %t26 to i32
  %t31 = add i32 %t23, %t28
  %t32 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 10
  %t38 = trunc i64 %t36 to i32
  %t41 = add i32 %t33, %t38
  %t44 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t31, i32 %t41)
  store %"compiler/source:Span" %t44, ptr %l24
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l25 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l33 = alloca i32
  %l38 = alloca i64
  %l39 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l10
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t3, ptr %lp2
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t5 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load i64, ptr %l4, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v1, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l16
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb4, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l15
  br label %bb3
bb3:
  %t17 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t17, ptr %l12, !tbaa !27
  br label %bb8
bb4:
  %t18 = load i32, ptr %l16, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_2aeb1d20595e7cd2_796959d3edf1a336)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb8:
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t36, ptr %l25, !tbaa !27
  %t37 = load i64, ptr %l7, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 %t37
  %t42 = load i32, ptr %t41, !tbaa !33
  store i32 %t42, ptr %l8, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l28, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l8, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l33
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l8, !tbaa !23
  %t64 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t60, i32 %t61)
  store i64 %t64, ptr %l38
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l28, !tbaa !29
  %t66 = load i32, ptr %l33, !tbaa !23
  %t67 = load i64, ptr %l38, !tbaa !65
  %t68 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t65, i32 %t66, i64 %t67)
  store i32 %t68, ptr %l39
  br label %bb15
bb15:
  %t69 = load i32, ptr %l39, !tbaa !23
  store i32 %t69, ptr %l9, !tbaa !23
  %t70 = load i32, ptr %l9, !tbaa !23
  %t71 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t74 = icmp ne i32 %t70, %t71
  br i1 %t74, label %bb16, label %bb17
bb16:
  %t76 = load ptr, ptr %lp2
  %t77 = load i32, ptr %l9, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t76, i32 %t77)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l7, !tbaa !24
  br label %bb9
bb21:
  %t84 = load i64, ptr %l4, !tbaa !24
  %t85 = load i64, ptr %l6, !tbaa !24
  %t88 = add i64 %t84, %t85
  store i64 %t88, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb2
bb23:
  %t90 = load ptr, ptr %lp2
  %t91 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t90
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l19 = alloca i1
  %l22 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i32
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l109 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l116 = alloca %"compiler/msgs:Msg"
  %l117 = alloca i64
  %l121 = alloca ptr
  %l125 = alloca ptr
  %l129 = alloca i64
  %l130 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca i64
  %l145 = alloca { i64, [3 x i64] }
  %l149 = alloca { i64, ptr }
  %l151 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  %t311 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l22
  br label %bb3
bb3:
  %t12 = load i1, ptr %l22, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l19, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l26, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  store i32 %t21, ptr %l27, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t31, { i64, ptr } %t32)
  store i32 %t35, ptr %l33
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l26, !tbaa !29
  %t37 = load i32, ptr %l27, !tbaa !23
  %t38 = load i32, ptr %l33, !tbaa !23
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t36, i32 %t37, i32 %t38)
  store i64 %t39, ptr %l34
  br label %bb9
bb9:
  %t40 = load i64, ptr %l34, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l38, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  store i32 %t49, ptr %l39, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/load:Loader", ptr %t56, i32 0, i32 3
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l43, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = call { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v1, ptr %s2, { i64, ptr } %t60)
  store { i64, ptr } %t62, ptr %l45
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t63 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t72 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s2, ptr %t70, { i64, ptr } %t69)
  store i32 %t72, ptr %l47
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = load i32, ptr %l39, !tbaa !23
  %t75 = load i32, ptr %l47, !tbaa !23
  %t76 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t73, i32 %t74, i32 %t75)
  store i64 %t76, ptr %l48
  br label %bb14
bb14:
  %t77 = load i64, ptr %l48, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l54, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  store ptr %t94, ptr %l57, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t98, i64 %t99)
  store i32 %t102, ptr %l61
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = load i32, ptr %l61, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t105, ptr %l62
  br label %bb20
bb20:
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = load i32, ptr %l62, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t106, i32 %t107)
  store { i64, ptr } %t108, ptr %l63
  br label %bb21
bb21:
  %t109 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = sub i64 %t110, 1
  store i64 %t112, ptr %l8, !tbaa !24
  %t114 = load i1, ptr %l6, !tbaa !21
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t117 = load i64, ptr %l5, !tbaa !24
  %t120 = icmp sge i64 %t116, %t117
  store i1 %t120, ptr %l67, !tbaa !21
  br label %bb24
bb23:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = icmp eq i64 %t122, %t123
  store i1 %t126, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t128 = load i1, ptr %l67, !tbaa !21
  br i1 %t128, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t130 = load i64, ptr %l8, !tbaa !24
  %t132 = icmp eq i64 %t130, 0
  br i1 %t132, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 13, ptr @.d30 }, ptr %l77, !tbaa !27
  br label %bb33
bb29:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = icmp eq i64 %t134, 1
  br i1 %t136, label %bb30, label %bb31
bb30:
  store { i64, ptr } { i64 13, ptr @.d31 }, ptr %l80, !tbaa !27
  br label %bb32
bb31:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t140 = call i64 @__olang_fmt_i64(ptr null, i64 %t138)
  %t141 = extractvalue { i64, ptr } { i64 11, ptr @.d32 }, 1
  %t142 = extractvalue { i64, ptr } { i64 11, ptr @.d32 }, 0
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t143)
  %t145 = call i64 @__olang_fmt_i64(ptr %t144, i64 %t138)
  %t146 = getelementptr i8, ptr %t144, i64 %t140
  call void @olang_textcopy(ptr %t146, ptr %t141, i64 %t142)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t144, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } %t148, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l80, !tbaa !27
  br label %bb32
bb32:
  %t157 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t157, ptr %l77, !tbaa !27
  br label %bb33
bb33:
  %t158 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t158, ptr %l9, !tbaa !27
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp eq i64 %t159, 1
  br i1 %t161, label %bb34, label %bb35
bb34:
  store { i64, ptr } { i64 3, ptr @.d33 }, ptr %l86, !tbaa !27
  br label %bb36
bb35:
  %t163 = load i64, ptr %l5, !tbaa !24
  %t165 = call i64 @__olang_fmt_i64(ptr null, i64 %t163)
  %t166 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t165)
  %t167 = call i64 @__olang_fmt_i64(ptr %t166, i64 %t163)
  %t168 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t166, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = extractvalue { i64, ptr } %t169, 1
  %t173 = mul i64 %t171, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l86, !tbaa !27
  br label %bb36
bb36:
  %t178 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t178, ptr %l10, !tbaa !27
  %t179 = load i64, ptr %l5, !tbaa !24
  %t181 = icmp eq i64 %t179, 0
  br i1 %t181, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 4, ptr @.d34 }, ptr %l92, !tbaa !27
  br label %bb42
bb38:
  %t183 = load i1, ptr %l6, !tbaa !21
  br i1 %t183, label %bb39, label %bb40
bb39:
  %t185 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t186 = extractvalue { i64, ptr } { i64 9, ptr @.d35 }, 1
  %t187 = extractvalue { i64, ptr } { i64 9, ptr @.d35 }, 0
  %t189 = extractvalue { i64, ptr } %t185, 1
  %t190 = extractvalue { i64, ptr } %t185, 0
  %t191 = add i64 %t187, %t190
  %t192 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t191)
  call void @olang_textcopy(ptr %t192, ptr %t186, i64 %t187)
  %t193 = getelementptr i8, ptr %t192, i64 %t187
  call void @olang_textcopy(ptr %t193, ptr %t189, i64 %t190)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t192, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } %t195, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l94, !tbaa !27
  br label %bb41
bb40:
  %t204 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t204, ptr %l94, !tbaa !27
  br label %bb41
bb41:
  %t206 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t206, ptr %l92, !tbaa !27
  br label %bb42
bb42:
  %t207 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t207, ptr %l11, !tbaa !27
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l99, !tbaa !29
  store %"compiler/source:Span" %a3, ptr %l100
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i32, ptr %l1, !tbaa !23
  %t214 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t210, i32 %t211)
  store { i64, ptr } %t214, ptr %l103
  br label %bb43
bb43:
  %t215 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l104, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l105, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t227 = load i64, ptr %l7, !tbaa !24
  %t230 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t226, i64 %t227)
  store ptr %t230, ptr %l109
  br label %bb44
bb44:
  %t231 = load ptr, ptr %l109, !tbaa !29
  %t233 = getelementptr %"compiler/ast:Func", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %t233, !tbaa !23
  %t235 = load ptr, ptr %l105, !tbaa !29
  %t237 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t235, i32 %t234)
  store { i64, ptr } %t237, ptr %l112
  br label %bb45
bb45:
  %t238 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t246 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %s0, ptr %v0, ptr %s0, ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t241, { i64, ptr } %t242, { i64, ptr } %t238, { i64, ptr } %a4, { i64, ptr } %t240)
  store %"compiler/msgs:Msg" %t246, ptr %l116
  br label %bb46
bb46:
  %t247 = load ptr, ptr %l99, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l100
  %t249 = load %"compiler/msgs:Msg", ptr %l116
  %t250 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t247, %"compiler/source:Span" %t248, %"compiler/msgs:Msg" %t249)
  store i64 %t250, ptr %l117
  br label %bb47
bb47:
  %t251 = load i64, ptr %l117, !tbaa !24
  store i64 %t251, ptr %l12, !tbaa !24
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l7, !tbaa !24
  %t259 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t255, i64 %t256)
  store ptr %t259, ptr %l121
  br label %bb48
bb48:
  %t260 = load ptr, ptr %l121, !tbaa !29
  store ptr %t260, ptr %l13, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 0
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/load:Loader", ptr %t267, i32 0, i32 5
  store ptr %t269, ptr %l125, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = load i64, ptr %l7, !tbaa !24
  %t277 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t273, i64 %t274)
  store i64 %t277, ptr %l129
  br label %bb49
bb49:
  %t278 = load ptr, ptr %l125, !tbaa !29
  %t279 = load i64, ptr %l129, !tbaa !24
  %t280 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t278, i64 %t279)
  store ptr %t280, ptr %l130
  br label %bb50
bb50:
  %t281 = load ptr, ptr %l130, !tbaa !29
  %t283 = getelementptr %"compiler/load:Module", ptr %t281, i32 0, i32 4
  %t284 = load i64, ptr %t283, !tbaa !24
  %t286 = load ptr, ptr %l13, !tbaa !29
  %t288 = getelementptr %"compiler/ast:Func", ptr %t286, i32 0, i32 0
  %t289 = load %"compiler/source:Span", ptr %t288
  store %"compiler/source:Span" %t289, ptr %l15
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/load:Loader", ptr %t297, i32 0, i32 4
  %t300 = load ptr, ptr %t299, !tbaa !29
  store ptr %t300, ptr %l138, !tbaa !29
  %t301 = load i64, ptr %l12, !tbaa !24
  store i64 %t301, ptr %l139, !tbaa !24
  %t303 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t304 = load i32, ptr %t303, !tbaa !23
  %t306 = sext i32 %t304 to i64
  %t307 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 1
  %t308 = load i32, ptr %t307, !tbaa !23
  %t310 = sext i32 %t308 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t311
  %t312 = getelementptr { i64, [3 x i64] }, ptr %t311, i32 0, i32 0
  store i64 3, ptr %t312
  %t314 = insertvalue { i64, i64, i64 } undef, i64 %t284, 0
  %t316 = insertvalue { i64, i64, i64 } %t314, i64 %t306, 1
  %t318 = insertvalue { i64, i64, i64 } %t316, i64 %t310, 2
  %t319 = getelementptr { i64, [3 x i64] }, ptr %t311, i32 0, i32 1
  store { i64, i64, i64 } %t318, ptr %t319
  %t320 = load { i64, [3 x i64] }, ptr %t311
  store { i64, [3 x i64] } %t320, ptr %l145
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l13, !tbaa !29
  %t324 = getelementptr %"compiler/ast:Func", ptr %t322, i32 0, i32 2
  %t325 = load i32, ptr %t324, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t321, i32 %t325)
  store { i64, ptr } %t328, ptr %l149
  br label %bb51
bb51:
  %t329 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t337 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s0, ptr %s0, { i64, ptr } %t335)
  store %"compiler/msgs:Msg" %t337, ptr %l151
  br label %bb52
bb52:
  %t338 = load ptr, ptr %l138, !tbaa !29
  %t339 = load i64, ptr %l139, !tbaa !24
  %t340 = load { i64, [3 x i64] }, ptr %l145
  %t341 = load %"compiler/msgs:Msg", ptr %l151
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t338, i64 %t339, { i64, [3 x i64] } %t340, %"compiler/msgs:Msg" %t341)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverflowsF64(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/check:litv"
  %l7 = alloca %"compiler/check:litv"
  %l8 = alloca { ptr, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l34 = alloca %"compiler/check:litv"
  %l38 = alloca %"compiler/check:litv"
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverflowsF64(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l17
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i1, ptr %l17, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 5
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb23
bb12:
  %t49 = load i32, ptr %l3
  %t51 = trunc i64 51 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t60 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t55, ptr %t56)
  store %"compiler/check:litv" %t60, ptr %l34
  br label %bb16
bb16:
  %t61 = load %"compiler/check:litv", ptr %l34
  store %"compiler/check:litv" %t61, ptr %l6
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t67 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store %"compiler/check:litv" %t67, ptr %l38
  br label %bb17
bb17:
  %t68 = load %"compiler/check:litv", ptr %l38
  store %"compiler/check:litv" %t68, ptr %l7
  %t69 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_36, 0
  %t70 = insertvalue { ptr, ptr } %t69, ptr null, 1
  store { ptr, ptr } %t70, ptr %l8
  %t72 = load { ptr, ptr }, ptr %l8
  %t73 = load %"compiler/check:litv", ptr %l6
  %t75 = extractvalue { ptr, ptr } %t72, 0
  %t76 = extractvalue { ptr, ptr } %t72, 1
  %t78 = call i1 %t75(ptr %t76, %"compiler/check:litv" %t73)
  store i1 %t78, ptr %l42
  br label %bb18
bb18:
  %t79 = load i1, ptr %l42, !tbaa !21
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t80 = load { ptr, ptr }, ptr %l8
  %t81 = load %"compiler/check:litv", ptr %l7
  %t83 = extractvalue { ptr, ptr } %t80, 0
  %t84 = extractvalue { ptr, ptr } %t80, 1
  %t86 = call i1 %t83(ptr %t84, %"compiler/check:litv" %t81)
  store i1 %t86, ptr %l46
  br label %bb21
bb20:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb22
bb21:
  %t87 = load i1, ptr %l46, !tbaa !21
  store i1 %t87, ptr %l43, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load i1, ptr %l43, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereset(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca ptr
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca ptr
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca ptr
  %l21 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca ptr
  %l25 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca ptr
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca ptr
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca ptr
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca ptr
  %l35 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca ptr
  %l37 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca ptr
  %l39 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca ptr
  %l41 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca ptr
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca ptr
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca ptr
  %l47 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca ptr
  %l50 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca ptr
  %l52 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca ptr
  %l54 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca ptr
  %l56 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca ptr
  %l58 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca ptr
  %l60 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca ptr
  %l62 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca ptr
  %l64 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca ptr
  %l66 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca ptr
  %l68 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca ptr
  %l70 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca ptr
  %l72 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca ptr
  %l74 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca ptr
  %l76 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca ptr
  %l78 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca ptr
  %l80 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca ptr
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca ptr
  %l84 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca ptr
  %l86 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca ptr
  %l88 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca ptr
  %l90 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca ptr
  %l92 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca ptr
  %l94 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca ptr
  %l96 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l97 = alloca ptr
  %l98 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca ptr
  %l100 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca ptr
  %l102 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l103 = alloca ptr
  %l104 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l105 = alloca ptr
  %l106 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l107 = alloca ptr
  %l108 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l109 = alloca ptr
  %l110 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca ptr
  %l112 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca ptr
  %l114 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l3, !tbaa !29
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l4
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t10
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l5, !tbaa !29
  %t12 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l6
  br label %bb3
bb3:
  %t13 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 90
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %t15
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l7, !tbaa !29
  %t17 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l8
  br label %bb4
bb4:
  %t18 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t19 = load ptr, ptr %l7, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 92
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %t20
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l9, !tbaa !29
  %t22 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l10
  br label %bb5
bb5:
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t24 = load ptr, ptr %l9, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 93
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %t25
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResetAny(ptr %v0, ptr %t29)
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l13, !tbaa !29
  %t32 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l14
  br label %bb7
bb7:
  %t33 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t35
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l15, !tbaa !29
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l16
  br label %bb8
bb8:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t39 = load ptr, ptr %l15, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %t40
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 15
  store i64 0, ptr %t43, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l18, !tbaa !29
  %t45 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l19
  br label %bb9
bb9:
  %t46 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  %t47 = load ptr, ptr %l18, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %t48
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l20, !tbaa !29
  %t50 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l21
  br label %bb10
bb10:
  %t51 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 17
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %t53
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l22, !tbaa !29
  %t55 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l23
  br label %bb11
bb11:
  %t56 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  %t57 = load ptr, ptr %l22, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 20
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %t58
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l24, !tbaa !29
  %t60 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l25
  br label %bb12
bb12:
  %t61 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  %t62 = load ptr, ptr %l24, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 21
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %t63
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 22
  store i32 %t65, ptr %t68, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l28, !tbaa !29
  %t70 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l29
  br label %bb13
bb13:
  %t71 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  %t72 = load ptr, ptr %l28, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 23
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %t73
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l30, !tbaa !29
  %t75 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l31
  br label %bb14
bb14:
  %t76 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  %t77 = load ptr, ptr %l30, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 24
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %t78
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l32, !tbaa !29
  %t80 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %l33
  br label %bb15
bb15:
  %t81 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  %t82 = load ptr, ptr %l32, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %t83
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l34, !tbaa !29
  %t85 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l35
  br label %bb16
bb16:
  %t86 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  %t87 = load ptr, ptr %l34, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 26
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %t88
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l36, !tbaa !29
  %t90 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %l37
  br label %bb17
bb17:
  %t91 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  %t92 = load ptr, ptr %l36, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %t93
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l38, !tbaa !29
  %t95 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %l39
  br label %bb18
bb18:
  %t96 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  %t97 = load ptr, ptr %l38, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 28
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %t98
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l40, !tbaa !29
  %t100 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %l41
  br label %bb19
bb19:
  %t101 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  %t102 = load ptr, ptr %l40, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t101, ptr %t103
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l42, !tbaa !29
  %t105 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l43
  br label %bb20
bb20:
  %t106 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  %t107 = load ptr, ptr %l42, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %t108
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l44, !tbaa !29
  %t110 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %l45
  br label %bb21
bb21:
  %t111 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  %t112 = load ptr, ptr %l44, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 33
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %t113
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l46, !tbaa !29
  %t115 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %l47
  br label %bb22
bb22:
  %t116 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  %t117 = load ptr, ptr %l46, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %t118
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 35
  store i32 0, ptr %t121, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l49, !tbaa !29
  %t123 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t123, ptr %l50
  br label %bb23
bb23:
  %t124 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  %t125 = load ptr, ptr %l49, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 47
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %t126
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l51, !tbaa !29
  %t128 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %l52
  br label %bb24
bb24:
  %t129 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  %t130 = load ptr, ptr %l51, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 48
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t129, ptr %t131
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l53, !tbaa !29
  %t133 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %l54
  br label %bb25
bb25:
  %t134 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  %t135 = load ptr, ptr %l53, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 49
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %t136
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l55, !tbaa !29
  %t138 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %l56
  br label %bb26
bb26:
  %t139 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  %t140 = load ptr, ptr %l55, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 50
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t139, ptr %t141
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l57, !tbaa !29
  %t143 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, ptr %l58
  br label %bb27
bb27:
  %t144 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  %t145 = load ptr, ptr %l57, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 52
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %t146
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l59, !tbaa !29
  %t148 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %l60
  br label %bb28
bb28:
  %t149 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  %t150 = load ptr, ptr %l59, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 54
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t149, ptr %t151
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l61, !tbaa !29
  %t153 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t153, ptr %l62
  br label %bb29
bb29:
  %t154 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  %t155 = load ptr, ptr %l61, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 55
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %t156
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l63, !tbaa !29
  %t158 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, ptr %l64
  br label %bb30
bb30:
  %t159 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  %t160 = load ptr, ptr %l63, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 56
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t159, ptr %t161
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l65, !tbaa !29
  %t163 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t163, ptr %l66
  br label %bb31
bb31:
  %t164 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  %t165 = load ptr, ptr %l65, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 57
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %t166
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l67, !tbaa !29
  %t168 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t168, ptr %l68
  br label %bb32
bb32:
  %t169 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  %t170 = load ptr, ptr %l67, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 58
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t169, ptr %t171
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l69, !tbaa !29
  %t173 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H94cbbacdefacbf11591e45fa927fb1cb(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t173, ptr %l70
  br label %bb33
bb33:
  %t174 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  %t175 = load ptr, ptr %l69, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 59
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t174, ptr %t176
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l71, !tbaa !29
  %t178 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t178, ptr %l72
  br label %bb34
bb34:
  %t179 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l72
  %t180 = load ptr, ptr %l71, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 60
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t179, ptr %t181
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l73, !tbaa !29
  %t183 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l74
  br label %bb35
bb35:
  %t184 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  %t185 = load ptr, ptr %l73, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 61
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %t186
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l75, !tbaa !29
  %t188 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2flis_H596e3d714cead58c6bb1a410db388b73(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t188, ptr %l76
  br label %bb36
bb36:
  %t189 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  %t190 = load ptr, ptr %l75, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t190, i32 0, i32 62
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t189, ptr %t191
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l77, !tbaa !29
  %t193 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t193, ptr %l78
  br label %bb37
bb37:
  %t194 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  %t195 = load ptr, ptr %l77, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 63
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t194, ptr %t196
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l79, !tbaa !29
  %t198 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t198, ptr %l80
  br label %bb38
bb38:
  %t199 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  %t200 = load ptr, ptr %l79, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t199, ptr %t201
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l81, !tbaa !29
  %t203 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t203, ptr %l82
  br label %bb39
bb39:
  %t204 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  %t205 = load ptr, ptr %l81, !tbaa !29
  %t206 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 65
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t204, ptr %t206
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l83, !tbaa !29
  %t208 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroDeepArg_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t208, ptr %l84
  br label %bb40
bb40:
  %t209 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  %t210 = load ptr, ptr %l83, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 66
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t209, ptr %t211
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l85, !tbaa !29
  %t213 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t213, ptr %l86
  br label %bb41
bb41:
  %t214 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  %t215 = load ptr, ptr %l85, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t215, i32 0, i32 67
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t214, ptr %t216
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l87, !tbaa !29
  %t218 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t218, ptr %l88
  br label %bb42
bb42:
  %t219 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  %t220 = load ptr, ptr %l87, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 68
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %t221
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l89, !tbaa !29
  %t223 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t223, ptr %l90
  br label %bb43
bb43:
  %t224 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  %t225 = load ptr, ptr %l89, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 69
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t224, ptr %t226
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l91, !tbaa !29
  %t228 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t228, ptr %l92
  br label %bb44
bb44:
  %t229 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  %t230 = load ptr, ptr %l91, !tbaa !29
  %t231 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 74
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t229, ptr %t231
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l93, !tbaa !29
  %t233 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t233, ptr %l94
  br label %bb45
bb45:
  %t234 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l94
  %t235 = load ptr, ptr %l93, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 75
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %t236
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l95, !tbaa !29
  %t238 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %l96
  br label %bb46
bb46:
  %t239 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  %t240 = load ptr, ptr %l95, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 76
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t239, ptr %t241
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l97, !tbaa !29
  %t243 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t243, ptr %l98
  br label %bb47
bb47:
  %t244 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  %t245 = load ptr, ptr %l97, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 77
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t244, ptr %t246
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l99, !tbaa !29
  %t248 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t248, ptr %l100
  br label %bb48
bb48:
  %t249 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  %t250 = load ptr, ptr %l99, !tbaa !29
  %t251 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 78
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t249, ptr %t251
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l101, !tbaa !29
  %t253 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t253, ptr %l102
  br label %bb49
bb49:
  %t254 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l102
  %t255 = load ptr, ptr %l101, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t255, i32 0, i32 79
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t254, ptr %t256
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l103, !tbaa !29
  %t258 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t258, ptr %l104
  br label %bb50
bb50:
  %t259 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  %t260 = load ptr, ptr %l103, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t260, i32 0, i32 80
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t259, ptr %t261
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l105, !tbaa !29
  %t263 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t263, ptr %l106
  br label %bb51
bb51:
  %t264 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l106
  %t265 = load ptr, ptr %l105, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 81
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t264, ptr %t266
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l107, !tbaa !29
  %t268 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t268, ptr %l108
  br label %bb52
bb52:
  %t269 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l108
  %t270 = load ptr, ptr %l107, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 84
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t269, ptr %t271
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l109, !tbaa !29
  %t273 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t273, ptr %l110
  br label %bb53
bb53:
  %t274 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  %t275 = load ptr, ptr %l109, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 85
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t274, ptr %t276
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l111, !tbaa !29
  %t278 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t278, ptr %l112
  br label %bb54
bb54:
  %t279 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l112
  %t280 = load ptr, ptr %l111, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 86
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t279, ptr %t281
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l113, !tbaa !29
  %t283 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t283, ptr %l114
  br label %bb55
bb55:
  %t284 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l114
  %t285 = load ptr, ptr %l113, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 87
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t284, ptr %t286
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCheckCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i1
  %l20 = alloca i64
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l55 = alloca i64
  %l58 = alloca i64
  %l79 = alloca i1
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 16
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l20
  br label %bb4
bb4:
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = icmp ne i64 %t18, 0
  store i1 %t19, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l16, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb9
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t26, ptr %l25
  br label %bb8
bb8:
  %t27 = load i1, ptr %l25, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l22, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l29
  br label %bb13
bb13:
  %t36 = load i1, ptr %l29, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l34
  br label %bb16
bb15:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb17
bb16:
  %t44 = load i1, ptr %l34, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l31, !tbaa !21
  br label %bb17
bb17:
  %t47 = load i1, ptr %l31, !tbaa !21
  br i1 %t47, label %bb18, label %bb19
bb18:
  br label %ret
bb19:
  br label %bb20
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  store ptr %t53, ptr %l38, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 11
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l45
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l45, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Body", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t71, i32 %t70)
  store i32 %t73, ptr %l48
  br label %bb22
bb22:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i32, ptr %l48, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t74, i32 %t75)
  store { i64, ptr } %t76, ptr %l49
  br label %bb23
bb23:
  %t77 = load { i64, ptr }, ptr %l49, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t80 = extractvalue { i64, ptr } %t77, 0
  store i64 %t80, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb24, label %bb25
bb24:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb29
bb26:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t93 = load i64, ptr %l5, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l58, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb28
bb28:
  %t108 = load i64, ptr %l58, !tbaa !24
  store i64 %t108, ptr %l55, !tbaa !24
  br label %bb29
bb29:
  %t109 = load i64, ptr %l55, !tbaa !24
  store i64 %t109, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb32:
  br label %bb33
bb33:
  %t118 = load i64, ptr %l5, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t120 = load i64, ptr %l7, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l3, !tbaa !24
  %t134 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t128, i64 %t129, i64 %t126)
  store i1 %t134, ptr %l79
  br label %bb34
bb34:
  %t135 = load i1, ptr %l79, !tbaa !21
  br i1 %t135, label %bb35, label %bb36
bb35:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %t136, i64 %t137)
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb39:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l9, !tbaa !24
  br label %bb30
bb40:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i1
  %l23 = alloca i32
  %l26 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l8
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l6, !tbaa !29
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l11
  br label %bb4
bb4:
  %t16 = load i1, ptr %l11, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l5, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t20)
  store i32 %t23, ptr %l15
  br label %bb9
bb9:
  %t24 = load i32, ptr %l15, !tbaa !23
  store i32 %t24, ptr %l2, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l18
  br label %bb10
bb10:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l2, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t41 = load i32, ptr %l23, !tbaa !23
  store i32 %t41, ptr %l2, !tbaa !23
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l26
  br label %bb15
bb15:
  %t47 = load i1, ptr %l26, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb16, label %bb17
bb16:
  br label %ret
bb17:
  br label %bb18
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 65
  store ptr %t52, ptr %l29, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t53)
  store ptr %t55, ptr %l31
  br label %bb19
bb19:
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t58 = getelementptr %"compiler/check:frame", ptr %t56, i32 0, i32 0
  %t59 = load i64, ptr %t58, !tbaa !24
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t63 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, ptr %v0, i64 %t59, ptr %t60)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t63, ptr %l35
  br label %bb20
bb20:
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l35
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compil_H33d643ee420c12f578033f46e688097e(ptr %v0, ptr %v0, ptr %t64, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t65)
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t10 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  store i64 %t10, ptr %l8
  br label %bb4
bb4:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 58
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t19)
  store ptr %t21, ptr %l14
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t25, i64 %t26)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t29, ptr %l18
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l12, !tbaa !29
  %t31 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t30, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, i1 true)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l33 = alloca { i64, ptr }
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l55 = alloca { i64, ptr }
  %l62 = alloca i32
  %l67 = alloca i32
  %l69 = alloca i64
  %l74 = alloca i64
  %l82 = alloca ptr
  %l87 = alloca i32
  %l89 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l18
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t3, ptr %lp3
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  %t5 = load ptr, ptr %lp3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store ptr %a1, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load i64, ptr %l5, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v1, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l24
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb4, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l23
  br label %bb3
bb3:
  %t17 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t17, ptr %l20, !tbaa !27
  br label %bb8
bb4:
  %t18 = load i32, ptr %l24, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_af79aa682331a71e_538108f01047ae92)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb8:
  %t23 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l8, !tbaa !24
  %t29 = load i64, ptr %l7, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb11:
  br label %bb12
bb12:
  %t36 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t36, ptr %l33, !tbaa !27
  %t37 = load i64, ptr %l8, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 %t37
  %t42 = load i32, ptr %t41, !tbaa !33
  store i32 %t42, ptr %l9, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l9, !tbaa !23
  %t53 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t49, i32 %t50)
  store i64 %t53, ptr %l40
  br label %bb13
bb13:
  %t54 = load i64, ptr %l40, !tbaa !65
  store i64 %t54, ptr %l10, !tbaa !65
  store ptr %a2, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t57 = load ptr, ptr %l11, !tbaa !29
  %t58 = load i64, ptr %l12, !tbaa !24
  %t61 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v2, ptr %t57, i64 %t58)
  %t62 = extractvalue { i32, { i64, ptr } } %t61, 1
  %t63 = extractvalue { i32, { i64, ptr } } %t61, 0
  store i32 %t63, ptr %l46
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb16, label %ok.65
ok.65:
  store { i64, ptr } %t62, ptr %l45
  br label %bb15
bb15:
  %t66 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t66, ptr %l42, !tbaa !27
  br label %bb20
bb16:
  %t67 = load i32, ptr %l46, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_17d8aaff70de119f_90c04534d00fd893)
  unreachable
bb19:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb20:
  %t72 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t72, ptr %l13, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  store i64 %t75, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t77 = load i64, ptr %l15, !tbaa !24
  %t78 = load i64, ptr %l14, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t85 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t85, ptr %l55, !tbaa !27
  %t86 = load i64, ptr %l15, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i32, ptr %t89, i64 %t86
  %t91 = load i32, ptr %t90, !tbaa !33
  store i32 %t91, ptr %l16, !tbaa !23
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l9, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l62
  br label %bb25
bb25:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load i32, ptr %l16, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l67
  br label %bb26
bb26:
  %t113 = load i32, ptr %l62, !tbaa !23
  %t114 = load i32, ptr %l67, !tbaa !23
  %t115 = icmp eq i32 %t113, %t114
  br i1 %t115, label %bb27, label %bb28
bb27:
  %t117 = load i64, ptr %l10, !tbaa !65
  store i64 %t117, ptr %l69, !tbaa !65
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %l16, !tbaa !23
  %t127 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t123, i32 %t124)
  store i64 %t127, ptr %l74
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t128 = load i64, ptr %l74, !tbaa !65
  %t129 = xor i64 %t128, -1
  %t130 = load i64, ptr %l69, !tbaa !65
  %t132 = and i64 %t130, %t129
  store i64 %t132, ptr %l10, !tbaa !65
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  %t134 = load i64, ptr %l15, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l15, !tbaa !24
  br label %bb21
bb32:
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l14, !tbaa !24
  %t142 = add i64 %t138, %t139
  store i64 %t142, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  br label %bb14
bb34:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l9, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l87
  br label %bb35
bb35:
  %t155 = load i64, ptr %l10, !tbaa !65
  %t156 = load ptr, ptr %l82, !tbaa !29
  %t157 = load i32, ptr %l87, !tbaa !23
  %t159 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t156, i32 %t157, i64 %t155)
  store i32 %t159, ptr %l89
  br label %bb36
bb36:
  %t160 = load i32, ptr %l89, !tbaa !23
  store i32 %t160, ptr %l17, !tbaa !23
  %t161 = load i32, ptr %l17, !tbaa !23
  %t162 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t165 = icmp ne i32 %t161, %t162
  br i1 %t165, label %bb37, label %bb38
bb37:
  %t167 = load ptr, ptr %lp3
  %t168 = load i32, ptr %l17, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3, ptr %t167, i32 %t168)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  %t171 = load i64, ptr %l8, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l8, !tbaa !24
  br label %bb9
bb42:
  %t175 = load i64, ptr %l5, !tbaa !24
  %t176 = load i64, ptr %l7, !tbaa !24
  %t179 = add i64 %t175, %t176
  store i64 %t179, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  br label %bb2
bb44:
  %t181 = load ptr, ptr %lp3
  %t182 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t181
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l4 = alloca ptr
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t9 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %t6, i32 %a1, %"compiler/source:Span" %a2)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i32
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca i1
  %l62 = alloca i64
  %l65 = alloca %"compiler/source:Span"
  %l70 = alloca i32
  %l74 = alloca ptr
  %l81 = alloca i32
  %l86 = alloca i32
  %l93 = alloca i1
  %l96 = alloca i1
  %l100 = alloca ptr
  %l103 = alloca i64
  %l109 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l115 = alloca { i64, ptr }
  %l117 = alloca %"compiler/msgs:Msg"
  %l118 = alloca i64
  %l121 = alloca ptr
  %l124 = alloca i64
  %l127 = alloca i1
  %l134 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l141 = alloca i32
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca ptr
  %l150 = alloca %"compiler/source:Span"
  %l151 = alloca ptr
  %l154 = alloca ptr
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca %"compiler/source:Span"
  %l157 = alloca i64
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l178 = alloca i32
  %l179 = alloca ptr
  %l181 = alloca %"compiler/source:Span"
  %l182 = alloca ptr
  %l186 = alloca i64
  %l191 = alloca ptr
  %l195 = alloca ptr
  %l196 = alloca %"compiler/source:Span"
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca i64
  %l202 = alloca ptr
  %l203 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l217 = alloca ptr
  %l218 = alloca %"compiler/source:Span"
  %l220 = alloca i32
  %l221 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca ptr
  %l226 = alloca i32
  %l227 = alloca ptr
  %l231 = alloca ptr
  %l232 = alloca %"compiler/source:Span"
  %l234 = alloca i32
  %l235 = alloca i32
  %l236 = alloca %"compiler/source:Span"
  %l242 = alloca i32
  %l246 = alloca ptr
  %l248 = alloca ptr
  %l249 = alloca ptr
  %l251 = alloca i32
  %l252 = alloca ptr
  %l256 = alloca i1
  %l257 = alloca i32
  %l261 = alloca ptr
  %l266 = alloca i32
  %l269 = alloca i32
  %l274 = alloca i32
  %l275 = alloca i32
  %l276 = alloca %"compiler/source:Span"
  %l282 = alloca i32
  %l283 = alloca ptr
  %l286 = alloca ptr
  %l291 = alloca %"compiler/typed:Slice"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  %t100 = alloca { i64, [4 x i64] }, align 8
  %t456 = alloca { i64, [5 x i64] }, align 8
  %t559 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l6, !tbaa !29
  %t3 = load ptr, ptr %l6, !tbaa !29
  %t5 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i32, ptr %l26, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t7, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  store i64 4, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l11, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l10, !tbaa !24
  %t20 = load i64, ptr %l9, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l11, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l11, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l34, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l34, !tbaa !24
  store i64 %t35, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l31, !tbaa !24
  store i64 %t36, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = load i64, ptr %l12, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l13, !tbaa !24
  %t47 = load i64, ptr %l11, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l14, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l7, !tbaa !23
  %t59 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l54
  br label %bb12
bb12:
  %t60 = load i1, ptr %l54, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb14:
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v0, ptr %t63, ptr %t64)
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l7, !tbaa !23
  %t76 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t72, i32 %t73)
  store i64 %t76, ptr %l62
  br label %bb17
bb17:
  %t77 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t78 = load i64, ptr %l62, !tbaa !24
  %t80 = and i64 %t78, %t77
  store i64 %t80, ptr %l8, !tbaa !24
  %t82 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t82, ptr %l65
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l7, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l70
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t93, %"compiler/source:Span" %t94, ptr %t95)
  store ptr %t99, ptr %l74
  br label %bb19
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 0
  store i64 2, ptr %t101
  %t102 = load %"compiler/source:Span", ptr %l65
  %t103 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t102, 0
  %t104 = load i32, ptr %l70, !tbaa !23
  %t105 = insertvalue { %"compiler/source:Span", i32, ptr } %t103, i32 %t104, 1
  %t106 = load ptr, ptr %l74, !tbaa !29
  %t107 = insertvalue { %"compiler/source:Span", i32, ptr } %t105, ptr %t106, 2
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t107, ptr %t108
  %t109 = load { i64, [4 x i64] }, ptr %t100
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t109, ptr %t111
  store ptr %t111, ptr %l6, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l7, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l81
  br label %bb20
bb20:
  %t123 = load i32, ptr %l81, !tbaa !23
  store i32 %t123, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t124 = load i64, ptr %l13, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l13, !tbaa !24
  br label %bb8
bb22:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l7, !tbaa !23
  %t132 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l86
  br label %bb23
bb23:
  %t133 = load i32, ptr %l86, !tbaa !23
  store i32 %t133, ptr %l15, !tbaa !23
  %t134 = load i32, ptr %l15, !tbaa !23
  %t135 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t138 = icmp eq i32 %t134, %t135
  br i1 %t138, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t140 = load i32, ptr %l7, !tbaa !23
  %t141 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t144 = icmp eq i32 %t140, %t141
  br i1 %t144, label %bb26, label %bb27
bb25:
  br label %bb102
bb26:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb29
bb27:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l7, !tbaa !23
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l96
  br label %bb28
bb28:
  %t151 = load i1, ptr %l96, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l93, !tbaa !21
  br label %bb29
bb29:
  %t154 = load i1, ptr %l93, !tbaa !21
  br i1 %t154, label %bb30, label %bb31
bb30:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l1
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t155, %"compiler/source:Span" %t156)
  store ptr %t159, ptr %l100
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s5)
  %t160 = load ptr, ptr %l100, !tbaa !29
  store ptr %t160, ptr %rv
  br label %ret
bb33:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l7, !tbaa !23
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t161, i32 %t162, { i64, ptr } { i64 5, ptr @.d37 }, i64 2)
  store i64 %t165, ptr %l103
  br label %bb34
bb34:
  %t166 = load i64, ptr %l103, !tbaa !24
  store i64 %t166, ptr %l16, !tbaa !24
  %t167 = load i64, ptr %l16, !tbaa !24
  %t169 = icmp slt i64 %t167, 0
  br i1 %t169, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l7, !tbaa !23
  %t173 = load %"compiler/source:Span", ptr %l1
  %t177 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s7, ptr %s7, ptr %t171, i32 %t172, { i64, ptr } { i64 5, ptr @.d38 }, %"compiler/source:Span" %t173, { i64, ptr } { i64 10, ptr @.d39 }, i64 2, i1 false)
  store i1 %t177, ptr %l109
  br label %bb37
bb36:
  br label %bb45
bb37:
  %t178 = load i1, ptr %l109, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l111, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t182, ptr %l112
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l7, !tbaa !23
  %t187 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t183, i32 %t184)
  store { i64, ptr } %t187, ptr %l115
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t188 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = extractvalue { i64, ptr } %t188, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  %t196 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s8, ptr %s8, { i64, ptr } %t194)
  store %"compiler/msgs:Msg" %t196, ptr %l117
  br label %bb41
bb41:
  %t197 = load ptr, ptr %l111, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l112
  %t199 = load %"compiler/msgs:Msg", ptr %l117
  %t200 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t197, %"compiler/source:Span" %t198, %"compiler/msgs:Msg" %t199)
  store i64 %t200, ptr %l118
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb43:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  %t205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t201, %"compiler/source:Span" %t202)
  store ptr %t205, ptr %l121
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  %t206 = load ptr, ptr %l121, !tbaa !29
  store ptr %t206, ptr %rv
  br label %ret
bb45:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l7, !tbaa !23
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t207, i32 %t208, { i64, ptr } { i64 3, ptr @.d40 }, i64 0)
  store i64 %t211, ptr %l124
  br label %bb46
bb46:
  %t212 = load i64, ptr %l124, !tbaa !24
  store i64 %t212, ptr %l17, !tbaa !24
  %t213 = load ptr, ptr %l4, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  br i1 %t215, label %bb47, label %bb48
bb47:
  %t217 = load i64, ptr %l17, !tbaa !24
  %t219 = icmp slt i64 %t217, 0
  store i1 %t219, ptr %l127, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb49
bb49:
  %t221 = load i1, ptr %l127, !tbaa !21
  br i1 %t221, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s9, ptr %t222, %"compiler/source:Span" %t223, { i64, ptr } { i64 47, ptr @.d41 })
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  %t230 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t226, %"compiler/source:Span" %t227)
  store ptr %t230, ptr %l134
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  %t231 = load ptr, ptr %l134, !tbaa !29
  store ptr %t231, ptr %rv
  br label %ret
bb54:
  %t232 = load ptr, ptr %l3, !tbaa !29
  %t234 = icmp eq ptr %t232, null
  br i1 %t234, label %bb55, label %bb56
bb55:
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l138, !tbaa !29
  %t237 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t237, ptr %l139
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t238)
  store i32 %t240, ptr %l141
  br label %bb57
bb56:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l143, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l144, !tbaa !29
  %t243 = load ptr, ptr %l3, !tbaa !29
  store ptr %t243, ptr %l145, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t244)
  store i32 %t246, ptr %l147
  br label %bb59
bb57:
  %t247 = load ptr, ptr %l138, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l139
  %t249 = load i32, ptr %l141, !tbaa !23
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t247, %"compiler/source:Span" %t248, i32 %t249, i64 0)
  store ptr %t250, ptr %l142
  br label %bb58
bb58:
  %t251 = load ptr, ptr %l142, !tbaa !29
  store ptr %t251, ptr %l137, !tbaa !29
  br label %bb63
bb59:
  %t252 = load ptr, ptr %l144, !tbaa !29
  %t253 = load ptr, ptr %l145, !tbaa !29
  %t254 = load i32, ptr %l147, !tbaa !23
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t252, ptr %t253, i32 %t254)
  store ptr %t255, ptr %l148
  br label %bb60
bb60:
  %t256 = load ptr, ptr %l3, !tbaa !29
  %t258 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t256)
  store %"compiler/source:Span" %t258, ptr %l150
  br label %bb61
bb61:
  %t259 = load ptr, ptr %l143, !tbaa !29
  %t260 = load ptr, ptr %l148, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l150
  %t262 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t259, ptr %t260, %"compiler/source:Span" %t261)
  store ptr %t262, ptr %l151
  br label %bb62
bb62:
  %t263 = load ptr, ptr %l151, !tbaa !29
  store ptr %t263, ptr %l137, !tbaa !29
  br label %bb63
bb63:
  %t264 = load ptr, ptr %l137, !tbaa !29
  store ptr %t264, ptr %l18, !tbaa !29
  store ptr null, ptr %l19, !tbaa !29
  %t265 = load ptr, ptr %l4, !tbaa !29
  %t267 = icmp eq ptr %t265, null
  br i1 %t267, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s10
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l154, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t270, ptr %l155
  %t271 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t271, ptr %l156
  %t272 = load i64, ptr %l17, !tbaa !24
  store i64 %t272, ptr %l157, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load %"compiler/source:Span", ptr %l1
  %t275 = load ptr, ptr %l6, !tbaa !29
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t273, %"compiler/source:Span" %t274, ptr %t275)
  store ptr %t279, ptr %l161
  br label %bb66
bb65:
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l174, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t281, ptr %l175, !tbaa !29
  %t282 = load ptr, ptr %l4, !tbaa !29
  store ptr %t282, ptr %l176, !tbaa !29
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t283)
  store i32 %t285, ptr %l178
  br label %bb80
bb66:
  %t286 = load ptr, ptr %l161, !tbaa !29
  store ptr %t286, ptr %l162, !tbaa !29
  %t287 = icmp sge i64 0, 0
  br i1 %t287, label %bb67, label %bb68
bb67:
  %t289 = icmp sle i64 0, 1152921504606846975
  br i1 %t289, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb69:
  %t291 = mul i64 0, 8
  %t292 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t291)
  %t293 = insertvalue { i64, ptr } undef, i64 0, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  store { i64, ptr } %t294, ptr %l165, !tbaa !27
  %t295 = icmp sge i64 0, 0
  br i1 %t295, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb71:
  %t297 = icmp sle i64 0, 1152921504606846975
  br i1 %t297, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb73:
  %t299 = mul i64 0, 8
  %t300 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t299)
  %t301 = insertvalue { i64, ptr } undef, i64 0, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l168, !tbaa !27
  %t303 = icmp sge i64 0, 0
  br i1 %t303, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb75:
  %t305 = icmp sle i64 0, 2305843009213693951
  br i1 %t305, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb77:
  %t307 = mul i64 0, 4
  %t308 = call ptr @__olang_scope_alloc_zeroed(ptr %s10, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 0, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  %t311 = load ptr, ptr %l154, !tbaa !29
  %t312 = load %"compiler/source:Span", ptr %l155
  %t313 = load %"compiler/source:Span", ptr %l156
  %t314 = load i64, ptr %l157, !tbaa !24
  %t315 = load ptr, ptr %l162, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t319 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s10, ptr %t311, %"compiler/source:Span" %t312, %"compiler/source:Span" %t313, i64 %t314, ptr %t315, { i64, ptr } %t316, { i64, ptr } %t317, { i64, ptr } %t310)
  store ptr %t319, ptr %l172
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb79:
  %t320 = load ptr, ptr %l172, !tbaa !29
  store ptr %t320, ptr %l19, !tbaa !29
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb80:
  %t322 = load ptr, ptr %l175, !tbaa !29
  %t323 = load ptr, ptr %l176, !tbaa !29
  %t324 = load i32, ptr %l178, !tbaa !23
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %t322, ptr %t323, i32 %t324)
  store ptr %t325, ptr %l179
  br label %bb81
bb81:
  %t326 = load ptr, ptr %l4, !tbaa !29
  %t328 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t326)
  store %"compiler/source:Span" %t328, ptr %l181
  br label %bb82
bb82:
  %t329 = load ptr, ptr %l174, !tbaa !29
  %t330 = load ptr, ptr %l179, !tbaa !29
  %t331 = load %"compiler/source:Span", ptr %l181
  %t332 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t329, ptr %t330, %"compiler/source:Span" %t331)
  store ptr %t332, ptr %l182
  br label %bb83
bb83:
  %t333 = load ptr, ptr %l182, !tbaa !29
  store ptr %t333, ptr %l19, !tbaa !29
  br label %bb84
bb84:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/check:Checker", ptr %t335, i32 0, i32 32
  %t339 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t337)
  store i64 %t339, ptr %l186
  br label %bb85
bb85:
  %t340 = load i64, ptr %l186, !tbaa !24
  store i64 %t340, ptr %l20, !tbaa !24
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 32
  %t344 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t343, ptr %t344)
  br label %bb86
bb86:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/check:Checker", ptr %t347, i32 0, i32 32
  store ptr %t349, ptr %l191, !tbaa !29
  %t350 = load ptr, ptr %l19, !tbaa !29
  %t352 = icmp eq ptr %t350, null
  br i1 %t352, label %bb87, label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_b203c9fbf4c249fb_735051f472c86bf)
  unreachable
bb88:
  br label %bb89
bb89:
  %t354 = load ptr, ptr %l19, !tbaa !29
  %t355 = load ptr, ptr %l191, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t355, ptr %t354)
  br label %bb90
bb90:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l195, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t358, ptr %l196
  %t359 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t359, ptr %l197
  %t360 = load i64, ptr %l16, !tbaa !24
  store i64 %t360, ptr %l198, !tbaa !24
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load %"compiler/source:Span", ptr %l1
  %t363 = load ptr, ptr %l6, !tbaa !29
  %t367 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t361, %"compiler/source:Span" %t362, ptr %t363)
  store ptr %t367, ptr %l202
  br label %bb91
bb91:
  %t368 = load ptr, ptr %l202, !tbaa !29
  store ptr %t368, ptr %l203, !tbaa !29
  %t369 = icmp sge i64 0, 0
  br i1 %t369, label %bb92, label %bb93
bb92:
  %t371 = icmp sle i64 0, 1152921504606846975
  br i1 %t371, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb94:
  %t373 = mul i64 0, 8
  %t374 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t373)
  %t375 = insertvalue { i64, ptr } undef, i64 0, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  store { i64, ptr } %t376, ptr %l206, !tbaa !27
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 32
  %t380 = load i64, ptr %l20, !tbaa !24
  %t383 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t379, i64 %t380)
  store { i64, ptr } %t383, ptr %l210
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb96:
  %t384 = icmp sge i64 0, 0
  br i1 %t384, label %bb97, label %bb98
bb97:
  %t386 = icmp sle i64 0, 2305843009213693951
  br i1 %t386, label %bb99, label %bb100
bb98:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb99:
  %t388 = mul i64 0, 4
  %t389 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t388)
  %t390 = insertvalue { i64, ptr } undef, i64 0, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  %t392 = load ptr, ptr %l195, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l196
  %t394 = load %"compiler/source:Span", ptr %l197
  %t395 = load i64, ptr %l198, !tbaa !24
  %t396 = load ptr, ptr %l203, !tbaa !29
  %t397 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t398 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s5, ptr %t392, %"compiler/source:Span" %t393, %"compiler/source:Span" %t394, i64 %t395, ptr %t396, { i64, ptr } %t397, { i64, ptr } %t398, { i64, ptr } %t391)
  store ptr %t400, ptr %l214
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb101:
  call void @__olang_scope_close(ptr %s5)
  %t401 = load ptr, ptr %l214, !tbaa !29
  store ptr %t401, ptr %rv
  br label %ret
bb102:
  store ptr null, ptr %l21, !tbaa !29
  %t402 = load ptr, ptr %l3, !tbaa !29
  %t404 = icmp eq ptr %t402, null
  br i1 %t404, label %bb103, label %bb104
bb103:
  %t406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t406, ptr %l217, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t407, ptr %l218
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t408)
  store i32 %t410, ptr %l220
  br label %bb105
bb104:
  %t411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t411, ptr %l223, !tbaa !29
  %t412 = load ptr, ptr %l3, !tbaa !29
  store ptr %t412, ptr %l224, !tbaa !29
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t413)
  store i32 %t415, ptr %l226
  br label %bb107
bb105:
  %t416 = load ptr, ptr %l217, !tbaa !29
  %t417 = load %"compiler/source:Span", ptr %l218
  %t418 = load i32, ptr %l220, !tbaa !23
  %t419 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t416, %"compiler/source:Span" %t417, i32 %t418, i64 0)
  store ptr %t419, ptr %l221
  br label %bb106
bb106:
  %t420 = load ptr, ptr %l221, !tbaa !29
  store ptr %t420, ptr %l21, !tbaa !29
  br label %bb109
bb107:
  %t422 = load ptr, ptr %l223, !tbaa !29
  %t423 = load ptr, ptr %l224, !tbaa !29
  %t424 = load i32, ptr %l226, !tbaa !23
  %t425 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t422, ptr %t423, i32 %t424)
  store ptr %t425, ptr %l227
  br label %bb108
bb108:
  %t426 = load ptr, ptr %l227, !tbaa !29
  store ptr %t426, ptr %l21, !tbaa !29
  br label %bb109
bb109:
  store ptr null, ptr %l22, !tbaa !29
  %t428 = load ptr, ptr %l4, !tbaa !29
  %t430 = icmp eq ptr %t428, null
  br i1 %t430, label %bb110, label %bb111
bb110:
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l231, !tbaa !29
  %t433 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t433, ptr %l232
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t434)
  store i32 %t436, ptr %l234
  br label %bb112
bb111:
  %t437 = load ptr, ptr %l0, !tbaa !29
  store ptr %t437, ptr %l248, !tbaa !29
  %t438 = load ptr, ptr %l4, !tbaa !29
  store ptr %t438, ptr %l249, !tbaa !29
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t439)
  store i32 %t441, ptr %l251
  br label %bb115
bb112:
  store i32 22, ptr %l235
  %t442 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t442, ptr %l236
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/check:Checker", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = getelementptr %"compiler/generic:Program", ptr %t446, i32 0, i32 2
  %t449 = load i32, ptr %l7, !tbaa !23
  %t450 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t454 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t448, i32 %t449, i64 %t450)
  store i32 %t454, ptr %l242
  br label %bb113
bb113:
  %t455 = load ptr, ptr %l6, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t456
  %t457 = getelementptr { i64, [5 x i64] }, ptr %t456, i32 0, i32 0
  store i64 3, ptr %t457
  %t458 = load %"compiler/source:Span", ptr %l236
  %t459 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t458, 0
  %t460 = load i32, ptr %l242, !tbaa !23
  %t461 = insertvalue { %"compiler/source:Span", i32, ptr } %t459, i32 %t460, 1
  %t463 = insertvalue { %"compiler/source:Span", i32, ptr } %t461, ptr %t455, 2
  %t464 = getelementptr { i64, [5 x i64] }, ptr %t456, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t463, ptr %t464
  %t465 = load { i64, [5 x i64] }, ptr %t456
  %t467 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t465, ptr %t467
  %t468 = load ptr, ptr %l231, !tbaa !29
  %t469 = load %"compiler/source:Span", ptr %l232
  %t470 = load i32, ptr %l234, !tbaa !23
  %t471 = load i32, ptr %l235
  %t473 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t468, %"compiler/source:Span" %t469, i32 %t470, i32 %t471, ptr %t467, ptr null)
  store ptr %t473, ptr %l246
  br label %bb114
bb114:
  %t474 = load ptr, ptr %l246, !tbaa !29
  store ptr %t474, ptr %l22, !tbaa !29
  br label %bb117
bb115:
  %t476 = load ptr, ptr %l248, !tbaa !29
  %t477 = load ptr, ptr %l249, !tbaa !29
  %t478 = load i32, ptr %l251, !tbaa !23
  %t479 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %t476, ptr %t477, i32 %t478)
  store ptr %t479, ptr %l252
  br label %bb116
bb116:
  %t480 = load ptr, ptr %l252, !tbaa !29
  store ptr %t480, ptr %l22, !tbaa !29
  br label %bb117
bb117:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load i32, ptr %l7, !tbaa !23
  %t486 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t482, i32 %t483)
  store i1 %t486, ptr %l256
  br label %bb118
bb118:
  %t487 = load i1, ptr %l256, !tbaa !21
  br i1 %t487, label %bb119, label %bb120
bb119:
  %t488 = load i32, ptr %l7, !tbaa !23
  store i32 %t488, ptr %l257, !tbaa !23
  br label %bb127
bb120:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/check:Checker", ptr %t490, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !29
  %t495 = getelementptr %"compiler/generic:Program", ptr %t493, i32 0, i32 2
  store ptr %t495, ptr %l261, !tbaa !29
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/check:Checker", ptr %t496, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !29
  %t501 = getelementptr %"compiler/generic:Program", ptr %t499, i32 0, i32 2
  %t502 = load i32, ptr %l15, !tbaa !23
  %t505 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t501, i32 %t502)
  store i32 %t505, ptr %l266
  br label %bb121
bb121:
  %t506 = load i32, ptr %l5
  %t508 = trunc i64 1 to i32
  %t509 = icmp eq i32 %t506, %t508
  br i1 %t509, label %bb122, label %bb123
bb122:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load i32, ptr %l15, !tbaa !23
  %t513 = load ptr, ptr %l3, !tbaa !29
  %t514 = load ptr, ptr %l4, !tbaa !29
  %t519 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v1, ptr %v2, ptr %t511, i32 %t512, ptr %t513, ptr %t514)
  store i32 %t519, ptr %l274
  br label %bb124
bb123:
  store i32 0, ptr %l269, !tbaa !23
  br label %bb125
bb124:
  %t520 = load i32, ptr %l274, !tbaa !23
  store i32 %t520, ptr %l269, !tbaa !23
  br label %bb125
bb125:
  %t521 = load ptr, ptr %l261, !tbaa !29
  %t522 = load i32, ptr %l266, !tbaa !23
  %t523 = load i32, ptr %l269, !tbaa !23
  %t524 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t521, i32 %t522, i32 %t523)
  store i32 %t524, ptr %l275
  br label %bb126
bb126:
  %t525 = load i32, ptr %l275, !tbaa !23
  store i32 %t525, ptr %l257, !tbaa !23
  br label %bb127
bb127:
  %t526 = load i32, ptr %l257, !tbaa !23
  %t527 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t527, ptr %l276
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/check:Checker", ptr %t528, i32 0, i32 1
  %t531 = load ptr, ptr %t530, !tbaa !29
  %t533 = getelementptr %"compiler/generic:Program", ptr %t531, i32 0, i32 2
  %t535 = load i64, ptr %l8, !tbaa !24
  %t539 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t533, i32 %t526, i64 %t535)
  store i32 %t539, ptr %l282
  br label %bb128
bb128:
  %t540 = load ptr, ptr %l6, !tbaa !29
  store ptr %t540, ptr %l283, !tbaa !29
  %t541 = load ptr, ptr %l21, !tbaa !29
  %t543 = icmp eq ptr %t541, null
  br i1 %t543, label %bb129, label %bb130
bb129:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb130:
  br label %bb131
bb131:
  %t545 = load ptr, ptr %l21, !tbaa !29
  store ptr %t545, ptr %l286, !tbaa !29
  %t546 = load ptr, ptr %l22, !tbaa !29
  %t548 = icmp eq ptr %t546, null
  br i1 %t548, label %bb132, label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb133:
  br label %bb134
bb134:
  %t550 = load ptr, ptr %l22, !tbaa !29
  %t551 = load i32, ptr %l5
  %t552 = load ptr, ptr %l283, !tbaa !29
  %t553 = load ptr, ptr %l286, !tbaa !29
  %t556 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t552, ptr %t553, ptr %t550, i32 %t551)
  store %"compiler/typed:Slice" %t556, ptr %l291
  br label %bb135
bb135:
  %t557 = load %"compiler/typed:Slice", ptr %l291
  %t558 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Slice" %t557, ptr %t558
  store { i64, [5 x i64] } zeroinitializer, ptr %t559
  %t560 = getelementptr { i64, [5 x i64] }, ptr %t559, i32 0, i32 0
  store i64 10, ptr %t560
  %t561 = load %"compiler/source:Span", ptr %l276
  %t562 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t561, 0
  %t563 = load i32, ptr %l282, !tbaa !23
  %t564 = insertvalue { %"compiler/source:Span", i32, ptr } %t562, i32 %t563, 1
  %t566 = insertvalue { %"compiler/source:Span", i32, ptr } %t564, ptr %t558, 2
  %t567 = getelementptr { i64, [5 x i64] }, ptr %t559, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t566, ptr %t567
  %t568 = load { i64, [5 x i64] }, ptr %t559
  %t570 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t568, ptr %t570
  store ptr %t570, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca i32
  %l68 = alloca ptr
  %l72 = alloca i1
  %l75 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca %"compiler/msgs:Msg"
  %l82 = alloca i64
  %l85 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca %"compiler/msgs:Msg"
  %l90 = alloca i64
  %l92 = alloca ptr
  %l95 = alloca i64
  %l96 = alloca i64
  %l98 = alloca ptr
  %l101 = alloca i64
  %l103 = alloca i64
  %l105 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l114 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l120 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i1
  %l139 = alloca i64
  %l141 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca %"compiler/source:Span"
  %l159 = alloca %"compiler/msgs:Msg"
  %l160 = alloca i64
  %l165 = alloca ptr
  %l168 = alloca i32
  %l171 = alloca ptr
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca %"compiler/source:Span"
  %l176 = alloca i32
  %l179 = alloca ptr
  %l182 = alloca { i64, ptr }
  %l186 = alloca ptr
  %l188 = alloca ptr
  %l189 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i1
  %l200 = alloca ptr
  %l202 = alloca ptr
  %l203 = alloca i1
  %l212 = alloca i1
  %l214 = alloca i1
  %l219 = alloca ptr
  %l221 = alloca ptr
  %l223 = alloca %"compiler/source:Span"
  %l224 = alloca %"compiler/msgs:Msg"
  %l225 = alloca i64
  %l230 = alloca ptr
  %l232 = alloca ptr
  %l233 = alloca ptr
  %l237 = alloca i1
  %l241 = alloca ptr
  %l242 = alloca { i64, ptr }
  %l243 = alloca i64
  %l246 = alloca i64
  %l253 = alloca i1
  %l257 = alloca ptr
  %l259 = alloca %"compiler/source:Span"
  %l260 = alloca ptr
  %l262 = alloca %"compiler/source:Span"
  %l263 = alloca { i64, ptr }
  %l264 = alloca %"compiler/msgs:Msg"
  %l265 = alloca i64
  %l268 = alloca i32
  %l271 = alloca { i64, ptr }
  %l276 = alloca i32
  %l279 = alloca %"std/prelude/text:StringBuilder"
  %l282 = alloca ptr
  %l287 = alloca i32
  %l288 = alloca { i64, ptr }
  %l295 = alloca { i64, ptr }
  %l299 = alloca i64
  %l302 = alloca ptr
  %l305 = alloca { i64, ptr }
  %l310 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l313 = alloca i64
  %l315 = alloca i64
  %l316 = alloca { i64, ptr }
  %l317 = alloca ptr
  %l319 = alloca %"compiler/source:Span"
  %l320 = alloca ptr
  %l321 = alloca { i64, ptr }
  %l323 = alloca %"compiler/source:Span"
  %l324 = alloca i32
  %l326 = alloca %"compiler/source:Span"
  %l328 = alloca %"compiler/source:Span"
  %l329 = alloca { i64, ptr }
  %l330 = alloca { i64, ptr }
  %l331 = alloca ptr
  %l333 = alloca %"compiler/source:Span"
  %l334 = alloca { i64, ptr }
  %l335 = alloca %"compiler/msgs:Msg"
  %l336 = alloca i64
  %l342 = alloca { i64, ptr }
  %l350 = alloca i1
  %l353 = alloca ptr
  %l355 = alloca %"compiler/source:Span"
  %l356 = alloca %"compiler/msgs:Msg"
  %l357 = alloca i64
  %l358 = alloca ptr
  %l364 = alloca i1
  %l366 = alloca ptr
  %l368 = alloca %"compiler/source:Span"
  %l369 = alloca %"compiler/msgs:Msg"
  %l370 = alloca i64
  %l371 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l373 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l379 = alloca i32
  %l381 = alloca i64
  %l383 = alloca i1
  %l385 = alloca ptr
  %l389 = alloca ptr
  %l393 = alloca i32
  %l396 = alloca i1
  %l397 = alloca i1
  %l400 = alloca i1
  %l401 = alloca i1
  %l406 = alloca i1
  %l407 = alloca i1
  %l412 = alloca i32
  %l417 = alloca i32
  %l423 = alloca i32
  %l431 = alloca { i64, ptr }
  %l434 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l437 = alloca i1
  %l442 = alloca i1
  %l453 = alloca { i64, ptr }
  %l464 = alloca i1
  %l466 = alloca ptr
  %l468 = alloca %"compiler/source:Span"
  %l470 = alloca { i64, ptr }
  %l475 = alloca ptr
  %l477 = alloca i32
  %l479 = alloca { i64, ptr }
  %l481 = alloca { i64, ptr }
  %l485 = alloca { i64, ptr }
  %l487 = alloca %"compiler/msgs:Msg"
  %l488 = alloca i64
  %l493 = alloca i1
  %l495 = alloca ptr
  %l497 = alloca %"compiler/source:Span"
  %l499 = alloca { i64, ptr }
  %l500 = alloca i1
  %l501 = alloca ptr
  %l502 = alloca ptr
  %l503 = alloca i32
  %l505 = alloca i64
  %l506 = alloca ptr
  %l507 = alloca %"compiler/typed:TaskClause"
  %l509 = alloca ptr
  %l511 = alloca %"compiler/source:Span"
  %l513 = alloca { i64, ptr }
  %l514 = alloca i1
  %l518 = alloca %"compiler/typed:Clause"
  %l524 = alloca i64
  %l533 = alloca { i64, ptr }
  %l547 = alloca i64
  %l549 = alloca i1
  %l552 = alloca i64
  %l555 = alloca ptr
  %l560 = alloca i32
  %l562 = alloca i64
  %l567 = alloca ptr
  %l569 = alloca %"compiler/source:Span"
  %l570 = alloca %"compiler/msgs:Msg"
  %l571 = alloca i64
  %l577 = alloca i64
  %l579 = alloca i1
  %l584 = alloca i32
  %l589 = alloca ptr
  %l594 = alloca i32
  %l595 = alloca { i64, ptr }
  %l596 = alloca { i64, ptr }
  %l598 = alloca i64
  %l600 = alloca i64
  %l601 = alloca { i64, ptr }
  %l603 = alloca i64
  %l605 = alloca i64
  %l607 = alloca ptr
  %l608 = alloca %"compiler/source:Span"
  %l610 = alloca i64
  %l613 = alloca %"compiler/msgs:Msg"
  %l614 = alloca i64
  %l616 = alloca i64
  %l620 = alloca i64
  %l623 = alloca i64
  %l643 = alloca ptr
  %l646 = alloca i32
  %l649 = alloca ptr
  %l653 = alloca i32
  %l661 = alloca i1
  %l662 = alloca i1
  %l665 = alloca i1
  %l666 = alloca i1
  %l670 = alloca i1
  %l671 = alloca i1
  %l674 = alloca ptr
  %l677 = alloca i32
  %l681 = alloca i32
  %l682 = alloca i1
  %l685 = alloca ptr
  %l688 = alloca i1
  %l693 = alloca i1
  %l694 = alloca i1
  %l698 = alloca i1
  %l700 = alloca i1
  %l703 = alloca ptr
  %l706 = alloca i32
  %l709 = alloca i1
  %l710 = alloca ptr
  %l712 = alloca { i64, ptr }
  %l715 = alloca %"compiler/source:Span"
  %l719 = alloca { i64, ptr }
  %l720 = alloca { i64, ptr }
  %l723 = alloca { i64, ptr }
  %l724 = alloca { i64, ptr }
  %l725 = alloca ptr
  %l728 = alloca %"compiler/source:Span"
  %l729 = alloca { i64, ptr }
  %l732 = alloca { i64, ptr }
  %l734 = alloca %"compiler/msgs:Msg"
  %l735 = alloca i64
  %l736 = alloca ptr
  %l738 = alloca { i64, ptr }
  %l741 = alloca %"compiler/source:Span"
  %l745 = alloca { i64, ptr }
  %l746 = alloca { i64, ptr }
  %l747 = alloca ptr
  %l750 = alloca ptr
  %l754 = alloca i32
  %l755 = alloca { i64, ptr }
  %l757 = alloca %"compiler/msgs:Msg"
  %l758 = alloca i64
  %l761 = alloca ptr
  %l762 = alloca ptr
  %l763 = alloca i1
  %l769 = alloca ptr
  %l771 = alloca ptr
  %l776 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l777 = alloca i1
  %l786 = alloca ptr
  %l787 = alloca %"compiler/source:Span"
  %l789 = alloca { i64, ptr }
  %l790 = alloca ptr
  %l792 = alloca { i64, ptr }
  %l796 = alloca i32
  %l797 = alloca %"compiler/typed:Spawn"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %t235 = alloca { i64, [3 x i64] }, align 8
  %t1608 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l68
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l68, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 29
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 33
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l75
  br label %bb4
bb3:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb5
bb4:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 32
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load i64, ptr %l75, !tbaa !24
  %t23 = icmp sle i64 %t21, %t20
  store i1 %t23, ptr %l72, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l72, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l79, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t27, ptr %l80
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnInDefer(ptr %s1)
  store %"compiler/msgs:Msg" %t28, ptr %l81
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t29 = load ptr, ptr %l79, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l80
  %t31 = load %"compiler/msgs:Msg", ptr %l81
  %t32 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t29, %"compiler/source:Span" %t30, %"compiler/msgs:Msg" %t31)
  store i64 %t32, ptr %l82
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t35 = getelementptr %"compiler/check:frame", ptr %t33, i32 0, i32 33
  %t37 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l85
  br label %bb11
bb11:
  %t38 = load i64, ptr %l85, !tbaa !24
  %t39 = icmp eq i64 %t38, 0
  br i1 %t39, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l87, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t42, ptr %l88
  %t43 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnOutsideJoin(ptr %s2)
  store %"compiler/msgs:Msg" %t43, ptr %l89
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t44 = load ptr, ptr %l87, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l88
  %t46 = load %"compiler/msgs:Msg", ptr %l89
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t44, %"compiler/source:Span" %t45, %"compiler/msgs:Msg" %t46)
  store i64 %t47, ptr %l90
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t48, i32 0, i32 33
  store ptr %t50, ptr %l92, !tbaa !29
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 33
  %t55 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t53)
  store i64 %t55, ptr %l95
  br label %bb17
bb17:
  %t56 = load i64, ptr %l95, !tbaa !24
  %t57 = sub i64 %t56, 1
  store i64 %t57, ptr %l96, !tbaa !24
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/check:frame", ptr %t58, i32 0, i32 33
  store ptr %t60, ptr %l98, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 33
  %t65 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l101
  br label %bb18
bb18:
  %t66 = load i64, ptr %l101, !tbaa !24
  %t67 = sub i64 %t66, 1
  %t68 = load ptr, ptr %l98, !tbaa !29
  %t70 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t67)
  store i64 %t70, ptr %l103
  br label %bb19
bb19:
  %t71 = load i64, ptr %l103, !tbaa !24
  %t72 = add i64 %t71, 1
  %t73 = load ptr, ptr %l92, !tbaa !29
  %t74 = load i64, ptr %l96, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t73, i64 %t74, i64 %t72)
  br label %bb20
bb20:
  %t76 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l105
  br label %bb21
bb21:
  %t77 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l105
  %t78 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %t78
  store ptr %t78, ptr %l5, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t80, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb24:
  br label %bb25
bb25:
  %t94 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t94, ptr %l114, !tbaa !27
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr ptr, ptr %t98, i64 %t95
  %t100 = load ptr, ptr %t99, !tbaa !39
  %t102 = load ptr, ptr %l5, !tbaa !29
  store ptr %t102, ptr %l117, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %t103, ptr %t100)
  store ptr %t107, ptr %l120
  br label %bb26
bb26:
  %t108 = load ptr, ptr %l117, !tbaa !29
  %t109 = load ptr, ptr %l120, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H5eacc50cc32d6e41ff62f01e24d943f2(ptr %v0, ptr %v0, ptr %t108, ptr %t109)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l7, !tbaa !24
  br label %bb22
bb29:
  store i1 false, ptr %l10, !tbaa !21
  %t114 = load ptr, ptr %l3, !tbaa !29
  store ptr %t114, ptr %l11, !tbaa !29
  %t116 = icmp sge i64 0, 0
  br i1 %t116, label %bb30, label %bb31
bb30:
  %t118 = icmp sle i64 0, 1152921504606846975
  br i1 %t118, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_e10ca684bef0956d_f742028d37a3af11)
  unreachable
bb32:
  %t120 = mul i64 0, 8
  %t121 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 0, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l12, !tbaa !27
  %t125 = load ptr, ptr %l3, !tbaa !29
  store ptr %t125, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t126 = load ptr, ptr %l127, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_e10ca684bef0956d_f742028d37a3af11)
  unreachable
bb34:
  %t129 = load ptr, ptr %l127, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 22
  store i1 %t132, ptr %l128, !tbaa !21
  br label %bb35
bb35:
  %t133 = load i1, ptr %l128, !tbaa !21
  br i1 %t133, label %bb36, label %bb37
bb36:
  %t134 = load ptr, ptr %l3, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t136, i32 0, i32 1
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l13, !tbaa !29
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t142 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t142, i32 0, i32 2
  %t144 = load { i64, ptr }, ptr %t143
  store { i64, ptr } %t144, ptr %l14, !tbaa !27
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i1 true, ptr %l10, !tbaa !21
  %t146 = load ptr, ptr %l13, !tbaa !29
  store ptr %t146, ptr %l11, !tbaa !29
  %t148 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t148, ptr %l12, !tbaa !27
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l4, !tbaa !29
  %t152 = getelementptr %"compiler/check:frame", ptr %t150, i32 0, i32 23
  %t154 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t152)
  store i64 %t154, ptr %l139
  br label %bb41
bb41:
  %t155 = load i64, ptr %l139, !tbaa !24
  store i64 %t155, ptr %l15, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 35
  store i32 0, ptr %t158, !tbaa !23
  %t159 = load ptr, ptr %l4, !tbaa !29
  store ptr %t159, ptr %l141, !tbaa !29
  %t160 = load ptr, ptr %l141, !tbaa !29
  %t161 = getelementptr %"compiler/check:frame", ptr %t160, i32 0, i32 15
  %t162 = load i64, ptr %t161, !tbaa !24
  %t164 = add i64 %t162, 1
  %t166 = load ptr, ptr %l141, !tbaa !29
  %t167 = getelementptr %"compiler/check:frame", ptr %t166, i32 0, i32 15
  store i64 %t164, ptr %t167, !tbaa !24
  store ptr null, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t168 = load ptr, ptr %l11, !tbaa !29
  store ptr %t168, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t169 = load ptr, ptr %l144, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb42, label %bb43
bb42:
  %t172 = load ptr, ptr %l144, !tbaa !29
  %t173 = load i64, ptr %t172
  %t175 = icmp eq i64 %t173, 23
  store i1 %t175, ptr %l145, !tbaa !21
  br label %bb43
bb43:
  %t176 = load i1, ptr %l145, !tbaa !21
  br i1 %t176, label %bb44, label %bb45
bb44:
  %t177 = load ptr, ptr %l11, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", ptr }, ptr %t179, i32 0, i32 0
  %t181 = load %"compiler/source:Span", ptr %t180
  store %"compiler/source:Span" %t181, ptr %l18
  %t183 = load ptr, ptr %l11, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", ptr }, ptr %t185, i32 0, i32 1
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l19, !tbaa !29
  br label %bb46
bb45:
  br label %bb67
bb46:
  %t189 = load ptr, ptr %l19, !tbaa !29
  %t191 = getelementptr %"compiler/ast:Func", ptr %t189, i32 0, i32 3
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/ast:Sig", ptr %t192, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t199 = icmp sgt i64 %t197, 0
  br i1 %t199, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s9
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l157, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t202, ptr %l158
  %t203 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnLambdaParams(ptr %s9)
  store %"compiler/msgs:Msg" %t203, ptr %l159
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t204 = load ptr, ptr %l157, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l158
  %t206 = load %"compiler/msgs:Msg", ptr %l159
  %t207 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t204, %"compiler/source:Span" %t205, %"compiler/msgs:Msg" %t206)
  store i64 %t207, ptr %l160
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb51:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l18
  %t210 = load ptr, ptr %l19, !tbaa !29
  %t211 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v2, ptr %t208, %"compiler/source:Span" %t209, ptr %t210, i32 %t211)
  store ptr %t216, ptr %l165
  br label %bb52
bb52:
  %t217 = load ptr, ptr %l165, !tbaa !29
  store ptr %t217, ptr %l20, !tbaa !29
  %t218 = load ptr, ptr %l20, !tbaa !29
  %t221 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t218)
  store i32 %t221, ptr %l168
  br label %bb53
bb53:
  %t222 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t223 = load i32, ptr %l168, !tbaa !23
  %t225 = icmp ne i32 %t223, %t222
  br i1 %t225, label %bb54, label %bb55
bb54:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l171, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t228, ptr %l172
  %t229 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t229, ptr %l173
  %t230 = load ptr, ptr %l20, !tbaa !29
  %t233 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t230)
  store i32 %t233, ptr %l176
  br label %bb56
bb55:
  br label %bb66
bb56:
  %t234 = load ptr, ptr %l20, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 0
  store i64 2, ptr %t236
  %t238 = insertvalue { ptr } undef, ptr %t234, 0
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 1
  store { ptr } %t238, ptr %t239
  %t240 = load { i64, [3 x i64] }, ptr %t235
  %t242 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t240, ptr %t242
  store ptr %t242, ptr %l179, !tbaa !29
  %t243 = icmp sge i64 0, 0
  br i1 %t243, label %bb57, label %bb58
bb57:
  %t245 = icmp sle i64 0, 1152921504606846975
  br i1 %t245, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_31ec5049601f3040_e4a7c8cc80642e04)
  unreachable
bb59:
  %t247 = mul i64 0, 8
  %t248 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t247)
  %t249 = insertvalue { i64, ptr } undef, i64 0, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  store { i64, ptr } %t250, ptr %l182, !tbaa !27
  %t251 = icmp sge i64 0, 0
  br i1 %t251, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_31ec5049601f3040_e4a7c8cc80642e04)
  unreachable
bb61:
  %t253 = icmp sle i64 0, 1152921504606846975
  br i1 %t253, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_31ec5049601f3040_e4a7c8cc80642e04)
  unreachable
bb63:
  %t255 = mul i64 0, 8
  %t256 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t255)
  %t257 = insertvalue { i64, ptr } undef, i64 0, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t259 = load ptr, ptr %l171, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l172
  %t261 = load %"compiler/source:Span", ptr %l173
  %t262 = load i32, ptr %l176, !tbaa !23
  %t263 = load ptr, ptr %l179, !tbaa !29
  %t264 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t266 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v0, ptr %t259, %"compiler/source:Span" %t260, %"compiler/source:Span" %t261, i32 %t262, ptr %t263, i64 -1, ptr null, { i64, ptr } %t264, { i64, ptr } %t258)
  store ptr %t266, ptr %l186
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_31ec5049601f3040_e4a7c8cc80642e04)
  unreachable
bb65:
  %t267 = load ptr, ptr %l186, !tbaa !29
  store ptr %t267, ptr %l16, !tbaa !29
  br label %bb66
bb66:
  br label %bb96
bb67:
  %t269 = load ptr, ptr %l11, !tbaa !29
  store ptr %t269, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t270 = load ptr, ptr %l188, !tbaa !29
  %t271 = icmp ne ptr %t270, null
  br i1 %t271, label %bb68, label %bb69
bb68:
  %t273 = load ptr, ptr %l188, !tbaa !29
  %t274 = load i64, ptr %t273
  %t276 = icmp eq i64 %t274, 12
  store i1 %t276, ptr %l189, !tbaa !21
  br label %bb69
bb69:
  %t277 = load i1, ptr %l189, !tbaa !21
  br i1 %t277, label %bb70, label %bb71
bb70:
  br label %bb76
bb71:
  %t278 = load ptr, ptr %l11, !tbaa !29
  store ptr %t278, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t279 = load ptr, ptr %l192, !tbaa !29
  %t280 = icmp ne ptr %t279, null
  br i1 %t280, label %bb72, label %bb73
bb72:
  %t282 = load ptr, ptr %l192, !tbaa !29
  %t283 = load i64, ptr %t282
  %t285 = icmp eq i64 %t283, 13
  store i1 %t285, ptr %l193, !tbaa !21
  br label %bb73
bb73:
  %t286 = load i1, ptr %l193, !tbaa !21
  br i1 %t286, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load ptr, ptr %l11, !tbaa !29
  %t290 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t294 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t287, ptr %t288, i32 %t290)
  store ptr %t294, ptr %l200
  br label %bb77
bb77:
  %t295 = load ptr, ptr %l200, !tbaa !29
  store ptr %t295, ptr %l16, !tbaa !29
  br label %bb96
bb78:
  %t297 = load ptr, ptr %l11, !tbaa !29
  store ptr %t297, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t298 = load ptr, ptr %l202, !tbaa !29
  %t299 = icmp ne ptr %t298, null
  br i1 %t299, label %bb79, label %bb80
bb79:
  %t301 = load ptr, ptr %l202, !tbaa !29
  %t302 = load i64, ptr %t301
  %t304 = icmp eq i64 %t302, 4
  store i1 %t304, ptr %l203, !tbaa !21
  br label %bb80
bb80:
  %t305 = load i1, ptr %l203, !tbaa !21
  br i1 %t305, label %bb81, label %bb82
bb81:
  %t306 = load ptr, ptr %l11, !tbaa !29
  %t308 = getelementptr { i64, [5 x i64] }, ptr %t306, i32 0, i32 1
  %t309 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t308, i32 0, i32 1
  %t310 = load i32, ptr %t309
  store i32 %t310, ptr %l21
  %t312 = load ptr, ptr %l11, !tbaa !29
  %t314 = getelementptr { i64, [5 x i64] }, ptr %t312, i32 0, i32 1
  %t315 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t314, i32 0, i32 2
  %t316 = load ptr, ptr %t315
  store ptr %t316, ptr %l22, !tbaa !29
  br label %bb83
bb82:
  br label %bb91
bb83:
  %t318 = load i32, ptr %l21
  %t320 = trunc i64 75 to i32
  %t321 = icmp eq i32 %t318, %t320
  br i1 %t321, label %bb84, label %bb85
bb84:
  %t323 = load ptr, ptr %l22, !tbaa !29
  %t325 = call i1 @compiler_2fcheck_2ecallLike(ptr %v2, ptr %t323)
  store i1 %t325, ptr %l214
  br label %bb86
bb85:
  store i1 false, ptr %l212, !tbaa !21
  br label %bb87
bb86:
  %t326 = load i1, ptr %l214, !tbaa !21
  store i1 %t326, ptr %l212, !tbaa !21
  br label %bb87
bb87:
  %t327 = load i1, ptr %l212, !tbaa !21
  br i1 %t327, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l17, !tbaa !21
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load ptr, ptr %l11, !tbaa !29
  %t331 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t335 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t328, ptr %t329, i32 %t331)
  store ptr %t335, ptr %l219
  br label %bb90
bb89:
  br label %bb91
bb90:
  %t336 = load ptr, ptr %l219, !tbaa !29
  store ptr %t336, ptr %l16, !tbaa !29
  br label %bb96
bb91:
  store %olang.scope zeroinitializer, ptr %s13
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l221, !tbaa !29
  %t339 = load ptr, ptr %l11, !tbaa !29
  %t341 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t339)
  store %"compiler/source:Span" %t341, ptr %l223
  br label %bb92
bb92:
  %t342 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnNotCall(ptr %s13)
  store %"compiler/msgs:Msg" %t342, ptr %l224
  br label %bb93
bb93:
  %t343 = load ptr, ptr %l221, !tbaa !29
  %t344 = load %"compiler/source:Span", ptr %l223
  %t345 = load %"compiler/msgs:Msg", ptr %l224
  %t346 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t343, %"compiler/source:Span" %t344, %"compiler/msgs:Msg" %t345)
  store i64 %t346, ptr %l225
  br label %bb94
bb94:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load ptr, ptr %l11, !tbaa !29
  %t350 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t354 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t347, ptr %t348, i32 %t350)
  store ptr %t354, ptr %l230
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s13)
  br label %bb96
bb96:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t355)
  store ptr %t357, ptr %l232
  br label %bb97
bb97:
  %t358 = load ptr, ptr %l232, !tbaa !29
  store ptr %t358, ptr %l4, !tbaa !29
  %t359 = load ptr, ptr %l4, !tbaa !29
  store ptr %t359, ptr %l233, !tbaa !29
  %t360 = load ptr, ptr %l233, !tbaa !29
  %t361 = getelementptr %"compiler/check:frame", ptr %t360, i32 0, i32 15
  %t362 = load i64, ptr %t361, !tbaa !24
  %t364 = sub i64 %t362, 1
  %t366 = load ptr, ptr %l233, !tbaa !29
  %t367 = getelementptr %"compiler/check:frame", ptr %t366, i32 0, i32 15
  store i64 %t364, ptr %t367, !tbaa !24
  %t368 = load i1, ptr %l10, !tbaa !21
  br i1 %t368, label %bb98, label %bb99
bb98:
  %t370 = load ptr, ptr %l16, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  %t374 = xor i1 %t372, true
  store i1 %t374, ptr %l237, !tbaa !21
  br label %bb100
bb99:
  store i1 false, ptr %l237, !tbaa !21
  br label %bb100
bb100:
  %t376 = load i1, ptr %l237, !tbaa !21
  br i1 %t376, label %bb101, label %bb102
bb101:
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l241, !tbaa !29
  %t378 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t378, ptr %l242, !tbaa !27
  %t379 = load i64, ptr %l15, !tbaa !24
  store i64 %t379, ptr %l243, !tbaa !24
  %t380 = load ptr, ptr %l4, !tbaa !29
  %t382 = getelementptr %"compiler/check:frame", ptr %t380, i32 0, i32 23
  %t384 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t382)
  store i64 %t384, ptr %l246
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t385 = load ptr, ptr %l241, !tbaa !29
  %t386 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t387 = load i64, ptr %l243, !tbaa !24
  %t388 = load i64, ptr %l246, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v2, ptr %t385, { i64, ptr } %t386, i64 %t387, i64 %t388)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t389 = load ptr, ptr %l4, !tbaa !29
  %t391 = getelementptr %"compiler/check:frame", ptr %t389, i32 0, i32 23
  %t392 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %t391, i64 %t392)
  br label %bb106
bb106:
  %t395 = load ptr, ptr %l16, !tbaa !29
  %t397 = icmp eq ptr %t395, null
  br i1 %t397, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb108:
  br label %bb109
bb109:
  %t399 = load ptr, ptr %l16, !tbaa !29
  %t401 = call i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %t399)
  store i1 %t401, ptr %l253
  br label %bb110
bb110:
  %t402 = load i1, ptr %l253, !tbaa !21
  br i1 %t402, label %bb111, label %bb112
bb111:
  %t403 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t403, 0
  %t407 = icmp eq i64 %t405, 0
  br i1 %t407, label %bb113, label %bb114
bb112:
  br label %bb156
bb113:
  store %olang.scope zeroinitializer, ptr %s17
  %t409 = load ptr, ptr %l0, !tbaa !29
  store ptr %t409, ptr %l257, !tbaa !29
  %t410 = load ptr, ptr %l11, !tbaa !29
  %t412 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t410)
  store %"compiler/source:Span" %t412, ptr %l259
  br label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s18
  %t413 = load ptr, ptr %l16, !tbaa !29
  %t416 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t413)
  store i32 %t416, ptr %l268
  br label %bb120
bb115:
  %t417 = load ptr, ptr %l0, !tbaa !29
  store ptr %t417, ptr %l260, !tbaa !29
  %t418 = load ptr, ptr %l11, !tbaa !29
  %t420 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t418)
  store %"compiler/source:Span" %t420, ptr %l262
  br label %bb116
bb116:
  %t421 = load ptr, ptr %l260, !tbaa !29
  %t422 = load %"compiler/source:Span", ptr %l262
  %t423 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t421, %"compiler/source:Span" %t422)
  store { i64, ptr } %t423, ptr %l263
  br label %bb117
bb117:
  %t424 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t425 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnySpawned(ptr %v0, ptr %s17, { i64, ptr } %t424)
  store %"compiler/msgs:Msg" %t425, ptr %l264
  br label %bb118
bb118:
  %t426 = load ptr, ptr %l257, !tbaa !29
  %t427 = load %"compiler/source:Span", ptr %l259
  %t428 = load %"compiler/msgs:Msg", ptr %l264
  %t429 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t426, %"compiler/source:Span" %t427, %"compiler/msgs:Msg" %t428)
  store i64 %t429, ptr %l265
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s17)
  br label %bb155
bb120:
  %t430 = load i32, ptr %l268, !tbaa !23
  store i32 %t430, ptr %l23, !tbaa !23
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load i32, ptr %l23, !tbaa !23
  %t435 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s18, ptr %t431, i32 %t432)
  store { i64, ptr } %t435, ptr %l271
  br label %bb121
bb121:
  %t436 = load { i64, ptr }, ptr %l271, !tbaa !27
  store { i64, ptr } %t436, ptr %l24, !tbaa !27
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/check:Checker", ptr %t437, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !29
  %t442 = getelementptr %"compiler/generic:Program", ptr %t440, i32 0, i32 2
  %t443 = load i32, ptr %l23, !tbaa !23
  %t446 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t442, i32 %t443)
  store i32 %t446, ptr %l276
  br label %bb122
bb122:
  %t447 = load i32, ptr %l276
  %t449 = trunc i64 22 to i32
  %t450 = icmp eq i32 %t447, %t449
  br i1 %t450, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s19
  %t452 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s19)
  store %"std/prelude/text:StringBuilder" %t452, ptr %l279
  br label %bb125
bb124:
  br label %bb145
bb125:
  %t453 = load %"std/prelude/text:StringBuilder", ptr %l279
  store %"std/prelude/text:StringBuilder" %t453, ptr %l25
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/check:Checker", ptr %t454, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !29
  %t459 = getelementptr %"compiler/generic:Program", ptr %t457, i32 0, i32 2
  store ptr %t459, ptr %l282, !tbaa !29
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/check:Checker", ptr %t460, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !29
  %t465 = getelementptr %"compiler/generic:Program", ptr %t463, i32 0, i32 2
  %t466 = load i32, ptr %l23, !tbaa !23
  %t469 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t465, i32 %t466)
  store i32 %t469, ptr %l287
  br label %bb126
bb126:
  %t470 = load ptr, ptr %l282, !tbaa !29
  %t471 = load i32, ptr %l287, !tbaa !23
  %t472 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t470, i32 %t471)
  store { i64, ptr } %t472, ptr %l288
  br label %bb127
bb127:
  %t473 = load { i64, ptr }, ptr %l288, !tbaa !27
  store { i64, ptr } %t473, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t474 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t476 = extractvalue { i64, ptr } %t474, 0
  store i64 %t476, ptr %l28, !tbaa !24
  br label %bb128
bb128:
  store %olang.scope zeroinitializer, ptr %s21
  %t478 = load i64, ptr %l27, !tbaa !24
  %t479 = load i64, ptr %l28, !tbaa !24
  %t482 = icmp slt i64 %t478, %t479
  %t484 = xor i1 %t482, true
  br i1 %t484, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s21)
  br label %bb140
bb130:
  br label %bb131
bb131:
  %t486 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t486, ptr %l295, !tbaa !27
  %t487 = load i64, ptr %l27, !tbaa !24
  %t489 = getelementptr { i64, ptr }, ptr %l295, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = getelementptr i32, ptr %t490, i64 %t487
  %t492 = load i32, ptr %t491, !tbaa !33
  store i32 %t492, ptr %l29, !tbaa !23
  %t495 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s19, ptr %l25)
  store i64 %t495, ptr %l299
  br label %bb132
bb132:
  %t496 = load i64, ptr %l299, !tbaa !24
  %t497 = icmp sgt i64 %t496, 0
  br i1 %t497, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s22, ptr %l25, { i64, ptr } { i64 2, ptr @.d42 })
  br label %bb135
bb134:
  br label %bb136
bb135:
  call void @__olang_scope_close(ptr %s22)
  br label %bb136
bb136:
  store ptr %l25, ptr %l302, !tbaa !29
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load i32, ptr %l29, !tbaa !23
  %t504 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s21, ptr %t500, i32 %t501)
  store { i64, ptr } %t504, ptr %l305
  br label %bb137
bb137:
  %t505 = load { i64, ptr }, ptr %l305, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t505, 0
  %t507 = extractvalue { i64, ptr } %t505, 1
  %t508 = mul i64 %t506, 1
  %t509 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t508)
  call void @llvm.memcpy.p0.p0.i64(ptr %t509, ptr %t507, i64 %t508, i1 false)
  %t510 = insertvalue { i64, ptr } undef, i64 %t506, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t509, 1
  %t512 = load ptr, ptr %l302, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s21, ptr %t512, { i64, ptr } %t511)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s21)
  br label %bb139
bb139:
  %t514 = load i64, ptr %l27, !tbaa !24
  %t516 = add i64 %t514, 1
  store i64 %t516, ptr %l27, !tbaa !24
  br label %bb128
bb140:
  %t519 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s19, ptr %s18, ptr %l25)
  store { i64, ptr } %t519, ptr %l310
  br label %bb141
bb141:
  %t520 = load { i64, ptr }, ptr %l310, !tbaa !27
  store { i64, ptr } %t520, ptr %l311, !tbaa !27
  %t521 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t522 = extractvalue { i64, ptr } %t521, 0
  %t523 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t524 = extractvalue { i64, ptr } %t523, 0
  store i64 %t524, ptr %l313, !tbaa !24
  %t526 = load i64, ptr %l313, !tbaa !24
  %t527 = icmp eq i64 %t522, %t526
  br i1 %t527, label %bb142, label %bb143
bb142:
  %t529 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !27
  %t531 = getelementptr { i64, ptr }, ptr %l311, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = load i64, ptr %l313, !tbaa !24
  %t534 = mul i64 %t533, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t530, ptr %t532, i64 %t534, i1 false)
  br label %bb144
bb143:
  %t535 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t536 = extractvalue { i64, ptr } %t535, 0
  store i64 %t536, ptr %l315, !tbaa !24
  %t537 = load i64, ptr %l315, !tbaa !24
  %t538 = mul i64 %t537, 1
  %t539 = call ptr @__olang_scope_alloc_zeroed(ptr %s18, i64 %t538)
  %t540 = insertvalue { i64, ptr } undef, i64 %t537, 0
  %t541 = insertvalue { i64, ptr } %t540, ptr %t539, 1
  store { i64, ptr } %t541, ptr %l316, !tbaa !27
  %t542 = getelementptr { i64, ptr }, ptr %l316, i32 0, i32 1
  %t543 = load ptr, ptr %t542, !tbaa !27
  %t544 = getelementptr { i64, ptr }, ptr %l311, i32 0, i32 1
  %t545 = load ptr, ptr %t544, !tbaa !27
  %t546 = load i64, ptr %l315, !tbaa !24
  %t547 = mul i64 %t546, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t543, ptr %t545, i64 %t547, i1 false)
  %t548 = load { i64, ptr }, ptr %l316, !tbaa !27
  store { i64, ptr } %t548, ptr %l24, !tbaa !27
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s19)
  br label %bb145
bb145:
  %t549 = load ptr, ptr %l0, !tbaa !29
  store ptr %t549, ptr %l317, !tbaa !29
  %t550 = load ptr, ptr %l11, !tbaa !29
  %t552 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t550)
  store %"compiler/source:Span" %t552, ptr %l319
  br label %bb146
bb146:
  %t553 = load ptr, ptr %l0, !tbaa !29
  store ptr %t553, ptr %l320, !tbaa !29
  %t554 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t554, ptr %l321, !tbaa !27
  %t555 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr ptr, ptr %t556, i64 0
  %t558 = load ptr, ptr %t557, !tbaa !39
  %t560 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t558)
  store %"compiler/source:Span" %t560, ptr %l323
  br label %bb147
bb147:
  %t561 = getelementptr %"compiler/source:Span", ptr %l323, i32 0, i32 0
  %t562 = load i32, ptr %t561, !tbaa !23
  store i32 %t562, ptr %l324, !tbaa !23
  %t563 = load ptr, ptr %l3, !tbaa !29
  %t565 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t563)
  store %"compiler/source:Span" %t565, ptr %l326
  br label %bb148
bb148:
  %t566 = getelementptr %"compiler/source:Span", ptr %l326, i32 0, i32 0
  %t567 = load i32, ptr %t566, !tbaa !23
  %t568 = load i32, ptr %l324, !tbaa !23
  %t570 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s18, i32 %t568, i32 %t567)
  store %"compiler/source:Span" %t570, ptr %l328
  br label %bb149
bb149:
  %t571 = load ptr, ptr %l320, !tbaa !29
  %t572 = load %"compiler/source:Span", ptr %l328
  %t573 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t571, %"compiler/source:Span" %t572)
  store { i64, ptr } %t573, ptr %l329
  br label %bb150
bb150:
  %t574 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t574, ptr %l330, !tbaa !27
  %t575 = load ptr, ptr %l0, !tbaa !29
  store ptr %t575, ptr %l331, !tbaa !29
  %t576 = load ptr, ptr %l11, !tbaa !29
  %t578 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t576)
  store %"compiler/source:Span" %t578, ptr %l333
  br label %bb151
bb151:
  %t579 = load ptr, ptr %l331, !tbaa !29
  %t580 = load %"compiler/source:Span", ptr %l333
  %t581 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t579, %"compiler/source:Span" %t580)
  store { i64, ptr } %t581, ptr %l334
  br label %bb152
bb152:
  %t582 = load { i64, ptr }, ptr %l329, !tbaa !27
  %t583 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t584 = load { i64, ptr }, ptr %l334, !tbaa !27
  %t585 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnySpawnedResult(ptr %v0, ptr %s18, ptr %v0, ptr %s18, { i64, ptr } %t582, { i64, ptr } %t583, { i64, ptr } %t584)
  store %"compiler/msgs:Msg" %t585, ptr %l335
  br label %bb153
bb153:
  %t586 = load ptr, ptr %l317, !tbaa !29
  %t587 = load %"compiler/source:Span", ptr %l319
  %t588 = load %"compiler/msgs:Msg", ptr %l335
  %t589 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t586, %"compiler/source:Span" %t587, %"compiler/msgs:Msg" %t588)
  store i64 %t589, ptr %l336
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s18)
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb156:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t592 = getelementptr %"compiler/check:Checker", ptr %t590, i32 0, i32 1
  %t593 = load ptr, ptr %t592, !tbaa !29
  %t595 = getelementptr %"compiler/generic:Program", ptr %t593, i32 0, i32 2
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = getelementptr %"compiler/check:Checker", ptr %t596, i32 0, i32 35
  %t599 = load i32, ptr %t598, !tbaa !23
  %t602 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t595, i32 %t599)
  store { i64, ptr } %t602, ptr %l342
  br label %bb157
bb157:
  %t603 = load { i64, ptr }, ptr %l342, !tbaa !27
  store { i64, ptr } %t603, ptr %l30, !tbaa !27
  %t604 = load i1, ptr %l17, !tbaa !21
  br i1 %t604, label %bb158, label %bb159
bb158:
  %t606 = icmp sge i64 0, 0
  br i1 %t606, label %bb160, label %bb161
bb159:
  br label %bb164
bb160:
  %t608 = icmp sle i64 0, 2305843009213693951
  br i1 %t608, label %bb162, label %bb163
bb161:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb162:
  %t610 = mul i64 0, 4
  %t611 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t610)
  %t612 = insertvalue { i64, ptr } undef, i64 0, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t611, 1
  store { i64, ptr } %t613, ptr %l30, !tbaa !27
  br label %bb164
bb163:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb164:
  %t615 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t617 = extractvalue { i64, ptr } %t615, 0
  %t619 = icmp sgt i64 %t617, 0
  br i1 %t619, label %bb165, label %bb166
bb165:
  %t621 = load i1, ptr %l10, !tbaa !21
  %t623 = xor i1 %t621, true
  store i1 %t623, ptr %l350, !tbaa !21
  br label %bb167
bb166:
  store i1 false, ptr %l350, !tbaa !21
  br label %bb167
bb167:
  %t625 = load i1, ptr %l350, !tbaa !21
  br i1 %t625, label %bb168, label %bb169
bb168:
  store %olang.scope zeroinitializer, ptr %s25
  %t626 = load ptr, ptr %l0, !tbaa !29
  store ptr %t626, ptr %l353, !tbaa !29
  %t627 = load ptr, ptr %l11, !tbaa !29
  %t629 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t627)
  store %"compiler/source:Span" %t629, ptr %l355
  br label %bb170
bb169:
  br label %bb173
bb170:
  %t630 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFallible(ptr %s25)
  store %"compiler/msgs:Msg" %t630, ptr %l356
  br label %bb171
bb171:
  %t631 = load ptr, ptr %l353, !tbaa !29
  %t632 = load %"compiler/source:Span", ptr %l355
  %t633 = load %"compiler/msgs:Msg", ptr %l356
  %t634 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s25, ptr %t631, %"compiler/source:Span" %t632, %"compiler/msgs:Msg" %t633)
  store i64 %t634, ptr %l357
  br label %bb172
bb172:
  %t635 = load ptr, ptr %l4, !tbaa !29
  store ptr %t635, ptr %l358, !tbaa !29
  %t636 = load ptr, ptr %l358, !tbaa !29
  %t637 = getelementptr %"compiler/check:frame", ptr %t636, i32 0, i32 36
  %t638 = load i64, ptr %t637, !tbaa !24
  %t640 = add i64 %t638, 1
  %t642 = load ptr, ptr %l358, !tbaa !29
  %t643 = getelementptr %"compiler/check:frame", ptr %t642, i32 0, i32 36
  store i64 %t640, ptr %t643, !tbaa !24
  call void @__olang_scope_close(ptr %s25)
  br label %bb173
bb173:
  %t644 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t646 = extractvalue { i64, ptr } %t644, 0
  %t648 = icmp eq i64 %t646, 0
  br i1 %t648, label %bb174, label %bb175
bb174:
  %t650 = load i1, ptr %l10, !tbaa !21
  store i1 %t650, ptr %l364, !tbaa !21
  br label %bb176
bb175:
  store i1 false, ptr %l364, !tbaa !21
  br label %bb176
bb176:
  %t652 = load i1, ptr %l364, !tbaa !21
  br i1 %t652, label %bb177, label %bb178
bb177:
  store %olang.scope zeroinitializer, ptr %s26
  %t653 = load ptr, ptr %l0, !tbaa !29
  store ptr %t653, ptr %l366, !tbaa !29
  %t654 = load ptr, ptr %l3, !tbaa !29
  %t656 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t654)
  store %"compiler/source:Span" %t656, ptr %l368
  br label %bb179
bb178:
  br label %bb182
bb179:
  %t657 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnTryInfallible(ptr %s26)
  store %"compiler/msgs:Msg" %t657, ptr %l369
  br label %bb180
bb180:
  %t658 = load ptr, ptr %l366, !tbaa !29
  %t659 = load %"compiler/source:Span", ptr %l368
  %t660 = load %"compiler/msgs:Msg", ptr %l369
  %t661 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s26, ptr %t658, %"compiler/source:Span" %t659, %"compiler/msgs:Msg" %t660)
  store i64 %t661, ptr %l370
  br label %bb181
bb181:
  call void @__olang_scope_close(ptr %s26)
  br label %bb182
bb182:
  %t662 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aTaskClause_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t662, ptr %l371
  br label %bb183
bb183:
  %t663 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l371
  %t664 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t663, ptr %t664
  store ptr %t664, ptr %l31, !tbaa !29
  %t666 = load ptr, ptr @__olang_prog_scope
  %t667 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e(ptr %t666)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t667, ptr %l373
  br label %bb184
bb184:
  %t668 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l373
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t668, ptr %l32
  %t669 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t671 = extractvalue { i64, ptr } %t669, 0
  %t673 = icmp sgt i64 %t671, 0
  br i1 %t673, label %bb185, label %bb186
bb185:
  store %olang.scope zeroinitializer, ptr %s27
  %t675 = load ptr, ptr %l16, !tbaa !29
  %t678 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t675)
  store i32 %t678, ptr %l379
  br label %bb187
bb186:
  br label %bb270
bb187:
  %t679 = load i32, ptr %l379, !tbaa !23
  store i32 %t679, ptr %l33, !tbaa !23
  %t680 = load ptr, ptr %l5, !tbaa !29
  %t682 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H4d447d5f762c25bc2b844b5f209f491d(ptr %v0, ptr %t680)
  store i64 %t682, ptr %l381
  br label %bb188
bb188:
  %t683 = load i64, ptr %l381, !tbaa !24
  %t684 = icmp eq i64 %t683, 1
  br i1 %t684, label %bb189, label %bb190
bb189:
  %t686 = load ptr, ptr %l5, !tbaa !29
  %t688 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %s27, ptr %t686, i64 0)
  store ptr %t688, ptr %l385
  br label %bb191
bb190:
  store i1 false, ptr %l383, !tbaa !21
  br label %bb192
bb191:
  %t689 = load ptr, ptr %l385, !tbaa !29
  %t690 = icmp eq ptr %t689, null
  %t692 = xor i1 %t690, true
  store i1 %t692, ptr %l383, !tbaa !21
  br label %bb192
bb192:
  %t694 = load i1, ptr %l383, !tbaa !21
  br i1 %t694, label %bb193, label %bb194
bb193:
  %t695 = load ptr, ptr %l5, !tbaa !29
  %t697 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %v0, ptr %t695, i64 0)
  store ptr %t697, ptr %l389
  br label %bb195
bb194:
  br label %bb218
bb195:
  %t698 = load ptr, ptr %l389, !tbaa !29
  store ptr %t698, ptr %l34, !tbaa !29
  %t699 = load ptr, ptr %l34, !tbaa !29
  %t701 = icmp eq ptr %t699, null
  br i1 %t701, label %bb196, label %bb197
bb196:
  call void @__olang_check_failed(ptr @olang_loc_ee8620bb7b7c2476_e7a9796d2a7d03d2)
  unreachable
bb197:
  br label %bb198
bb198:
  %t703 = load ptr, ptr %l34, !tbaa !29
  %t705 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t703)
  store i32 %t705, ptr %l393
  br label %bb199
bb199:
  %t706 = load i32, ptr %l393, !tbaa !23
  store i32 %t706, ptr %l35, !tbaa !23
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t708 = load i32, ptr %l33, !tbaa !23
  %t711 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t707, i32 %t708)
  store i1 %t711, ptr %l396
  br label %bb200
bb200:
  %t712 = load i1, ptr %l396, !tbaa !21
  br i1 %t712, label %bb201, label %bb202
bb201:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load i32, ptr %l35, !tbaa !23
  %t717 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t713, i32 %t714)
  store i1 %t717, ptr %l400
  br label %bb203
bb202:
  store i1 false, ptr %l397, !tbaa !21
  br label %bb204
bb203:
  %t718 = load i1, ptr %l400, !tbaa !21
  store i1 %t718, ptr %l397, !tbaa !21
  br label %bb204
bb204:
  %t719 = load i1, ptr %l397, !tbaa !21
  br i1 %t719, label %bb205, label %bb206
bb205:
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t722 = getelementptr %"compiler/check:Checker", ptr %t720, i32 0, i32 1
  %t723 = load ptr, ptr %t722, !tbaa !29
  %t725 = getelementptr %"compiler/generic:Program", ptr %t723, i32 0, i32 2
  %t726 = load i32, ptr %l35, !tbaa !23
  %t729 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t725, i32 %t726)
  store i1 %t729, ptr %l406
  br label %bb207
bb206:
  store i1 false, ptr %l401, !tbaa !21
  br label %bb208
bb207:
  %t730 = load i1, ptr %l406, !tbaa !21
  store i1 %t730, ptr %l401, !tbaa !21
  br label %bb208
bb208:
  %t731 = load i1, ptr %l401, !tbaa !21
  br i1 %t731, label %bb209, label %bb210
bb209:
  %t732 = load ptr, ptr %l0, !tbaa !29
  %t734 = getelementptr %"compiler/check:Checker", ptr %t732, i32 0, i32 1
  %t735 = load ptr, ptr %t734, !tbaa !29
  %t737 = getelementptr %"compiler/generic:Program", ptr %t735, i32 0, i32 2
  %t738 = load i32, ptr %l35, !tbaa !23
  %t741 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t737, i32 %t738)
  store i32 %t741, ptr %l412
  br label %bb211
bb210:
  store i1 false, ptr %l407, !tbaa !21
  br label %bb213
bb211:
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t744 = getelementptr %"compiler/check:Checker", ptr %t742, i32 0, i32 1
  %t745 = load ptr, ptr %t744, !tbaa !29
  %t747 = getelementptr %"compiler/generic:Program", ptr %t745, i32 0, i32 2
  %t748 = load i32, ptr %l33, !tbaa !23
  %t751 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t747, i32 %t748)
  store i32 %t751, ptr %l417
  br label %bb212
bb212:
  %t752 = load i32, ptr %l412, !tbaa !23
  %t753 = load i32, ptr %l417, !tbaa !23
  %t754 = icmp eq i32 %t752, %t753
  store i1 %t754, ptr %l407, !tbaa !21
  br label %bb213
bb213:
  %t756 = load i1, ptr %l407, !tbaa !21
  br i1 %t756, label %bb214, label %bb215
bb214:
  %t757 = load ptr, ptr %l0, !tbaa !29
  %t759 = getelementptr %"compiler/check:Checker", ptr %t757, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !29
  %t762 = getelementptr %"compiler/generic:Program", ptr %t760, i32 0, i32 2
  %t763 = load i32, ptr %l33, !tbaa !23
  %t766 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t762, i32 %t763)
  store i32 %t766, ptr %l423
  br label %bb216
bb215:
  br label %bb217
bb216:
  %t767 = load i32, ptr %l423, !tbaa !23
  store i32 %t767, ptr %l33, !tbaa !23
  br label %bb217
bb217:
  br label %bb218
bb218:
  %t768 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t768, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t770 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t772 = extractvalue { i64, ptr } %t770, 0
  store i64 %t772, ptr %l38, !tbaa !24
  br label %bb219
bb219:
  store %olang.scope zeroinitializer, ptr %s31
  %t774 = load i64, ptr %l37, !tbaa !24
  %t775 = load i64, ptr %l38, !tbaa !24
  %t778 = icmp slt i64 %t774, %t775
  %t780 = xor i1 %t778, true
  br i1 %t780, label %bb220, label %bb221
bb220:
  call void @__olang_scope_close(ptr %s31)
  br label %bb269
bb221:
  br label %bb222
bb222:
  %t782 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t782, ptr %l431, !tbaa !27
  %t783 = load i64, ptr %l37, !tbaa !24
  %t785 = getelementptr { i64, ptr }, ptr %l431, i32 0, i32 1
  %t786 = load ptr, ptr %t785, !tbaa !27
  %t787 = getelementptr ptr, ptr %t786, i64 %t783
  %t788 = load ptr, ptr %t787, !tbaa !39
  store ptr %t788, ptr %l39, !tbaa !29
  %t790 = load ptr, ptr @__olang_prog_scope
  %t791 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e(ptr %t790)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t791, ptr %l434
  br label %bb223
bb223:
  %t792 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l434
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t792, ptr %l40
  %t793 = load ptr, ptr %l0, !tbaa !29
  %t794 = load ptr, ptr %l39, !tbaa !29
  %t797 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v2, ptr %t793, ptr %t794)
  store i1 %t797, ptr %l437
  br label %bb224
bb224:
  %t798 = load i1, ptr %l437, !tbaa !21
  store i1 %t798, ptr %l41, !tbaa !21
  %t799 = load ptr, ptr %l39, !tbaa !29
  %t801 = getelementptr %"compiler/ast:Catch", ptr %t799, i32 0, i32 1
  %t802 = load { i64, ptr }, ptr %t801, !tbaa !27
  %t804 = extractvalue { i64, ptr } %t802, 0
  %t806 = icmp sgt i64 %t804, 0
  br i1 %t806, label %bb225, label %bb226
bb225:
  %t808 = load i1, ptr %l41, !tbaa !21
  %t810 = xor i1 %t808, true
  store i1 %t810, ptr %l442, !tbaa !21
  br label %bb227
bb226:
  store i1 false, ptr %l442, !tbaa !21
  br label %bb227
bb227:
  %t812 = load i1, ptr %l442, !tbaa !21
  br i1 %t812, label %bb228, label %bb229
bb228:
  %t813 = load ptr, ptr %l39, !tbaa !29
  %t815 = getelementptr %"compiler/ast:Catch", ptr %t813, i32 0, i32 1
  %t816 = load { i64, ptr }, ptr %t815, !tbaa !27
  store { i64, ptr } %t816, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t818 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t820 = extractvalue { i64, ptr } %t818, 0
  store i64 %t820, ptr %l44, !tbaa !24
  br label %bb230
bb229:
  br label %bb237
bb230:
  store %olang.scope zeroinitializer, ptr %s34
  %t822 = load i64, ptr %l43, !tbaa !24
  %t823 = load i64, ptr %l44, !tbaa !24
  %t826 = icmp slt i64 %t822, %t823
  %t828 = xor i1 %t826, true
  br i1 %t828, label %bb231, label %bb232
bb231:
  call void @__olang_scope_close(ptr %s34)
  br label %bb236
bb232:
  br label %bb233
bb233:
  %t830 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t830, ptr %l453, !tbaa !27
  %t831 = load i64, ptr %l43, !tbaa !24
  %t833 = getelementptr { i64, ptr }, ptr %l453, i32 0, i32 1
  %t834 = load ptr, ptr %t833, !tbaa !27
  %t835 = getelementptr ptr, ptr %t834, i64 %t831
  %t836 = load ptr, ptr %t835, !tbaa !39
  %t838 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v2, ptr %s31, ptr %t838, ptr %t836, ptr %l40)
  br label %bb234
bb234:
  call void @__olang_scope_close(ptr %s34)
  br label %bb235
bb235:
  %t843 = load i64, ptr %l43, !tbaa !24
  %t845 = add i64 %t843, 1
  store i64 %t845, ptr %l43, !tbaa !24
  br label %bb230
bb236:
  br label %bb237
bb237:
  %t847 = load ptr, ptr %l39, !tbaa !29
  %t849 = getelementptr %"compiler/ast:Catch", ptr %t847, i32 0, i32 5
  %t850 = load i32, ptr %t849, !tbaa !23
  %t852 = icmp ne i32 %t850, 0
  br i1 %t852, label %bb238, label %bb239
bb238:
  store i1 true, ptr %l464, !tbaa !21
  br label %bb240
bb239:
  %t854 = load i1, ptr %l41, !tbaa !21
  store i1 %t854, ptr %l464, !tbaa !21
  br label %bb240
bb240:
  %t856 = load i1, ptr %l464, !tbaa !21
  br i1 %t856, label %bb241, label %bb242
bb241:
  store %olang.scope zeroinitializer, ptr %s36
  %t857 = load ptr, ptr %l0, !tbaa !29
  store ptr %t857, ptr %l466, !tbaa !29
  %t858 = load i1, ptr %l41, !tbaa !21
  br i1 %t858, label %bb243, label %bb244
bb242:
  br label %bb252
bb243:
  %t860 = load ptr, ptr %l39, !tbaa !29
  %t862 = getelementptr %"compiler/ast:Catch", ptr %t860, i32 0, i32 1
  %t863 = load { i64, ptr }, ptr %t862, !tbaa !27
  store { i64, ptr } %t863, ptr %l470, !tbaa !27
  %t864 = getelementptr { i64, ptr }, ptr %l470, i32 0, i32 1
  %t865 = load ptr, ptr %t864, !tbaa !27
  %t866 = getelementptr ptr, ptr %t865, i64 0
  %t867 = load ptr, ptr %t866, !tbaa !39
  %t869 = getelementptr %"compiler/ast:Path", ptr %t867, i32 0, i32 0
  %t870 = load %"compiler/source:Span", ptr %t869
  store %"compiler/source:Span" %t870, ptr %l468
  br label %bb245
bb244:
  %t872 = load ptr, ptr %l39, !tbaa !29
  %t874 = getelementptr %"compiler/ast:Catch", ptr %t872, i32 0, i32 6
  %t875 = load %"compiler/source:Span", ptr %t874
  store %"compiler/source:Span" %t875, ptr %l468
  br label %bb245
bb245:
  %t877 = load ptr, ptr %l0, !tbaa !29
  store ptr %t877, ptr %l475, !tbaa !29
  %t878 = load i1, ptr %l41, !tbaa !21
  br i1 %t878, label %bb246, label %bb247
bb246:
  %t880 = load ptr, ptr %l39, !tbaa !29
  %t882 = getelementptr %"compiler/ast:Catch", ptr %t880, i32 0, i32 1
  %t883 = load { i64, ptr }, ptr %t882, !tbaa !27
  store { i64, ptr } %t883, ptr %l479, !tbaa !27
  %t884 = getelementptr { i64, ptr }, ptr %l479, i32 0, i32 1
  %t885 = load ptr, ptr %t884, !tbaa !27
  %t886 = getelementptr ptr, ptr %t885, i64 0
  %t887 = load ptr, ptr %t886, !tbaa !39
  %t889 = getelementptr %"compiler/ast:Path", ptr %t887, i32 0, i32 1
  %t890 = load { i64, ptr }, ptr %t889, !tbaa !27
  store { i64, ptr } %t890, ptr %l481, !tbaa !27
  %t891 = getelementptr { i64, ptr }, ptr %l481, i32 0, i32 1
  %t892 = load ptr, ptr %t891, !tbaa !27
  %t893 = getelementptr i32, ptr %t892, i64 0
  %t894 = load i32, ptr %t893, !tbaa !33
  store i32 %t894, ptr %l477, !tbaa !23
  br label %bb248
bb247:
  %t896 = load ptr, ptr %l39, !tbaa !29
  %t898 = getelementptr %"compiler/ast:Catch", ptr %t896, i32 0, i32 5
  %t899 = load i32, ptr %t898, !tbaa !23
  store i32 %t899, ptr %l477, !tbaa !23
  br label %bb248
bb248:
  %t901 = load ptr, ptr %l475, !tbaa !29
  %t902 = load i32, ptr %l477, !tbaa !23
  %t903 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s36, ptr %t901, i32 %t902)
  store { i64, ptr } %t903, ptr %l485
  br label %bb249
bb249:
  %t904 = load { i64, ptr }, ptr %l485, !tbaa !27
  %t905 = extractvalue { i64, ptr } %t904, 0
  %t906 = extractvalue { i64, ptr } %t904, 1
  %t907 = mul i64 %t905, 1
  %t908 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t907)
  call void @llvm.memcpy.p0.p0.i64(ptr %t908, ptr %t906, i64 %t907, i1 false)
  %t909 = insertvalue { i64, ptr } undef, i64 %t905, 0
  %t910 = insertvalue { i64, ptr } %t909, ptr %t908, 1
  %t912 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchNameInTask(ptr %s36, ptr %s36, { i64, ptr } %t910)
  store %"compiler/msgs:Msg" %t912, ptr %l487
  br label %bb250
bb250:
  %t913 = load ptr, ptr %l466, !tbaa !29
  %t914 = load %"compiler/source:Span", ptr %l468
  %t915 = load %"compiler/msgs:Msg", ptr %l487
  %t916 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s36, ptr %t913, %"compiler/source:Span" %t914, %"compiler/msgs:Msg" %t915)
  store i64 %t916, ptr %l488
  br label %bb251
bb251:
  call void @__olang_scope_close(ptr %s36)
  br label %bb252
bb252:
  %t917 = load ptr, ptr %l39, !tbaa !29
  %t919 = getelementptr %"compiler/ast:Catch", ptr %t917, i32 0, i32 1
  %t920 = load { i64, ptr }, ptr %t919, !tbaa !27
  %t922 = extractvalue { i64, ptr } %t920, 0
  %t924 = icmp eq i64 %t922, 0
  br i1 %t924, label %bb253, label %bb254
bb253:
  store i1 true, ptr %l493, !tbaa !21
  br label %bb255
bb254:
  %t926 = load i1, ptr %l41, !tbaa !21
  store i1 %t926, ptr %l493, !tbaa !21
  br label %bb255
bb255:
  %t928 = load i1, ptr %l493, !tbaa !21
  store i1 %t928, ptr %l46, !tbaa !21
  %t929 = load ptr, ptr %l31, !tbaa !29
  store ptr %t929, ptr %l495, !tbaa !29
  %t930 = load ptr, ptr %l39, !tbaa !29
  %t932 = getelementptr %"compiler/ast:Catch", ptr %t930, i32 0, i32 0
  %t933 = load %"compiler/source:Span", ptr %t932
  store %"compiler/source:Span" %t933, ptr %l497
  %t935 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %s31, ptr %v0, ptr %l40)
  store { i64, ptr } %t935, ptr %l499
  br label %bb256
bb256:
  %t936 = load i1, ptr %l46, !tbaa !21
  store i1 %t936, ptr %l500, !tbaa !21
  %t937 = load ptr, ptr %l0, !tbaa !29
  store ptr %t937, ptr %l501, !tbaa !29
  %t938 = load ptr, ptr %l39, !tbaa !29
  store ptr %t938, ptr %l502, !tbaa !29
  %t939 = load i32, ptr %l33, !tbaa !23
  store i32 %t939, ptr %l503, !tbaa !23
  %t940 = load ptr, ptr %l5, !tbaa !29
  %t942 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H4d447d5f762c25bc2b844b5f209f491d(ptr %v0, ptr %t940)
  store i64 %t942, ptr %l505
  br label %bb257
bb257:
  %t943 = load ptr, ptr %l501, !tbaa !29
  %t944 = load ptr, ptr %l502, !tbaa !29
  %t945 = load i32, ptr %l503, !tbaa !23
  %t946 = load i64, ptr %l505, !tbaa !24
  %t947 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v2, ptr %t943, ptr %t944, i32 %t945, i64 %t946)
  store ptr %t947, ptr %l506
  br label %bb258
bb258:
  %t948 = load %"compiler/source:Span", ptr %l497
  %t949 = load { i64, ptr }, ptr %l499, !tbaa !27
  %t950 = load i1, ptr %l500, !tbaa !21
  %t951 = load ptr, ptr %l506, !tbaa !29
  %t952 = call %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t948, { i64, ptr } %t949, i1 %t950, ptr %t951)
  store %"compiler/typed:TaskClause" %t952, ptr %l507
  br label %bb259
bb259:
  %t953 = load %"compiler/typed:TaskClause", ptr %l507
  %t954 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/typed:TaskClause" %t953, ptr %t954
  %t955 = load ptr, ptr %l495, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aTaskClause_26_3e_H3ca385fa4615f85153508d1633d8a345(ptr %v0, ptr %v0, ptr %t955, ptr %t954)
  br label %bb260
bb260:
  store ptr %l32, ptr %l509, !tbaa !29
  %t957 = load ptr, ptr %l39, !tbaa !29
  %t959 = getelementptr %"compiler/ast:Catch", ptr %t957, i32 0, i32 0
  %t960 = load %"compiler/source:Span", ptr %t959
  store %"compiler/source:Span" %t960, ptr %l511
  %t962 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %s31, ptr %s0, ptr %l40)
  store { i64, ptr } %t962, ptr %l513
  br label %bb261
bb261:
  %t963 = load i1, ptr %l46, !tbaa !21
  store i1 %t963, ptr %l514, !tbaa !21
  %t964 = icmp sge i64 0, 0
  br i1 %t964, label %bb262, label %bb263
bb262:
  %t966 = icmp sle i64 0, 1152921504606846975
  br i1 %t966, label %bb264, label %bb265
bb263:
  call void @__olang_check_failed(ptr @olang_loc_a0a2b29f181c5519_be518ce768fc1fe5)
  unreachable
bb264:
  %t968 = mul i64 0, 8
  %t969 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t968)
  %t970 = insertvalue { i64, ptr } undef, i64 0, 0
  %t971 = insertvalue { i64, ptr } %t970, ptr %t969, 1
  %t972 = load %"compiler/source:Span", ptr %l511
  %t973 = load { i64, ptr }, ptr %l513, !tbaa !27
  %t974 = load i1, ptr %l514, !tbaa !21
  %t976 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, %"compiler/source:Span" %t972, { i64, ptr } %t973, i1 %t974, ptr null, { i64, ptr } %t971, i64 -1, i32 0)
  store %"compiler/typed:Clause" %t976, ptr %l518
  br label %bb266
bb265:
  call void @__olang_check_failed(ptr @olang_loc_a0a2b29f181c5519_be518ce768fc1fe5)
  unreachable
bb266:
  %t977 = load %"compiler/typed:Clause", ptr %l518
  %t978 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 72, i64 8)
  store %"compiler/typed:Clause" %t977, ptr %t978
  %t979 = load ptr, ptr %l509, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eP_Hee51906bde9346e7b7b6808fdce5ba81(ptr %s0, ptr %s0, ptr %t979, ptr %t978)
  br label %bb267
bb267:
  call void @__olang_scope_close(ptr %s31)
  br label %bb268
bb268:
  %t981 = load i64, ptr %l37, !tbaa !24
  %t983 = add i64 %t981, 1
  store i64 %t983, ptr %l37, !tbaa !24
  br label %bb219
bb269:
  call void @__olang_scope_close(ptr %s27)
  br label %bb270
bb270:
  %t985 = load ptr, ptr %l4, !tbaa !29
  %t987 = getelementptr %"compiler/check:frame", ptr %t985, i32 0, i32 35
  %t989 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t987)
  store i64 %t989, ptr %l524
  br label %bb271
bb271:
  %t990 = load i64, ptr %l524, !tbaa !24
  store i64 %t990, ptr %l47, !tbaa !24
  %t991 = load i1, ptr %l10, !tbaa !21
  br i1 %t991, label %bb272, label %bb273
bb272:
  %t993 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t993, ptr %l48, !tbaa !27
  store i64 0, ptr %l49, !tbaa !24
  %t995 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t997 = extractvalue { i64, ptr } %t995, 0
  store i64 %t997, ptr %l50, !tbaa !24
  br label %bb274
bb273:
  br label %bb281
bb274:
  store %olang.scope zeroinitializer, ptr %s40
  %t999 = load i64, ptr %l49, !tbaa !24
  %t1000 = load i64, ptr %l50, !tbaa !24
  %t1003 = icmp slt i64 %t999, %t1000
  %t1005 = xor i1 %t1003, true
  br i1 %t1005, label %bb275, label %bb276
bb275:
  call void @__olang_scope_close(ptr %s40)
  br label %bb280
bb276:
  br label %bb277
bb277:
  %t1007 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t1007, ptr %l533, !tbaa !27
  %t1008 = load i64, ptr %l49, !tbaa !24
  %t1010 = getelementptr { i64, ptr }, ptr %l533, i32 0, i32 1
  %t1011 = load ptr, ptr %t1010, !tbaa !27
  %t1012 = getelementptr i32, ptr %t1011, i64 %t1008
  %t1013 = load i32, ptr %t1012, !tbaa !33
  %t1015 = load ptr, ptr %l4, !tbaa !29
  %t1017 = getelementptr %"compiler/check:frame", ptr %t1015, i32 0, i32 35
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t1017, i32 %t1013)
  br label %bb278
bb278:
  call void @__olang_scope_close(ptr %s40)
  br label %bb279
bb279:
  %t1021 = load i64, ptr %l49, !tbaa !24
  %t1023 = add i64 %t1021, 1
  store i64 %t1023, ptr %l49, !tbaa !24
  br label %bb274
bb280:
  br label %bb281
bb281:
  %t1025 = load ptr, ptr %l0, !tbaa !29
  %t1026 = load ptr, ptr %l4, !tbaa !29
  %t1028 = getelementptr %"compiler/check:frame", ptr %t1026, i32 0, i32 35
  %t1029 = load i64, ptr %l47, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v0, ptr %s0, ptr %t1025, ptr %t1028, i64 %t1029, ptr %l32)
  br label %bb282
bb282:
  %t1034 = load ptr, ptr %l5, !tbaa !29
  %t1036 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H4d447d5f762c25bc2b844b5f209f491d(ptr %v0, ptr %t1034)
  store i64 %t1036, ptr %l547
  br label %bb283
bb283:
  %t1037 = load i64, ptr %l547, !tbaa !24
  %t1038 = icmp sgt i64 %t1037, 0
  br i1 %t1038, label %bb284, label %bb285
bb284:
  %t1040 = load ptr, ptr %l4, !tbaa !29
  %t1042 = getelementptr %"compiler/check:frame", ptr %t1040, i32 0, i32 35
  %t1044 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t1042)
  store i64 %t1044, ptr %l552
  br label %bb286
bb285:
  store i1 false, ptr %l549, !tbaa !21
  br label %bb287
bb286:
  %t1045 = load i64, ptr %l47, !tbaa !24
  %t1046 = load i64, ptr %l552, !tbaa !24
  %t1048 = icmp sgt i64 %t1046, %t1045
  store i1 %t1048, ptr %l549, !tbaa !21
  br label %bb287
bb287:
  %t1050 = load i1, ptr %l549, !tbaa !21
  br i1 %t1050, label %bb288, label %bb289
bb288:
  %t1051 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1051, ptr %l555, !tbaa !29
  %t1052 = load ptr, ptr %l555, !tbaa !29
  %t1053 = getelementptr %"compiler/check:frame", ptr %t1052, i32 0, i32 28
  %t1054 = load i64, ptr %t1053, !tbaa !24
  %t1056 = add i64 %t1054, 1
  %t1058 = load ptr, ptr %l555, !tbaa !29
  %t1059 = getelementptr %"compiler/check:frame", ptr %t1058, i32 0, i32 28
  store i64 %t1056, ptr %t1059, !tbaa !24
  br label %bb290
bb289:
  br label %bb290
bb290:
  %t1060 = load ptr, ptr %l16, !tbaa !29
  %t1063 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1060)
  store i32 %t1063, ptr %l560
  br label %bb291
bb291:
  %t1064 = load i32, ptr %l560, !tbaa !23
  store i32 %t1064, ptr %l52, !tbaa !23
  %t1065 = load ptr, ptr %l5, !tbaa !29
  %t1067 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H4d447d5f762c25bc2b844b5f209f491d(ptr %v0, ptr %t1065)
  store i64 %t1067, ptr %l562
  br label %bb292
bb292:
  %t1068 = load i64, ptr %l562, !tbaa !24
  %t1069 = icmp sgt i64 %t1068, 0
  br i1 %t1069, label %bb293, label %bb294
bb293:
  %t1071 = load i32, ptr %l52, !tbaa !23
  %t1072 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1075 = icmp eq i32 %t1071, %t1072
  br i1 %t1075, label %bb295, label %bb296
bb294:
  br label %bb419
bb295:
  store %olang.scope zeroinitializer, ptr %s44
  %t1077 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1077, ptr %l567, !tbaa !29
  %t1078 = load ptr, ptr %l3, !tbaa !29
  %t1080 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t1078)
  store %"compiler/source:Span" %t1080, ptr %l569
  br label %bb297
bb296:
  store %olang.scope zeroinitializer, ptr %s45
  %t1081 = icmp sge i64 1, 0
  br i1 %t1081, label %bb300, label %bb301
bb297:
  %t1083 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultVoid(ptr %s44)
  store %"compiler/msgs:Msg" %t1083, ptr %l570
  br label %bb298
bb298:
  %t1084 = load ptr, ptr %l567, !tbaa !29
  %t1085 = load %"compiler/source:Span", ptr %l569
  %t1086 = load %"compiler/msgs:Msg", ptr %l570
  %t1087 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s44, ptr %t1084, %"compiler/source:Span" %t1085, %"compiler/msgs:Msg" %t1086)
  store i64 %t1087, ptr %l571
  br label %bb299
bb299:
  call void @__olang_scope_close(ptr %s44)
  br label %bb418
bb300:
  %t1088 = icmp sle i64 1, 2305843009213693951
  br i1 %t1088, label %bb302, label %bb303
bb301:
  call void @__olang_check_failed(ptr @olang_loc_677b6b070937960c_aa2fc92e4a99f78)
  unreachable
bb302:
  %t1090 = mul i64 1, 4
  %t1091 = call ptr @__olang_scope_alloc_zeroed(ptr %s45, i64 %t1090)
  %t1092 = insertvalue { i64, ptr } undef, i64 1, 0
  %t1093 = insertvalue { i64, ptr } %t1092, ptr %t1091, 1
  store { i64, ptr } %t1093, ptr %l53, !tbaa !27
  %t1095 = load i32, ptr %l52, !tbaa !23
  %t1097 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t1098 = load ptr, ptr %t1097, !tbaa !27
  %t1099 = getelementptr i32, ptr %t1098, i64 0
  store i32 %t1095, ptr %t1099, !tbaa !33
  %t1100 = load ptr, ptr %l5, !tbaa !29
  %t1102 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H4d447d5f762c25bc2b844b5f209f491d(ptr %v0, ptr %t1100)
  store i64 %t1102, ptr %l577
  br label %bb304
bb303:
  call void @__olang_check_failed(ptr @olang_loc_677b6b070937960c_aa2fc92e4a99f78)
  unreachable
bb304:
  %t1103 = load i64, ptr %l577, !tbaa !24
  %t1104 = icmp sgt i64 %t1103, 1
  br i1 %t1104, label %bb305, label %bb306
bb305:
  %t1106 = load ptr, ptr %l0, !tbaa !29
  %t1108 = getelementptr %"compiler/check:Checker", ptr %t1106, i32 0, i32 1
  %t1109 = load ptr, ptr %t1108, !tbaa !29
  %t1111 = getelementptr %"compiler/generic:Program", ptr %t1109, i32 0, i32 2
  %t1112 = load i32, ptr %l52, !tbaa !23
  %t1115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1111, i32 %t1112)
  store i32 %t1115, ptr %l584
  br label %bb307
bb306:
  store i1 false, ptr %l579, !tbaa !21
  br label %bb308
bb307:
  %t1116 = load i32, ptr %l584
  %t1118 = trunc i64 22 to i32
  %t1119 = icmp eq i32 %t1116, %t1118
  store i1 %t1119, ptr %l579, !tbaa !21
  br label %bb308
bb308:
  %t1121 = load i1, ptr %l579, !tbaa !21
  br i1 %t1121, label %bb309, label %bb310
bb309:
  %t1122 = load ptr, ptr %l0, !tbaa !29
  %t1124 = getelementptr %"compiler/check:Checker", ptr %t1122, i32 0, i32 1
  %t1125 = load ptr, ptr %t1124, !tbaa !29
  %t1127 = getelementptr %"compiler/generic:Program", ptr %t1125, i32 0, i32 2
  store ptr %t1127, ptr %l589, !tbaa !29
  %t1128 = load ptr, ptr %l0, !tbaa !29
  %t1130 = getelementptr %"compiler/check:Checker", ptr %t1128, i32 0, i32 1
  %t1131 = load ptr, ptr %t1130, !tbaa !29
  %t1133 = getelementptr %"compiler/generic:Program", ptr %t1131, i32 0, i32 2
  %t1134 = load i32, ptr %l52, !tbaa !23
  %t1137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1133, i32 %t1134)
  store i32 %t1137, ptr %l594
  br label %bb311
bb310:
  br label %bb316
bb311:
  %t1138 = load ptr, ptr %l589, !tbaa !29
  %t1139 = load i32, ptr %l594, !tbaa !23
  %t1140 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1138, i32 %t1139)
  store { i64, ptr } %t1140, ptr %l595
  br label %bb312
bb312:
  %t1141 = load { i64, ptr }, ptr %l595, !tbaa !27
  store { i64, ptr } %t1141, ptr %l596, !tbaa !27
  %t1142 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t1143 = extractvalue { i64, ptr } %t1142, 0
  %t1144 = load { i64, ptr }, ptr %l596, !tbaa !27
  %t1145 = extractvalue { i64, ptr } %t1144, 0
  store i64 %t1145, ptr %l598, !tbaa !24
  %t1147 = load i64, ptr %l598, !tbaa !24
  %t1148 = icmp eq i64 %t1143, %t1147
  br i1 %t1148, label %bb313, label %bb314
bb313:
  %t1150 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t1151 = load ptr, ptr %t1150, !tbaa !27
  %t1152 = getelementptr { i64, ptr }, ptr %l596, i32 0, i32 1
  %t1153 = load ptr, ptr %t1152, !tbaa !27
  %t1154 = load i64, ptr %l598, !tbaa !24
  %t1155 = mul i64 %t1154, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t1151, ptr %t1153, i64 %t1155, i1 false)
  br label %bb315
bb314:
  %t1156 = load { i64, ptr }, ptr %l596, !tbaa !27
  %t1157 = extractvalue { i64, ptr } %t1156, 0
  store i64 %t1157, ptr %l600, !tbaa !24
  %t1158 = load i64, ptr %l600, !tbaa !24
  %t1159 = mul i64 %t1158, 4
  %t1160 = call ptr @__olang_scope_alloc_zeroed(ptr %s45, i64 %t1159)
  %t1161 = insertvalue { i64, ptr } undef, i64 %t1158, 0
  %t1162 = insertvalue { i64, ptr } %t1161, ptr %t1160, 1
  store { i64, ptr } %t1162, ptr %l601, !tbaa !27
  %t1163 = getelementptr { i64, ptr }, ptr %l601, i32 0, i32 1
  %t1164 = load ptr, ptr %t1163, !tbaa !27
  %t1165 = getelementptr { i64, ptr }, ptr %l596, i32 0, i32 1
  %t1166 = load ptr, ptr %t1165, !tbaa !27
  %t1167 = load i64, ptr %l600, !tbaa !24
  %t1168 = mul i64 %t1167, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t1164, ptr %t1166, i64 %t1168, i1 false)
  %t1169 = load { i64, ptr }, ptr %l601, !tbaa !27
  store { i64, ptr } %t1169, ptr %l53, !tbaa !27
  br label %bb315
bb315:
  br label %bb316
bb316:
  %t1170 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t1172 = extractvalue { i64, ptr } %t1170, 0
  store i64 %t1172, ptr %l603, !tbaa !24
  %t1173 = load ptr, ptr %l5, !tbaa !29
  %t1175 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H4d447d5f762c25bc2b844b5f209f491d(ptr %v0, ptr %t1173)
  store i64 %t1175, ptr %l605
  br label %bb317
bb317:
  %t1176 = load i64, ptr %l603, !tbaa !24
  %t1177 = load i64, ptr %l605, !tbaa !24
  %t1178 = icmp ne i64 %t1176, %t1177
  br i1 %t1178, label %bb318, label %bb319
bb318:
  store %olang.scope zeroinitializer, ptr %s47
  %t1180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1180, ptr %l607, !tbaa !29
  %t1181 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1181, ptr %l608
  %t1182 = load ptr, ptr %l5, !tbaa !29
  %t1184 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H4d447d5f762c25bc2b844b5f209f491d(ptr %v0, ptr %t1182)
  store i64 %t1184, ptr %l610
  br label %bb320
bb319:
  store i64 0, ptr %l54, !tbaa !24
  %t1185 = load ptr, ptr %l5, !tbaa !29
  %t1187 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H4d447d5f762c25bc2b844b5f209f491d(ptr %v0, ptr %t1185)
  store i64 %t1187, ptr %l616
  br label %bb323
bb320:
  %t1188 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t1190 = extractvalue { i64, ptr } %t1188, 0
  %t1191 = load i64, ptr %l610, !tbaa !24
  %t1193 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %s47, i64 %t1191, i64 %t1190)
  store %"compiler/msgs:Msg" %t1193, ptr %l613
  br label %bb321
bb321:
  %t1194 = load ptr, ptr %l607, !tbaa !29
  %t1195 = load %"compiler/source:Span", ptr %l608
  %t1196 = load %"compiler/msgs:Msg", ptr %l613
  %t1197 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s47, ptr %t1194, %"compiler/source:Span" %t1195, %"compiler/msgs:Msg" %t1196)
  store i64 %t1197, ptr %l614
  br label %bb322
bb322:
  call void @__olang_scope_close(ptr %s47)
  br label %bb417
bb323:
  %t1198 = load i64, ptr %l616, !tbaa !24
  store i64 %t1198, ptr %l55, !tbaa !24
  store i64 1, ptr %l56, !tbaa !24
  %t1199 = load i64, ptr %l55, !tbaa !24
  %t1200 = load i64, ptr %l54, !tbaa !24
  %t1203 = icmp sgt i64 %t1199, %t1200
  br i1 %t1203, label %bb324, label %bb325
bb324:
  %t1205 = load i64, ptr %l56, !tbaa !24
  %t1207 = icmp sgt i64 %t1205, 0
  br i1 %t1207, label %bb326, label %bb327
bb325:
  store i64 0, ptr %l620, !tbaa !24
  br label %bb329
bb326:
  %t1209 = load i64, ptr %l55, !tbaa !24
  %t1210 = load i64, ptr %l54, !tbaa !24
  %t1213 = sub i64 %t1209, %t1210
  %t1214 = load i64, ptr %l56, !tbaa !24
  %t1217 = add i64 %t1213, %t1214
  %t1219 = sub i64 %t1217, 1
  %t1220 = load i64, ptr %l56, !tbaa !24
  %t1223 = sdiv i64 %t1219, %t1220
  store i64 %t1223, ptr %l623, !tbaa !24
  br label %bb328
bb327:
  store i64 0, ptr %l623, !tbaa !24
  br label %bb328
bb328:
  %t1225 = load i64, ptr %l623, !tbaa !24
  store i64 %t1225, ptr %l620, !tbaa !24
  br label %bb329
bb329:
  %t1226 = load i64, ptr %l620, !tbaa !24
  store i64 %t1226, ptr %l57, !tbaa !24
  store i64 0, ptr %l58, !tbaa !24
  br label %bb330
bb330:
  store %olang.scope zeroinitializer, ptr %s50
  %t1227 = load i64, ptr %l58, !tbaa !24
  %t1228 = load i64, ptr %l57, !tbaa !24
  %t1231 = icmp slt i64 %t1227, %t1228
  %t1233 = xor i1 %t1231, true
  br i1 %t1233, label %bb331, label %bb332
bb331:
  call void @__olang_scope_close(ptr %s50)
  br label %bb416
bb332:
  br label %bb333
bb333:
  %t1235 = load i64, ptr %l54, !tbaa !24
  %t1236 = load i64, ptr %l58, !tbaa !24
  %t1237 = load i64, ptr %l56, !tbaa !24
  %t1240 = mul i64 %t1236, %t1237
  %t1243 = add i64 %t1235, %t1240
  store i64 %t1243, ptr %l59, !tbaa !24
  %t1245 = load ptr, ptr %l5, !tbaa !29
  %t1246 = load i64, ptr %l59, !tbaa !24
  %t1249 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %s50, ptr %t1245, i64 %t1246)
  store ptr %t1249, ptr %l643
  br label %bb334
bb334:
  %t1250 = load ptr, ptr %l643, !tbaa !29
  %t1251 = icmp eq ptr %t1250, null
  %t1253 = xor i1 %t1251, true
  br i1 %t1253, label %bb335, label %bb336
bb335:
  %t1255 = load ptr, ptr %l5, !tbaa !29
  %t1256 = load i64, ptr %l59, !tbaa !24
  %t1259 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %v0, ptr %t1255, i64 %t1256)
  store ptr %t1259, ptr %l649
  br label %bb337
bb336:
  %t1260 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1260, ptr %l646, !tbaa !23
  br label %bb342
bb337:
  %t1262 = load ptr, ptr %l649, !tbaa !29
  store ptr %t1262, ptr %l60, !tbaa !29
  %t1263 = load ptr, ptr %l60, !tbaa !29
  %t1265 = icmp eq ptr %t1263, null
  br i1 %t1265, label %bb338, label %bb339
bb338:
  call void @__olang_check_failed(ptr @olang_loc_bd22b69341f84ac1_ea8edc6c92d7b395)
  unreachable
bb339:
  br label %bb340
bb340:
  %t1267 = load ptr, ptr %l60, !tbaa !29
  %t1269 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t1267)
  store i32 %t1269, ptr %l653
  br label %bb341
bb341:
  %t1270 = load i32, ptr %l653, !tbaa !23
  store i32 %t1270, ptr %l646, !tbaa !23
  br label %bb342
bb342:
  %t1271 = load i32, ptr %l646, !tbaa !23
  store i32 %t1271, ptr %l61, !tbaa !23
  %t1272 = load ptr, ptr %l0, !tbaa !29
  %t1274 = getelementptr %"compiler/check:Checker", ptr %t1272, i32 0, i32 1
  %t1275 = load ptr, ptr %t1274, !tbaa !29
  %t1277 = getelementptr %"compiler/generic:Program", ptr %t1275, i32 0, i32 2
  %t1278 = load i32, ptr %l61, !tbaa !23
  %t1279 = load i64, ptr %l59, !tbaa !24
  %t1281 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t1282 = load ptr, ptr %t1281, !tbaa !27
  %t1283 = getelementptr i32, ptr %t1282, i64 %t1279
  %t1284 = load i32, ptr %t1283, !tbaa !33
  %t1288 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t1277, i32 %t1278, i32 %t1284)
  store i1 %t1288, ptr %l661
  br label %bb343
bb343:
  %t1289 = load i1, ptr %l661, !tbaa !21
  br i1 %t1289, label %bb344, label %bb345
bb344:
  store i1 true, ptr %l662, !tbaa !21
  br label %bb357
bb345:
  %t1290 = load ptr, ptr %l0, !tbaa !29
  %t1291 = load i32, ptr %l61, !tbaa !23
  %t1294 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1290, i32 %t1291)
  store i1 %t1294, ptr %l665
  br label %bb346
bb346:
  %t1295 = load i1, ptr %l665, !tbaa !21
  br i1 %t1295, label %bb347, label %bb348
bb347:
  %t1296 = load ptr, ptr %l0, !tbaa !29
  %t1297 = load i64, ptr %l59, !tbaa !24
  %t1299 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t1300 = load ptr, ptr %t1299, !tbaa !27
  %t1301 = getelementptr i32, ptr %t1300, i64 %t1297
  %t1302 = load i32, ptr %t1301, !tbaa !33
  %t1305 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1296, i32 %t1302)
  store i1 %t1305, ptr %l670
  br label %bb349
bb348:
  store i1 false, ptr %l666, !tbaa !21
  br label %bb350
bb349:
  %t1306 = load i1, ptr %l670, !tbaa !21
  store i1 %t1306, ptr %l666, !tbaa !21
  br label %bb350
bb350:
  %t1307 = load i1, ptr %l666, !tbaa !21
  br i1 %t1307, label %bb351, label %bb352
bb351:
  %t1308 = load ptr, ptr %l0, !tbaa !29
  %t1310 = getelementptr %"compiler/check:Checker", ptr %t1308, i32 0, i32 1
  %t1311 = load ptr, ptr %t1310, !tbaa !29
  %t1313 = getelementptr %"compiler/generic:Program", ptr %t1311, i32 0, i32 2
  store ptr %t1313, ptr %l674, !tbaa !29
  %t1314 = load ptr, ptr %l0, !tbaa !29
  %t1315 = load i32, ptr %l61, !tbaa !23
  %t1318 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1314, i32 %t1315)
  store i32 %t1318, ptr %l677
  br label %bb353
bb352:
  store i1 false, ptr %l671, !tbaa !21
  br label %bb356
bb353:
  %t1319 = load ptr, ptr %l0, !tbaa !29
  %t1320 = load i64, ptr %l59, !tbaa !24
  %t1322 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t1323 = load ptr, ptr %t1322, !tbaa !27
  %t1324 = getelementptr i32, ptr %t1323, i64 %t1320
  %t1325 = load i32, ptr %t1324, !tbaa !33
  %t1328 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1319, i32 %t1325)
  store i32 %t1328, ptr %l681
  br label %bb354
bb354:
  %t1329 = load ptr, ptr %l674, !tbaa !29
  %t1330 = load i32, ptr %l677, !tbaa !23
  %t1331 = load i32, ptr %l681, !tbaa !23
  %t1332 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t1329, i32 %t1330, i32 %t1331)
  store i1 %t1332, ptr %l682
  br label %bb355
bb355:
  %t1333 = load i1, ptr %l682, !tbaa !21
  store i1 %t1333, ptr %l671, !tbaa !21
  br label %bb356
bb356:
  %t1334 = load i1, ptr %l671, !tbaa !21
  store i1 %t1334, ptr %l662, !tbaa !21
  br label %bb357
bb357:
  %t1335 = load i1, ptr %l662, !tbaa !21
  store i1 %t1335, ptr %l62, !tbaa !21
  %t1336 = load ptr, ptr %l5, !tbaa !29
  %t1337 = load i64, ptr %l59, !tbaa !24
  %t1340 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %s50, ptr %t1336, i64 %t1337)
  store ptr %t1340, ptr %l685
  br label %bb358
bb358:
  %t1341 = load ptr, ptr %l685, !tbaa !29
  %t1342 = icmp eq ptr %t1341, null
  %t1344 = xor i1 %t1342, true
  br i1 %t1344, label %bb359, label %bb360
bb359:
  %t1346 = load i1, ptr %l62, !tbaa !21
  %t1348 = xor i1 %t1346, true
  store i1 %t1348, ptr %l688, !tbaa !21
  br label %bb361
bb360:
  store i1 false, ptr %l688, !tbaa !21
  br label %bb361
bb361:
  %t1350 = load i1, ptr %l688, !tbaa !21
  br i1 %t1350, label %bb362, label %bb363
bb362:
  %t1351 = load ptr, ptr %l0, !tbaa !29
  %t1352 = load i32, ptr %l61, !tbaa !23
  %t1355 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1351, i32 %t1352)
  store i1 %t1355, ptr %l693
  br label %bb364
bb363:
  br label %bb414
bb364:
  %t1356 = load i1, ptr %l693, !tbaa !21
  br i1 %t1356, label %bb365, label %bb366
bb365:
  %t1357 = load ptr, ptr %l0, !tbaa !29
  %t1358 = load i64, ptr %l59, !tbaa !24
  %t1360 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t1361 = load ptr, ptr %t1360, !tbaa !27
  %t1362 = getelementptr i32, ptr %t1361, i64 %t1358
  %t1363 = load i32, ptr %t1362, !tbaa !33
  %t1366 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1357, i32 %t1363)
  store i1 %t1366, ptr %l698
  br label %bb367
bb366:
  store i1 false, ptr %l694, !tbaa !21
  br label %bb368
bb367:
  %t1367 = load i1, ptr %l698, !tbaa !21
  %t1368 = xor i1 %t1367, true
  store i1 %t1368, ptr %l694, !tbaa !21
  br label %bb368
bb368:
  %t1370 = load i1, ptr %l694, !tbaa !21
  br i1 %t1370, label %bb369, label %bb370
bb369:
  %t1371 = load ptr, ptr %l0, !tbaa !29
  %t1373 = getelementptr %"compiler/check:Checker", ptr %t1371, i32 0, i32 1
  %t1374 = load ptr, ptr %t1373, !tbaa !29
  %t1376 = getelementptr %"compiler/generic:Program", ptr %t1374, i32 0, i32 2
  store ptr %t1376, ptr %l703, !tbaa !29
  %t1377 = load ptr, ptr %l0, !tbaa !29
  %t1378 = load i32, ptr %l61, !tbaa !23
  %t1381 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1377, i32 %t1378)
  store i32 %t1381, ptr %l706
  br label %bb371
bb370:
  store i1 false, ptr %l700, !tbaa !21
  br label %bb373
bb371:
  %t1382 = load i64, ptr %l59, !tbaa !24
  %t1384 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t1385 = load ptr, ptr %t1384, !tbaa !27
  %t1386 = getelementptr i32, ptr %t1385, i64 %t1382
  %t1387 = load i32, ptr %t1386, !tbaa !33
  %t1388 = load ptr, ptr %l703, !tbaa !29
  %t1389 = load i32, ptr %l706, !tbaa !23
  %t1391 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t1388, i32 %t1389, i32 %t1387)
  store i1 %t1391, ptr %l709
  br label %bb372
bb372:
  %t1392 = load i1, ptr %l709, !tbaa !21
  store i1 %t1392, ptr %l700, !tbaa !21
  br label %bb373
bb373:
  %t1393 = load i1, ptr %l700, !tbaa !21
  br i1 %t1393, label %bb374, label %bb375
bb374:
  store %olang.scope zeroinitializer, ptr %s52
  %t1394 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1394, ptr %l710, !tbaa !29
  %t1395 = load ptr, ptr %l0, !tbaa !29
  %t1396 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1396, ptr %l712, !tbaa !27
  %t1397 = load i64, ptr %l59, !tbaa !24
  %t1399 = getelementptr { i64, ptr }, ptr %l712, i32 0, i32 1
  %t1400 = load ptr, ptr %t1399, !tbaa !27
  %t1401 = getelementptr ptr, ptr %t1400, i64 %t1397
  %t1402 = load ptr, ptr %t1401, !tbaa !39
  %t1405 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t1395, ptr %t1402)
  store %"compiler/source:Span" %t1405, ptr %l715
  br label %bb376
bb375:
  store %olang.scope zeroinitializer, ptr %s53
  %t1406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1406, ptr %l736, !tbaa !29
  %t1407 = load ptr, ptr %l0, !tbaa !29
  %t1408 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1408, ptr %l738, !tbaa !27
  %t1409 = load i64, ptr %l59, !tbaa !24
  %t1411 = getelementptr { i64, ptr }, ptr %l738, i32 0, i32 1
  %t1412 = load ptr, ptr %t1411, !tbaa !27
  %t1413 = getelementptr ptr, ptr %t1412, i64 %t1409
  %t1414 = load ptr, ptr %t1413, !tbaa !39
  %t1417 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t1407, ptr %t1414)
  store %"compiler/source:Span" %t1417, ptr %l741
  br label %bb384
bb376:
  %t1418 = load ptr, ptr %l0, !tbaa !29
  %t1419 = load i64, ptr %l59, !tbaa !24
  %t1421 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t1422 = load ptr, ptr %t1421, !tbaa !27
  %t1423 = getelementptr i32, ptr %t1422, i64 %t1419
  %t1424 = load i32, ptr %t1423, !tbaa !33
  %t1427 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s52, ptr %t1418, i32 %t1424)
  store { i64, ptr } %t1427, ptr %l719
  br label %bb377
bb377:
  %t1428 = load { i64, ptr }, ptr %l719, !tbaa !27
  %t1429 = extractvalue { i64, ptr } %t1428, 0
  %t1430 = extractvalue { i64, ptr } %t1428, 1
  %t1431 = mul i64 %t1429, 1
  %t1432 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1431)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1432, ptr %t1430, i64 %t1431, i1 false)
  %t1433 = insertvalue { i64, ptr } undef, i64 %t1429, 0
  %t1434 = insertvalue { i64, ptr } %t1433, ptr %t1432, 1
  store { i64, ptr } %t1434, ptr %l720, !tbaa !27
  %t1435 = load ptr, ptr %l0, !tbaa !29
  %t1436 = load i32, ptr %l61, !tbaa !23
  %t1439 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s52, ptr %t1435, i32 %t1436)
  store { i64, ptr } %t1439, ptr %l723
  br label %bb378
bb378:
  %t1440 = load { i64, ptr }, ptr %l723, !tbaa !27
  %t1441 = extractvalue { i64, ptr } %t1440, 0
  %t1442 = extractvalue { i64, ptr } %t1440, 1
  %t1443 = mul i64 %t1441, 1
  %t1444 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1443)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1444, ptr %t1442, i64 %t1443, i1 false)
  %t1445 = insertvalue { i64, ptr } undef, i64 %t1441, 0
  %t1446 = insertvalue { i64, ptr } %t1445, ptr %t1444, 1
  store { i64, ptr } %t1446, ptr %l724, !tbaa !27
  %t1447 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1447, ptr %l725, !tbaa !29
  %t1448 = load ptr, ptr %l0, !tbaa !29
  %t1449 = load ptr, ptr %l3, !tbaa !29
  %t1452 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v2, ptr %t1448, ptr %t1449)
  store %"compiler/source:Span" %t1452, ptr %l728
  br label %bb379
bb379:
  %t1453 = load ptr, ptr %l725, !tbaa !29
  %t1454 = load %"compiler/source:Span", ptr %l728
  %t1455 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t1453, %"compiler/source:Span" %t1454)
  store { i64, ptr } %t1455, ptr %l729
  br label %bb380
bb380:
  %t1456 = load ptr, ptr %l0, !tbaa !29
  %t1457 = load i32, ptr %l61, !tbaa !23
  %t1460 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s52, ptr %t1456, i32 %t1457)
  store { i64, ptr } %t1460, ptr %l732
  br label %bb381
bb381:
  %t1461 = load { i64, ptr }, ptr %l732, !tbaa !27
  %t1462 = extractvalue { i64, ptr } %t1461, 0
  %t1463 = extractvalue { i64, ptr } %t1461, 1
  %t1464 = mul i64 %t1462, 1
  %t1465 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1464)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1465, ptr %t1463, i64 %t1464, i1 false)
  %t1466 = insertvalue { i64, ptr } undef, i64 %t1462, 0
  %t1467 = insertvalue { i64, ptr } %t1466, ptr %t1465, 1
  %t1468 = load { i64, ptr }, ptr %l720, !tbaa !27
  %t1469 = load { i64, ptr }, ptr %l724, !tbaa !27
  %t1470 = load { i64, ptr }, ptr %l729, !tbaa !27
  %t1472 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultAsRef(ptr %s52, ptr %s52, ptr %v0, ptr %s52, ptr %s52, { i64, ptr } %t1468, { i64, ptr } %t1469, { i64, ptr } %t1470, { i64, ptr } %t1467)
  store %"compiler/msgs:Msg" %t1472, ptr %l734
  br label %bb382
bb382:
  %t1473 = load ptr, ptr %l710, !tbaa !29
  %t1474 = load %"compiler/source:Span", ptr %l715
  %t1475 = load %"compiler/msgs:Msg", ptr %l734
  %t1476 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s52, ptr %t1473, %"compiler/source:Span" %t1474, %"compiler/msgs:Msg" %t1475)
  store i64 %t1476, ptr %l735
  br label %bb383
bb383:
  call void @__olang_scope_close(ptr %s52)
  br label %bb413
bb384:
  %t1477 = load ptr, ptr %l0, !tbaa !29
  %t1478 = load i64, ptr %l59, !tbaa !24
  %t1480 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t1481 = load ptr, ptr %t1480, !tbaa !27
  %t1482 = getelementptr i32, ptr %t1481, i64 %t1478
  %t1483 = load i32, ptr %t1482, !tbaa !33
  %t1486 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s53, ptr %t1477, i32 %t1483)
  store { i64, ptr } %t1486, ptr %l745
  br label %bb385
bb385:
  %t1487 = load { i64, ptr }, ptr %l745, !tbaa !27
  %t1488 = extractvalue { i64, ptr } %t1487, 0
  %t1489 = extractvalue { i64, ptr } %t1487, 1
  %t1490 = mul i64 %t1488, 1
  %t1491 = call ptr @__olang_scope_alloc(ptr %s53, i64 %t1490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1491, ptr %t1489, i64 %t1490, i1 false)
  %t1492 = insertvalue { i64, ptr } undef, i64 %t1488, 0
  %t1493 = insertvalue { i64, ptr } %t1492, ptr %t1491, 1
  store { i64, ptr } %t1493, ptr %l746, !tbaa !27
  %t1494 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1494, ptr %l747, !tbaa !29
  %t1495 = load ptr, ptr %l5, !tbaa !29
  %t1496 = load i64, ptr %l59, !tbaa !24
  %t1499 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %v0, ptr %t1495, i64 %t1496)
  store ptr %t1499, ptr %l750
  br label %bb386
bb386:
  %t1500 = load ptr, ptr %l750, !tbaa !29
  store ptr %t1500, ptr %l63, !tbaa !29
  %t1501 = load ptr, ptr %l63, !tbaa !29
  %t1503 = icmp eq ptr %t1501, null
  br i1 %t1503, label %bb387, label %bb388
bb387:
  call void @__olang_check_failed(ptr @olang_loc_bd26e4864ba9573a_dfa400004ab377ee)
  unreachable
bb388:
  br label %bb389
bb389:
  %t1505 = load ptr, ptr %l63, !tbaa !29
  %t1507 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t1505)
  store i32 %t1507, ptr %l754
  br label %bb390
bb390:
  %t1508 = load ptr, ptr %l747, !tbaa !29
  %t1509 = load i32, ptr %l754, !tbaa !23
  %t1510 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s53, ptr %t1508, i32 %t1509)
  store { i64, ptr } %t1510, ptr %l755
  br label %bb391
bb391:
  %t1511 = load { i64, ptr }, ptr %l755, !tbaa !27
  %t1512 = extractvalue { i64, ptr } %t1511, 0
  %t1513 = extractvalue { i64, ptr } %t1511, 1
  %t1514 = mul i64 %t1512, 1
  %t1515 = call ptr @__olang_scope_alloc(ptr %s53, i64 %t1514)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1515, ptr %t1513, i64 %t1514, i1 false)
  %t1516 = insertvalue { i64, ptr } undef, i64 %t1512, 0
  %t1517 = insertvalue { i64, ptr } %t1516, ptr %t1515, 1
  %t1518 = load { i64, ptr }, ptr %l746, !tbaa !27
  %t1520 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultType(ptr %s53, ptr %s53, ptr %s53, { i64, ptr } %t1518, { i64, ptr } %t1517)
  store %"compiler/msgs:Msg" %t1520, ptr %l757
  br label %bb392
bb392:
  %t1521 = load ptr, ptr %l736, !tbaa !29
  %t1522 = load %"compiler/source:Span", ptr %l741
  %t1523 = load %"compiler/msgs:Msg", ptr %l757
  %t1524 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s53, ptr %t1521, %"compiler/source:Span" %t1522, %"compiler/msgs:Msg" %t1523)
  store i64 %t1524, ptr %l758
  br label %bb393
bb393:
  %t1525 = load i64, ptr %l758, !tbaa !24
  store i64 %t1525, ptr %l64, !tbaa !24
  %t1526 = load ptr, ptr %l5, !tbaa !29
  %t1527 = load i64, ptr %l59, !tbaa !24
  %t1530 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %s53, ptr %t1526, i64 %t1527)
  store ptr %t1530, ptr %l761
  br label %bb394
bb394:
  %t1531 = load ptr, ptr %l761, !tbaa !29
  store ptr %t1531, ptr %l65, !tbaa !29
  %t1532 = load ptr, ptr %l65, !tbaa !29
  store ptr %t1532, ptr %l762, !tbaa !29
  store i1 false, ptr %l763, !tbaa !21
  %t1533 = load ptr, ptr %l762, !tbaa !29
  %t1534 = icmp ne ptr %t1533, null
  br i1 %t1534, label %bb395, label %bb396
bb395:
  %t1536 = load ptr, ptr %l762, !tbaa !29
  %t1537 = load i64, ptr %t1536
  %t1539 = icmp eq i64 %t1537, 0
  store i1 %t1539, ptr %l763, !tbaa !21
  br label %bb396
bb396:
  %t1540 = load i1, ptr %l763, !tbaa !21
  br i1 %t1540, label %bb397, label %bb398
bb397:
  %t1541 = load ptr, ptr %l65, !tbaa !29
  %t1543 = getelementptr { i64, [4 x i64] }, ptr %t1541, i32 0, i32 1
  %t1544 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t1543, i32 0, i32 2
  %t1545 = load i32, ptr %t1544
  store i32 %t1545, ptr %l66, !tbaa !23
  br label %bb399
bb398:
  br label %bb407
bb399:
  store %olang.scope zeroinitializer, ptr %s54
  %t1547 = load ptr, ptr %l0, !tbaa !29
  %t1549 = getelementptr %"compiler/check:Checker", ptr %t1547, i32 0, i32 27
  store ptr %t1549, ptr %l769, !tbaa !29
  %t1550 = load ptr, ptr %l0, !tbaa !29
  %t1552 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1550)
  store ptr %t1552, ptr %l771
  br label %bb400
bb400:
  %t1553 = load ptr, ptr %l771, !tbaa !29
  %t1555 = getelementptr %"compiler/check:frame", ptr %t1553, i32 0, i32 0
  %t1556 = load i64, ptr %t1555, !tbaa !24
  %t1557 = load i32, ptr %l66, !tbaa !23
  %t1559 = sext i32 %t1557 to i64
  %t1562 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s54, i64 %t1556, i64 %t1559)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1562, ptr %l776
  br label %bb401
bb401:
  %t1563 = load ptr, ptr %l769, !tbaa !29
  %t1564 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l776
  %t1565 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t1563, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1564)
  store i1 %t1565, ptr %l777
  br label %bb402
bb402:
  %t1566 = load i1, ptr %l777, !tbaa !21
  br i1 %t1566, label %bb403, label %bb404
bb403:
  %t1567 = load ptr, ptr %l0, !tbaa !29
  %t1568 = load i64, ptr %l64, !tbaa !24
  %t1569 = load i32, ptr %l66, !tbaa !23
  %t1571 = sext i32 %t1569 to i64
  %t1572 = load i64, ptr %l59, !tbaa !24
  %t1574 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t1575 = load ptr, ptr %t1574, !tbaa !27
  %t1576 = getelementptr i32, ptr %t1575, i64 %t1572
  %t1577 = load i32, ptr %t1576, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalNote(ptr %v0, ptr %t1567, i64 %t1568, i64 %t1571, i32 %t1577)
  br label %bb405
bb404:
  br label %bb406
bb405:
  br label %bb406
bb406:
  call void @__olang_scope_close(ptr %s54)
  br label %bb412
bb407:
  br i1 true, label %bb408, label %bb409
bb408:
  br label %bb410
bb409:
  br label %bb411
bb410:
  br label %bb412
bb411:
  call void @__olang_check_failed(ptr @olang_loc_e80162ef31442376_d45687553b8e74d2)
  unreachable
bb412:
  call void @__olang_scope_close(ptr %s53)
  br label %bb413
bb413:
  br label %bb414
bb414:
  call void @__olang_scope_close(ptr %s50)
  br label %bb415
bb415:
  %t1582 = load i64, ptr %l58, !tbaa !24
  %t1584 = add i64 %t1582, 1
  store i64 %t1584, ptr %l58, !tbaa !24
  br label %bb330
bb416:
  br label %bb417
bb417:
  call void @__olang_scope_close(ptr %s45)
  br label %bb418
bb418:
  br label %bb419
bb419:
  %t1586 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1586, ptr %l786, !tbaa !29
  %t1587 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1587, ptr %l787
  %t1588 = load ptr, ptr %l5, !tbaa !29
  %t1590 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Hc6bfb67c24d59c9d5bbbdae0417c538b(ptr %v0, ptr %v0, ptr %t1588)
  store { i64, ptr } %t1590, ptr %l789
  br label %bb420
bb420:
  %t1591 = load ptr, ptr %l16, !tbaa !29
  store ptr %t1591, ptr %l790, !tbaa !29
  %t1592 = load ptr, ptr %l31, !tbaa !29
  %t1594 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aTaskClause_26_3e_Hc73dff03d06e80c51c2cbccf7b6fc7e6(ptr %v0, ptr %v0, ptr %t1592)
  store { i64, ptr } %t1594, ptr %l792
  br label %bb421
bb421:
  %t1595 = load ptr, ptr %l0, !tbaa !29
  %t1596 = load %"compiler/source:Span", ptr %l1
  %t1600 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1595, i32 6, %"compiler/source:Span" %t1596)
  store i32 %t1600, ptr %l796
  br label %bb422
bb422:
  %t1601 = load { i64, ptr }, ptr %l789, !tbaa !27
  %t1602 = load ptr, ptr %l790, !tbaa !29
  %t1603 = load { i64, ptr }, ptr %l792, !tbaa !27
  %t1604 = load i32, ptr %l796, !tbaa !23
  %t1605 = call %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t1601, ptr %t1602, { i64, ptr } %t1603, i32 %t1604)
  store %"compiler/typed:Spawn" %t1605, ptr %l797
  br label %bb423
bb423:
  %t1606 = load %"compiler/typed:Spawn", ptr %l797
  %t1607 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Spawn" %t1606, ptr %t1607
  store { i64, [3 x i64] } zeroinitializer, ptr %t1608
  %t1609 = getelementptr { i64, [3 x i64] }, ptr %t1608, i32 0, i32 0
  store i64 14, ptr %t1609
  %t1610 = load %"compiler/source:Span", ptr %l787
  %t1611 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1610, 0
  %t1613 = insertvalue { %"compiler/source:Span", ptr } %t1611, ptr %t1607, 1
  %t1614 = getelementptr { i64, [3 x i64] }, ptr %t1608, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1613, ptr %t1614
  %t1615 = load { i64, [3 x i64] }, ptr %t1608
  %t1617 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1615, ptr %t1617
  %t1618 = load ptr, ptr %l786, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1618, ptr %t1617)
  br label %bb424
bb424:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca { i64, ptr }
  %l29 = alloca i32
  %l32 = alloca i1
  %l36 = alloca { i64, ptr }
  %l40 = alloca i32
  %l54 = alloca i64
  %l57 = alloca i64
  %l78 = alloca { i64, ptr }
  %l81 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a2)
  store { i64, ptr } %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t26, ptr %l25, !tbaa !27
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t27, 1
  %t31 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t34)
  store i32 %t37, ptr %l29
  br label %bb4
bb3:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  %t38 = load i32, ptr %l29
  %t40 = trunc i64 30 to i32
  %t41 = icmp eq i32 %t38, %t40
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t43 = load i1, ptr %l21, !tbaa !21
  br i1 %t43, label %bb6, label %bb7
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l36, !tbaa !27
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = sub i64 %t51, 1
  %t55 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i32, ptr %t56, i64 %t53
  %t58 = load i32, ptr %t57, !tbaa !33
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t49, i32 %t58)
  store i32 %t61, ptr %l40
  br label %bb8
bb7:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb9
bb8:
  %t62 = load i32, ptr %l40, !tbaa !23
  %t63 = icmp eq i32 %t62, 0
  store i1 %t63, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t65 = load i1, ptr %l32, !tbaa !21
  br i1 %t65, label %bb10, label %bb11
bb10:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = sub i64 %t66, 1
  store i64 %t68, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = icmp eq i64 %t70, 0
  br i1 %t72, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t74 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t74, { i64, ptr } { i64 1, ptr @.d43 })
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 4
  %t79 = load i1, ptr %t78, !tbaa !21
  store i1 %t79, ptr %l5, !tbaa !21
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 4
  store i1 true, ptr %t83, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l4, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb17, label %bb18
bb17:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb22
bb19:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l57, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb21
bb21:
  %t112 = load i64, ptr %l57, !tbaa !24
  store i64 %t112, ptr %l54, !tbaa !24
  br label %bb22
bb22:
  %t113 = load i64, ptr %l54, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb25:
  br label %bb26
bb26:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t138, ptr %l78, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i32, ptr %t142, i64 %t139
  %t144 = load i32, ptr %t143, !tbaa !33
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t137, i32 %t144)
  store i32 %t147, ptr %l81
  br label %bb27
bb27:
  %t148 = load i32, ptr %l81
  %t150 = trunc i64 30 to i32
  %t151 = icmp eq i32 %t148, %t150
  br i1 %t151, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l84, !tbaa !29
  %t154 = load i64, ptr %l11, !tbaa !24
  %t156 = icmp sgt i64 %t154, 0
  br i1 %t156, label %bb30, label %bb31
bb29:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t160 = icmp sgt i64 %t158, 0
  br i1 %t160, label %bb34, label %bb35
bb30:
  store { i64, ptr } { i64 3, ptr @.d44 }, ptr %l87, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 2, ptr @.d45 }, ptr %l87, !tbaa !27
  br label %bb32
bb32:
  %t162 = load ptr, ptr %l84, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l87, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t162, { i64, ptr } %t163)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t164 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t164, { i64, ptr } { i64 2, ptr @.d46 })
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t168, ptr %l93, !tbaa !27
  %t169 = load i64, ptr %l11, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i32, ptr %t172, i64 %t169
  %t174 = load i32, ptr %t173, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t166, ptr %t167, i32 %t174, i1 false)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb40:
  %t178 = load i64, ptr %l10, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l10, !tbaa !24
  br label %bb23
bb41:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i1, ptr %l5, !tbaa !21
  %t186 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 4
  store i1 %t183, ptr %t186, !tbaa !21
  %t187 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t187, { i64, ptr } { i64 1, ptr @.d47 })
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estaticArray(ptr %v0, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca ptr
  %l22 = alloca i64
  %l26 = alloca i1
  %l29 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l42 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i1
  %l63 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca i32
  %l73 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i32
  %l87 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca i32
  %l97 = alloca i64
  %l99 = alloca ptr
  %l109 = alloca i64
  %l112 = alloca i64
  %l131 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l135 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca i1
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca i32
  %l164 = alloca ptr
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t171 = alloca { i64, [2 x i64] }, align 8
  %t188 = alloca i64
  %t295 = alloca { i64, [2 x i64] }, align 8
  %t348 = alloca { i64, [2 x i64] }, align 8
  %t356 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l22
  br label %bb1
bb1:
  %t11 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t12 = load i64, ptr %l22, !tbaa !24
  %t14 = and i64 %t12, %t11
  %t16 = icmp ne i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l29, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l34
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l29, !tbaa !29
  %t35 = load i32, ptr %l34, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l35
  br label %bb5
bb5:
  %t37 = load i32, ptr %l35
  %t39 = trunc i64 19 to i32
  %t40 = icmp eq i32 %t37, %t39
  %t42 = xor i1 %t40, true
  store i1 %t42, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  store ptr %t51, ptr %l42, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l47
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l42, !tbaa !29
  %t63 = load i32, ptr %l47, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t64, ptr %l48
  br label %bb11
bb11:
  %t65 = load i32, ptr %l48, !tbaa !23
  store i32 %t65, ptr %l3, !tbaa !23
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t67 = load ptr, ptr %l49, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load ptr, ptr %l49, !tbaa !29
  %t71 = load i64, ptr %t70
  %t73 = icmp eq i64 %t71, 7
  store i1 %t73, ptr %l50, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l50, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 0
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l4
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l5, !tbaa !23
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l6, !tbaa !29
  br label %bb16
bb15:
  br label %bb70
bb16:
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Make", ptr %t93, i32 0, i32 0
  %t96 = load i32, ptr %t95
  %t98 = trunc i64 2 to i32
  %t99 = icmp eq i32 %t96, %t98
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb21
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  store ptr %t108, ptr %l66, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l5, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l71
  br label %bb19
bb19:
  %t119 = load i32, ptr %l3, !tbaa !23
  %t120 = load ptr, ptr %l66, !tbaa !29
  %t121 = load i32, ptr %l71, !tbaa !23
  %t123 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t120, i32 %t121, i32 %t119)
  store i1 %t123, ptr %l73
  br label %bb20
bb20:
  %t124 = load i1, ptr %l73, !tbaa !21
  %t125 = xor i1 %t124, true
  store i1 %t125, ptr %l63, !tbaa !21
  br label %bb21
bb21:
  %t127 = load i1, ptr %l63, !tbaa !21
  br i1 %t127, label %bb22, label %bb23
bb22:
  store ptr null, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l3, !tbaa !23
  %t133 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t129, i32 %t130)
  store i1 %t133, ptr %l78
  br label %bb25
bb25:
  %t134 = load i1, ptr %l78, !tbaa !21
  br i1 %t134, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb28
bb27:
  %t135 = load i32, ptr %l3, !tbaa !23
  %t136 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t139 = icmp eq i32 %t135, %t136
  store i1 %t139, ptr %l79, !tbaa !21
  br label %bb28
bb28:
  %t141 = load i1, ptr %l79, !tbaa !21
  br i1 %t141, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb33
bb30:
  %t142 = load i32, ptr %l3, !tbaa !23
  store i32 %t142, ptr %l84, !tbaa !23
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  store ptr %t148, ptr %l87, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t149)
  store i32 %t151, ptr %l89
  br label %bb31
bb31:
  %t152 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t153 = load ptr, ptr %l87, !tbaa !29
  %t154 = load i32, ptr %l89, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t153, i32 %t154, i64 %t152)
  store i32 %t156, ptr %l91
  br label %bb32
bb32:
  %t157 = load i32, ptr %l84, !tbaa !23
  %t158 = load i32, ptr %l91, !tbaa !23
  %t159 = icmp eq i32 %t157, %t158
  store i1 %t159, ptr %l83, !tbaa !21
  br label %bb33
bb33:
  %t161 = load i1, ptr %l83, !tbaa !21
  %t162 = xor i1 %t161, true
  br i1 %t162, label %bb34, label %bb35
bb34:
  store ptr null, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t165 = load ptr, ptr %l6, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Make", ptr %t165, i32 0, i32 2
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l97, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [2 x i64] }, ptr %t171, i32 0, i32 0
  store i64 0, ptr %t172
  %t173 = insertvalue { i64 } undef, i64 0, 0
  %t174 = getelementptr { i64, [2 x i64] }, ptr %t171, i32 0, i32 1
  store { i64 } %t173, ptr %t174
  %t175 = load { i64, [2 x i64] }, ptr %t171
  %t177 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t175, ptr %t177
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load i64, ptr %l97, !tbaa !24
  %t179 = icmp sge i64 %t178, 0
  br i1 %t179, label %bb37, label %bb38
bb37:
  %t181 = load i64, ptr %l97, !tbaa !24
  %t182 = icmp sle i64 %t181, 1152921504606846975
  br i1 %t182, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3727962a9e2e15db_7cf774666c9d4227)
  unreachable
bb39:
  %t184 = load i64, ptr %l97, !tbaa !24
  %t185 = mul i64 %t184, 8
  %t186 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t185)
  %t187 = load ptr, ptr %l99, !tbaa !29
  store i64 0, ptr %t188
  br label %fill.189
fill.189:
  %t192 = load i64, ptr %t188
  %t193 = icmp slt i64 %t192, %t184
  br i1 %t193, label %fillb.190, label %filld.191
fillb.190:
  %t194 = getelementptr ptr, ptr %t186, i64 %t192
  store ptr %t187, ptr %t194
  %t195 = add i64 %t192, 1
  store i64 %t195, ptr %t188
  br label %fill.189
filld.191:
  %t196 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t186, 1
  %t198 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t198, ptr %lp7
  %t200 = load ptr, ptr %lp7
  store { i64, ptr } %t197, ptr %t200, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Make", ptr %t201, i32 0, i32 2
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 0
  store i64 %t206, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t208 = load i64, ptr %l9, !tbaa !24
  %t209 = load i64, ptr %l8, !tbaa !24
  %t212 = icmp sgt i64 %t208, %t209
  br i1 %t212, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_3727962a9e2e15db_7cf774666c9d4227)
  unreachable
bb41:
  %t214 = load i64, ptr %l10, !tbaa !24
  %t216 = icmp sgt i64 %t214, 0
  br i1 %t216, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb46
bb43:
  %t218 = load i64, ptr %l9, !tbaa !24
  %t219 = load i64, ptr %l8, !tbaa !24
  %t222 = sub i64 %t218, %t219
  %t223 = load i64, ptr %l10, !tbaa !24
  %t226 = add i64 %t222, %t223
  %t228 = sub i64 %t226, 1
  %t229 = load i64, ptr %l10, !tbaa !24
  %t232 = sdiv i64 %t228, %t229
  store i64 %t232, ptr %l112, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb45
bb45:
  %t234 = load i64, ptr %l112, !tbaa !24
  store i64 %t234, ptr %l109, !tbaa !24
  br label %bb46
bb46:
  %t235 = load i64, ptr %l109, !tbaa !24
  store i64 %t235, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s6
  %t236 = load i64, ptr %l12, !tbaa !24
  %t237 = load i64, ptr %l11, !tbaa !24
  %t240 = icmp slt i64 %t236, %t237
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb68
bb49:
  br label %bb50
bb50:
  %t244 = load i64, ptr %l8, !tbaa !24
  %t245 = load i64, ptr %l12, !tbaa !24
  %t246 = load i64, ptr %l10, !tbaa !24
  %t249 = mul i64 %t245, %t246
  %t252 = add i64 %t244, %t249
  store i64 %t252, ptr %l13, !tbaa !24
  %t254 = load ptr, ptr %l6, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Make", ptr %t254, i32 0, i32 2
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  store { i64, ptr } %t257, ptr %l131, !tbaa !27
  %t258 = load i64, ptr %l13, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr ptr, ptr %t261, i64 %t258
  %t263 = load ptr, ptr %t262, !tbaa !39
  store ptr %t263, ptr %l14, !tbaa !29
  %t265 = load ptr, ptr %l14, !tbaa !29
  store ptr %t265, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t266 = load ptr, ptr %l134, !tbaa !29
  %t267 = icmp ne ptr %t266, null
  br i1 %t267, label %bb51, label %bb52
bb51:
  %t269 = load ptr, ptr %l134, !tbaa !29
  %t270 = load i64, ptr %t269
  %t272 = icmp eq i64 %t270, 0
  store i1 %t272, ptr %l135, !tbaa !21
  br label %bb52
bb52:
  %t273 = load i1, ptr %l135, !tbaa !21
  br i1 %t273, label %bb53, label %bb54
bb53:
  %t274 = load ptr, ptr %l14, !tbaa !29
  %t276 = getelementptr { i64, [5 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t276, i32 0, i32 1
  %t278 = load i32, ptr %t277
  store i32 %t278, ptr %l15, !tbaa !23
  %t280 = load ptr, ptr %l14, !tbaa !29
  %t282 = getelementptr { i64, [5 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t282, i32 0, i32 2
  %t284 = load i64, ptr %t283
  store i64 %t284, ptr %l16, !tbaa !24
  br label %bb55
bb54:
  br label %bb59
bb55:
  %t286 = load i32, ptr %l15, !tbaa !23
  %t287 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t290 = icmp eq i32 %t286, %t287
  br i1 %t290, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s6)
  store ptr null, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t293 = load i64, ptr %l13, !tbaa !24
  %t294 = load i64, ptr %l16, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t295
  %t296 = getelementptr { i64, [2 x i64] }, ptr %t295, i32 0, i32 0
  store i64 0, ptr %t296
  %t298 = insertvalue { i64 } undef, i64 %t294, 0
  %t299 = getelementptr { i64, [2 x i64] }, ptr %t295, i32 0, i32 1
  store { i64 } %t298, ptr %t299
  %t300 = load { i64, [2 x i64] }, ptr %t295
  %t302 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t300, ptr %t302
  %t304 = load ptr, ptr %lp7
  %t306 = getelementptr { i64, ptr }, ptr %t304, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr ptr, ptr %t307, i64 %t293
  store ptr %t302, ptr %t308, !tbaa !39
  br label %bb66
bb59:
  %t309 = load ptr, ptr %l14, !tbaa !29
  store ptr %t309, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t310 = load ptr, ptr %l150, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb60, label %bb61
bb60:
  %t313 = load ptr, ptr %l150, !tbaa !29
  %t314 = load i64, ptr %t313
  %t316 = icmp eq i64 %t314, 1
  store i1 %t316, ptr %l151, !tbaa !21
  br label %bb61
bb61:
  %t317 = load i1, ptr %l151, !tbaa !21
  br i1 %t317, label %bb62, label %bb63
bb62:
  %t318 = load ptr, ptr %l14, !tbaa !29
  %t320 = getelementptr { i64, [5 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t320, i32 0, i32 3
  %t322 = load ptr, ptr %t321
  store ptr %t322, ptr %l17, !tbaa !29
  br label %bb64
bb63:
  br label %bb65
bb64:
  %t324 = load i64, ptr %l13, !tbaa !24
  %t325 = load ptr, ptr %l17, !tbaa !29
  %t327 = load ptr, ptr %lp7
  %t329 = getelementptr { i64, ptr }, ptr %t327, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = getelementptr ptr, ptr %t330, i64 %t324
  store ptr %t325, ptr %t331, !tbaa !39
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s6)
  store ptr null, ptr %rv
  br label %ret
bb66:
  call void @__olang_scope_close(ptr %s6)
  br label %bb67
bb67:
  %t333 = load i64, ptr %l12, !tbaa !24
  %t335 = add i64 %t333, 1
  store i64 %t335, ptr %l12, !tbaa !24
  br label %bb47
bb68:
  %t337 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t337, ptr %l161
  %t338 = load i32, ptr %l2, !tbaa !23
  store i32 %t338, ptr %l162, !tbaa !23
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t339)
  store ptr %t341, ptr %l164
  br label %bb69
bb69:
  %t342 = load ptr, ptr %l164, !tbaa !29
  %t344 = getelementptr %"compiler/check:frame", ptr %t342, i32 0, i32 2
  %t345 = load i64, ptr %t344, !tbaa !24
  %t346 = load ptr, ptr %lp7
  %t347 = load { i64, ptr }, ptr %t346, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t348
  %t349 = getelementptr { i64, [2 x i64] }, ptr %t348, i32 0, i32 0
  store i64 2, ptr %t349
  %t351 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t347, 0
  %t352 = getelementptr { i64, [2 x i64] }, ptr %t348, i32 0, i32 1
  store { { i64, ptr } } %t351, ptr %t352
  %t353 = load { i64, [2 x i64] }, ptr %t348
  %t355 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t353, ptr %t355
  store { i64, [5 x i64] } zeroinitializer, ptr %t356
  %t357 = getelementptr { i64, [5 x i64] }, ptr %t356, i32 0, i32 0
  store i64 1, ptr %t357
  %t358 = load %"compiler/source:Span", ptr %l161
  %t359 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t358, 0
  %t360 = load i32, ptr %l162, !tbaa !23
  %t361 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t359, i32 %t360, 1
  %t363 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t361, i64 %t345, 2
  %t365 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t363, ptr %t355, 3
  %t366 = getelementptr { i64, [5 x i64] }, ptr %t356, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t365, ptr %t366
  %t367 = load { i64, [5 x i64] }, ptr %t356
  %t369 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t367, ptr %t369
  store ptr %t369, ptr %rv
  br label %ret
bb70:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrReceivers(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l57 = alloca i1
  %l62 = alloca ptr
  %l71 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l83 = alloca i1
  %l85 = alloca i1
  %l87 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l100 = alloca i64
  %l106 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i32
  %l138 = alloca i64
  %l148 = alloca ptr
  %l154 = alloca ptr
  %l162 = alloca { i64, [3 x i64] }
  %l163 = alloca %"compiler/msgs:Msg"
  %l164 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t306 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 11
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load i64, ptr %l22, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l29, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l29, !tbaa !24
  store i64 %t35, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l26, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb72
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 16
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l50
  br label %bb13
bb13:
  %t62 = load i64, ptr %l50, !tbaa !24
  %t63 = icmp ne i64 %t62, 2
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb18
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 58
  store ptr %t67, ptr %l54, !tbaa !29
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t68, i64 0)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t70, ptr %l56
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l54, !tbaa !29
  %t72 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  %t73 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t71, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72)
  store i1 %t73, ptr %l57
  br label %bb17
bb17:
  %t74 = load i1, ptr %l57, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l52, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l52, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb20:
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 11
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t80, i64 %t81)
  store ptr %t84, ptr %l62
  br label %bb22
bb22:
  %t85 = load ptr, ptr %l62, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 1
  %t88 = load { i64, [2 x i64] }, ptr %t87
  store { i64, [2 x i64] } %t88, ptr %l8
  %t90 = load { i64, [2 x i64] }, ptr %l8
  %t92 = extractvalue { i64, [2 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 0
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t96 = getelementptr { i64 }, ptr %t95, i32 0, i32 0
  %t97 = load i64, ptr %t96
  store i64 %t97, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  br label %bb69
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t106, ptr %l71
  br label %bb26
bb26:
  %t107 = load i64, ptr %l71, !tbaa !24
  store i64 %t107, ptr %l10, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t111, i64 %t112)
  store ptr %t115, ptr %l75
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l75, !tbaa !29
  store ptr %t116, ptr %l11, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l11, !tbaa !29
  %t120 = getelementptr %"compiler/ast:Func", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t117, i32 %t121)
  store { i64, ptr } %t124, ptr %l79
  br label %bb28
bb28:
  %t125 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t125, ptr %l12, !tbaa !27
  %t126 = load ptr, ptr %l11, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Func", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  br i1 %t131, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb36
bb30:
  %t133 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t133, { i64, ptr } { i64 3, ptr @.d48 })
  store i1 %t135, ptr %l85
  br label %bb31
bb31:
  %t136 = load i1, ptr %l85, !tbaa !21
  %t137 = xor i1 %t136, true
  br i1 %t137, label %bb32, label %bb33
bb32:
  %t139 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t139, { i64, ptr } { i64 3, ptr @.d49 })
  store i1 %t141, ptr %l89
  br label %bb34
bb33:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb35
bb34:
  %t142 = load i1, ptr %l89, !tbaa !21
  %t143 = xor i1 %t142, true
  store i1 %t143, ptr %l87, !tbaa !21
  br label %bb35
bb35:
  %t145 = load i1, ptr %l87, !tbaa !21
  store i1 %t145, ptr %l83, !tbaa !21
  br label %bb36
bb36:
  %t146 = load i1, ptr %l83, !tbaa !21
  br i1 %t146, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb40
bb38:
  %t147 = load i64, ptr %l10, !tbaa !24
  %t150 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t147)
  store i1 %t150, ptr %l94
  br label %bb39
bb39:
  %t151 = load i1, ptr %l94, !tbaa !21
  store i1 %t151, ptr %l91, !tbaa !21
  br label %bb40
bb40:
  %t152 = load i1, ptr %l91, !tbaa !21
  br i1 %t152, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb42:
  br label %bb43
bb43:
  %t153 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t153, i1 true)
  br label %bb44
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i64, ptr %l10, !tbaa !24
  %t163 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t159, i64 %t160)
  store i64 %t163, ptr %l100
  br label %bb45
bb45:
  %t164 = load i64, ptr %l100, !tbaa !24
  store i64 %t164, ptr %l13, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/load:Loader", ptr %t171, i32 0, i32 5
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t173, i64 %t174)
  store ptr %t177, ptr %l106
  br label %bb46
bb46:
  %t178 = load ptr, ptr %l106, !tbaa !29
  %t180 = getelementptr %"compiler/load:Module", ptr %t178, i32 0, i32 6
  %t181 = load ptr, ptr %t180, !tbaa !29
  store ptr %t181, ptr %l14, !tbaa !29
  %t183 = load ptr, ptr %l14, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_7cf0066f219391e3_f59e2f38f1229917)
  unreachable
bb48:
  br label %bb49
bb49:
  %t187 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr %"compiler/source:Source", ptr %t187, i32 0, i32 1
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l15, !tbaa !27
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t195 = getelementptr %"compiler/ast:Func", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  br i1 %t198, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_93e3a02800d00d4_2c47855b6b12ccf8)
  unreachable
bb51:
  br label %bb52
bb52:
  %t200 = load ptr, ptr %l11, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Func", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Param", ptr %t203, i32 0, i32 0
  %t207 = getelementptr %"compiler/source:Span", ptr %t206, i32 0, i32 1
  %t208 = load i32, ptr %t207, !tbaa !23
  %t210 = sext i32 %t208 to i64
  store i64 %t210, ptr %l16, !tbaa !24
  %t212 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t212, ptr %l123, !tbaa !27
  %t213 = load i64, ptr %l16, !tbaa !24
  store i64 %t213, ptr %l124, !tbaa !24
  %t214 = load ptr, ptr %l11, !tbaa !29
  %t216 = getelementptr %"compiler/ast:Func", ptr %t214, i32 0, i32 0
  %t217 = getelementptr %"compiler/source:Span", ptr %t216, i32 0, i32 1
  %t218 = load i32, ptr %t217, !tbaa !23
  %t220 = sext i32 %t218 to i64
  store i64 %t220, ptr %l127, !tbaa !24
  %t221 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l128, !tbaa !24
  %t223 = load i64, ptr %l124, !tbaa !24
  %t224 = icmp sge i64 %t223, 0
  br i1 %t224, label %bb53, label %bb54
bb53:
  %t226 = load i64, ptr %l124, !tbaa !24
  %t227 = load i64, ptr %l127, !tbaa !24
  %t228 = icmp sle i64 %t226, %t227
  br i1 %t228, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb55:
  %t230 = load i64, ptr %l127, !tbaa !24
  %t231 = load i64, ptr %l128, !tbaa !24
  %t232 = icmp sle i64 %t230, %t231
  br i1 %t232, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb57:
  %t234 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l124, !tbaa !24
  %t237 = load i64, ptr %l127, !tbaa !24
  %t238 = getelementptr i8, ptr %t235, i64 %t236
  %t239 = sub i64 %t237, %t236
  %t240 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t238, 1
  %t242 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t245 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t241, { i64, ptr } %t242)
  %t246 = extractvalue { i32, i64 } %t245, 1
  %t247 = extractvalue { i32, i64 } %t245, 0
  store i32 %t247, ptr %l135
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb60, label %ok.249
ok.249:
  store i64 %t246, ptr %l134
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb59:
  %t250 = load i64, ptr %l134, !tbaa !24
  store i64 %t250, ptr %l122, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l122, !tbaa !24
  br label %bb62
bb62:
  %t251 = load i64, ptr %l122, !tbaa !24
  store i64 %t251, ptr %l17, !tbaa !24
  %t252 = load i64, ptr %l17, !tbaa !24
  %t254 = icmp slt i64 %t252, 0
  br i1 %t254, label %bb63, label %bb64
bb63:
  %t256 = load ptr, ptr %l11, !tbaa !29
  %t258 = getelementptr %"compiler/ast:Func", ptr %t256, i32 0, i32 0
  %t259 = getelementptr %"compiler/source:Span", ptr %t258, i32 0, i32 0
  %t260 = load i32, ptr %t259, !tbaa !23
  %t262 = sext i32 %t260 to i64
  store i64 %t262, ptr %l138, !tbaa !24
  br label %bb65
bb64:
  %t264 = load i64, ptr %l16, !tbaa !24
  %t265 = load i64, ptr %l17, !tbaa !24
  %t268 = add i64 %t264, %t265
  store i64 %t268, ptr %l138, !tbaa !24
  br label %bb65
bb65:
  %t270 = load i64, ptr %l138, !tbaa !24
  store i64 %t270, ptr %l18, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/check:Checker", ptr %t271, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = getelementptr %"compiler/generic:Program", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/load:Loader", ptr %t277, i32 0, i32 4
  %t280 = load ptr, ptr %t279, !tbaa !29
  store ptr %t280, ptr %l148, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Program", ptr %t284, i32 0, i32 0
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = getelementptr %"compiler/load:Loader", ptr %t287, i32 0, i32 5
  %t290 = load i64, ptr %l13, !tbaa !24
  %t293 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t289, i64 %t290)
  store ptr %t293, ptr %l154
  br label %bb66
bb66:
  %t294 = load ptr, ptr %l154, !tbaa !29
  %t296 = getelementptr %"compiler/load:Module", ptr %t294, i32 0, i32 4
  %t297 = load i64, ptr %t296, !tbaa !24
  %t298 = load i64, ptr %l18, !tbaa !24
  %t299 = load i64, ptr %l18, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t305 = add i64 %t299, %t302
  store { i64, [3 x i64] } zeroinitializer, ptr %t306
  %t307 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 0
  store i64 3, ptr %t307
  %t309 = insertvalue { i64, i64, i64 } undef, i64 %t297, 0
  %t311 = insertvalue { i64, i64, i64 } %t309, i64 %t298, 1
  %t313 = insertvalue { i64, i64, i64 } %t311, i64 %t305, 2
  %t314 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 1
  store { i64, i64, i64 } %t313, ptr %t314
  %t315 = load { i64, [3 x i64] }, ptr %t306
  store { i64, [3 x i64] } %t315, ptr %l162
  %t316 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %s4)
  store %"compiler/msgs:Msg" %t316, ptr %l163
  br label %bb67
bb67:
  %t317 = load ptr, ptr %l148, !tbaa !29
  %t318 = load { i64, [3 x i64] }, ptr %l162
  %t319 = load %"compiler/msgs:Msg", ptr %l163
  %t320 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t317, { i64, [3 x i64] } %t318, %"compiler/msgs:Msg" %t319)
  store i64 %t320, ptr %l164
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s4)
  br label %bb70
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb71:
  %t321 = load i64, ptr %l6, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l6, !tbaa !24
  br label %bb9
bb72:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca %"compiler/names:Ref"
  %l27 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/load:Loader", ptr %t29, i32 0, i32 5
  %t35 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t31, i64 %a1)
  store ptr %t35, ptr %l19
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 4
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load ptr, ptr %l13, !tbaa !29
  %t45 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t42, i64 %t39, i32 %t41)
  store %"compiler/names:Ref" %t45, ptr %l23
  br label %bb7
bb7:
  %t46 = load %"compiler/names:Ref", ptr %l23
  store %"compiler/names:Ref" %t46, ptr %l4
  %t47 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t48 = load i32, ptr %t47
  %t50 = trunc i64 4 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  %t55 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  %t58 = icmp slt i64 %t56, 0
  store i1 %t58, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t60 = load i1, ptr %l27, !tbaa !21
  br i1 %t60, label %bb11, label %bb12
bb11:
  %t61 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t62 = load i32, ptr %t61
  %t64 = trunc i64 7 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  store ptr %t74, ptr %l35, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t82 = load i64, ptr %t81, !tbaa !24
  %t86 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t78, i64 %t80, i64 %t82)
  store i32 %t86, ptr %l40
  br label %bb14
bb14:
  %t87 = load ptr, ptr %l35, !tbaa !29
  %t88 = load i32, ptr %l40, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t89, ptr %l41
  br label %bb15
bb15:
  %t90 = load i32, ptr %l41
  %t92 = trunc i64 3 to i32
  %t93 = icmp eq i32 %t90, %t92
  store i1 %t93, ptr %rv
  br label %ret
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitWritten(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca ptr
  %l7 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca %"compiler/names:Ref"
  %l26 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l37 = alloca %"compiler/names:Ref"
  %l41 = alloca i1
  %l47 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l65 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb31
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l16, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l22
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l22
  store %"compiler/names:Ref" %t42, ptr %l5
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = icmp sgt i64 %t45, 1
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t50 = load i32, ptr %t49
  %t52 = trunc i64 0 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l26, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l31, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t63)
  store ptr %t65, ptr %l33
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t66 = load ptr, ptr %l33, !tbaa !29
  %t68 = getelementptr %"compiler/check:frame", ptr %t66, i32 0, i32 2
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t75 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t72, i64 %t69, i32 %t71)
  store %"compiler/names:Ref" %t75, ptr %l37
  br label %bb14
bb14:
  %t76 = load %"compiler/names:Ref", ptr %l37
  store %"compiler/names:Ref" %t76, ptr %l5
  br label %bb15
bb15:
  %t77 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t78 = load i32, ptr %t77
  %t80 = trunc i64 4 to i32
  %t81 = icmp eq i32 %t78, %t80
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb18
bb17:
  %t85 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 2
  %t86 = load i64, ptr %t85, !tbaa !24
  %t88 = icmp slt i64 %t86, 0
  store i1 %t88, ptr %l41, !tbaa !21
  br label %bb18
bb18:
  %t90 = load i1, ptr %l41, !tbaa !21
  br i1 %t90, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  store ptr %t97, ptr %l47, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 2
  %t105 = load i64, ptr %t104, !tbaa !24
  %t109 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t101, i64 %t103, i64 %t105)
  store i32 %t109, ptr %l52
  br label %bb22
bb22:
  %t110 = load ptr, ptr %l47, !tbaa !29
  %t111 = load i32, ptr %l52, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t112, ptr %l53
  br label %bb23
bb23:
  %t113 = load i32, ptr %l53
  %t115 = trunc i64 3 to i32
  %t116 = icmp eq i32 %t113, %t115
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l58, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t122, ptr %l59
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l60, !tbaa !29
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %a2)
  store %"compiler/source:Span" %t126, ptr %l62
  br label %bb27
bb27:
  %t127 = load ptr, ptr %l60, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l62
  %t129 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t127, %"compiler/source:Span" %t128)
  store { i64, ptr } %t129, ptr %l63
  br label %bb28
bb28:
  %t130 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t131 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitNotAType(ptr %v0, ptr %s1, { i64, ptr } %t130)
  store %"compiler/msgs:Msg" %t131, ptr %l64
  br label %bb29
bb29:
  %t132 = load ptr, ptr %l58, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l59
  %t134 = load %"compiler/msgs:Msg", ptr %l64
  %t135 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t132, %"compiler/source:Span" %t133, %"compiler/msgs:Msg" %t134)
  store i64 %t135, ptr %l65
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb31:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOrNull(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 4, ptr @.d50 }, ptr %l6, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  br label %bb4
bb2:
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %t10)
  store { i64, ptr } %t13, ptr %l10
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l5, !tbaa !27
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = mul i64 %t26, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l42 = alloca i32
  %l45 = alloca ptr
  %l50 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca i32
  %l74 = alloca i32
  %l75 = alloca i64
  %l86 = alloca i1
  %l95 = alloca i1
  %l99 = alloca i32
  %l104 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l161 = alloca i32
  %l167 = alloca ptr
  %l172 = alloca i32
  %l182 = alloca ptr
  %l187 = alloca i32
  %l188 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s24 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l25, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l25, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l1, !tbaa !23
  %t14 = icmp eq i32 %t12, 0
  store i1 %t14, ptr %l29, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l29, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb10
bb8:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v1, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l35
  br label %bb9
bb9:
  %t22 = load i1, ptr %l35, !tbaa !21
  store i1 %t22, ptr %l32, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l32, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v1, ptr %t24, i32 %t25, i1 true)
  br label %bb14
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l42
  br label %bb15
bb15:
  %t38 = load i32, ptr %l42
  store i32 %t38, ptr %l4
  %t39 = load i32, ptr %l4
  %t41 = trunc i64 20 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l45, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l50
  br label %bb19
bb19:
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t56, 1
  %t59 = load ptr, ptr %l45, !tbaa !29
  %t60 = load i32, ptr %l50, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t59, i32 %t60, ptr %t55, i64 %t58)
  br label %bb20
bb20:
  br label %bb97
bb21:
  %t63 = load i32, ptr %l4
  %t65 = trunc i64 18 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb75
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t68 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d51 }, 0
  %t69 = insertvalue [2 x { i64, ptr }] %t68, { i64, ptr } { i64 3, ptr @.d52 }, 1
  %t71 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store [2 x { i64, ptr }] %t69, ptr %t71
  store ptr %t71, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t73 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t76 = load i64, ptr %l6, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t84 = load ptr, ptr %l5
  %t85 = load i64, ptr %l6, !tbaa !24
  %t88 = getelementptr [2 x { i64, ptr }], ptr %t84, i64 0, i64 %t85
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !37
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l68, !tbaa !29
  %t95 = load i32, ptr %l1, !tbaa !23
  store i32 %t95, ptr %l69, !tbaa !23
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = getelementptr %"compiler/types:Table", ptr %t101, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = load ptr, ptr @__olang_prog_scope
  %t108 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %t105, ptr %t103, { i64, ptr } %t89)
  store i32 %t108, ptr %l74
  br label %bb29
bb29:
  %t109 = load ptr, ptr %l68, !tbaa !29
  %t110 = load i32, ptr %l69, !tbaa !23
  %t111 = load i32, ptr %l74, !tbaa !23
  %t112 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t109, i32 %t110, i32 %t111)
  store i64 %t112, ptr %l75
  br label %bb30
bb30:
  %t113 = load i64, ptr %l75, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t116 = icmp sge i64 %t114, 0
  br i1 %t116, label %bb31, label %bb32
bb31:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 39
  %t121 = getelementptr %"compiler/source:Span", ptr %t120, i32 0, i32 0
  %t122 = load i32, ptr %t121, !tbaa !23
  %t124 = icmp sge i32 %t122, 0
  br i1 %t124, label %bb33, label %bb34
bb32:
  br label %bb38
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i64, ptr %l9, !tbaa !24
  %t128 = load i32, ptr %l1, !tbaa !23
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 39
  %t132 = load %"compiler/source:Span", ptr %t131
  %t137 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %s7, ptr %s7, ptr %t126, i64 %t127, i32 %t128, { i64, ptr } { i64 3, ptr @.d53 }, %"compiler/source:Span" %t132, { i64, ptr } { i64 3, ptr @.d54 })
  store i1 %t137, ptr %l86
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l9, !tbaa !24
  %t140 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrInstance(ptr %v0, ptr %t138, i64 %t139, i32 %t140)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t144 = load i64, ptr %l6, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l6, !tbaa !24
  br label %bb25
bb40:
  call void @__olang_scope_close(ptr %s4)
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t152 = load i32, ptr %l1, !tbaa !23
  %t155 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t151, i32 %t152)
  store i1 %t155, ptr %l95
  br label %bb41
bb41:
  %t156 = load i1, ptr %l95, !tbaa !21
  %t157 = xor i1 %t156, true
  br i1 %t157, label %bb42, label %bb43
bb42:
  br label %ret
bb43:
  br label %bb44
bb44:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l1, !tbaa !23
  %t163 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t159, i32 %t160)
  store i32 %t163, ptr %l99
  br label %bb45
bb45:
  %t164 = load i32, ptr %l99
  store i32 %t164, ptr %l10
  %t165 = load i32, ptr %l10
  %t167 = trunc i64 0 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb46, label %bb47
bb46:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  store ptr %t175, ptr %l104, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/generic:Program", ptr %t179, i32 0, i32 2
  %t182 = load i32, ptr %l1, !tbaa !23
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t181, i32 %t182)
  store i32 %t185, ptr %l109
  br label %bb48
bb47:
  %t186 = load i32, ptr %l10
  %t188 = trunc i64 1 to i32
  %t189 = icmp eq i32 %t186, %t188
  br i1 %t189, label %bb57, label %bb58
bb48:
  %t191 = load ptr, ptr %l104, !tbaa !29
  %t192 = load i32, ptr %l109, !tbaa !23
  %t193 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t191, i32 %t192)
  store { i64, ptr } %t193, ptr %l110
  br label %bb49
bb49:
  %t194 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t194, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 0
  store i64 %t197, ptr %l13, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  %t199 = load i64, ptr %l12, !tbaa !24
  %t200 = load i64, ptr %l13, !tbaa !24
  %t203 = icmp slt i64 %t199, %t200
  %t205 = xor i1 %t203, true
  br i1 %t205, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s12)
  br label %bb56
bb52:
  br label %bb53
bb53:
  %t207 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t207, ptr %l117, !tbaa !27
  %t208 = load i64, ptr %l12, !tbaa !24
  %t210 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr i32, ptr %t211, i64 %t208
  %t213 = load i32, ptr %t212, !tbaa !33
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t218 = load i64, ptr %l3, !tbaa !24
  %t220 = add i64 %t218, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t215, i32 %t213, ptr %t217, i64 %t220)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s12)
  br label %bb55
bb55:
  %t225 = load i64, ptr %l12, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l12, !tbaa !24
  br label %bb50
bb56:
  br label %bb74
bb57:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/check:Checker", ptr %t229, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t234 = getelementptr %"compiler/generic:Program", ptr %t232, i32 0, i32 2
  store ptr %t234, ptr %l131, !tbaa !29
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/generic:Program", ptr %t238, i32 0, i32 2
  %t241 = load i32, ptr %l1, !tbaa !23
  %t244 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t240, i32 %t241)
  store i32 %t244, ptr %l136
  br label %bb59
bb58:
  %t245 = load i32, ptr %l10
  %t247 = trunc i64 4 to i32
  %t248 = icmp eq i32 %t245, %t247
  br i1 %t248, label %bb68, label %bb69
bb59:
  %t250 = load ptr, ptr %l131, !tbaa !29
  %t251 = load i32, ptr %l136, !tbaa !23
  %t252 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t250, i32 %t251)
  store { i64, ptr } %t252, ptr %l137
  br label %bb60
bb60:
  %t253 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t253, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t254 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t254, 0
  store i64 %t256, ptr %l17, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s17
  %t258 = load i64, ptr %l16, !tbaa !24
  %t259 = load i64, ptr %l17, !tbaa !24
  %t262 = icmp slt i64 %t258, %t259
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s17)
  br label %bb67
bb63:
  br label %bb64
bb64:
  %t266 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t266, ptr %l144, !tbaa !27
  %t267 = load i64, ptr %l16, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i32, ptr %t270, i64 %t267
  %t272 = load i32, ptr %t271, !tbaa !33
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = load ptr, ptr %l2, !tbaa !29
  %t277 = load i64, ptr %l3, !tbaa !24
  %t279 = add i64 %t277, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t274, i32 %t272, ptr %t276, i64 %t279)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s17)
  br label %bb66
bb66:
  %t284 = load i64, ptr %l16, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l16, !tbaa !24
  br label %bb61
bb67:
  br label %bb73
bb68:
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l156, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/check:Checker", ptr %t289, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = getelementptr %"compiler/generic:Program", ptr %t292, i32 0, i32 2
  %t295 = load i32, ptr %l1, !tbaa !23
  %t298 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t294, i32 %t295)
  store i32 %t298, ptr %l161
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t299 = load ptr, ptr %l2, !tbaa !29
  %t300 = load i64, ptr %l3, !tbaa !24
  %t302 = add i64 %t300, 1
  %t303 = load ptr, ptr %l156, !tbaa !29
  %t304 = load i32, ptr %l161, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t303, i32 %t304, ptr %t299, i64 %t302)
  br label %bb71
bb71:
  br label %bb72
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  br label %bb97
bb75:
  %t307 = load i32, ptr %l4
  %t309 = trunc i64 19 to i32
  %t310 = icmp eq i32 %t307, %t309
  br i1 %t310, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb81
bb78:
  %t312 = load ptr, ptr %l0, !tbaa !29
  store ptr %t312, ptr %l167, !tbaa !29
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/check:Checker", ptr %t313, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t318 = getelementptr %"compiler/generic:Program", ptr %t316, i32 0, i32 2
  %t319 = load i32, ptr %l1, !tbaa !23
  %t322 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t318, i32 %t319)
  store i32 %t322, ptr %l172
  br label %bb79
bb79:
  %t323 = load ptr, ptr %l2, !tbaa !29
  %t324 = load i64, ptr %l3, !tbaa !24
  %t326 = add i64 %t324, 1
  %t327 = load ptr, ptr %l167, !tbaa !29
  %t328 = load i32, ptr %l172, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t327, i32 %t328, ptr %t323, i64 %t326)
  br label %bb80
bb80:
  br label %bb97
bb81:
  %t331 = load i32, ptr %l4
  %t333 = trunc i64 22 to i32
  %t334 = icmp eq i32 %t331, %t333
  br i1 %t334, label %bb82, label %bb83
bb82:
  br label %bb86
bb83:
  %t336 = load i32, ptr %l4
  %t338 = trunc i64 23 to i32
  %t339 = icmp eq i32 %t336, %t338
  br i1 %t339, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb96
bb86:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = getelementptr %"compiler/generic:Program", ptr %t344, i32 0, i32 2
  store ptr %t346, ptr %l182, !tbaa !29
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/check:Checker", ptr %t347, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !29
  %t352 = getelementptr %"compiler/generic:Program", ptr %t350, i32 0, i32 2
  %t353 = load i32, ptr %l1, !tbaa !23
  %t356 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t352, i32 %t353)
  store i32 %t356, ptr %l187
  br label %bb87
bb87:
  %t357 = load ptr, ptr %l182, !tbaa !29
  %t358 = load i32, ptr %l187, !tbaa !23
  %t359 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t357, i32 %t358)
  store { i64, ptr } %t359, ptr %l188
  br label %bb88
bb88:
  %t360 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t360, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t361 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t361, 0
  store i64 %t363, ptr %l21, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s24
  %t365 = load i64, ptr %l20, !tbaa !24
  %t366 = load i64, ptr %l21, !tbaa !24
  %t369 = icmp slt i64 %t365, %t366
  %t371 = xor i1 %t369, true
  br i1 %t371, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s24)
  br label %bb95
bb91:
  br label %bb92
bb92:
  %t373 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t373, ptr %l195, !tbaa !27
  %t374 = load i64, ptr %l20, !tbaa !24
  %t376 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr i32, ptr %t377, i64 %t374
  %t379 = load i32, ptr %t378, !tbaa !33
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = load ptr, ptr %l2, !tbaa !29
  %t384 = load i64, ptr %l3, !tbaa !24
  %t386 = add i64 %t384, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t381, i32 %t379, ptr %t383, i64 %t386)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s24)
  br label %bb94
bb94:
  %t391 = load i64, ptr %l20, !tbaa !24
  %t393 = add i64 %t391, 1
  store i64 %t393, ptr %l20, !tbaa !24
  br label %bb89
bb95:
  br label %bb97
bb96:
  br label %bb97
bb97:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l6 = alloca i1
  %l15 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/ast:If", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_cc3b6ed7ca85eab5_875d9ef7a16c4e59)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:If", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Branch", ptr %t20, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t24, { i64, ptr } %t25)
  store i1 %t28, ptr %l15
  br label %bb6
bb6:
  %t29 = load i1, ptr %l15, !tbaa !21
  store i1 %t29, ptr %l6, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l6, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/ast:If", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t35, { i64, ptr } %t36)
  store i1 %t39, ptr %l20
  br label %bb11
bb11:
  %t40 = load i1, ptr %l20, !tbaa !21
  store i1 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i64
  %l30 = alloca i1
  %l32 = alloca i64
  %l41 = alloca i64
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb4:
  br label %bb23
bb5:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp eq i64 %t16, 64
  store i1 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 5
  %t21 = load i1, ptr %t20, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp eq i64 %t23, 64
  br i1 %t25, label %bb10, label %bb11
bb9:
  br label %bb16
bb10:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb15
bb11:
  %t27 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = icmp sge i64 %t28, 0
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t32 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l22, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = shl i64 1, %t36
  %t40 = icmp slt i64 %t33, %t37
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l20, !tbaa !21
  store i1 %t42, ptr %l17, !tbaa !21
  br label %bb15
bb15:
  %t43 = load i1, ptr %l17, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
bb16:
  %t44 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  br i1 %t47, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = icmp eq i64 %t50, 64
  br i1 %t52, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb22
bb21:
  %t54 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = load i64, ptr %l3, !tbaa !24
  store i64 %t56, ptr %l32, !tbaa !24
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = load i64, ptr %l32, !tbaa !24
  %t59 = shl i64 1, %t58
  %t62 = icmp slt i64 %t55, %t59
  store i1 %t62, ptr %l30, !tbaa !21
  br label %bb22
bb22:
  %t64 = load i1, ptr %l30, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
bb23:
  %t65 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t66 = load i1, ptr %t65, !tbaa !21
  br i1 %t66, label %bb24, label %bb25
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = icmp eq i64 %t69, 64
  br i1 %t71, label %bb27, label %bb28
bb27:
  store i1 true, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = sub i64 %t74, 1
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = shl i64 1, %t78
  store i64 %t79, ptr %l4, !tbaa !24
  %t81 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load i64, ptr %l4, !tbaa !24
  %t85 = sub i64 0, %t83
  %t88 = icmp sge i64 %t82, %t85
  br i1 %t88, label %bb30, label %bb31
bb30:
  %t90 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = load i64, ptr %l4, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  store i1 %t95, ptr %l47, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l47, !tbaa !21
  store i1 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2eintFloatBits(i32 %a0, %"compiler/check:litv" %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca i64
  %rv = alloca i64
  store i32 %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t5 = load i64, ptr %t4, !tbaa !24
  store i64 %t5, ptr %l2, !tbaa !65
  %t8 = load i32, ptr %l0, !tbaa !23
  %t10 = icmp eq i32 %t8, 13
  br i1 %t10, label %bb3, label %bb4
bb2:
  br label %bb12
bb3:
  %t12 = load i64, ptr %l2, !tbaa !65
  %t14 = uitofp i64 %t12 to float
  %t16 = bitcast float %t14 to i32
  %t18 = zext i32 %t16 to i64
  store i64 %t18, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t20 = load i32, ptr %l0, !tbaa !23
  %t22 = icmp eq i32 %t20, 12
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load i64, ptr %l2, !tbaa !65
  %t26 = call bfloat @__olang_int_bf16(i64 %t24, i1 false)
  %t28 = bitcast bfloat %t26 to i16
  %t29 = call i16 asm "", "=r,0"(i16 %t28)
  %t31 = zext i16 %t29 to i64
  store i64 %t31, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = load i32, ptr %l0, !tbaa !23
  %t35 = icmp eq i32 %t33, 11
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l2, !tbaa !65
  %t39 = uitofp i64 %t37 to double
  %t40 = call double @llvm.arithmetic.fence.f64(double %t39)
  %t41 = fptrunc double %t40 to half
  %t43 = bitcast half %t41 to i16
  %t44 = call i16 asm "", "=r,0"(i16 %t43)
  %t46 = zext i16 %t44 to i64
  store i64 %t46, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l2, !tbaa !65
  %t50 = uitofp i64 %t48 to double
  %t52 = bitcast double %t50 to i64
  store i64 %t52, ptr %rv
  br label %ret
bb12:
  %t55 = load i32, ptr %l0, !tbaa !23
  %t57 = icmp eq i32 %t55, 13
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t60 = load i64, ptr %t59, !tbaa !24
  %t62 = sitofp i64 %t60 to float
  %t64 = bitcast float %t62 to i32
  %t66 = zext i32 %t64 to i64
  store i64 %t66, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t68 = load i32, ptr %l0, !tbaa !23
  %t70 = icmp eq i32 %t68, 12
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  %t76 = sub i64 0, %t73
  %t77 = select i1 %t75, i64 %t76, i64 %t73
  %t78 = call bfloat @__olang_int_bf16(i64 %t77, i1 %t75)
  %t80 = bitcast bfloat %t78 to i16
  %t81 = call i16 asm "", "=r,0"(i16 %t80)
  %t83 = zext i16 %t81 to i64
  store i64 %t83, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t85 = load i32, ptr %l0, !tbaa !23
  %t87 = icmp eq i32 %t85, 11
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t89 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t90 = load i64, ptr %t89, !tbaa !24
  %t92 = sitofp i64 %t90 to double
  %t93 = call double @llvm.arithmetic.fence.f64(double %t92)
  %t94 = fptrunc double %t93 to half
  %t96 = bitcast half %t94 to i16
  %t97 = call i16 asm "", "=r,0"(i16 %t96)
  %t99 = zext i16 %t97 to i64
  store i64 %t99, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t101 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = sitofp i64 %t102 to double
  %t106 = bitcast double %t104 to i64
  store i64 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2eintOnly(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 80 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 81 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 82 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0
  %t20 = trunc i64 52 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0
  %t26 = trunc i64 85 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0
  %t32 = trunc i64 86 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2elastIsValue(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t6 = sub i64 %t4, 1
  %t8 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr ptr, ptr %t9, i64 %t6
  %t11 = load ptr, ptr %t10, !tbaa !39
  store ptr %t11, ptr %l1, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i64, ptr %t17
  %t20 = icmp eq i64 %t18, 0
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr }, ptr %t24, i32 0, i32 1
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %t28)
  store i1 %t30, ptr %l16
  br label %bb6
bb6:
  %t31 = load i1, ptr %l16, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l8, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_696a437f6b67e70a_247b6a7ce30931f6)
  unreachable
bb12:
  %t34 = load i1, ptr %l8, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2eliteralOrder_2einit() #0 {
entry:
  %l0 = alloca [12 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 3, ptr @.d55 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr @.d56 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 3, ptr @.d57 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 3, ptr @.d58 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr @.d59 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr @.d60 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr @.d61 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 4, ptr @.d62 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr @.d63 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr @.d64 }, ptr %t10, !tbaa !37
  %t11 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 2, ptr @.d65 }, ptr %t11, !tbaa !37
  %t12 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 2, ptr @.d66 }, ptr %t12, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fcheck_2eliteralOrder, ptr %l0, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v0, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"compiler/source:Span"
  %l77 = alloca i64
  %l80 = alloca i64
  %l99 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t97 = alloca { i64, [4 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %t3
  store ptr %t3, ptr %l3, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l6, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l8, !tbaa !24
  store i64 %a2, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l8, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb11, label %bb12
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l32, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ePu_H50118fa117031f41a126a195286f9d97(ptr %v0, ptr %v0, ptr %t41, ptr %t39)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l5, !tbaa !24
  br label %bb4
bb10:
  br label %bb25
bb11:
  %t49 = load i64, ptr %l10, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb16
bb13:
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l10, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l10, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l46, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb15
bb15:
  %t69 = load i64, ptr %l46, !tbaa !24
  store i64 %t69, ptr %l43, !tbaa !24
  br label %bb16
bb16:
  %t70 = load i64, ptr %l43, !tbaa !24
  store i64 %t70, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  %t71 = load i64, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s7)
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l12, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l13, !tbaa !24
  %t89 = load ptr, ptr %l3, !tbaa !29
  store ptr %t89, ptr %l64, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t90, ptr %l65, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr ptr, ptr %t92, i64 0
  %t94 = load ptr, ptr %t93, !tbaa !39
  %t96 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %t94)
  store %"compiler/source:Span" %t96, ptr %l67
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t99 = load %"compiler/source:Span", ptr %l67
  %t100 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t99, 0
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  store { %"compiler/source:Span" } %t100, ptr %t101
  %t102 = load { i64, [4 x i64] }, ptr %t97
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t102, ptr %t104
  %t105 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ePu_H50118fa117031f41a126a195286f9d97(ptr %v0, ptr %v0, ptr %t105, ptr %t104)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb23
bb23:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l12, !tbaa !24
  br label %bb17
bb24:
  br label %bb25
bb25:
  store i64 1, ptr %l14, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t115 = load i64, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb26, label %bb27
bb26:
  %t121 = load i64, ptr %l16, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb31
bb28:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l16, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l16, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l80, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb30
bb30:
  %t141 = load i64, ptr %l80, !tbaa !24
  store i64 %t141, ptr %l77, !tbaa !24
  br label %bb31
bb31:
  %t142 = load i64, ptr %l77, !tbaa !24
  store i64 %t142, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s10
  %t143 = load i64, ptr %l18, !tbaa !24
  %t144 = load i64, ptr %l17, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s10)
  br label %bb38
bb34:
  br label %bb35
bb35:
  %t151 = load i64, ptr %l14, !tbaa !24
  %t152 = load i64, ptr %l18, !tbaa !24
  %t153 = load i64, ptr %l16, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  %t161 = load ptr, ptr %l3, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t162, ptr %l99, !tbaa !27
  %t165 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t159
  %t168 = load ptr, ptr %t167, !tbaa !39
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ePu_H50118fa117031f41a126a195286f9d97(ptr %v0, ptr %v0, ptr %t161, ptr %t168)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s10)
  br label %bb37
bb37:
  %t171 = load i64, ptr %l18, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l18, !tbaa !24
  br label %bb32
bb38:
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t177 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eTo_H10e4dc538dd932dd9b3885c00bcf8105(ptr %v0, ptr %v0, ptr %t175)
  store { i64, ptr } %t177, ptr %l105
  br label %bb39
bb39:
  %t178 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t178, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb29
bb10:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 3
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = call i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %t34)
  store i1 %t36, ptr %l19
  br label %bb16
bb16:
  %t37 = load i1, ptr %l19, !tbaa !21
  store i1 %t37, ptr %l3, !tbaa !21
  br label %bb29
bb17:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l20, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 2
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = call i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %t53)
  store i1 %t55, ptr %l27
  br label %bb23
bb23:
  %t56 = load i1, ptr %l27, !tbaa !21
  store i1 %t56, ptr %l3, !tbaa !21
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_5f83e155ca38cf66_2e569db778e046b2)
  unreachable
bb29:
  %t57 = load i1, ptr %l3, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:opShape"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:opShape" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/check:opShape" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:opShape" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/check:opShape" %t14, i1 %a3, 3
  store %"compiler/check:opShape" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:opShape", ptr %rv
  ret %"compiler/check:opShape" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
@.d0 = private constant [3 x i8] c"Str"
@.d1 = private constant [3 x i8] c"str"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d2 = private constant [32 x i8] c"a build constant without a value"
@.d3 = private constant [3 x i8] c"U64"
@.d4 = private constant [3 x i8] c"F64"
@.d5 = private constant [35 x i8] c"a build constant of this kind (B10)"
@.d6 = private constant [4 x i8] c"Bool"
@.d7 = private constant [5 x i8] c"Array"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d8 = private constant [37 x i8] c"several globals given one value (D8c)"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d9 = private constant [1 x i8] c"."
@.d10 = private constant [20 x i8] c"std/prelude/argument"
@.d11 = private constant [13 x i8] c"ArgumentError"
@.d12 = private constant [7 x i8] c"INVALID"
@.d13 = private constant [2 x i8] c": "
@.d14 = private constant [20 x i8] c"std/prelude/iterator"
@.d15 = private constant [9 x i8] c"Exhausted"
@.d16 = private constant [1 x i8] c"_"
@.d17 = private constant [0 x i8] c""
@.d18 = private constant [1 x i8] c"s"
@.d19 = private constant [27 x i8] c" - it is not a numeric type"
@.d20 = private constant [93 x i8] c" - a declared type has its base's limits only where it extends it and declares no constructor"
@.d21 = private constant [46 x i8] c"Max, Min, Inf, NaN, Epsilon and SmallestNormal"
@.d22 = private constant [11 x i8] c"Max and Min"
@.d23 = private constant [18 x i8] c" - its limits are "
@.d24 = private constant [4 x i8] c"true"
@.d25 = private constant [22 x i8] c"a literal of this kind"
@.d26 = private constant [33 x i8] c"a local the checker has not bound"
@.d27 = private constant [30 x i8] c"a name of this kind as a value"
@.d28 = private constant [0 x i8] c""
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d29 = private constant [10 x i8] c") noreturn"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d30 = private constant [13 x i8] c"no parameters"
@.d31 = private constant [13 x i8] c"one parameter"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d32 = private constant [11 x i8] c" parameters"
@.d33 = private constant [3 x i8] c"one"
@.d34 = private constant [4 x i8] c"none"
@.d35 = private constant [9 x i8] c"at least "
define internal i1 @olang_lambda_36(ptr %env, %"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l3 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 1
  %t2 = load i1, ptr %t1, !tbaa !21
  %t4 = xor i1 %t2, true
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb6
bb2:
  %t6 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 4
  %t7 = load double, ptr %t6, !tbaa !26
  %t9 = fcmp ole double %t7, 0x7fefffffffffffff
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 4
  %t12 = load double, ptr %t11, !tbaa !26
  %t14 = fcmp oge double %t12, 0xffefffffffffffff
  store i1 %t14, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t16 = load i1, ptr %l6, !tbaa !21
  store i1 %t16, ptr %l3, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l3, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d37 = private constant [5 x i8] c"Slice"
@.d38 = private constant [5 x i8] c"Slice"
@.d39 = private constant [10 x i8] c"'x[lo:hi]'"
@.d40 = private constant [3 x i8] c"Len"
@.d41 = private constant [47 x i8] c"a slice with no end of a type with no Len (E31)"
@.d42 = private constant [2 x i8] c", "
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d43 = private constant [1 x i8] c"<"
@.d44 = private constant [3 x i8] c" ? "
@.d45 = private constant [2 x i8] c"? "
@.d46 = private constant [2 x i8] c", "
@.d47 = private constant [1 x i8] c">"
@.d48 = private constant [3 x i8] c"Str"
@.d49 = private constant [3 x i8] c"str"
@.d50 = private constant [4 x i8] c"null"
@.d51 = private constant [3 x i8] c"Str"
@.d52 = private constant [3 x i8] c"str"
@.d53 = private constant [3 x i8] c"Str"
@.d54 = private constant [3 x i8] c"'$'"
declare bfloat @__olang_int_bf16(i64, i1)
declare double @llvm.arithmetic.fence.f64(double)
@.d55 = private constant [3 x i8] c"F64"
@.d56 = private constant [3 x i8] c"I64"
@.d57 = private constant [3 x i8] c"U64"
@.d58 = private constant [3 x i8] c"F32"
@.d59 = private constant [3 x i8] c"I32"
@.d60 = private constant [3 x i8] c"U32"
@.d61 = private constant [3 x i8] c"F16"
@.d62 = private constant [4 x i8] c"BF16"
@.d63 = private constant [3 x i8] c"I16"
@.d64 = private constant [3 x i8] c"U16"
@.d65 = private constant [2 x i8] c"I8"
@.d66 = private constant [2 x i8] c"U8"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2fcheck_2eCtEntry = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ebuiltAst(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBind_26_3e_2eRun_H6780729b4f4c1d3e21064ca0ba41c437(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7630015a1eabc80_a7cefd5c2ca62e84 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_895a5b373a859d11_d91bb98a2d8e9a75 = external constant [0 x i8]
@olang_loc_57cee8e261e9bb7a_a117945682ceb0be = external constant [0 x i8]
@olang_loc_66d51bf767fdffb_4023b8d39b45a3bf = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_2d4bbb6497aa425c_2f833b8e3e06fbc8 = external constant [0 x i8]
@olang_loc_c46ca745ccc2db8d_58407427ebe5099 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8144c9e107914b58_42c61ae8c534985c = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStrBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6eddca2d598ce6fb_9d8bffc2796cf667 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
@olang_loc_f64a0f855cc2648c_4038adf1240cd248 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_fa88b19e51866753_1c515c5623826c7f = external constant [0 x i8]
@olang_loc_962a22c7791f971e_263bae1157bb3aaa = external constant [0 x i8]
@olang_loc_bce8d8bde069702e_ffe04dc686cce872 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_27c62905650ee804_ddef4b1ccc198ce0 = external constant [0 x i8]
declare { i1, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_35d0274d34665ca7_d8b5deabc24f5253 = external constant [0 x i8]
declare %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtLast(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowInStatement(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCaseTest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
@olang_loc_514ceade83978a4d_1843f44cd2570191 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8bbd92ac148fb220_5a9ba8c1b178084 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eSet_H7eb7f72699477ff6ed0f03fe599574de(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5, ptr %a6)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eTru_H381e973120335535f017a290d5069d76(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H66d61cdd994b442644a8ee2ce6a8bf73(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i32 %a2)
@olang_loc_27b76e5e144937_92b9984f1a7672bb = external constant [0 x i8]
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildDefaulted(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefineValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %a0)
@G_2ecompiler_2fcheck_2eRoGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4)
@olang_loc_6495b6dfee4ecee2_6e1c2cfd4a22a64e = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_8d548c3c72e36863_6a32d0416bf96aff = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/typed:ContractInfo" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H1fc1bd863e6a60d3e5c2aece55d841d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_46400974b7d00480_e2373b052a0b959c = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eRemove_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H044304b59760c17b661e6227d2ca1ac9(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeRel_3e_2eCl_H61e34197f63b762a003a73c4f2bf0624(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_700945490095e3ab_b793fb317cfa4b47 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28 = external constant [0 x i8]
@olang_loc_25ec48d7738ec131_33504a893c084afd = external constant [0 x i8]
@olang_loc_1c86c4e2a1d4d52a_afb2831c22759b16 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %a0, %"compiler/generic:AnySlot" %a1)
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3)
@olang_loc_8b08af1e0b47ad17_714e6cc493d1321b = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractNeedsArgumentError(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectErr(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c7b5cbd58e58cb02_20344cc1e983d9b6 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
@olang_loc_b7234c2f48bf29ec_30c1ec6e3fb60508 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1)
@olang_loc_8e26fbb1c5557eef_13e6cc5de085742b = external constant [0 x i8]
@olang_loc_6d702b04e725ae1a_71c02c55b3dfc416 = external constant [0 x i8]
declare %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4, i64 %a5, i32 %a6)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %v0)
@olang_loc_602058b5bbdc5ba4_407e96c83aaf1680 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotStmtSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNextLine(ptr %v0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %v0)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotInferable(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoLimit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2elimitIndex(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2elimitBits(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuteParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, i32 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextLit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIntLiteralTooLarge(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFloatLiteralRange(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueParam(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMisused(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"compiler/check:fixedInit" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6f2dcaa3b3ff2363ea7964270c7a6b31(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_d573417cd970c31d_c74d35b0202ac379 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarAsValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2enameDistance(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2aeb1d20595e7cd2_796959d3edf1a336 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResetAny(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H94cbbacdefacbf11591e45fa927fb1cb(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2flis_H596e3d714cead58c6bb1a410db388b73(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroDeepArg_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compil_H33d643ee420c12f578033f46e688097e(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_af79aa682331a71e_538108f01047ae92 = external constant [0 x i8]
@olang_loc_17d8aaff70de119f_90c04534d00fd893 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb = external constant [0 x i8]
@olang_loc_e4f33d7277813d9a_8adeed4fca551266 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
@olang_loc_b203c9fbf4c249fb_735051f472c86bf = external constant [0 x i8]
@olang_loc_85a2f2931038d80c_e5a946dd8e187d18 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_2f1aad6b95023edd_c82f5ce971f0d619 = external constant [0 x i8]
declare %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnInDefer(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnOutsideJoin(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2ector(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H5eacc50cc32d6e41ff62f01e24d943f2(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e10ca684bef0956d_f742028d37a3af11 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnLambdaParams(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
@olang_loc_31ec5049601f3040_e4a7c8cc80642e04 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnNotCall(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnySpawned(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnySpawnedResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_da760de622febe3_df78aa298e2a00e7 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFallible(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnTryInfallible(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aTaskClause_26_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H4d447d5f762c25bc2b844b5f209f491d(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ee8620bb7b7c2476_e7a9796d2a7d03d2 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchNameInTask(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aTaskClause_26_3e_H3ca385fa4615f85153508d1633d8a345(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a0a2b29f181c5519_be518ce768fc1fe5 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eP_Hee51906bde9346e7b7b6808fdce5ba81(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultVoid(ptr %v0)
@olang_loc_677b6b070937960c_aa2fc92e4a99f78 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_bd22b69341f84ac1_ea8edc6c92d7b395 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultAsRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_bd26e4864ba9573a_dfa400004ab377ee = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalNote(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3)
@olang_loc_e80162ef31442376_d45687553b8e74d2 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Hc6bfb67c24d59c9d5bbbdae0417c538b(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aTaskClause_26_3e_Hc73dff03d06e80c51c2cbccf7b6fc7e6(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
@olang_loc_3727962a9e2e15db_7cf774666c9d4227 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
@olang_loc_7cf0066f219391e3_f59e2f38f1229917 = external constant [0 x i8]
@olang_loc_93e3a02800d00d4_2c47855b6b12ccf8 = external constant [0 x i8]
@olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitNotAType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_cc3b6ed7ca85eab5_875d9ef7a16c4e59 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %a0)
@olang_loc_696a437f6b67e70a_247b6a7ce30931f6 = external constant [0 x i8]
@G_2ecompiler_2fcheck_2eliteralOrder = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ePu_H50118fa117031f41a126a195286f9d97(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eTo_H10e4dc538dd932dd9b3885c00bcf8105(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0)
@olang_loc_5f83e155ca38cf66_2e569db778e046b2 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
