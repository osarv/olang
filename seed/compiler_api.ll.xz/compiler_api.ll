; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1, i1 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/api:change" = type { i1, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/api:sig" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/doc:Entry" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/session:Analysis" = type { ptr, ptr, ptr, ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local i32 @compiler_2fapi_2eMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"compiler/diag:Diagnostics"
  %l5 = alloca { i64, ptr }
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l8 = alloca [2 x { i64, ptr }]
  %l9 = alloca { i64, ptr }
  %l10 = alloca [2 x { i64, ptr }]
  %l11 = alloca [2 x { i64, ptr }]
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca [2 x { i64, ptr }]
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca [2 x { i64, ptr }]
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca %"compiler/api:change"
  %l26 = alloca i1
  %l27 = alloca %"compiler/diag:Diagnostics"
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l32 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l46 = alloca i1
  %l48 = alloca i32
  %l50 = alloca i32
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l65 = alloca i1
  %l67 = alloca i32
  %l69 = alloca i32
  %l71 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l94 = alloca i64
  %l96 = alloca ptr
  %l97 = alloca { i64, [3 x i64] }
  %l99 = alloca %"compiler/msgs:Msg"
  %l100 = alloca i64
  %l102 = alloca i32
  %l104 = alloca i32
  %l106 = alloca i1
  %l107 = alloca %"std/prelude/text:StringBuilder"
  %l109 = alloca i64
  %l111 = alloca i64
  %l116 = alloca { i64, ptr }
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l118 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l128 = alloca i32
  %l130 = alloca i1
  %l131 = alloca i32
  %l133 = alloca i32
  %l135 = alloca i1
  %l136 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l146 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l147 = alloca i32
  %l149 = alloca i1
  %l150 = alloca i32
  %l152 = alloca i32
  %l154 = alloca i1
  %l157 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l159 = alloca i64
  %l166 = alloca i64
  %l168 = alloca i64
  %l173 = alloca %"compiler/api:change"
  %l177 = alloca ptr
  %l179 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l186 = alloca i64
  %l189 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l197 = alloca i32
  %l199 = alloca i32
  %l201 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  %t163 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l26
  br label %bb1
bb1:
  %t3 = load i1, ptr %l26, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %s0, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %t2, i64 544, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l27, i64 544, i1 false)
  %t4 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d1, i32 0, i32 1) })
  %t5 = extractvalue { i32, { i64, ptr } } %t4, 1
  %t6 = extractvalue { i32, { i64, ptr } } %t4, 0
  store i32 %t6, ptr %l30
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb4, label %ok.8, !prof !99
ok.8:
  store { i64, ptr } %t5, ptr %l29
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t9, ptr %l28, !tbaa !27
  br label %bb7
bb4:
  %t10 = load i32, ptr %l30, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  store i1 %t13, ptr %l32, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  call void @compiler_2fapi_2esay(ptr %s1, { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb7:
  %t15 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  store { i64, ptr } %a0, ptr %l35, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t19 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t17, 0
  %t20 = insertvalue [2 x { i64, ptr }] %t19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t20, ptr %l6
  %t23 = insertvalue { i64, ptr } undef, i64 2, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %l6, 1
  %t26 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t24)
  store { i64, ptr } %t26, ptr %l40
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t34 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t37 = call { i32, { i64, ptr } } @compiler_2fapi_2eside(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t34, { i64, ptr } %t33, ptr %l4)
  %t38 = extractvalue { i32, { i64, ptr } } %t37, 1
  %t39 = extractvalue { i32, { i64, ptr } } %t37, 0
  store i32 %t39, ptr %l44
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb10, label %ok.41, !prof !99
ok.41:
  store { i64, ptr } %t38, ptr %l43
  br label %bb9
bb9:
  %t42 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t42, ptr %l34, !tbaa !27
  br label %bb17
bb10:
  %t43 = load i32, ptr %l44, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  store i1 %t46, ptr %l46, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  %t48 = call i32 @compiler_2fapi_2esaid(ptr %s0, ptr %l4)
  store i32 %t48, ptr %l48
  br label %bb12
bb12:
  %t49 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t49)
  store i32 %t51, ptr %l50
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb14, label %ok.53, !prof !99
ok.53:
  br label %bb13
bb13:
  br label %bb16
bb14:
  %t54 = load i32, ptr %l50, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  store i1 %t57, ptr %l52, !tbaa !21
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l48, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb17:
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t59, ptr %l7, !tbaa !27
  store { i64, ptr } %a1, ptr %l54, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t61, 0
  %t64 = insertvalue [2 x { i64, ptr }] %t63, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t64, ptr %l8
  %t67 = insertvalue { i64, ptr } undef, i64 2, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %l8, 1
  %t70 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t68)
  store { i64, ptr } %t70, ptr %l59
  br label %bb18
bb18:
  %t71 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t78 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t81 = call { i32, { i64, ptr } } @compiler_2fapi_2eside(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t78, { i64, ptr } %t77, ptr %l4)
  %t82 = extractvalue { i32, { i64, ptr } } %t81, 1
  %t83 = extractvalue { i32, { i64, ptr } } %t81, 0
  store i32 %t83, ptr %l63
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb20, label %ok.85, !prof !99
ok.85:
  store { i64, ptr } %t82, ptr %l62
  br label %bb19
bb19:
  %t86 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t86, ptr %l53, !tbaa !27
  br label %bb27
bb20:
  %t87 = load i32, ptr %l63, !tbaa !23
  %t88 = ashr i32 %t87, 16
  %t90 = icmp eq i32 %t88, 1
  store i1 %t90, ptr %l65, !tbaa !21
  br label %bb21
bb21:
  call void @__olang_ert_req_clear()
  %t92 = call i32 @compiler_2fapi_2esaid(ptr %s0, ptr %l4)
  store i32 %t92, ptr %l67
  br label %bb22
bb22:
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t95 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t93)
  store i32 %t95, ptr %l69
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb24, label %ok.97, !prof !99
ok.97:
  br label %bb23
bb23:
  br label %bb26
bb24:
  %t98 = load i32, ptr %l69, !tbaa !23
  %t99 = ashr i32 %t98, 16
  %t101 = icmp eq i32 %t99, 1
  store i1 %t101, ptr %l71, !tbaa !21
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t102 = load i32, ptr %l67, !tbaa !23
  store i32 %t102, ptr %rv
  br label %ret
bb27:
  %t103 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t103, ptr %l9, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t107 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t104, 0
  %t109 = insertvalue [2 x { i64, ptr }] %t107, { i64, ptr } %t105, 1
  store [2 x { i64, ptr }] %t109, ptr %l10
  %t112 = insertvalue { i64, ptr } undef, i64 2, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %l10, 1
  %t115 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t113)
  store { i64, ptr } %t115, ptr %l77
  br label %bb28
bb28:
  %t116 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  %t118 = extractvalue { i64, ptr } %t116, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  %t123 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t126 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fapi_2esources(ptr %s0, ptr %v2, ptr %s0, { i64, ptr } %t122, { i64, ptr } %t123)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %l80
  br label %bb29
bb29:
  %t127 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  %t128 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %t128
  store ptr %t128, ptr %l81, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t132 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t129, 0
  %t134 = insertvalue [2 x { i64, ptr }] %t132, { i64, ptr } %t130, 1
  store [2 x { i64, ptr }] %t134, ptr %l11
  %t137 = insertvalue { i64, ptr } undef, i64 2, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %l11, 1
  %t140 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t138)
  store { i64, ptr } %t140, ptr %l87
  br label %bb30
bb30:
  %t141 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t148 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t151 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fapi_2esources(ptr %s0, ptr %v2, ptr %s0, { i64, ptr } %t147, { i64, ptr } %t148)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l90
  br label %bb31
bb31:
  %t152 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  %t153 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %t153
  %t154 = load ptr, ptr %l81, !tbaa !29
  %t156 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fapi_2eunion(ptr %s0, ptr %s0, ptr %s0, ptr %t154, ptr %t153)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t156, ptr %l92
  br label %bb32
bb32:
  %t157 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %l12
  %t159 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l12)
  store i64 %t159, ptr %l94
  br label %bb33
bb33:
  %t160 = load i64, ptr %l94, !tbaa !24
  %t161 = icmp eq i64 %t160, 0
  br i1 %t161, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l4, ptr %l96, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [3 x i64] }, ptr %t163, i32 0, i32 0
  store i64 0, ptr %t164
  %t165 = load { i64, [3 x i64] }, ptr %t163
  store { i64, [3 x i64] } %t165, ptr %l97
  %t166 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t168 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eApiNoFiles(ptr %v2, ptr %s10, { i64, ptr } %t166)
  store %"compiler/msgs:Msg" %t168, ptr %l99
  br label %bb36
bb35:
  br label %bb43
bb36:
  %t169 = load ptr, ptr %l96, !tbaa !29
  %t170 = load { i64, [3 x i64] }, ptr %l97
  %t171 = load %"compiler/msgs:Msg", ptr %l99
  %t172 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %s0, ptr %s10, ptr %t169, { i64, [3 x i64] } %t170, %"compiler/msgs:Msg" %t171)
  store i64 %t172, ptr %l100
  br label %bb37
bb37:
  %t174 = call i32 @compiler_2fapi_2esaid(ptr %s0, ptr %l4)
  store i32 %t174, ptr %l102
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s10)
  %t175 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t177 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t175)
  store i32 %t177, ptr %l104
  %t178 = icmp ne i32 %t177, 0
  br i1 %t178, label %bb40, label %ok.179, !prof !99
ok.179:
  br label %bb39
bb39:
  br label %bb42
bb40:
  %t180 = load i32, ptr %l104, !tbaa !23
  %t181 = ashr i32 %t180, 16
  %t183 = icmp eq i32 %t181, 1
  store i1 %t183, ptr %l106, !tbaa !21
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t184 = load i32, ptr %l102, !tbaa !23
  store i32 %t184, ptr %rv
  br label %ret
bb43:
  store i64 0, ptr %l13, !tbaa !24
  %t185 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t185, ptr %l107
  br label %bb44
bb44:
  %t186 = load %"std/prelude/text:StringBuilder", ptr %l107
  store %"std/prelude/text:StringBuilder" %t186, ptr %l14
  store ptr %l12, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s15
  %t188 = load i64, ptr %l16, !tbaa !24
  store i64 %t188, ptr %l109, !tbaa !24
  %t189 = load ptr, ptr %l15, !tbaa !29
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t189)
  store i64 %t191, ptr %l111
  br label %bb46
bb46:
  %t192 = load i64, ptr %l109, !tbaa !24
  %t193 = load i64, ptr %l111, !tbaa !24
  %t194 = icmp slt i64 %t192, %t193
  %t196 = xor i1 %t194, true
  br i1 %t196, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s15)
  br label %bb89
bb48:
  br label %bb49
bb49:
  %t198 = load ptr, ptr %l15, !tbaa !29
  %t199 = load i64, ptr %l16, !tbaa !24
  %t202 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t198, i64 %t199)
  store { i64, ptr } %t202, ptr %l116
  br label %bb50
bb50:
  %t203 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t203, ptr %l17, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t204, ptr %l118, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t205, ptr %l119, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t208 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t206, 0
  %t209 = insertvalue [2 x { i64, ptr }] %t208, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t209, ptr %l18
  %t212 = insertvalue { i64, ptr } undef, i64 2, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %l18, 1
  %t215 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s15, ptr %s15, { i64, ptr } %t213)
  store { i64, ptr } %t215, ptr %l124
  br label %bb51
bb51:
  %t216 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  %t218 = extractvalue { i64, ptr } %t216, 1
  %t219 = mul i64 %t217, 1
  %t220 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t219)
  call void @llvm.memcpy.p0.p0.i64(ptr %t220, ptr %t218, i64 %t219, i1 false)
  %t221 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  %t223 = load ptr, ptr %l3, !tbaa !29
  %t224 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t228 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fapi_2eentries(ptr %s0, ptr %s0, ptr %s15, ptr %v3, ptr %s15, { i64, ptr } %t224, { i64, ptr } %t225, { i64, ptr } %t222, ptr %t223)
  %t229 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t228, 1
  %t230 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t228, 0
  store i32 %t230, ptr %l128
  %t231 = icmp ne i32 %t230, 0
  br i1 %t231, label %bb53, label %ok.232, !prof !99
ok.232:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t229, ptr %l127
  br label %bb52
bb52:
  %t233 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l127
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t233, ptr %l117
  br label %bb59
bb53:
  %t234 = load i32, ptr %l128, !tbaa !23
  %t235 = ashr i32 %t234, 16
  %t237 = icmp eq i32 %t235, 1
  store i1 %t237, ptr %l130, !tbaa !21
  br label %bb54
bb54:
  call void @__olang_ert_req_clear()
  store i32 2, ptr %l131, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  %t238 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t240 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t238)
  store i32 %t240, ptr %l133
  %t241 = icmp ne i32 %t240, 0
  br i1 %t241, label %bb56, label %ok.242, !prof !99
ok.242:
  br label %bb55
bb55:
  br label %bb58
bb56:
  %t243 = load i32, ptr %l133, !tbaa !23
  %t244 = ashr i32 %t243, 16
  %t246 = icmp eq i32 %t244, 1
  store i1 %t246, ptr %l135, !tbaa !21
  br label %bb57
bb57:
  call void @__olang_ert_req_clear()
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t247 = load i32, ptr %l131, !tbaa !23
  store i32 %t247, ptr %rv
  br label %ret
bb59:
  %t248 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t248, ptr %l19
  %t249 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t249, ptr %l137, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t250, ptr %l138, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t253 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t251, 0
  %t254 = insertvalue [2 x { i64, ptr }] %t253, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t254, ptr %l20
  %t257 = insertvalue { i64, ptr } undef, i64 2, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %l20, 1
  %t260 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s15, ptr %s15, { i64, ptr } %t258)
  store { i64, ptr } %t260, ptr %l143
  br label %bb60
bb60:
  %t261 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  %t263 = extractvalue { i64, ptr } %t261, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t268 = load ptr, ptr %l3, !tbaa !29
  %t269 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t270 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t273 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fapi_2eentries(ptr %s0, ptr %s0, ptr %s15, ptr %v3, ptr %s15, { i64, ptr } %t269, { i64, ptr } %t270, { i64, ptr } %t267, ptr %t268)
  %t274 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t273, 1
  %t275 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t273, 0
  store i32 %t275, ptr %l147
  %t276 = icmp ne i32 %t275, 0
  br i1 %t276, label %bb62, label %ok.277, !prof !99
ok.277:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t274, ptr %l146
  br label %bb61
bb61:
  %t278 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l146
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %l136
  br label %bb68
bb62:
  %t279 = load i32, ptr %l147, !tbaa !23
  %t280 = ashr i32 %t279, 16
  %t282 = icmp eq i32 %t280, 1
  store i1 %t282, ptr %l149, !tbaa !21
  br label %bb63
bb63:
  call void @__olang_ert_req_clear()
  store i32 2, ptr %l150, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  %t283 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t285 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t283)
  store i32 %t285, ptr %l152
  %t286 = icmp ne i32 %t285, 0
  br i1 %t286, label %bb65, label %ok.287, !prof !99
ok.287:
  br label %bb64
bb64:
  br label %bb67
bb65:
  %t288 = load i32, ptr %l152, !tbaa !23
  %t289 = ashr i32 %t288, 16
  %t291 = icmp eq i32 %t289, 1
  store i1 %t291, ptr %l154, !tbaa !21
  br label %bb66
bb66:
  call void @__olang_ert_req_clear()
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t292 = load i32, ptr %l150, !tbaa !23
  store i32 %t292, ptr %rv
  br label %ret
bb68:
  %t293 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l136
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t293, ptr %l21
  %t296 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fapi_2ecompare(ptr %s15, ptr %s15, ptr %s15, ptr %l19, ptr %l21)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t296, ptr %l157
  br label %bb69
bb69:
  %t297 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t297, ptr %l22
  %t299 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3achange_3e_2eLen_3ccompiler_2fapi_3achange_3e(ptr %s15, ptr %l22)
  store i64 %t299, ptr %l159
  br label %bb70
bb70:
  %t300 = load i64, ptr %l159, !tbaa !24
  %t301 = icmp eq i64 %t300, 0
  br i1 %t301, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s15)
  br label %bb88
bb72:
  br label %bb73
bb73:
  %t303 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t303, 1
  %t306 = extractvalue { i64, ptr } %t303, 0
  %t307 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t308 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t309 = add i64 %t306, %t308
  %t310 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t309)
  call void @olang_textcopy(ptr %t310, ptr %t305, i64 %t306)
  %t311 = getelementptr i8, ptr %t310, i64 %t306
  call void @olang_textcopy(ptr %t311, ptr %t307, i64 %t308)
  %t312 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t310, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t316 = extractvalue { i64, ptr } %t313, 1
  %t317 = mul i64 %t315, 1
  %t318 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t317)
  call void @llvm.memcpy.p0.p0.i64(ptr %t318, ptr %t316, i64 %t317, i1 false)
  %t319 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t318, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l14, { i64, ptr } %t320)
  br label %bb74
bb74:
  store ptr %l22, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s27
  %t324 = load i64, ptr %l24, !tbaa !24
  store i64 %t324, ptr %l166, !tbaa !24
  %t325 = load ptr, ptr %l23, !tbaa !29
  %t327 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3achange_3e_2eLen_3ccompiler_2fapi_3achange_3e(ptr %s15, ptr %t325)
  store i64 %t327, ptr %l168
  br label %bb76
bb76:
  %t328 = load i64, ptr %l166, !tbaa !24
  %t329 = load i64, ptr %l168, !tbaa !24
  %t330 = icmp slt i64 %t328, %t329
  %t332 = xor i1 %t330, true
  br i1 %t332, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s27)
  br label %bb87
bb78:
  br label %bb79
bb79:
  %t334 = load ptr, ptr %l23, !tbaa !29
  %t335 = load i64, ptr %l24, !tbaa !24
  %t338 = call %"compiler/api:change" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3achange_3e_2eAt_3ccompiler_2fapi_3achange_3e(ptr %s15, ptr %s15, ptr %t334, i64 %t335)
  store %"compiler/api:change" %t338, ptr %l173
  br label %bb80
bb80:
  %t339 = load %"compiler/api:change", ptr %l173
  store %"compiler/api:change" %t339, ptr %l25
  %t340 = getelementptr %"compiler/api:change", ptr %l25, i32 0, i32 0
  %t341 = load i1, ptr %t340, !tbaa !21
  br i1 %t341, label %bb81, label %bb82
bb81:
  %t343 = load i64, ptr %l13, !tbaa !24
  %t345 = add i64 %t343, 1
  store i64 %t345, ptr %l13, !tbaa !24
  br label %bb83
bb82:
  br label %bb83
bb83:
  store ptr %l14, ptr %l177, !tbaa !29
  %t348 = call { i64, ptr } @compiler_2fapi_2erowOf(ptr %s27, ptr %s27, ptr %l25)
  store { i64, ptr } %t348, ptr %l179
  br label %bb84
bb84:
  %t349 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t349, 0
  %t351 = extractvalue { i64, ptr } %t349, 1
  %t352 = mul i64 %t350, 1
  %t353 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t352)
  call void @llvm.memcpy.p0.p0.i64(ptr %t353, ptr %t351, i64 %t352, i1 false)
  %t354 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t353, 1
  %t356 = load ptr, ptr %l177, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %t356, { i64, ptr } %t355)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s27)
  br label %bb86
bb86:
  %t358 = load i64, ptr %l24, !tbaa !24
  %t360 = add i64 %t358, 1
  store i64 %t360, ptr %l24, !tbaa !24
  br label %bb75
bb87:
  call void @__olang_scope_close(ptr %s15)
  br label %bb88
bb88:
  %t362 = load i64, ptr %l16, !tbaa !24
  %t364 = add i64 %t362, 1
  store i64 %t364, ptr %l16, !tbaa !24
  br label %bb45
bb89:
  store ptr %l14, ptr %l185, !tbaa !29
  %t366 = load i64, ptr %l13, !tbaa !24
  store i64 %t366, ptr %l186, !tbaa !24
  %t367 = load i64, ptr %l13, !tbaa !24
  %t369 = icmp eq i64 %t367, 1
  br i1 %t369, label %bb90, label %bb91
bb90:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l189, !tbaa !27
  br label %bb92
bb91:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l189, !tbaa !27
  br label %bb92
bb92:
  %t371 = load i64, ptr %l186, !tbaa !24
  %t372 = call i64 @__olang_fmt_i64(ptr null, i64 %t371)
  %t373 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t374 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t375 = add i64 %t372, %t374
  %t376 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = add i64 %t375, %t378
  %t380 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t381 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t382 = add i64 %t379, %t381
  %t383 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t382)
  %t384 = call i64 @__olang_fmt_i64(ptr %t383, i64 %t371)
  %t385 = getelementptr i8, ptr %t383, i64 %t372
  call void @olang_textcopy(ptr %t385, ptr %t373, i64 %t374)
  %t386 = getelementptr i8, ptr %t385, i64 %t374
  call void @olang_textcopy(ptr %t386, ptr %t377, i64 %t378)
  %t387 = getelementptr i8, ptr %t386, i64 %t378
  call void @olang_textcopy(ptr %t387, ptr %t380, i64 %t381)
  %t388 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t383, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = extractvalue { i64, ptr } %t389, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  %t397 = load ptr, ptr %l185, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t397, { i64, ptr } %t396)
  br label %bb93
bb93:
  %t400 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l14)
  store { i64, ptr } %t400, ptr %l193
  br label %bb94
bb94:
  %t401 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t401, 0
  %t403 = extractvalue { i64, ptr } %t401, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  call void @compiler_2fapi_2esay(ptr %s0, { i64, ptr } %t407)
  br label %bb95
bb95:
  %t409 = load i64, ptr %l13, !tbaa !24
  %t411 = icmp sgt i64 %t409, 0
  br i1 %t411, label %bb96, label %bb97
bb96:
  store i32 1, ptr %l197, !tbaa !23
  br label %bb98
bb97:
  store i32 0, ptr %l197, !tbaa !23
  br label %bb98
bb98:
  %t413 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t415 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t413)
  store i32 %t415, ptr %l199
  %t416 = icmp ne i32 %t415, 0
  br i1 %t416, label %bb100, label %ok.417, !prof !99
ok.417:
  br label %bb99
bb99:
  br label %bb102
bb100:
  %t418 = load i32, ptr %l199, !tbaa !23
  %t419 = ashr i32 %t418, 16
  %t421 = icmp eq i32 %t419, 1
  store i1 %t421, ptr %l201, !tbaa !21
  br label %bb101
bb101:
  call void @__olang_ert_req_clear()
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s0)
  %t422 = load i32, ptr %l197, !tbaa !23
  store i32 %t422, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fapi_2eaddBreaks(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i1, ptr %l6, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/api:change" @compiler_2fapi_2echanged(ptr %v0, ptr %v1, ptr %v2, %"compiler/api:sig" %a0, %"compiler/api:sig" %a1) #0 {
entry:
  %l0 = alloca %"compiler/api:sig"
  %l1 = alloca %"compiler/api:sig"
  %l2 = alloca { { i64, ptr }, { i64, ptr } }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { { i64, ptr }, { i64, ptr } }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca { { i64, ptr }, { i64, ptr } }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca { { i64, ptr }, { i64, ptr } }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca i1
  %l42 = alloca i1
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l53 = alloca i1
  %l60 = alloca i1
  %l70 = alloca %"compiler/api:change"
  %l80 = alloca %"compiler/api:change"
  %l82 = alloca i1
  %l83 = alloca i1
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l90 = alloca i1
  %l97 = alloca %"compiler/api:change"
  %l107 = alloca %"compiler/api:change"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/api:change"
  store %"compiler/api:sig" %a0, ptr %l0
  store %"compiler/api:sig" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/api:sig", ptr %l0, i32 0, i32 2
  %t2 = load { i64, ptr }, ptr %t1, !tbaa !27
  %t4 = call { { i64, ptr }, { i64, ptr } } @compiler_2fapi_2esplitErrors(ptr %v0, ptr %s0, { i64, ptr } %t2)
  store { { i64, ptr }, { i64, ptr } } %t4, ptr %l14
  br label %bb1
bb1:
  %t5 = load { { i64, ptr }, { i64, ptr } }, ptr %l14
  store { { i64, ptr }, { i64, ptr } } %t5, ptr %l2
  %t6 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l2, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l15, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l16, !tbaa !24
  %t10 = load i64, ptr %l16, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l17, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l16, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t21, ptr %l3, !tbaa !27
  %t22 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l2, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l18, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l19, !tbaa !24
  %t26 = load i64, ptr %l19, !tbaa !24
  %t27 = mul i64 %t26, 16
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l20, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l19, !tbaa !24
  %t36 = mul i64 %t35, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  %t38 = getelementptr %"compiler/api:sig", ptr %l1, i32 0, i32 2
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = call { { i64, ptr }, { i64, ptr } } @compiler_2fapi_2esplitErrors(ptr %v1, ptr %s0, { i64, ptr } %t39)
  store { { i64, ptr }, { i64, ptr } } %t41, ptr %l22
  br label %bb2
bb2:
  %t42 = load { { i64, ptr }, { i64, ptr } }, ptr %l22
  store { { i64, ptr }, { i64, ptr } } %t42, ptr %l5
  %t43 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l5, i32 0, i32 0
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l23, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l24, !tbaa !24
  %t47 = load i64, ptr %l24, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l25, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l24, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t59 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l5, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l26, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l27, !tbaa !24
  %t63 = load i64, ptr %l27, !tbaa !24
  %t64 = mul i64 %t63, 16
  %t65 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l28, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = load i64, ptr %l27, !tbaa !24
  %t73 = mul i64 %t72, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t69, ptr %t71, i64 %t73, i1 false)
  %t74 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t74, ptr %l7, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t75, { i64, ptr } %t58)
  store i1 %t79, ptr %l31
  br label %bb3
bb3:
  %t80 = load i1, ptr %l31, !tbaa !21
  br i1 %t80, label %bb4, label %bb5
bb4:
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t81, ptr %l8, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t83, ptr %l9, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t95 = icmp eq i64 %t89, %t92
  store i1 %t95, ptr %l11, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb5:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb16
bb6:
  %t97 = load i1, ptr %l11, !tbaa !21
  br i1 %t97, label %bb7, label %bb8
bb7:
  %t99 = load i64, ptr %l12, !tbaa !24
  %t100 = load i64, ptr %l10, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  store i1 %t103, ptr %l42, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb9
bb9:
  %t105 = load i1, ptr %l42, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t108 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t108, ptr %l47, !tbaa !27
  %t109 = load i64, ptr %l12, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %t112, i64 %t109
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !37
  %t115 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t115, ptr %l50, !tbaa !27
  %t116 = load i64, ptr %l12, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %t119, i64 %t116
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !37
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t114, { i64, ptr } %t121)
  store i1 %t124, ptr %l53
  br label %bb13
bb13:
  %t125 = load i1, ptr %l53, !tbaa !21
  store i1 %t125, ptr %l11, !tbaa !21
  br label %bb14
bb14:
  %t126 = load i64, ptr %l12, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l12, !tbaa !24
  br label %bb6
bb15:
  %t130 = load i1, ptr %l11, !tbaa !21
  %t132 = xor i1 %t130, true
  store i1 %t132, ptr %l32, !tbaa !21
  br label %bb16
bb16:
  %t134 = load i1, ptr %l32, !tbaa !21
  br i1 %t134, label %bb17, label %bb18
bb17:
  %t135 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t139 = call i1 @compiler_2fapi_2esubset(ptr %s0, ptr %s0, { i64, ptr } %t135, { i64, ptr } %t136)
  store i1 %t139, ptr %l60
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t140 = load i1, ptr %l60, !tbaa !21
  br i1 %t140, label %bb20, label %bb21
bb20:
  %t141 = getelementptr %"compiler/api:sig", ptr %l1, i32 0, i32 1
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  %t143 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t146 = extractvalue { i64, ptr } %t142, 1
  %t147 = extractvalue { i64, ptr } %t142, 0
  %t148 = add i64 %t144, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t143, i64 %t144)
  %t150 = getelementptr i8, ptr %t149, i64 %t144
  call void @olang_textcopy(ptr %t150, ptr %t146, i64 %t147)
  %t151 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t149, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t160 = getelementptr %"compiler/api:sig", ptr %l0, i32 0, i32 2
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 1
  %t164 = extractvalue { i64, ptr } %t161, 0
  %t165 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t164)
  call void @olang_textcopy(ptr %t165, ptr %t163, i64 %t164)
  %t166 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = extractvalue { i64, ptr } %t167, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t175 = getelementptr %"compiler/api:sig", ptr %l1, i32 0, i32 2
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 1
  %t179 = extractvalue { i64, ptr } %t176, 0
  %t180 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t178, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = extractvalue { i64, ptr } %t182, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  %t193 = call %"compiler/api:change" @compiler_2fapi_3achange_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, i1 false, { i64, ptr } %t159, { i64, ptr } %t174, { i64, ptr } %t189)
  store %"compiler/api:change" %t193, ptr %l70
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t194 = load %"compiler/api:change", ptr %l70
  store %"compiler/api:change" %t194, ptr %rv
  br label %ret
bb23:
  %t195 = getelementptr %"compiler/api:sig", ptr %l1, i32 0, i32 1
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  %t197 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t200 = extractvalue { i64, ptr } %t196, 1
  %t201 = extractvalue { i64, ptr } %t196, 0
  %t202 = add i64 %t198, %t201
  %t203 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t202)
  call void @olang_textcopy(ptr %t203, ptr %t197, i64 %t198)
  %t204 = getelementptr i8, ptr %t203, i64 %t198
  call void @olang_textcopy(ptr %t204, ptr %t200, i64 %t201)
  %t205 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t203, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = extractvalue { i64, ptr } %t206, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t214 = getelementptr %"compiler/api:sig", ptr %l0, i32 0, i32 2
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = extractvalue { i64, ptr } %t215, 0
  %t219 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t217, i64 %t218)
  %t220 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = extractvalue { i64, ptr } %t221, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t229 = getelementptr %"compiler/api:sig", ptr %l1, i32 0, i32 2
  %t230 = load { i64, ptr }, ptr %t229, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = extractvalue { i64, ptr } %t230, 0
  %t234 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t232, i64 %t233)
  %t235 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = extractvalue { i64, ptr } %t236, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t247 = call %"compiler/api:change" @compiler_2fapi_3achange_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, i1 true, { i64, ptr } %t213, { i64, ptr } %t228, { i64, ptr } %t243)
  store %"compiler/api:change" %t247, ptr %l80
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t248 = load %"compiler/api:change", ptr %l80
  store %"compiler/api:change" %t248, ptr %rv
  br label %ret
bb25:
  %t249 = getelementptr %"compiler/api:sig", ptr %l1, i32 0, i32 1
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  %t252 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t250, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t252, ptr %l82
  br label %bb26
bb26:
  %t253 = load i1, ptr %l82, !tbaa !21
  br i1 %t253, label %bb27, label %bb28
bb27:
  %t254 = getelementptr %"compiler/api:sig", ptr %l0, i32 0, i32 2
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t257 = call { i64, ptr } @compiler_2fapi_2evalueless(ptr %v0, ptr %s0, { i64, ptr } %t255)
  store { i64, ptr } %t257, ptr %l85
  br label %bb29
bb28:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb32
bb29:
  %t258 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 0
  %t260 = extractvalue { i64, ptr } %t258, 1
  %t261 = mul i64 %t259, 1
  %t262 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t261)
  call void @llvm.memcpy.p0.p0.i64(ptr %t262, ptr %t260, i64 %t261, i1 false)
  %t263 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  store { i64, ptr } %t264, ptr %l86, !tbaa !27
  %t265 = getelementptr %"compiler/api:sig", ptr %l1, i32 0, i32 2
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  %t268 = call { i64, ptr } @compiler_2fapi_2evalueless(ptr %v1, ptr %s0, { i64, ptr } %t266)
  store { i64, ptr } %t268, ptr %l88
  br label %bb30
bb30:
  %t269 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  %t271 = extractvalue { i64, ptr } %t269, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  %t276 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t278 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t276, { i64, ptr } %t275)
  store i1 %t278, ptr %l90
  br label %bb31
bb31:
  %t279 = load i1, ptr %l90, !tbaa !21
  store i1 %t279, ptr %l83, !tbaa !21
  br label %bb32
bb32:
  %t280 = load i1, ptr %l83, !tbaa !21
  br i1 %t280, label %bb33, label %bb34
bb33:
  %t281 = getelementptr %"compiler/api:sig", ptr %l0, i32 0, i32 2
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 1
  %t285 = extractvalue { i64, ptr } %t282, 0
  %t286 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t284, i64 %t285)
  %t287 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t291 = extractvalue { i64, ptr } %t288, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t296 = getelementptr %"compiler/api:sig", ptr %l1, i32 0, i32 2
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 1
  %t300 = extractvalue { i64, ptr } %t297, 0
  %t301 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t300)
  call void @olang_textcopy(ptr %t301, ptr %t299, i64 %t300)
  %t302 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t301, 1
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t306 = extractvalue { i64, ptr } %t303, 1
  %t307 = mul i64 %t305, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t307)
  call void @llvm.memcpy.p0.p0.i64(ptr %t308, ptr %t306, i64 %t307, i1 false)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  %t313 = call %"compiler/api:change" @compiler_2fapi_3achange_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, i1 false, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d18, i32 0, i32 1) }, { i64, ptr } %t295, { i64, ptr } %t310)
  store %"compiler/api:change" %t313, ptr %l97
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t314 = load %"compiler/api:change", ptr %l97
  store %"compiler/api:change" %t314, ptr %rv
  br label %ret
bb36:
  %t315 = getelementptr %"compiler/api:sig", ptr %l1, i32 0, i32 1
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  %t317 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t318 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t320 = extractvalue { i64, ptr } %t316, 1
  %t321 = extractvalue { i64, ptr } %t316, 0
  %t322 = add i64 %t318, %t321
  %t323 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t322)
  call void @olang_textcopy(ptr %t323, ptr %t317, i64 %t318)
  %t324 = getelementptr i8, ptr %t323, i64 %t318
  call void @olang_textcopy(ptr %t324, ptr %t320, i64 %t321)
  %t325 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t323, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = extractvalue { i64, ptr } %t326, 1
  %t330 = mul i64 %t328, 1
  %t331 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t330)
  call void @llvm.memcpy.p0.p0.i64(ptr %t331, ptr %t329, i64 %t330, i1 false)
  %t332 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  %t334 = getelementptr %"compiler/api:sig", ptr %l0, i32 0, i32 2
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 1
  %t338 = extractvalue { i64, ptr } %t335, 0
  %t339 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t338)
  call void @olang_textcopy(ptr %t339, ptr %t337, i64 %t338)
  %t340 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t344 = extractvalue { i64, ptr } %t341, 1
  %t345 = mul i64 %t343, 1
  %t346 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t345)
  call void @llvm.memcpy.p0.p0.i64(ptr %t346, ptr %t344, i64 %t345, i1 false)
  %t347 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  %t349 = getelementptr %"compiler/api:sig", ptr %l1, i32 0, i32 2
  %t350 = load { i64, ptr }, ptr %t349, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t350, 1
  %t353 = extractvalue { i64, ptr } %t350, 0
  %t354 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t353)
  call void @olang_textcopy(ptr %t354, ptr %t352, i64 %t353)
  %t355 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t354, 1
  %t358 = extractvalue { i64, ptr } %t356, 0
  %t359 = extractvalue { i64, ptr } %t356, 1
  %t360 = mul i64 %t358, 1
  %t361 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t360)
  call void @llvm.memcpy.p0.p0.i64(ptr %t361, ptr %t359, i64 %t360, i1 false)
  %t362 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  %t367 = call %"compiler/api:change" @compiler_2fapi_3achange_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, i1 true, { i64, ptr } %t333, { i64, ptr } %t348, { i64, ptr } %t363)
  store %"compiler/api:change" %t367, ptr %l107
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  %t368 = load %"compiler/api:change", ptr %l107
  store %"compiler/api:change" %t368, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/api:change", ptr %rv
  ret %"compiler/api:change" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fapi_2ecompare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/api:sig"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/api:sig"
  %l10 = alloca %"compiler/api:sig"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/api:sig"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/api:sig"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca %"compiler/api:sig"
  %l37 = alloca i64
  %l39 = alloca i64
  %l44 = alloca %"compiler/api:sig"
  %l45 = alloca %"compiler/api:sig"
  %l48 = alloca %"compiler/api:sig"
  %l49 = alloca i32
  %l51 = alloca i1
  %l52 = alloca ptr
  %l54 = alloca i1
  %l61 = alloca %"compiler/api:change"
  %l64 = alloca i1
  %l66 = alloca ptr
  %l69 = alloca %"compiler/api:change"
  %l72 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l74 = alloca i64
  %l76 = alloca i64
  %l81 = alloca %"compiler/api:sig"
  %l89 = alloca i64
  %l91 = alloca i64
  %l96 = alloca %"compiler/api:sig"
  %l99 = alloca i1
  %l101 = alloca ptr
  %l108 = alloca %"compiler/api:change"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3achange_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fapi_3asig_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %l19
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t6, ptr %l3
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l5, !tbaa !24
  store i64 %t9, ptr %l21, !tbaa !24
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2eLen_3ccompiler_2fapi_3asig_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l23
  br label %bb4
bb4:
  %t13 = load i64, ptr %l21, !tbaa !24
  %t14 = load i64, ptr %l23, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = call %"compiler/api:sig" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2eAt_3ccompiler_2fapi_3asig_3e(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store %"compiler/api:sig" %t23, ptr %l28
  br label %bb8
bb8:
  %t24 = load %"compiler/api:sig", ptr %l28
  store %"compiler/api:sig" %t24, ptr %l6
  %t25 = getelementptr %"compiler/api:sig", ptr %l6, i32 0, i32 0
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 1
  %t29 = extractvalue { i64, ptr } %t26, 0
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t28, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t40 = load %"compiler/api:sig", ptr %l6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hae803d8bca68916aa9f075d6624b0839(ptr %s0, ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t39, %"compiler/api:sig" %t40)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l5, !tbaa !24
  br label %bb3
bb11:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t50 = load i64, ptr %l8, !tbaa !24
  store i64 %t50, ptr %l37, !tbaa !24
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2eLen_3ccompiler_2fapi_3asig_3e(ptr %v1, ptr %t51)
  store i64 %t53, ptr %l39
  br label %bb13
bb13:
  %t54 = load i64, ptr %l37, !tbaa !24
  %t55 = load i64, ptr %l39, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb14, label %bb15
bb14:
  br label %bb32
bb15:
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l7, !tbaa !29
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = call %"compiler/api:sig" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2eAt_3ccompiler_2fapi_3asig_3e(ptr %v1, ptr %v1, ptr %t60, i64 %t61)
  store %"compiler/api:sig" %t64, ptr %l44
  br label %bb17
bb17:
  %t65 = load %"compiler/api:sig", ptr %l44
  store %"compiler/api:sig" %t65, ptr %l9
  %t66 = getelementptr %"compiler/api:sig", ptr %l9, i32 0, i32 0
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t70 = call { i32, %"compiler/api:sig" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H1e871a75bae078877fd6428e2f181625(ptr %s0, ptr %v1, ptr %s0, ptr %l3, { i64, ptr } %t67)
  %t71 = extractvalue { i32, %"compiler/api:sig" } %t70, 1
  %t72 = extractvalue { i32, %"compiler/api:sig" } %t70, 0
  store i32 %t72, ptr %l49
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb19, label %ok.74, !prof !99
ok.74:
  store %"compiler/api:sig" %t71, ptr %l48
  br label %bb18
bb18:
  %t75 = load %"compiler/api:sig", ptr %l48
  store %"compiler/api:sig" %t75, ptr %l45
  br label %bb24
bb19:
  %t76 = load i32, ptr %l49, !tbaa !23
  %t77 = ashr i32 %t76, 16
  %t79 = icmp eq i32 %t77, 1
  store i1 %t79, ptr %l51, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  %t80 = load ptr, ptr %lp2
  store ptr %t80, ptr %l52, !tbaa !29
  %t81 = getelementptr %"compiler/api:sig", ptr %l9, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = call i1 @compiler_2fapi_2eaddBreaks(ptr %v1, { i64, ptr } %t82)
  store i1 %t84, ptr %l54
  br label %bb21
bb21:
  %t85 = getelementptr %"compiler/api:sig", ptr %l9, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t87 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t90 = extractvalue { i64, ptr } %t86, 1
  %t91 = extractvalue { i64, ptr } %t86, 0
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t87, i64 %t88)
  %t94 = getelementptr i8, ptr %t93, i64 %t88
  call void @olang_textcopy(ptr %t94, ptr %t90, i64 %t91)
  %t95 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = extractvalue { i64, ptr } %t96, 1
  %t100 = mul i64 %t98, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t101, ptr %t99, i64 %t100, i1 false)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t104 = getelementptr %"compiler/api:sig", ptr %l9, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = extractvalue { i64, ptr } %t105, 0
  %t109 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t107, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = extractvalue { i64, ptr } %t111, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t119 = load i1, ptr %l54, !tbaa !21
  %t122 = call %"compiler/api:change" @compiler_2fapi_3achange_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, i1 %t119, { i64, ptr } %t103, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, { i64, ptr } %t118)
  store %"compiler/api:change" %t122, ptr %l61
  br label %bb22
bb22:
  %t123 = load ptr, ptr %l52, !tbaa !29
  %t124 = load %"compiler/api:change", ptr %l61
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3achange_3e_2ePush_3ccompiler_2fapi_3achange_3e(ptr %v2, ptr %v2, ptr %t123, %"compiler/api:change" %t124)
  br label %bb23
bb23:
  br label %bb31
bb24:
  %t125 = load %"compiler/api:sig", ptr %l45
  store %"compiler/api:sig" %t125, ptr %l10
  %t126 = getelementptr %"compiler/api:sig", ptr %l10, i32 0, i32 2
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t128 = getelementptr %"compiler/api:sig", ptr %l9, i32 0, i32 2
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  %t132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t127, { i64, ptr } %t129)
  store i1 %t132, ptr %l64
  br label %bb25
bb25:
  %t133 = load i1, ptr %l64, !tbaa !21
  %t134 = xor i1 %t133, true
  br i1 %t134, label %bb26, label %bb27
bb26:
  %t136 = load ptr, ptr %lp2
  store ptr %t136, ptr %l66, !tbaa !29
  %t137 = load %"compiler/api:sig", ptr %l10
  %t138 = load %"compiler/api:sig", ptr %l9
  %t141 = call %"compiler/api:change" @compiler_2fapi_2echanged(ptr %s0, ptr %v1, ptr %v2, %"compiler/api:sig" %t137, %"compiler/api:sig" %t138)
  store %"compiler/api:change" %t141, ptr %l69
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t142 = load ptr, ptr %l66, !tbaa !29
  %t143 = load %"compiler/api:change", ptr %l69
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3achange_3e_2ePush_3ccompiler_2fapi_3achange_3e(ptr %v2, ptr %v2, ptr %t142, %"compiler/api:change" %t143)
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t144 = load i64, ptr %l8, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l8, !tbaa !24
  br label %bb12
bb32:
  %t148 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t148, ptr %l72
  br label %bb33
bb33:
  %t149 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l72
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t149, ptr %l11
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb34
bb34:
  %t152 = load i64, ptr %l13, !tbaa !24
  store i64 %t152, ptr %l74, !tbaa !24
  %t153 = load ptr, ptr %l12, !tbaa !29
  %t155 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2eLen_3ccompiler_2fapi_3asig_3e(ptr %v1, ptr %t153)
  store i64 %t155, ptr %l76
  br label %bb35
bb35:
  %t156 = load i64, ptr %l74, !tbaa !24
  %t157 = load i64, ptr %l76, !tbaa !24
  %t158 = icmp slt i64 %t156, %t157
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb36, label %bb37
bb36:
  br label %bb42
bb37:
  br label %bb38
bb38:
  %t162 = load ptr, ptr %l12, !tbaa !29
  %t163 = load i64, ptr %l13, !tbaa !24
  %t166 = call %"compiler/api:sig" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2eAt_3ccompiler_2fapi_3asig_3e(ptr %v1, ptr %v1, ptr %t162, i64 %t163)
  store %"compiler/api:sig" %t166, ptr %l81
  br label %bb39
bb39:
  %t167 = load %"compiler/api:sig", ptr %l81
  store %"compiler/api:sig" %t167, ptr %l14
  %t168 = getelementptr %"compiler/api:sig", ptr %l14, i32 0, i32 0
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 1
  %t172 = extractvalue { i64, ptr } %t169, 0
  %t173 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t171, i64 %t172)
  %t174 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %s0, ptr %l11, { i64, ptr } %t182, i1 true)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t185 = load i64, ptr %l13, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l13, !tbaa !24
  br label %bb34
bb42:
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb43
bb43:
  %t191 = load i64, ptr %l16, !tbaa !24
  store i64 %t191, ptr %l89, !tbaa !24
  %t192 = load ptr, ptr %l15, !tbaa !29
  %t194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2eLen_3ccompiler_2fapi_3asig_3e(ptr %v0, ptr %t192)
  store i64 %t194, ptr %l91
  br label %bb44
bb44:
  %t195 = load i64, ptr %l89, !tbaa !24
  %t196 = load i64, ptr %l91, !tbaa !24
  %t197 = icmp slt i64 %t195, %t196
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb45, label %bb46
bb45:
  br label %bb56
bb46:
  br label %bb47
bb47:
  %t201 = load ptr, ptr %l15, !tbaa !29
  %t202 = load i64, ptr %l16, !tbaa !24
  %t205 = call %"compiler/api:sig" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2eAt_3ccompiler_2fapi_3asig_3e(ptr %v0, ptr %v0, ptr %t201, i64 %t202)
  store %"compiler/api:sig" %t205, ptr %l96
  br label %bb48
bb48:
  %t206 = load %"compiler/api:sig", ptr %l96
  store %"compiler/api:sig" %t206, ptr %l17
  %t207 = getelementptr %"compiler/api:sig", ptr %l17, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t211 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s0, ptr %v0, ptr %l11, { i64, ptr } %t208)
  store i1 %t211, ptr %l99
  br label %bb49
bb49:
  %t212 = load i1, ptr %l99, !tbaa !21
  %t213 = xor i1 %t212, true
  br i1 %t213, label %bb50, label %bb51
bb50:
  %t215 = load ptr, ptr %lp2
  store ptr %t215, ptr %l101, !tbaa !29
  %t216 = getelementptr %"compiler/api:sig", ptr %l17, i32 0, i32 1
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  %t218 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t221 = extractvalue { i64, ptr } %t217, 1
  %t222 = extractvalue { i64, ptr } %t217, 0
  %t223 = add i64 %t219, %t222
  %t224 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t223)
  call void @olang_textcopy(ptr %t224, ptr %t218, i64 %t219)
  %t225 = getelementptr i8, ptr %t224, i64 %t219
  call void @olang_textcopy(ptr %t225, ptr %t221, i64 %t222)
  %t226 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t224, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = extractvalue { i64, ptr } %t227, 1
  %t231 = mul i64 %t229, 1
  %t232 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t232, ptr %t230, i64 %t231, i1 false)
  %t233 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  %t235 = getelementptr %"compiler/api:sig", ptr %l17, i32 0, i32 2
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 1
  %t239 = extractvalue { i64, ptr } %t236, 0
  %t240 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t238, i64 %t239)
  %t241 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = extractvalue { i64, ptr } %t242, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  %t252 = call %"compiler/api:change" @compiler_2fapi_3achange_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, i1 true, { i64, ptr } %t234, { i64, ptr } %t249, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store %"compiler/api:change" %t252, ptr %l108
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t253 = load ptr, ptr %l101, !tbaa !29
  %t254 = load %"compiler/api:change", ptr %l108
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3achange_3e_2ePush_3ccompiler_2fapi_3achange_3e(ptr %v2, ptr %v2, ptr %t253, %"compiler/api:change" %t254)
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t255 = load i64, ptr %l16, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l16, !tbaa !24
  br label %bb43
bb56:
  %t259 = load ptr, ptr %lp2
  %t260 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t259
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t260, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fapi_2eentries(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca [2 x { i64, ptr }]
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/text:LineIter"
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca { i64, ptr }
  %l19 = alloca i1
  %l26 = alloca i32
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l37 = alloca i1
  %l40 = alloca %"std/prelude/text:LineIter"
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l46 = alloca i1
  %l48 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l65 = alloca %"compiler/api:sig"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  %t33 = alloca { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, align 8
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t2, ptr %lp4
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t4 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t8 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %a0, 0
  %t10 = insertvalue [2 x { i64, ptr }] %t8, { i64, ptr } %a1, 1
  store [2 x { i64, ptr }] %t10, ptr %l5
  %t13 = insertvalue { i64, ptr } undef, i64 2, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %l5, 1
  %t16 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l17
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t20 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t18)
  store i1 %t20, ptr %l19
  br label %bb3
bb3:
  %t21 = load i1, ptr %l19, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %lp4
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t24
  call void @__olang_scope_close(ptr %s0)
  %t27 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t27, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t32 = ptrtoint ptr %t31 to i64
  %t34 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t33, i32 0, i32 0
  store { i64, ptr } %t28, ptr %t34, !tbaa !28
  %t36 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t33, i32 0, i32 1
  store { i64, ptr } %t29, ptr %t36, !tbaa !28
  %t38 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t33, i32 0, i32 2
  store ptr %a3, ptr %t38, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t40 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t33, i32 0, i32 3
  store ptr %s0, ptr %t40, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t41 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t33, i32 0, i32 4
  store ptr %v2, ptr %t41, !tbaa !28
  call void @__olang_scope_escape(ptr %v3)
  %t42 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t33, i32 0, i32 5
  store ptr %v3, ptr %t42, !tbaa !28
  %t43 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_24, 0
  %t44 = insertvalue { ptr, ptr } %t43, ptr %t33, 1
  %t46 = extractvalue { ptr, ptr } %t44, 0
  %t47 = extractvalue { ptr, ptr } %t44, 1
  %t48 = call i32 @compiler_2fsession_2eInChild(ptr %s0, ptr %t46, ptr %t47)
  store i32 %t48, ptr %l26
  br label %bb7
bb7:
  %t49 = load i32, ptr %l26, !tbaa !23
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t53 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t56 = extractvalue { i64, ptr } %t52, 1
  %t57 = extractvalue { i64, ptr } %t52, 0
  %t58 = add i64 %t54, %t57
  %t59 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t53, i64 %t54)
  %t63 = getelementptr i8, ptr %t62, i64 %t54
  call void @olang_textcopy(ptr %t63, ptr %t56, i64 %t57)
  %t64 = getelementptr i8, ptr %t63, i64 %t57
  call void @olang_textcopy(ptr %t64, ptr %t59, i64 %t60)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = extractvalue { i64, ptr } %t66, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  call void @compiler_2fapi_2esay(ptr %s2, { i64, ptr } %t73)
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t76 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t76, ptr %rv
  br label %ret
bb11:
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t79 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v2, ptr %s0, { i64, ptr } %t77)
  %t80 = extractvalue { i32, { i64, ptr } } %t79, 1
  %t81 = extractvalue { i32, { i64, ptr } } %t79, 0
  store i32 %t81, ptr %l35
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb13, label %ok.83, !prof !99
ok.83:
  store { i64, ptr } %t80, ptr %l34
  br label %bb12
bb12:
  %t84 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t84, ptr %l32, !tbaa !27
  br label %bb15
bb13:
  %t85 = load i32, ptr %l35, !tbaa !23
  %t86 = ashr i32 %t85, 16
  %t88 = icmp eq i32 %t86, 1
  store i1 %t88, ptr %l37, !tbaa !21
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  %t90 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t90, ptr %rv
  br label %ret
bb15:
  %t91 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t94 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t91)
  store %"std/prelude/text:LineIter" %t94, ptr %l40
  br label %bb16
bb16:
  %t95 = load %"std/prelude/text:LineIter", ptr %l40
  store %"std/prelude/text:LineIter" %t95, ptr %l8
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l8)
  %t98 = extractvalue { i32, { i64, ptr } } %t97, 1
  %t99 = extractvalue { i32, { i64, ptr } } %t97, 0
  store i32 %t99, ptr %l44
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb19, label %ok.101, !prof !99
ok.101:
  store { i64, ptr } %t98, ptr %l43
  br label %bb18
bb18:
  %t102 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t102, ptr %l41, !tbaa !27
  br label %bb21
bb19:
  %t103 = load i32, ptr %l44, !tbaa !23
  %t104 = ashr i32 %t103, 16
  %t106 = icmp eq i32 %t104, 1
  store i1 %t106, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb21:
  %t107 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t110 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s6, ptr %s6, { i64, ptr } %t107, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store { i64, ptr } %t110, ptr %l48
  br label %bb22
bb22:
  %t111 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t111, ptr %l10, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t116 = icmp eq i64 %t114, 3
  br i1 %t116, label %bb23, label %bb24
bb23:
  %t118 = load ptr, ptr %lp4
  store ptr %t118, ptr %l52, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t119, ptr %l53, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %t121, i64 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !37
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = extractvalue { i64, ptr } %t123, 0
  %t127 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t126)
  call void @olang_textcopy(ptr %t127, ptr %t125, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = extractvalue { i64, ptr } %t129, 1
  %t133 = mul i64 %t131, 1
  %t134 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  %t137 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t137, ptr %l57, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %t139, i64 1
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !37
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = extractvalue { i64, ptr } %t141, 0
  %t145 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t143, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = extractvalue { i64, ptr } %t147, 1
  %t151 = mul i64 %t149, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t151)
  call void @llvm.memcpy.p0.p0.i64(ptr %t152, ptr %t150, i64 %t151, i1 false)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  %t155 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t155, ptr %l61, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %t157, i64 2
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !37
  %t161 = extractvalue { i64, ptr } %t159, 1
  %t162 = extractvalue { i64, ptr } %t159, 0
  %t163 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t162)
  call void @olang_textcopy(ptr %t163, ptr %t161, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = extractvalue { i64, ptr } %t165, 1
  %t169 = mul i64 %t167, 1
  %t170 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t169)
  call void @llvm.memcpy.p0.p0.i64(ptr %t170, ptr %t168, i64 %t169, i1 false)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  %t176 = call %"compiler/api:sig" @compiler_2fapi_3asig_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t136, { i64, ptr } %t154, { i64, ptr } %t172)
  store %"compiler/api:sig" %t176, ptr %l65
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t177 = load ptr, ptr %l52, !tbaa !29
  %t178 = load %"compiler/api:sig", ptr %l65
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2ePush_3ccompiler_2fapi_3asig_3e(ptr %v4, ptr %v4, ptr %t177, %"compiler/api:sig" %t178)
  br label %bb26
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  br label %bb17
bb29:
  %t179 = load ptr, ptr %lp4
  %t180 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t179
  call void @__olang_scope_close(ptr %s0)
  %t182 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t182, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fapi_2egit(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:Output"
  %l2 = alloca %"std/os:Output"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:Output"
  %l6 = alloca i32
  %l8 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t4 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t3, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t5 = extractvalue { i32, %"std/os:Output" } %t4, 1
  %t6 = extractvalue { i32, %"std/os:Output" } %t4, 0
  store i32 %t6, ptr %l6
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store %"std/os:Output" %t5, ptr %l5
  br label %bb1
bb1:
  %t9 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t9, ptr %l2
  br label %bb4
bb2:
  %t10 = load i32, ptr %l6, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  %t15 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t15, ptr %rv
  br label %ret
bb4:
  %t16 = load %"std/os:Output", ptr %l2
  store %"std/os:Output" %t16, ptr %l1
  %t17 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = icmp ne i32 %t18, 0
  br i1 %t20, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l14, !tbaa !24
  %t25 = load i64, ptr %l14, !tbaa !24
  %t26 = mul i64 %t25, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l15, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = load i64, ptr %l14, !tbaa !24
  %t35 = mul i64 %t34, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %t33, i64 %t35, i1 false)
  %t36 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t36, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t37 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t38 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t37, 1
  store { i32, { i64, ptr } } %t38, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t39 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %s0, ptr %s0, { i64, ptr } %t40)
  store { i64, ptr } %t42, ptr %l17
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  call void @__olang_scope_close(ptr %s0)
  %t50 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t48, 1
  store { i32, { i64, ptr } } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fapi_2eitemKind(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i1
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l38 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t7, ptr %l9
  br label %bb4
bb4:
  %t8 = load i1, ptr %l9, !tbaa !21
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t10, ptr %l11, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l12, !tbaa !24
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l13, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t24, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t28, ptr %l15
  br label %bb9
bb9:
  %t29 = load i1, ptr %l15, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t32, ptr %l18, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l19, !tbaa !24
  %t35 = load i64, ptr %l19, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l20, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l19, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t46, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t49 = insertvalue [5 x { i64, ptr }] %t48, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t50 = insertvalue [5 x { i64, ptr }] %t49, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d38, i32 0, i32 1) }, 2
  %t51 = insertvalue [5 x { i64, ptr }] %t50, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, 3
  %t52 = insertvalue [5 x { i64, ptr }] %t51, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d40, i32 0, i32 1) }, 4
  %t54 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 80, i64 8)
  store [5 x { i64, ptr }] %t52, ptr %t54
  store ptr %t54, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t56 = load ptr, ptr %l1
  store i64 5, ptr %l3, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load i64, ptr %l2, !tbaa !24
  %t60 = load i64, ptr %l3, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb15:
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l1
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = getelementptr [5 x { i64, ptr }], ptr %t67, i64 0, i64 %t68
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !37
  store { i64, ptr } %t72, ptr %l4, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t80 = extractvalue { i64, ptr } %t76, 1
  %t81 = extractvalue { i64, ptr } %t76, 0
  %t82 = add i64 %t78, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t77, i64 %t78)
  %t84 = getelementptr i8, ptr %t83, i64 %t78
  call void @olang_textcopy(ptr %t84, ptr %t80, i64 %t81)
  %t85 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  %t89 = extractvalue { i64, ptr } %t86, 0
  %t90 = extractvalue { i64, ptr } %t86, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  %t97 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s4, { i64, ptr } %t74, { i64, ptr } %t94)
  store i1 %t97, ptr %l38
  br label %bb17
bb17:
  %t98 = load i1, ptr %l38, !tbaa !21
  br i1 %t98, label %bb18, label %bb19
bb18:
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t99, ptr %l40, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l41, !tbaa !24
  %t103 = load i64, ptr %l41, !tbaa !24
  %t104 = mul i64 %t103, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l42, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l41, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  %t114 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t114, ptr %l40, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t115 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t115, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t116 = load i64, ptr %l2, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l2, !tbaa !24
  br label %bb13
bb22:
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l45, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t120, ptr %l46, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l47, !tbaa !24
  %t123 = load i64, ptr %l47, !tbaa !24
  %t124 = mul i64 %t123, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l48, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l47, !tbaa !24
  %t133 = mul i64 %t132, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t129, ptr %t131, i64 %t133, i1 false)
  %t134 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t134, ptr %l46, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t135 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t135, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fapi_2eitemSigs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/doc:Entry"
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca %"compiler/doc:Entry"
  %l31 = alloca %"compiler/doc:Entry"
  %l33 = alloca { i64, ptr }
  %l35 = alloca i1
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t72 = alloca %"compiler/doc:Entry", align 8
  %t75 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/doc:Entry", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @compiler_2fapi_2esigLine(ptr %v1, ptr %s0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l10
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = call { i64, ptr } @compiler_2fapi_2eitemKind(ptr %s0, ptr %s0, { i64, ptr } %t8)
  store { i64, ptr } %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/doc:Entry", ptr %t13, i32 0, i32 2
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %t17, 1
  %t27 = extractvalue { i64, ptr } %t17, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t33 = extractvalue { i64, ptr } %t18, 1
  %t34 = extractvalue { i64, ptr } %t18, 0
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t20, i64 %t21)
  %t40 = getelementptr i8, ptr %t39, i64 %t21
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t26, i64 %t27)
  %t42 = getelementptr i8, ptr %t41, i64 %t27
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t33, i64 %t34)
  %t44 = getelementptr i8, ptr %t43, i64 %t34
  call void @olang_textcopy(ptr %t44, ptr %t36, i64 %t37)
  %t45 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t39, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } %t46, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t12, { i64, ptr } %t53)
  br label %bb3
bb3:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/doc:Entry", ptr %t56, i32 0, i32 5
  store ptr %t58, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load i64, ptr %l5, !tbaa !24
  store i64 %t60, ptr %l22, !tbaa !24
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t61)
  store i64 %t63, ptr %l24
  br label %bb5
bb5:
  %t64 = load i64, ptr %l22, !tbaa !24
  %t65 = load i64, ptr %l24, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb7:
  br label %bb8
bb8:
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t71 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t72, ptr %v1, ptr %v1, ptr %t70, i64 %t71)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t72, i64 152, i1 false)
  br label %bb9
bb9:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t75, ptr %v1, ptr %l29)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t75, i64 152, i1 false)
  br label %bb10
bb10:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l31, i64 152, i1 false)
  %t77 = getelementptr %"compiler/doc:Entry", ptr %l6, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  %t80 = call { i64, ptr } @compiler_2fapi_2esigLine(ptr %v1, ptr %s3, { i64, ptr } %t78)
  store { i64, ptr } %t80, ptr %l33
  br label %bb11
bb11:
  %t81 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t81, ptr %l7, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s3, ptr %s3, { i64, ptr } %t82, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t84, ptr %l35
  br label %bb12
bb12:
  %t85 = load i1, ptr %l35, !tbaa !21
  br i1 %t85, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr %"compiler/doc:Entry", ptr %t87, i32 0, i32 2
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t90, 1
  %t95 = extractvalue { i64, ptr } %t90, 0
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t100 = extractvalue { i64, ptr } %t91, 1
  %t101 = extractvalue { i64, ptr } %t91, 0
  %t102 = add i64 %t98, %t101
  %t103 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t105 = add i64 %t102, %t104
  %t107 = extractvalue { i64, ptr } %t92, 1
  %t108 = extractvalue { i64, ptr } %t92, 0
  %t109 = add i64 %t105, %t108
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t112 = add i64 %t109, %t111
  %t113 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t94, i64 %t95)
  %t114 = getelementptr i8, ptr %t113, i64 %t95
  call void @olang_textcopy(ptr %t114, ptr %t96, i64 %t97)
  %t115 = getelementptr i8, ptr %t114, i64 %t97
  call void @olang_textcopy(ptr %t115, ptr %t100, i64 %t101)
  %t116 = getelementptr i8, ptr %t115, i64 %t101
  call void @olang_textcopy(ptr %t116, ptr %t103, i64 %t104)
  %t117 = getelementptr i8, ptr %t116, i64 %t104
  call void @olang_textcopy(ptr %t117, ptr %t107, i64 %t108)
  %t118 = getelementptr i8, ptr %t117, i64 %t108
  call void @olang_textcopy(ptr %t118, ptr %t110, i64 %t111)
  %t119 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t113, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = extractvalue { i64, ptr } %t120, 1
  %t124 = mul i64 %t122, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t86, { i64, ptr } %t127)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb16:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l43, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr %"compiler/doc:Entry", ptr %t131, i32 0, i32 2
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l45, !tbaa !27
  %t135 = getelementptr %"compiler/doc:Entry", ptr %l6, i32 0, i32 2
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l46, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t139 = getelementptr %"compiler/doc:Entry", ptr %l6, i32 0, i32 6
  %t140 = load i1, ptr %t139, !tbaa !21
  %t144 = call { i64, ptr } @compiler_2fapi_2ememberKind(ptr %s0, ptr %s3, ptr %s3, { i64, ptr } %t137, { i64, ptr } %t138, i1 %t140)
  store { i64, ptr } %t144, ptr %l50
  br label %bb17
bb17:
  %t145 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t152 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = add i64 %t151, %t154
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t158 = add i64 %t155, %t157
  %t159 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t167 = extractvalue { i64, ptr } %t145, 1
  %t168 = extractvalue { i64, ptr } %t145, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t147, i64 %t148)
  %t174 = getelementptr i8, ptr %t173, i64 %t148
  call void @olang_textcopy(ptr %t174, ptr %t149, i64 %t150)
  %t175 = getelementptr i8, ptr %t174, i64 %t150
  call void @olang_textcopy(ptr %t175, ptr %t153, i64 %t154)
  %t176 = getelementptr i8, ptr %t175, i64 %t154
  call void @olang_textcopy(ptr %t176, ptr %t156, i64 %t157)
  %t177 = getelementptr i8, ptr %t176, i64 %t157
  call void @olang_textcopy(ptr %t177, ptr %t160, i64 %t161)
  %t178 = getelementptr i8, ptr %t177, i64 %t161
  call void @olang_textcopy(ptr %t178, ptr %t163, i64 %t164)
  %t179 = getelementptr i8, ptr %t178, i64 %t164
  call void @olang_textcopy(ptr %t179, ptr %t167, i64 %t168)
  %t180 = getelementptr i8, ptr %t179, i64 %t168
  call void @olang_textcopy(ptr %t180, ptr %t170, i64 %t171)
  %t181 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t173, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = extractvalue { i64, ptr } %t182, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  %t190 = load ptr, ptr %l43, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t190, { i64, ptr } %t189)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t192 = load i64, ptr %l5, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l5, !tbaa !24
  br label %bb4
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fapi_2eitems(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i8
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l20 = alloca i64
  %l38 = alloca { i64, ptr }
  %l43 = alloca i1
  %l46 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l66 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l78 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l100 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l17, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb48
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l9, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t56
  %t61 = load i8, ptr %t60, !tbaa !32
  store i8 %t61, ptr %l10, !tbaa !22
  %t63 = load i8, ptr %l10, !tbaa !22
  %t65 = icmp eq i8 %t63, 40
  br i1 %t65, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb14
bb13:
  %t67 = load i8, ptr %l10, !tbaa !22
  %t69 = icmp eq i8 %t67, 60
  store i1 %t69, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t71 = load i1, ptr %l43, !tbaa !21
  br i1 %t71, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  %t72 = load i8, ptr %l10, !tbaa !22
  %t74 = icmp eq i8 %t72, 91
  store i1 %t74, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l46, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t77 = load i64, ptr %l2, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l2, !tbaa !24
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t81 = load i8, ptr %l10, !tbaa !22
  %t83 = icmp eq i8 %t81, 41
  br i1 %t83, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  %t85 = load i8, ptr %l10, !tbaa !22
  %t87 = icmp eq i8 %t85, 62
  store i1 %t87, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t89 = load i1, ptr %l53, !tbaa !21
  br i1 %t89, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb26
bb25:
  %t90 = load i8, ptr %l10, !tbaa !22
  %t92 = icmp eq i8 %t90, 93
  store i1 %t92, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l56, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t97 = icmp sgt i64 %t95, 0
  store i1 %t97, ptr %l59, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb29
bb29:
  %t99 = load i1, ptr %l59, !tbaa !21
  br i1 %t99, label %bb30, label %bb31
bb30:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t102 = sub i64 %t100, 1
  store i64 %t102, ptr %l2, !tbaa !24
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t104 = load i64, ptr %l2, !tbaa !24
  %t106 = icmp eq i64 %t104, 0
  br i1 %t106, label %bb33, label %bb34
bb33:
  %t108 = load i8, ptr %l10, !tbaa !22
  %t110 = icmp eq i8 %t108, 44
  store i1 %t110, ptr %l66, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb35
bb35:
  %t112 = load i1, ptr %l66, !tbaa !21
  br i1 %t112, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s5
  %t113 = load ptr, ptr %lp1
  store ptr %t113, ptr %l69, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t114, ptr %l70, !tbaa !27
  %t115 = load i64, ptr %l3, !tbaa !24
  store i64 %t115, ptr %l71, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  store i64 %t116, ptr %l72, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l73, !tbaa !24
  %t119 = load i64, ptr %l71, !tbaa !24
  %t120 = icmp sge i64 %t119, 0
  br i1 %t120, label %bb38, label %bb39
bb37:
  br label %bb46
bb38:
  %t122 = load i64, ptr %l71, !tbaa !24
  %t123 = load i64, ptr %l72, !tbaa !24
  %t124 = icmp sle i64 %t122, %t123
  br i1 %t124, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_260304cabd5cd416_913b5f9104b1a62)
  unreachable
bb40:
  %t126 = load i64, ptr %l72, !tbaa !24
  %t127 = load i64, ptr %l73, !tbaa !24
  %t128 = icmp sle i64 %t126, %t127
  br i1 %t128, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_260304cabd5cd416_913b5f9104b1a62)
  unreachable
bb42:
  %t130 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l71, !tbaa !24
  %t133 = load i64, ptr %l72, !tbaa !24
  %t134 = getelementptr i8, ptr %t131, i64 %t132
  %t135 = sub i64 %t133, %t132
  %t136 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t134, 1
  %t139 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s5, { i64, ptr } %t137)
  store { i64, ptr } %t139, ptr %l78
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_260304cabd5cd416_913b5f9104b1a62)
  unreachable
bb44:
  %t140 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t141, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t153 = load ptr, ptr %l69, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t153, { i64, ptr } %t152)
  br label %bb45
bb45:
  %t155 = load i64, ptr %l9, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t159 = load i64, ptr %l8, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l8, !tbaa !24
  br label %bb8
bb48:
  %t163 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = load i64, ptr %l3, !tbaa !24
  %t169 = icmp sgt i64 %t165, %t166
  br i1 %t169, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t171 = load ptr, ptr %lp1
  store ptr %t171, ptr %l89, !tbaa !29
  %t172 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t172, ptr %l90, !tbaa !27
  %t173 = load i64, ptr %l3, !tbaa !24
  store i64 %t173, ptr %l91, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t174, 0
  store i64 %t177, ptr %l94, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  store i64 %t179, ptr %l95, !tbaa !24
  %t180 = load i64, ptr %l91, !tbaa !24
  %t181 = icmp sge i64 %t180, 0
  br i1 %t181, label %bb51, label %bb52
bb50:
  br label %bb59
bb51:
  %t183 = load i64, ptr %l91, !tbaa !24
  %t184 = load i64, ptr %l94, !tbaa !24
  %t185 = icmp sle i64 %t183, %t184
  br i1 %t185, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_604929f766c85c73_85c34c9ae6f351df)
  unreachable
bb53:
  %t187 = load i64, ptr %l94, !tbaa !24
  %t188 = load i64, ptr %l95, !tbaa !24
  %t189 = icmp sle i64 %t187, %t188
  br i1 %t189, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_604929f766c85c73_85c34c9ae6f351df)
  unreachable
bb55:
  %t191 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = load i64, ptr %l91, !tbaa !24
  %t194 = load i64, ptr %l94, !tbaa !24
  %t195 = getelementptr i8, ptr %t192, i64 %t193
  %t196 = sub i64 %t194, %t193
  %t197 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t195, 1
  %t200 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s8, { i64, ptr } %t198)
  store { i64, ptr } %t200, ptr %l100
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_604929f766c85c73_85c34c9ae6f351df)
  unreachable
bb57:
  %t201 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t202, i64 %t203)
  %t205 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = extractvalue { i64, ptr } %t206, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t214 = load ptr, ptr %l89, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t214, { i64, ptr } %t213)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s8)
  br label %bb59
bb59:
  %t216 = load ptr, ptr %lp1
  %t218 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t216)
  store { i64, ptr } %t218, ptr %l104
  br label %bb60
bb60:
  %t219 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t219, ptr %l105, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  store i64 %t221, ptr %l106, !tbaa !24
  %t222 = load i64, ptr %l106, !tbaa !24
  %t223 = mul i64 %t222, 16
  %t224 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t223)
  %t225 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  store { i64, ptr } %t226, ptr %l107, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = load i64, ptr %l106, !tbaa !24
  %t232 = mul i64 %t231, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t228, ptr %t230, i64 %t232, i1 false)
  %t233 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t233, ptr %l105, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t234, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fapi_2ememberKind(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br i1 %a2, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %a1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t5, ptr %l6
  br label %bb3
bb3:
  %t6 = load i1, ptr %l6, !tbaa !21
  store i1 %t6, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l9, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t22, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t26, ptr %l13
  br label %bb8
bb8:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t28, ptr %l11, !tbaa !27
  br label %bb27
bb12:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t32, ptr %l17
  br label %bb13
bb13:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t34, ptr %l11, !tbaa !27
  br label %bb27
bb17:
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t36, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t38, ptr %l21
  br label %bb18
bb18:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t40, ptr %l11, !tbaa !27
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t42, ptr %l11, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_2367fe2aaee9c783_ead5253a58acfdcf)
  unreachable
bb27:
  %t44 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l26, !tbaa !24
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l27, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l26, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t57, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fapi_2erowOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l7 = alloca i1
  %l16 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/api:change", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb3
bb3:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/api:change", ptr %t7, i32 0, i32 2
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t12, ptr %l7
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/api:change", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/api:change", ptr %t19, i32 0, i32 3
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t23 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t26 = extractvalue { i64, ptr } %t14, 1
  %t27 = extractvalue { i64, ptr } %t14, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t33 = extractvalue { i64, ptr } %t18, 1
  %t34 = extractvalue { i64, ptr } %t18, 0
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t40 = extractvalue { i64, ptr } %t22, 1
  %t41 = extractvalue { i64, ptr } %t22, 0
  %t42 = add i64 %t38, %t41
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t23, i64 %t24)
  %t47 = getelementptr i8, ptr %t46, i64 %t24
  call void @olang_textcopy(ptr %t47, ptr %t26, i64 %t27)
  %t48 = getelementptr i8, ptr %t47, i64 %t27
  call void @olang_textcopy(ptr %t48, ptr %t29, i64 %t30)
  %t49 = getelementptr i8, ptr %t48, i64 %t30
  call void @olang_textcopy(ptr %t49, ptr %t33, i64 %t34)
  %t50 = getelementptr i8, ptr %t49, i64 %t34
  call void @olang_textcopy(ptr %t50, ptr %t36, i64 %t37)
  %t51 = getelementptr i8, ptr %t50, i64 %t37
  call void @olang_textcopy(ptr %t51, ptr %t40, i64 %t41)
  %t52 = getelementptr i8, ptr %t51, i64 %t41
  call void @olang_textcopy(ptr %t52, ptr %t43, i64 %t44)
  %t53 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t46, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t54, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/api:change", ptr %t56, i32 0, i32 3
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t59, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store i1 %t61, ptr %l16
  br label %bb8
bb8:
  %t62 = load i1, ptr %l16, !tbaa !21
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t63 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/api:change", ptr %t64, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/api:change", ptr %t68, i32 0, i32 2
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t72 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t75 = extractvalue { i64, ptr } %t63, 1
  %t76 = extractvalue { i64, ptr } %t63, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t82 = extractvalue { i64, ptr } %t67, 1
  %t83 = extractvalue { i64, ptr } %t67, 0
  %t84 = add i64 %t80, %t83
  %t85 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t87 = add i64 %t84, %t86
  %t89 = extractvalue { i64, ptr } %t71, 1
  %t90 = extractvalue { i64, ptr } %t71, 0
  %t91 = add i64 %t87, %t90
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t94 = add i64 %t91, %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t72, i64 %t73)
  %t96 = getelementptr i8, ptr %t95, i64 %t73
  call void @olang_textcopy(ptr %t96, ptr %t75, i64 %t76)
  %t97 = getelementptr i8, ptr %t96, i64 %t76
  call void @olang_textcopy(ptr %t97, ptr %t78, i64 %t79)
  %t98 = getelementptr i8, ptr %t97, i64 %t79
  call void @olang_textcopy(ptr %t98, ptr %t82, i64 %t83)
  %t99 = getelementptr i8, ptr %t98, i64 %t83
  call void @olang_textcopy(ptr %t99, ptr %t85, i64 %t86)
  %t100 = getelementptr i8, ptr %t99, i64 %t86
  call void @olang_textcopy(ptr %t100, ptr %t89, i64 %t90)
  %t101 = getelementptr i8, ptr %t100, i64 %t90
  call void @olang_textcopy(ptr %t101, ptr %t92, i64 %t93)
  %t102 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t95, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t103, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t105 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/api:change", ptr %t106, i32 0, i32 1
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/api:change", ptr %t110, i32 0, i32 2
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/api:change", ptr %t114, i32 0, i32 3
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t118 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t121 = extractvalue { i64, ptr } %t105, 1
  %t122 = extractvalue { i64, ptr } %t105, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t128 = extractvalue { i64, ptr } %t109, 1
  %t129 = extractvalue { i64, ptr } %t109, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t135 = extractvalue { i64, ptr } %t113, 1
  %t136 = extractvalue { i64, ptr } %t113, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t142 = extractvalue { i64, ptr } %t117, 1
  %t143 = extractvalue { i64, ptr } %t117, 0
  %t144 = add i64 %t140, %t143
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t118, i64 %t119)
  %t149 = getelementptr i8, ptr %t148, i64 %t119
  call void @olang_textcopy(ptr %t149, ptr %t121, i64 %t122)
  %t150 = getelementptr i8, ptr %t149, i64 %t122
  call void @olang_textcopy(ptr %t150, ptr %t124, i64 %t125)
  %t151 = getelementptr i8, ptr %t150, i64 %t125
  call void @olang_textcopy(ptr %t151, ptr %t128, i64 %t129)
  %t152 = getelementptr i8, ptr %t151, i64 %t129
  call void @olang_textcopy(ptr %t152, ptr %t131, i64 %t132)
  %t153 = getelementptr i8, ptr %t152, i64 %t132
  call void @olang_textcopy(ptr %t153, ptr %t135, i64 %t136)
  %t154 = getelementptr i8, ptr %t153, i64 %t136
  call void @olang_textcopy(ptr %t154, ptr %t138, i64 %t139)
  %t155 = getelementptr i8, ptr %t154, i64 %t139
  call void @olang_textcopy(ptr %t155, ptr %t142, i64 %t143)
  %t156 = getelementptr i8, ptr %t155, i64 %t143
  call void @olang_textcopy(ptr %t156, ptr %t145, i64 %t146)
  %t157 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t148, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t158, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fapi_2esaid(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %a0)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  call void @compiler_2fapi_2esay(ptr %s0, { i64, ptr } %t10)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fapi_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fapi_2eside(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca [5 x { i64, ptr }]
  %l4 = alloca { i64, ptr }
  %l5 = alloca [3 x { i64, ptr }]
  %l6 = alloca { i64, ptr }
  %l7 = alloca [3 x { i64, ptr }]
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca [8 x { i64, ptr }]
  %l11 = alloca [5 x { i64, ptr }]
  %l12 = alloca [2 x { i64, ptr }]
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca { i64, [3 x i64] }
  %l32 = alloca %"compiler/msgs:Msg"
  %l33 = alloca i64
  %l35 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l42 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l50 = alloca i32
  %l52 = alloca i1
  %l56 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i32
  %l66 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l80 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t66 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t1)
  store i1 %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load i1, ptr %l14, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t7, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  call void @__olang_scope_close(ptr %s0)
  %t13 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t11, 1
  store { i32, { i64, ptr } } %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t16, i64 %t17)
  %t22 = getelementptr i8, ptr %t21, i64 %t17
  call void @olang_textcopy(ptr %t22, ptr %t18, i64 %t19)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t21, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = extractvalue { i64, ptr } %t24, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t32 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t33 = insertvalue [5 x { i64, ptr }] %t32, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t34 = insertvalue [5 x { i64, ptr }] %t33, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d81, i32 0, i32 1) }, 2
  %t35 = insertvalue [5 x { i64, ptr }] %t34, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d82, i32 0, i32 1) }, 3
  %t37 = insertvalue [5 x { i64, ptr }] %t35, { i64, ptr } %t31, 4
  store [5 x { i64, ptr }] %t37, ptr %l3
  %t40 = insertvalue { i64, ptr } undef, i64 5, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %l3, 1
  %t43 = call { i32, { i64, ptr } } @compiler_2fapi_2egit(ptr %s0, ptr %s0, { i64, ptr } %t41)
  %t44 = extractvalue { i32, { i64, ptr } } %t43, 1
  %t45 = extractvalue { i32, { i64, ptr } } %t43, 0
  store i32 %t45, ptr %l25
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb6, label %ok.47, !prof !99
ok.47:
  store { i64, ptr } %t44, ptr %l24
  br label %bb5
bb5:
  %t48 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t48, ptr %l17, !tbaa !27
  br label %bb7
bb6:
  %t49 = load i32, ptr %l25, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  call void @__olang_scope_close(ptr %s0)
  %t59 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t57, 0
  store { i32, { i64, ptr } } %t59, ptr %rv
  br label %ret
bb7:
  %t60 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t63, ptr %l28
  br label %bb8
bb8:
  %t64 = load i1, ptr %l28, !tbaa !21
  br i1 %t64, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %a2, ptr %l29, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t68 = load { i64, [3 x i64] }, ptr %t66
  store { i64, [3 x i64] } %t68, ptr %l30
  %t69 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t71 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eApiNoSide(ptr %v0, ptr %s4, { i64, ptr } %t69)
  store %"compiler/msgs:Msg" %t71, ptr %l32
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t72 = load ptr, ptr %l29, !tbaa !29
  %t73 = load { i64, [3 x i64] }, ptr %l30
  %t74 = load %"compiler/msgs:Msg", ptr %l32
  %t75 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v2, ptr %s4, ptr %t72, { i64, [3 x i64] } %t73, %"compiler/msgs:Msg" %t74)
  store i64 %t75, ptr %l33
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t77 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t77, ptr %rv
  br label %ret
bb13:
  %t78 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t79 = insertvalue [3 x { i64, ptr }] %t78, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t80 = insertvalue [3 x { i64, ptr }] %t79, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d86, i32 0, i32 1) }, 2
  store [3 x { i64, ptr }] %t80, ptr %l5
  %t83 = insertvalue { i64, ptr } undef, i64 3, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %l5, 1
  %t86 = call { i32, { i64, ptr } } @compiler_2fapi_2egit(ptr %s0, ptr %s0, { i64, ptr } %t84)
  %t87 = extractvalue { i32, { i64, ptr } } %t86, 1
  %t88 = extractvalue { i32, { i64, ptr } } %t86, 0
  store i32 %t88, ptr %l40
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb15, label %ok.90, !prof !99
ok.90:
  store { i64, ptr } %t87, ptr %l39
  br label %bb14
bb14:
  %t91 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t91, ptr %l35, !tbaa !27
  br label %bb16
bb15:
  %t92 = load i32, ptr %l40, !tbaa !23
  %t93 = lshr i32 %t92, 16
  %t94 = and i32 %t92, 65535
  %t95 = icmp eq i32 %t93, 1
  %t96 = select i1 %t95, i32 1, i32 0
  %t97 = icmp eq i32 %t92, 0
  %t98 = shl i32 %t96, 16
  %t99 = or i32 %t98, %t94
  %t100 = select i1 %t97, i32 0, i32 %t99
  call void @__olang_scope_close(ptr %s0)
  %t102 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t100, 0
  store { i32, { i64, ptr } } %t102, ptr %rv
  br label %ret
bb16:
  %t103 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t103, ptr %l6, !tbaa !27
  %t104 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t105 = insertvalue [3 x { i64, ptr }] %t104, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t106 = insertvalue [3 x { i64, ptr }] %t105, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d89, i32 0, i32 1) }, 2
  store [3 x { i64, ptr }] %t106, ptr %l7
  %t109 = insertvalue { i64, ptr } undef, i64 3, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %l7, 1
  %t112 = call { i32, { i64, ptr } } @compiler_2fapi_2egit(ptr %s0, ptr %s0, { i64, ptr } %t110)
  %t113 = extractvalue { i32, { i64, ptr } } %t112, 1
  %t114 = extractvalue { i32, { i64, ptr } } %t112, 0
  store i32 %t114, ptr %l47
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb18, label %ok.116, !prof !99
ok.116:
  store { i64, ptr } %t113, ptr %l46
  br label %bb17
bb17:
  %t117 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t117, ptr %l42, !tbaa !27
  br label %bb19
bb18:
  %t118 = load i32, ptr %l47, !tbaa !23
  %t119 = lshr i32 %t118, 16
  %t120 = and i32 %t118, 65535
  %t121 = icmp eq i32 %t119, 1
  %t122 = select i1 %t121, i32 1, i32 0
  %t123 = icmp eq i32 %t118, 0
  %t124 = shl i32 %t122, 16
  %t125 = or i32 %t124, %t120
  %t126 = select i1 %t123, i32 0, i32 %t125
  call void @__olang_scope_close(ptr %s0)
  %t128 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t126, 0
  store { i32, { i64, ptr } } %t128, ptr %rv
  br label %ret
bb19:
  %t129 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t129, ptr %l8, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t132 = call i32 @std_2fos_2eMkDirAll(ptr %v1, { i64, ptr } %t130)
  store i32 %t132, ptr %l50
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb21, label %ok.134, !prof !99
ok.134:
  br label %bb20
bb20:
  br label %bb23
bb21:
  %t135 = load i32, ptr %l50, !tbaa !23
  %t136 = ashr i32 %t135, 16
  %t138 = icmp eq i32 %t136, 1
  store i1 %t138, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  %t140 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t140, ptr %rv
  br label %ret
bb23:
  %t141 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = extractvalue { i64, ptr } %t141, 0
  %t145 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t143, i64 %t144)
  %t149 = getelementptr i8, ptr %t148, i64 %t144
  call void @olang_textcopy(ptr %t149, ptr %t145, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t148, 1
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t156 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t157 = insertvalue [8 x { i64, ptr }] %t156, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t159 = insertvalue [8 x { i64, ptr }] %t157, { i64, ptr } %t153, 2
  %t160 = insertvalue [8 x { i64, ptr }] %t159, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d93, i32 0, i32 1) }, 3
  %t161 = insertvalue [8 x { i64, ptr }] %t160, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d94, i32 0, i32 1) }, 4
  %t162 = insertvalue [8 x { i64, ptr }] %t161, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d95, i32 0, i32 1) }, 5
  %t164 = insertvalue [8 x { i64, ptr }] %t162, { i64, ptr } %t154, 6
  %t166 = insertvalue [8 x { i64, ptr }] %t164, { i64, ptr } %t155, 7
  store [8 x { i64, ptr }] %t166, ptr %l10
  %t169 = insertvalue { i64, ptr } undef, i64 8, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %l10, 1
  %t172 = call { i32, { i64, ptr } } @compiler_2fapi_2egit(ptr %s0, ptr %s0, { i64, ptr } %t170)
  %t173 = extractvalue { i32, { i64, ptr } } %t172, 1
  %t174 = extractvalue { i32, { i64, ptr } } %t172, 0
  store i32 %t174, ptr %l64
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb25, label %ok.176, !prof !99
ok.176:
  store { i64, ptr } %t173, ptr %l63
  br label %bb24
bb24:
  %t177 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t177, ptr %l56, !tbaa !27
  br label %bb26
bb25:
  %t178 = load i32, ptr %l64, !tbaa !23
  %t179 = lshr i32 %t178, 16
  %t180 = and i32 %t178, 65535
  %t181 = icmp eq i32 %t179, 1
  %t182 = select i1 %t181, i32 1, i32 0
  %t183 = icmp eq i32 %t178, 0
  %t184 = shl i32 %t182, 16
  %t185 = or i32 %t184, %t180
  %t186 = select i1 %t183, i32 0, i32 %t185
  call void @__olang_scope_close(ptr %s0)
  %t188 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t186, 0
  store { i32, { i64, ptr } } %t188, ptr %rv
  br label %ret
bb26:
  %t189 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t191 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t192 = insertvalue [5 x { i64, ptr }] %t191, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t194 = insertvalue [5 x { i64, ptr }] %t192, { i64, ptr } %t189, 2
  %t195 = insertvalue [5 x { i64, ptr }] %t194, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d98, i32 0, i32 1) }, 3
  %t197 = insertvalue [5 x { i64, ptr }] %t195, { i64, ptr } %t190, 4
  store [5 x { i64, ptr }] %t197, ptr %l11
  %t200 = insertvalue { i64, ptr } undef, i64 5, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %l11, 1
  %t203 = call { i32, { i64, ptr } } @compiler_2fapi_2egit(ptr %s0, ptr %s0, { i64, ptr } %t201)
  %t204 = extractvalue { i32, { i64, ptr } } %t203, 1
  %t205 = extractvalue { i32, { i64, ptr } } %t203, 0
  store i32 %t205, ptr %l73
  %t206 = icmp ne i32 %t205, 0
  br i1 %t206, label %bb28, label %ok.207, !prof !99
ok.207:
  store { i64, ptr } %t204, ptr %l72
  br label %bb27
bb27:
  %t208 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t208, ptr %l66, !tbaa !27
  br label %bb29
bb28:
  %t209 = load i32, ptr %l73, !tbaa !23
  %t210 = lshr i32 %t209, 16
  %t211 = and i32 %t209, 65535
  %t212 = icmp eq i32 %t210, 1
  %t213 = select i1 %t212, i32 1, i32 0
  %t214 = icmp eq i32 %t209, 0
  %t215 = shl i32 %t213, 16
  %t216 = or i32 %t215, %t211
  %t217 = select i1 %t214, i32 0, i32 %t216
  call void @__olang_scope_close(ptr %s0)
  %t219 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t217, 0
  store { i32, { i64, ptr } } %t219, ptr %rv
  br label %ret
bb29:
  %t220 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t221 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t223 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t220, 0
  %t225 = insertvalue [2 x { i64, ptr }] %t223, { i64, ptr } %t221, 1
  store [2 x { i64, ptr }] %t225, ptr %l12
  %t228 = insertvalue { i64, ptr } undef, i64 2, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %l12, 1
  %t231 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %v3, { i64, ptr } %t229)
  store { i64, ptr } %t231, ptr %l80
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t232 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t233 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t232, 1
  store { i32, { i64, ptr } } %t233, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fapi_2esigLine(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l33 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdoc_2ePastAttrs(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) })
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l9
  br label %bb2
bb2:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  store i64 %t17, ptr %l14, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l15, !tbaa !24
  %t22 = icmp sge i64 0, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = icmp sle i64 0, %t24
  br i1 %t25, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_87c5320dd61ccdf_e8122b69ccf346f3)
  unreachable
bb8:
  %t27 = load i64, ptr %l14, !tbaa !24
  %t28 = load i64, ptr %l15, !tbaa !24
  %t29 = icmp sle i64 %t27, %t28
  br i1 %t29, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_87c5320dd61ccdf_e8122b69ccf346f3)
  unreachable
bb10:
  %t31 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l14, !tbaa !24
  %t34 = getelementptr i8, ptr %t32, i64 0
  %t35 = sub i64 %t33, 0
  %t36 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t34, 1
  store { i64, ptr } %t37, ptr %l3, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d100, i32 0, i32 1) })
  %t42 = extractvalue { i32, i64 } %t41, 1
  %t43 = extractvalue { i32, i64 } %t41, 0
  store i32 %t43, ptr %l23
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb13, label %ok.45, !prof !99
ok.45:
  store i64 %t42, ptr %l22
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_87c5320dd61ccdf_e8122b69ccf346f3)
  unreachable
bb12:
  %t46 = load i64, ptr %l22, !tbaa !24
  store i64 %t46, ptr %l20, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l20, !tbaa !24
  br label %bb15
bb15:
  %t51 = load i64, ptr %l20, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t52, ptr %l26, !tbaa !27
  store i64 %t51, ptr %l27, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l28, !tbaa !24
  %t56 = icmp sge i64 0, 0
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t58 = load i64, ptr %l27, !tbaa !24
  %t59 = icmp sle i64 0, %t58
  br i1 %t59, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8bccbc7f06b99562_adcc063d2387be96)
  unreachable
bb18:
  %t61 = load i64, ptr %l27, !tbaa !24
  %t62 = load i64, ptr %l28, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_8bccbc7f06b99562_adcc063d2387be96)
  unreachable
bb20:
  %t65 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l27, !tbaa !24
  %t68 = getelementptr i8, ptr %t66, i64 0
  %t69 = sub i64 %t67, 0
  %t70 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t73 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s0, { i64, ptr } %t71)
  store { i64, ptr } %t73, ptr %l33
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_8bccbc7f06b99562_adcc063d2387be96)
  unreachable
bb22:
  %t74 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t75, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fapi_2esources(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca [2 x { i64, ptr }]
  %l9 = alloca [2 x { i64, ptr }]
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l32 = alloca i1
  %l43 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l50 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l67 = alloca i64
  %l69 = alloca i64
  %l74 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t5)
  store i1 %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load i1, ptr %l15, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %t11)
  store i1 %t13, ptr %l18
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t14 = load i1, ptr %l18, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s1, { i64, ptr } %t15, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t17, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i1, ptr %l21, !tbaa !21
  store i1 %t18, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l19, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  %t20 = load ptr, ptr %lp2
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t23, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t20, { i64, ptr } %t34)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t37 = load ptr, ptr %lp2
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t37
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %rv
  br label %ret
bb14:
  %t40 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t40)
  %t43 = extractvalue { i32, { i64, ptr } } %t42, 1
  %t44 = extractvalue { i32, { i64, ptr } } %t42, 0
  store i32 %t44, ptr %l30
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb16, label %ok.46, !prof !99
ok.46:
  store { i64, ptr } %t43, ptr %l29
  br label %bb15
bb15:
  %t47 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t47, ptr %l27, !tbaa !27
  br label %bb22
bb16:
  %t48 = load i32, ptr %l30, !tbaa !23
  %t49 = ashr i32 %t48, 16
  %t51 = icmp eq i32 %t49, 1
  store i1 %t51, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_ert_req_clear()
  %t52 = icmp sge i64 0, 0
  br i1 %t52, label %bb18, label %bb19
bb18:
  %t54 = icmp sle i64 0, 576460752303423487
  br i1 %t54, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7ad8a062239855c4_5d778575ea84a368)
  unreachable
bb20:
  %t56 = mul i64 0, 16
  %t57 = insertvalue { i64, ptr } undef, i64 0, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t58, ptr %l27, !tbaa !27
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_7ad8a062239855c4_5d778575ea84a368)
  unreachable
bb22:
  %t60 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  store i64 %t65, ptr %l6, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t67 = load i64, ptr %l5, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb25:
  br label %bb26
bb26:
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t75, ptr %l43, !tbaa !27
  %t76 = load i64, ptr %l5, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %t79, i64 %t76
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !37
  store { i64, ptr } %t81, ptr %l7, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s5, { i64, ptr } %t83, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i1 %t85, ptr %l47
  br label %bb27
bb27:
  %t86 = load i1, ptr %l47, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb31
bb29:
  %t87 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s5, { i64, ptr } %t87, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store i1 %t89, ptr %l50
  br label %bb30
bb30:
  %t90 = load i1, ptr %l50, !tbaa !21
  store i1 %t90, ptr %l48, !tbaa !21
  br label %bb31
bb31:
  %t91 = load i1, ptr %l48, !tbaa !21
  br i1 %t91, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb47
bb33:
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t92 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t95 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t92, 0
  %t97 = insertvalue [2 x { i64, ptr }] %t95, { i64, ptr } %t93, 1
  store [2 x { i64, ptr }] %t97, ptr %l8
  %t100 = insertvalue { i64, ptr } undef, i64 2, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %l8, 1
  %t103 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s7, ptr %s7, { i64, ptr } %t101)
  store { i64, ptr } %t103, ptr %l56
  br label %bb35
bb35:
  %t104 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  %t106 = extractvalue { i64, ptr } %t104, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l57, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t114 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t111, 0
  %t116 = insertvalue [2 x { i64, ptr }] %t114, { i64, ptr } %t112, 1
  store [2 x { i64, ptr }] %t116, ptr %l9
  %t119 = insertvalue { i64, ptr } undef, i64 2, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %l9, 1
  %t122 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s7, ptr %s7, { i64, ptr } %t120)
  store { i64, ptr } %t122, ptr %l63
  br label %bb36
bb36:
  %t123 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t132 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fapi_2esources(ptr %s7, ptr %s7, ptr %s7, { i64, ptr } %t130, { i64, ptr } %t129)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %l65
  br label %bb37
bb37:
  %t133 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65
  %t134 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %t134
  store ptr %t134, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb38
bb38:
  %t136 = load i64, ptr %l11, !tbaa !24
  store i64 %t136, ptr %l67, !tbaa !24
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t139 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s7, ptr %t137)
  store i64 %t139, ptr %l69
  br label %bb39
bb39:
  %t140 = load i64, ptr %l67, !tbaa !24
  %t141 = load i64, ptr %l69, !tbaa !24
  %t142 = icmp slt i64 %t140, %t141
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb40, label %bb41
bb40:
  br label %bb46
bb41:
  br label %bb42
bb42:
  %t146 = load ptr, ptr %l10, !tbaa !29
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s7, ptr %s7, ptr %t146, i64 %t147)
  store { i64, ptr } %t150, ptr %l74
  br label %bb43
bb43:
  %t151 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t152 = load ptr, ptr %lp2
  %t155 = extractvalue { i64, ptr } %t151, 1
  %t156 = extractvalue { i64, ptr } %t151, 0
  %t157 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t155, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t152, { i64, ptr } %t166)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t169 = load i64, ptr %l11, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l11, !tbaa !24
  br label %bb38
bb46:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  br label %bb47
bb47:
  %t173 = load i64, ptr %l5, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l5, !tbaa !24
  br label %bb23
bb48:
  %t177 = load ptr, ptr %lp2
  %t178 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t177
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t178, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2fapi_2esplitErrors(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb59
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l56, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = sub i64 %t96, 1
  store i64 %t98, ptr %l1, !tbaa !24
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = icmp eq i8 %t104, 63
  store i1 %t106, ptr %l63, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb34
bb34:
  %t108 = load i1, ptr %l63, !tbaa !21
  br i1 %t108, label %bb35, label %bb36
bb35:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t111 = icmp sgt i64 %t109, 0
  store i1 %t111, ptr %l66, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb37
bb37:
  %t113 = load i1, ptr %l66, !tbaa !21
  br i1 %t113, label %bb38, label %bb39
bb38:
  %t114 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t114, ptr %l70, !tbaa !27
  %t115 = load i64, ptr %l7, !tbaa !24
  %t117 = sub i64 %t115, 1
  %t119 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i8, ptr %t120, i64 %t117
  %t122 = load i8, ptr %t121, !tbaa !32
  %t124 = icmp eq i8 %t122, 32
  store i1 %t124, ptr %l69, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb40
bb40:
  %t126 = load i1, ptr %l69, !tbaa !21
  br i1 %t126, label %bb41, label %bb42
bb41:
  %t127 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t127, ptr %l75, !tbaa !27
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = sub i64 %t128, 1
  store i64 %t130, ptr %l77, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l78, !tbaa !24
  %t133 = icmp sge i64 0, 0
  br i1 %t133, label %bb43, label %bb44
bb42:
  br label %bb57
bb43:
  %t135 = load i64, ptr %l77, !tbaa !24
  %t136 = icmp sle i64 0, %t135
  br i1 %t136, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_d41a7e60632d887_5501c681380c557b)
  unreachable
bb45:
  %t138 = load i64, ptr %l77, !tbaa !24
  %t139 = load i64, ptr %l78, !tbaa !24
  %t140 = icmp sle i64 %t138, %t139
  br i1 %t140, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_d41a7e60632d887_5501c681380c557b)
  unreachable
bb47:
  %t142 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l77, !tbaa !24
  %t145 = getelementptr i8, ptr %t143, i64 0
  %t146 = sub i64 %t144, 0
  %t147 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t145, 1
  %t150 = extractvalue { i64, ptr } %t148, 1
  %t151 = extractvalue { i64, ptr } %t148, 0
  %t152 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t150, i64 %t151)
  %t153 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  store { i64, ptr } %t154, ptr %l83, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t155, ptr %l84, !tbaa !27
  %t156 = load i64, ptr %l7, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l86, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t159, 0
  store i64 %t162, ptr %l89, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l90, !tbaa !24
  %t165 = load i64, ptr %l86, !tbaa !24
  %t166 = icmp sge i64 %t165, 0
  br i1 %t166, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_d41a7e60632d887_5501c681380c557b)
  unreachable
bb49:
  %t168 = load i64, ptr %l86, !tbaa !24
  %t169 = load i64, ptr %l89, !tbaa !24
  %t170 = icmp sle i64 %t168, %t169
  br i1 %t170, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_d41a7e60632d887_5501c681380c557b)
  unreachable
bb51:
  %t172 = load i64, ptr %l89, !tbaa !24
  %t173 = load i64, ptr %l90, !tbaa !24
  %t174 = icmp sle i64 %t172, %t173
  br i1 %t174, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_d41a7e60632d887_5501c681380c557b)
  unreachable
bb53:
  %t176 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = load i64, ptr %l86, !tbaa !24
  %t179 = load i64, ptr %l89, !tbaa !24
  %t180 = getelementptr i8, ptr %t177, i64 %t178
  %t181 = sub i64 %t179, %t178
  %t182 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t180, 1
  %t185 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %t183)
  store { i64, ptr } %t185, ptr %l95
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_d41a7e60632d887_5501c681380c557b)
  unreachable
bb55:
  %t186 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t187 = call { i64, ptr } @compiler_2fapi_2eitems(ptr %v1, ptr %v1, { i64, ptr } %t186)
  store { i64, ptr } %t187, ptr %l96
  br label %bb56
bb56:
  %t188 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t189 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t188, 0
  %t190 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t191 = insertvalue { { i64, ptr }, { i64, ptr } } %t189, { i64, ptr } %t190, 1
  store { { i64, ptr }, { i64, ptr } } %t191, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t193 = load i64, ptr %l6, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l6, !tbaa !24
  br label %bb7
bb59:
  %t197 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 1
  %t200 = extractvalue { i64, ptr } %t197, 0
  %t201 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t200)
  call void @olang_textcopy(ptr %t201, ptr %t199, i64 %t200)
  %t202 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  store { i64, ptr } %t203, ptr %l101, !tbaa !27
  %t204 = icmp sge i64 0, 0
  br i1 %t204, label %bb60, label %bb61
bb60:
  %t206 = icmp sle i64 0, 576460752303423487
  br i1 %t206, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_a3e1d230fee7d732_44f12f5b03cf85de)
  unreachable
bb62:
  %t208 = mul i64 0, 16
  %t209 = insertvalue { i64, ptr } undef, i64 0, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t211 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t212 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t211, 0
  %t214 = insertvalue { { i64, ptr }, { i64, ptr } } %t212, { i64, ptr } %t210, 1
  store { { i64, ptr }, { i64, ptr } } %t214, ptr %rv
  br label %ret
bb63:
  call void @__olang_check_failed(ptr @olang_loc_a3e1d230fee7d732_44f12f5b03cf85de)
  unreachable
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fapi_2esubset(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %t19, i64 %t16
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !37
  %t27 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v1, ptr %v0, { i64, ptr } %a1, { i64, ptr } %t21)
  store i1 %t27, ptr %l18
  br label %bb5
bb5:
  %t28 = load i1, ptr %l18, !tbaa !21
  %t29 = xor i1 %t28, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fapi_2eunion(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l13 = alloca i64
  %l18 = alloca { i64, ptr }
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %a0, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l11, !tbaa !24
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l13
  br label %bb3
bb3:
  %t11 = load i64, ptr %l11, !tbaa !24
  %t12 = load i64, ptr %l13, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t23 = load ptr, ptr %lp2
  %t26 = extractvalue { i64, ptr } %t22, 1
  %t27 = extractvalue { i64, ptr } %t22, 0
  %t28 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t26, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t23, { i64, ptr } %t37)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l4, !tbaa !24
  br label %bb2
bb10:
  store ptr %a1, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t46 = load i64, ptr %l7, !tbaa !24
  store i64 %t46, ptr %l26, !tbaa !24
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t47)
  store i64 %t49, ptr %l28
  br label %bb12
bb12:
  %t50 = load i64, ptr %l26, !tbaa !24
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = icmp slt i64 %t50, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb13, label %bb14
bb13:
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l6, !tbaa !29
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t56, i64 %t57)
  store { i64, ptr } %t60, ptr %l33
  br label %bb16
bb16:
  %t61 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t61, ptr %l8, !tbaa !27
  %t62 = load ptr, ptr %lp2
  %t63 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t66 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v2, ptr %v1, ptr %t62, { i64, ptr } %t63)
  store i1 %t66, ptr %l36
  br label %bb17
bb17:
  %t67 = load i1, ptr %l36, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t70 = load ptr, ptr %lp2
  %t71 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = extractvalue { i64, ptr } %t71, 0
  %t75 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t73, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = extractvalue { i64, ptr } %t77, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t70, { i64, ptr } %t84)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb11
bb23:
  %t91 = load ptr, ptr %lp2
  %t92 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_104, 0
  %t93 = insertvalue { ptr, ptr } %t92, ptr null, 1
  %t96 = extractvalue { ptr, ptr } %t93, 0
  %t97 = extractvalue { ptr, ptr } %t93, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v2, ptr %s0, ptr %t91, ptr %t96, ptr %t97)
  br label %bb24
bb24:
  %t98 = load ptr, ptr %lp2
  %t99 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t98
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fapi_2evalueless(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d105, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  store i64 %t13, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l10, !tbaa !24
  %t18 = icmp sge i64 0, 0
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l9, !tbaa !24
  %t21 = icmp sle i64 0, %t20
  br i1 %t21, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9951d8874535c65a_5b7a0ddb735ab90e)
  unreachable
bb7:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t25 = icmp sle i64 %t23, %t24
  br i1 %t25, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9951d8874535c65a_5b7a0ddb735ab90e)
  unreachable
bb9:
  %t27 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l9, !tbaa !24
  %t30 = getelementptr i8, ptr %t28, i64 0
  %t31 = sub i64 %t29, 0
  %t32 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9951d8874535c65a_5b7a0ddb735ab90e)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fapi_2ewriteSigs(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/doc:Module"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/doc:Entry"
  %l10 = alloca %"compiler/diag:Diagnostics"
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca i1
  %l25 = alloca i1
  %l30 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l42 = alloca ptr
  %l51 = alloca %"compiler/doc:Module"
  %l52 = alloca %"std/prelude/text:StringBuilder"
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"compiler/doc:Entry"
  %l63 = alloca %"compiler/doc:Entry"
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l73 = alloca i32
  %l75 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/diag:Diagnostics", align 8
  %t112 = alloca %"compiler/doc:Entry", align 8
  %t115 = alloca %"compiler/doc:Entry", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t1, ptr %v2, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t1, i64 544, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 544, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %l10, i64 544, i1 false)
  store ptr %t2, ptr %l3, !tbaa !29
  store { i64, ptr } %a0, ptr %l12, !tbaa !27
  store ptr %a2, ptr %l13, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l14, !tbaa !29
  %t7 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15
  %t9 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t8, ptr %t9
  %t10 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = load ptr, ptr %l14, !tbaa !29
  %t14 = call ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t10, ptr %t11, ptr %t12, ptr %t9, i1 true)
  store ptr %t14, ptr %l17
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l17, !tbaa !29
  store ptr %t15, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t16)
  store i64 %t18, ptr %l19
  br label %bb4
bb4:
  %t19 = load i64, ptr %l19, !tbaa !24
  %t20 = icmp sgt i64 %t19, 0
  br i1 %t20, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb7
bb6:
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/session:Analysis", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  store i1 %t27, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l21, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb10
bb9:
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/session:Analysis", ptr %t30, i32 0, i32 2
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  store i1 %t35, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l25, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v2, ptr %s1, ptr %t38)
  store { i64, ptr } %t40, ptr %l30
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t41 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  call void @compiler_2fapi_2esay(ptr %s1, { i64, ptr } %t47)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb15:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/session:Analysis", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_c4a0fad4d32f1d23_28eb6d814d877c07)
  unreachable
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = getelementptr %"compiler/session:Analysis", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l37, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/session:Analysis", ptr %t61, i32 0, i32 2
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = icmp eq ptr %t64, null
  br i1 %t66, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_c4a0fad4d32f1d23_28eb6d814d877c07)
  unreachable
bb20:
  br label %bb21
bb21:
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/session:Analysis", ptr %t68, i32 0, i32 2
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l42, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t74 = getelementptr %"compiler/session:Analysis", ptr %t72, i32 0, i32 3
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  br i1 %t77, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_c4a0fad4d32f1d23_28eb6d814d877c07)
  unreachable
bb23:
  br label %bb24
bb24:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/session:Analysis", ptr %t79, i32 0, i32 3
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load ptr, ptr %l4, !tbaa !29
  %t85 = getelementptr %"compiler/session:Analysis", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/load:Loader", ptr %t86, i32 0, i32 12
  %t89 = load i64, ptr %t88, !tbaa !24
  %t90 = load ptr, ptr %l37, !tbaa !29
  %t91 = load ptr, ptr %l42, !tbaa !29
  %t94 = call %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v2, ptr %v2, ptr %v2, ptr %s0, ptr %t90, ptr %t91, ptr %t82, i64 %t89, i1 false)
  store %"compiler/doc:Module" %t94, ptr %l51
  br label %bb25
bb25:
  %t95 = load %"compiler/doc:Module", ptr %l51
  store %"compiler/doc:Module" %t95, ptr %l5
  %t96 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t96, ptr %l52
  br label %bb26
bb26:
  %t97 = load %"std/prelude/text:StringBuilder", ptr %l52
  store %"std/prelude/text:StringBuilder" %t97, ptr %l6
  %t98 = getelementptr %"compiler/doc:Module", ptr %l5, i32 0, i32 3
  store ptr %t98, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t100 = load i64, ptr %l8, !tbaa !24
  store i64 %t100, ptr %l54, !tbaa !24
  %t101 = load ptr, ptr %l7, !tbaa !29
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %s0, ptr %t101)
  store i64 %t103, ptr %l56
  br label %bb28
bb28:
  %t104 = load i64, ptr %l54, !tbaa !24
  %t105 = load i64, ptr %l56, !tbaa !24
  %t106 = icmp slt i64 %t104, %t105
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb30:
  br label %bb31
bb31:
  %t110 = load ptr, ptr %l7, !tbaa !29
  %t111 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t112, ptr %s0, ptr %s0, ptr %t110, i64 %t111)
  call void @llvm.memmove.p0.p0.i64(ptr %l61, ptr %t112, i64 152, i1 false)
  br label %bb32
bb32:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t115, ptr %s0, ptr %l61)
  call void @llvm.memmove.p0.p0.i64(ptr %l63, ptr %t115, i64 152, i1 false)
  br label %bb33
bb33:
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l63, i64 152, i1 false)
  call void @compiler_2fapi_2eitemSigs(ptr %s0, ptr %s3, ptr %l6, ptr %l9)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l8, !tbaa !24
  br label %bb27
bb36:
  store { i64, ptr } %a1, ptr %l68, !tbaa !27
  %t125 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t125, ptr %l70
  br label %bb37
bb37:
  %t126 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = extractvalue { i64, ptr } %t126, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t134 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t136 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s0, { i64, ptr } %t134, { i64, ptr } %t133)
  store i32 %t136, ptr %l73
  %t137 = icmp ne i32 %t136, 0
  br i1 %t137, label %bb39, label %ok.138, !prof !99
ok.138:
  br label %bb38
bb38:
  br label %bb41
bb39:
  %t139 = load i32, ptr %l73, !tbaa !23
  %t140 = ashr i32 %t139, 16
  %t142 = icmp eq i32 %t140, 1
  store i1 %t142, ptr %l75, !tbaa !21
  br label %bb40
bb40:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb41:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/api:change" @compiler_2fapi_3achange_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/api:change"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/api:change" undef, i1 %a0, 0
  %t12 = insertvalue %"compiler/api:change" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/api:change" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/api:change" %t14, { i64, ptr } %a3, 3
  store %"compiler/api:change" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/api:change", ptr %rv
  ret %"compiler/api:change" %rr
}

define dso_local %"compiler/api:sig" @compiler_2fapi_3asig_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/api:sig"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/api:sig" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/api:sig" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/api:sig" %t10, { i64, ptr } %a2, 2
  store %"compiler/api:sig" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/api:sig", ptr %rv
  ret %"compiler/api:sig" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"olang-api-" }>, align 8
declare void @__olang_ert_req_clear()
@.d2 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"olang: a scratch directory cannot be made\0A" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"old" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"new" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d5 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"old.sigs" }>, align 8
@.d6 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"new.sigs" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d10 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" breaking change" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"case" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"word" }>, align 8
@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"method" }>, align 8
@.d15 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"narrower error set of " }>, align 8
@.d16 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"wider error set of " }>, align 8
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"global" }>, align 8
@.d18 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"value of global" }>, align 8
@.d19 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"changed " }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fapi_3asig_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fapi_3asig_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"added " }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d22 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"removed " }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i32 @olang_lambda_24(ptr %env) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  %cp0 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load { i64, ptr }, ptr %cp1, !tbaa !28
  %cp2 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load ptr, ptr %cp2, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fapi_2ewriteSigs(ptr %vc0, ptr %vc1, ptr %vc2, { i64, ptr } %cv0, { i64, ptr } %cv1, ptr %cv2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

@.d25 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d26 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c" does not check - api compares modules that do\0A" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\09" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d32 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d34 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"global" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"enum" }>, align 8
@.d37 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"error" }>, align 8
@.d38 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"trait" }>, align 8
@.d39 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"struct" }>, align 8
@.d40 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extends" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"type" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\09" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/doc:Entry"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 152, i1 false)
  %t2 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 5
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 7
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"meets " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d47 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"\09meets\09" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\09" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d52 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d53 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d54 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"enum" }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"case" }>, align 8
@.d56 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"error" }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"word" }>, align 8
@.d58 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"trait" }>, align 8
@.d59 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"method" }>, align 8
@.d60 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"field" }>, align 8
@.d61 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"breaking" }>, align 8
@.d62 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ok      " }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d65 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d66 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d68 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d69 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d70 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d71 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d73 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d74 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d75 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d76 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"\0A              now: " }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d78 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"^{commit}" }>, align 8
@.d79 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d80 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"rev-parse" }>, align 8
@.d81 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"--verify" }>, align 8
@.d82 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--quiet" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d85 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"rev-parse" }>, align 8
@.d86 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"--show-toplevel" }>, align 8
@.d87 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d88 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"rev-parse" }>, align 8
@.d89 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"--show-prefix" }>, align 8
@.d90 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tar" }>, align 8
@.d91 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d92 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-C" }>, align 8
@.d93 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"archive" }>, align 8
@.d94 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"--format=tar" }>, align 8
@.d95 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d96 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"tar" }>, align 8
@.d97 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-xf" }>, align 8
@.d98 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-C" }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d100 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"   #" }>, align 8
@.d101 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d102 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d103 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"testdata" }>, align 8
define internal i1 @olang_lambda_104(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eCompare(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = icmp slt i32 %t6, 0
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d105 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/doc:Entry"
  %rv = alloca { i64, ptr }
  %t16 = alloca %"compiler/doc:Entry", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 152
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/doc:Entry", ptr %t14, i64 %t12
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t16, ptr %v0, ptr %t15)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t16, i64 152, i1 false)
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr %"compiler/doc:Entry", ptr %t21, i64 %t19
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %l6, i64 152, i1 false)
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t23, 1
  store i64 %t24, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eApiNoFiles(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3achange_3e_2eLen_3ccompiler_2fapi_3achange_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/api:change" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3achange_3e_2eAt_3ccompiler_2fapi_3achange_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3achange_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2eLen_3ccompiler_2fapi_3asig_3e(ptr %v0, ptr %a0)
declare %"compiler/api:sig" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2eAt_3ccompiler_2fapi_3asig_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hae803d8bca68916aa9f075d6624b0839(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, %"compiler/api:sig" %a2)
declare { i32, %"compiler/api:sig" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H1e871a75bae078877fd6428e2f181625(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3achange_3e_2ePush_3ccompiler_2fapi_3achange_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/api:change" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fsession_2eInChild(ptr %v0, ptr %a0c, ptr %a0e)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fapi_3asig_3e_2ePush_3ccompiler_2fapi_3asig_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/api:sig" %a1)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_260304cabd5cd416_913b5f9104b1a62 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_604929f766c85c73_85c34c9ae6f351df = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_2367fe2aaee9c783_ead5253a58acfdcf = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eApiNoSide(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdoc_2ePastAttrs(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_87c5320dd61ccdf_e8122b69ccf346f3 = external constant [0 x i8]
@olang_loc_8bccbc7f06b99562_adcc063d2387be96 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_7ad8a062239855c4_5d778575ea84a368 = external constant [0 x i8]
@olang_loc_d41a7e60632d887_5501c681380c557b = external constant [0 x i8]
@olang_loc_a3e1d230fee7d732_44f12f5b03cf85de = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
@olang_loc_9951d8874535c65a_5b7a0ddb735ab90e = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, i1 %a4)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
@olang_loc_c4a0fad4d32f1d23_28eb6d814d877c07 = external constant [0 x i8]
declare %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i1 %a4)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fapi_3asig_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare i32 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eCompare(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
