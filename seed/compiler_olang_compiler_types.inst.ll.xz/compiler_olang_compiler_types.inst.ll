; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/list:listState.9783095779ea18337775adeb6569839d" = type { { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, i64, i64, i64 }
%"compiler/types:data" = type { i32, i64, i64, i64, i64, i64 }
%"compiler/types:decl" = type { i64, i32, i32, i32 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" = type { { i64, ptr }, i64, ptr }
%"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" = type { %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr }
%"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" = type { { i64, ptr }, i64 }
%"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" = type { %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr }
%"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" = type { { i64, ptr }, i32 }
%"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68" = type { %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr }
%"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" = type { i32, { i64, ptr } }
%"compiler/types:body" = type { i32, i32, i32, i1, i1 }
%"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2" = type { %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8", ptr }
%"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" = type { i32, %"compiler/types:body" }
%"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de" = type { %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00", ptr }
%"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" = type { %"compiler/types:data", i32 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  ret void
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__H9437066785f0bdbcfc17884fffb14a92(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Ha96ac7e1b060f2f8a9c35aa4bd1fc8d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hcaffdb9d24c80e421d58a725793b74fc(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hf9046546eeaba1d92e03d463169230dc(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  ret void
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_H503e6d35c0db63145eb2ca8ce5f41f51(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_He07f56466a5a9f826ee9e17dcb7906ae(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_Hfe37b7e06e962429d54fa57b80e63073(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  ret void
}

define dso_local i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2eAt_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
  ret i32 %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ePush_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca i64
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t14
  store i32 %t15, ptr %t20, !tbaa !33
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l17
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l17, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l4, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l24, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  store i64 %t50, ptr %l27, !tbaa !24
  %t52 = load i64, ptr %l27, !tbaa !24
  %t53 = load i64, ptr %l27, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t57
  store i32 %t58, ptr %t63, !tbaa !33
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l39 = alloca i64
  %l42 = alloca i64
  %l62 = alloca { i64, ptr }
  %l76 = alloca i64
  %l79 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t44 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t15 = icmp sle i64 0, 2305843009213693951
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_ae6ae33dde1e4099_ce02605783a66c6d)
  unreachable
bb5:
  %t17 = mul i64 0, 4
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_ae6ae33dde1e4099_ce02605783a66c6d)
  unreachable
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 7
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l27, !tbaa !24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l29, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 0
  %t33 = load i32, ptr %t32, !tbaa !33
  store i32 %t33, ptr %l30, !tbaa !23
  %t34 = load i64, ptr %l27, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = icmp sle i64 %t37, 2305843009213693951
  br i1 %t38, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_75439ba5cf39818c_1ee20a1c24d50740)
  unreachable
bb10:
  %t40 = load i64, ptr %l27, !tbaa !24
  %t41 = mul i64 %t40, 4
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  %t43 = load i32, ptr %l30, !tbaa !23
  store i64 0, ptr %t44
  br label %fill.45
fill.45:
  %t48 = load i64, ptr %t44
  %t49 = icmp slt i64 %t48, %t40
  br i1 %t49, label %fillb.46, label %filld.47
fillb.46:
  %t50 = getelementptr i32, ptr %t42, i64 %t48
  store i32 %t43, ptr %t50
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %t44
  br label %fill.45
filld.47:
  %t52 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t42, 1
  store { i64, ptr } %t53, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t55, i32 0, i32 2
  %t58 = load i64, ptr %t57, !tbaa !24
  store i64 %t58, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_75439ba5cf39818c_1ee20a1c24d50740)
  unreachable
bb12:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb17
bb14:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l42, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb16
bb16:
  %t86 = load i64, ptr %l42, !tbaa !24
  store i64 %t86, ptr %l39, !tbaa !24
  br label %bb17
bb17:
  %t87 = load i64, ptr %l39, !tbaa !24
  store i64 %t87, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb20:
  br label %bb21
bb21:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t97 = load i64, ptr %l8, !tbaa !24
  %t98 = load i64, ptr %l6, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l9, !tbaa !24
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t107 = load i64, ptr %l9, !tbaa !24
  %t110 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t106, i64 %t107)
  store { i64, ptr } %t110, ptr %l62
  br label %bb22
bb22:
  %t111 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t111, ptr %l10, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = sub i64 %t120, 1
  %t125 = icmp eq i64 %t116, %t122
  br i1 %t125, label %bb23, label %bb24
bb23:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t127, i32 0, i32 5
  %t130 = load i64, ptr %t129, !tbaa !24
  store i64 %t130, ptr %l11, !tbaa !24
  br label %bb25
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  store i64 %t132, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb26, label %bb27
bb26:
  %t140 = load i64, ptr %l14, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb31
bb28:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l14, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l79, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb30
bb30:
  %t160 = load i64, ptr %l79, !tbaa !24
  store i64 %t160, ptr %l76, !tbaa !24
  br label %bb31
bb31:
  %t161 = load i64, ptr %l76, !tbaa !24
  store i64 %t161, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t162 = load i64, ptr %l16, !tbaa !24
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l17, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t180, ptr %l97, !tbaa !27
  %t181 = load i64, ptr %l3, !tbaa !24
  %t182 = load i64, ptr %l17, !tbaa !24
  %t185 = add i64 %t181, %t182
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t186, ptr %l101, !tbaa !27
  %t187 = load i64, ptr %l17, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i32, ptr %t190, i64 %t187
  %t192 = load i32, ptr %t191, !tbaa !33
  %t195 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 %t185
  store i32 %t192, ptr %t197, !tbaa !33
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  %t198 = load i64, ptr %l16, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l16, !tbaa !24
  br label %bb32
bb37:
  %t202 = load i64, ptr %l3, !tbaa !24
  %t203 = load i64, ptr %l11, !tbaa !24
  %t206 = add i64 %t202, %t203
  store i64 %t206, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb38:
  %t208 = load i64, ptr %l8, !tbaa !24
  %t210 = add i64 %t208, 1
  store i64 %t210, ptr %l8, !tbaa !24
  br label %bb18
bb39:
  %t212 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/types:data" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eAt_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca %"compiler/types:data"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr %"compiler/types:data", ptr %t17, i64 %t14
  %t19 = load %"compiler/types:data", ptr %t18
  store %"compiler/types:data" %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/types:data", ptr %t60, i64 %t57
  %t62 = load %"compiler/types:data", ptr %t61
  store %"compiler/types:data" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:data", ptr %rv
  ret %"compiler/types:data" %rr
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eLen_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ePush_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0, %"compiler/types:data" %a1) #0 {
entry:
  %l1 = alloca %"compiler/types:data"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/types:data" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/types:data", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ftypes_3adata_3e_2egrow_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t18, %"compiler/types:data" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/types:data", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/types:data", ptr %t34, i64 %t29
  store %"compiler/types:data" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca %"compiler/types:decl"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr %"compiler/types:decl", ptr %t17, i64 %t14
  %t19 = load %"compiler/types:decl", ptr %t18
  store %"compiler/types:decl" %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/types:decl", ptr %t60, i64 %t57
  %t62 = load %"compiler/types:decl", ptr %t61
  store %"compiler/types:decl" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:decl", ptr %rv
  ret %"compiler/types:decl" %rr
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eLen_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ePush_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0, %"compiler/types:decl" %a1) #0 {
entry:
  %l1 = alloca %"compiler/types:decl"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/types:decl" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/types:decl", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ftypes_3adecl_3e_2egrow_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t18, %"compiler/types:decl" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/types:decl", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/types:decl", ptr %t34, i64 %t29
  store %"compiler/types:decl" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cArray_3cI64_3e_26_3e_2echunk_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cArray_3cI64_3e_26_3e_2egrow_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cArray_3cstd_2fprelude_2ftext_3_H395d0b4a0ee049b5aba8a05d127a287a(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cArray_3ccompiler_2fsource_3aNa_H70d4606c0570419720f1b9b6aa9e9e01(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cArray_3cstd_2fprelude_2ftext_3_H395d0b4a0ee049b5aba8a05d127a287a(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cArray_3ccompiler_2fsource_3aNa_H72d51cda187b904dfcadabacd051699a(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cArray_3ccompiler_2ftypes_3aTyp_Hb5b6e2012aced595d3535b56d3721cb1(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cArray_3ccompiler_2ftypes_3aTyp_Hdcc5901812a51a1d2e4061576b911940(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cArray_3cstd_2fprelude_2ftext_3_H395d0b4a0ee049b5aba8a05d127a287a(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ftypes_3aListId_3e_2_H3752fd35f93ed741c21b5950d8b55da1(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI32_3e_2egrow_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ftypes_3aListId_3e_2_H7c526e622d15e3e7cc7ac481e205431c(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ftypes_3adata_3e_2ec_H3077f25b471a38455a6036e3ee5a930a(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ftypes_3adata_3e_2egrow_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0, %"compiler/types:data" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/types:data"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/types:data"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/types:data"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/types:data" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/types:data", ptr %l1
  store %"compiler/types:data" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 192153584101141162
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b65ba72fc2f1ee31_fb6768e5a5cc4925)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 48
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/types:data", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/types:data", ptr %t52, i64 %t58
  store %"compiler/types:data" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_b65ba72fc2f1ee31_fb6768e5a5cc4925)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_aff9ecd93f4bce24_e6e0ff61d4d04eb8)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_aff9ecd93f4bce24_e6e0ff61d4d04eb8)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_6127422c0ab09887_c42801d9ffc7f09b)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_6127422c0ab09887_c42801d9ffc7f09b)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/types:data", ptr %l1
  store %"compiler/types:data" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 192153584101141162
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_8e24239d49c69192_77f80809e9492706)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 48
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/types:data", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/types:data", ptr %t251, i64 %t257
  store %"compiler/types:data" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_8e24239d49c69192_77f80809e9492706)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ftypes_3adecl_3e_2ec_Hcc58d5f8b5d69525eb220d3506f847bc(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ftypes_3adecl_3e_2egrow_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0, %"compiler/types:decl" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/types:decl"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/types:decl"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/types:decl"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/types:decl" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/types:decl", ptr %l1
  store %"compiler/types:decl" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 384307168202282325
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_2a2166aadef315_7058a11aac8f2ca9)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 24
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/types:decl", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/types:decl", ptr %t52, i64 %t58
  store %"compiler/types:decl" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2a2166aadef315_7058a11aac8f2ca9)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_f45eee6084f2e728_940aded39d72e1dc)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f45eee6084f2e728_940aded39d72e1dc)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_de7b0e347725a48b_8273211ba2ec0b3f)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_de7b0e347725a48b_8273211ba2ec0b3f)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/types:decl", ptr %l1
  store %"compiler/types:decl" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 384307168202282325
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_c6a84165ebf909f6_cc577b7fbe89806a)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 24
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/types:decl", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/types:decl", ptr %t251, i64 %t257
  store %"compiler/types:decl" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_c6a84165ebf909f6_cc577b7fbe89806a)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cArray_3cI64_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2ftypes_3adata_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2eb_Haa07a9920fb141698122924aee0e618d(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t31, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t34, ptr %l19, !tbaa !27
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t41, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  %t45 = insertvalue { i32, i64 } zeroinitializer, i64 %t43, 1
  store { i32, i64 } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  %t52 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca i1
  %s2 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2eb_Haa07a9920fb141698122924aee0e618d(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l20, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l20, ptr %l22)
  store i1 %t39, ptr %l24
  br label %bb6
bb6:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t45, i32 0, i32 1
  store i64 %t42, ptr %t46, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb11:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t55 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2ea_Heb1c52e0d0131b8f0ddae61b637ef99a(ptr %v0, ptr %v1, ptr %t52, i64 %t53, { i64, ptr } %t54, i64 %t55)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H453784843b408e8ae093d39318df1aed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca i1
  %s2 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2eb_Haa07a9920fb141698122924aee0e618d(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l20, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l20, ptr %l22)
  store i1 %t39, ptr %l24
  br label %bb6
bb6:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t45, i32 0, i32 1
  store i32 %t42, ptr %t46, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb11:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t55 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20compiler_2_He23b092642da66976aca1098dcbe4593(ptr %v0, ptr %v1, ptr %t52, i64 %t53, { i64, ptr } %t54, i32 %t55)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H6f9f964c6e47aa337ef4265757211d88(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2eb_Haa07a9920fb141698122924aee0e618d(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t31, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t34, ptr %l19, !tbaa !27
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  %t45 = insertvalue { i32, i32 } zeroinitializer, i32 %t43, 1
  store { i32, i32 } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  %t52 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H0a665c2b4d7e237317fbcb46f7b513e7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3ccompiler_2ftypes_3aTypeId_Hbb86158fd21d677de6effcf13ad3c770(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t31, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t34, ptr %l19, !tbaa !27
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftypes_3aTypeId_3e_26(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  %t45 = insertvalue { i32, i32 } zeroinitializer, i32 %t43, 1
  store { i32, i32 } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  %t52 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_He4e7022cb78ea4ca3380b08f831d7938(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca i1
  %s2 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3ccompiler_2ftypes_3aTypeId_Hbb86158fd21d677de6effcf13ad3c770(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l20, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftypes_3aTypeId_3e_26(ptr %l20, ptr %l22)
  store i1 %t39, ptr %l24
  br label %bb6
bb6:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t45, i32 0, i32 1
  store i32 %t42, ptr %t46, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb11:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t55 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3ccompiler_2ftypes_3aTypeId_H7baf6c8776d3af678a27580d78dd09e1(ptr %v0, ptr %v1, ptr %t52, i64 %t53, { i64, ptr } %t54, i32 %t55)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6b4c62a37e5c57cb2d11c50f44a997f9(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t10, i32 %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = icmp eq i32 %t33, %t34
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t41, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t43, 1
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb10:
  %t52 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hd895f0b253f779909e5758cb24860698(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t33, i32 0, i32 0
  %t35 = load i32, ptr %t34, !tbaa !23
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = icmp eq i32 %t35, %t36
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t45, i32 0, i32 1
  store { i64, ptr } %t42, ptr %t46, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb10:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i32, ptr %l1, !tbaa !23
  %t55 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20Ar_H55758ae1ae6699a5dd513e5946ec2841(ptr %v0, ptr %v1, ptr %t52, i64 %t53, i32 %t54, { i64, ptr } %t55)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %a0, i32 %a1, %"compiler/types:body" %a2) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:body"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store i32 %a1, ptr %l1
  store %"compiler/types:body" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8", ptr %t33, i32 0, i32 0
  %t35 = load i32, ptr %t34, !tbaa !23
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = icmp eq i32 %t35, %t36
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load %"compiler/types:body", ptr %l2
  %t45 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8", ptr %t45, i32 0, i32 1
  store %"compiler/types:body" %t42, ptr %t46
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb10:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i32, ptr %l1, !tbaa !23
  %t55 = load %"compiler/types:body", ptr %l2
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20co_H2183874486250c2fbb22f5080d2b444e(ptr %v0, ptr %t52, i64 %t53, i32 %t54, %"compiler/types:body" %t55)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/types:body" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hede57d818a9c1e0bef22465b1936f190(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/types:body" }
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t10, i32 %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = icmp eq i32 %t33, %t34
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8", ptr %t41, i32 0, i32 1
  %t43 = load %"compiler/types:body", ptr %t42
  call void @__olang_scope_close(ptr %s2)
  %t45 = insertvalue { i32, %"compiler/types:body" } zeroinitializer, %"compiler/types:body" %t43, 1
  store { i32, %"compiler/types:body" } %t45, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb10:
  %t52 = insertvalue { i32, %"compiler/types:body" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/types:body" } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/types:body" }, ptr %rv
  ret { i32, %"compiler/types:body" } %rr
}

define dso_local { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hde6d536d7268ca732b315d911361d6aa(ptr %v0, ptr %a0, %"compiler/types:data" %a1) #0 {
entry:
  %l1 = alloca %"compiler/types:data"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca %"compiler/types:data"
  %l19 = alloca %"compiler/types:data"
  %l21 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store %"compiler/types:data" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load %"compiler/types:data", ptr %l1
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3adata_2c_20comp_Haec5875a03c283ed01d0ccb5686e3ef6(ptr %v0, ptr %t10, %"compiler/types:data" %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00", ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/types:data", ptr %t32
  store %"compiler/types:data" %t33, ptr %l17
  %t34 = load %"compiler/types:data", ptr %l1
  store %"compiler/types:data" %t34, ptr %l19
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3adata(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00", ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  %t45 = insertvalue { i32, i32 } zeroinitializer, i32 %t43, 1
  store { i32, i32 } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  %t52 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hffc99e12659a835aff737c3e51f11f7b(ptr %v0, ptr %a0, %"compiler/types:data" %a1, i32 %a2) #0 {
entry:
  %l1 = alloca %"compiler/types:data"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l20 = alloca %"compiler/types:data"
  %l22 = alloca %"compiler/types:data"
  %l24 = alloca i1
  %s2 = alloca %olang.scope
  store %"compiler/types:data" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load %"compiler/types:data", ptr %l1
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3adata_2c_20comp_Haec5875a03c283ed01d0ccb5686e3ef6(ptr %v0, ptr %t6, %"compiler/types:data" %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00", ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/types:data", ptr %t34
  store %"compiler/types:data" %t35, ptr %l20
  %t36 = load %"compiler/types:data", ptr %l1
  store %"compiler/types:data" %t36, ptr %l22
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3adata(ptr %l20, ptr %l22)
  store i1 %t39, ptr %l24
  br label %bb6
bb6:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00", ptr %t45, i32 0, i32 1
  store i32 %t42, ptr %t46, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb11:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load %"compiler/types:data", ptr %l1
  %t55 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3adata_2c_20comp_Hbd21a777628a6b1387db0d8cc914ebc5(ptr %v0, ptr %t52, i64 %t53, %"compiler/types:data" %t54, i32 %t55)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H25f20ec7bc3952e7f71d4b5fc38b1e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %r = tail call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H7cdf11fa982e6abfb09bba8099b31363(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  ret { i32, i32 } %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H4604c93a4aa22278631629833c26f586(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Head3ac46f52d9d4661d8417badad2a94(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
  ret void
}

define dso_local { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l19 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t31, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t33, { i64, ptr } %t34)
  store i1 %t37, ptr %l19
  br label %bb6
bb6:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t41, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  %t45 = insertvalue { i32, i64 } zeroinitializer, i64 %t43, 1
  store { i32, i64 } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  %t52 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t35, { i64, ptr } %t36)
  store i1 %t39, ptr %l22
  br label %bb6
bb6:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t45, i32 0, i32 1
  store i64 %t42, ptr %t46, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb11:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t55 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__H6f8d5b6df875cf2fc8b35e7cf5ff7776(ptr %v0, ptr %v1, ptr %t52, i64 %t53, { i64, ptr } %t54, i64 %t55)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2ea_Heb1c52e0d0131b8f0ddae61b637ef99a(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" @std_2fprelude_2fmap_3amapSlot_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v1, ptr %v0, ptr %v0, { i64, ptr } %t15, i64 %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %t30, ptr %l18
  br label %bb3
bb2:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2fmap_3aMapEntry_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v1, ptr %v0, { i64, ptr } %t40, i64 %t41)
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2eg_H00dd73a0c3276b9527cb678881f93acd(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2eb_Haa07a9920fb141698122924aee0e618d(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @olang_2eHelperKind_2eHash_2eArray_3cI64_3e({ i64, ptr } %a1)
  store i64 %t3, ptr %l3
  br label %bb1
bb1:
  %t6 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %a0, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = sub i64 %t9, 1
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = and i64 %t12, %t11
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2eg_H00dd73a0c3276b9527cb678881f93acd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_cca85bf63c0f00d3_511652e6f51d26cf)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_cca85bf63c0f00d3_511652e6f51d26cf)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t100, i32 0, i32 0
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2eb_Haa07a9920fb141698122924aee0e618d(ptr %v0, ptr %v0, ptr %t97, { i64, ptr } %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb15
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20compiler_2_H3775460d3265d8ed73c06ca5eb74de67(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_d8f732a5541499f9_7292a0b8e151f025)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_d8f732a5541499f9_7292a0b8e151f025)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t100, i32 0, i32 0
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2eb_Haa07a9920fb141698122924aee0e618d(ptr %v0, ptr %v0, ptr %t97, { i64, ptr } %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb15
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

@std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20compiler_2_H3e52185f7a69f31d3215733c70caac4e = dso_local alias i64 (ptr, ptr, ptr, { i64, ptr }), ptr @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2eb_Haa07a9920fb141698122924aee0e618d
define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20compiler_2_He23b092642da66976aca1098dcbe4593(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" @std_2fprelude_2fmap_3amapSlot_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v1, ptr %v0, ptr %v0, { i64, ptr } %t15, i32 %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" %t30, ptr %l18
  br label %bb3
bb2:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v1, ptr %v0, { i64, ptr } %t40, i32 %t41)
  store %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20compiler_2_H3775460d3265d8ed73c06ca5eb74de67(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3ccompiler_2ftypes_3aTypeId_H40ba9e1a1e8a571dd00b675fb254134f(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_45eead6db3fccf07_9a5d2a967168878b)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_45eead6db3fccf07_9a5d2a967168878b)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t100, i32 0, i32 0
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3ccompiler_2ftypes_3aTypeId_Hbb86158fd21d677de6effcf13ad3c770(ptr %v0, ptr %v0, ptr %t97, { i64, ptr } %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb15
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3ccompiler_2ftypes_3aTypeId_H7baf6c8776d3af678a27580d78dd09e1(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" @std_2fprelude_2fmap_3amapSlot_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v1, ptr %v0, ptr %v0, { i64, ptr } %t15, i32 %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" %t30, ptr %l18
  br label %bb3
bb2:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v1, ptr %v0, { i64, ptr } %t40, i32 %t41)
  store %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3ccompiler_2ftypes_3aTypeId_H40ba9e1a1e8a571dd00b675fb254134f(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cArray_3ccompiler_2ftypes_3aTypeId_Hbb86158fd21d677de6effcf13ad3c770(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @olang_2eHelperKind_2eHash_2eArray_3ccompiler_2ftypes_3aTypeId_3e({ i64, ptr } %a1)
  store i64 %t3, ptr %l3
  br label %bb1
bb1:
  %t6 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %a0, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = sub i64 %t9, 1
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = and i64 %t12, %t11
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20Ar_H11c15a589a450791f5cfe2e9d2ac02f5(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_75a586d239747118_fb7cb175b601a7c4)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_75a586d239747118_fb7cb175b601a7c4)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t100, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t97, i32 %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb15
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20Ar_H55758ae1ae6699a5dd513e5946ec2841(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load i32, ptr %l2, !tbaa !23
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v1, ptr %v0, ptr %v0, i32 %t15, { i64, ptr } %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68" %t30, ptr %l18
  br label %bb3
bb2:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = call %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v1, ptr %v0, i32 %t40, { i64, ptr } %t41)
  store %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20Ar_H11c15a589a450791f5cfe2e9d2ac02f5(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20Ar_He58c0b21c34fe2695c6573070c48157c(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %a0, i32 %a1)
  ret i64 %r
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20co_H0d115d9c6b8c87897f5fccb978d3c9d3(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %a0, i32 %a1)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20co_H2183874486250c2fbb22f5080d2b444e(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/types:body" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/types:body"
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/types:body" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load i32, ptr %l2, !tbaa !23
  %t16 = load %"compiler/types:body", ptr %l3
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0, ptr %v0, i32 %t15, %"compiler/types:body" %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2" %t30, ptr %l18
  br label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load %"compiler/types:body", ptr %l3
  %t44 = call %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %s2, i32 %t40, %"compiler/types:body" %t41)
  store %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  call void @__olang_scope_close(ptr %s2)
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20co_Ha93527859f9e8cc504f60ad3facfefb7(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20co_Ha93527859f9e8cc504f60ad3facfefb7(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6b228e8e3bb778f6_9ba10c08bed107ca)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6b228e8e3bb778f6_9ba10c08bed107ca)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8", ptr %t100, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t97, i32 %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb15
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3adata_2c_20comp_H3c505efa63029f9d69e9a969815de814(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_734dc814588cfd35_5917b733a7d676b1)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_734dc814588cfd35_5917b733a7d676b1)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00", ptr %t100, i32 0, i32 0
  %t102 = load %"compiler/types:data", ptr %t101
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3adata_2c_20comp_Haec5875a03c283ed01d0ccb5686e3ef6(ptr %v0, ptr %t97, %"compiler/types:data" %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb15
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3adata_2c_20comp_Haec5875a03c283ed01d0ccb5686e3ef6(ptr %v0, ptr %a0, %"compiler/types:data" %a1) #0 {
entry:
  %l2 = alloca %"compiler/types:data"
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/types:data" %a1, ptr %l2
  %t3 = call i64 @olang_2eHelperKind_2eHash_2ecompiler_2ftypes_3adata(ptr %l2)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %a0, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = sub i64 %t9, 1
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = and i64 %t12, %t11
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3adata_2c_20comp_Hbd21a777628a6b1387db0d8cc914ebc5(ptr %v0, ptr %a0, i64 %a1, %"compiler/types:data" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/types:data" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load %"compiler/types:data", ptr %l2
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, ptr %v0, %"compiler/types:data" %t15, i32 %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de" %t30, ptr %l18
  br label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load %"compiler/types:data", ptr %l2
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %s2, %"compiler/types:data" %t40, i32 %t41)
  store %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  call void @__olang_scope_close(ptr %s2)
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3adata_2c_20comp_H3c505efa63029f9d69e9a969815de814(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__H55386d1d5a9fee910e59cedc6f8f41cf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__H6f8d5b6df875cf2fc8b35e7cf5ff7776(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" @std_2fprelude_2fmap_3amapSlot_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v1, ptr %v0, ptr %v0, { i64, ptr } %t15, i64 %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %t30, ptr %l18
  br label %bb3
bb2:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2fmap_3aMapEntry_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v1, ptr %v0, { i64, ptr } %t40, i64 %t41)
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Hc31e2d572160cad57b6a109d58d0b02b(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Ha703e6a05ea609b5ce76533c4aa9480a(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Hb607cf8cfea9e435942a2a7aa285b5e9(ptr %v0, ptr %a0)
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Hbd80e455c9ef463d96d35d5c1f32b3ea(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__H040b1ace6b50ea17a6debe86ca4e7ec3(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3)
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Hc31e2d572160cad57b6a109d58d0b02b(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_b509d27efc810532_83b2149f0073e7e)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b509d27efc810532_83b2149f0073e7e)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t100, i32 0, i32 0
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v0, ptr %t97, { i64, ptr } %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb15
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Hd4cb60f90614005908bf41efbf706214(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  ret i64 %r
}

define dso_local %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2fmap_3aMapEntry_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t6, i64 %a1, 1
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %rv
  ret %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %rr
}

define dso_local %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" @std_2fprelude_2fmap_3aMapEntry_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %r = tail call %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
  ret %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" %r
}

define dso_local %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" @std_2fprelude_2fmap_3aMapEntry_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %r = tail call %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
  ret %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" %r
}

define dso_local %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" undef, i32 %a0, 0
  %t8 = insertvalue %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" %t6, { i64, ptr } %a1, 1
  store %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %rv
  ret %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" %rr
}

define dso_local %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0, i32 %a0, %"compiler/types:body" %a1) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" undef, i32 %a0, 0
  %t8 = insertvalue %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" %t6, %"compiler/types:body" %a1, 1
  store %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8", ptr %rv
  ret %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" %rr
}

define dso_local %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, %"compiler/types:data" %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" undef, %"compiler/types:data" %a0, 0
  %t8 = insertvalue %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" %t6, i32 %a1, 1
  store %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00", ptr %rv
  ret %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" %rr
}

@std_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector = dso_local alias %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" (ptr, ptr, { i64, ptr }, i64), ptr @std_2fprelude_2fmap_3aMapEntry_3cArray_3cI64_3e_26_2c_20I64_3e_2ector
define dso_local %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %r = tail call %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
  ret %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" @std_2fprelude_2fmap_3amapSlot_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l7 = alloca %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381"
  %rv = alloca %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2fmap_3aMapEntry_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0, ptr %v2, { i64, ptr } %a0, i64 %a1)
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %l7
  %t10 = insertvalue %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" undef, %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t6, 0
  %t12 = insertvalue %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %t10, ptr %a2, 1
  store %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %rv
  ret %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %rr
}

define dso_local %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" @std_2fprelude_2fmap_3amapSlot_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, ptr %a2) #0 {
entry:
  %r = tail call %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" @std_2fprelude_2fmap_3amapSlot_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, ptr %a2)
  ret %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" %r
}

define dso_local %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" @std_2fprelude_2fmap_3amapSlot_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, ptr %a2) #0 {
entry:
  %r = tail call %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" @std_2fprelude_2fmap_3amapSlot_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, ptr %a2)
  ret %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" %r
}

define dso_local %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l7 = alloca %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3"
  %rv = alloca %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0, ptr %v2, i32 %a0, { i64, ptr } %a1)
  store %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %l7
  %t10 = insertvalue %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68" undef, %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" %t6, 0
  %t12 = insertvalue %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68" %t10, ptr %a2, 1
  store %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68", ptr %rv
  ret %"std/prelude/map:mapSlot.9fad770fd5413f409faa110922a11f68" %rr
}

define dso_local %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0, ptr %v1, i32 %a0, %"compiler/types:body" %a1, ptr %a2) #0 {
entry:
  %l7 = alloca %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8"
  %rv = alloca %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v1, i32 %a0, %"compiler/types:body" %a1)
  store %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8", ptr %l7
  %t10 = insertvalue %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2" undef, %"std/prelude/map:MapEntry.dabafc827418928f3c6bffdc478ff0c8" %t6, 0
  %t12 = insertvalue %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2" %t10, ptr %a2, 1
  store %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2", ptr %rv
  ret %"std/prelude/map:mapSlot.b3b1e0c5081853e57c7e64cbed1f4ee2" %rr
}

define dso_local %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, ptr %v1, %"compiler/types:data" %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l7 = alloca %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00"
  %rv = alloca %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v1, %"compiler/types:data" %a0, i32 %a1)
  store %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00", ptr %l7
  %t10 = insertvalue %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de" undef, %"std/prelude/map:MapEntry.4eef46dc0972740bf88cdb39cde49e00" %t6, 0
  %t12 = insertvalue %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de" %t10, ptr %a2, 1
  store %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de", ptr %rv
  ret %"std/prelude/map:mapSlot.e9c8a46c6b0027958f6c59791c3fe3de" %rr
}

@std_2fprelude_2fmap_3amapSlot_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector = dso_local alias %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" (ptr, ptr, ptr, { i64, ptr }, i64, ptr), ptr @std_2fprelude_2fmap_3amapSlot_3cArray_3cI64_3e_26_2c_20I64_3e_2ector
define dso_local %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" @std_2fprelude_2fmap_3amapSlot_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, ptr %a2) #0 {
entry:
  %r = tail call %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" @std_2fprelude_2fmap_3amapSlot_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, ptr %a2)
  ret %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca i8
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 %a1
  %t13 = load i8, ptr %t12, !tbaa !32
  store i8 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l1 = alloca i8
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load i8, ptr %l1, !tbaa !22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cU8_3e_2eroom_3cU8_3e(ptr %v0, ptr %t20, i64 %t26, i8 %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load i8, ptr %l1, !tbaa !22
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i8, ptr %t43, i64 %t38
  store i8 %t39, ptr %t44, !tbaa !32
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1, i8 %a2) #0 {
entry:
  %l5 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %a1
  store i8 %a2, ptr %t14, !tbaa !32
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cU8_3e_2eroom_3cU8_3e(ptr %v0, ptr %a0, i64 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i8
  %l50 = alloca i64
  %l53 = alloca i64
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %t68 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store i8 %a2, ptr %l40, !tbaa !22
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = mul i64 %t64, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t65)
  %t67 = load i8, ptr %l40, !tbaa !22
  store i64 0, ptr %t68
  br label %fill.69
fill.69:
  %t72 = load i64, ptr %t68
  %t73 = icmp slt i64 %t72, %t64
  br i1 %t73, label %fillb.70, label %filld.71
fillb.70:
  %t74 = getelementptr i8, ptr %t66, i64 %t72
  store i8 %t67, ptr %t74
  %t75 = add i64 %t72, 1
  store i64 %t75, ptr %t68
  br label %fill.69
filld.71:
  %t76 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t66, 1
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t79, i32 0, i32 0
  store { i64, ptr } %t77, ptr %t80, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t81, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t86, i32 0, i32 1
  %t89 = load i64, ptr %t88, !tbaa !24
  store i64 %t89, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = icmp sgt i64 %t91, %t92
  br i1 %t95, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_82621e7fa771df57_9df77e2c20223e03)
  unreachable
bb15:
  %t97 = load i64, ptr %l8, !tbaa !24
  %t99 = icmp sgt i64 %t97, 0
  br i1 %t99, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb20
bb17:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = sub i64 %t101, %t102
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = add i64 %t105, %t106
  %t111 = sub i64 %t109, 1
  %t112 = load i64, ptr %l8, !tbaa !24
  %t115 = sdiv i64 %t111, %t112
  store i64 %t115, ptr %l53, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb19
bb19:
  %t117 = load i64, ptr %l53, !tbaa !24
  store i64 %t117, ptr %l50, !tbaa !24
  br label %bb20
bb20:
  %t118 = load i64, ptr %l50, !tbaa !24
  store i64 %t118, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t119 = load i64, ptr %l10, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t127 = load i64, ptr %l6, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l8, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t135 = add i64 %t127, %t132
  store i64 %t135, ptr %l11, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t137, ptr %l71, !tbaa !27
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t139, ptr %l73, !tbaa !27
  %t140 = load i64, ptr %l11, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i8, ptr %t143, i64 %t140
  %t145 = load i8, ptr %t144, !tbaa !32
  %t148 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i8, ptr %t149, i64 %t138
  store i8 %t145, ptr %t150, !tbaa !32
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  %t151 = load i64, ptr %l10, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l10, !tbaa !24
  br label %bb21
bb26:
  %t155 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU8_3e_2ector(ptr %v0, i64 %a0)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %t5
  %t8 = insertvalue %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t5, 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU8_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = mul i64 0, 1
  %t4 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t3)
  %t5 = insertvalue { i64, ptr } undef, i64 0, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t4, 1
  %t11 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" undef, { i64, ptr } %t6, 0
  %t13 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t11, i64 0, 1
  %t15 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t13, i64 %a0, 2
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %rv
  br label %ret
bb2:
  call void @__olang_check_failed(ptr @olang_loc_73be79a0f5252363_a20a40abfe5be5cf)
  unreachable
ret:
  %rr = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i1 false, ptr %l4, !tbaa !21
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  %t7 = extractvalue { i64, ptr } zeroinitializer, 0
  %t8 = icmp eq i64 %t6, %t7
  %t9 = extractvalue { i64, ptr } %t5, 1
  %t10 = extractvalue { i64, ptr } zeroinitializer, 1
  %t11 = icmp eq ptr %t9, %t10
  %t12 = and i1 %t8, %t11
  store i1 %t12, ptr %l5, !tbaa !21
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } zeroinitializer, 0
  %t16 = icmp eq i64 %t14, %t15
  %t17 = extractvalue { i64, ptr } %t13, 1
  %t18 = extractvalue { i64, ptr } zeroinitializer, 1
  %t19 = icmp eq ptr %t17, %t18
  %t20 = and i1 %t16, %t19
  store i1 %t20, ptr %l6, !tbaa !21
  %t21 = load i1, ptr %l5, !tbaa !21
  %t22 = load i1, ptr %l6, !tbaa !21
  %t23 = and i1 %t21, %t22
  %t24 = load i1, ptr %l5, !tbaa !21
  %t25 = load i1, ptr %l6, !tbaa !21
  %t26 = or i1 %t24, %t25
  store i1 %t26, ptr %l8, !tbaa !21
  br i1 %t23, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t28 = load i1, ptr %l8, !tbaa !21
  br i1 %t28, label %bb4, label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e({ i64, ptr } %t29, { i64, ptr } %t30)
  store i1 %t33, ptr %l11
  br label %bb5
bb4:
  %t34 = load i1, ptr %l4, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
bb5:
  %t35 = load i1, ptr %l11, !tbaa !21
  store i1 %t35, ptr %l4, !tbaa !21
  br label %bb4
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftypes_3aTypeId_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i1 false, ptr %l4, !tbaa !21
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  %t7 = extractvalue { i64, ptr } zeroinitializer, 0
  %t8 = icmp eq i64 %t6, %t7
  %t9 = extractvalue { i64, ptr } %t5, 1
  %t10 = extractvalue { i64, ptr } zeroinitializer, 1
  %t11 = icmp eq ptr %t9, %t10
  %t12 = and i1 %t8, %t11
  store i1 %t12, ptr %l5, !tbaa !21
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } zeroinitializer, 0
  %t16 = icmp eq i64 %t14, %t15
  %t17 = extractvalue { i64, ptr } %t13, 1
  %t18 = extractvalue { i64, ptr } zeroinitializer, 1
  %t19 = icmp eq ptr %t17, %t18
  %t20 = and i1 %t16, %t19
  store i1 %t20, ptr %l6, !tbaa !21
  %t21 = load i1, ptr %l5, !tbaa !21
  %t22 = load i1, ptr %l6, !tbaa !21
  %t23 = and i1 %t21, %t22
  %t24 = load i1, ptr %l5, !tbaa !21
  %t25 = load i1, ptr %l6, !tbaa !21
  %t26 = or i1 %t24, %t25
  store i1 %t26, ptr %l8, !tbaa !21
  br i1 %t23, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t28 = load i1, ptr %l8, !tbaa !21
  br i1 %t28, label %bb4, label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftypes_3aTypeId_3e({ i64, ptr } %t29, { i64, ptr } %t30)
  store i1 %t33, ptr %l11
  br label %bb5
bb4:
  %t34 = load i1, ptr %l4, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
bb5:
  %t35 = load i1, ptr %l11, !tbaa !21
  store i1 %t35, ptr %l4, !tbaa !21
  br label %bb4
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3adata(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/types:data", ptr %t1, i32 0, i32 0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/types:data", ptr %t3, i32 0, i32 0
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aHelperKind(ptr %t2, ptr %t4)
  store i1 %t7, ptr %l5
  br label %bb2
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb9
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb1
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/types:data", ptr %t9, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/types:data", ptr %t12, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = icmp eq i64 %t11, %t14
  br i1 %t17, label %bb4, label %bb1
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/types:data", ptr %t19, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/types:data", ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23, !tbaa !24
  %t27 = icmp eq i64 %t21, %t24
  br i1 %t27, label %bb5, label %bb1
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/types:data", ptr %t29, i32 0, i32 3
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/types:data", ptr %t32, i32 0, i32 3
  %t34 = load i64, ptr %t33, !tbaa !24
  %t37 = icmp eq i64 %t31, %t34
  br i1 %t37, label %bb6, label %bb1
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/types:data", ptr %t39, i32 0, i32 4
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/types:data", ptr %t42, i32 0, i32 4
  %t44 = load i64, ptr %t43, !tbaa !24
  %t47 = icmp eq i64 %t41, %t44
  br i1 %t47, label %bb7, label %bb1
bb7:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/types:data", ptr %t49, i32 0, i32 5
  %t51 = load i64, ptr %t50, !tbaa !24
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/types:data", ptr %t52, i32 0, i32 5
  %t54 = load i64, ptr %t53, !tbaa !24
  %t57 = icmp eq i64 %t51, %t54
  br i1 %t57, label %bb8, label %bb1
bb8:
  br label %bb9
bb9:
  %t59 = load i1, ptr %l2, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define linkonce_odr i64 @olang_2eHelperKind_2eHash_2eArray_3cI64_3e({ i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp slt i64 %t3, %t4
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i64, ptr %t9, i64 %t7
  %t11 = load i64, ptr %t10, !tbaa !34
  %t13 = mul i64 %t11, -7046029254386353131
  store i64 %t13, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t15 = ashr i64 %t14, 29
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = xor i64 %t16, %t15
  %t19 = load i64, ptr %l1, !tbaa !24
  %t20 = mul i64 %t19, 1099511628211
  %t23 = add i64 %t20, %t18
  store i64 %t23, ptr %l1, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
bb3:
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define linkonce_odr i64 @olang_2eHelperKind_2eHash_2eArray_3ccompiler_2ftypes_3aTypeId_3e({ i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp slt i64 %t3, %t4
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i32, ptr %t9, i64 %t7
  %t11 = load i32, ptr %t10, !tbaa !33
  %t13 = call i64 @std_2fprelude_2fhash_2eI32_2eHash(i32 %t11)
  store i64 %t13, ptr %l6
  br label %bb4
bb3:
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
bb4:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = mul i64 %t15, 1099511628211
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = add i64 %t16, %t18
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = add i64 %t20, 1
  store i64 %t21, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define linkonce_odr i64 @olang_2eHelperKind_2eHash_2ecompiler_2ftypes_3adata(ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/types:data", ptr %t1, i32 0, i32 0
  %t4 = call i64 @olang_2eHelperKind_2eHash_2ecompiler_2fmir_3aHelperKind(ptr %t2)
  store i64 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = mul i64 %t5, 1099511628211
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = add i64 %t6, %t8
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/types:data", ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = mul i64 %t12, -7046029254386353131
  store i64 %t14, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = ashr i64 %t15, 29
  %t17 = load i64, ptr %l6, !tbaa !24
  %t19 = xor i64 %t17, %t16
  %t20 = load i64, ptr %l1, !tbaa !24
  %t21 = mul i64 %t20, 1099511628211
  %t24 = add i64 %t21, %t19
  store i64 %t24, ptr %l1, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/types:data", ptr %t25, i32 0, i32 2
  %t27 = load i64, ptr %t26, !tbaa !24
  %t29 = mul i64 %t27, -7046029254386353131
  store i64 %t29, ptr %l11, !tbaa !24
  %t30 = load i64, ptr %l11, !tbaa !24
  %t31 = ashr i64 %t30, 29
  %t32 = load i64, ptr %l11, !tbaa !24
  %t34 = xor i64 %t32, %t31
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = mul i64 %t35, 1099511628211
  %t39 = add i64 %t36, %t34
  store i64 %t39, ptr %l1, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/types:data", ptr %t40, i32 0, i32 3
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = mul i64 %t42, -7046029254386353131
  store i64 %t44, ptr %l16, !tbaa !24
  %t45 = load i64, ptr %l16, !tbaa !24
  %t46 = ashr i64 %t45, 29
  %t47 = load i64, ptr %l16, !tbaa !24
  %t49 = xor i64 %t47, %t46
  %t50 = load i64, ptr %l1, !tbaa !24
  %t51 = mul i64 %t50, 1099511628211
  %t54 = add i64 %t51, %t49
  store i64 %t54, ptr %l1, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/types:data", ptr %t55, i32 0, i32 4
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = mul i64 %t57, -7046029254386353131
  store i64 %t59, ptr %l21, !tbaa !24
  %t60 = load i64, ptr %l21, !tbaa !24
  %t61 = ashr i64 %t60, 29
  %t62 = load i64, ptr %l21, !tbaa !24
  %t64 = xor i64 %t62, %t61
  %t65 = load i64, ptr %l1, !tbaa !24
  %t66 = mul i64 %t65, 1099511628211
  %t69 = add i64 %t66, %t64
  store i64 %t69, ptr %l1, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/types:data", ptr %t70, i32 0, i32 5
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = mul i64 %t72, -7046029254386353131
  store i64 %t74, ptr %l26, !tbaa !24
  %t75 = load i64, ptr %l26, !tbaa !24
  %t76 = ashr i64 %t75, 29
  %t77 = load i64, ptr %l26, !tbaa !24
  %t79 = xor i64 %t77, %t76
  %t80 = load i64, ptr %l1, !tbaa !24
  %t81 = mul i64 %t80, 1099511628211
  %t84 = add i64 %t81, %t79
  store i64 %t84, ptr %l1, !tbaa !24
  %t85 = load i64, ptr %l1, !tbaa !24
  store i64 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i64, ptr %t15, i64 %t13
  %t17 = load i64, ptr %t16, !tbaa !34
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i64, ptr %t20, i64 %t18
  %t22 = load i64, ptr %t21, !tbaa !34
  %t25 = icmp eq i64 %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftypes_3aTypeId_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i32, ptr %t15, i64 %t13
  %t17 = load i32, ptr %t16, !tbaa !33
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 %t18
  %t22 = load i32, ptr %t21, !tbaa !33
  %t25 = icmp eq i32 %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aHelperKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i64 @olang_2eHelperKind_2eHash_2ecompiler_2fmir_3aHelperKind(ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = mul i64 %t3, -7046029254386353131
  store i64 %t5, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = ashr i64 %t6, 29
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = xor i64 %t8, %t7
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = mul i64 %t11, 1099511628211
  %t15 = add i64 %t12, %t10
  store i64 %t15, ptr %l1, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
@G_2estd_2fprelude_2flist_2efirstChunk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2flist_2ehighBit(i64 %a0)
@G_2estd_2fprelude_2flist_2efirstChunkLog = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_ae6ae33dde1e4099_ce02605783a66c6d = external constant [0 x i8]
@olang_loc_75439ba5cf39818c_1ee20a1c24d50740 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cArray_3cstd_2fprelude_2ftext_3_H395d0b4a0ee049b5aba8a05d127a287a(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI32_3e_2egrow_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b65ba72fc2f1ee31_fb6768e5a5cc4925 = external constant [0 x i8]
@olang_loc_aff9ecd93f4bce24_e6e0ff61d4d04eb8 = external constant [0 x i8]
@olang_loc_6127422c0ab09887_c42801d9ffc7f09b = external constant [0 x i8]
@olang_loc_8e24239d49c69192_77f80809e9492706 = external constant [0 x i8]
@olang_loc_2a2166aadef315_7058a11aac8f2ca9 = external constant [0 x i8]
@olang_loc_f45eee6084f2e728_940aded39d72e1dc = external constant [0 x i8]
@olang_loc_de7b0e347725a48b_8273211ba2ec0b3f = external constant [0 x i8]
@olang_loc_c6a84165ebf909f6_cc577b7fbe89806a = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H7cdf11fa982e6abfb09bba8099b31363(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Head3ac46f52d9d4661d8417badad2a94(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_cca85bf63c0f00d3_511652e6f51d26cf = external constant [0 x i8]
@olang_loc_d8f732a5541499f9_7292a0b8e151f025 = external constant [0 x i8]
declare %"std/prelude/map:mapSlot.06782ed39f42f7125d98657ba03d8a66" @std_2fprelude_2fmap_3amapSlot_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, ptr %a2)
declare %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
@olang_loc_45eead6db3fccf07_9a5d2a967168878b = external constant [0 x i8]
@olang_loc_75a586d239747118_fb7cb175b601a7c4 = external constant [0 x i8]
@olang_loc_6b228e8e3bb778f6_9ba10c08bed107ca = external constant [0 x i8]
@olang_loc_734dc814588cfd35_5917b733a7d676b1 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Hb607cf8cfea9e435942a2a7aa285b5e9(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__H040b1ace6b50ea17a6debe86ca4e7ec3(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3)
@olang_loc_b509d27efc810532_83b2149f0073e7e = external constant [0 x i8]
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
@olang_loc_82621e7fa771df57_9df77e2c20223e03 = external constant [0 x i8]
@olang_loc_73be79a0f5252363_a20a40abfe5be5cf = external constant [0 x i8]
declare i64 @std_2fprelude_2fhash_2eI32_2eHash(i32 %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
