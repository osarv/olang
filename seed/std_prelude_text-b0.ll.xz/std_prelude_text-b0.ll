; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:decimal" = type { { i64, ptr }, { i64, ptr }, i64, i64, i1 }
define dso_local { i32, i64 } @std_2fprelude_2ftext_2eeiselLemire(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, i64 }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i1
  %l22 = alloca i64
  %l26 = alloca i64
  %l42 = alloca { i64, i64 }
  %l48 = alloca i1
  %l59 = alloca { i64, i64 }
  %l75 = alloca i1
  %l79 = alloca i1
  %l92 = alloca i64
  %l102 = alloca i1
  %l106 = alloca i1
  %l111 = alloca i64
  %l130 = alloca i1
  %rv = alloca { i32, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, -348
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sgt i64 %t5, 347
  store i1 %t7, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t11, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load i64, ptr %l0, !tbaa !65
  %t14 = call i64 @std_2fprelude_2ftext_2eleadingZeros(i64 %t12)
  store i64 %t14, ptr %l22
  br label %bb7
bb7:
  %t15 = load i64, ptr %l22, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l0, !tbaa !65
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l26, !tbaa !65
  %t21 = load i64, ptr %l26, !tbaa !65
  %t22 = load i64, ptr %l26, !tbaa !65
  %t23 = shl i64 %t16, %t22
  store i64 %t23, ptr %l0, !tbaa !65
  %t25 = load i64, ptr %l1, !tbaa !24
  %t27 = mul i64 217706, %t25
  %t29 = ashr i64 %t27, 16
  %t31 = add i64 %t29, 64
  %t33 = add i64 %t31, 1023
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = sub i64 %t33, %t34
  store i64 %t37, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l1, !tbaa !24
  %t41 = add i64 %t39, 348
  %t43 = mul i64 %t41, 2
  store i64 %t43, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l0, !tbaa !65
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = getelementptr [1392 x i64], ptr @G_2estd_2fprelude_2ftext_2epow10Mant, i64 0, i64 %t46
  %t49 = load i64, ptr %t48, !tbaa !34
  %t53 = call { i64, i64 } @std_2fprelude_2ftext_2emul128(i64 %t45, i64 %t49)
  store { i64, i64 } %t53, ptr %l42
  br label %bb8
bb8:
  %t54 = load { i64, i64 }, ptr %l42
  store { i64, i64 } %t54, ptr %l5
  %t55 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 0
  %t56 = load i64, ptr %t55, !tbaa !65
  store i64 %t56, ptr %l6, !tbaa !65
  %t58 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !65
  store i64 %t59, ptr %l7, !tbaa !65
  %t61 = load i64, ptr %l6, !tbaa !65
  %t63 = and i64 %t61, 511
  %t65 = icmp eq i64 %t63, 511
  br i1 %t65, label %bb9, label %bb10
bb9:
  %t67 = load i64, ptr %l7, !tbaa !65
  %t68 = load i64, ptr %l0, !tbaa !65
  %t71 = add i64 %t67, %t68
  %t72 = load i64, ptr %l0, !tbaa !65
  %t75 = icmp ult i64 %t71, %t72
  store i1 %t75, ptr %l48, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb11
bb11:
  %t77 = load i1, ptr %l48, !tbaa !21
  br i1 %t77, label %bb12, label %bb13
bb12:
  %t78 = load i64, ptr %l0, !tbaa !65
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = add i64 %t79, 1
  %t83 = getelementptr [1392 x i64], ptr @G_2estd_2fprelude_2ftext_2epow10Mant, i64 0, i64 %t81
  %t84 = load i64, ptr %t83, !tbaa !34
  %t88 = call { i64, i64 } @std_2fprelude_2ftext_2emul128(i64 %t78, i64 %t84)
  store { i64, i64 } %t88, ptr %l59
  br label %bb14
bb13:
  br label %bb27
bb14:
  %t89 = load { i64, i64 }, ptr %l59
  store { i64, i64 } %t89, ptr %l8
  %t90 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t91 = load i64, ptr %t90, !tbaa !65
  %t93 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t94 = load i64, ptr %t93, !tbaa !65
  store i64 %t94, ptr %l10, !tbaa !65
  %t96 = load i64, ptr %l6, !tbaa !65
  store i64 %t96, ptr %l11, !tbaa !65
  %t98 = load i64, ptr %l7, !tbaa !65
  %t102 = add i64 %t98, %t91
  store i64 %t102, ptr %l12, !tbaa !65
  %t104 = load i64, ptr %l12, !tbaa !65
  %t105 = load i64, ptr %l7, !tbaa !65
  %t108 = icmp ult i64 %t104, %t105
  br i1 %t108, label %bb15, label %bb16
bb15:
  %t110 = load i64, ptr %l11, !tbaa !65
  %t113 = add i64 %t110, 1
  store i64 %t113, ptr %l11, !tbaa !65
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t115 = load i64, ptr %l11, !tbaa !65
  %t117 = and i64 %t115, 511
  %t119 = icmp eq i64 %t117, 511
  br i1 %t119, label %bb18, label %bb19
bb18:
  %t121 = load i64, ptr %l12, !tbaa !65
  %t123 = add i64 %t121, 1
  %t125 = icmp eq i64 %t123, 0
  store i1 %t125, ptr %l75, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb20
bb20:
  %t127 = load i1, ptr %l75, !tbaa !21
  br i1 %t127, label %bb21, label %bb22
bb21:
  %t128 = load i64, ptr %l10, !tbaa !65
  %t129 = load i64, ptr %l0, !tbaa !65
  %t132 = add i64 %t128, %t129
  %t133 = load i64, ptr %l0, !tbaa !65
  %t136 = icmp ult i64 %t132, %t133
  store i1 %t136, ptr %l79, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb23
bb23:
  %t138 = load i1, ptr %l79, !tbaa !21
  br i1 %t138, label %bb24, label %bb25
bb24:
  %t140 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t140, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t141 = load i64, ptr %l11, !tbaa !65
  store i64 %t141, ptr %l6, !tbaa !65
  %t143 = load i64, ptr %l12, !tbaa !65
  store i64 %t143, ptr %l7, !tbaa !65
  br label %bb27
bb27:
  %t145 = load i64, ptr %l6, !tbaa !65
  %t147 = lshr i64 %t145, 63
  store i64 %t147, ptr %l13, !tbaa !65
  %t149 = load i64, ptr %l6, !tbaa !65
  %t150 = load i64, ptr %l13, !tbaa !65
  %t152 = add i64 %t150, 9
  store i64 %t152, ptr %l92, !tbaa !65
  %t154 = load i64, ptr %l92, !tbaa !65
  %t155 = load i64, ptr %l92, !tbaa !65
  %t156 = lshr i64 %t149, %t155
  store i64 %t156, ptr %l14, !tbaa !65
  %t158 = load i64, ptr %l3, !tbaa !24
  %t160 = load i64, ptr %l13, !tbaa !65
  %t162 = xor i64 1, %t160
  %t166 = sub i64 %t158, %t162
  store i64 %t166, ptr %l3, !tbaa !24
  %t168 = load i64, ptr %l7, !tbaa !65
  %t170 = icmp eq i64 %t168, 0
  br i1 %t170, label %bb28, label %bb29
bb28:
  %t172 = load i64, ptr %l6, !tbaa !65
  %t174 = and i64 %t172, 511
  %t176 = icmp eq i64 %t174, 0
  store i1 %t176, ptr %l102, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb30
bb30:
  %t178 = load i1, ptr %l102, !tbaa !21
  br i1 %t178, label %bb31, label %bb32
bb31:
  %t179 = load i64, ptr %l14, !tbaa !65
  %t181 = and i64 %t179, 3
  %t183 = icmp eq i64 %t181, 1
  store i1 %t183, ptr %l106, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb33
bb33:
  %t185 = load i1, ptr %l106, !tbaa !21
  br i1 %t185, label %bb34, label %bb35
bb34:
  %t187 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t187, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t188 = load i64, ptr %l14, !tbaa !65
  store i64 %t188, ptr %l111, !tbaa !65
  %t189 = load i64, ptr %l111, !tbaa !65
  %t190 = load i64, ptr %l111, !tbaa !65
  %t192 = and i64 %t190, 1
  %t195 = add i64 %t189, %t192
  store i64 %t195, ptr %l14, !tbaa !65
  %t197 = load i64, ptr %l14, !tbaa !65
  %t200 = lshr i64 %t197, 1
  store i64 %t200, ptr %l14, !tbaa !65
  %t202 = load i64, ptr %l14, !tbaa !65
  %t204 = lshr i64 %t202, 53
  %t206 = icmp ugt i64 %t204, 0
  br i1 %t206, label %bb37, label %bb38
bb37:
  %t208 = load i64, ptr %l14, !tbaa !65
  %t211 = lshr i64 %t208, 1
  store i64 %t211, ptr %l14, !tbaa !65
  %t213 = load i64, ptr %l3, !tbaa !24
  %t216 = add i64 %t213, 1
  store i64 %t216, ptr %l3, !tbaa !24
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t218 = load i64, ptr %l3, !tbaa !24
  %t220 = icmp sle i64 %t218, 0
  br i1 %t220, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb42
bb41:
  %t222 = load i64, ptr %l3, !tbaa !24
  %t224 = icmp sge i64 %t222, 2047
  store i1 %t224, ptr %l130, !tbaa !21
  br label %bb42
bb42:
  %t226 = load i1, ptr %l130, !tbaa !21
  br i1 %t226, label %bb43, label %bb44
bb43:
  %t228 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t228, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t229 = load i64, ptr %l3, !tbaa !24
  %t232 = shl i64 %t229, 52
  %t233 = load i64, ptr %l14, !tbaa !65
  %t235 = and i64 %t233, 4503599627370495
  %t238 = or i64 %t232, %t235
  %t240 = insertvalue { i32, i64 } zeroinitializer, i64 %t238, 1
  store { i32, i64 } %t240, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i64 @std_2fprelude_2ftext_2eleadingZeros(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !65
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 64, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l1, !tbaa !24
  %t6 = load i64, ptr %l0, !tbaa !65
  %t8 = lshr i64 %t6, 32
  %t10 = icmp eq i64 %t8, 0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = add i64 %t12, 32
  store i64 %t15, ptr %l1, !tbaa !24
  %t17 = load i64, ptr %l0, !tbaa !65
  %t20 = shl i64 %t17, 32
  store i64 %t20, ptr %l0, !tbaa !65
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t22 = load i64, ptr %l0, !tbaa !65
  %t24 = lshr i64 %t22, 48
  %t26 = icmp eq i64 %t24, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = add i64 %t28, 16
  store i64 %t31, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l0, !tbaa !65
  %t36 = shl i64 %t33, 16
  store i64 %t36, ptr %l0, !tbaa !65
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t38 = load i64, ptr %l0, !tbaa !65
  %t40 = lshr i64 %t38, 56
  %t42 = icmp eq i64 %t40, 0
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load i64, ptr %l1, !tbaa !24
  %t47 = add i64 %t44, 8
  store i64 %t47, ptr %l1, !tbaa !24
  %t49 = load i64, ptr %l0, !tbaa !65
  %t52 = shl i64 %t49, 8
  store i64 %t52, ptr %l0, !tbaa !65
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t54 = load i64, ptr %l0, !tbaa !65
  %t56 = lshr i64 %t54, 60
  %t58 = icmp eq i64 %t56, 0
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = load i64, ptr %l1, !tbaa !24
  %t63 = add i64 %t60, 4
  store i64 %t63, ptr %l1, !tbaa !24
  %t65 = load i64, ptr %l0, !tbaa !65
  %t68 = shl i64 %t65, 4
  store i64 %t68, ptr %l0, !tbaa !65
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t70 = load i64, ptr %l0, !tbaa !65
  %t72 = lshr i64 %t70, 62
  %t74 = icmp eq i64 %t72, 0
  br i1 %t74, label %bb16, label %bb17
bb16:
  %t76 = load i64, ptr %l1, !tbaa !24
  %t79 = add i64 %t76, 2
  store i64 %t79, ptr %l1, !tbaa !24
  %t81 = load i64, ptr %l0, !tbaa !65
  %t84 = shl i64 %t81, 2
  store i64 %t84, ptr %l0, !tbaa !65
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t86 = load i64, ptr %l0, !tbaa !65
  %t88 = lshr i64 %t86, 63
  %t90 = icmp eq i64 %t88, 0
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = load i64, ptr %l1, !tbaa !24
  %t95 = add i64 %t92, 1
  store i64 %t95, ptr %l1, !tbaa !24
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t97 = load i64, ptr %l1, !tbaa !24
  store i64 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2epadNumber(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i8 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l2, !tbaa !22
  %t3 = icmp ne i8 %t1, 48
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr i8, ptr %t7, i64 0
  %t9 = load i8, ptr %t8, !tbaa !32
  %t11 = icmp ne i8 %t9, 45
  store i1 %t11, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load i8, ptr %l2, !tbaa !22
  %t20 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %t14, i64 %t15, i8 %t16)
  store { i64, ptr } %t20, ptr %l12
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l13, !tbaa !24
  %t23 = load i64, ptr %l13, !tbaa !24
  %t24 = mul i64 %t23, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l14, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l13, !tbaa !24
  %t33 = mul i64 %t32, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t34 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t34, ptr %rv
  br label %ret
bb7:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t35, ptr %l15, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t36, 0
  store i64 %t39, ptr %l18, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l19, !tbaa !24
  %t42 = icmp sge i64 1, 0
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = load i64, ptr %l18, !tbaa !24
  %t45 = icmp sle i64 1, %t44
  br i1 %t45, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a4eada95f0ad22d1_b928dd828664326d)
  unreachable
bb10:
  %t47 = load i64, ptr %l18, !tbaa !24
  %t48 = load i64, ptr %l19, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_a4eada95f0ad22d1_b928dd828664326d)
  unreachable
bb12:
  %t51 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = getelementptr i8, ptr %t52, i64 1
  %t55 = sub i64 %t53, 1
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t58 = load i64, ptr %l1, !tbaa !24
  %t60 = sub i64 %t58, 1
  %t63 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %s0, { i64, ptr } %t57, i64 %t60, i8 48)
  store { i64, ptr } %t63, ptr %l26
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_a4eada95f0ad22d1_b928dd828664326d)
  unreachable
bb14:
  %t64 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l27, !tbaa !24
  %t66 = load i64, ptr %l27, !tbaa !24
  %t67 = mul i64 %t66, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l28, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l27, !tbaa !24
  %t76 = mul i64 %t75, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t72, ptr %t74, i64 %t76, i1 false)
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t79 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t77, i64 %t78)
  %t84 = getelementptr i8, ptr %t83, i64 %t78
  call void @olang_textcopy(ptr %t84, ptr %t80, i64 %t81)
  %t85 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fprelude_2ftext_2erop(i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca { i64, i64 }
  %l4 = alloca i64
  %l5 = alloca { i64, i64 }
  %l8 = alloca i64
  %l12 = alloca { i64, i64 }
  %l16 = alloca { i64, i64 }
  %rv = alloca i64
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr %l2, !tbaa !65
  %t5 = call { i64, i64 } @std_2fprelude_2ftext_2emul128(i64 %a1, i64 %t2)
  store { i64, i64 } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, i64 }, ptr %l12
  store { i64, i64 } %t6, ptr %l3
  %t7 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !65
  store i64 %t8, ptr %l4, !tbaa !65
  %t11 = load i64, ptr %l2, !tbaa !65
  %t14 = call { i64, i64 } @std_2fprelude_2ftext_2emul128(i64 %a0, i64 %t11)
  store { i64, i64 } %t14, ptr %l16
  br label %bb2
bb2:
  %t15 = load { i64, i64 }, ptr %l16
  store { i64, i64 } %t15, ptr %l5
  %t16 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 0
  %t17 = load i64, ptr %t16, !tbaa !65
  %t19 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 1
  %t20 = load i64, ptr %t19, !tbaa !65
  %t24 = lshr i64 %t20, 1
  %t25 = load i64, ptr %l4, !tbaa !65
  %t28 = add i64 %t24, %t25
  store i64 %t28, ptr %l8, !tbaa !65
  %t31 = load i64, ptr %l8, !tbaa !65
  %t33 = lshr i64 %t31, 63
  %t36 = add i64 %t17, %t33
  %t39 = load i64, ptr %l8, !tbaa !65
  %t40 = load i64, ptr @G_2estd_2fprelude_2ftext_2emask63, !tbaa !65
  %t43 = and i64 %t39, %t40
  %t44 = load i64, ptr @G_2estd_2fprelude_2ftext_2emask63, !tbaa !65
  %t47 = add i64 %t43, %t44
  %t49 = lshr i64 %t47, 63
  %t52 = or i64 %t36, %t49
  store i64 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @std_2fprelude_2ftext_2esameLetters(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l21 = alloca { i64, ptr }
  %l25 = alloca i8
  %l26 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp ne i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t28, ptr %l21, !tbaa !27
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i8, ptr %t32, i64 %t29
  %t34 = load i8, ptr %t33, !tbaa !32
  %t38 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t34)
  store i8 %t38, ptr %l25
  br label %bb8
bb8:
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t39, ptr %l26, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i8, ptr %t43, i64 %t40
  %t45 = load i8, ptr %t44, !tbaa !32
  %t46 = load i8, ptr %l25, !tbaa !22
  %t48 = icmp ne i8 %t46, %t45
  br i1 %t48, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t51, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, i64 } @std_2fprelude_2ftext_2eschubfach(i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i1
  %l27 = alloca i64
  %l42 = alloca i1
  %l93 = alloca i64
  %l95 = alloca i64
  %l100 = alloca i64
  %l102 = alloca i64
  %l107 = alloca i64
  %l109 = alloca i64
  %l179 = alloca i1
  %l182 = alloca i1
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !65
  %t3 = and i64 %t1, 1
  store i64 %t3, ptr %l3, !tbaa !65
  %t5 = load i64, ptr %l1, !tbaa !65
  %t7 = shl i64 %t5, 2
  store i64 %t7, ptr %l4, !tbaa !65
  %t9 = load i64, ptr %l4, !tbaa !65
  %t11 = add i64 %t9, 2
  store i64 %t11, ptr %l5, !tbaa !65
  %t13 = load i64, ptr %l4, !tbaa !65
  %t15 = sub i64 %t13, 2
  store i64 %t15, ptr %l6, !tbaa !65
  %t17 = load i64, ptr %l0, !tbaa !24
  %t19 = mul i64 %t17, 661971961083
  %t21 = ashr i64 %t19, 41
  store i64 %t21, ptr %l7, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !65
  %t24 = shl i64 1, 52
  %t27 = icmp eq i64 %t23, %t24
  br i1 %t27, label %bb1, label %bb2
bb1:
  %t29 = load i64, ptr %l0, !tbaa !24
  %t31 = icmp ne i64 %t29, -1074
  store i1 %t31, ptr %l42, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb3
bb3:
  %t33 = load i1, ptr %l42, !tbaa !21
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t34 = load i64, ptr %l4, !tbaa !65
  %t36 = sub i64 %t34, 1
  store i64 %t36, ptr %l6, !tbaa !65
  %t38 = load i64, ptr %l0, !tbaa !24
  %t40 = mul i64 %t38, 661971961083
  %t42 = sub i64 %t40, 274743187321
  %t44 = ashr i64 %t42, 41
  store i64 %t44, ptr %l7, !tbaa !24
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t46 = load i64, ptr %l0, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t49 = sub i64 0, %t47
  %t51 = mul i64 %t49, 913124641741
  %t53 = ashr i64 %t51, 38
  %t56 = add i64 %t46, %t53
  %t58 = add i64 %t56, 2
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = sub i64 348, %t60
  %t64 = mul i64 %t62, 2
  store i64 %t64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t68 = getelementptr [1392 x i64], ptr @G_2estd_2fprelude_2ftext_2epow10Mant, i64 0, i64 %t66
  %t69 = load i64, ptr %t68, !tbaa !34
  store i64 %t69, ptr %l10, !tbaa !65
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = add i64 %t72, 1
  %t76 = getelementptr [1392 x i64], ptr @G_2estd_2fprelude_2ftext_2epow10Mant, i64 0, i64 %t74
  %t77 = load i64, ptr %t76, !tbaa !34
  %t80 = load i64, ptr %l10, !tbaa !65
  %t82 = lshr i64 %t80, 2
  store i64 %t82, ptr %l12, !tbaa !65
  %t86 = lshr i64 %t77, 2
  %t87 = load i64, ptr %l10, !tbaa !65
  %t89 = shl i64 %t87, 62
  %t92 = or i64 %t86, %t89
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l13, !tbaa !65
  %t96 = load i64, ptr %l13, !tbaa !65
  %t98 = icmp eq i64 %t96, 0
  br i1 %t98, label %bb7, label %bb8
bb7:
  %t100 = load i64, ptr %l12, !tbaa !65
  %t103 = add i64 %t100, 1
  store i64 %t103, ptr %l12, !tbaa !65
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t105 = load i64, ptr %l12, !tbaa !65
  %t107 = shl i64 %t105, 1
  %t108 = load i64, ptr %l13, !tbaa !65
  %t110 = lshr i64 %t108, 63
  %t113 = or i64 %t107, %t110
  store i64 %t113, ptr %l14, !tbaa !65
  %t115 = load i64, ptr %l13, !tbaa !65
  %t116 = load i64, ptr @G_2estd_2fprelude_2ftext_2emask63, !tbaa !65
  %t119 = and i64 %t115, %t116
  store i64 %t119, ptr %l15, !tbaa !65
  %t121 = load i64, ptr %l14, !tbaa !65
  %t122 = load i64, ptr %l15, !tbaa !65
  %t123 = load i64, ptr %l4, !tbaa !65
  %t124 = load i64, ptr %l8, !tbaa !24
  store i64 %t124, ptr %l93, !tbaa !65
  %t127 = load i64, ptr %l93, !tbaa !65
  %t128 = load i64, ptr %l93, !tbaa !65
  %t129 = shl i64 %t123, %t128
  %t133 = call i64 @std_2fprelude_2ftext_2erop(i64 %t121, i64 %t122, i64 %t129)
  store i64 %t133, ptr %l95
  br label %bb10
bb10:
  %t134 = load i64, ptr %l95, !tbaa !65
  store i64 %t134, ptr %l16, !tbaa !65
  %t135 = load i64, ptr %l14, !tbaa !65
  %t136 = load i64, ptr %l15, !tbaa !65
  %t137 = load i64, ptr %l6, !tbaa !65
  %t138 = load i64, ptr %l8, !tbaa !24
  store i64 %t138, ptr %l100, !tbaa !65
  %t141 = load i64, ptr %l100, !tbaa !65
  %t142 = load i64, ptr %l100, !tbaa !65
  %t143 = shl i64 %t137, %t142
  %t147 = call i64 @std_2fprelude_2ftext_2erop(i64 %t135, i64 %t136, i64 %t143)
  store i64 %t147, ptr %l102
  br label %bb11
bb11:
  %t148 = load i64, ptr %l102, !tbaa !65
  store i64 %t148, ptr %l17, !tbaa !65
  %t149 = load i64, ptr %l14, !tbaa !65
  %t150 = load i64, ptr %l15, !tbaa !65
  %t151 = load i64, ptr %l5, !tbaa !65
  %t152 = load i64, ptr %l8, !tbaa !24
  store i64 %t152, ptr %l107, !tbaa !65
  %t155 = load i64, ptr %l107, !tbaa !65
  %t156 = load i64, ptr %l107, !tbaa !65
  %t157 = shl i64 %t151, %t156
  %t161 = call i64 @std_2fprelude_2ftext_2erop(i64 %t149, i64 %t150, i64 %t157)
  store i64 %t161, ptr %l109
  br label %bb12
bb12:
  %t162 = load i64, ptr %l109, !tbaa !65
  store i64 %t162, ptr %l18, !tbaa !65
  %t163 = load i64, ptr %l16, !tbaa !65
  %t165 = lshr i64 %t163, 2
  store i64 %t165, ptr %l19, !tbaa !65
  %t167 = load i64, ptr %l19, !tbaa !65
  %t169 = icmp uge i64 %t167, 10
  br i1 %t169, label %bb13, label %bb14
bb13:
  %t171 = load i64, ptr %l19, !tbaa !65
  %t173 = udiv i64 %t171, 10
  %t175 = mul i64 10, %t173
  store i64 %t175, ptr %l20, !tbaa !65
  %t177 = load i64, ptr %l20, !tbaa !65
  %t179 = add i64 %t177, 10
  store i64 %t179, ptr %l21, !tbaa !65
  %t181 = load i64, ptr %l17, !tbaa !65
  %t182 = load i64, ptr %l3, !tbaa !65
  %t185 = add i64 %t181, %t182
  %t186 = load i64, ptr %l20, !tbaa !65
  %t188 = shl i64 %t186, 2
  %t191 = icmp ule i64 %t185, %t188
  store i1 %t191, ptr %l22, !tbaa !21
  %t193 = load i64, ptr %l21, !tbaa !65
  %t195 = shl i64 %t193, 2
  %t196 = load i64, ptr %l3, !tbaa !65
  %t199 = add i64 %t195, %t196
  %t200 = load i64, ptr %l18, !tbaa !65
  %t203 = icmp ule i64 %t199, %t200
  %t205 = load i1, ptr %l22, !tbaa !21
  %t209 = icmp ne i1 %t205, %t203
  br i1 %t209, label %bb15, label %bb16
bb14:
  br label %bb21
bb15:
  %t211 = load i1, ptr %l22, !tbaa !21
  br i1 %t211, label %bb17, label %bb18
bb16:
  br label %bb20
bb17:
  %t213 = load i64, ptr %l20, !tbaa !65
  %t214 = load i64, ptr %l7, !tbaa !24
  %t216 = insertvalue { i64, i64 } undef, i64 %t213, 0
  %t218 = insertvalue { i64, i64 } %t216, i64 %t214, 1
  store { i64, i64 } %t218, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t220 = load i64, ptr %l21, !tbaa !65
  %t221 = load i64, ptr %l7, !tbaa !24
  %t223 = insertvalue { i64, i64 } undef, i64 %t220, 0
  %t225 = insertvalue { i64, i64 } %t223, i64 %t221, 1
  store { i64, i64 } %t225, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t227 = load i64, ptr %l19, !tbaa !65
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l24, !tbaa !65
  %t231 = load i64, ptr %l17, !tbaa !65
  %t232 = load i64, ptr %l3, !tbaa !65
  %t235 = add i64 %t231, %t232
  %t236 = load i64, ptr %l19, !tbaa !65
  %t238 = shl i64 %t236, 2
  %t241 = icmp ule i64 %t235, %t238
  store i1 %t241, ptr %l25, !tbaa !21
  %t243 = load i64, ptr %l24, !tbaa !65
  %t245 = shl i64 %t243, 2
  %t246 = load i64, ptr %l3, !tbaa !65
  %t249 = add i64 %t245, %t246
  %t250 = load i64, ptr %l18, !tbaa !65
  %t253 = icmp ule i64 %t249, %t250
  %t255 = load i1, ptr %l25, !tbaa !21
  %t259 = icmp ne i1 %t255, %t253
  br i1 %t259, label %bb22, label %bb23
bb22:
  %t261 = load i1, ptr %l25, !tbaa !21
  br i1 %t261, label %bb24, label %bb25
bb23:
  br label %bb27
bb24:
  %t263 = load i64, ptr %l19, !tbaa !65
  %t264 = load i64, ptr %l7, !tbaa !24
  %t265 = load i64, ptr %l2, !tbaa !24
  %t268 = add i64 %t264, %t265
  %t270 = insertvalue { i64, i64 } undef, i64 %t263, 0
  %t272 = insertvalue { i64, i64 } %t270, i64 %t268, 1
  store { i64, i64 } %t272, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t274 = load i64, ptr %l24, !tbaa !65
  %t275 = load i64, ptr %l7, !tbaa !24
  %t276 = load i64, ptr %l2, !tbaa !24
  %t279 = add i64 %t275, %t276
  %t281 = insertvalue { i64, i64 } undef, i64 %t274, 0
  %t283 = insertvalue { i64, i64 } %t281, i64 %t279, 1
  store { i64, i64 } %t283, ptr %rv
  br label %ret
bb27:
  %t285 = load i64, ptr %l16, !tbaa !65
  %t287 = load i64, ptr %l19, !tbaa !65
  %t288 = load i64, ptr %l24, !tbaa !65
  %t291 = add i64 %t287, %t288
  %t293 = shl i64 %t291, 1
  %t297 = sub i64 %t285, %t293
  store i64 %t297, ptr %l27, !tbaa !24
  %t299 = load i64, ptr %l27, !tbaa !24
  %t301 = icmp slt i64 %t299, 0
  br i1 %t301, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l179, !tbaa !21
  br label %bb33
bb29:
  %t303 = load i64, ptr %l27, !tbaa !24
  %t305 = icmp eq i64 %t303, 0
  br i1 %t305, label %bb30, label %bb31
bb30:
  %t307 = load i64, ptr %l19, !tbaa !65
  %t309 = and i64 %t307, 1
  %t311 = icmp eq i64 %t309, 0
  store i1 %t311, ptr %l182, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb32
bb32:
  %t313 = load i1, ptr %l182, !tbaa !21
  store i1 %t313, ptr %l179, !tbaa !21
  br label %bb33
bb33:
  %t314 = load i1, ptr %l179, !tbaa !21
  br i1 %t314, label %bb34, label %bb35
bb34:
  %t315 = load i64, ptr %l19, !tbaa !65
  %t316 = load i64, ptr %l7, !tbaa !24
  %t317 = load i64, ptr %l2, !tbaa !24
  %t320 = add i64 %t316, %t317
  %t322 = insertvalue { i64, i64 } undef, i64 %t315, 0
  %t324 = insertvalue { i64, i64 } %t322, i64 %t320, 1
  store { i64, i64 } %t324, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t326 = load i64, ptr %l24, !tbaa !65
  %t327 = load i64, ptr %l7, !tbaa !24
  %t328 = load i64, ptr %l2, !tbaa !24
  %t331 = add i64 %t327, %t328
  %t333 = insertvalue { i64, i64 } undef, i64 %t326, 0
  %t335 = insertvalue { i64, i64 } %t333, i64 %t331, 1
  store { i64, i64 } %t335, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i32, double } @std_2fprelude_2ftext_2eslowF64(ptr %v0, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:decimal"
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:decimal"
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, double }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:decimal" @std_2fprelude_2ftext_3adecimal_2ector(ptr %s0)
  store %"std/prelude/text:decimal" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:decimal", ptr %l4
  store %"std/prelude/text:decimal" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eset(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %a0)
  br label %bb2
bb2:
  %t7 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2ebits(ptr %s0, ptr %l2)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb4, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l9
  br label %bb3
bb3:
  %t12 = load i64, ptr %l9, !tbaa !65
  store i64 %t12, ptr %l7, !tbaa !65
  br label %bb5
bb4:
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, double } zeroinitializer, i32 %t21, 0
  store { i32, double } %t23, ptr %rv
  br label %ret
bb5:
  %t24 = load i64, ptr %l7, !tbaa !65
  store i64 %t24, ptr %l3, !tbaa !65
  br i1 %a1, label %bb6, label %bb7
bb6:
  %t27 = load i64, ptr %l3, !tbaa !65
  %t29 = shl i64 1, 63
  %t32 = or i64 %t27, %t29
  store i64 %t32, ptr %l3, !tbaa !65
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t34 = load i64, ptr %l3, !tbaa !65
  %t36 = bitcast i64 %t34 to double
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, double } zeroinitializer, double %t36, 1
  store { i32, double } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eBytes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1) #0 {
entry:
  %l1 = alloca i8
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i8
  %l7 = alloca i64
  %l8 = alloca i8
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i8
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l78 = alloca i64
  %l81 = alloca i1
  %l91 = alloca { i64, ptr }
  %rv = alloca { i32, i64 }
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eBytes(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = add i64 %t5, 32
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp sle i64 %t7, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l24, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l25, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = add i64 %t17, 32
  store i64 %t19, ptr %l27, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l28, !tbaa !24
  %t22 = load i64, ptr %l25, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb24
bb5:
  %t25 = load i64, ptr %l25, !tbaa !24
  %t26 = load i64, ptr %l27, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_25a16543c1c048a3_ac3acc06ad2304b7)
  unreachable
bb7:
  %t29 = load i64, ptr %l27, !tbaa !24
  %t30 = load i64, ptr %l28, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_25a16543c1c048a3_ac3acc06ad2304b7)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l25, !tbaa !24
  %t36 = load i64, ptr %l27, !tbaa !24
  %t37 = getelementptr i8, ptr %t34, i64 %t35
  store ptr %t37, ptr %l4
  %t39 = icmp sgt i64 32, 0
  br i1 %t39, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_25a16543c1c048a3_ac3acc06ad2304b7)
  unreachable
bb11:
  %t41 = load ptr, ptr %l4
  %t45 = getelementptr [32 x i8], ptr %t41, i64 0, i64 0
  %t46 = load i8, ptr %t45, !tbaa !32
  %t47 = load i8, ptr %l1, !tbaa !22
  %t50 = xor i8 %t46, %t47
  store i8 %t50, ptr %l6, !tbaa !22
  store i64 1, ptr %l7, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i8 0, ptr %l23, !tbaa !22
  br label %bb23
bb14:
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = icmp slt i64 %t52, 32
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb15, label %bb16
bb15:
  br label %bb22
bb16:
  br label %bb17
bb17:
  %t58 = load ptr, ptr %l4
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = getelementptr [32 x i8], ptr %t58, i64 0, i64 %t59
  %t63 = load i8, ptr %t62, !tbaa !32
  %t64 = load i8, ptr %l1, !tbaa !22
  %t67 = xor i8 %t63, %t64
  store i8 %t67, ptr %l8, !tbaa !22
  %t69 = load i8, ptr %l8, !tbaa !22
  %t70 = load i8, ptr %l6, !tbaa !22
  %t73 = icmp ult i8 %t69, %t70
  br i1 %t73, label %bb18, label %bb19
bb18:
  %t75 = load i8, ptr %l8, !tbaa !22
  store i8 %t75, ptr %l6, !tbaa !22
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = add i64 %t77, 1
  store i64 %t80, ptr %l7, !tbaa !24
  br label %bb14
bb22:
  %t82 = load i8, ptr %l6, !tbaa !22
  store i8 %t82, ptr %l23, !tbaa !22
  br label %bb23
bb23:
  %t84 = load i8, ptr %l23, !tbaa !22
  %t85 = icmp ne i8 %t84, 0
  store i1 %t85, ptr %l22, !tbaa !21
  br label %bb24
bb24:
  %t87 = load i1, ptr %l22, !tbaa !21
  %t88 = xor i1 %t87, true
  br i1 %t88, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = add i64 %t90, 32
  store i64 %t93, ptr %l3, !tbaa !24
  br label %bb28
bb28:
  br label %bb2
bb29:
  %t95 = load i64, ptr %l3, !tbaa !24
  store i64 %t95, ptr %l9, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t101 = load i64, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb35
bb32:
  %t111 = load i64, ptr %l10, !tbaa !24
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l11, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l69, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb34
bb34:
  %t127 = load i64, ptr %l69, !tbaa !24
  store i64 %t127, ptr %l66, !tbaa !24
  br label %bb35
bb35:
  %t128 = load i64, ptr %l66, !tbaa !24
  store i64 %t128, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t129 = load i64, ptr %l12, !tbaa !24
  %t130 = sub i64 %t129, 1
  store i64 %t130, ptr %l78, !tbaa !24
  %t131 = load i64, ptr %l12, !tbaa !24
  %t132 = icmp slt i64 %t131, 2147483648
  %t133 = load i64, ptr %l13, !tbaa !24
  %t134 = icmp sge i64 %t133, 0
  %t137 = and i1 %t132, %t134
  store i1 %t137, ptr %l81, !tbaa !21
  br label %bb36
bb36:
  %t138 = load i64, ptr %l13, !tbaa !24
  %t139 = load i64, ptr %l12, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb37, label %bb38
bb37:
  br label %bb44
bb38:
  br label %bb39
bb39:
  %t146 = load i64, ptr %l9, !tbaa !24
  %t147 = load i64, ptr %l13, !tbaa !24
  %t148 = load i64, ptr %l11, !tbaa !24
  %t151 = mul i64 %t147, %t148
  %t154 = add i64 %t146, %t151
  store i64 %t154, ptr %l14, !tbaa !24
  %t156 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t156, ptr %l91, !tbaa !27
  %t157 = load i64, ptr %l14, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i8, ptr %t160, i64 %t157
  %t162 = load i8, ptr %t161, !tbaa !32
  %t163 = load i8, ptr %l1, !tbaa !22
  %t166 = icmp eq i8 %t162, %t163
  br i1 %t166, label %bb40, label %bb41
bb40:
  %t168 = load i64, ptr %l14, !tbaa !24
  %t170 = insertvalue { i32, i64 } zeroinitializer, i64 %t168, 1
  store { i32, i64 } %t170, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t171 = load i64, ptr %l13, !tbaa !24
  %t174 = add i64 %t171, 1
  store i64 %t174, ptr %l13, !tbaa !24
  br label %bb36
bb44:
  %t177 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t177, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i8
  %l12 = alloca i64
  %l13 = alloca i8
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l41 = alloca i64
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l53 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l59 = alloca i1
  %l65 = alloca i1
  %l75 = alloca i1
  %l76 = alloca { i64, ptr }
  %l79 = alloca i1
  %l81 = alloca { i64, ptr }
  %l89 = alloca i1
  %l117 = alloca i1
  %l118 = alloca { i64, ptr }
  %l129 = alloca i1
  %l130 = alloca { i64, ptr }
  %l133 = alloca i1
  %l135 = alloca { i64, ptr }
  %l143 = alloca i1
  %l176 = alloca i1
  %l177 = alloca { i64, ptr }
  %l181 = alloca i1
  %l182 = alloca { i64, ptr }
  %l193 = alloca i1
  %l194 = alloca { i64, ptr }
  %l198 = alloca i1
  %l199 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l214 = alloca i1
  %l215 = alloca { i64, ptr }
  %l218 = alloca i1
  %l225 = alloca i1
  %l226 = alloca { i64, ptr }
  %l229 = alloca i1
  %l236 = alloca { i64, ptr }
  %l256 = alloca double
  %l264 = alloca double
  %l265 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca { i32, double }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = insertvalue { i32, double } zeroinitializer, i32 65536, 0
  store { i32, double } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i1 false, ptr %l1, !tbaa !21
  store i64 0, ptr %l2, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l20, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  %t15 = icmp eq i8 %t13, 45
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb6
bb5:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l24, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 0
  %t21 = load i8, ptr %t20, !tbaa !32
  %t23 = icmp eq i8 %t21, 43
  store i1 %t23, ptr %l23, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l23, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t26, ptr %l27, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 0
  %t30 = load i8, ptr %t29, !tbaa !32
  %t32 = icmp eq i8 %t30, 45
  store i1 %t32, ptr %l1, !tbaa !21
  store i64 1, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t34, ptr %l30, !tbaa !27
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l31, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t36, 0
  store i64 %t39, ptr %l34, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l35, !tbaa !24
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t45 = load i64, ptr %l31, !tbaa !24
  %t46 = load i64, ptr %l34, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_747b1402afddac05_321abc763f710dd9)
  unreachable
bb12:
  %t49 = load i64, ptr %l34, !tbaa !24
  %t50 = load i64, ptr %l35, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_747b1402afddac05_321abc763f710dd9)
  unreachable
bb14:
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l34, !tbaa !24
  %t57 = getelementptr i8, ptr %t54, i64 %t55
  %t58 = sub i64 %t56, %t55
  %t59 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t57, 1
  store { i64, ptr } %t60, ptr %l3, !tbaa !27
  %t62 = load i1, ptr %l1, !tbaa !21
  br i1 %t62, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_747b1402afddac05_321abc763f710dd9)
  unreachable
bb16:
  %t64 = shl i64 1, 63
  store i64 %t64, ptr %l41, !tbaa !65
  br label %bb18
bb17:
  store i64 0, ptr %l41, !tbaa !65
  br label %bb18
bb18:
  %t66 = load i64, ptr %l41, !tbaa !65
  store i64 %t66, ptr %l4, !tbaa !65
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb19, label %bb20
bb19:
  %t73 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t73, ptr %l47, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i8, ptr %t75, i64 0
  %t77 = load i8, ptr %t76, !tbaa !32
  %t79 = icmp ne i8 %t77, 46
  store i1 %t79, ptr %l46, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb21
bb21:
  %t81 = load i1, ptr %l46, !tbaa !21
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t82, ptr %l51, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i8, ptr %t84, i64 0
  %t86 = load i8, ptr %t85, !tbaa !32
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t86)
  store i1 %t88, ptr %l53
  br label %bb24
bb23:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb25
bb24:
  %t89 = load i1, ptr %l53, !tbaa !21
  %t90 = xor i1 %t89, true
  store i1 %t90, ptr %l50, !tbaa !21
  br label %bb25
bb25:
  %t92 = load i1, ptr %l50, !tbaa !21
  br i1 %t92, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t93 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t95 = call i1 @std_2fprelude_2ftext_2esameLetters(ptr %v0, ptr %s3, { i64, ptr } %t93, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t95, ptr %l56
  br label %bb28
bb27:
  br label %bb40
bb28:
  %t96 = load i1, ptr %l56, !tbaa !21
  br i1 %t96, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb32
bb30:
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2esameLetters(ptr %v0, ptr %s3, { i64, ptr } %t97, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t99, ptr %l59
  br label %bb31
bb31:
  %t100 = load i1, ptr %l59, !tbaa !21
  store i1 %t100, ptr %l57, !tbaa !21
  br label %bb32
bb32:
  %t101 = load i1, ptr %l57, !tbaa !21
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t102 = load i64, ptr %l4, !tbaa !65
  %t103 = shl i64 2047, 52
  %t106 = or i64 %t102, %t103
  %t108 = bitcast i64 %t106 to double
  call void @__olang_scope_close(ptr %s3)
  %t110 = insertvalue { i32, double } zeroinitializer, double %t108, 1
  store { i32, double } %t110, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t111 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t113 = call i1 @std_2fprelude_2ftext_2esameLetters(ptr %v0, ptr %s3, { i64, ptr } %t111, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t113, ptr %l65
  br label %bb36
bb36:
  %t114 = load i1, ptr %l65, !tbaa !21
  br i1 %t114, label %bb37, label %bb38
bb37:
  %t115 = load i64, ptr %l4, !tbaa !65
  %t116 = shl i64 4095, 51
  %t119 = or i64 %t115, %t116
  %t121 = bitcast i64 %t119 to double
  call void @__olang_scope_close(ptr %s3)
  %t123 = insertvalue { i32, double } zeroinitializer, double %t121, 1
  store { i32, double } %t123, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s3)
  %t125 = insertvalue { i32, double } zeroinitializer, i32 65537, 0
  store { i32, double } %t125, ptr %rv
  br label %ret
bb40:
  store i64 0, ptr %l5, !tbaa !65
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb41
bb41:
  %t126 = load i64, ptr %l10, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t132 = icmp slt i64 %t126, %t129
  br i1 %t132, label %bb42, label %bb43
bb42:
  %t134 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t134, ptr %l76, !tbaa !27
  %t135 = load i64, ptr %l10, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t135
  %t140 = load i8, ptr %t139, !tbaa !32
  %t142 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t140)
  store i1 %t142, ptr %l79
  br label %bb44
bb43:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb45
bb44:
  %t143 = load i1, ptr %l79, !tbaa !21
  store i1 %t143, ptr %l75, !tbaa !21
  br label %bb45
bb45:
  %t144 = load i1, ptr %l75, !tbaa !21
  %t145 = xor i1 %t144, true
  br i1 %t145, label %bb46, label %bb47
bb46:
  br label %bb62
bb47:
  br label %bb48
bb48:
  %t147 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t147, ptr %l81, !tbaa !27
  %t148 = load i64, ptr %l10, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i8, ptr %t151, i64 %t148
  %t153 = load i8, ptr %t152, !tbaa !32
  store i8 %t153, ptr %l11, !tbaa !22
  %t155 = load i64, ptr %l9, !tbaa !24
  %t158 = add i64 %t155, 1
  store i64 %t158, ptr %l9, !tbaa !24
  %t160 = load i8, ptr %l11, !tbaa !22
  %t162 = icmp ne i8 %t160, 48
  br i1 %t162, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb51
bb50:
  %t164 = load i64, ptr %l7, !tbaa !24
  %t166 = icmp sgt i64 %t164, 0
  store i1 %t166, ptr %l89, !tbaa !21
  br label %bb51
bb51:
  %t168 = load i1, ptr %l89, !tbaa !21
  br i1 %t168, label %bb52, label %bb53
bb52:
  %t169 = load i64, ptr %l7, !tbaa !24
  %t172 = add i64 %t169, 1
  store i64 %t172, ptr %l7, !tbaa !24
  %t174 = load i64, ptr %l6, !tbaa !24
  %t176 = icmp slt i64 %t174, 19
  br i1 %t176, label %bb54, label %bb55
bb53:
  br label %bb60
bb54:
  %t178 = load i64, ptr %l5, !tbaa !65
  %t181 = mul i64 %t178, 10
  %t182 = load i8, ptr %l11, !tbaa !22
  %t184 = sub i8 %t182, 48
  %t186 = zext i8 %t184 to i64
  %t189 = add i64 %t181, %t186
  store i64 %t189, ptr %l5, !tbaa !65
  %t191 = load i64, ptr %l6, !tbaa !24
  %t194 = add i64 %t191, 1
  store i64 %t194, ptr %l6, !tbaa !24
  br label %bb59
bb55:
  %t196 = load i8, ptr %l11, !tbaa !22
  %t198 = icmp ne i8 %t196, 48
  br i1 %t198, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb58
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t200 = load i64, ptr %l10, !tbaa !24
  %t203 = add i64 %t200, 1
  store i64 %t203, ptr %l10, !tbaa !24
  br label %bb61
bb61:
  br label %bb41
bb62:
  %t205 = load i64, ptr %l7, !tbaa !24
  store i64 %t205, ptr %l12, !tbaa !24
  %t207 = load i64, ptr %l10, !tbaa !24
  %t208 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t213 = icmp slt i64 %t207, %t210
  br i1 %t213, label %bb63, label %bb64
bb63:
  %t215 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t215, ptr %l118, !tbaa !27
  %t216 = load i64, ptr %l10, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr i8, ptr %t219, i64 %t216
  %t221 = load i8, ptr %t220, !tbaa !32
  %t223 = icmp eq i8 %t221, 46
  store i1 %t223, ptr %l117, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb65
bb65:
  %t225 = load i1, ptr %l117, !tbaa !21
  br i1 %t225, label %bb66, label %bb67
bb66:
  %t226 = load i64, ptr %l10, !tbaa !24
  %t229 = add i64 %t226, 1
  store i64 %t229, ptr %l10, !tbaa !24
  br label %bb68
bb67:
  br label %bb90
bb68:
  %t231 = load i64, ptr %l10, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t237 = icmp slt i64 %t231, %t234
  br i1 %t237, label %bb69, label %bb70
bb69:
  %t239 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t239, ptr %l130, !tbaa !27
  %t240 = load i64, ptr %l10, !tbaa !24
  %t242 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = getelementptr i8, ptr %t243, i64 %t240
  %t245 = load i8, ptr %t244, !tbaa !32
  %t247 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t245)
  store i1 %t247, ptr %l133
  br label %bb71
bb70:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb72
bb71:
  %t248 = load i1, ptr %l133, !tbaa !21
  store i1 %t248, ptr %l129, !tbaa !21
  br label %bb72
bb72:
  %t249 = load i1, ptr %l129, !tbaa !21
  %t250 = xor i1 %t249, true
  br i1 %t250, label %bb73, label %bb74
bb73:
  br label %bb89
bb74:
  br label %bb75
bb75:
  %t252 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t252, ptr %l135, !tbaa !27
  %t253 = load i64, ptr %l10, !tbaa !24
  %t255 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr i8, ptr %t256, i64 %t253
  %t258 = load i8, ptr %t257, !tbaa !32
  store i8 %t258, ptr %l13, !tbaa !22
  %t260 = load i64, ptr %l9, !tbaa !24
  %t263 = add i64 %t260, 1
  store i64 %t263, ptr %l9, !tbaa !24
  %t265 = load i8, ptr %l13, !tbaa !22
  %t267 = icmp eq i8 %t265, 48
  br i1 %t267, label %bb76, label %bb77
bb76:
  %t269 = load i64, ptr %l7, !tbaa !24
  %t271 = icmp eq i64 %t269, 0
  store i1 %t271, ptr %l143, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb78
bb78:
  %t273 = load i1, ptr %l143, !tbaa !21
  br i1 %t273, label %bb79, label %bb80
bb79:
  %t274 = load i64, ptr %l12, !tbaa !24
  %t277 = sub i64 %t274, 1
  store i64 %t277, ptr %l12, !tbaa !24
  br label %bb87
bb80:
  %t279 = load i64, ptr %l7, !tbaa !24
  %t282 = add i64 %t279, 1
  store i64 %t282, ptr %l7, !tbaa !24
  %t284 = load i64, ptr %l6, !tbaa !24
  %t286 = icmp slt i64 %t284, 19
  br i1 %t286, label %bb81, label %bb82
bb81:
  %t288 = load i64, ptr %l5, !tbaa !65
  %t291 = mul i64 %t288, 10
  %t292 = load i8, ptr %l13, !tbaa !22
  %t294 = sub i8 %t292, 48
  %t296 = zext i8 %t294 to i64
  %t299 = add i64 %t291, %t296
  store i64 %t299, ptr %l5, !tbaa !65
  %t301 = load i64, ptr %l6, !tbaa !24
  %t304 = add i64 %t301, 1
  store i64 %t304, ptr %l6, !tbaa !24
  br label %bb86
bb82:
  %t306 = load i8, ptr %l13, !tbaa !22
  %t308 = icmp ne i8 %t306, 48
  br i1 %t308, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb85
bb84:
  br label %bb85
bb85:
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t310 = load i64, ptr %l10, !tbaa !24
  %t313 = add i64 %t310, 1
  store i64 %t313, ptr %l10, !tbaa !24
  br label %bb88
bb88:
  br label %bb68
bb89:
  br label %bb90
bb90:
  %t315 = load i64, ptr %l9, !tbaa !24
  %t317 = icmp eq i64 %t315, 0
  br i1 %t317, label %bb91, label %bb92
bb91:
  %t320 = insertvalue { i32, double } zeroinitializer, i32 65537, 0
  store { i32, double } %t320, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t321 = load i64, ptr %l10, !tbaa !24
  %t322 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t327 = icmp slt i64 %t321, %t324
  br i1 %t327, label %bb94, label %bb95
bb94:
  %t329 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t329, ptr %l177, !tbaa !27
  %t330 = load i64, ptr %l10, !tbaa !24
  %t332 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr i8, ptr %t333, i64 %t330
  %t335 = load i8, ptr %t334, !tbaa !32
  %t337 = icmp eq i8 %t335, 101
  br i1 %t337, label %bb96, label %bb97
bb95:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb99
bb96:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb98
bb97:
  %t339 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t339, ptr %l182, !tbaa !27
  %t340 = load i64, ptr %l10, !tbaa !24
  %t342 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr i8, ptr %t343, i64 %t340
  %t345 = load i8, ptr %t344, !tbaa !32
  %t347 = icmp eq i8 %t345, 69
  store i1 %t347, ptr %l181, !tbaa !21
  br label %bb98
bb98:
  %t349 = load i1, ptr %l181, !tbaa !21
  store i1 %t349, ptr %l176, !tbaa !21
  br label %bb99
bb99:
  %t350 = load i1, ptr %l176, !tbaa !21
  br i1 %t350, label %bb100, label %bb101
bb100:
  %t351 = load i64, ptr %l10, !tbaa !24
  %t354 = add i64 %t351, 1
  store i64 %t354, ptr %l10, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t356 = load i64, ptr %l10, !tbaa !24
  %t357 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t362 = icmp slt i64 %t356, %t359
  br i1 %t362, label %bb102, label %bb103
bb101:
  br label %bb134
bb102:
  %t364 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t364, ptr %l194, !tbaa !27
  %t365 = load i64, ptr %l10, !tbaa !24
  %t367 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = getelementptr i8, ptr %t368, i64 %t365
  %t370 = load i8, ptr %t369, !tbaa !32
  %t372 = icmp eq i8 %t370, 43
  br i1 %t372, label %bb104, label %bb105
bb103:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb107
bb104:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb106
bb105:
  %t374 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t374, ptr %l199, !tbaa !27
  %t375 = load i64, ptr %l10, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr i8, ptr %t378, i64 %t375
  %t380 = load i8, ptr %t379, !tbaa !32
  %t382 = icmp eq i8 %t380, 45
  store i1 %t382, ptr %l198, !tbaa !21
  br label %bb106
bb106:
  %t384 = load i1, ptr %l198, !tbaa !21
  store i1 %t384, ptr %l193, !tbaa !21
  br label %bb107
bb107:
  %t385 = load i1, ptr %l193, !tbaa !21
  br i1 %t385, label %bb108, label %bb109
bb108:
  %t386 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t386, ptr %l203, !tbaa !27
  %t387 = load i64, ptr %l10, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr i8, ptr %t390, i64 %t387
  %t392 = load i8, ptr %t391, !tbaa !32
  %t394 = icmp eq i8 %t392, 45
  br i1 %t394, label %bb110, label %bb111
bb109:
  br label %bb113
bb110:
  store i64 -1, ptr %l14, !tbaa !24
  br label %bb112
bb111:
  br label %bb112
bb112:
  %t396 = load i64, ptr %l10, !tbaa !24
  %t399 = add i64 %t396, 1
  store i64 %t399, ptr %l10, !tbaa !24
  br label %bb113
bb113:
  %t401 = load i64, ptr %l10, !tbaa !24
  %t402 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t404 = extractvalue { i64, ptr } %t402, 0
  %t407 = icmp eq i64 %t401, %t404
  br i1 %t407, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l214, !tbaa !21
  br label %bb117
bb115:
  %t409 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t409, ptr %l215, !tbaa !27
  %t410 = load i64, ptr %l10, !tbaa !24
  %t412 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr i8, ptr %t413, i64 %t410
  %t415 = load i8, ptr %t414, !tbaa !32
  %t417 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t415)
  store i1 %t417, ptr %l218
  br label %bb116
bb116:
  %t418 = load i1, ptr %l218, !tbaa !21
  %t419 = xor i1 %t418, true
  store i1 %t419, ptr %l214, !tbaa !21
  br label %bb117
bb117:
  %t421 = load i1, ptr %l214, !tbaa !21
  br i1 %t421, label %bb118, label %bb119
bb118:
  %t423 = insertvalue { i32, double } zeroinitializer, i32 65537, 0
  store { i32, double } %t423, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb121
bb121:
  %t424 = load i64, ptr %l10, !tbaa !24
  %t425 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t430 = icmp slt i64 %t424, %t427
  br i1 %t430, label %bb122, label %bb123
bb122:
  %t432 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t432, ptr %l226, !tbaa !27
  %t433 = load i64, ptr %l10, !tbaa !24
  %t435 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr i8, ptr %t436, i64 %t433
  %t438 = load i8, ptr %t437, !tbaa !32
  %t440 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t438)
  store i1 %t440, ptr %l229
  br label %bb124
bb123:
  store i1 false, ptr %l225, !tbaa !21
  br label %bb125
bb124:
  %t441 = load i1, ptr %l229, !tbaa !21
  store i1 %t441, ptr %l225, !tbaa !21
  br label %bb125
bb125:
  %t442 = load i1, ptr %l225, !tbaa !21
  %t443 = xor i1 %t442, true
  br i1 %t443, label %bb126, label %bb127
bb126:
  br label %bb133
bb127:
  br label %bb128
bb128:
  %t445 = load i64, ptr %l15, !tbaa !24
  %t447 = icmp slt i64 %t445, 100000
  br i1 %t447, label %bb129, label %bb130
bb129:
  %t449 = load i64, ptr %l15, !tbaa !24
  %t452 = mul i64 %t449, 10
  %t453 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t453, ptr %l236, !tbaa !27
  %t454 = load i64, ptr %l10, !tbaa !24
  %t456 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr i8, ptr %t457, i64 %t454
  %t459 = load i8, ptr %t458, !tbaa !32
  %t461 = sub i8 %t459, 48
  %t463 = zext i8 %t461 to i64
  %t466 = add i64 %t452, %t463
  store i64 %t466, ptr %l15, !tbaa !24
  br label %bb131
bb130:
  br label %bb131
bb131:
  %t468 = load i64, ptr %l10, !tbaa !24
  %t471 = add i64 %t468, 1
  store i64 %t471, ptr %l10, !tbaa !24
  br label %bb132
bb132:
  br label %bb121
bb133:
  %t473 = load i64, ptr %l12, !tbaa !24
  %t475 = load i64, ptr %l15, !tbaa !24
  %t476 = load i64, ptr %l14, !tbaa !24
  %t479 = mul i64 %t475, %t476
  %t482 = add i64 %t473, %t479
  store i64 %t482, ptr %l12, !tbaa !24
  br label %bb134
bb134:
  %t484 = load i64, ptr %l10, !tbaa !24
  %t485 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t487 = extractvalue { i64, ptr } %t485, 0
  %t490 = icmp slt i64 %t484, %t487
  br i1 %t490, label %bb135, label %bb136
bb135:
  %t493 = insertvalue { i32, double } zeroinitializer, i32 65537, 0
  store { i32, double } %t493, ptr %rv
  br label %ret
bb136:
  br label %bb137
bb137:
  %t494 = load i64, ptr %l5, !tbaa !65
  %t495 = load i64, ptr %l12, !tbaa !24
  %t496 = load i64, ptr %l6, !tbaa !24
  %t499 = sub i64 %t495, %t496
  %t500 = load i1, ptr %l8, !tbaa !21
  %t501 = load i1, ptr %l1, !tbaa !21
  %t502 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t508 = call { i32, double } @std_2fprelude_2ftext_2etoF64(ptr %v0, i64 %t494, i64 %t499, i1 %t500, i1 %t501, { i64, ptr } %t502)
  %t509 = extractvalue { i32, double } %t508, 1
  %t510 = extractvalue { i32, double } %t508, 0
  store i32 %t510, ptr %l265
  %t511 = icmp ne i32 %t510, 0
  br i1 %t511, label %bb139, label %ok.512, !prof !99
ok.512:
  store double %t509, ptr %l264
  br label %bb138
bb138:
  %t513 = load double, ptr %l264, !tbaa !26
  store double %t513, ptr %l256, !tbaa !26
  br label %bb140
bb139:
  %t514 = load i32, ptr %l265, !tbaa !23
  %t515 = lshr i32 %t514, 16
  %t516 = and i32 %t514, 65535
  %t517 = icmp eq i32 %t515, 1
  %t518 = select i1 %t517, i32 1, i32 0
  %t519 = icmp eq i32 %t514, 0
  %t520 = shl i32 %t518, 16
  %t521 = or i32 %t520, %t516
  %t522 = select i1 %t519, i32 0, i32 %t521
  %t524 = insertvalue { i32, double } zeroinitializer, i32 %t522, 0
  store { i32, double } %t524, ptr %rv
  br label %ret
bb140:
  %t525 = load double, ptr %l256, !tbaa !26
  %t526 = insertvalue { i32, double } zeroinitializer, double %t525, 1
  store { i32, double } %t526, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l6 = alloca i64
  %l11 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l41 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i32
  %l50 = alloca i64
  %l51 = alloca i32
  %l55 = alloca i64
  %l60 = alloca i64
  %l64 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i32
  %l72 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l11, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  %t15 = icmp eq i8 %t13, 45
  store i1 %t15, ptr %l2, !tbaa !21
  %t17 = load i1, ptr %l2, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l16, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 0
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp eq i8 %t23, 43
  store i1 %t25, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t28, ptr %l20, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t29, 0
  store i64 %t32, ptr %l23, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = icmp sge i64 1, 0
  br i1 %t35, label %bb9, label %bb10
bb8:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l29, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 0
  store i64 %t41, ptr %l32, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l33, !tbaa !24
  %t44 = icmp sge i64 0, 0
  br i1 %t44, label %bb15, label %bb16
bb9:
  %t46 = load i64, ptr %l23, !tbaa !24
  %t47 = icmp sle i64 1, %t46
  br i1 %t47, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_50f801f94424a14_5c76de4ac41c4c38)
  unreachable
bb11:
  %t49 = load i64, ptr %l23, !tbaa !24
  %t50 = load i64, ptr %l24, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_50f801f94424a14_5c76de4ac41c4c38)
  unreachable
bb13:
  %t53 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l23, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 1
  %t57 = sub i64 %t55, 1
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l19, !tbaa !27
  br label %bb21
bb14:
  call void @__olang_check_failed(ptr @olang_loc_50f801f94424a14_5c76de4ac41c4c38)
  unreachable
bb15:
  %t61 = load i64, ptr %l32, !tbaa !24
  %t62 = icmp sle i64 0, %t61
  br i1 %t62, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_50f801f94424a14_5c76de4ac41c4c38)
  unreachable
bb17:
  %t64 = load i64, ptr %l32, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_50f801f94424a14_5c76de4ac41c4c38)
  unreachable
bb19:
  %t68 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l32, !tbaa !24
  %t71 = getelementptr i8, ptr %t69, i64 0
  %t72 = sub i64 %t70, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  store { i64, ptr } %t74, ptr %l19, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_50f801f94424a14_5c76de4ac41c4c38)
  unreachable
bb21:
  %t76 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t76, ptr %l3, !tbaa !27
  %t77 = load i64, ptr %l1, !tbaa !24
  %t80 = icmp eq i64 %t77, 0
  br i1 %t80, label %bb22, label %bb23
bb22:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t84 = call i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %t82)
  store i1 %t84, ptr %l43
  br label %bb24
bb23:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb24:
  %t85 = load i1, ptr %l43, !tbaa !21
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t86 = load i1, ptr %l41, !tbaa !21
  br i1 %t86, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s2
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t87, ptr %l45, !tbaa !27
  %t88 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 0)
  %t89 = extractvalue { i32, i64 } %t88, 1
  %t90 = extractvalue { i32, i64 } %t88, 0
  store i32 %t90, ptr %l47
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb29, label %ok.92, !prof !99
ok.92:
  store i64 %t89, ptr %l46
  br label %bb28
bb27:
  br label %bb36
bb28:
  %t93 = xor i64 0, -1
  %t94 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t95 = load i64, ptr %l46, !tbaa !24
  %t97 = call { i32, i64 } @std_2fprelude_2ftext_2ereadDigits(ptr %v0, { i64, ptr } %t94, i64 %t95, i64 %t93)
  %t98 = extractvalue { i32, i64 } %t97, 1
  %t99 = extractvalue { i32, i64 } %t97, 0
  store i32 %t99, ptr %l51
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb31, label %ok.101, !prof !99
ok.101:
  store i64 %t98, ptr %l50
  br label %bb30
bb29:
  %t102 = load i32, ptr %l47, !tbaa !23
  %t103 = lshr i32 %t102, 16
  %t104 = and i32 %t102, 65535
  %t105 = icmp eq i32 %t103, 1
  %t106 = select i1 %t105, i32 0, i32 0
  %t107 = icmp eq i32 %t102, 0
  %t108 = shl i32 %t106, 16
  %t109 = or i32 %t108, %t104
  %t110 = select i1 %t107, i32 0, i32 %t109
  call void @__olang_scope_close(ptr %s2)
  %t112 = insertvalue { i32, i64 } zeroinitializer, i32 %t110, 0
  store { i32, i64 } %t112, ptr %rv
  br label %ret
bb30:
  %t113 = load i64, ptr %l50, !tbaa !65
  store i64 %t113, ptr %l44, !tbaa !65
  br label %bb32
bb31:
  %t114 = load i32, ptr %l51, !tbaa !23
  %t115 = lshr i32 %t114, 16
  %t116 = and i32 %t114, 65535
  %t117 = icmp eq i32 %t115, 1
  %t118 = select i1 %t117, i32 1, i32 0
  %t119 = icmp eq i32 %t114, 0
  %t120 = shl i32 %t118, 16
  %t121 = or i32 %t120, %t116
  %t122 = select i1 %t119, i32 0, i32 %t121
  call void @__olang_scope_close(ptr %s2)
  %t124 = insertvalue { i32, i64 } zeroinitializer, i32 %t122, 0
  store { i32, i64 } %t124, ptr %rv
  br label %ret
bb32:
  %t125 = load i64, ptr %l44, !tbaa !65
  store i64 %t125, ptr %l4, !tbaa !24
  %t127 = load i1, ptr %l2, !tbaa !21
  br i1 %t127, label %bb33, label %bb34
bb33:
  %t129 = load i64, ptr %l4, !tbaa !24
  %t131 = sub i64 0, %t129
  store i64 %t131, ptr %l55, !tbaa !24
  br label %bb35
bb34:
  %t133 = load i64, ptr %l4, !tbaa !24
  store i64 %t133, ptr %l55, !tbaa !24
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  %t135 = load i64, ptr %l55, !tbaa !24
  %t136 = insertvalue { i32, i64 } zeroinitializer, i64 %t135, 1
  store { i32, i64 } %t136, ptr %rv
  br label %ret
bb36:
  %t137 = load i1, ptr %l2, !tbaa !21
  br i1 %t137, label %bb37, label %bb38
bb37:
  %t139 = shl i64 1, 63
  store i64 %t139, ptr %l60, !tbaa !65
  br label %bb39
bb38:
  %t141 = shl i64 1, 63
  %t143 = sub i64 %t141, 1
  store i64 %t143, ptr %l60, !tbaa !65
  br label %bb39
bb39:
  %t145 = load i64, ptr %l60, !tbaa !65
  %t146 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t147 = load i64, ptr %l1, !tbaa !24
  %t152 = call { i32, i64 } @std_2fprelude_2ftext_2ereadDigits(ptr %v0, { i64, ptr } %t146, i64 %t147, i64 %t145)
  %t153 = extractvalue { i32, i64 } %t152, 1
  %t154 = extractvalue { i32, i64 } %t152, 0
  store i32 %t154, ptr %l69
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb41, label %ok.156, !prof !99
ok.156:
  store i64 %t153, ptr %l68
  br label %bb40
bb40:
  %t157 = load i64, ptr %l68, !tbaa !65
  store i64 %t157, ptr %l64, !tbaa !65
  br label %bb42
bb41:
  %t158 = load i32, ptr %l69, !tbaa !23
  %t159 = lshr i32 %t158, 16
  %t160 = and i32 %t158, 65535
  %t161 = icmp eq i32 %t159, 1
  %t162 = select i1 %t161, i32 1, i32 0
  %t163 = icmp eq i32 %t158, 0
  %t164 = shl i32 %t162, 16
  %t165 = or i32 %t164, %t160
  %t166 = select i1 %t163, i32 0, i32 %t165
  %t168 = insertvalue { i32, i64 } zeroinitializer, i32 %t166, 0
  store { i32, i64 } %t168, ptr %rv
  br label %ret
bb42:
  %t169 = load i64, ptr %l64, !tbaa !65
  store i64 %t169, ptr %l6, !tbaa !65
  %t170 = load i1, ptr %l2, !tbaa !21
  br i1 %t170, label %bb43, label %bb44
bb43:
  %t172 = load i64, ptr %l6, !tbaa !65
  %t175 = sub i64 0, %t172
  store i64 %t175, ptr %l72, !tbaa !24
  br label %bb45
bb44:
  %t177 = load i64, ptr %l6, !tbaa !65
  store i64 %t177, ptr %l72, !tbaa !24
  br label %bb45
bb45:
  %t180 = load i64, ptr %l72, !tbaa !24
  %t181 = insertvalue { i32, i64 } zeroinitializer, i64 %t180, 1
  store { i32, i64 } %t181, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i32
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  %t15 = icmp eq i8 %t13, 43
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t18, 0
  store i64 %t21, ptr %l14, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l15, !tbaa !24
  %t24 = icmp sge i64 1, 0
  br i1 %t24, label %bb6, label %bb7
bb5:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t26, ptr %l20, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t27, 0
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l24, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb12, label %bb13
bb6:
  %t35 = load i64, ptr %l14, !tbaa !24
  %t36 = icmp sle i64 1, %t35
  br i1 %t36, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_905129bbca3acd7f_cb7c148eab960383)
  unreachable
bb8:
  %t38 = load i64, ptr %l14, !tbaa !24
  %t39 = load i64, ptr %l15, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_905129bbca3acd7f_cb7c148eab960383)
  unreachable
bb10:
  %t42 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l14, !tbaa !24
  %t45 = getelementptr i8, ptr %t43, i64 1
  %t46 = sub i64 %t44, 1
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l10, !tbaa !27
  br label %bb18
bb11:
  call void @__olang_check_failed(ptr @olang_loc_905129bbca3acd7f_cb7c148eab960383)
  unreachable
bb12:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = icmp sle i64 0, %t50
  br i1 %t51, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_905129bbca3acd7f_cb7c148eab960383)
  unreachable
bb14:
  %t53 = load i64, ptr %l23, !tbaa !24
  %t54 = load i64, ptr %l24, !tbaa !24
  %t55 = icmp sle i64 %t53, %t54
  br i1 %t55, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_905129bbca3acd7f_cb7c148eab960383)
  unreachable
bb16:
  %t57 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l23, !tbaa !24
  %t60 = getelementptr i8, ptr %t58, i64 0
  %t61 = sub i64 %t59, 0
  %t62 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  store { i64, ptr } %t63, ptr %l10, !tbaa !27
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_905129bbca3acd7f_cb7c148eab960383)
  unreachable
bb18:
  %t65 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t68 = xor i64 0, -1
  %t72 = call { i32, i64 } @std_2fprelude_2ftext_2ereadDigits(ptr %v0, { i64, ptr } %t65, i64 %a1, i64 %t68)
  %t73 = extractvalue { i32, i64 } %t72, 1
  %t74 = extractvalue { i32, i64 } %t72, 0
  store i32 %t74, ptr %l34
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb20, label %ok.76, !prof !99
ok.76:
  store i64 %t73, ptr %l33
  br label %bb19
bb19:
  %t77 = load i64, ptr %l33, !tbaa !65
  store i64 %t77, ptr %l29, !tbaa !65
  br label %bb21
bb20:
  %t78 = load i32, ptr %l34, !tbaa !23
  %t79 = lshr i32 %t78, 16
  %t80 = and i32 %t78, 65535
  %t81 = icmp eq i32 %t79, 1
  %t82 = select i1 %t81, i32 1, i32 0
  %t83 = icmp eq i32 %t78, 0
  %t84 = shl i32 %t82, 16
  %t85 = or i32 %t84, %t80
  %t86 = select i1 %t83, i32 0, i32 %t85
  %t88 = insertvalue { i32, i64 } zeroinitializer, i32 %t86, 0
  store { i32, i64 } %t88, ptr %rv
  br label %ret
bb21:
  %t89 = load i64, ptr %l29, !tbaa !65
  %t90 = insertvalue { i32, i64 } zeroinitializer, i64 %t89, 1
  store { i32, i64 } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l49 = alloca i64
  %l52 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l88 = alloca { i64, ptr }
  %l93 = alloca i64
  %l96 = alloca i1
  %l101 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca { i64, ptr }
  %l123 = alloca i64
  %l126 = alloca i64
  %l144 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca i64
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i64
  %l167 = alloca { i64, ptr }
  %l168 = alloca i64
  %l169 = alloca { i64, ptr }
  %l170 = alloca i64
  %l173 = alloca i64
  %l174 = alloca i64
  %l180 = alloca i64
  %l184 = alloca i64
  %l185 = alloca i32
  %l193 = alloca i64
  %l194 = alloca { i64, ptr }
  %l203 = alloca i64
  %l206 = alloca i64
  %l224 = alloca i64
  %l228 = alloca i64
  %l229 = alloca i32
  %l230 = alloca { i64, ptr }
  %l231 = alloca i64
  %l232 = alloca { i64, ptr }
  %l233 = alloca i64
  %l234 = alloca i64
  %l235 = alloca i64
  %l247 = alloca { i64, ptr }
  %l249 = alloca i64
  %l250 = alloca { i64, ptr }
  %l251 = alloca i64
  %l254 = alloca i64
  %l255 = alloca i64
  %rv = alloca { i64, ptr }
  %t21 = alloca i64
  %t193 = alloca i64
  %t385 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l39, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t10, ptr %l40, !tbaa !27
  %t11 = load i64, ptr %l39, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  br label %bb25
bb3:
  %t14 = load i64, ptr %l39, !tbaa !24
  %t15 = icmp sle i64 %t14, 576460752303423487
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_7e5260ba99d492e_23f7bc5db39388ba)
  unreachable
bb5:
  %t17 = load i64, ptr %l39, !tbaa !24
  %t18 = mul i64 %t17, 16
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  %t20 = load { i64, ptr }, ptr %l40, !tbaa !27
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, %t17
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr { i64, ptr }, ptr %t19, i64 %t25
  store { i64, ptr } %t20, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t19, 1
  store { i64, ptr } %t30, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_7e5260ba99d492e_23f7bc5db39388ba)
  unreachable
bb7:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb12
bb9:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l52, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb11
bb11:
  %t62 = load i64, ptr %l52, !tbaa !24
  store i64 %t62, ptr %l49, !tbaa !24
  br label %bb12
bb12:
  %t63 = load i64, ptr %l49, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t72 = load i64, ptr %l3, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l8, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t82, ptr %l70, !tbaa !27
  %t83 = load i64, ptr %l8, !tbaa !24
  store i64 %t83, ptr %l71, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t84, ptr %l72, !tbaa !27
  %t85 = load i64, ptr %l8, !tbaa !24
  store i64 %t85, ptr %l73, !tbaa !24
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l75, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l76, !tbaa !24
  %t91 = load i64, ptr %l73, !tbaa !24
  %t92 = icmp sge i64 %t91, 0
  br i1 %t92, label %bb17, label %bb18
bb17:
  %t94 = load i64, ptr %l73, !tbaa !24
  %t95 = load i64, ptr %l75, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_772a81b2a0193ab_4eeb0795ad52cbef)
  unreachable
bb19:
  %t98 = load i64, ptr %l75, !tbaa !24
  %t99 = load i64, ptr %l76, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_772a81b2a0193ab_4eeb0795ad52cbef)
  unreachable
bb21:
  %t102 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l73, !tbaa !24
  %t105 = load i64, ptr %l75, !tbaa !24
  %t106 = getelementptr i8, ptr %t103, i64 %t104
  %t107 = sub i64 %t105, %t104
  %t108 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  %t111 = load i64, ptr %l71, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %t113, i64 %t111
  store { i64, ptr } %t109, ptr %t114, !tbaa !37
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_772a81b2a0193ab_4eeb0795ad52cbef)
  unreachable
bb23:
  %t115 = load i64, ptr %l7, !tbaa !24
  %t118 = add i64 %t115, 1
  store i64 %t118, ptr %l7, !tbaa !24
  br label %bb13
bb24:
  %t120 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t120, ptr %rv
  br label %ret
bb25:
  %t122 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t126 = icmp eq i64 %t124, 1
  br i1 %t126, label %bb26, label %bb27
bb26:
  %t128 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t128, ptr %l88, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i8, ptr %t130, i64 0
  %t132 = load i8, ptr %t131, !tbaa !32
  store i8 %t132, ptr %l9, !tbaa !22
  store i64 1, ptr %l10, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t134, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t136, 0
  store i64 %t138, ptr %l13, !tbaa !24
  %t140 = load i64, ptr %l13, !tbaa !24
  %t141 = sub i64 %t140, 1
  store i64 %t141, ptr %l93, !tbaa !24
  %t142 = load i64, ptr %l13, !tbaa !24
  %t143 = icmp slt i64 %t142, 2147483648
  %t144 = load i64, ptr %l12, !tbaa !24
  %t145 = icmp sge i64 %t144, 0
  %t148 = and i1 %t143, %t145
  store i1 %t148, ptr %l96, !tbaa !21
  br label %bb28
bb27:
  br label %bb68
bb28:
  %t149 = load i64, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l13, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb29, label %bb30
bb29:
  br label %bb36
bb30:
  br label %bb31
bb31:
  %t157 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t157, ptr %l101, !tbaa !27
  %t158 = load i64, ptr %l12, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i8, ptr %t161, i64 %t158
  %t163 = load i8, ptr %t162, !tbaa !32
  %t166 = load i8, ptr %l9, !tbaa !22
  %t169 = icmp eq i8 %t163, %t166
  br i1 %t169, label %bb32, label %bb33
bb32:
  %t171 = load i64, ptr %l10, !tbaa !24
  %t174 = add i64 %t171, 1
  store i64 %t174, ptr %l10, !tbaa !24
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t176 = load i64, ptr %l12, !tbaa !24
  %t179 = add i64 %t176, 1
  store i64 %t179, ptr %l12, !tbaa !24
  br label %bb28
bb36:
  %t181 = load i64, ptr %l10, !tbaa !24
  store i64 %t181, ptr %l113, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t182, ptr %l114, !tbaa !27
  %t183 = load i64, ptr %l113, !tbaa !24
  %t184 = icmp sge i64 %t183, 0
  br i1 %t184, label %bb37, label %bb38
bb37:
  %t186 = load i64, ptr %l113, !tbaa !24
  %t187 = icmp sle i64 %t186, 576460752303423487
  br i1 %t187, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d87f88b977e3dc00_ec36da1d2da1f7ac)
  unreachable
bb39:
  %t189 = load i64, ptr %l113, !tbaa !24
  %t190 = mul i64 %t189, 16
  %t191 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t190)
  %t192 = load { i64, ptr }, ptr %l114, !tbaa !27
  store i64 0, ptr %t193
  br label %fill.194
fill.194:
  %t197 = load i64, ptr %t193
  %t198 = icmp slt i64 %t197, %t189
  br i1 %t198, label %fillb.195, label %filld.196
fillb.195:
  %t199 = getelementptr { i64, ptr }, ptr %t191, i64 %t197
  store { i64, ptr } %t192, ptr %t199
  %t200 = add i64 %t197, 1
  store i64 %t200, ptr %t193
  br label %fill.194
filld.196:
  %t201 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t191, 1
  store { i64, ptr } %t202, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t204 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 0
  store i64 %t206, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t208 = load i64, ptr %l19, !tbaa !24
  %t209 = load i64, ptr %l18, !tbaa !24
  %t212 = icmp sgt i64 %t208, %t209
  br i1 %t212, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_d87f88b977e3dc00_ec36da1d2da1f7ac)
  unreachable
bb41:
  %t214 = load i64, ptr %l20, !tbaa !24
  %t216 = icmp sgt i64 %t214, 0
  br i1 %t216, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb46
bb43:
  %t218 = load i64, ptr %l19, !tbaa !24
  %t219 = load i64, ptr %l18, !tbaa !24
  %t222 = sub i64 %t218, %t219
  %t223 = load i64, ptr %l20, !tbaa !24
  %t226 = add i64 %t222, %t223
  %t228 = sub i64 %t226, 1
  %t229 = load i64, ptr %l20, !tbaa !24
  %t232 = sdiv i64 %t228, %t229
  store i64 %t232, ptr %l126, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb45
bb45:
  %t234 = load i64, ptr %l126, !tbaa !24
  store i64 %t234, ptr %l123, !tbaa !24
  br label %bb46
bb46:
  %t235 = load i64, ptr %l123, !tbaa !24
  store i64 %t235, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb47
bb47:
  %t236 = load i64, ptr %l22, !tbaa !24
  %t237 = load i64, ptr %l21, !tbaa !24
  %t240 = icmp slt i64 %t236, %t237
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb48, label %bb49
bb48:
  br label %bb61
bb49:
  br label %bb50
bb50:
  %t244 = load i64, ptr %l18, !tbaa !24
  %t245 = load i64, ptr %l22, !tbaa !24
  %t246 = load i64, ptr %l20, !tbaa !24
  %t249 = mul i64 %t245, %t246
  %t252 = add i64 %t244, %t249
  store i64 %t252, ptr %l23, !tbaa !24
  %t254 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t254, ptr %l144, !tbaa !27
  %t255 = load i64, ptr %l23, !tbaa !24
  %t257 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !27
  %t259 = getelementptr i8, ptr %t258, i64 %t255
  %t260 = load i8, ptr %t259, !tbaa !32
  %t261 = load i8, ptr %l9, !tbaa !22
  %t264 = icmp eq i8 %t260, %t261
  br i1 %t264, label %bb51, label %bb52
bb51:
  %t266 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t266, ptr %l149, !tbaa !27
  %t267 = load i64, ptr %l16, !tbaa !24
  store i64 %t267, ptr %l150, !tbaa !24
  %t268 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t268, ptr %l151, !tbaa !27
  %t269 = load i64, ptr %l17, !tbaa !24
  store i64 %t269, ptr %l152, !tbaa !24
  %t270 = load i64, ptr %l23, !tbaa !24
  store i64 %t270, ptr %l153, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  store i64 %t272, ptr %l154, !tbaa !24
  %t273 = load i64, ptr %l152, !tbaa !24
  %t274 = icmp sge i64 %t273, 0
  br i1 %t274, label %bb53, label %bb54
bb52:
  br label %bb59
bb53:
  %t276 = load i64, ptr %l152, !tbaa !24
  %t277 = load i64, ptr %l153, !tbaa !24
  %t278 = icmp sle i64 %t276, %t277
  br i1 %t278, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_2e2cde2328365f0d_7f8402dd000c68f1)
  unreachable
bb55:
  %t280 = load i64, ptr %l153, !tbaa !24
  %t281 = load i64, ptr %l154, !tbaa !24
  %t282 = icmp sle i64 %t280, %t281
  br i1 %t282, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_2e2cde2328365f0d_7f8402dd000c68f1)
  unreachable
bb57:
  %t284 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = load i64, ptr %l152, !tbaa !24
  %t287 = load i64, ptr %l153, !tbaa !24
  %t288 = getelementptr i8, ptr %t285, i64 %t286
  %t289 = sub i64 %t287, %t286
  %t290 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t291 = insertvalue { i64, ptr } %t290, ptr %t288, 1
  %t293 = load i64, ptr %l150, !tbaa !24
  %t294 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %t295, i64 %t293
  store { i64, ptr } %t291, ptr %t296, !tbaa !37
  %t297 = load i64, ptr %l16, !tbaa !24
  %t300 = add i64 %t297, 1
  store i64 %t300, ptr %l16, !tbaa !24
  %t302 = load i64, ptr %l23, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l17, !tbaa !24
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_2e2cde2328365f0d_7f8402dd000c68f1)
  unreachable
bb59:
  br label %bb60
bb60:
  %t306 = load i64, ptr %l22, !tbaa !24
  %t309 = add i64 %t306, 1
  store i64 %t309, ptr %l22, !tbaa !24
  br label %bb47
bb61:
  %t311 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t311, ptr %l167, !tbaa !27
  %t312 = load i64, ptr %l16, !tbaa !24
  store i64 %t312, ptr %l168, !tbaa !24
  %t313 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t313, ptr %l169, !tbaa !27
  %t314 = load i64, ptr %l17, !tbaa !24
  store i64 %t314, ptr %l170, !tbaa !24
  %t315 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t315, 0
  store i64 %t318, ptr %l173, !tbaa !24
  %t319 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 0
  store i64 %t320, ptr %l174, !tbaa !24
  %t321 = load i64, ptr %l170, !tbaa !24
  %t322 = icmp sge i64 %t321, 0
  br i1 %t322, label %bb62, label %bb63
bb62:
  %t324 = load i64, ptr %l170, !tbaa !24
  %t325 = load i64, ptr %l173, !tbaa !24
  %t326 = icmp sle i64 %t324, %t325
  br i1 %t326, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_e2668a7978910092_9cf11ab17c253f8e)
  unreachable
bb64:
  %t328 = load i64, ptr %l173, !tbaa !24
  %t329 = load i64, ptr %l174, !tbaa !24
  %t330 = icmp sle i64 %t328, %t329
  br i1 %t330, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_e2668a7978910092_9cf11ab17c253f8e)
  unreachable
bb66:
  %t332 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = load i64, ptr %l170, !tbaa !24
  %t335 = load i64, ptr %l173, !tbaa !24
  %t336 = getelementptr i8, ptr %t333, i64 %t334
  %t337 = sub i64 %t335, %t334
  %t338 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t336, 1
  %t341 = load i64, ptr %l168, !tbaa !24
  %t342 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr { i64, ptr }, ptr %t343, i64 %t341
  store { i64, ptr } %t339, ptr %t344, !tbaa !37
  %t345 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t345, ptr %rv
  br label %ret
bb67:
  call void @__olang_check_failed(ptr @olang_loc_e2668a7978910092_9cf11ab17c253f8e)
  unreachable
bb68:
  store i64 1, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb69
bb69:
  %t347 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t349 = load i64, ptr %l25, !tbaa !24
  %t353 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2efindFrom(ptr %v0, ptr %v1, { i64, ptr } %t347, { i64, ptr } %t348, i64 %t349)
  %t354 = extractvalue { i32, i64 } %t353, 1
  %t355 = extractvalue { i32, i64 } %t353, 0
  store i32 %t355, ptr %l185
  %t356 = icmp ne i32 %t355, 0
  br i1 %t356, label %bb71, label %ok.357, !prof !99
ok.357:
  store i64 %t354, ptr %l184
  br label %bb70
bb70:
  %t358 = load i64, ptr %l184, !tbaa !24
  store i64 %t358, ptr %l180, !tbaa !24
  br label %bb73
bb71:
  br label %bb72
bb72:
  br label %bb75
bb73:
  %t359 = load i64, ptr %l180, !tbaa !24
  %t360 = load i64, ptr %l24, !tbaa !24
  %t363 = add i64 %t360, 1
  store i64 %t363, ptr %l24, !tbaa !24
  %t366 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t366, 0
  %t371 = add i64 %t359, %t368
  store i64 %t371, ptr %l25, !tbaa !24
  br label %bb74
bb74:
  br label %bb69
bb75:
  %t373 = load i64, ptr %l24, !tbaa !24
  store i64 %t373, ptr %l193, !tbaa !24
  %t374 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t374, ptr %l194, !tbaa !27
  %t375 = load i64, ptr %l193, !tbaa !24
  %t376 = icmp sge i64 %t375, 0
  br i1 %t376, label %bb76, label %bb77
bb76:
  %t378 = load i64, ptr %l193, !tbaa !24
  %t379 = icmp sle i64 %t378, 576460752303423487
  br i1 %t379, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_f0ac1019d5a8f22f_63f4135826f9c983)
  unreachable
bb78:
  %t381 = load i64, ptr %l193, !tbaa !24
  %t382 = mul i64 %t381, 16
  %t383 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t382)
  %t384 = load { i64, ptr }, ptr %l194, !tbaa !27
  store i64 0, ptr %t385
  br label %fill.386
fill.386:
  %t389 = load i64, ptr %t385
  %t390 = icmp slt i64 %t389, %t381
  br i1 %t390, label %fillb.387, label %filld.388
fillb.387:
  %t391 = getelementptr { i64, ptr }, ptr %t383, i64 %t389
  store { i64, ptr } %t384, ptr %t391
  %t392 = add i64 %t389, 1
  store i64 %t392, ptr %t385
  br label %fill.386
filld.388:
  %t393 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t383, 1
  store { i64, ptr } %t394, ptr %l27, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  %t396 = load i64, ptr %l24, !tbaa !24
  %t398 = sub i64 %t396, 1
  store i64 %t398, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t400 = load i64, ptr %l29, !tbaa !24
  %t401 = load i64, ptr %l28, !tbaa !24
  %t404 = icmp sgt i64 %t400, %t401
  br i1 %t404, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_f0ac1019d5a8f22f_63f4135826f9c983)
  unreachable
bb80:
  %t406 = load i64, ptr %l30, !tbaa !24
  %t408 = icmp sgt i64 %t406, 0
  br i1 %t408, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l203, !tbaa !24
  br label %bb85
bb82:
  %t410 = load i64, ptr %l29, !tbaa !24
  %t411 = load i64, ptr %l28, !tbaa !24
  %t414 = sub i64 %t410, %t411
  %t415 = load i64, ptr %l30, !tbaa !24
  %t418 = add i64 %t414, %t415
  %t420 = sub i64 %t418, 1
  %t421 = load i64, ptr %l30, !tbaa !24
  %t424 = sdiv i64 %t420, %t421
  store i64 %t424, ptr %l206, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l206, !tbaa !24
  br label %bb84
bb84:
  %t426 = load i64, ptr %l206, !tbaa !24
  store i64 %t426, ptr %l203, !tbaa !24
  br label %bb85
bb85:
  %t427 = load i64, ptr %l203, !tbaa !24
  store i64 %t427, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb86
bb86:
  %t428 = load i64, ptr %l32, !tbaa !24
  %t429 = load i64, ptr %l31, !tbaa !24
  %t432 = icmp slt i64 %t428, %t429
  %t434 = xor i1 %t432, true
  br i1 %t434, label %bb87, label %bb88
bb87:
  br label %bb101
bb88:
  br label %bb89
bb89:
  %t436 = load i64, ptr %l28, !tbaa !24
  %t437 = load i64, ptr %l32, !tbaa !24
  %t438 = load i64, ptr %l30, !tbaa !24
  %t441 = mul i64 %t437, %t438
  %t444 = add i64 %t436, %t441
  store i64 %t444, ptr %l33, !tbaa !24
  %t446 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t447 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t448 = load i64, ptr %l25, !tbaa !24
  %t452 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2efindFrom(ptr %v0, ptr %v1, { i64, ptr } %t446, { i64, ptr } %t447, i64 %t448)
  %t453 = extractvalue { i32, i64 } %t452, 1
  %t454 = extractvalue { i32, i64 } %t452, 0
  store i32 %t454, ptr %l229
  %t455 = icmp ne i32 %t454, 0
  br i1 %t455, label %bb91, label %ok.456, !prof !99
ok.456:
  store i64 %t453, ptr %l228
  br label %bb90
bb90:
  %t457 = load i64, ptr %l228, !tbaa !24
  store i64 %t457, ptr %l224, !tbaa !24
  br label %bb93
bb91:
  br label %bb92
bb92:
  call void @__olang_check_failed(ptr @olang_loc_ed29604078651463_1de5c36b2217515f)
  unreachable
bb93:
  %t458 = load i64, ptr %l224, !tbaa !24
  store i64 %t458, ptr %l34, !tbaa !24
  %t459 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t459, ptr %l230, !tbaa !27
  %t460 = load i64, ptr %l33, !tbaa !24
  store i64 %t460, ptr %l231, !tbaa !24
  %t461 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t461, ptr %l232, !tbaa !27
  %t462 = load i64, ptr %l25, !tbaa !24
  store i64 %t462, ptr %l233, !tbaa !24
  %t463 = load i64, ptr %l34, !tbaa !24
  store i64 %t463, ptr %l234, !tbaa !24
  %t464 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  store i64 %t465, ptr %l235, !tbaa !24
  %t466 = load i64, ptr %l233, !tbaa !24
  %t467 = icmp sge i64 %t466, 0
  br i1 %t467, label %bb94, label %bb95
bb94:
  %t469 = load i64, ptr %l233, !tbaa !24
  %t470 = load i64, ptr %l234, !tbaa !24
  %t471 = icmp sle i64 %t469, %t470
  br i1 %t471, label %bb96, label %bb97
bb95:
  call void @__olang_check_failed(ptr @olang_loc_212fcf1c84890a91_ea10bf30807cf1ed)
  unreachable
bb96:
  %t473 = load i64, ptr %l234, !tbaa !24
  %t474 = load i64, ptr %l235, !tbaa !24
  %t475 = icmp sle i64 %t473, %t474
  br i1 %t475, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_212fcf1c84890a91_ea10bf30807cf1ed)
  unreachable
bb98:
  %t477 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !27
  %t479 = load i64, ptr %l233, !tbaa !24
  %t480 = load i64, ptr %l234, !tbaa !24
  %t481 = getelementptr i8, ptr %t478, i64 %t479
  %t482 = sub i64 %t480, %t479
  %t483 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t484 = insertvalue { i64, ptr } %t483, ptr %t481, 1
  %t486 = load i64, ptr %l231, !tbaa !24
  %t487 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !27
  %t489 = getelementptr { i64, ptr }, ptr %t488, i64 %t486
  store { i64, ptr } %t484, ptr %t489, !tbaa !37
  %t490 = load i64, ptr %l34, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t496 = add i64 %t490, %t493
  store i64 %t496, ptr %l25, !tbaa !24
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_212fcf1c84890a91_ea10bf30807cf1ed)
  unreachable
bb100:
  %t498 = load i64, ptr %l32, !tbaa !24
  %t501 = add i64 %t498, 1
  store i64 %t501, ptr %l32, !tbaa !24
  br label %bb86
bb101:
  %t503 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t503, ptr %l247, !tbaa !27
  %t504 = load i64, ptr %l24, !tbaa !24
  %t506 = sub i64 %t504, 1
  store i64 %t506, ptr %l249, !tbaa !24
  %t507 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t507, ptr %l250, !tbaa !27
  %t508 = load i64, ptr %l25, !tbaa !24
  store i64 %t508, ptr %l251, !tbaa !24
  %t509 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t512 = extractvalue { i64, ptr } %t509, 0
  store i64 %t512, ptr %l254, !tbaa !24
  %t513 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t514 = extractvalue { i64, ptr } %t513, 0
  store i64 %t514, ptr %l255, !tbaa !24
  %t515 = load i64, ptr %l251, !tbaa !24
  %t516 = icmp sge i64 %t515, 0
  br i1 %t516, label %bb102, label %bb103
bb102:
  %t518 = load i64, ptr %l251, !tbaa !24
  %t519 = load i64, ptr %l254, !tbaa !24
  %t520 = icmp sle i64 %t518, %t519
  br i1 %t520, label %bb104, label %bb105
bb103:
  call void @__olang_check_failed(ptr @olang_loc_f0b654da92e9b0b6_ad614321653256ba)
  unreachable
bb104:
  %t522 = load i64, ptr %l254, !tbaa !24
  %t523 = load i64, ptr %l255, !tbaa !24
  %t524 = icmp sle i64 %t522, %t523
  br i1 %t524, label %bb106, label %bb107
bb105:
  call void @__olang_check_failed(ptr @olang_loc_f0b654da92e9b0b6_ad614321653256ba)
  unreachable
bb106:
  %t526 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t527 = load ptr, ptr %t526, !tbaa !27
  %t528 = load i64, ptr %l251, !tbaa !24
  %t529 = load i64, ptr %l254, !tbaa !24
  %t530 = getelementptr i8, ptr %t527, i64 %t528
  %t531 = sub i64 %t529, %t528
  %t532 = insertvalue { i64, ptr } undef, i64 %t531, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t530, 1
  %t535 = load i64, ptr %l249, !tbaa !24
  %t536 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t537 = load ptr, ptr %t536, !tbaa !27
  %t538 = getelementptr { i64, ptr }, ptr %t537, i64 %t535
  store { i64, ptr } %t533, ptr %t538, !tbaa !37
  %t539 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t539, ptr %rv
  br label %ret
bb107:
  call void @__olang_check_failed(ptr @olang_loc_f0b654da92e9b0b6_ad614321653256ba)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2ebits(ptr %v0, ptr noalias dereferenceable(56) align 8 %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %l26 = alloca i64
  %l40 = alloca i1
  %l44 = alloca i1
  %l46 = alloca { i64, ptr }
  %l54 = alloca i64
  %l85 = alloca i64
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:decimal", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp eq i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/prelude/text:decimal", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp slt i64 %t11, -330
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l10, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = insertvalue { i32, i64 } zeroinitializer, i64 0, 1
  store { i32, i64 } %t17, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"std/prelude/text:decimal", ptr %t18, i32 0, i32 3
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = icmp sgt i64 %t21, 310
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t26 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t26, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/text:decimal", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/prelude/text:decimal", ptr %t36, i32 0, i32 3
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = icmp sge i64 %t39, 9
  br i1 %t41, label %bb14, label %bb15
bb14:
  store i64 27, ptr %l26, !tbaa !24
  br label %bb16
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"std/prelude/text:decimal", ptr %t43, i32 0, i32 3
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = getelementptr [9 x i64], ptr @G_2estd_2fprelude_2ftext_2edecimalShifts, i64 0, i64 %t46
  %t49 = load i64, ptr %t48, !tbaa !34
  store i64 %t49, ptr %l26, !tbaa !24
  br label %bb16
bb16:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l2, !tbaa !24
  %t55 = sub i64 0, %t53
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eshift(ptr %v0, ptr %t52, i64 %t55)
  br label %bb17
bb17:
  %t58 = load i64, ptr %l1, !tbaa !24
  %t60 = load i64, ptr %l2, !tbaa !24
  %t63 = add i64 %t58, %t60
  store i64 %t63, ptr %l1, !tbaa !24
  br label %bb18
bb18:
  br label %bb10
bb19:
  br label %bb20
bb20:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"std/prelude/text:decimal", ptr %t65, i32 0, i32 3
  %t68 = load i64, ptr %t67, !tbaa !24
  %t70 = icmp slt i64 %t68, 0
  br i1 %t70, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb26
bb22:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"std/prelude/text:decimal", ptr %t72, i32 0, i32 3
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = icmp eq i64 %t75, 0
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/text:decimal", ptr %t79, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l46, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i8, ptr %t84, i64 0
  %t86 = load i8, ptr %t85, !tbaa !32
  %t88 = icmp ult i8 %t86, 5
  store i1 %t88, ptr %l44, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l44, !tbaa !21
  store i1 %t90, ptr %l40, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l40, !tbaa !21
  %t92 = xor i1 %t91, true
  br i1 %t92, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"std/prelude/text:decimal", ptr %t94, i32 0, i32 3
  %t97 = load i64, ptr %t96, !tbaa !24
  %t99 = sub i64 0, %t97
  %t101 = icmp sge i64 %t99, 9
  br i1 %t101, label %bb30, label %bb31
bb30:
  store i64 27, ptr %l54, !tbaa !24
  br label %bb32
bb31:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"std/prelude/text:decimal", ptr %t103, i32 0, i32 3
  %t106 = load i64, ptr %t105, !tbaa !24
  %t108 = sub i64 0, %t106
  %t110 = getelementptr [9 x i64], ptr @G_2estd_2fprelude_2ftext_2edecimalShifts, i64 0, i64 %t108
  %t111 = load i64, ptr %t110, !tbaa !34
  store i64 %t111, ptr %l54, !tbaa !24
  br label %bb32
bb32:
  %t113 = load i64, ptr %l54, !tbaa !24
  store i64 %t113, ptr %l3, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eshift(ptr %v0, ptr %t114, i64 %t115)
  br label %bb33
bb33:
  %t118 = load i64, ptr %l1, !tbaa !24
  %t120 = load i64, ptr %l3, !tbaa !24
  %t123 = sub i64 %t118, %t120
  store i64 %t123, ptr %l1, !tbaa !24
  br label %bb34
bb34:
  br label %bb20
bb35:
  %t125 = load i64, ptr %l1, !tbaa !24
  %t128 = sub i64 %t125, 1
  store i64 %t128, ptr %l1, !tbaa !24
  %t130 = load i64, ptr %l1, !tbaa !24
  %t132 = icmp slt i64 %t130, -1022
  br i1 %t132, label %bb36, label %bb37
bb36:
  %t134 = load i64, ptr %l1, !tbaa !24
  %t136 = sub i64 -1022, %t134
  store i64 %t136, ptr %l4, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l4, !tbaa !24
  %t141 = sub i64 0, %t139
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eshift(ptr %v0, ptr %t138, i64 %t141)
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t144 = load i64, ptr %l1, !tbaa !24
  %t146 = load i64, ptr %l4, !tbaa !24
  %t149 = add i64 %t144, %t146
  store i64 %t149, ptr %l1, !tbaa !24
  br label %bb39
bb39:
  %t151 = load i64, ptr %l1, !tbaa !24
  %t153 = add i64 %t151, 1023
  %t155 = icmp sge i64 %t153, 2047
  br i1 %t155, label %bb40, label %bb41
bb40:
  %t158 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t158, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t159 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eshift(ptr %v0, ptr %t159, i64 53)
  br label %bb43
bb43:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eroundedInteger(ptr %v0, ptr %t161)
  store i64 %t163, ptr %l85
  br label %bb44
bb44:
  %t164 = load i64, ptr %l85, !tbaa !65
  store i64 %t164, ptr %l5, !tbaa !65
  %t165 = load i64, ptr %l5, !tbaa !65
  %t166 = shl i64 1, 53
  %t169 = icmp eq i64 %t165, %t166
  br i1 %t169, label %bb45, label %bb46
bb45:
  %t171 = load i64, ptr %l5, !tbaa !65
  %t174 = lshr i64 %t171, 1
  store i64 %t174, ptr %l5, !tbaa !65
  %t176 = load i64, ptr %l1, !tbaa !24
  %t179 = add i64 %t176, 1
  store i64 %t179, ptr %l1, !tbaa !24
  %t181 = load i64, ptr %l1, !tbaa !24
  %t183 = add i64 %t181, 1023
  %t185 = icmp sge i64 %t183, 2047
  br i1 %t185, label %bb47, label %bb48
bb46:
  br label %bb50
bb47:
  %t188 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t188, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t189 = load i64, ptr %l1, !tbaa !24
  %t191 = add i64 %t189, 1023
  store i64 %t191, ptr %l6, !tbaa !24
  %t193 = load i64, ptr %l5, !tbaa !65
  %t194 = shl i64 1, 52
  %t197 = and i64 %t193, %t194
  %t199 = icmp eq i64 %t197, 0
  br i1 %t199, label %bb51, label %bb52
bb51:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t201 = load i64, ptr %l5, !tbaa !65
  %t203 = and i64 %t201, 4503599627370495
  %t204 = load i64, ptr %l6, !tbaa !24
  %t207 = shl i64 %t204, 52
  %t210 = or i64 %t203, %t207
  %t212 = insertvalue { i32, i64 } zeroinitializer, i64 %t210, 1
  store { i32, i64 } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eleftShift(ptr %v0, ptr noalias dereferenceable(56) align 8 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l33 = alloca { i64, ptr }
  %l37 = alloca i64
  %l46 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l89 = alloca i64
  %l95 = alloca i64
  %l98 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i1
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l137 = alloca i64
  %l140 = alloca i64
  %l149 = alloca i64
  %l152 = alloca i1
  %l163 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:decimal", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !65
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/prelude/text:decimal", ptr %t8, i32 0, i32 2
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = sub i64 %t11, 1
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sge i64 %t15, 0
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t21 = load i64, ptr %l3, !tbaa !65
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"std/prelude/text:decimal", ptr %t23, i32 0, i32 0
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l33, !tbaa !27
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr i8, ptr %t30, i64 %t27
  %t32 = load i8, ptr %t31, !tbaa !32
  %t34 = zext i8 %t32 to i64
  store i64 %a1, ptr %l37, !tbaa !65
  %t37 = load i64, ptr %l37, !tbaa !65
  %t38 = load i64, ptr %l37, !tbaa !65
  %t39 = shl i64 %t34, %t38
  %t42 = add i64 %t21, %t39
  store i64 %t42, ptr %l3, !tbaa !65
  %t44 = load i64, ptr %l3, !tbaa !65
  %t46 = udiv i64 %t44, 10
  store i64 %t46, ptr %l5, !tbaa !65
  %t48 = load i64, ptr %l2, !tbaa !24
  %t51 = sub i64 %t48, 1
  store i64 %t51, ptr %l2, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/text:decimal", ptr %t53, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l46, !tbaa !27
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l3, !tbaa !65
  %t59 = load i64, ptr %l5, !tbaa !65
  %t61 = mul i64 10, %t59
  %t64 = sub i64 %t58, %t61
  %t66 = trunc i64 %t64 to i8
  %t69 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t57
  store i8 %t66, ptr %t71, !tbaa !32
  %t72 = load i64, ptr %l5, !tbaa !65
  store i64 %t72, ptr %l3, !tbaa !65
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = sub i64 %t74, 1
  store i64 %t77, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  br label %bb1
bb6:
  br label %bb7
bb7:
  %t79 = load i64, ptr %l3, !tbaa !65
  %t81 = icmp ugt i64 %t79, 0
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t85 = load i64, ptr %l3, !tbaa !65
  %t87 = udiv i64 %t85, 10
  store i64 %t87, ptr %l6, !tbaa !65
  %t89 = load i64, ptr %l2, !tbaa !24
  %t92 = sub i64 %t89, 1
  store i64 %t92, ptr %l2, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"std/prelude/text:decimal", ptr %t94, i32 0, i32 1
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l66, !tbaa !27
  %t98 = load i64, ptr %l2, !tbaa !24
  %t99 = load i64, ptr %l3, !tbaa !65
  %t100 = load i64, ptr %l6, !tbaa !65
  %t102 = mul i64 10, %t100
  %t105 = sub i64 %t99, %t102
  %t107 = trunc i64 %t105 to i8
  %t110 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i8, ptr %t111, i64 %t98
  store i8 %t107, ptr %t112, !tbaa !32
  %t113 = load i64, ptr %l6, !tbaa !65
  store i64 %t113, ptr %l3, !tbaa !65
  br label %bb11
bb11:
  br label %bb7
bb12:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/prelude/text:decimal", ptr %t115, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = load i64, ptr %l2, !tbaa !24
  %t124 = sub i64 %t120, %t121
  store i64 %t124, ptr %l7, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l79, !tbaa !29
  %t127 = load ptr, ptr %l79, !tbaa !29
  %t128 = getelementptr %"std/prelude/text:decimal", ptr %t127, i32 0, i32 3
  %t129 = load i64, ptr %t128, !tbaa !24
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"std/prelude/text:decimal", ptr %t132, i32 0, i32 2
  %t135 = load i64, ptr %t134, !tbaa !24
  %t138 = sub i64 %t131, %t135
  %t141 = add i64 %t129, %t138
  %t143 = load ptr, ptr %l79, !tbaa !29
  %t144 = getelementptr %"std/prelude/text:decimal", ptr %t143, i32 0, i32 3
  store i64 %t141, ptr %t144, !tbaa !24
  %t145 = load i64, ptr %l7, !tbaa !24
  %t147 = icmp slt i64 %t145, 800
  br i1 %t147, label %bb13, label %bb14
bb13:
  %t149 = load i64, ptr %l7, !tbaa !24
  store i64 %t149, ptr %l89, !tbaa !24
  br label %bb15
bb14:
  store i64 800, ptr %l89, !tbaa !24
  br label %bb15
bb15:
  %t151 = load i64, ptr %l89, !tbaa !24
  store i64 %t151, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t152 = load i64, ptr %l8, !tbaa !24
  store i64 %t152, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t154 = load i64, ptr %l10, !tbaa !24
  %t155 = load i64, ptr %l9, !tbaa !24
  %t158 = icmp sgt i64 %t154, %t155
  br i1 %t158, label %bb16, label %bb17
bb16:
  %t160 = load i64, ptr %l11, !tbaa !24
  %t162 = icmp sgt i64 %t160, 0
  br i1 %t162, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb21
bb18:
  %t164 = load i64, ptr %l10, !tbaa !24
  %t165 = load i64, ptr %l9, !tbaa !24
  %t168 = sub i64 %t164, %t165
  %t169 = load i64, ptr %l11, !tbaa !24
  %t172 = add i64 %t168, %t169
  %t174 = sub i64 %t172, 1
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = sdiv i64 %t174, %t175
  store i64 %t178, ptr %l98, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb20
bb20:
  %t180 = load i64, ptr %l98, !tbaa !24
  store i64 %t180, ptr %l95, !tbaa !24
  br label %bb21
bb21:
  %t181 = load i64, ptr %l95, !tbaa !24
  store i64 %t181, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t182 = load i64, ptr %l12, !tbaa !24
  %t183 = sub i64 %t182, 1
  store i64 %t183, ptr %l107, !tbaa !24
  %t184 = load i64, ptr %l12, !tbaa !24
  %t185 = icmp slt i64 %t184, 2147483648
  %t186 = load i64, ptr %l13, !tbaa !24
  %t187 = icmp sge i64 %t186, 0
  %t190 = and i1 %t185, %t187
  store i1 %t190, ptr %l110, !tbaa !21
  br label %bb22
bb22:
  %t191 = load i64, ptr %l13, !tbaa !24
  %t192 = load i64, ptr %l12, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t199 = load i64, ptr %l9, !tbaa !24
  %t200 = load i64, ptr %l13, !tbaa !24
  %t201 = load i64, ptr %l11, !tbaa !24
  %t204 = mul i64 %t200, %t201
  %t207 = add i64 %t199, %t204
  store i64 %t207, ptr %l14, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"std/prelude/text:decimal", ptr %t209, i32 0, i32 0
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l121, !tbaa !27
  %t213 = load i64, ptr %l14, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"std/prelude/text:decimal", ptr %t214, i32 0, i32 1
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l124, !tbaa !27
  %t218 = load i64, ptr %l2, !tbaa !24
  %t219 = load i64, ptr %l14, !tbaa !24
  %t222 = add i64 %t218, %t219
  %t224 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i8, ptr %t225, i64 %t222
  %t227 = load i8, ptr %t226, !tbaa !32
  %t230 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i8, ptr %t231, i64 %t213
  store i8 %t227, ptr %t232, !tbaa !32
  br label %bb26
bb26:
  %t233 = load i64, ptr %l13, !tbaa !24
  %t236 = add i64 %t233, 1
  store i64 %t236, ptr %l13, !tbaa !24
  br label %bb22
bb27:
  %t238 = load i64, ptr %l8, !tbaa !24
  store i64 %t238, ptr %l15, !tbaa !24
  %t240 = load i64, ptr %l7, !tbaa !24
  store i64 %t240, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t242 = load i64, ptr %l16, !tbaa !24
  %t243 = load i64, ptr %l15, !tbaa !24
  %t246 = icmp sgt i64 %t242, %t243
  br i1 %t246, label %bb28, label %bb29
bb28:
  %t248 = load i64, ptr %l17, !tbaa !24
  %t250 = icmp sgt i64 %t248, 0
  br i1 %t250, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb33
bb30:
  %t252 = load i64, ptr %l16, !tbaa !24
  %t253 = load i64, ptr %l15, !tbaa !24
  %t256 = sub i64 %t252, %t253
  %t257 = load i64, ptr %l17, !tbaa !24
  %t260 = add i64 %t256, %t257
  %t262 = sub i64 %t260, 1
  %t263 = load i64, ptr %l17, !tbaa !24
  %t266 = sdiv i64 %t262, %t263
  store i64 %t266, ptr %l140, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb32
bb32:
  %t268 = load i64, ptr %l140, !tbaa !24
  store i64 %t268, ptr %l137, !tbaa !24
  br label %bb33
bb33:
  %t269 = load i64, ptr %l137, !tbaa !24
  store i64 %t269, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t270 = load i64, ptr %l18, !tbaa !24
  %t271 = sub i64 %t270, 1
  store i64 %t271, ptr %l149, !tbaa !24
  %t272 = load i64, ptr %l18, !tbaa !24
  %t273 = icmp slt i64 %t272, 2147483648
  %t274 = load i64, ptr %l19, !tbaa !24
  %t275 = icmp sge i64 %t274, 0
  %t278 = and i1 %t273, %t275
  store i1 %t278, ptr %l152, !tbaa !21
  br label %bb34
bb34:
  %t279 = load i64, ptr %l19, !tbaa !24
  %t280 = load i64, ptr %l18, !tbaa !24
  %t283 = icmp slt i64 %t279, %t280
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb35, label %bb36
bb35:
  br label %bb42
bb36:
  br label %bb37
bb37:
  %t287 = load i64, ptr %l15, !tbaa !24
  %t288 = load i64, ptr %l19, !tbaa !24
  %t289 = load i64, ptr %l17, !tbaa !24
  %t292 = mul i64 %t288, %t289
  %t295 = add i64 %t287, %t292
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"std/prelude/text:decimal", ptr %t297, i32 0, i32 1
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  store { i64, ptr } %t300, ptr %l163, !tbaa !27
  %t301 = load i64, ptr %l2, !tbaa !24
  %t305 = add i64 %t301, %t295
  %t307 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i8, ptr %t308, i64 %t305
  %t310 = load i8, ptr %t309, !tbaa !32
  %t312 = icmp ne i8 %t310, 0
  br i1 %t312, label %bb38, label %bb39
bb38:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"std/prelude/text:decimal", ptr %t314, i32 0, i32 4
  store i1 true, ptr %t316, !tbaa !21
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t317 = load i64, ptr %l19, !tbaa !24
  %t320 = add i64 %t317, 1
  store i64 %t320, ptr %l19, !tbaa !24
  br label %bb34
bb42:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i64, ptr %l8, !tbaa !24
  %t326 = getelementptr %"std/prelude/text:decimal", ptr %t322, i32 0, i32 2
  store i64 %t323, ptr %t326, !tbaa !24
  %t327 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2etrim(ptr %v0, ptr %t327)
  br label %bb43
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2erightShift(ptr %v0, ptr noalias dereferenceable(56) align 8 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l21 = alloca i64
  %l35 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l49 = alloca i64
  %l58 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l65 = alloca i64
  %l86 = alloca i64
  %l95 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !65
  br label %bb1
bb1:
  %t1 = load i64, ptr %l4, !tbaa !65
  %t2 = load i64, ptr %l1, !tbaa !65
  store i64 %t2, ptr %l9, !tbaa !65
  %t4 = load i64, ptr %l9, !tbaa !65
  %t5 = load i64, ptr %l9, !tbaa !65
  %t6 = lshr i64 %t1, %t5
  %t8 = icmp eq i64 %t6, 0
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/prelude/text:decimal", ptr %t13, i32 0, i32 2
  %t16 = load i64, ptr %t15, !tbaa !24
  %t19 = icmp sge i64 %t12, %t16
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l4, !tbaa !65
  %t23 = icmp eq i64 %t21, 0
  br i1 %t23, label %bb7, label %bb8
bb6:
  br label %bb16
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"std/prelude/text:decimal", ptr %t25, i32 0, i32 2
  store i64 0, ptr %t27, !tbaa !24
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t28 = load i64, ptr %l4, !tbaa !65
  %t29 = load i64, ptr %l1, !tbaa !65
  store i64 %t29, ptr %l21, !tbaa !65
  %t31 = load i64, ptr %l21, !tbaa !65
  %t32 = load i64, ptr %l21, !tbaa !65
  %t33 = lshr i64 %t28, %t32
  %t35 = icmp eq i64 %t33, 0
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t39 = load i64, ptr %l4, !tbaa !65
  %t42 = mul i64 %t39, 10
  store i64 %t42, ptr %l4, !tbaa !65
  %t44 = load i64, ptr %l2, !tbaa !24
  %t47 = add i64 %t44, 1
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb14
bb14:
  br label %bb10
bb15:
  br label %bb18
bb16:
  %t49 = load i64, ptr %l4, !tbaa !65
  %t52 = mul i64 %t49, 10
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/text:decimal", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l35, !tbaa !27
  %t57 = load i64, ptr %l2, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t57
  %t62 = load i8, ptr %t61, !tbaa !32
  %t64 = zext i8 %t62 to i64
  %t67 = add i64 %t52, %t64
  store i64 %t67, ptr %l4, !tbaa !65
  %t69 = load i64, ptr %l2, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l2, !tbaa !24
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l43, !tbaa !29
  %t75 = load ptr, ptr %l43, !tbaa !29
  %t76 = getelementptr %"std/prelude/text:decimal", ptr %t75, i32 0, i32 3
  %t77 = load i64, ptr %t76, !tbaa !24
  %t79 = load i64, ptr %l2, !tbaa !24
  %t81 = sub i64 %t79, 1
  %t84 = sub i64 %t77, %t81
  %t86 = load ptr, ptr %l43, !tbaa !29
  %t87 = getelementptr %"std/prelude/text:decimal", ptr %t86, i32 0, i32 3
  store i64 %t84, ptr %t87, !tbaa !24
  %t88 = load i64, ptr %l1, !tbaa !65
  store i64 %t88, ptr %l49, !tbaa !65
  %t89 = load i64, ptr %l49, !tbaa !65
  %t90 = load i64, ptr %l49, !tbaa !65
  %t91 = shl i64 1, %t90
  %t93 = sub i64 %t91, 1
  store i64 %t93, ptr %l5, !tbaa !65
  br label %bb19
bb19:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/text:decimal", ptr %t96, i32 0, i32 2
  %t99 = load i64, ptr %t98, !tbaa !24
  %t102 = icmp slt i64 %t95, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"std/prelude/text:decimal", ptr %t106, i32 0, i32 0
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l58, !tbaa !27
  %t110 = load i64, ptr %l2, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/text:decimal", ptr %t117, i32 0, i32 0
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l62, !tbaa !27
  %t121 = load i64, ptr %l3, !tbaa !24
  %t122 = load i64, ptr %l4, !tbaa !65
  %t123 = load i64, ptr %l1, !tbaa !65
  store i64 %t123, ptr %l65, !tbaa !65
  %t125 = load i64, ptr %l65, !tbaa !65
  %t126 = load i64, ptr %l65, !tbaa !65
  %t127 = lshr i64 %t122, %t126
  %t129 = trunc i64 %t127 to i8
  %t132 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i8, ptr %t133, i64 %t121
  store i8 %t129, ptr %t134, !tbaa !32
  %t135 = load i64, ptr %l3, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l3, !tbaa !24
  %t140 = load i64, ptr %l4, !tbaa !65
  %t142 = load i64, ptr %l5, !tbaa !65
  %t145 = and i64 %t140, %t142
  %t147 = mul i64 %t145, 10
  %t150 = zext i8 %t115 to i64
  %t153 = add i64 %t147, %t150
  store i64 %t153, ptr %l4, !tbaa !65
  %t155 = load i64, ptr %l2, !tbaa !24
  %t158 = add i64 %t155, 1
  store i64 %t158, ptr %l2, !tbaa !24
  br label %bb23
bb23:
  br label %bb19
bb24:
  br label %bb25
bb25:
  %t160 = load i64, ptr %l4, !tbaa !65
  %t162 = icmp ugt i64 %t160, 0
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb26, label %bb27
bb26:
  br label %bb36
bb27:
  br label %bb28
bb28:
  %t166 = load i64, ptr %l4, !tbaa !65
  %t167 = load i64, ptr %l1, !tbaa !65
  store i64 %t167, ptr %l86, !tbaa !65
  %t169 = load i64, ptr %l86, !tbaa !65
  %t170 = load i64, ptr %l86, !tbaa !65
  %t171 = lshr i64 %t166, %t170
  store i64 %t171, ptr %l7, !tbaa !65
  %t173 = load i64, ptr %l4, !tbaa !65
  %t175 = load i64, ptr %l5, !tbaa !65
  %t178 = and i64 %t173, %t175
  store i64 %t178, ptr %l4, !tbaa !65
  %t180 = load i64, ptr %l3, !tbaa !24
  %t182 = icmp slt i64 %t180, 800
  br i1 %t182, label %bb29, label %bb30
bb29:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"std/prelude/text:decimal", ptr %t184, i32 0, i32 0
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  store { i64, ptr } %t187, ptr %l95, !tbaa !27
  %t188 = load i64, ptr %l3, !tbaa !24
  %t189 = load i64, ptr %l7, !tbaa !65
  %t191 = trunc i64 %t189 to i8
  %t194 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i8, ptr %t195, i64 %t188
  store i8 %t191, ptr %t196, !tbaa !32
  %t197 = load i64, ptr %l3, !tbaa !24
  %t200 = add i64 %t197, 1
  store i64 %t200, ptr %l3, !tbaa !24
  br label %bb34
bb30:
  %t202 = load i64, ptr %l7, !tbaa !65
  %t204 = icmp ugt i64 %t202, 0
  br i1 %t204, label %bb31, label %bb32
bb31:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"std/prelude/text:decimal", ptr %t206, i32 0, i32 4
  store i1 true, ptr %t208, !tbaa !21
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t209 = load i64, ptr %l4, !tbaa !65
  %t212 = mul i64 %t209, 10
  store i64 %t212, ptr %l4, !tbaa !65
  br label %bb35
bb35:
  br label %bb25
bb36:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i64, ptr %l3, !tbaa !24
  %t218 = getelementptr %"std/prelude/text:decimal", ptr %t214, i32 0, i32 2
  store i64 %t215, ptr %t218, !tbaa !24
  %t219 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2etrim(ptr %v0, ptr %t219)
  br label %bb37
bb37:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eroundedInteger(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l11 = alloca i1
  %l21 = alloca { i64, ptr }
  %l43 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:decimal", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 20
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = xor i64 0, -1
  store i64 %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l1, !tbaa !65
  store i64 0, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"std/prelude/text:decimal", ptr %t11, i32 0, i32 3
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = icmp slt i64 %t10, %t14
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/text:decimal", ptr %t20, i32 0, i32 2
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = icmp slt i64 %t19, %t23
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l11, !tbaa !21
  %t29 = xor i1 %t28, true
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t31 = load i64, ptr %l1, !tbaa !65
  %t34 = mul i64 %t31, 10
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/text:decimal", ptr %t35, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l21, !tbaa !27
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i8, ptr %t42, i64 %t39
  %t44 = load i8, ptr %t43, !tbaa !32
  %t46 = zext i8 %t44 to i64
  %t49 = add i64 %t34, %t46
  store i64 %t49, ptr %l1, !tbaa !65
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = add i64 %t51, 1
  store i64 %t54, ptr %l2, !tbaa !24
  br label %bb11
bb11:
  br label %bb4
bb12:
  br label %bb13
bb13:
  %t56 = load i64, ptr %l2, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"std/prelude/text:decimal", ptr %t57, i32 0, i32 3
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = icmp slt i64 %t56, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t67 = load i64, ptr %l1, !tbaa !65
  %t70 = mul i64 %t67, 10
  store i64 %t70, ptr %l1, !tbaa !65
  %t72 = load i64, ptr %l2, !tbaa !24
  %t75 = add i64 %t72, 1
  store i64 %t75, ptr %l2, !tbaa !24
  br label %bb17
bb17:
  br label %bb13
bb18:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"std/prelude/text:decimal", ptr %t78, i32 0, i32 3
  %t81 = load i64, ptr %t80, !tbaa !24
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eroundsUp(ptr %v0, ptr %t77, i64 %t81)
  store i1 %t84, ptr %l43
  br label %bb19
bb19:
  %t85 = load i1, ptr %l43, !tbaa !21
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t86 = load i64, ptr %l1, !tbaa !65
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l1, !tbaa !65
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t91 = load i64, ptr %l1, !tbaa !65
  store i64 %t91, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eroundsUp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l11 = alloca { i64, ptr }
  %l15 = alloca i1
  %l26 = alloca i1
  %l28 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/prelude/text:decimal", ptr %t6, i32 0, i32 2
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = icmp sge i64 %t5, %t9
  store i1 %t12, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l4, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/prelude/text:decimal", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l11, !tbaa !27
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t27 = icmp eq i8 %t25, 5
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = add i64 %t29, 1
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/prelude/text:decimal", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t38 = icmp eq i64 %t31, %t35
  store i1 %t38, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l15, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"std/prelude/text:decimal", ptr %t41, i32 0, i32 4
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb11:
  br label %bb18
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l1, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"std/prelude/text:decimal", ptr %t51, i32 0, i32 0
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l28, !tbaa !27
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = sub i64 %t55, 1
  %t59 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t57
  %t62 = load i8, ptr %t61, !tbaa !32
  %t64 = urem i8 %t62, 2
  %t66 = icmp eq i8 %t64, 1
  store i1 %t66, ptr %l26, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  %t68 = load i1, ptr %l26, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/text:decimal", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l35, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  %t80 = icmp uge i8 %t78, 5
  store i1 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eset(ptr %v0, ptr %v1, ptr noalias dereferenceable(56) align 8 %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca { i64, ptr }
  %l22 = alloca i1
  %l27 = alloca i1
  %l31 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l100 = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i1 false, ptr %l3, !tbaa !21
  br label %bb1
bb1:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %bb27
bb3:
  br label %bb4
bb4:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l12, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l4, !tbaa !22
  %t19 = load i8, ptr %l4, !tbaa !22
  %t21 = icmp eq i8 %t19, 46
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/prelude/text:decimal", ptr %t24, i32 0, i32 2
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = getelementptr %"std/prelude/text:decimal", ptr %t23, i32 0, i32 3
  store i64 %t27, ptr %t30, !tbaa !24
  br label %bb25
bb6:
  %t31 = load i8, ptr %l4, !tbaa !22
  %t33 = icmp ult i8 %t31, 48
  br i1 %t33, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb9
bb8:
  %t35 = load i8, ptr %l4, !tbaa !22
  %t37 = icmp ugt i8 %t35, 57
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  br label %bb27
bb11:
  %t40 = load i8, ptr %l4, !tbaa !22
  %t42 = icmp eq i8 %t40, 48
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"std/prelude/text:decimal", ptr %t44, i32 0, i32 2
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = icmp eq i64 %t47, 0
  store i1 %t49, ptr %l27, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l31, !tbaa !29
  %t53 = load ptr, ptr %l31, !tbaa !29
  %t54 = getelementptr %"std/prelude/text:decimal", ptr %t53, i32 0, i32 3
  %t55 = load i64, ptr %t54, !tbaa !24
  %t58 = sub i64 %t55, 1
  %t60 = load ptr, ptr %l31, !tbaa !29
  %t61 = getelementptr %"std/prelude/text:decimal", ptr %t60, i32 0, i32 3
  store i64 %t58, ptr %t61, !tbaa !24
  br label %bb23
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"std/prelude/text:decimal", ptr %t62, i32 0, i32 2
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp slt i64 %t65, 800
  br i1 %t67, label %bb17, label %bb18
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/text:decimal", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l39, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"std/prelude/text:decimal", ptr %t73, i32 0, i32 2
  %t76 = load i64, ptr %t75, !tbaa !24
  %t77 = load i8, ptr %l4, !tbaa !22
  %t79 = sub i8 %t77, 48
  %t83 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i8, ptr %t84, i64 %t76
  store i8 %t79, ptr %t85, !tbaa !32
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l45, !tbaa !29
  %t87 = load ptr, ptr %l45, !tbaa !29
  %t88 = getelementptr %"std/prelude/text:decimal", ptr %t87, i32 0, i32 2
  %t89 = load i64, ptr %t88, !tbaa !24
  %t92 = add i64 %t89, 1
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = getelementptr %"std/prelude/text:decimal", ptr %t94, i32 0, i32 2
  store i64 %t92, ptr %t95, !tbaa !24
  br label %bb22
bb18:
  %t96 = load i8, ptr %l4, !tbaa !22
  %t98 = icmp ne i8 %t96, 48
  br i1 %t98, label %bb19, label %bb20
bb19:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"std/prelude/text:decimal", ptr %t100, i32 0, i32 4
  store i1 true, ptr %t102, !tbaa !21
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t103 = load i64, ptr %l2, !tbaa !24
  %t106 = add i64 %t103, 1
  store i64 %t106, ptr %l2, !tbaa !24
  br label %bb26
bb26:
  br label %bb1
bb27:
  %t108 = load i1, ptr %l3, !tbaa !21
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb28, label %bb29
bb28:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"std/prelude/text:decimal", ptr %t113, i32 0, i32 2
  %t116 = load i64, ptr %t115, !tbaa !24
  %t119 = getelementptr %"std/prelude/text:decimal", ptr %t112, i32 0, i32 3
  store i64 %t116, ptr %t119, !tbaa !24
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t120 = load i64, ptr %l2, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t126 = icmp slt i64 %t120, %t123
  br i1 %t126, label %bb31, label %bb32
bb31:
  %t128 = load i64, ptr %l2, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l2, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t133, ptr %l67, !tbaa !27
  %t134 = load i64, ptr %l2, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i8, ptr %t137, i64 %t134
  %t139 = load i8, ptr %t138, !tbaa !32
  %t141 = icmp eq i8 %t139, 43
  br i1 %t141, label %bb33, label %bb34
bb32:
  br label %bb48
bb33:
  %t143 = load i64, ptr %l2, !tbaa !24
  %t146 = add i64 %t143, 1
  store i64 %t146, ptr %l2, !tbaa !24
  br label %bb38
bb34:
  %t148 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t148, ptr %l74, !tbaa !27
  %t149 = load i64, ptr %l2, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i8, ptr %t152, i64 %t149
  %t154 = load i8, ptr %t153, !tbaa !32
  %t156 = icmp eq i8 %t154, 45
  br i1 %t156, label %bb35, label %bb36
bb35:
  store i64 -1, ptr %l5, !tbaa !24
  %t158 = load i64, ptr %l2, !tbaa !24
  %t161 = add i64 %t158, 1
  store i64 %t161, ptr %l2, !tbaa !24
  br label %bb37
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb39
bb39:
  %t163 = load i64, ptr %l2, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t169 = icmp slt i64 %t163, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb40, label %bb41
bb40:
  br label %bb47
bb41:
  br label %bb42
bb42:
  %t173 = load i64, ptr %l6, !tbaa !24
  %t175 = icmp slt i64 %t173, 10000
  br i1 %t175, label %bb43, label %bb44
bb43:
  %t177 = load i64, ptr %l6, !tbaa !24
  %t180 = mul i64 %t177, 10
  %t181 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t181, ptr %l91, !tbaa !27
  %t182 = load i64, ptr %l2, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i8, ptr %t185, i64 %t182
  %t187 = load i8, ptr %t186, !tbaa !32
  %t189 = sub i8 %t187, 48
  %t191 = zext i8 %t189 to i64
  %t194 = add i64 %t180, %t191
  store i64 %t194, ptr %l6, !tbaa !24
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t196 = load i64, ptr %l2, !tbaa !24
  %t199 = add i64 %t196, 1
  store i64 %t199, ptr %l2, !tbaa !24
  br label %bb46
bb46:
  br label %bb39
bb47:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l100, !tbaa !29
  %t202 = load ptr, ptr %l100, !tbaa !29
  %t203 = getelementptr %"std/prelude/text:decimal", ptr %t202, i32 0, i32 3
  %t204 = load i64, ptr %t203, !tbaa !24
  %t206 = load i64, ptr %l6, !tbaa !24
  %t207 = load i64, ptr %l5, !tbaa !24
  %t210 = mul i64 %t206, %t207
  %t213 = add i64 %t204, %t210
  %t215 = load ptr, ptr %l100, !tbaa !29
  %t216 = getelementptr %"std/prelude/text:decimal", ptr %t215, i32 0, i32 3
  store i64 %t213, ptr %t216, !tbaa !24
  br label %bb48
bb48:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eshift(ptr %v0, ptr noalias dereferenceable(56) align 8 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:decimal", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp eq i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  br label %bb4
bb4:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp sgt i64 %t8, 60
  %t12 = xor i1 %t10, true
  br i1 %t12, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eleftShift(ptr %v0, ptr %t14, i64 60)
  br label %bb8
bb8:
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t16, 60
  store i64 %t19, ptr %l1, !tbaa !24
  br label %bb9
bb9:
  br label %bb4
bb10:
  br label %bb11
bb11:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp slt i64 %t21, -60
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2erightShift(ptr %v0, ptr %t27, i64 60)
  br label %bb15
bb15:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = add i64 %t29, 60
  store i64 %t32, ptr %l1, !tbaa !24
  br label %bb16
bb16:
  br label %bb11
bb17:
  %t34 = load i64, ptr %l1, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb18, label %bb19
bb18:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eleftShift(ptr %v0, ptr %t38, i64 %t39)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = icmp slt i64 %t43, 0
  br i1 %t45, label %bb22, label %bb23
bb22:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l1, !tbaa !24
  %t50 = sub i64 0, %t48
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2erightShift(ptr %v0, ptr %t47, i64 %t50)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %ret
ret:
  ret void
}

define dso_local { i32, double } @std_2fprelude_2ftext_2etoF64(ptr %v0, i64 %a0, i64 %a1, i1 %a2, i1 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca double
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca double
  %l15 = alloca i1
  %l30 = alloca i1
  %l44 = alloca i1
  %l53 = alloca i1
  %l61 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i32
  %l66 = alloca double
  %l69 = alloca double
  %l70 = alloca i32
  %l73 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i32
  %l79 = alloca double
  %l82 = alloca double
  %l83 = alloca i32
  %l88 = alloca double
  %l91 = alloca double
  %l92 = alloca i32
  %rv = alloca { i32, double }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i1 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !65
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i1, ptr %l3, !tbaa !21
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb6
bb3:
  store double 0x8000000000000000, ptr %l12, !tbaa !26
  br label %bb5
bb4:
  store double 0x0000000000000000, ptr %l12, !tbaa !26
  br label %bb5
bb5:
  %t7 = load double, ptr %l12, !tbaa !26
  %t8 = insertvalue { i32, double } zeroinitializer, double %t7, 1
  store { i32, double } %t8, ptr %rv
  br label %ret
bb6:
  %t9 = load i1, ptr %l2, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb7, label %bb8
bb7:
  %t13 = load i64, ptr %l0, !tbaa !65
  %t15 = lshr i64 %t13, 52
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l15, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  %t20 = load i64, ptr %l0, !tbaa !65
  %t22 = uitofp i64 %t20 to double
  store double %t22, ptr %l5, !tbaa !26
  %t24 = load i1, ptr %l3, !tbaa !21
  br i1 %t24, label %bb12, label %bb13
bb11:
  br label %bb39
bb12:
  %t26 = load double, ptr %l5, !tbaa !26
  %t29 = fneg double %t26
  store double %t29, ptr %l5, !tbaa !26
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t31 = load i64, ptr %l1, !tbaa !24
  %t33 = icmp eq i64 %t31, 0
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t35 = load double, ptr %l5, !tbaa !26
  %t37 = insertvalue { i32, double } zeroinitializer, double %t35, 1
  store { i32, double } %t37, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t38 = load i64, ptr %l1, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = icmp sle i64 %t42, 37
  store i1 %t44, ptr %l30, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb21, label %bb22
bb21:
  %t47 = load i64, ptr %l1, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp sgt i64 %t49, 22
  br i1 %t51, label %bb23, label %bb24
bb22:
  %t53 = load i64, ptr %l1, !tbaa !24
  %t55 = icmp slt i64 %t53, 0
  br i1 %t55, label %bb32, label %bb33
bb23:
  %t57 = load double, ptr %l5, !tbaa !26
  %t59 = load i64, ptr %l6, !tbaa !24
  %t61 = sub i64 %t59, 22
  %t63 = getelementptr [23 x double], ptr @G_2estd_2fprelude_2ftext_2eexactPow10, i64 0, i64 %t61
  %t64 = load double, ptr %t63, !tbaa !36
  %t67 = fmul double %t57, %t64
  store double %t67, ptr %l5, !tbaa !26
  store i64 22, ptr %l6, !tbaa !24
  br label %bb25
bb24:
  br label %bb25
bb25:
  %t69 = load double, ptr %l5, !tbaa !26
  %t71 = fcmp ole double %t69, 0x430c6bf526340000
  br i1 %t71, label %bb26, label %bb27
bb26:
  %t73 = load double, ptr %l5, !tbaa !26
  %t75 = fcmp oge double %t73, 0xc30c6bf526340000
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb28
bb28:
  %t77 = load i1, ptr %l44, !tbaa !21
  br i1 %t77, label %bb29, label %bb30
bb29:
  %t78 = load double, ptr %l5, !tbaa !26
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = getelementptr [23 x double], ptr @G_2estd_2fprelude_2ftext_2eexactPow10, i64 0, i64 %t79
  %t82 = load double, ptr %t81, !tbaa !36
  %t85 = fmul double %t78, %t82
  %t87 = insertvalue { i32, double } zeroinitializer, double %t85, 1
  store { i32, double } %t87, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  br label %bb38
bb32:
  %t88 = load i64, ptr %l1, !tbaa !24
  %t90 = icmp sge i64 %t88, -22
  store i1 %t90, ptr %l53, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb34
bb34:
  %t92 = load i1, ptr %l53, !tbaa !21
  br i1 %t92, label %bb35, label %bb36
bb35:
  %t93 = load double, ptr %l5, !tbaa !26
  %t94 = load i64, ptr %l1, !tbaa !24
  %t96 = sub i64 0, %t94
  %t98 = getelementptr [23 x double], ptr @G_2estd_2fprelude_2ftext_2eexactPow10, i64 0, i64 %t96
  %t99 = load double, ptr %t98, !tbaa !36
  %t102 = fdiv double %t93, %t99
  %t104 = insertvalue { i32, double } zeroinitializer, double %t102, 1
  store { i32, double } %t104, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t105 = load i64, ptr %l0, !tbaa !65
  %t106 = load i64, ptr %l1, !tbaa !24
  %t109 = call { i32, i64 } @std_2fprelude_2ftext_2eeiselLemire(i64 %t105, i64 %t106)
  %t110 = extractvalue { i32, i64 } %t109, 1
  %t111 = extractvalue { i32, i64 } %t109, 0
  store i32 %t111, ptr %l65
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb41, label %ok.113, !prof !99
ok.113:
  store i64 %t110, ptr %l64
  br label %bb40
bb40:
  %t114 = load i64, ptr %l64, !tbaa !65
  store i64 %t114, ptr %l61, !tbaa !65
  br label %bb46
bb41:
  br label %bb42
bb42:
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t116 = load i1, ptr %l3, !tbaa !21
  %t119 = call { i32, double } @std_2fprelude_2ftext_2eslowF64(ptr %v0, { i64, ptr } %t115, i1 %t116)
  %t120 = extractvalue { i32, double } %t119, 1
  %t121 = extractvalue { i32, double } %t119, 0
  store i32 %t121, ptr %l70
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb44, label %ok.123, !prof !99
ok.123:
  store double %t120, ptr %l69
  br label %bb43
bb43:
  %t124 = load double, ptr %l69, !tbaa !26
  store double %t124, ptr %l66, !tbaa !26
  br label %bb45
bb44:
  %t125 = load i32, ptr %l70, !tbaa !23
  %t126 = lshr i32 %t125, 16
  %t127 = and i32 %t125, 65535
  %t128 = icmp eq i32 %t126, 1
  %t129 = select i1 %t128, i32 1, i32 0
  %t130 = icmp eq i32 %t125, 0
  %t131 = shl i32 %t129, 16
  %t132 = or i32 %t131, %t127
  %t133 = select i1 %t130, i32 0, i32 %t132
  %t135 = insertvalue { i32, double } zeroinitializer, i32 %t133, 0
  store { i32, double } %t135, ptr %rv
  br label %ret
bb45:
  %t136 = load double, ptr %l66, !tbaa !26
  %t137 = insertvalue { i32, double } zeroinitializer, double %t136, 1
  store { i32, double } %t137, ptr %rv
  br label %ret
bb46:
  %t138 = load i64, ptr %l61, !tbaa !65
  store i64 %t138, ptr %l7, !tbaa !65
  %t139 = load i1, ptr %l2, !tbaa !21
  br i1 %t139, label %bb47, label %bb48
bb47:
  %t141 = load i64, ptr %l0, !tbaa !65
  %t143 = add i64 %t141, 1
  %t144 = load i64, ptr %l1, !tbaa !24
  %t147 = call { i32, i64 } @std_2fprelude_2ftext_2eeiselLemire(i64 %t143, i64 %t144)
  %t148 = extractvalue { i32, i64 } %t147, 1
  %t149 = extractvalue { i32, i64 } %t147, 0
  store i32 %t149, ptr %l78
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb50, label %ok.151, !prof !99
ok.151:
  store i64 %t148, ptr %l77
  br label %bb49
bb48:
  br label %bb62
bb49:
  %t152 = load i64, ptr %l77, !tbaa !65
  store i64 %t152, ptr %l73, !tbaa !65
  br label %bb55
bb50:
  br label %bb51
bb51:
  %t153 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t154 = load i1, ptr %l3, !tbaa !21
  %t157 = call { i32, double } @std_2fprelude_2ftext_2eslowF64(ptr %v0, { i64, ptr } %t153, i1 %t154)
  %t158 = extractvalue { i32, double } %t157, 1
  %t159 = extractvalue { i32, double } %t157, 0
  store i32 %t159, ptr %l83
  %t160 = icmp ne i32 %t159, 0
  br i1 %t160, label %bb53, label %ok.161, !prof !99
ok.161:
  store double %t158, ptr %l82
  br label %bb52
bb52:
  %t162 = load double, ptr %l82, !tbaa !26
  store double %t162, ptr %l79, !tbaa !26
  br label %bb54
bb53:
  %t163 = load i32, ptr %l83, !tbaa !23
  %t164 = lshr i32 %t163, 16
  %t165 = and i32 %t163, 65535
  %t166 = icmp eq i32 %t164, 1
  %t167 = select i1 %t166, i32 1, i32 0
  %t168 = icmp eq i32 %t163, 0
  %t169 = shl i32 %t167, 16
  %t170 = or i32 %t169, %t165
  %t171 = select i1 %t168, i32 0, i32 %t170
  %t173 = insertvalue { i32, double } zeroinitializer, i32 %t171, 0
  store { i32, double } %t173, ptr %rv
  br label %ret
bb54:
  %t174 = load double, ptr %l79, !tbaa !26
  %t175 = insertvalue { i32, double } zeroinitializer, double %t174, 1
  store { i32, double } %t175, ptr %rv
  br label %ret
bb55:
  %t176 = load i64, ptr %l73, !tbaa !65
  %t178 = load i64, ptr %l7, !tbaa !65
  %t181 = icmp ne i64 %t176, %t178
  br i1 %t181, label %bb56, label %bb57
bb56:
  %t183 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t184 = load i1, ptr %l3, !tbaa !21
  %t187 = call { i32, double } @std_2fprelude_2ftext_2eslowF64(ptr %v0, { i64, ptr } %t183, i1 %t184)
  %t188 = extractvalue { i32, double } %t187, 1
  %t189 = extractvalue { i32, double } %t187, 0
  store i32 %t189, ptr %l92
  %t190 = icmp ne i32 %t189, 0
  br i1 %t190, label %bb59, label %ok.191, !prof !99
ok.191:
  store double %t188, ptr %l91
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t192 = load double, ptr %l91, !tbaa !26
  store double %t192, ptr %l88, !tbaa !26
  br label %bb60
bb59:
  %t193 = load i32, ptr %l92, !tbaa !23
  %t194 = lshr i32 %t193, 16
  %t195 = and i32 %t193, 65535
  %t196 = icmp eq i32 %t194, 1
  %t197 = select i1 %t196, i32 1, i32 0
  %t198 = icmp eq i32 %t193, 0
  %t199 = shl i32 %t197, 16
  %t200 = or i32 %t199, %t195
  %t201 = select i1 %t198, i32 0, i32 %t200
  %t203 = insertvalue { i32, double } zeroinitializer, i32 %t201, 0
  store { i32, double } %t203, ptr %rv
  br label %ret
bb60:
  %t204 = load double, ptr %l88, !tbaa !26
  %t205 = insertvalue { i32, double } zeroinitializer, double %t204, 1
  store { i32, double } %t205, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t206 = load i1, ptr %l3, !tbaa !21
  br i1 %t206, label %bb63, label %bb64
bb63:
  %t208 = load i64, ptr %l7, !tbaa !65
  %t210 = shl i64 1, 63
  %t213 = or i64 %t208, %t210
  store i64 %t213, ptr %l7, !tbaa !65
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t215 = load i64, ptr %l7, !tbaa !65
  %t217 = bitcast i64 %t215 to double
  %t219 = insertvalue { i32, double } zeroinitializer, double %t217, 1
  store { i32, double } %t219, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local %"std/prelude/text:decimal" @std_2fprelude_2ftext_3adecimal_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l5 = alloca i64
  %l9 = alloca i64
  %rv = alloca %"std/prelude/text:decimal"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3adecimal_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = icmp sge i64 800, 0
  br i1 %t7, label %bb3, label %bb4
bb3:
  %t9 = mul i64 800, 1
  %t10 = load i64, ptr %l5
  %t11 = inttoptr i64 %t10 to ptr
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %t11, i64 %t9)
  %t13 = insertvalue { i64, ptr } undef, i64 800, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l0, !tbaa !27
  %t16 = call ptr @__olang_scope_hold(ptr %v0)
  %t17 = ptrtoint ptr %t16 to i64
  store i64 %t17, ptr %l9, !tbaa !24
  %t18 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3adecimal_2e1
  br i1 %t18, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_933a37c789dcabb3_fc2c50e2754a07ff)
  unreachable
bb5:
  %t20 = call ptr @__olang_region_make(ptr %v0)
  %t21 = ptrtoint ptr %t20 to i64
  store i64 %t21, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t22 = icmp sge i64 820, 0
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = mul i64 820, 1
  %t25 = load i64, ptr %l9
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_scope_alloc_zeroed(ptr %t26, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 820, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = insertvalue %"std/prelude/text:decimal" undef, { i64, ptr } %t31, 0
  %t34 = insertvalue %"std/prelude/text:decimal" %t32, { i64, ptr } %t29, 1
  %t36 = insertvalue %"std/prelude/text:decimal" %t34, i64 0, 2
  %t38 = insertvalue %"std/prelude/text:decimal" %t36, i64 0, 3
  %t40 = insertvalue %"std/prelude/text:decimal" %t38, i1 false, 4
  store %"std/prelude/text:decimal" %t40, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_322251a7a19e567e_616a29da982d62a)
  unreachable
ret:
  %rr = load %"std/prelude/text:decimal", ptr %rv
  ret %"std/prelude/text:decimal" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"inf" }>, align 8
@.d2 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"infinity" }>, align 8
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"nan" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd_2fprelude_2ftext_3adecimal_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2estd_2fprelude_2ftext_3adecimal_2e1 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@G_2estd_2fprelude_2ftext_2epow10Mant = available_externally constant <{ [11136 x i8] }> <{ [11136 x i8] c"\88\02\1C\08\A0\D5\8F\FA\53\E4\60\CD\69\C8\32\17\95\81\11\05\84\E5\99\9C\B4\8E\5C\20\42\BD\7F\0E\FA\E1\55\06\E5\5E\C0\C3\61\B2\73\A8\92\AC\1F\52\78\5A\EB\47\9E\76\B0\F4\F9\9E\90\52\B7\97\A7\E6\8B\18\F3\EC\22\4A\EE\98\5C\63\9A\93\D2\BE\28\90\AE\DE\2F\A8\AB\DC\29\BF\33\FC\80\38\87\EE\32\74\5A\D6\3B\92\D6\53\F4\EE\3F\3B\A1\06\29\AA\3F\11\F8\65\65\1B\66\B4\58\95\07\C5\24\A4\59\CA\C7\4A\76\BF\3E\A2\7F\E1\AE\BA\49\F6\2D\0D\F0\BC\79\5D\53\6F\CE\8A\DF\99\5A\E9\DC\73\79\10\2C\2C\D8\F4\94\05\C1\B6\2B\A0\D8\91\69\E8\4B\8A\9B\1B\07\79\F9\46\71\A4\36\C8\4E\B6\84\E2\DE\6C\82\E2\48\97\B7\98\8D\4D\44\7A\E2\E3\25\9B\16\08\23\1B\1B\FD\72\7F\78\B0\6A\8C\6D\8E\F7\20\0E\E5\F5\F0\30\FE\4F\9F\96\5C\85\EF\08\B2\35\A9\51\5E\33\2D\BD\BD\23\47\BC\B3\66\2B\8B\DE\82\13\E6\35\80\78\2C\AD\76\AC\55\30\20\FB\16\8B\31\CC\AF\21\50\CB\3B\4C\93\17\6B\3C\E8\B9\DC\AD\3D\BF\1B\2A\24\BE\4A\DF\78\DD\85\4B\62\E8\53\D9\0D\AF\A2\34\AD\6D\1D\D7\6B\AA\33\6F\3D\71\D4\87\68\AD\E5\40\8C\64\72\86\06\95\00\CB\8C\8D\C9\A9\C2\18\1F\51\AF\FD\0E\68\48\BA\C0\FD\EF\F0\3B\D4\F2\DE\66\25\1B\BD\12\02\6D\74\98\FE\95\76\A5\84\57\4B\60\F7\30\B6\4B\01\88\91\3E\7E\3B\D4\CE\A5\2D\5E\38\35\BD\A3\9E\41\EA\35\CE\5D\4A\89\42\CF\B9\75\86\82\AC\4C\06\52\B2\E1\A0\7A\CE\95\89\81\93\09\94\D1\EB\EF\43\73\1F\1A\49\19\42\FB\EB\A1\F8\0B\F9\C5\E6\EB\14\10\A6\60\9B\9F\12\FA\66\CA\F6\4E\77\77\E0\26\1A\D4\D0\38\82\47\97\B8\00\FD\B4\22\55\95\98\B0\20\89\82\63\B1\8C\5E\73\20\9E\B0\35\55\5D\5F\6E\B4\55\62\BC\DD\2F\36\90\A8\C5\1D\83\AA\34\F7\89\21\EB\7B\2B\D5\BB\43\B4\12\F7\E4\23\D5\01\75\EC\E9\A5\2D\3B\65\55\AA\B0\6B\9A\6E\36\25\21\C9\33\B2\47\F8\89\BE\EA\D4\9C\06\C1\0A\84\6E\69\BB\C0\9E\99\76\2C\6E\25\0A\44\48\F1\0D\25\CA\43\EA\70\06\C0\CA\DB\64\57\86\2A\CD\96\28\57\5E\6A\92\06\04\38\BC\12\3E\ED\27\75\80\BC\F2\EC\F5\04\37\08\05\C6\6B\97\8D\E8\71\92\A0\EB\2E\68\33\C6\44\4A\86\F7\A3\7E\58\31\87\5B\44\93\1D\21\E0\FB\6A\EE\B3\7A\4C\9E\AE\FD\68\72\15\B8\64\29\D8\BA\05\EA\60\59\DF\45\1A\3D\03\CF\1A\E6\BD\33\8E\29\87\24\B9\6F\AB\6B\30\06\62\C1\D0\8F\56\E0\F8\79\D4\B6\D3\A5\96\86\BC\87\BA\F1\C4\B3\6C\18\77\98\89\A4\48\8F\3C\A8\AB\29\29\2E\B6\E0\87\DE\94\FE\AB\CD\1A\33\25\49\0B\BA\D9\DC\71\8C\14\0B\1D\7F\8B\C0\F0\9F\6F\1B\8E\28\10\54\8E\AF\D9\4D\E4\5E\AE\F0\EC\07\4A\A2\B1\32\14\E9\71\DB\50\61\9D\F6\D9\2C\E8\C9\6E\05\AF\9F\AC\31\27\89\D2\5C\22\3A\08\1C\31\BE\CA\C6\9A\C7\17\FE\70\AB\06\F4\AA\48\0A\63\BD\6D\7D\78\81\B9\9D\3D\4D\D6\08\B1\D5\DA\CC\BB\2C\09\4E\EB\F0\93\82\46\F0\85\A5\8E\C5\08\60\F5\BB\25\21\26\ED\38\23\58\6C\A7\4E\F2\F6\0A\B8\F2\2A\AF\AA\6F\28\07\2C\6E\47\D1\E1\AE\B4\0D\66\AF\F5\1A\CA\45\79\84\DB\A4\CC\82\4D\ED\90\C8\9F\8D\D9\50\3C\97\97\65\12\CE\7F\A3\A0\28\B5\BA\07\F1\0F\E5\0C\7D\FD\FE\96\C1\5F\CC\C8\72\62\A9\49\ED\53\1E\4F\DC\BC\BE\FC\B1\77\FF\7A\0F\BB\13\9C\E8\E8\25\B1\09\36\F7\3D\CF\AA\9F\AC\E9\54\8C\61\91\B1\77\1D\8C\03\75\0D\83\95\C7\17\24\6A\EF\B9\F5\9D\D5\25\6F\44\D2\D0\E3\7A\F9\1D\AD\44\6B\28\73\05\4B\77\C5\6A\83\62\CE\EC\9B\32\EC\0A\43\F9\67\E3\4E\D5\76\45\24\FB\01\E8\C2\3F\A7\CD\93\F7\41\9C\22\8A\D4\56\ED\79\02\A2\F3\0F\11\C1\78\75\52\43\6B\D6\44\56\34\8C\41\45\98\A9\AA\78\6B\89\13\0A\83\0C\D6\6B\41\EF\91\56\BE\53\D5\56\C6\6B\98\CC\23\8F\CB\C6\11\6B\36\EC\ED\A8\8A\EC\B7\86\BE\BF\2C\39\3F\1C\EB\02\A2\B3\94\A9\D6\F3\32\14\D7\F7\7B\07\4F\E3\A5\83\8A\E0\B9\53\CC\B0\3F\D9\CC\F5\DA\C9\22\5C\8F\24\AD\58\E8\68\FF\9C\8F\0F\40\B3\D1\BE\95\99\D9\36\6C\37\91\A1\1F\C2\B9\09\08\10\23\2D\FB\FF\8F\44\47\85\B5\8A\A7\32\28\0C\0A\D4\AB\F9\F9\FF\B3\15\99\E6\E2\6C\51\3F\32\8F\0C\C9\16\3B\FC\7F\90\AD\1F\D0\8D\E3\92\67\7F\D9\A7\3D\AE\4A\FB\9F\F4\98\27\44\B1\9C\77\41\DF\CF\11\CD\99\1D\FA\C7\31\7F\31\95\DD\83\D5\11\D7\43\56\40\40\52\FC\1C\7F\EF\3E\7D\8A\72\25\6B\66\EA\35\28\48\66\3B\E4\5E\AB\8E\1C\AD\CF\EE\05\00\65\43\32\DA\40\4A\9D\36\56\B2\63\D8\82\6A\07\40\3E\D4\BE\90\68\4E\22\E2\75\4F\3E\87\91\A2\04\E8\A6\44\77\5A\02\E2\AA\5A\53\E3\0D\A9\36\CB\05\A2\D0\15\15\71\83\9A\55\31\28\5C\51\D3\03\3E\87\CA\44\5B\5A\0D\91\80\D5\1E\99\D9\12\84\C2\86\94\FE\0A\79\58\E8\B6\E0\8A\66\FF\8F\17\A5\72\A8\39\BE\4D\97\6E\62\E3\98\2D\40\FF\73\5D\CE\8F\12\C8\2D\21\3D\0A\FB\8E\7F\1C\88\7F\68\FA\80\99\0B\9D\BC\34\66\E6\7C\72\9F\23\6A\9F\02\39\A1\80\4E\C4\EB\C1\FF\1F\1C\4E\87\AC\44\47\43\87\C9\20\62\B5\66\B2\FF\27\A3\22\A9\D7\15\19\14\E9\FB\A8\BA\62\00\9F\FF\F1\4B\B5\C9\A6\AD\8F\AC\71\9D\A9\B4\3D\60\C3\3F\77\6F\22\7C\10\99\B3\17\CE\C4\D3\21\4D\38\B4\0F\55\CB\2B\9B\54\7F\A0\9D\01\F6\48\6A\60\46\A1\53\2A\7E\FB\E0\94\4F\84\02\C1\99\6D\42\FC\CB\44\74\DA\2E\39\19\7A\63\25\43\31\C0\08\53\FB\FE\55\11\91\FA\88\9F\58\BC\EE\93\3D\F0\CA\27\BA\7E\AB\55\35\79\B5\63\B7\35\75\7C\26\96\DE\58\34\2F\8B\55\C1\4B\A2\3C\25\83\92\1B\B0\BB\16\6F\01\FB\ED\AA\B1\9E\CB\8B\EE\23\77\22\9C\EA\DC\CA\C1\79\A9\15\5E\46\5F\17\75\76\8A\95\A1\92\C9\1E\19\EC\89\CD\FA\0B\36\5D\12\14\ED\FA\49\B7\7B\66\1F\67\EC\80\F9\CE\84\F4\16\59\A8\79\1C\E5\1A\40\E7\80\27\E1\B7\82\D2\58\AE\37\09\CC\31\8F\10\88\90\B0\B8\EC\B2\D1\07\EF\99\85\0B\3F\FE\B2\15\AA\B4\DC\E6\A7\1F\86\C9\6A\00\67\CE\CE\BD\DF\9A\D4\E1\93\E0\91\A7\67\BD\42\60\00\41\A1\D6\8B\E0\24\6D\5C\2C\BB\C8\E0\6D\53\78\40\91\49\CC\AE\18\6E\88\73\F7\E9\FA\58\48\68\96\90\F5\5B\7F\DA\9E\89\6A\50\75\A4\39\AF\2D\01\5E\7A\79\99\8F\88\03\96\42\52\C9\06\84\6D\78\81\F5\D8\D7\7F\B3\AA\83\3B\D3\A6\7B\08\E5\C8\D6\E1\32\CF\CD\5F\60\D5\64\0A\88\90\9A\4A\1E\FB\26\CD\7F\A1\E0\3B\5C\85\7F\06\55\9A\A0\EE\F2\5C\6F\C0\DF\C9\D8\4A\B3\A6\1E\48\EA\C0\48\AA\2F\F4\8B\B0\57\FC\8E\1D\60\D0\26\DA\24\F1\DA\94\3B\F1\57\CE\B6\5D\79\12\3C\82\58\08\B7\D6\08\3D\C5\76\ED\81\24\B5\17\17\CB\A2\6E\CA\64\0C\4B\8C\76\54\68\A2\6D\A2\DD\DC\7D\CB\09\FD\7D\CF\5D\2F\94\A9\02\0B\09\0B\15\54\5D\FE\4C\7C\5D\43\35\3B\F9\D3\E1\A6\E5\26\8D\54\FA\9E\AF\6D\1A\4A\01\C5\7B\C4\9A\10\9F\70\B0\E9\B8\C6\1B\09\A1\9C\41\B6\9A\35\C0\D4\C6\8C\1C\24\67\F8\62\4B\C9\03\D2\63\01\C3\F8\44\FC\D7\91\76\40\9B\1D\CF\5D\42\63\DE\E0\79\36\56\FB\4D\36\94\10\C2\E4\42\F5\12\FC\15\59\98\C4\2B\7A\E1\43\B9\94\F2\9D\93\B2\17\7B\5B\6F\3E\5A\5B\EC\6C\CA\F3\9C\97\42\9C\CF\EE\2C\99\05\A7\31\72\27\08\BD\30\84\BD\53\83\83\2A\78\FF\C6\50\BD\4E\31\4A\EC\3C\E5\EC\28\64\24\35\56\BF\F8\A4\36\D1\5E\AE\13\46\0F\94\99\BE\36\E1\95\77\1B\87\84\85\F6\99\98\17\13\B9\3F\6E\84\59\7B\55\E2\28\E5\26\74\C0\7E\DD\57\E7\CF\89\E5\2F\DA\EA\1A\33\4F\98\48\38\6F\EA\96\90\21\76\EF\5D\C8\D2\F0\3F\63\BE\5A\06\0B\A5\BC\B4\A9\53\6B\75\7A\07\ED\0F\FB\6D\F1\C7\4D\CE\EB\E1\94\28\C6\12\59\49\E8\D3\BD\E4\F6\9C\F0\60\33\8D\5C\D9\BB\AB\D7\2D\71\64\EC\9D\34\C4\2C\39\80\B0\B3\CF\AA\96\4D\79\8D\BD\67\C5\41\F5\77\47\A0\DC\A0\83\55\FC\A0\D7\F0\EC\60\1B\49\F9\AA\2C\E4\89\44\72\B5\9D\C4\86\16\F4\39\62\9B\B7\D5\37\5D\AC\D5\CE\22\C5\75\28\1C\31\C7\3A\82\25\CB\85\74\D7\8B\82\6B\36\93\32\63\7D\BC\64\71\F7\9E\D3\A8\86\97\31\03\02\9C\FF\5D\AE\EB\BD\4D\B5\86\08\53\A8\FC\FD\83\02\83\7F\F5\D9\66\2D\A1\62\A8\CA\67\D2\7B\FD\24\C3\63\DF\72\D0\60\BC\A4\3D\A9\DE\80\83\6D\1E\F7\59\9E\CB\47\42\78\EB\0D\8D\53\16\61\A4\08\E6\74\F0\85\BE\D9\52\56\66\51\70\E8\5B\79\CD\8B\1F\92\6C\27\2E\90\67\F6\DF\32\46\71\D9\6B\80\B6\53\DB\A3\D8\1C\BA\00\F3\97\BF\97\CD\CF\86\A0\A4\28\D2\CC\0E\A4\E8\80\F0\7D\AF\FD\C0\83\A8\C8\CD\B2\06\80\12\CD\22\61\6C\5D\1B\3D\B1\A4\D2\FA\81\5F\08\20\57\80\6B\79\63\1A\31\C6\EE\A6\C3\9C\B0\3B\05\74\36\30\E3\CB\FC\60\BD\77\AA\90\F4\C3\9C\8A\06\11\44\FC\DB\BE\3B\B9\AC\15\D5\B4\F1\F4\44\2D\48\15\55\FB\92\EE\C5\F3\8B\2D\05\11\17\99\4A\1C\4D\2D\15\DD\1B\75\B6\F0\EE\78\46\D5\5C\BF\5D\63\A0\78\5A\D4\62\D2\E4\AC\2A\17\98\0A\34\EF\34\7C\C8\16\71\89\FB\86\0E\AC\7A\0E\9F\86\80\95\A0\4D\3D\AE\E6\35\5D\D4\12\57\19\D2\46\A8\E0\BA\09\A1\CC\59\60\83\74\89\D7\AC\9F\86\58\D2\98\E9\4B\C9\3F\70\38\A4\D1\2B\06\CC\23\54\77\83\FF\91\CF\DD\27\46\A3\06\63\7B\08\BF\2C\29\55\64\7F\B6\42\D5\B1\17\4C\C8\3B\1A\CA\EE\77\73\6A\3D\1F\E4\93\4A\9E\1D\5F\BA\CA\20\3E\F5\2A\88\62\86\93\8E\9C\EE\82\72\7B\B4\7E\54\8D\B2\35\2A\FB\67\38\B2\43\AA\23\4F\9A\61\9E\E9\31\1F\C3\F4\F9\81\C6\DE\D4\94\EC\E2\00\FA\05\64\7E\F3\F9\38\3C\11\3C\8B\04\DD\D3\8D\40\BC\83\DE\5E\70\38\47\8B\15\0B\AE\45\D4\48\B1\50\AB\24\96\76\8C\06\19\EE\DA\8D\D9\57\09\9B\DD\24\D6\AD\3B\C9\17\A4\CF\D4\A8\F8\87\D6\E5\80\0A\D7\A5\4C\E5\BC\1D\8D\03\0A\D3\F6\A9\4C\1F\21\CD\4C\CF\9F\5E\2B\65\70\84\CC\87\74\D4\1F\67\69\00\20\C3\47\76\3B\3F\C6\D2\DF\D4\C8\84\73\E0\41\00\F4\D9\EC\29\09\CF\77\C7\17\0A\FB\A5\90\58\52\00\71\10\68\F4\CC\C2\55\B9\9D\CC\79\CF\B4\EE\66\40\8D\14\82\71\BF\99\D5\93\E2\1F\AC\81\30\55\40\48\D8\4C\F1\C6\2F\00\CB\38\DB\27\17\A2\7C\6A\50\5A\0E\A0\AD\B8\3B\C0\FD\06\D2\F1\9C\CA\1C\85\E4\F0\11\08\D9\A6\4A\30\BD\88\46\2E\44\FD\63\A6\1D\6D\16\4A\8F\90\2E\3E\76\15\EC\9C\4A\9E\FE\87\32\04\4E\8E\59\9A\BA\CD\D3\1A\27\44\DD\C5\FD\29\3F\85\E1\F1\EF\40\28\C1\88\E1\30\95\54\F7\7C\F4\8E\E6\59\EE\2B\D1\B9\78\F5\8C\3E\DD\94\9A\CE\58\19\30\F8\74\BB\82\E7\D6\32\30\8E\14\3A\C1\01\AF\1F\3C\36\52\6A\E3\A1\8C\3F\BC\B1\99\88\F1\C1\9A\27\CB\C3\E6\44\DC\E5\B7\A7\15\0F\60\F5\96\B9\C0\F8\5E\3A\10\AB\29\DE\A5\11\DB\12\B8\B2\BC\E7\F0\B6\F6\48\D4\15\74\56\0F\D6\91\17\66\DF\EB\21\AD\64\34\5B\49\1B\11\95\C9\25\BB\CE\9F\6B\93\34\EC\BE\00\D9\0D\B1\CA\FB\3B\EF\69\C2\87\46\B8\42\A7\EE\40\4F\51\5D\3D\FA\0A\6B\04\B3\29\58\E6\12\51\2A\11\A3\A5\B4\0C\DC\E6\C2\E2\0F\1A\F7\8F\AB\72\BA\EA\85\E7\F0\47\93\A0\73\DB\93\E0\F4\B3\56\0F\69\65\67\21\ED\59\B8\88\50\D2\B8\18\F2\E0\2C\53\C3\3E\C1\69\68\30\73\55\72\83\73\4F\97\8C\FB\13\3A\C7\18\42\41\1E\CF\EA\4E\64\50\23\BD\AF\FA\98\08\F9\9E\92\D1\E5\83\A5\62\7D\24\6C\AC\DB\39\BF\4A\B7\46\F7\45\DF\72\A7\5D\CE\96\C3\4B\89\83\B7\8E\32\8C\BA\8B\6B\4F\11\F5\81\7C\B4\9E\AB\64\65\32\3F\2F\A9\6E\06\A2\55\72\A2\9B\61\86\D6\BD\FE\FE\0E\7B\53\0A\C8\85\75\87\45\01\FD\13\86\36\5F\5F\E9\2C\74\06\BD\E7\52\E9\96\41\FC\98\A7\04\37\B7\23\38\11\48\2C\A0\A7\A3\FC\51\3B\7F\D1\C5\04\A5\2C\86\15\5A\F7\C4\48\E6\3D\13\85\EF\82\FB\22\E7\DB\73\4D\98\9A\F5\DA\5F\0D\58\66\AB\A3\BA\EB\E0\D2\D0\60\3E\C1\B3\D1\B7\10\EE\3F\96\CC\A8\26\99\07\05\F9\8D\31\1F\C6\E5\94\E9\CF\BB\FF\52\70\7F\49\46\77\F1\FD\D3\9B\0F\FD\F1\61\D5\9F\33\A6\EF\ED\8B\EA\B6\FE\C8\82\53\7C\6E\BA\CA\C7\C0\8F\6B\E9\2E\A5\64\FE\7B\63\68\1B\0A\69\BD\F9\B0\73\C6\A3\7A\CE\FD\3D\2D\3E\21\51\A6\61\16\9C\4E\08\5C\A6\0C\A1\BE\06\B8\8D\69\E5\0F\FA\1B\C3\62\0A\F3\CF\4F\49\6E\48\26\F1\C3\DE\93\F8\E2\F3\FA\CC\EF\C3\A3\DB\89\5A\B7\76\3A\6B\5C\DB\6D\98\1C\E0\75\5A\46\29\96\F8\65\14\09\86\33\52\89\BE\23\58\13\F1\97\B3\BB\F6\7F\59\8B\67\C0\A6\2B\EE\2C\2E\58\ED\7D\A0\6A\74\EF\17\B7\40\38\48\DB\94\DC\1C\57\B4\4E\A4\C2\A8\EB\DD\E4\50\46\1A\12\BA\13\E4\6C\61\62\4D\F3\92\66\15\1E\E5\D7\A0\96\E8\17\1D\C8\F9\BA\20\B0\77\60\CD\32\EF\86\24\5E\91\2E\12\1D\DC\74\14\CE\0A\B8\80\FF\AA\A8\AD\B5\B5\BA\56\24\13\92\99\81\0D\E6\60\BF\D5\12\19\23\E3\69\6C\ED\97\F6\FF\E1\10\8F\9C\97\C5\AB\EF\F5\8D\C1\63\F4\1E\FA\3F\8D\CA\B3\83\FD\B6\96\6B\73\B1\B2\7C\B1\A6\F8\8F\30\BD\A0\E4\BC\64\7C\46\D0\DD\DE\DB\5D\D0\F6\B3\7C\AC\E4\0E\F6\BE\0D\2C\A2\8A\6B\A9\3A\42\7A\F0\CD\6B\9D\92\B3\2E\11\B7\4A\AD\C6\53\C9\D2\98\6C\C1\86\44\77\60\7A\D5\64\9D\D8\B7\A8\7B\07\BF\C7\71\E8\8B\4A\7C\6C\05\5F\62\87\72\49\AD\64\D7\1C\47\11\2D\5D\9B\C7\C6\F6\3A\A9\CF\9B\D8\3D\0D\E4\98\D5\79\34\82\79\78\B4\89\D3\C3\C2\4E\8D\10\1D\FF\4A\CB\60\F1\4B\CB\10\36\84\BA\39\51\58\2A\72\DF\CE\FE\B8\ED\1E\FE\94\43\A5\28\88\65\EE\B4\4E\97\C2\3E\27\A9\A6\3D\7A\94\CE\32\EA\FE\29\62\22\3D\73\87\B8\29\88\66\CC\1C\81\5F\52\3F\5A\7D\35\06\08\A8\26\34\2A\80\FF\63\A1\F7\26\CF\B0\DC\C2\07\CA\52\30\C1\34\60\FF\BC\C9\B5\F0\02\DD\93\B3\89\FC\67\7C\F1\41\38\3F\2C\FC\E2\AC\43\D4\78\20\AC\BB\C0\ED\36\29\83\A7\9B\9D\0D\4C\AA\84\4B\94\4B\D5\31\A9\84\F3\63\91\02\C5\11\DF\D4\65\5E\79\9E\0A\7D\D3\65\F0\BC\35\43\F6\D5\16\4A\FF\B5\17\46\4D\2E\A4\3F\16\96\01\EA\99\45\4E\8E\BF\D1\CE\4B\50\39\8D\CF\9B\FB\81\64\C0\D6\E1\71\2F\86\C2\5E\E4\88\70\C3\82\7A\A2\7D\F0\4C\5A\4E\BB\27\73\76\5D\55\26\BA\91\8C\85\4E\96\6F\F8\10\D5\F8\07\6A\3A\EA\AF\28\B6\EF\26\E2\BB\8B\36\55\0A\F7\89\04\89\E5\DB\B2\A3\AB\B0\DA\EA\2E\84\EA\CC\74\AC\45\2B\6F\C9\4F\46\6B\AE\C8\92\9D\92\12\00\C9\8B\0B\3B\CB\BB\E3\17\06\DA\7A\B7\44\37\17\40\BB\6E\CE\09\BD\AA\DC\9D\87\90\59\E5\15\05\1D\10\6A\0A\42\CC\B6\EA\A9\C2\54\FA\57\8F\2D\23\12\4A\82\46\A9\9F\64\65\54\F3\E9\F8\2D\B3\F9\AB\96\DC\22\98\93\47\BD\7E\29\70\24\77\F9\DF\F7\56\BC\93\2B\7E\78\59\36\EF\19\C6\76\EA\FB\8B\5A\B6\55\3C\DB\4E\EB\57\03\6B\A0\77\14\E5\FA\AE\F1\23\6B\0B\92\22\E6\ED\C4\85\88\95\59\9E\B9\DA\ED\EC\45\8E\36\AB\5F\E9\9B\53\75\FD\F7\02\B4\88\14\B4\EB\18\02\CB\DB\11\81\A8\D2\FC\B5\03\E1\AA\19\A1\26\9F\C2\BD\52\D6\A2\52\07\7C\A3\44\99\D5\5F\49\F0\46\33\6D\E7\4B\A5\93\84\2D\E6\CA\7F\85\DB\2D\56\0C\40\A4\70\6F\8E\B8\E5\B8\9F\BD\DF\A6\52\B9\6B\0F\50\CD\4C\CB\B2\26\1F\A7\07\AD\97\D0\A7\A7\46\13\A4\00\20\7E\2F\78\73\C8\24\CC\5E\82\C8\28\0C\8C\66\00\D4\8E\3B\56\90\FA\2D\7F\F6\A2\FA\32\0F\2F\80\00\89\72\CA\6B\34\79\F9\1E\B4\CB\B9\FF\D2\3A\A0\40\2B\4F\BC\86\81\D7\B7\26\A1\FE\A8\BF\87\49\C8\10\F6\E2\36\F4\B0\E6\32\B8\24\9F\C9\D7\F4\2D\7D\CA\D9\0D\43\31\5D\A0\3F\E6\ED\C6\BB\0D\72\79\1C\3D\50\91\94\7D\74\88\CF\5F\A9\F8\2A\91\CE\97\63\4C\A4\75\7C\CE\48\B5\E1\DB\69\9B\BA\1A\E1\3E\BE\AF\86\C9\1B\02\9B\22\DA\52\44\C2\68\61\99\CE\AD\5B\E8\FB\A2\C2\41\AB\90\67\D5\F2\C3\B9\3F\42\99\72\E2\FA\A5\19\09\6B\BA\60\C5\97\1A\D4\67\C9\9F\87\CD\DC\0F\60\CB\05\E9\B8\B6\BD\20\C9\C1\BB\87\E9\00\54\13\38\3E\47\23\67\24\ED\68\3B\B2\AA\E9\23\01\29\0B\E3\86\0C\76\C0\36\94\21\65\AF\0A\72\B6\A0\F9\CE\9B\A8\8F\93\70\44\B9\69\3E\5B\8D\0E\E4\08\F8\C2\C2\92\73\B8\8C\95\E7\04\0E\B2\30\12\1D\0B\B6\B9\B9\3B\48\F3\77\BD\90\C2\48\6F\5E\2B\F2\C6\B1\28\A8\4A\1A\F0\D5\EC\B4\F3\1A\0B\36\B6\AE\38\1E\32\52\DD\20\6C\0B\28\E2\B0\E1\8D\C3\63\DA\C6\25\5F\53\8A\94\23\07\59\8D\0E\AD\38\5A\7E\48\9C\57\37\E8\AC\79\EC\48\AF\B0\51\D8\C6\F0\9D\5A\83\2D\44\22\18\98\27\1B\DB\DC\65\8E\F8\6C\45\31\E4\F8\6B\15\0F\BF\F8\F0\08\8A\FF\58\1B\64\CB\9E\8E\1B\C5\DA\D2\EE\36\2D\8B\AC\3F\2F\22\3D\7E\46\72\E2\77\91\87\AA\84\F8\AD\D7\0F\BB\6A\CC\1D\D8\0E\5B\EA\BA\94\EA\52\BB\CC\86\E9\B4\C2\9F\12\47\E9\98\A5\E9\39\A5\27\EA\7F\A8\24\62\B3\47\D7\98\23\3F\0E\64\88\8E\B1\E4\9F\D2\AD\3A\A0\19\0D\7F\EC\8E\89\3E\15\F9\EE\EE\A3\83\AC\24\04\30\68\CF\53\19\2B\8E\5A\B7\AA\EA\8C\A4\D7\2D\05\3C\42\C3\A8\5F\B6\31\31\65\55\25\B0\CD\4D\79\06\CB\12\F4\92\37\11\BF\3E\5F\55\17\8E\80\D0\0B\E4\BE\8B\D8\BB\E2\D6\6E\0E\B7\2A\9D\B1\A0\C4\0E\9D\AE\AE\CE\6A\5B\8B\0A\D2\64\75\04\DE\C8\75\52\44\5A\5A\82\45\F2\2E\8D\06\BE\92\85\15\FB\12\67\D5\F0\F0\E2\D6\EE\3D\18\C4\B6\7B\73\ED\9C\6B\60\85\96\D6\4D\46\55\4C\1E\75\A4\5A\D0\28\C4\86\B8\26\3C\4C\E1\97\AA\DF\65\92\4D\71\04\33\F5\A8\66\30\4B\9F\D9\3D\D5\AB\7F\7B\D0\C6\E2\3F\99\29\40\FE\8E\03\A8\46\E5\96\5F\9A\84\78\DB\8F\BF\33\D0\BD\72\04\52\98\DE\7C\F7\C0\A5\56\D2\73\EF\40\44\6D\8F\85\66\3E\96\AD\9A\98\27\76\63\A8\95\A8\4A\A4\79\13\00\E7\DD\59\C1\7E\B1\53\7C\12\BB\52\5D\0D\58\18\C0\60\55\AF\71\DE\9D\68\1B\D7\E9\A6\B4\10\6E\1E\F0\B8\AA\0D\07\AB\62\21\71\26\92\E8\70\CA\04\13\96\B3\CA\D1\C8\55\BB\69\0D\B0\B6\22\0D\FD\C5\97\7B\60\3D\05\3B\2B\2A\C4\10\5C\E4\6A\50\7C\B7\7D\9A\B8\8C\E3\04\5B\9A\7A\8A\B9\8E\42\B2\AD\92\8E\60\F3\77\1C\C6\F1\40\19\ED\67\B2\D3\1E\59\37\B2\38\F0\55\A3\37\2E\91\5F\E8\01\DF\88\66\2F\C5\DE\46\6C\6B\C6\E2\BC\BA\3B\31\61\8B\15\A0\3D\3B\4B\AC\23\23\77\1B\6C\A9\8A\7D\39\AE\1A\08\0D\0A\5E\97\EC\AB\55\22\C7\53\ED\DC\C7\D9\21\4A\90\8C\35\BD\E7\96\75\75\5C\54\14\EA\1C\88\54\2E\DA\77\41\D6\50\7E\D2\92\73\69\99\24\24\AA\E9\B9\D0\D5\D1\0B\E5\DD\87\77\D0\C3\BF\2D\AD\D4\64\E8\44\4B\C6\4E\5E\95\B4\4A\62\DA\97\3C\EC\84\3E\11\0B\EF\3B\F1\5A\BD\61\DD\FA\D0\BD\4B\27\A6\8E\D5\CD\EA\8A\AD\B1\EC\BA\94\39\45\AD\1E\B1\CF\F2\4A\81\A5\ED\18\DE\67\F4\FC\43\4B\2C\B3\CE\81\D7\CE\70\87\94\CF\EA\80\31\FC\14\5E\F7\5F\42\A2\8D\02\4D\A9\79\83\25\A1\3E\3B\9A\35\F5\F7\D2\CA\30\43\A0\13\58\E4\6E\09\0D\CA\00\83\F2\B5\87\FD\FC\53\88\18\6E\9D\CA\8B\48\7E\E0\91\B7\D1\74\9E\7D\34\55\CF\64\A2\5E\77\DA\9D\58\76\25\06\12\C6\9D\81\2A\03\FE\4A\36\95\51\C5\EE\D3\AE\87\96\F7\04\22\F5\83\BD\DD\83\3A\52\3B\75\44\CD\14\BE\9A\42\35\79\72\96\6A\92\C4\27\8A\92\95\00\9A\6D\C1\93\82\17\0F\3C\05\B7\75\B1\2C\F7\BA\80\00\C9\F1\38\63\DD\12\8B\C6\24\53\EE\7B\DA\74\50\A0\1D\97\03\5E\CA\EB\16\FC\F6\D3\EA\1A\11\92\64\08\E5\BC\84\F5\BC\A6\1C\BB\F4\88\A5\61\95\B6\7D\4A\1E\EC\E5\32\6C\D0\E3\E9\31\2B\07\5D\1D\92\8E\EE\92\93\CF\9F\43\62\2E\32\FF\3A\49\B4\A4\36\32\AA\77\B8\C2\87\D4\FA\B9\FE\BE\09\5B\E1\4D\C4\BE\94\95\E6\B3\A9\89\79\68\BE\2E\4C\D9\AC\B0\3A\F7\7C\1D\90\10\0A\F6\4B\01\37\9D\0F\0F\D8\5C\09\35\DC\24\B4\94\8C\F3\9E\C1\84\84\53\13\0E\B4\4B\42\13\2E\E1\B9\6F\B0\06\F2\A5\65\28\CB\88\50\6F\09\CC\BC\8C\D3\45\2E\44\B7\87\3F\F9\FE\AA\24\CB\0B\FF\EB\AF\48\D7\39\15\A5\69\8F\F7\BE\D5\ED\BD\CE\FE\E6\DB\1B\4D\88\5A\0E\44\73\B5\97\A5\B4\36\41\5F\70\89\30\30\95\F8\88\0A\68\31\FC\CE\61\84\11\77\CC\AB\3D\7C\BA\36\2B\0D\C2\FD\BC\42\7A\E5\D5\94\BF\D6\4C\1B\69\04\76\90\32\3D\B5\69\6C\AF\05\BD\37\86\0F\B1\C1\C2\49\9A\3F\A6\23\84\47\1B\47\AC\C5\A7\53\1D\72\33\DC\80\CF\0F\2B\65\19\E2\58\17\B7\D1\A8\A4\4E\40\13\61\C3\D3\3B\DF\4F\8D\97\6E\12\83\E9\26\31\08\AC\1C\5A\64\0A\D7\A3\70\3D\0A\D7\A3\A3\70\3D\0A\D7\A3\70\3D\CC\CC\CC\CC\CC\CC\CC\CC\CC\CC\CC\CC\CC\CC\CC\CC\00\00\00\00\00\00\00\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\A0\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\C8\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\FA\00\00\00\00\00\00\00\00\00\00\00\00\00\00\40\9C\00\00\00\00\00\00\00\00\00\00\00\00\00\00\50\C3\00\00\00\00\00\00\00\00\00\00\00\00\00\00\24\F4\00\00\00\00\00\00\00\00\00\00\00\00\00\80\96\98\00\00\00\00\00\00\00\00\00\00\00\00\00\20\BC\BE\00\00\00\00\00\00\00\00\00\00\00\00\00\28\6B\EE\00\00\00\00\00\00\00\00\00\00\00\00\00\F9\02\95\00\00\00\00\00\00\00\00\00\00\00\00\40\B7\43\BA\00\00\00\00\00\00\00\00\00\00\00\00\10\A5\D4\E8\00\00\00\00\00\00\00\00\00\00\00\00\2A\E7\84\91\00\00\00\00\00\00\00\00\00\00\00\80\F4\20\E6\B5\00\00\00\00\00\00\00\00\00\00\00\A0\31\A9\5F\E3\00\00\00\00\00\00\00\00\00\00\00\04\BF\C9\1B\8E\00\00\00\00\00\00\00\00\00\00\00\C5\2E\BC\A2\B1\00\00\00\00\00\00\00\00\00\00\40\76\3A\6B\0B\DE\00\00\00\00\00\00\00\00\00\00\E8\89\04\23\C7\8A\00\00\00\00\00\00\00\00\00\00\62\AC\C5\EB\78\AD\00\00\00\00\00\00\00\00\00\80\7A\17\B7\26\D7\D8\00\00\00\00\00\00\00\00\00\90\AC\6E\32\78\86\87\00\00\00\00\00\00\00\00\00\B4\57\0A\3F\16\68\A9\00\00\00\00\00\00\00\00\00\A1\ED\CC\CE\1B\C2\D3\00\00\00\00\00\00\00\00\A0\84\14\40\61\51\59\84\00\00\00\00\00\00\00\00\C8\A5\19\90\B9\A5\6F\A5\00\00\00\00\00\00\00\00\3A\0F\20\F4\27\8F\CB\CE\00\00\00\00\00\00\00\00\84\09\94\F8\78\39\3F\81\00\00\00\00\00\00\00\40\E5\0B\B9\36\D7\07\8F\A1\00\00\00\00\00\00\00\50\DE\4E\67\04\CD\C9\F2\C9\00\00\00\00\00\00\00\A4\96\22\81\45\40\7C\6F\FC\00\00\00\00\00\00\00\4D\9D\B5\70\2B\A8\AD\C5\9D\00\00\00\00\00\00\20\F0\05\E3\4C\36\12\19\37\C5\00\00\00\00\00\00\28\6C\C6\1B\E0\C3\56\DF\84\F6\00\00\00\00\00\00\32\C7\5C\11\6C\3A\96\0B\13\9A\00\00\00\00\00\40\7F\3C\B3\15\07\C9\7B\CE\97\C0\00\00\00\00\00\10\9F\4B\20\DB\48\BB\1A\C2\BD\F0\00\00\00\00\00\D4\86\1E\F4\88\0D\B5\50\99\76\96\00\00\00\00\80\44\14\13\31\EB\50\E2\A4\3F\14\BC\00\00\00\00\A0\55\D9\17\FD\25\E5\1A\8E\4F\19\EB\00\00\00\00\08\AB\CF\5D\BE\37\CF\D0\B8\D1\EF\92\00\00\00\00\E5\CA\A1\5A\AD\05\03\05\27\C6\AB\B7\00\00\00\40\9E\3D\4A\F1\19\C7\43\C6\B0\B7\96\E5\00\00\00\D0\05\CD\9C\6D\6F\5C\EA\7B\CE\32\7E\8F\00\00\00\A2\23\00\82\E4\8B\F3\E4\1A\82\BF\5D\B3\00\00\80\8A\2C\80\A2\DD\6E\30\9E\A1\62\2F\35\E0\00\00\20\AD\37\20\0B\D5\45\DE\02\A5\9D\3D\21\8C\00\00\34\CC\22\F4\26\45\D6\95\43\0E\05\8D\29\AF\00\00\41\7F\2B\B1\70\96\4C\7B\D4\51\46\F0\F3\DA\00\40\11\5F\76\DD\0C\3C\0F\CD\24\F3\2B\76\D8\88\00\C8\6A\FB\69\0A\88\A5\53\00\EE\EF\B6\93\0E\AB\00\7A\45\7A\04\0D\EA\8E\68\80\E9\AB\A4\38\D2\D5\80\D8\D6\98\45\90\A4\72\41\F0\71\EB\66\63\A3\85\50\47\86\7F\2B\DA\A6\47\51\6C\4E\A6\40\3C\0C\A7\24\D9\67\5F\B6\90\90\99\65\07\E2\CF\50\4B\CF\D0\6D\CF\41\F7\E3\B4\F4\FF\9F\44\ED\81\12\8F\81\82\A4\21\89\7A\0E\F1\F8\BF\C7\95\68\22\D7\F2\21\A3\0D\6A\2B\19\52\2D\F7\AF\39\BB\02\EB\8C\6F\EA\CB\90\44\76\9F\A6\F8\F4\9B\08\6A\C3\25\70\0B\E5\FE\B4\D5\53\47\D0\36\F2\02\45\22\9A\17\26\27\4F\9F\90\65\94\2C\42\62\D7\01\D6\AA\80\9D\EF\F0\22\C7\F5\7E\B9\B7\D2\3A\4D\42\8B\D5\E0\84\2B\AD\EB\F8\B2\DE\A7\65\87\89\E0\D2\77\85\0C\33\3B\4C\93\9B\2F\EB\88\9F\F4\55\CC\63\D5\A6\CF\FF\49\1F\78\C2\FB\25\6B\C7\71\6B\BF\3C\8A\90\C3\7F\1C\27\16\F3\7A\EF\45\39\4E\46\EF\8B\56\3A\DA\CF\71\D8\ED\97\AC\B5\CB\E3\F0\8B\75\97\EC\C8\D0\43\8E\4E\E9\BD\17\A3\BE\1C\ED\EE\52\3D\27\FB\C4\D4\31\A2\63\ED\DD\4B\EE\63\A8\AA\A7\4C\F8\1C\FB\24\5F\45\5E\94\6A\EF\74\3E\A9\CA\E8\8F\36\E4\39\EE\B6\D6\75\B9\44\2B\12\8E\53\FD\E2\B3\44\5D\C8\A9\64\4C\D3\E7\16\B6\96\71\A8\BC\DB\60\4A\3A\1D\EA\BE\0F\E4\90\CD\31\FE\46\E9\55\89\BC\DD\88\A4\A4\AE\13\1D\B5\41\BE\BD\98\63\AB\AB\6B\14\AB\CD\4D\9A\58\64\E2\D1\2D\ED\7E\3C\96\96\C6\EC\8A\A0\70\60\B7\7E\8D\A2\3C\54\CF\E5\1D\1E\FC\A8\AD\C8\8C\38\65\DE\B0\CB\4B\29\43\5F\A5\25\3B\12\D9\FA\AF\86\FE\15\DD\BE\9E\F3\13\B7\0E\EF\49\AB\C7\FC\2D\14\BF\2D\8A\37\43\78\6C\32\69\35\6E\96\F9\7B\39\D9\2E\B9\AC\04\54\96\07\7F\C3\C2\49\FB\F7\DA\87\8F\7A\E7\D7\06\E9\7B\C9\5E\74\33\DC\FD\DA\E8\B4\99\AC\F0\86\A3\71\ED\3D\BB\28\A0\69\BC\11\23\22\C0\D7\AC\A8\0C\CE\68\0D\EA\32\08\C4\2B\D6\AB\2A\B0\0D\D8\D2\90\01\C3\90\A4\3F\0A\F5\DB\65\AB\1A\8E\08\C7\83\FA\E0\79\DA\C6\67\26\79\52\3F\56\A1\B1\CA\B8\A4\38\59\18\91\B8\01\70\57\26\CF\AB\09\5E\FD\E6\CD\86\6F\5E\B5\26\02\4C\ED\78\61\0B\C6\5A\5E\B0\80\B4\05\5B\31\58\81\4F\54\D6\39\8E\77\F1\75\DC\A0\21\C7\B1\3D\AE\61\63\69\4C\C8\71\D5\6D\93\13\C9\E9\38\1E\CD\19\3A\BC\03\5F\3A\CE\4A\49\78\58\FB\23\C7\65\40\A0\48\AB\04\7B\E4\C0\CE\2D\4B\17\9D\76\9C\3F\28\64\0D\EB\62\9A\1D\71\42\F9\1D\5D\C4\94\83\4F\32\BD\D0\A5\3B\00\65\0D\93\77\65\74\F5\79\64\E3\7E\EC\44\8F\CA\20\5F\E8\BB\6A\BF\68\99\CB\1E\4E\CF\13\8B\99\7E\E8\76\E2\6A\45\EF\C2\BF\7E\A6\21\C3\D8\ED\3F\9E\A2\14\9B\C5\16\AB\B3\EF\1E\10\EA\F3\4E\E9\CF\C5\E5\EC\80\3B\EE\4A\D0\95\12\4A\72\58\D1\F1\A1\BB\1F\28\61\CA\A9\5D\44\BB\97\DC\8E\AE\45\6E\8A\2A\26\72\F9\3C\14\75\15\EA\BD\93\32\1A\D7\09\2D\F5\58\E7\1B\A6\2C\69\4D\92\56\9C\5F\70\26\26\3C\59\2E\E1\A2\CF\77\C3\E0\B6\6C\83\77\0C\B0\2F\8B\6F\7A\99\8B\C3\55\F4\98\E4\47\64\95\0F\9C\FB\6D\0B\EC\3F\37\9A\B5\98\DF\8E\AC\5E\BD\89\41\BD\24\47\E7\0F\C5\00\E3\7E\97\B2\57\B6\2C\EC\91\EC\ED\58\E1\53\F6\C0\9B\5E\3D\DF\ED\E3\37\67\B6\67\29\2F\6C\F4\99\58\21\5B\86\8B\74\EE\82\00\D2\E0\79\BD\87\71\C0\AE\E9\F1\67\AE\11\AA\A3\80\06\59\D8\EC\E9\8D\70\1A\64\EE\01\DA\95\94\CC\20\48\6F\0E\E8\B2\58\86\90\FE\34\41\88\DD\DC\7F\14\8D\05\09\31\DE\EE\A7\34\3E\82\51\AA\15\D4\9F\59\F0\46\4B\BD\96\EA\D1\C1\CD\E2\E5\D4\1A\C9\07\70\AC\18\9E\6C\9E\32\23\99\C0\AD\0F\85\B0\DD\04\C6\6B\CF\E2\03\45\FF\6B\BF\30\99\53\A6\1C\15\86\B7\46\83\DB\84\16\FF\46\EF\7C\7F\E8\CF\63\9A\67\65\18\64\12\E6\6E\5F\8C\15\AE\4F\F1\81\7E\C0\60\3F\8F\7E\CB\4F\49\77\EF\9A\99\A3\6D\A2\9D\F0\38\0F\33\5E\BE\E3\1C\55\AB\01\80\0C\09\CB\C5\2C\07\D3\BF\F5\AD\5C\63\2A\16\02\A0\4F\CB\FD\F6\F7\C8\C7\2F\73\D9\73\7E\DA\4D\01\C4\11\9F\9E\FA\9A\DD\DC\FD\E7\67\28\1D\51\A1\01\35\D6\46\C6\B8\01\15\54\FD\E1\81\B2\65\A5\09\42\C2\8B\D8\F7\26\42\1A\A9\7C\5A\22\1F\5F\07\46\69\59\57\E7\9A\58\69\B0\E9\8D\78\75\33\37\89\97\C3\2F\2D\A1\C1\AE\83\1C\64\B1\D6\52\00\84\6B\7D\B4\7B\78\09\F2\9A\A4\23\BD\5D\8C\67\C0\32\63\CE\50\4D\EB\45\97\E0\46\36\96\BA\B7\40\F8\FF\FB\01\A5\20\66\17\BD\98\D8\C3\3B\A9\E5\50\B6\FF\7A\42\CE\A8\3F\5D\EC\BE\CE\B4\8A\13\1F\E5\A3\DF\8C\E9\80\C9\47\BA\93\37\01\B1\36\6C\33\6F\C6\17\F0\23\E1\BB\D9\A8\B8\84\41\5D\44\47\00\0B\B8\1D\EC\6C\D9\2A\10\D3\E6\E5\91\74\15\59\C0\0D\A6\92\13\E4\C7\1A\EA\43\90\2F\DB\68\AD\37\98\C8\87\77\18\DD\79\A1\E4\54\B4\FB\11\C3\98\45\BE\BA\29\94\5E\54\D8\C9\1D\6A\E1\7A\D6\F3\FE\D6\6D\29\F4\1D\BB\34\27\9E\52\E2\8C\0C\66\58\5F\A6\E4\99\18\E4\E9\01\B1\45\E7\1A\B0\8F\7F\2E\F7\CF\5D\C0\5E\5D\64\42\1D\17\A1\21\DC\73\1F\FA\F4\43\75\70\76\BA\7E\49\72\AE\04\95\89\A8\53\1C\79\4A\49\06\6A\69\DE\DB\0E\DA\45\FA\AB\92\68\63\17\9D\DB\87\04\03\D6\92\92\50\D7\F8\D6\B6\42\3C\5D\84\D2\A9\45\C2\C5\9B\5B\92\86\5B\86\B2\A9\45\BA\92\23\8A\0B\32\B7\82\F2\36\68\F2\A7\1E\14\D7\68\77\AC\6C\8E\FF\64\23\AF\44\02\EF\D1\26\D9\0C\43\95\D7\07\32\1F\1F\76\ED\6A\61\35\83\B8\07\E8\49\BD\E6\44\7F\E7\A6\D3\A8\C5\B9\02\A4\A6\09\62\9C\6C\20\16\5F\A1\90\08\13\37\68\03\CD\0F\8C\7A\C3\87\A8\DB\36\64\5A\E5\6B\22\21\22\80\89\97\2C\DA\54\49\49\C2\FD\B0\DE\06\6B\A9\2A\A0\6C\BD\B7\10\AA\9B\DB\F2\3D\5D\96\C8\C5\53\35\C8\C7\AC\E5\94\94\82\92\6F\8C\F4\BB\3A\B7\A8\42\FA\F9\17\1F\BA\39\23\77\CB\D7\78\B5\84\72\A9\69\9C\FB\6E\53\14\04\76\2A\FF\0D\D7\E2\25\CF\13\84\C3\BA\4A\68\19\85\13\F5\FE\D1\8C\5B\EF\C2\18\65\F4\69\5D\C2\5F\66\58\B2\7E\02\38\99\D5\79\2F\BF\98\61\7A\D9\FB\3F\77\2F\EF\03\86\FF\4A\58\FB\EE\BE\FA\D8\CF\FA\0F\55\FB\AA\84\67\BF\5D\2E\BA\AA\EE\38\CF\83\F9\53\2A\BA\95\B2\A0\97\FA\5C\B4\2A\95\83\61\F2\7B\74\5A\94\DD\DF\88\3D\39\74\61\75\BA\E4\F9\EE\9A\11\71\F9\94\17\EB\8C\47\D1\B9\12\E9\5D\B8\AA\01\56\CD\37\7A\EE\12\B8\CC\22\B4\AB\91\3A\B3\0A\C1\55\E0\62\AC\AA\17\E6\7F\2B\A1\16\B6\09\60\4D\31\6B\98\7B\57\94\9D\DF\5F\76\49\9C\E3\0B\B8\A0\FD\85\7E\5A\ED\7D\C2\EB\FB\E9\AD\41\8E\07\73\84\BE\13\8F\58\14\1C\B3\E6\7A\64\19\D2\B1\C8\8F\25\AE\D8\B2\6E\59\E3\5F\A0\99\BD\9F\46\DE\BB\F3\AE\D9\8E\5F\CA\6F\EE\3B\04\80\D6\23\EC\8A\54\58\0D\48\B9\7B\DE\25\E9\4A\05\20\CC\2C\A7\AD\6A\AE\10\9A\A7\1A\56\AF\A4\9D\06\28\FF\F7\10\D9\04\DA\94\80\51\A1\2B\1B\86\22\04\79\FF\9A\AA\87\42\08\5D\F0\D2\44\FB\90\28\2B\45\57\BF\41\95\A9\53\4A\74\AC\07\16\3A\35\F2\75\16\2D\2F\92\FA\D3\E8\5C\91\97\89\9B\88\42\B7\09\2E\7C\5D\9B\7C\84\11\DA\BA\FE\35\61\95\69\25\8C\39\DB\34\C2\9B\A5\95\90\69\7E\83\B9\FA\43\2E\EF\07\12\C2\B2\02\CF\BB\F4\03\5E\E4\67\F9\94\7D\F5\44\4B\B9\AF\61\81\F5\78\C2\BA\EE\E0\1B\1D\DC\32\16\9E\A7\1B\BA\A1\32\17\73\69\2A\D9\62\64\93\BF\9B\85\91\A2\28\CA\FE\DC\CF\03\75\8F\7B\7D\78\AF\02\E7\35\CB\B2\FC\3E\D4\C3\44\52\73\DA\5C\AB\AD\61\B0\01\BF\EF\9D\A7\64\FA\6A\13\88\08\3A\16\19\7A\1C\C2\AE\6B\C5\D0\FD\B8\45\18\AA\8A\08\5B\9F\98\A3\72\9A\C6\F6\45\3D\27\57\9E\54\AD\8A\99\63\3F\A6\87\20\3C\9A\4B\86\78\F6\E2\54\AC\36\7F\3C\CF\8F\A9\28\CB\C0\DD\A7\16\B4\1B\6A\57\84\9F\0B\C3\F3\D3\F2\FD\F0\D5\51\1C\A1\A2\44\6D\65\43\E7\59\78\C4\B7\9E\96\25\B3\B1\A4\E5\4A\64\9F\14\61\70\96\B5\65\46\BC\EE\1F\DE\0D\9F\5D\3D\87\59\79\0C\FC\22\FF\57\EB\EA\A7\55\D1\06\B5\0C\A9\D8\CB\87\DD\75\FF\16\93\F2\88\D5\42\24\F1\A7\09\CE\BE\E9\54\53\BF\DC\B7\2F\EB\8A\53\6D\ED\11\0C\81\2E\24\2A\28\EF\D3\E5\FA\A5\6D\A8\C8\68\16\8F\10\9D\56\1A\79\75\A4\8F\BC\87\44\69\7D\01\6E\F9\55\44\EC\60\D7\92\8D\B3\AC\A9\95\C3\DC\81\C9\37\6A\55\27\39\8D\F7\70\E0\17\14\7B\F4\53\E2\BB\85\62\95\B8\43\B8\9A\46\8C\8E\EC\CC\78\74\6D\95\93\BB\BA\A6\54\66\41\58\AF\B2\27\00\97\D1\C8\7A\38\6A\69\D0\E9\BF\51\2E\DB\9E\31\C0\FC\05\7B\99\06\E2\41\22\F2\17\F3\FC\88\03\1F\F8\BD\E3\EC\1F\44\5A\D2\AA\EE\DD\2F\3C\AB\C3\26\76\AD\1C\E8\27\D5\F1\86\55\6A\D5\3B\0B\D6\74\B0\D3\D8\23\E2\71\8A\56\74\75\62\65\05\C7\85\49\4E\84\67\56\2D\87\F6\6C\D1\12\BB\BE\C6\38\A7\DB\61\65\01\AC\F8\28\B4\C7\85\D7\69\6E\F8\06\D1\52\BA\BE\01\D7\36\33\E1\9C\B3\26\02\45\5B\A4\82\73\34\17\61\46\02\C0\EC\84\60\B0\42\16\72\4D\A3\90\01\5D\F9\D7\02\F0\27\A5\78\5C\D3\9B\CE\20\CC\F4\41\B4\F7\8D\03\EC\31\CE\96\33\C8\42\02\29\FF\71\52\A1\75\71\04\67\7E\41\3E\20\BD\69\A1\79\9F\86\D3\84\E9\C6\62\00\0F\D1\4D\68\2C\C4\09\58\C7\68\08\E6\A3\78\7B\C0\52\45\61\82\37\35\0C\2E\F9\82\8A\DF\CC\56\9A\70\A7\CB\7C\B1\42\A1\C7\BC\9B\91\B6\0B\40\76\60\A6\88\FE\DB\5D\93\89\F9\AB\C2\35\A4\0E\D0\93\F8\CF\6A\FE\52\35\F8\EB\F7\56\F3\43\4D\12\C4\B8\F6\83\05\DE\53\21\7B\F3\5A\16\98\4A\70\8B\7A\33\7A\72\C3\D6\A8\E9\59\B0\F1\1B\BE\5C\4C\2E\59\C0\18\4F\74\0C\13\64\70\1C\EE\A2\ED\73\DF\79\6F\F0\DE\62\11\E7\8B\3E\C6\D1\D4\85\94\A8\2B\AC\45\56\CB\DD\8A\E1\2E\CE\37\06\4A\A7\B9\92\36\17\D7\2B\3E\95\6D\99\BA\C1\C5\87\1C\11\E8\37\04\DD\CC\B6\8D\FA\C8\A0\14\99\DB\D4\B1\0A\91\A2\22\0A\40\92\98\9C\1D\C8\59\7F\12\4A\5E\4D\B5\4B\AB\0C\D0\B6\BE\03\25\3A\30\1F\97\DC\B5\A0\E2\1D\D6\0F\84\64\AE\44\2E\24\7E\73\DE\A9\71\A4\8D\D2\E5\89\D2\FE\EC\EA\5C\AD\5D\10\56\14\8E\0D\B1\47\5F\2C\87\3E\A8\25\74\18\75\94\6B\99\F1\50\DD\19\77\F7\28\4E\12\2F\D1\2F\C9\3C\E3\FF\96\52\8A\6F\AA\9A\D9\70\6B\BD\82\7B\FB\0B\DC\BF\3C\E7\AC\0B\55\01\10\4D\C6\6C\63\5A\FA\0E\D3\EF\0B\21\D8\4E\AA\01\54\E0\F7\47\3C\78\5C\E9\E3\75\A7\14\87\71\0A\81\34\EC\FA\AC\65\96\B3\E3\5C\53\D1\D9\A8\0D\4D\A1\41\A7\39\18\7F\7C\A0\1C\34\A8\45\10\D3\50\A0\09\12\11\48\DE\1E\4D\E4\91\20\89\2B\EA\83\32\04\46\AB\0A\ED\4A\93\60\5D\B6\68\6B\B6\E4\A4\3F\85\17\56\4D\A8\1D\F8\B9\F4\E3\42\06\E4\1D\CE\8E\66\9D\AB\60\12\25\36\F3\78\CE\E9\83\AE\D2\80\19\60\42\6B\7C\2B\D7\C1\30\17\42\E4\24\5A\07\A1\1F\F8\12\86\5B\F6\4C\B2\FC\9C\52\1D\AE\30\49\C9\27\B6\97\67\F2\33\E0\DE\3C\44\A7\A4\D9\7C\9B\FB\B1\A3\7D\01\EF\40\98\16\A5\8A\E8\06\08\2E\41\9D\4E\86\EE\60\95\28\1F\8E\4E\AD\A2\08\8A\79\91\C4\E2\27\2A\B9\BA\F2\A6\F1\A2\58\CB\8A\EC\D7\B5\F5\DB\B1\74\67\69\AF\10\AE\65\17\BF\D6\F3\A6\91\99\29\EF\A8\E0\A1\6D\CA\AC\3F\DD\6E\CC\B0\10\F6\BF\F3\2A\D3\58\0A\09\FD\17\8E\94\8A\FF\DC\94\F3\EF\B0\F5\07\EF\4C\4B\FC\DD\D9\9C\B6\1F\0A\3D\F8\95\8E\F9\64\15\10\AF\BD\4A\0F\44\A4\A7\4C\4C\76\BB\F1\37\BE\1A\D4\1A\6D\9D\13\55\8D\D1\5F\DF\53\EA\ED\C5\6D\21\89\61\C8\84\2C\55\F8\E2\9B\6B\74\92\B4\9B\E4\B4\F5\3C\FD\32\77\6A\B6\DB\82\86\11\B7\A1\C2\1D\22\33\8C\BC\3F\15\05\A4\92\23\E8\D5\E4\4A\33\A5\EA\3F\AF\AB\0F\2D\83\A6\3B\16\B1\05\8F\0E\40\A7\F2\87\4D\CB\29\F8\23\90\CA\5B\1D\C7\B2\12\10\51\EF\E9\20\3E\74\F6\2C\34\BD\B2\E4\78\DF\16\54\25\6B\24\A9\4D\91\1A\9C\40\B6\EF\8E\AB\8B\8E\54\F7\C2\B6\89\D0\1A\20\C3\D0\A3\AB\72\96\AE\B1\29\B5\73\24\AC\84\A1\E8\F3\C4\8C\56\0F\3C\DA\1E\74\A2\90\2D\D7\E5\C9\71\18\FB\17\96\89\65\88\92\88\65\7A\7C\A6\2F\7E\8D\DE\F9\9D\FB\EB\7E\AA\B7\EA\FE\98\1B\90\BB\DD\31\56\78\85\FA\A6\1E\D5\65\A5\3E\7F\22\74\2A\55\DE\35\6B\93\5C\28\33\85\5F\27\87\8F\95\88\3A\D5\56\03\46\B8\73\F2\7F\A6\37\F1\68\F3\BA\2A\89\8A\2C\84\57\A6\10\EF\1F\D0\85\2D\43\B0\69\75\2B\2D\9B\B2\F6\67\6A\F5\13\82\73\FC\29\0E\62\29\3B\9C\42\5F\F4\01\C5\F2\98\A2\8F\7B\B4\91\BA\F3\49\83\13\77\71\42\76\2F\3F\CB\73\9A\21\36\A9\70\1C\24\D7\D4\0D\D3\53\FB\0E\FE\10\01\AA\83\D3\8C\23\ED\06\A5\E8\63\14\5D\C9\9E\AA\40\4A\32\04\38\36\F4\48\CE\E2\7C\59\B4\7B\C6\D5\D0\DC\3E\05\C6\43\B1\DA\81\1B\DC\6F\A1\1A\F8\0A\05\94\8E\86\B7\94\DD\28\31\91\E9\E5\A4\10\9B\26\83\1C\19\B4\F2\7C\CA\72\7D\F5\63\1F\CE\D4\C1\F0\A3\63\1F\61\2F\1C\FD\CF\DC\F2\3C\A7\01\4A\F2\EC\8C\3C\67\39\3B\63\BC\01\CA\17\86\08\41\6E\97\13\D8\85\E0\03\05\BE\D5\82\BC\9D\A7\4A\D1\49\BD\18\4E\A7\D8\44\86\2D\4B\A2\2B\85\51\9D\45\9C\EC\9E\21\D1\0E\D6\E7\F8\DD\45\3B\F3\52\82\AB\E1\93\03\B5\42\C9\E5\90\BB\CA\17\0A\B0\E7\62\16\DA\B8\43\62\93\3B\1F\75\6A\3D\9D\0C\9C\A1\FB\9B\10\E7\D4\3A\78\0A\67\12\C5\0C\E2\87\01\45\7D\61\6A\90\C5\24\8B\66\80\2B\FB\27\DA\E9\41\96\DC\F9\84\B4\F6\ED\2D\80\60\F6\F9\B1\51\64\D2\BB\53\38\A6\E1\73\69\39\A0\F8\73\78\5E\B2\7E\63\55\34\E3\07\8D\E8\E1\23\64\7B\48\0B\DB\5F\5E\BC\6A\01\DC\49\B0\62\DA\2C\3D\9A\1A\CE\91\F7\75\6B\C5\01\53\5C\DC\FB\10\78\CC\40\A1\41\76\BA\29\63\1B\E1\B3\B9\89\9D\0A\CB\7F\C8\04\E9\A9\29\F4\3B\62\D9\20\28\AC\44\CD\BD\9F\FA\45\63\54\33\F1\CA\BA\0F\29\32\D7\95\40\AD\47\79\17\7C\A9\C0\D6\BE\D4\A9\59\7F\86\5D\48\CC\CC\AB\8E\ED\49\70\8C\EE\49\14\30\1F\A8\74\5A\FF\BF\56\F2\68\5C\8C\2F\6A\5C\19\FC\26\D2\11\31\FF\6F\EC\2E\83\73\B7\5D\C2\D9\8F\5D\58\83\AB\7E\FF\C5\53\FD\31\C8\25\F5\32\D0\F3\74\2E\A4\55\5E\7F\B7\A8\7C\3E\BA\6F\B2\3F\C4\30\12\3A\CD\EB\35\5F\E5\D2\1B\CE\28\85\CF\A7\7A\5E\4B\44\80\B3\81\5B\CF\63\D1\80\79\66\C3\51\19\36\5E\55\A0\1F\62\32\C3\BC\05\E1\D7\40\34\A6\9F\C3\B5\6A\C8\A7\FA\FE\F3\2B\47\D9\8D\50\C1\8F\87\34\63\85\FA\51\B9\FE\F0\F6\98\4F\B1\D2\D8\B9\D4\00\5E\93\9C\D3\33\9F\56\9A\BF\D1\6E\07\4F\E8\09\81\35\B8\C3\C8\00\47\EC\80\2F\86\0A\C8\62\62\4C\E1\42\A6\F4\FA\C0\58\27\61\BB\27\CD\BD\7D\BD\CF\CC\E9\E7\98\9C\78\97\B8\1C\D5\38\80\2C\DD\AC\03\40\E4\21\BF\C3\56\BD\E6\63\0A\47\E0\78\14\98\04\50\5D\EA\EE\74\AC\6C\E0\FC\CC\58\18\CB\0C\DF\02\52\7A\52\95\C8\EB\43\0C\1E\80\37\0F\FD\CF\96\83\E6\18\A7\BA\BA\E6\54\8F\25\60\05\D3\FD\83\7C\24\20\DF\50\E9\69\20\2A\F3\2E\B8\C6\47\7E\D2\CD\16\74\8B\D2\91\41\54\FA\57\1D\33\DC\4C\1D\47\81\1C\51\2E\47\B6\52\E9\F8\AD\E4\3F\13\E0\E5\98\A1\63\E5\F9\D8\E3\A6\23\77\D9\DD\0F\18\58\8F\FF\44\5E\2F\9C\67\8E\48\76\EA\A7\EA\09\0F\57\73\3F\D6\35\3B\83\01\B2\DA\13\E5\51\65\CC\D2\2C\4F\CF\4B\03\0A\E4\81\DE\D1\58\5E\A6\7E\7F\07\F8\91\61\0F\42\86\2E\11\8B\82\F7\FA\27\AF\AF\04\FB\F6\39\93\D2\27\7A\D5\AD\63\B5\F9\F1\9A\DB\C5\79\74\08\38\C7\B1\D8\4A\D9\BC\22\78\AE\81\52\37\18\48\05\83\1C\6F\C7\CE\87\B5\15\0B\0D\91\93\22\8F\9A\C6\A3\E3\4A\79\C2\A9\22\DB\4D\50\75\38\EB\B2\41\B8\8C\9C\9D\17\33\D4\EB\51\61\A4\92\06\A6\5F\28\F3\D7\81\C2\EE\9F\84\33\D3\BC\A6\1B\C4\C7\DB\F3\EF\4D\22\73\EA\C7\A5\00\08\6C\90\22\B5\B9\12\EF\6B\E1\EA\0F\E5\39\CF\00\0A\87\34\6B\22\68\D7\75\E3\CC\F2\29\2F\84\81\40\66\D4\00\83\15\A1\E6\53\1C\80\6F\F4\3A\E5\A1\D0\7F\09\C1\E3\5A\49\60\68\23\60\8B\B1\89\5E\CA\C4\DF\4B\B1\9C\B1\5B\38\42\2C\38\EE\1D\2C\F6\FC\B5\D7\9E\DD\03\9E\72\46\A9\1B\E3\B4\92\DB\19\9E\D1\46\83\6A\C2\A2\07\6C\93\E2\1B\62\77\52\A0\C5\85\18\24\05\73\8B\09\C7\38\DB\A2\3A\15\67\08\F7\A7\1E\6D\C6\4F\EE\CB\B8\03\C9\A5\44\6D\40\65\9A\28\33\04\DC\F1\74\7F\73\44\3B\CF\95\88\90\FE\C0\F2\3F\05\53\2E\52\5F\50\15\0A\43\BB\AA\34\3E\F1\EF\8F\C6\E7\B9\26\77\64\4D\E6\09\B5\EA\E0\C6\96\F5\19\DC\30\34\78\CA\5E\E0\5F\4C\62\25\99\78\BC\72\20\13\3D\41\16\7D\B6\D8\77\DF\BA\6E\BF\96\EB\8F\E8\57\8C\D1\5B\1C\E4\E7\AA\CB\34\A5\37\3E\93\59\F1\B6\F7\62\B9\91\8E\A1\95\FE\81\8E\C5\0D\B8\B0\AD\A4\B5\BB\27\36\72\09\3B\7E\22\F2\36\11\E6\1C\D9\0D\A3\AA\B1\C3\CE\E6\E4\8E\55\57\C2\CA\8F\B1\A7\E8\A5\0A\4F\3A\21\1F\9E\F2\2A\ED\72\BD\B3\9D\D1\62\4F\CD\E2\88\A9\A7\45\AF\75\A8\CF\AC\E0\05\86\3B\A3\80\1B\EB\93\88\8B\8D\49\C9\01\6C\8C\C3\33\05\66\30\F1\72\BC\6A\EE\F0\9B\3B\02\87\AF\B4\80\86\7F\7C\AD\8F\EB\05\2A\ED\82\CA\C2\68\DB\E1\20\68\9F\DB\98\73\A6\43\3A\D4\91\BE\79\21\89\8C\14\A1\43\89\3F\08\88\D4\48\49\36\2E\D8\69\AB\B0\59\89\94\6B\4F\0A\6A\09\9B\DB\C3\39\4E\44\D6\1C\B0\AB\79\46\E3\8C\84\E5\40\69\1A\E4\B0\EA\85\11\4E\0B\0C\0C\0E\D8\F2\1F\91\03\21\1D\5D\65\A7\95\21\0E\0F\8F\11\8E\6F\67\75\44\69\64\B4\3E\D1\FB\A9\D1\D2\F2\95\71\4B" }>, align 64
declare { i64, i64 } @std_2fprelude_2ftext_2emul128(i64 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
@olang_loc_a4eada95f0ad22d1_b928dd828664326d = external constant [0 x i8]
@G_2estd_2fprelude_2ftext_2emask63 = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\7F" }>, align 8
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
@olang_loc_25a16543c1c048a3_ac3acc06ad2304b7 = external constant [0 x i8]
@olang_loc_747b1402afddac05_321abc763f710dd9 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_50f801f94424a14_5c76de4ac41c4c38 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2ereadDigits(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_905129bbca3acd7f_cb7c148eab960383 = external constant [0 x i8]
@olang_loc_7e5260ba99d492e_23f7bc5db39388ba = external constant [0 x i8]
@olang_loc_772a81b2a0193ab_4eeb0795ad52cbef = external constant [0 x i8]
@olang_loc_d87f88b977e3dc00_ec36da1d2da1f7ac = external constant [0 x i8]
@olang_loc_2e2cde2328365f0d_7f8402dd000c68f1 = external constant [0 x i8]
@olang_loc_e2668a7978910092_9cf11ab17c253f8e = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2efindFrom(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2)
@olang_loc_f0ac1019d5a8f22f_63f4135826f9c983 = external constant [0 x i8]
@olang_loc_ed29604078651463_1de5c36b2217515f = external constant [0 x i8]
@olang_loc_212fcf1c84890a91_ea10bf30807cf1ed = external constant [0 x i8]
@olang_loc_f0b654da92e9b0b6_ad614321653256ba = external constant [0 x i8]
@G_2estd_2fprelude_2ftext_2edecimalShifts = available_externally constant <{ [72 x i8] }> <{ [72 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00\09\00\00\00\00\00\00\00\0D\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\13\00\00\00\00\00\00\00\17\00\00\00\00\00\00\00\1A\00\00\00\00\00\00\00" }>, align 64
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2etrim(ptr %v0, ptr %a0)
@G_2estd_2fprelude_2ftext_2eexactPow10 = available_externally constant <{ [184 x i8] }> <{ [184 x i8] c"\00\00\00\00\00\00\F0\3F\00\00\00\00\00\00\24\40\00\00\00\00\00\00\59\40\00\00\00\00\00\40\8F\40\00\00\00\00\00\88\C3\40\00\00\00\00\00\6A\F8\40\00\00\00\00\80\84\2E\41\00\00\00\00\D0\12\63\41\00\00\00\00\84\D7\97\41\00\00\00\00\65\CD\CD\41\00\00\00\20\5F\A0\02\42\00\00\00\E8\76\48\37\42\00\00\00\A2\94\1A\6D\42\00\00\40\E5\9C\30\A2\42\00\00\90\1E\C4\BC\D6\42\00\00\34\26\F5\6B\0C\43\00\80\E0\37\79\C3\41\43\00\A0\D8\85\57\34\76\43\00\C8\4E\67\6D\C1\AB\43\00\3D\91\60\E4\58\E1\43\40\8C\B5\78\1D\AF\15\44\50\EF\E2\D6\E4\1A\4B\44\92\D5\4D\06\CF\F0\80\44" }>, align 64
@olang_loc_933a37c789dcabb3_fc2c50e2754a07ff = external constant [0 x i8]
@olang_loc_322251a7a19e567e_616a29da982d62a = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
